<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-06 03:37:09 --> Config Class Initialized
INFO - 2023-03-06 03:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:09 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:09 --> URI Class Initialized
INFO - 2023-03-06 03:37:09 --> Router Class Initialized
INFO - 2023-03-06 03:37:09 --> Output Class Initialized
INFO - 2023-03-06 03:37:09 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:09 --> Input Class Initialized
INFO - 2023-03-06 03:37:09 --> Language Class Initialized
INFO - 2023-03-06 03:37:09 --> Loader Class Initialized
INFO - 2023-03-06 03:37:09 --> Controller Class Initialized
INFO - 2023-03-06 03:37:09 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:09 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:09 --> Model "Change_model" initialized
INFO - 2023-03-06 03:37:09 --> Model "Grafana_model" initialized
INFO - 2023-03-06 03:37:09 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:09 --> Total execution time: 0.0385
INFO - 2023-03-06 03:37:09 --> Config Class Initialized
INFO - 2023-03-06 03:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:09 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:09 --> URI Class Initialized
INFO - 2023-03-06 03:37:09 --> Router Class Initialized
INFO - 2023-03-06 03:37:09 --> Output Class Initialized
INFO - 2023-03-06 03:37:09 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:09 --> Input Class Initialized
INFO - 2023-03-06 03:37:09 --> Language Class Initialized
INFO - 2023-03-06 03:37:09 --> Loader Class Initialized
INFO - 2023-03-06 03:37:09 --> Controller Class Initialized
INFO - 2023-03-06 03:37:09 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:09 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:09 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:09 --> Total execution time: 0.0034
INFO - 2023-03-06 03:37:09 --> Config Class Initialized
INFO - 2023-03-06 03:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:09 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:09 --> URI Class Initialized
INFO - 2023-03-06 03:37:09 --> Router Class Initialized
INFO - 2023-03-06 03:37:09 --> Output Class Initialized
INFO - 2023-03-06 03:37:09 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:09 --> Input Class Initialized
INFO - 2023-03-06 03:37:09 --> Language Class Initialized
INFO - 2023-03-06 03:37:09 --> Loader Class Initialized
INFO - 2023-03-06 03:37:09 --> Controller Class Initialized
INFO - 2023-03-06 03:37:09 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:09 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:09 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:09 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:09 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:09 --> Total execution time: 0.0182
INFO - 2023-03-06 03:37:20 --> Config Class Initialized
INFO - 2023-03-06 03:37:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:20 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:20 --> URI Class Initialized
INFO - 2023-03-06 03:37:20 --> Router Class Initialized
INFO - 2023-03-06 03:37:20 --> Output Class Initialized
INFO - 2023-03-06 03:37:20 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:20 --> Input Class Initialized
INFO - 2023-03-06 03:37:20 --> Language Class Initialized
INFO - 2023-03-06 03:37:20 --> Loader Class Initialized
INFO - 2023-03-06 03:37:20 --> Controller Class Initialized
INFO - 2023-03-06 03:37:20 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:20 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:20 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:20 --> Total execution time: 0.0458
INFO - 2023-03-06 03:37:20 --> Config Class Initialized
INFO - 2023-03-06 03:37:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:20 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:20 --> URI Class Initialized
INFO - 2023-03-06 03:37:20 --> Router Class Initialized
INFO - 2023-03-06 03:37:20 --> Output Class Initialized
INFO - 2023-03-06 03:37:20 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:20 --> Input Class Initialized
INFO - 2023-03-06 03:37:20 --> Language Class Initialized
INFO - 2023-03-06 03:37:20 --> Loader Class Initialized
INFO - 2023-03-06 03:37:20 --> Controller Class Initialized
INFO - 2023-03-06 03:37:20 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:20 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:20 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:20 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:20 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:20 --> Total execution time: 0.0259
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
INFO - 2023-03-06 03:37:27 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:27 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Model "Change_model" initialized
INFO - 2023-03-06 03:37:27 --> Model "Grafana_model" initialized
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.0267
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
INFO - 2023-03-06 03:37:27 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:27 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.0031
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
INFO - 2023-03-06 03:37:27 --> Helper loaded: form_helper
INFO - 2023-03-06 03:37:27 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:27 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.0160
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.0113
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.0119
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:27 --> Total execution time: 0.1346
INFO - 2023-03-06 03:37:27 --> Config Class Initialized
INFO - 2023-03-06 03:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:27 --> URI Class Initialized
INFO - 2023-03-06 03:37:27 --> Router Class Initialized
INFO - 2023-03-06 03:37:27 --> Output Class Initialized
INFO - 2023-03-06 03:37:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:27 --> Input Class Initialized
INFO - 2023-03-06 03:37:27 --> Language Class Initialized
INFO - 2023-03-06 03:37:27 --> Loader Class Initialized
INFO - 2023-03-06 03:37:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:28 --> Total execution time: 0.0933
INFO - 2023-03-06 03:37:33 --> Config Class Initialized
INFO - 2023-03-06 03:37:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:33 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:33 --> URI Class Initialized
INFO - 2023-03-06 03:37:33 --> Router Class Initialized
INFO - 2023-03-06 03:37:33 --> Output Class Initialized
INFO - 2023-03-06 03:37:33 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:33 --> Input Class Initialized
INFO - 2023-03-06 03:37:33 --> Language Class Initialized
INFO - 2023-03-06 03:37:33 --> Loader Class Initialized
INFO - 2023-03-06 03:37:33 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:33 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:33 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:33 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:33 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:33 --> Total execution time: 0.0249
INFO - 2023-03-06 03:37:33 --> Config Class Initialized
INFO - 2023-03-06 03:37:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:33 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:33 --> URI Class Initialized
INFO - 2023-03-06 03:37:33 --> Router Class Initialized
INFO - 2023-03-06 03:37:33 --> Output Class Initialized
INFO - 2023-03-06 03:37:33 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:33 --> Input Class Initialized
INFO - 2023-03-06 03:37:33 --> Language Class Initialized
INFO - 2023-03-06 03:37:33 --> Loader Class Initialized
INFO - 2023-03-06 03:37:33 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:33 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:33 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:33 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:33 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:33 --> Total execution time: 0.0994
INFO - 2023-03-06 03:37:48 --> Config Class Initialized
INFO - 2023-03-06 03:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:48 --> URI Class Initialized
INFO - 2023-03-06 03:37:48 --> Router Class Initialized
INFO - 2023-03-06 03:37:48 --> Output Class Initialized
INFO - 2023-03-06 03:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:48 --> Input Class Initialized
INFO - 2023-03-06 03:37:48 --> Language Class Initialized
INFO - 2023-03-06 03:37:48 --> Loader Class Initialized
INFO - 2023-03-06 03:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:48 --> Total execution time: 0.0171
INFO - 2023-03-06 03:37:48 --> Config Class Initialized
INFO - 2023-03-06 03:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:48 --> URI Class Initialized
INFO - 2023-03-06 03:37:48 --> Router Class Initialized
INFO - 2023-03-06 03:37:48 --> Output Class Initialized
INFO - 2023-03-06 03:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:48 --> Input Class Initialized
INFO - 2023-03-06 03:37:48 --> Language Class Initialized
INFO - 2023-03-06 03:37:48 --> Loader Class Initialized
INFO - 2023-03-06 03:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:48 --> Total execution time: 0.0337
INFO - 2023-03-06 03:37:48 --> Config Class Initialized
INFO - 2023-03-06 03:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:48 --> URI Class Initialized
INFO - 2023-03-06 03:37:48 --> Router Class Initialized
INFO - 2023-03-06 03:37:48 --> Output Class Initialized
INFO - 2023-03-06 03:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:48 --> Input Class Initialized
INFO - 2023-03-06 03:37:48 --> Language Class Initialized
INFO - 2023-03-06 03:37:48 --> Loader Class Initialized
INFO - 2023-03-06 03:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:48 --> Total execution time: 0.0631
INFO - 2023-03-06 03:37:48 --> Config Class Initialized
INFO - 2023-03-06 03:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:48 --> URI Class Initialized
INFO - 2023-03-06 03:37:48 --> Router Class Initialized
INFO - 2023-03-06 03:37:48 --> Output Class Initialized
INFO - 2023-03-06 03:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:48 --> Input Class Initialized
INFO - 2023-03-06 03:37:48 --> Language Class Initialized
INFO - 2023-03-06 03:37:48 --> Loader Class Initialized
INFO - 2023-03-06 03:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:48 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:48 --> Total execution time: 0.0184
INFO - 2023-03-06 03:37:51 --> Config Class Initialized
INFO - 2023-03-06 03:37:51 --> Config Class Initialized
INFO - 2023-03-06 03:37:51 --> Hooks Class Initialized
INFO - 2023-03-06 03:37:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 03:37:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:51 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:52 --> URI Class Initialized
INFO - 2023-03-06 03:37:52 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:52 --> Router Class Initialized
INFO - 2023-03-06 03:37:52 --> URI Class Initialized
INFO - 2023-03-06 03:37:52 --> Output Class Initialized
INFO - 2023-03-06 03:37:52 --> Router Class Initialized
INFO - 2023-03-06 03:37:52 --> Security Class Initialized
INFO - 2023-03-06 03:37:52 --> Output Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:52 --> Security Class Initialized
INFO - 2023-03-06 03:37:52 --> Input Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:52 --> Language Class Initialized
INFO - 2023-03-06 03:37:52 --> Input Class Initialized
INFO - 2023-03-06 03:37:52 --> Language Class Initialized
INFO - 2023-03-06 03:37:52 --> Loader Class Initialized
INFO - 2023-03-06 03:37:52 --> Loader Class Initialized
INFO - 2023-03-06 03:37:52 --> Controller Class Initialized
INFO - 2023-03-06 03:37:52 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 03:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:52 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:52 --> Total execution time: 0.0062
INFO - 2023-03-06 03:37:52 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:52 --> Config Class Initialized
INFO - 2023-03-06 03:37:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:52 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:52 --> URI Class Initialized
INFO - 2023-03-06 03:37:52 --> Router Class Initialized
INFO - 2023-03-06 03:37:52 --> Output Class Initialized
INFO - 2023-03-06 03:37:52 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:52 --> Input Class Initialized
INFO - 2023-03-06 03:37:52 --> Language Class Initialized
INFO - 2023-03-06 03:37:52 --> Loader Class Initialized
INFO - 2023-03-06 03:37:52 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:52 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:52 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:52 --> Total execution time: 0.0521
INFO - 2023-03-06 03:37:52 --> Config Class Initialized
INFO - 2023-03-06 03:37:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:52 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:52 --> URI Class Initialized
INFO - 2023-03-06 03:37:52 --> Router Class Initialized
INFO - 2023-03-06 03:37:52 --> Output Class Initialized
INFO - 2023-03-06 03:37:52 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:52 --> Input Class Initialized
INFO - 2023-03-06 03:37:52 --> Language Class Initialized
INFO - 2023-03-06 03:37:52 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:52 --> Loader Class Initialized
INFO - 2023-03-06 03:37:52 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:52 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:52 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:52 --> Final output sent to browser
INFO - 2023-03-06 03:37:52 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:52 --> Total execution time: 0.0631
DEBUG - 2023-03-06 03:37:52 --> Total execution time: 0.0162
INFO - 2023-03-06 03:37:54 --> Config Class Initialized
INFO - 2023-03-06 03:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:54 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:54 --> URI Class Initialized
INFO - 2023-03-06 03:37:54 --> Router Class Initialized
INFO - 2023-03-06 03:37:54 --> Output Class Initialized
INFO - 2023-03-06 03:37:54 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:54 --> Input Class Initialized
INFO - 2023-03-06 03:37:54 --> Language Class Initialized
INFO - 2023-03-06 03:37:54 --> Loader Class Initialized
INFO - 2023-03-06 03:37:54 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:54 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:54 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:54 --> Total execution time: 0.1056
INFO - 2023-03-06 03:37:54 --> Config Class Initialized
INFO - 2023-03-06 03:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:54 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:54 --> URI Class Initialized
INFO - 2023-03-06 03:37:54 --> Router Class Initialized
INFO - 2023-03-06 03:37:54 --> Output Class Initialized
INFO - 2023-03-06 03:37:54 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:54 --> Input Class Initialized
INFO - 2023-03-06 03:37:54 --> Language Class Initialized
INFO - 2023-03-06 03:37:54 --> Loader Class Initialized
INFO - 2023-03-06 03:37:54 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:54 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:54 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:54 --> Total execution time: 0.0156
INFO - 2023-03-06 03:37:55 --> Config Class Initialized
INFO - 2023-03-06 03:37:55 --> Hooks Class Initialized
INFO - 2023-03-06 03:37:55 --> Config Class Initialized
INFO - 2023-03-06 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:55 --> URI Class Initialized
INFO - 2023-03-06 03:37:55 --> URI Class Initialized
INFO - 2023-03-06 03:37:55 --> Router Class Initialized
INFO - 2023-03-06 03:37:55 --> Router Class Initialized
INFO - 2023-03-06 03:37:55 --> Output Class Initialized
INFO - 2023-03-06 03:37:55 --> Output Class Initialized
INFO - 2023-03-06 03:37:55 --> Security Class Initialized
INFO - 2023-03-06 03:37:55 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:55 --> Input Class Initialized
INFO - 2023-03-06 03:37:55 --> Language Class Initialized
INFO - 2023-03-06 03:37:55 --> Input Class Initialized
INFO - 2023-03-06 03:37:55 --> Loader Class Initialized
INFO - 2023-03-06 03:37:55 --> Language Class Initialized
INFO - 2023-03-06 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:55 --> Loader Class Initialized
INFO - 2023-03-06 03:37:55 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:55 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:55 --> Total execution time: 0.0069
INFO - 2023-03-06 03:37:55 --> Config Class Initialized
INFO - 2023-03-06 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:55 --> URI Class Initialized
INFO - 2023-03-06 03:37:55 --> Router Class Initialized
INFO - 2023-03-06 03:37:55 --> Output Class Initialized
INFO - 2023-03-06 03:37:55 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:55 --> Input Class Initialized
INFO - 2023-03-06 03:37:55 --> Language Class Initialized
INFO - 2023-03-06 03:37:55 --> Loader Class Initialized
INFO - 2023-03-06 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:55 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:55 --> Model "Login_model" initialized
INFO - 2023-03-06 03:37:55 --> Final output sent to browser
INFO - 2023-03-06 03:37:55 --> Database Driver Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Total execution time: 0.0225
INFO - 2023-03-06 03:37:55 --> Config Class Initialized
INFO - 2023-03-06 03:37:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:55 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:55 --> URI Class Initialized
INFO - 2023-03-06 03:37:55 --> Router Class Initialized
INFO - 2023-03-06 03:37:55 --> Output Class Initialized
INFO - 2023-03-06 03:37:55 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:55 --> Input Class Initialized
INFO - 2023-03-06 03:37:55 --> Language Class Initialized
INFO - 2023-03-06 03:37:55 --> Loader Class Initialized
INFO - 2023-03-06 03:37:55 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:55 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:55 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:55 --> Total execution time: 0.0223
INFO - 2023-03-06 03:37:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:55 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:55 --> Total execution time: 0.0537
INFO - 2023-03-06 03:37:56 --> Config Class Initialized
INFO - 2023-03-06 03:37:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:56 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:56 --> URI Class Initialized
INFO - 2023-03-06 03:37:56 --> Router Class Initialized
INFO - 2023-03-06 03:37:56 --> Output Class Initialized
INFO - 2023-03-06 03:37:56 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:56 --> Input Class Initialized
INFO - 2023-03-06 03:37:56 --> Language Class Initialized
INFO - 2023-03-06 03:37:56 --> Loader Class Initialized
INFO - 2023-03-06 03:37:56 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:56 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:56 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:56 --> Total execution time: 0.0120
INFO - 2023-03-06 03:37:56 --> Config Class Initialized
INFO - 2023-03-06 03:37:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:56 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:56 --> URI Class Initialized
INFO - 2023-03-06 03:37:56 --> Router Class Initialized
INFO - 2023-03-06 03:37:56 --> Output Class Initialized
INFO - 2023-03-06 03:37:56 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:56 --> Input Class Initialized
INFO - 2023-03-06 03:37:56 --> Language Class Initialized
INFO - 2023-03-06 03:37:56 --> Loader Class Initialized
INFO - 2023-03-06 03:37:56 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:56 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:56 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:56 --> Total execution time: 0.0503
INFO - 2023-03-06 03:37:57 --> Config Class Initialized
INFO - 2023-03-06 03:37:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:57 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:57 --> URI Class Initialized
INFO - 2023-03-06 03:37:57 --> Router Class Initialized
INFO - 2023-03-06 03:37:57 --> Output Class Initialized
INFO - 2023-03-06 03:37:57 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:57 --> Input Class Initialized
INFO - 2023-03-06 03:37:57 --> Language Class Initialized
INFO - 2023-03-06 03:37:57 --> Loader Class Initialized
INFO - 2023-03-06 03:37:57 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:57 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:57 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:57 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:57 --> Total execution time: 0.0212
INFO - 2023-03-06 03:37:57 --> Config Class Initialized
INFO - 2023-03-06 03:37:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:37:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:37:57 --> Utf8 Class Initialized
INFO - 2023-03-06 03:37:57 --> URI Class Initialized
INFO - 2023-03-06 03:37:57 --> Router Class Initialized
INFO - 2023-03-06 03:37:57 --> Output Class Initialized
INFO - 2023-03-06 03:37:57 --> Security Class Initialized
DEBUG - 2023-03-06 03:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:37:57 --> Input Class Initialized
INFO - 2023-03-06 03:37:57 --> Language Class Initialized
INFO - 2023-03-06 03:37:57 --> Loader Class Initialized
INFO - 2023-03-06 03:37:57 --> Controller Class Initialized
DEBUG - 2023-03-06 03:37:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:37:57 --> Database Driver Class Initialized
INFO - 2023-03-06 03:37:57 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:37:57 --> Final output sent to browser
DEBUG - 2023-03-06 03:37:57 --> Total execution time: 0.0527
INFO - 2023-03-06 03:38:03 --> Config Class Initialized
INFO - 2023-03-06 03:38:03 --> Config Class Initialized
INFO - 2023-03-06 03:38:03 --> Hooks Class Initialized
INFO - 2023-03-06 03:38:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 03:38:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:38:03 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:03 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:03 --> URI Class Initialized
INFO - 2023-03-06 03:38:03 --> URI Class Initialized
INFO - 2023-03-06 03:38:03 --> Router Class Initialized
INFO - 2023-03-06 03:38:03 --> Output Class Initialized
INFO - 2023-03-06 03:38:03 --> Router Class Initialized
INFO - 2023-03-06 03:38:03 --> Security Class Initialized
INFO - 2023-03-06 03:38:03 --> Output Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:03 --> Security Class Initialized
INFO - 2023-03-06 03:38:03 --> Input Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:03 --> Language Class Initialized
INFO - 2023-03-06 03:38:03 --> Input Class Initialized
INFO - 2023-03-06 03:38:03 --> Language Class Initialized
INFO - 2023-03-06 03:38:03 --> Loader Class Initialized
INFO - 2023-03-06 03:38:03 --> Loader Class Initialized
INFO - 2023-03-06 03:38:03 --> Controller Class Initialized
INFO - 2023-03-06 03:38:03 --> Controller Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 03:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:38:03 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:03 --> Total execution time: 0.0043
INFO - 2023-03-06 03:38:03 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:03 --> Config Class Initialized
INFO - 2023-03-06 03:38:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:38:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:38:03 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:03 --> URI Class Initialized
INFO - 2023-03-06 03:38:03 --> Router Class Initialized
INFO - 2023-03-06 03:38:03 --> Output Class Initialized
INFO - 2023-03-06 03:38:03 --> Security Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:03 --> Input Class Initialized
INFO - 2023-03-06 03:38:03 --> Language Class Initialized
INFO - 2023-03-06 03:38:03 --> Loader Class Initialized
INFO - 2023-03-06 03:38:03 --> Controller Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:38:03 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:38:03 --> Model "Login_model" initialized
INFO - 2023-03-06 03:38:03 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:03 --> Total execution time: 0.0178
INFO - 2023-03-06 03:38:03 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:03 --> Config Class Initialized
INFO - 2023-03-06 03:38:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:38:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:38:03 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:03 --> URI Class Initialized
INFO - 2023-03-06 03:38:03 --> Router Class Initialized
INFO - 2023-03-06 03:38:03 --> Output Class Initialized
INFO - 2023-03-06 03:38:03 --> Security Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:03 --> Input Class Initialized
INFO - 2023-03-06 03:38:03 --> Language Class Initialized
INFO - 2023-03-06 03:38:03 --> Loader Class Initialized
INFO - 2023-03-06 03:38:03 --> Controller Class Initialized
DEBUG - 2023-03-06 03:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:38:03 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:38:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:38:03 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:03 --> Total execution time: 0.0240
INFO - 2023-03-06 03:38:03 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:03 --> Total execution time: 0.0140
INFO - 2023-03-06 03:38:04 --> Config Class Initialized
INFO - 2023-03-06 03:38:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:38:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:38:04 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:04 --> URI Class Initialized
INFO - 2023-03-06 03:38:04 --> Router Class Initialized
INFO - 2023-03-06 03:38:04 --> Output Class Initialized
INFO - 2023-03-06 03:38:04 --> Security Class Initialized
DEBUG - 2023-03-06 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:04 --> Input Class Initialized
INFO - 2023-03-06 03:38:04 --> Language Class Initialized
INFO - 2023-03-06 03:38:04 --> Loader Class Initialized
INFO - 2023-03-06 03:38:04 --> Controller Class Initialized
DEBUG - 2023-03-06 03:38:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:38:04 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:38:04 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:04 --> Total execution time: 0.0188
INFO - 2023-03-06 03:38:04 --> Config Class Initialized
INFO - 2023-03-06 03:38:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:38:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:38:04 --> Utf8 Class Initialized
INFO - 2023-03-06 03:38:04 --> URI Class Initialized
INFO - 2023-03-06 03:38:04 --> Router Class Initialized
INFO - 2023-03-06 03:38:04 --> Output Class Initialized
INFO - 2023-03-06 03:38:04 --> Security Class Initialized
DEBUG - 2023-03-06 03:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:38:04 --> Input Class Initialized
INFO - 2023-03-06 03:38:04 --> Language Class Initialized
INFO - 2023-03-06 03:38:04 --> Loader Class Initialized
INFO - 2023-03-06 03:38:04 --> Controller Class Initialized
DEBUG - 2023-03-06 03:38:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:38:04 --> Database Driver Class Initialized
INFO - 2023-03-06 03:38:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:38:04 --> Final output sent to browser
DEBUG - 2023-03-06 03:38:04 --> Total execution time: 0.0220
INFO - 2023-03-06 03:51:47 --> Config Class Initialized
INFO - 2023-03-06 03:51:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:51:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:51:47 --> Utf8 Class Initialized
INFO - 2023-03-06 03:51:47 --> URI Class Initialized
INFO - 2023-03-06 03:51:47 --> Router Class Initialized
INFO - 2023-03-06 03:51:47 --> Output Class Initialized
INFO - 2023-03-06 03:51:47 --> Security Class Initialized
DEBUG - 2023-03-06 03:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:51:47 --> Input Class Initialized
INFO - 2023-03-06 03:51:47 --> Language Class Initialized
INFO - 2023-03-06 03:51:47 --> Loader Class Initialized
INFO - 2023-03-06 03:51:47 --> Controller Class Initialized
DEBUG - 2023-03-06 03:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:51:47 --> Database Driver Class Initialized
INFO - 2023-03-06 03:51:47 --> Final output sent to browser
DEBUG - 2023-03-06 03:51:47 --> Total execution time: 0.0131
INFO - 2023-03-06 03:51:47 --> Config Class Initialized
INFO - 2023-03-06 03:51:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:51:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:51:47 --> Utf8 Class Initialized
INFO - 2023-03-06 03:51:47 --> URI Class Initialized
INFO - 2023-03-06 03:51:47 --> Router Class Initialized
INFO - 2023-03-06 03:51:47 --> Output Class Initialized
INFO - 2023-03-06 03:51:47 --> Security Class Initialized
DEBUG - 2023-03-06 03:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:51:47 --> Input Class Initialized
INFO - 2023-03-06 03:51:47 --> Language Class Initialized
INFO - 2023-03-06 03:51:47 --> Loader Class Initialized
INFO - 2023-03-06 03:51:47 --> Controller Class Initialized
DEBUG - 2023-03-06 03:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:51:47 --> Database Driver Class Initialized
INFO - 2023-03-06 03:51:48 --> Final output sent to browser
DEBUG - 2023-03-06 03:51:48 --> Total execution time: 0.6862
INFO - 2023-03-06 03:52:10 --> Config Class Initialized
INFO - 2023-03-06 03:52:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:52:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:52:10 --> Utf8 Class Initialized
INFO - 2023-03-06 03:52:10 --> URI Class Initialized
INFO - 2023-03-06 03:52:10 --> Router Class Initialized
INFO - 2023-03-06 03:52:10 --> Output Class Initialized
INFO - 2023-03-06 03:52:10 --> Security Class Initialized
DEBUG - 2023-03-06 03:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:52:10 --> Input Class Initialized
INFO - 2023-03-06 03:52:10 --> Language Class Initialized
INFO - 2023-03-06 03:52:10 --> Loader Class Initialized
INFO - 2023-03-06 03:52:10 --> Controller Class Initialized
DEBUG - 2023-03-06 03:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:52:10 --> Database Driver Class Initialized
INFO - 2023-03-06 03:52:11 --> Final output sent to browser
DEBUG - 2023-03-06 03:52:11 --> Total execution time: 0.0123
INFO - 2023-03-06 03:52:11 --> Config Class Initialized
INFO - 2023-03-06 03:52:11 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:52:11 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:52:11 --> Utf8 Class Initialized
INFO - 2023-03-06 03:52:11 --> URI Class Initialized
INFO - 2023-03-06 03:52:11 --> Router Class Initialized
INFO - 2023-03-06 03:52:11 --> Output Class Initialized
INFO - 2023-03-06 03:52:11 --> Security Class Initialized
DEBUG - 2023-03-06 03:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:52:11 --> Input Class Initialized
INFO - 2023-03-06 03:52:11 --> Language Class Initialized
INFO - 2023-03-06 03:52:11 --> Loader Class Initialized
INFO - 2023-03-06 03:52:11 --> Controller Class Initialized
DEBUG - 2023-03-06 03:52:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:52:11 --> Database Driver Class Initialized
INFO - 2023-03-06 03:52:11 --> Final output sent to browser
DEBUG - 2023-03-06 03:52:11 --> Total execution time: 0.0779
INFO - 2023-03-06 03:52:14 --> Config Class Initialized
INFO - 2023-03-06 03:52:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:52:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:52:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:52:14 --> URI Class Initialized
INFO - 2023-03-06 03:52:14 --> Router Class Initialized
INFO - 2023-03-06 03:52:14 --> Output Class Initialized
INFO - 2023-03-06 03:52:14 --> Security Class Initialized
DEBUG - 2023-03-06 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:52:14 --> Input Class Initialized
INFO - 2023-03-06 03:52:14 --> Language Class Initialized
INFO - 2023-03-06 03:52:14 --> Loader Class Initialized
INFO - 2023-03-06 03:52:14 --> Controller Class Initialized
DEBUG - 2023-03-06 03:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:52:14 --> Database Driver Class Initialized
INFO - 2023-03-06 03:52:14 --> Final output sent to browser
DEBUG - 2023-03-06 03:52:14 --> Total execution time: 0.0124
INFO - 2023-03-06 03:52:14 --> Config Class Initialized
INFO - 2023-03-06 03:52:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:52:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:52:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:52:14 --> URI Class Initialized
INFO - 2023-03-06 03:52:14 --> Router Class Initialized
INFO - 2023-03-06 03:52:14 --> Output Class Initialized
INFO - 2023-03-06 03:52:14 --> Security Class Initialized
DEBUG - 2023-03-06 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:52:14 --> Input Class Initialized
INFO - 2023-03-06 03:52:14 --> Language Class Initialized
INFO - 2023-03-06 03:52:14 --> Loader Class Initialized
INFO - 2023-03-06 03:52:14 --> Controller Class Initialized
DEBUG - 2023-03-06 03:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:52:14 --> Database Driver Class Initialized
INFO - 2023-03-06 03:52:14 --> Final output sent to browser
DEBUG - 2023-03-06 03:52:14 --> Total execution time: 0.0147
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
INFO - 2023-03-06 03:54:28 --> Helper loaded: form_helper
INFO - 2023-03-06 03:54:28 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Model "Change_model" initialized
INFO - 2023-03-06 03:54:28 --> Model "Grafana_model" initialized
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.0355
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
INFO - 2023-03-06 03:54:28 --> Helper loaded: form_helper
INFO - 2023-03-06 03:54:28 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.0881
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
INFO - 2023-03-06 03:54:28 --> Helper loaded: form_helper
INFO - 2023-03-06 03:54:28 --> Helper loaded: url_helper
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:28 --> Model "Login_model" initialized
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.1072
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.0219
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.0179
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:28 --> Total execution time: 0.0451
INFO - 2023-03-06 03:54:28 --> Config Class Initialized
INFO - 2023-03-06 03:54:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:28 --> URI Class Initialized
INFO - 2023-03-06 03:54:28 --> Router Class Initialized
INFO - 2023-03-06 03:54:28 --> Output Class Initialized
INFO - 2023-03-06 03:54:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:28 --> Input Class Initialized
INFO - 2023-03-06 03:54:28 --> Language Class Initialized
INFO - 2023-03-06 03:54:28 --> Loader Class Initialized
INFO - 2023-03-06 03:54:29 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:29 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:29 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:29 --> Total execution time: 0.0609
INFO - 2023-03-06 03:54:30 --> Config Class Initialized
INFO - 2023-03-06 03:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:30 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:30 --> URI Class Initialized
INFO - 2023-03-06 03:54:30 --> Router Class Initialized
INFO - 2023-03-06 03:54:30 --> Output Class Initialized
INFO - 2023-03-06 03:54:30 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:30 --> Input Class Initialized
INFO - 2023-03-06 03:54:30 --> Language Class Initialized
INFO - 2023-03-06 03:54:30 --> Loader Class Initialized
INFO - 2023-03-06 03:54:30 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:30 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:30 --> Total execution time: 0.0036
INFO - 2023-03-06 03:54:30 --> Config Class Initialized
INFO - 2023-03-06 03:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:30 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:30 --> URI Class Initialized
INFO - 2023-03-06 03:54:30 --> Router Class Initialized
INFO - 2023-03-06 03:54:30 --> Output Class Initialized
INFO - 2023-03-06 03:54:30 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:30 --> Input Class Initialized
INFO - 2023-03-06 03:54:30 --> Language Class Initialized
INFO - 2023-03-06 03:54:30 --> Loader Class Initialized
INFO - 2023-03-06 03:54:30 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:30 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:30 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:30 --> Total execution time: 0.0586
INFO - 2023-03-06 03:54:30 --> Config Class Initialized
INFO - 2023-03-06 03:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:30 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:30 --> URI Class Initialized
INFO - 2023-03-06 03:54:30 --> Router Class Initialized
INFO - 2023-03-06 03:54:30 --> Output Class Initialized
INFO - 2023-03-06 03:54:30 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:30 --> Input Class Initialized
INFO - 2023-03-06 03:54:30 --> Language Class Initialized
INFO - 2023-03-06 03:54:30 --> Loader Class Initialized
INFO - 2023-03-06 03:54:30 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:30 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:30 --> Total execution time: 0.0452
INFO - 2023-03-06 03:54:30 --> Config Class Initialized
INFO - 2023-03-06 03:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:30 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:30 --> URI Class Initialized
INFO - 2023-03-06 03:54:30 --> Router Class Initialized
INFO - 2023-03-06 03:54:30 --> Output Class Initialized
INFO - 2023-03-06 03:54:30 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:30 --> Input Class Initialized
INFO - 2023-03-06 03:54:30 --> Language Class Initialized
INFO - 2023-03-06 03:54:30 --> Loader Class Initialized
INFO - 2023-03-06 03:54:30 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:30 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:30 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:30 --> Total execution time: 0.0094
INFO - 2023-03-06 03:54:44 --> Config Class Initialized
INFO - 2023-03-06 03:54:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:44 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:44 --> URI Class Initialized
INFO - 2023-03-06 03:54:44 --> Router Class Initialized
INFO - 2023-03-06 03:54:44 --> Output Class Initialized
INFO - 2023-03-06 03:54:44 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:44 --> Input Class Initialized
INFO - 2023-03-06 03:54:44 --> Language Class Initialized
INFO - 2023-03-06 03:54:44 --> Loader Class Initialized
INFO - 2023-03-06 03:54:44 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:44 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:44 --> Total execution time: 0.0044
INFO - 2023-03-06 03:54:44 --> Config Class Initialized
INFO - 2023-03-06 03:54:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:44 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:44 --> URI Class Initialized
INFO - 2023-03-06 03:54:44 --> Router Class Initialized
INFO - 2023-03-06 03:54:44 --> Output Class Initialized
INFO - 2023-03-06 03:54:44 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:44 --> Input Class Initialized
INFO - 2023-03-06 03:54:44 --> Language Class Initialized
INFO - 2023-03-06 03:54:44 --> Loader Class Initialized
INFO - 2023-03-06 03:54:44 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:44 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:44 --> Model "Login_model" initialized
INFO - 2023-03-06 03:54:44 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:44 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:44 --> Total execution time: 0.0288
INFO - 2023-03-06 03:54:44 --> Config Class Initialized
INFO - 2023-03-06 03:54:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:44 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:44 --> URI Class Initialized
INFO - 2023-03-06 03:54:44 --> Router Class Initialized
INFO - 2023-03-06 03:54:44 --> Output Class Initialized
INFO - 2023-03-06 03:54:44 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:44 --> Input Class Initialized
INFO - 2023-03-06 03:54:44 --> Language Class Initialized
INFO - 2023-03-06 03:54:44 --> Loader Class Initialized
INFO - 2023-03-06 03:54:44 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:44 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:44 --> Total execution time: 0.0048
INFO - 2023-03-06 03:54:44 --> Config Class Initialized
INFO - 2023-03-06 03:54:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:44 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:44 --> URI Class Initialized
INFO - 2023-03-06 03:54:44 --> Router Class Initialized
INFO - 2023-03-06 03:54:44 --> Output Class Initialized
INFO - 2023-03-06 03:54:44 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:44 --> Input Class Initialized
INFO - 2023-03-06 03:54:44 --> Language Class Initialized
INFO - 2023-03-06 03:54:44 --> Loader Class Initialized
INFO - 2023-03-06 03:54:44 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:44 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:44 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:44 --> Total execution time: 0.1643
INFO - 2023-03-06 03:54:49 --> Config Class Initialized
INFO - 2023-03-06 03:54:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:49 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:49 --> URI Class Initialized
INFO - 2023-03-06 03:54:49 --> Router Class Initialized
INFO - 2023-03-06 03:54:49 --> Output Class Initialized
INFO - 2023-03-06 03:54:49 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:49 --> Input Class Initialized
INFO - 2023-03-06 03:54:49 --> Language Class Initialized
INFO - 2023-03-06 03:54:49 --> Loader Class Initialized
INFO - 2023-03-06 03:54:49 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:49 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:49 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:49 --> Total execution time: 0.0219
INFO - 2023-03-06 03:54:54 --> Config Class Initialized
INFO - 2023-03-06 03:54:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:54 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:54 --> URI Class Initialized
INFO - 2023-03-06 03:54:54 --> Router Class Initialized
INFO - 2023-03-06 03:54:54 --> Output Class Initialized
INFO - 2023-03-06 03:54:54 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:54 --> Input Class Initialized
INFO - 2023-03-06 03:54:54 --> Language Class Initialized
INFO - 2023-03-06 03:54:54 --> Loader Class Initialized
INFO - 2023-03-06 03:54:54 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:54 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:54 --> Total execution time: 0.0037
INFO - 2023-03-06 03:54:54 --> Config Class Initialized
INFO - 2023-03-06 03:54:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:54 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:54 --> URI Class Initialized
INFO - 2023-03-06 03:54:54 --> Router Class Initialized
INFO - 2023-03-06 03:54:54 --> Output Class Initialized
INFO - 2023-03-06 03:54:54 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:54 --> Input Class Initialized
INFO - 2023-03-06 03:54:54 --> Language Class Initialized
INFO - 2023-03-06 03:54:54 --> Loader Class Initialized
INFO - 2023-03-06 03:54:54 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:54 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:54 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:54 --> Total execution time: 0.0167
INFO - 2023-03-06 03:54:59 --> Config Class Initialized
INFO - 2023-03-06 03:54:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:54:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:54:59 --> Utf8 Class Initialized
INFO - 2023-03-06 03:54:59 --> URI Class Initialized
INFO - 2023-03-06 03:54:59 --> Router Class Initialized
INFO - 2023-03-06 03:54:59 --> Output Class Initialized
INFO - 2023-03-06 03:54:59 --> Security Class Initialized
DEBUG - 2023-03-06 03:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:54:59 --> Input Class Initialized
INFO - 2023-03-06 03:54:59 --> Language Class Initialized
INFO - 2023-03-06 03:54:59 --> Loader Class Initialized
INFO - 2023-03-06 03:54:59 --> Controller Class Initialized
DEBUG - 2023-03-06 03:54:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:54:59 --> Database Driver Class Initialized
INFO - 2023-03-06 03:54:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:54:59 --> Final output sent to browser
DEBUG - 2023-03-06 03:54:59 --> Total execution time: 0.0168
INFO - 2023-03-06 03:55:04 --> Config Class Initialized
INFO - 2023-03-06 03:55:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:55:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:55:04 --> Utf8 Class Initialized
INFO - 2023-03-06 03:55:04 --> URI Class Initialized
INFO - 2023-03-06 03:55:04 --> Router Class Initialized
INFO - 2023-03-06 03:55:04 --> Output Class Initialized
INFO - 2023-03-06 03:55:04 --> Security Class Initialized
DEBUG - 2023-03-06 03:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:55:04 --> Input Class Initialized
INFO - 2023-03-06 03:55:04 --> Language Class Initialized
INFO - 2023-03-06 03:55:04 --> Loader Class Initialized
INFO - 2023-03-06 03:55:04 --> Controller Class Initialized
DEBUG - 2023-03-06 03:55:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:55:04 --> Final output sent to browser
DEBUG - 2023-03-06 03:55:04 --> Total execution time: 0.0045
INFO - 2023-03-06 03:55:04 --> Config Class Initialized
INFO - 2023-03-06 03:55:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:55:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:55:04 --> Utf8 Class Initialized
INFO - 2023-03-06 03:55:04 --> URI Class Initialized
INFO - 2023-03-06 03:55:04 --> Router Class Initialized
INFO - 2023-03-06 03:55:04 --> Output Class Initialized
INFO - 2023-03-06 03:55:04 --> Security Class Initialized
DEBUG - 2023-03-06 03:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:55:04 --> Input Class Initialized
INFO - 2023-03-06 03:55:04 --> Language Class Initialized
INFO - 2023-03-06 03:55:04 --> Loader Class Initialized
INFO - 2023-03-06 03:55:04 --> Controller Class Initialized
DEBUG - 2023-03-06 03:55:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:55:04 --> Database Driver Class Initialized
INFO - 2023-03-06 03:55:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:55:04 --> Final output sent to browser
DEBUG - 2023-03-06 03:55:04 --> Total execution time: 0.0167
INFO - 2023-03-06 03:55:07 --> Config Class Initialized
INFO - 2023-03-06 03:55:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:55:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:55:07 --> Utf8 Class Initialized
INFO - 2023-03-06 03:55:07 --> URI Class Initialized
INFO - 2023-03-06 03:55:07 --> Router Class Initialized
INFO - 2023-03-06 03:55:07 --> Output Class Initialized
INFO - 2023-03-06 03:55:07 --> Security Class Initialized
DEBUG - 2023-03-06 03:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:55:07 --> Input Class Initialized
INFO - 2023-03-06 03:55:07 --> Language Class Initialized
INFO - 2023-03-06 03:55:07 --> Loader Class Initialized
INFO - 2023-03-06 03:55:07 --> Controller Class Initialized
DEBUG - 2023-03-06 03:55:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:55:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:55:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:55:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:55:07 --> Model "Login_model" initialized
INFO - 2023-03-06 03:55:07 --> Final output sent to browser
DEBUG - 2023-03-06 03:55:07 --> Total execution time: 0.0382
INFO - 2023-03-06 03:55:07 --> Config Class Initialized
INFO - 2023-03-06 03:55:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:55:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:55:07 --> Utf8 Class Initialized
INFO - 2023-03-06 03:55:07 --> URI Class Initialized
INFO - 2023-03-06 03:55:07 --> Router Class Initialized
INFO - 2023-03-06 03:55:07 --> Output Class Initialized
INFO - 2023-03-06 03:55:07 --> Security Class Initialized
DEBUG - 2023-03-06 03:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:55:07 --> Input Class Initialized
INFO - 2023-03-06 03:55:07 --> Language Class Initialized
INFO - 2023-03-06 03:55:07 --> Loader Class Initialized
INFO - 2023-03-06 03:55:07 --> Controller Class Initialized
DEBUG - 2023-03-06 03:55:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:55:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:55:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:55:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:55:07 --> Model "Login_model" initialized
INFO - 2023-03-06 03:55:07 --> Final output sent to browser
DEBUG - 2023-03-06 03:55:07 --> Total execution time: 0.0721
INFO - 2023-03-06 03:56:28 --> Config Class Initialized
INFO - 2023-03-06 03:56:28 --> Config Class Initialized
INFO - 2023-03-06 03:56:28 --> Hooks Class Initialized
INFO - 2023-03-06 03:56:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 03:56:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:56:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:28 --> URI Class Initialized
INFO - 2023-03-06 03:56:28 --> URI Class Initialized
INFO - 2023-03-06 03:56:28 --> Router Class Initialized
INFO - 2023-03-06 03:56:28 --> Router Class Initialized
INFO - 2023-03-06 03:56:28 --> Output Class Initialized
INFO - 2023-03-06 03:56:28 --> Output Class Initialized
INFO - 2023-03-06 03:56:28 --> Security Class Initialized
INFO - 2023-03-06 03:56:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 03:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:56:28 --> Input Class Initialized
INFO - 2023-03-06 03:56:28 --> Input Class Initialized
INFO - 2023-03-06 03:56:28 --> Language Class Initialized
INFO - 2023-03-06 03:56:28 --> Language Class Initialized
INFO - 2023-03-06 03:56:28 --> Loader Class Initialized
INFO - 2023-03-06 03:56:28 --> Loader Class Initialized
INFO - 2023-03-06 03:56:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:56:28 --> Total execution time: 0.0048
INFO - 2023-03-06 03:56:28 --> Config Class Initialized
INFO - 2023-03-06 03:56:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:56:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:56:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:56:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:28 --> URI Class Initialized
INFO - 2023-03-06 03:56:28 --> Router Class Initialized
INFO - 2023-03-06 03:56:28 --> Output Class Initialized
INFO - 2023-03-06 03:56:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:56:28 --> Input Class Initialized
INFO - 2023-03-06 03:56:28 --> Language Class Initialized
INFO - 2023-03-06 03:56:28 --> Loader Class Initialized
INFO - 2023-03-06 03:56:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:56:28 --> Total execution time: 0.0511
INFO - 2023-03-06 03:56:28 --> Config Class Initialized
INFO - 2023-03-06 03:56:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:56:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:56:28 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:28 --> URI Class Initialized
INFO - 2023-03-06 03:56:28 --> Router Class Initialized
INFO - 2023-03-06 03:56:28 --> Output Class Initialized
INFO - 2023-03-06 03:56:28 --> Security Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:56:28 --> Input Class Initialized
INFO - 2023-03-06 03:56:28 --> Language Class Initialized
INFO - 2023-03-06 03:56:28 --> Loader Class Initialized
INFO - 2023-03-06 03:56:28 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:28 --> Model "Login_model" initialized
INFO - 2023-03-06 03:56:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:28 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:56:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:56:28 --> Final output sent to browser
INFO - 2023-03-06 03:56:28 --> Final output sent to browser
DEBUG - 2023-03-06 03:56:28 --> Total execution time: 0.0618
DEBUG - 2023-03-06 03:56:28 --> Total execution time: 0.0150
INFO - 2023-03-06 03:56:29 --> Config Class Initialized
INFO - 2023-03-06 03:56:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:56:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:56:29 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:29 --> URI Class Initialized
INFO - 2023-03-06 03:56:29 --> Router Class Initialized
INFO - 2023-03-06 03:56:29 --> Output Class Initialized
INFO - 2023-03-06 03:56:29 --> Security Class Initialized
DEBUG - 2023-03-06 03:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:56:29 --> Input Class Initialized
INFO - 2023-03-06 03:56:29 --> Language Class Initialized
INFO - 2023-03-06 03:56:29 --> Loader Class Initialized
INFO - 2023-03-06 03:56:29 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:29 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:56:29 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:29 --> Model "Login_model" initialized
INFO - 2023-03-06 03:56:29 --> Final output sent to browser
DEBUG - 2023-03-06 03:56:29 --> Total execution time: 0.0448
INFO - 2023-03-06 03:56:29 --> Config Class Initialized
INFO - 2023-03-06 03:56:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:56:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:56:29 --> Utf8 Class Initialized
INFO - 2023-03-06 03:56:29 --> URI Class Initialized
INFO - 2023-03-06 03:56:29 --> Router Class Initialized
INFO - 2023-03-06 03:56:29 --> Output Class Initialized
INFO - 2023-03-06 03:56:29 --> Security Class Initialized
DEBUG - 2023-03-06 03:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:56:29 --> Input Class Initialized
INFO - 2023-03-06 03:56:29 --> Language Class Initialized
INFO - 2023-03-06 03:56:29 --> Loader Class Initialized
INFO - 2023-03-06 03:56:29 --> Controller Class Initialized
DEBUG - 2023-03-06 03:56:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:56:29 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:56:29 --> Database Driver Class Initialized
INFO - 2023-03-06 03:56:29 --> Model "Login_model" initialized
INFO - 2023-03-06 03:56:29 --> Final output sent to browser
DEBUG - 2023-03-06 03:56:29 --> Total execution time: 0.0412
INFO - 2023-03-06 03:57:27 --> Config Class Initialized
INFO - 2023-03-06 03:57:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:57:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:57:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:57:27 --> URI Class Initialized
INFO - 2023-03-06 03:57:27 --> Router Class Initialized
INFO - 2023-03-06 03:57:27 --> Output Class Initialized
INFO - 2023-03-06 03:57:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:57:27 --> Input Class Initialized
INFO - 2023-03-06 03:57:27 --> Language Class Initialized
INFO - 2023-03-06 03:57:27 --> Loader Class Initialized
INFO - 2023-03-06 03:57:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:57:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:57:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:57:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:57:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:57:27 --> Model "Login_model" initialized
INFO - 2023-03-06 03:57:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:57:27 --> Total execution time: 0.0435
INFO - 2023-03-06 03:57:27 --> Config Class Initialized
INFO - 2023-03-06 03:57:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:57:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:57:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:57:27 --> URI Class Initialized
INFO - 2023-03-06 03:57:27 --> Router Class Initialized
INFO - 2023-03-06 03:57:27 --> Output Class Initialized
INFO - 2023-03-06 03:57:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:57:27 --> Input Class Initialized
INFO - 2023-03-06 03:57:27 --> Language Class Initialized
INFO - 2023-03-06 03:57:27 --> Loader Class Initialized
INFO - 2023-03-06 03:57:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:57:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:57:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:57:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:57:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:57:27 --> Model "Login_model" initialized
INFO - 2023-03-06 03:57:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:57:27 --> Total execution time: 0.0805
INFO - 2023-03-06 03:58:07 --> Config Class Initialized
INFO - 2023-03-06 03:58:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:07 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:07 --> URI Class Initialized
INFO - 2023-03-06 03:58:07 --> Router Class Initialized
INFO - 2023-03-06 03:58:07 --> Output Class Initialized
INFO - 2023-03-06 03:58:07 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:07 --> Input Class Initialized
INFO - 2023-03-06 03:58:07 --> Language Class Initialized
INFO - 2023-03-06 03:58:07 --> Loader Class Initialized
INFO - 2023-03-06 03:58:07 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:07 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:07 --> Total execution time: 0.0313
INFO - 2023-03-06 03:58:07 --> Config Class Initialized
INFO - 2023-03-06 03:58:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:07 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:07 --> URI Class Initialized
INFO - 2023-03-06 03:58:07 --> Router Class Initialized
INFO - 2023-03-06 03:58:07 --> Output Class Initialized
INFO - 2023-03-06 03:58:07 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:07 --> Input Class Initialized
INFO - 2023-03-06 03:58:07 --> Language Class Initialized
INFO - 2023-03-06 03:58:07 --> Loader Class Initialized
INFO - 2023-03-06 03:58:07 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:07 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:07 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:07 --> Total execution time: 0.0643
INFO - 2023-03-06 03:58:14 --> Config Class Initialized
INFO - 2023-03-06 03:58:14 --> Hooks Class Initialized
INFO - 2023-03-06 03:58:14 --> Config Class Initialized
INFO - 2023-03-06 03:58:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 03:58:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:14 --> URI Class Initialized
INFO - 2023-03-06 03:58:14 --> URI Class Initialized
INFO - 2023-03-06 03:58:14 --> Router Class Initialized
INFO - 2023-03-06 03:58:14 --> Router Class Initialized
INFO - 2023-03-06 03:58:14 --> Output Class Initialized
INFO - 2023-03-06 03:58:14 --> Output Class Initialized
INFO - 2023-03-06 03:58:14 --> Security Class Initialized
INFO - 2023-03-06 03:58:14 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:14 --> Input Class Initialized
INFO - 2023-03-06 03:58:14 --> Input Class Initialized
INFO - 2023-03-06 03:58:14 --> Language Class Initialized
INFO - 2023-03-06 03:58:14 --> Language Class Initialized
INFO - 2023-03-06 03:58:14 --> Loader Class Initialized
INFO - 2023-03-06 03:58:14 --> Loader Class Initialized
INFO - 2023-03-06 03:58:14 --> Controller Class Initialized
INFO - 2023-03-06 03:58:14 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 03:58:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:14 --> Final output sent to browser
INFO - 2023-03-06 03:58:14 --> Database Driver Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Total execution time: 0.0037
INFO - 2023-03-06 03:58:14 --> Config Class Initialized
INFO - 2023-03-06 03:58:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:14 --> URI Class Initialized
INFO - 2023-03-06 03:58:14 --> Router Class Initialized
INFO - 2023-03-06 03:58:14 --> Output Class Initialized
INFO - 2023-03-06 03:58:14 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:14 --> Input Class Initialized
INFO - 2023-03-06 03:58:14 --> Language Class Initialized
INFO - 2023-03-06 03:58:14 --> Loader Class Initialized
INFO - 2023-03-06 03:58:14 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:14 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:14 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:14 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:14 --> Total execution time: 0.0159
INFO - 2023-03-06 03:58:14 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:14 --> Config Class Initialized
INFO - 2023-03-06 03:58:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:14 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:14 --> URI Class Initialized
INFO - 2023-03-06 03:58:14 --> Router Class Initialized
INFO - 2023-03-06 03:58:14 --> Output Class Initialized
INFO - 2023-03-06 03:58:14 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:14 --> Input Class Initialized
INFO - 2023-03-06 03:58:14 --> Language Class Initialized
INFO - 2023-03-06 03:58:14 --> Loader Class Initialized
INFO - 2023-03-06 03:58:14 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:14 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:14 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:14 --> Total execution time: 0.0179
INFO - 2023-03-06 03:58:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:14 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:14 --> Total execution time: 0.0527
INFO - 2023-03-06 03:58:16 --> Config Class Initialized
INFO - 2023-03-06 03:58:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:16 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:16 --> URI Class Initialized
INFO - 2023-03-06 03:58:16 --> Router Class Initialized
INFO - 2023-03-06 03:58:16 --> Output Class Initialized
INFO - 2023-03-06 03:58:16 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:16 --> Input Class Initialized
INFO - 2023-03-06 03:58:16 --> Language Class Initialized
INFO - 2023-03-06 03:58:16 --> Loader Class Initialized
INFO - 2023-03-06 03:58:16 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:16 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:16 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:16 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:16 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:16 --> Total execution time: 0.1655
INFO - 2023-03-06 03:58:16 --> Config Class Initialized
INFO - 2023-03-06 03:58:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:16 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:16 --> URI Class Initialized
INFO - 2023-03-06 03:58:16 --> Router Class Initialized
INFO - 2023-03-06 03:58:16 --> Output Class Initialized
INFO - 2023-03-06 03:58:16 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:16 --> Input Class Initialized
INFO - 2023-03-06 03:58:16 --> Language Class Initialized
INFO - 2023-03-06 03:58:16 --> Loader Class Initialized
INFO - 2023-03-06 03:58:16 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:16 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:16 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:16 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:16 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:16 --> Total execution time: 0.0396
INFO - 2023-03-06 03:58:17 --> Config Class Initialized
INFO - 2023-03-06 03:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:17 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:17 --> URI Class Initialized
INFO - 2023-03-06 03:58:17 --> Router Class Initialized
INFO - 2023-03-06 03:58:17 --> Output Class Initialized
INFO - 2023-03-06 03:58:17 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:17 --> Input Class Initialized
INFO - 2023-03-06 03:58:17 --> Language Class Initialized
INFO - 2023-03-06 03:58:17 --> Loader Class Initialized
INFO - 2023-03-06 03:58:17 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:17 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:17 --> Total execution time: 0.0466
INFO - 2023-03-06 03:58:17 --> Config Class Initialized
INFO - 2023-03-06 03:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:17 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:17 --> URI Class Initialized
INFO - 2023-03-06 03:58:17 --> Router Class Initialized
INFO - 2023-03-06 03:58:17 --> Output Class Initialized
INFO - 2023-03-06 03:58:17 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:17 --> Input Class Initialized
INFO - 2023-03-06 03:58:17 --> Language Class Initialized
INFO - 2023-03-06 03:58:17 --> Loader Class Initialized
INFO - 2023-03-06 03:58:17 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:17 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:17 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:17 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:17 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:17 --> Total execution time: 0.0207
INFO - 2023-03-06 03:58:17 --> Config Class Initialized
INFO - 2023-03-06 03:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:17 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:17 --> URI Class Initialized
INFO - 2023-03-06 03:58:17 --> Router Class Initialized
INFO - 2023-03-06 03:58:17 --> Output Class Initialized
INFO - 2023-03-06 03:58:17 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:17 --> Input Class Initialized
INFO - 2023-03-06 03:58:17 --> Language Class Initialized
INFO - 2023-03-06 03:58:17 --> Loader Class Initialized
INFO - 2023-03-06 03:58:17 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:17 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:17 --> Total execution time: 0.0421
INFO - 2023-03-06 03:58:17 --> Config Class Initialized
INFO - 2023-03-06 03:58:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:17 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:17 --> URI Class Initialized
INFO - 2023-03-06 03:58:17 --> Router Class Initialized
INFO - 2023-03-06 03:58:17 --> Output Class Initialized
INFO - 2023-03-06 03:58:17 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:17 --> Input Class Initialized
INFO - 2023-03-06 03:58:17 --> Language Class Initialized
INFO - 2023-03-06 03:58:17 --> Loader Class Initialized
INFO - 2023-03-06 03:58:17 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:17 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:17 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:17 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:17 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:17 --> Total execution time: 0.0228
INFO - 2023-03-06 03:58:18 --> Config Class Initialized
INFO - 2023-03-06 03:58:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:18 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:18 --> URI Class Initialized
INFO - 2023-03-06 03:58:18 --> Router Class Initialized
INFO - 2023-03-06 03:58:18 --> Output Class Initialized
INFO - 2023-03-06 03:58:18 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:18 --> Input Class Initialized
INFO - 2023-03-06 03:58:18 --> Language Class Initialized
INFO - 2023-03-06 03:58:18 --> Loader Class Initialized
INFO - 2023-03-06 03:58:18 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:18 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:18 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:18 --> Total execution time: 0.0169
INFO - 2023-03-06 03:58:18 --> Config Class Initialized
INFO - 2023-03-06 03:58:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:18 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:18 --> URI Class Initialized
INFO - 2023-03-06 03:58:18 --> Router Class Initialized
INFO - 2023-03-06 03:58:18 --> Output Class Initialized
INFO - 2023-03-06 03:58:18 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:18 --> Input Class Initialized
INFO - 2023-03-06 03:58:18 --> Language Class Initialized
INFO - 2023-03-06 03:58:18 --> Loader Class Initialized
INFO - 2023-03-06 03:58:18 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:18 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:18 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:18 --> Total execution time: 0.0523
INFO - 2023-03-06 03:58:20 --> Config Class Initialized
INFO - 2023-03-06 03:58:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:20 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:20 --> URI Class Initialized
INFO - 2023-03-06 03:58:20 --> Router Class Initialized
INFO - 2023-03-06 03:58:20 --> Output Class Initialized
INFO - 2023-03-06 03:58:20 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:20 --> Input Class Initialized
INFO - 2023-03-06 03:58:20 --> Language Class Initialized
INFO - 2023-03-06 03:58:20 --> Loader Class Initialized
INFO - 2023-03-06 03:58:20 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:20 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:20 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:20 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:20 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:20 --> Total execution time: 0.0415
INFO - 2023-03-06 03:58:22 --> Config Class Initialized
INFO - 2023-03-06 03:58:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:22 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:22 --> URI Class Initialized
INFO - 2023-03-06 03:58:22 --> Router Class Initialized
INFO - 2023-03-06 03:58:22 --> Output Class Initialized
INFO - 2023-03-06 03:58:22 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:22 --> Input Class Initialized
INFO - 2023-03-06 03:58:22 --> Language Class Initialized
INFO - 2023-03-06 03:58:22 --> Loader Class Initialized
INFO - 2023-03-06 03:58:22 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:22 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:22 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:22 --> Total execution time: 0.0455
INFO - 2023-03-06 03:58:22 --> Config Class Initialized
INFO - 2023-03-06 03:58:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:22 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:22 --> URI Class Initialized
INFO - 2023-03-06 03:58:22 --> Router Class Initialized
INFO - 2023-03-06 03:58:22 --> Output Class Initialized
INFO - 2023-03-06 03:58:22 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:22 --> Input Class Initialized
INFO - 2023-03-06 03:58:22 --> Language Class Initialized
INFO - 2023-03-06 03:58:22 --> Loader Class Initialized
INFO - 2023-03-06 03:58:22 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:22 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:22 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:22 --> Total execution time: 0.0137
INFO - 2023-03-06 03:58:25 --> Config Class Initialized
INFO - 2023-03-06 03:58:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:25 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:25 --> URI Class Initialized
INFO - 2023-03-06 03:58:25 --> Router Class Initialized
INFO - 2023-03-06 03:58:25 --> Output Class Initialized
INFO - 2023-03-06 03:58:25 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:25 --> Input Class Initialized
INFO - 2023-03-06 03:58:25 --> Language Class Initialized
INFO - 2023-03-06 03:58:25 --> Loader Class Initialized
INFO - 2023-03-06 03:58:25 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:25 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:25 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:25 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:25 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:25 --> Total execution time: 0.0431
INFO - 2023-03-06 03:58:25 --> Config Class Initialized
INFO - 2023-03-06 03:58:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:25 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:25 --> URI Class Initialized
INFO - 2023-03-06 03:58:25 --> Router Class Initialized
INFO - 2023-03-06 03:58:25 --> Output Class Initialized
INFO - 2023-03-06 03:58:25 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:25 --> Input Class Initialized
INFO - 2023-03-06 03:58:25 --> Language Class Initialized
INFO - 2023-03-06 03:58:25 --> Loader Class Initialized
INFO - 2023-03-06 03:58:25 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:25 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:25 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:25 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:25 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:25 --> Total execution time: 0.0330
INFO - 2023-03-06 03:58:27 --> Config Class Initialized
INFO - 2023-03-06 03:58:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:27 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:27 --> URI Class Initialized
INFO - 2023-03-06 03:58:27 --> Router Class Initialized
INFO - 2023-03-06 03:58:27 --> Output Class Initialized
INFO - 2023-03-06 03:58:27 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:27 --> Input Class Initialized
INFO - 2023-03-06 03:58:27 --> Language Class Initialized
INFO - 2023-03-06 03:58:27 --> Loader Class Initialized
INFO - 2023-03-06 03:58:27 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:27 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:27 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:27 --> Model "Login_model" initialized
INFO - 2023-03-06 03:58:27 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:27 --> Total execution time: 0.1211
INFO - 2023-03-06 03:58:42 --> Config Class Initialized
INFO - 2023-03-06 03:58:42 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:42 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:42 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:42 --> URI Class Initialized
INFO - 2023-03-06 03:58:42 --> Router Class Initialized
INFO - 2023-03-06 03:58:42 --> Output Class Initialized
INFO - 2023-03-06 03:58:42 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:42 --> Input Class Initialized
INFO - 2023-03-06 03:58:42 --> Language Class Initialized
INFO - 2023-03-06 03:58:42 --> Loader Class Initialized
INFO - 2023-03-06 03:58:42 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:42 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:42 --> Total execution time: 0.0041
INFO - 2023-03-06 03:58:42 --> Config Class Initialized
INFO - 2023-03-06 03:58:42 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:42 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:42 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:42 --> URI Class Initialized
INFO - 2023-03-06 03:58:42 --> Router Class Initialized
INFO - 2023-03-06 03:58:42 --> Output Class Initialized
INFO - 2023-03-06 03:58:42 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:42 --> Input Class Initialized
INFO - 2023-03-06 03:58:42 --> Language Class Initialized
INFO - 2023-03-06 03:58:42 --> Loader Class Initialized
INFO - 2023-03-06 03:58:42 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:42 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:42 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:42 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:42 --> Total execution time: 0.0131
INFO - 2023-03-06 03:58:42 --> Config Class Initialized
INFO - 2023-03-06 03:58:42 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:42 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:42 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:42 --> URI Class Initialized
INFO - 2023-03-06 03:58:42 --> Router Class Initialized
INFO - 2023-03-06 03:58:42 --> Output Class Initialized
INFO - 2023-03-06 03:58:42 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:42 --> Input Class Initialized
INFO - 2023-03-06 03:58:42 --> Language Class Initialized
INFO - 2023-03-06 03:58:42 --> Loader Class Initialized
INFO - 2023-03-06 03:58:42 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:42 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:42 --> Total execution time: 0.0457
INFO - 2023-03-06 03:58:42 --> Config Class Initialized
INFO - 2023-03-06 03:58:42 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:58:42 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:58:42 --> Utf8 Class Initialized
INFO - 2023-03-06 03:58:42 --> URI Class Initialized
INFO - 2023-03-06 03:58:42 --> Router Class Initialized
INFO - 2023-03-06 03:58:42 --> Output Class Initialized
INFO - 2023-03-06 03:58:42 --> Security Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:58:42 --> Input Class Initialized
INFO - 2023-03-06 03:58:42 --> Language Class Initialized
INFO - 2023-03-06 03:58:42 --> Loader Class Initialized
INFO - 2023-03-06 03:58:42 --> Controller Class Initialized
DEBUG - 2023-03-06 03:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:58:42 --> Database Driver Class Initialized
INFO - 2023-03-06 03:58:42 --> Model "Cluster_model" initialized
INFO - 2023-03-06 03:58:42 --> Final output sent to browser
DEBUG - 2023-03-06 03:58:42 --> Total execution time: 0.0148
INFO - 2023-03-06 03:59:46 --> Config Class Initialized
INFO - 2023-03-06 03:59:46 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:59:46 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:59:46 --> Utf8 Class Initialized
INFO - 2023-03-06 03:59:46 --> URI Class Initialized
INFO - 2023-03-06 03:59:46 --> Router Class Initialized
INFO - 2023-03-06 03:59:46 --> Output Class Initialized
INFO - 2023-03-06 03:59:46 --> Security Class Initialized
DEBUG - 2023-03-06 03:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:59:46 --> Input Class Initialized
INFO - 2023-03-06 03:59:46 --> Language Class Initialized
INFO - 2023-03-06 03:59:46 --> Loader Class Initialized
INFO - 2023-03-06 03:59:46 --> Controller Class Initialized
DEBUG - 2023-03-06 03:59:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:59:46 --> Database Driver Class Initialized
INFO - 2023-03-06 03:59:46 --> Final output sent to browser
DEBUG - 2023-03-06 03:59:46 --> Total execution time: 0.0138
INFO - 2023-03-06 03:59:46 --> Config Class Initialized
INFO - 2023-03-06 03:59:46 --> Hooks Class Initialized
DEBUG - 2023-03-06 03:59:46 --> UTF-8 Support Enabled
INFO - 2023-03-06 03:59:46 --> Utf8 Class Initialized
INFO - 2023-03-06 03:59:46 --> URI Class Initialized
INFO - 2023-03-06 03:59:46 --> Router Class Initialized
INFO - 2023-03-06 03:59:46 --> Output Class Initialized
INFO - 2023-03-06 03:59:46 --> Security Class Initialized
DEBUG - 2023-03-06 03:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 03:59:46 --> Input Class Initialized
INFO - 2023-03-06 03:59:46 --> Language Class Initialized
INFO - 2023-03-06 03:59:46 --> Loader Class Initialized
INFO - 2023-03-06 03:59:46 --> Controller Class Initialized
DEBUG - 2023-03-06 03:59:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 03:59:46 --> Database Driver Class Initialized
INFO - 2023-03-06 03:59:46 --> Final output sent to browser
DEBUG - 2023-03-06 03:59:46 --> Total execution time: 0.3537
INFO - 2023-03-06 04:00:31 --> Config Class Initialized
INFO - 2023-03-06 04:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:00:31 --> Utf8 Class Initialized
INFO - 2023-03-06 04:00:31 --> URI Class Initialized
INFO - 2023-03-06 04:00:31 --> Router Class Initialized
INFO - 2023-03-06 04:00:31 --> Output Class Initialized
INFO - 2023-03-06 04:00:31 --> Security Class Initialized
DEBUG - 2023-03-06 04:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:00:31 --> Input Class Initialized
INFO - 2023-03-06 04:00:31 --> Language Class Initialized
INFO - 2023-03-06 04:00:31 --> Loader Class Initialized
INFO - 2023-03-06 04:00:31 --> Controller Class Initialized
DEBUG - 2023-03-06 04:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:00:31 --> Database Driver Class Initialized
INFO - 2023-03-06 04:00:31 --> Final output sent to browser
DEBUG - 2023-03-06 04:00:31 --> Total execution time: 0.0132
INFO - 2023-03-06 04:00:31 --> Config Class Initialized
INFO - 2023-03-06 04:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:00:31 --> Utf8 Class Initialized
INFO - 2023-03-06 04:00:31 --> URI Class Initialized
INFO - 2023-03-06 04:00:31 --> Router Class Initialized
INFO - 2023-03-06 04:00:31 --> Output Class Initialized
INFO - 2023-03-06 04:00:31 --> Security Class Initialized
DEBUG - 2023-03-06 04:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:00:31 --> Input Class Initialized
INFO - 2023-03-06 04:00:31 --> Language Class Initialized
INFO - 2023-03-06 04:00:31 --> Loader Class Initialized
INFO - 2023-03-06 04:00:31 --> Controller Class Initialized
DEBUG - 2023-03-06 04:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:00:31 --> Database Driver Class Initialized
INFO - 2023-03-06 04:00:31 --> Final output sent to browser
DEBUG - 2023-03-06 04:00:31 --> Total execution time: 0.0175
INFO - 2023-03-06 04:00:48 --> Config Class Initialized
INFO - 2023-03-06 04:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:00:48 --> Utf8 Class Initialized
INFO - 2023-03-06 04:00:48 --> URI Class Initialized
INFO - 2023-03-06 04:00:48 --> Router Class Initialized
INFO - 2023-03-06 04:00:48 --> Output Class Initialized
INFO - 2023-03-06 04:00:48 --> Security Class Initialized
DEBUG - 2023-03-06 04:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:00:48 --> Input Class Initialized
INFO - 2023-03-06 04:00:48 --> Language Class Initialized
INFO - 2023-03-06 04:00:48 --> Loader Class Initialized
INFO - 2023-03-06 04:00:48 --> Controller Class Initialized
DEBUG - 2023-03-06 04:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:00:48 --> Database Driver Class Initialized
INFO - 2023-03-06 04:00:48 --> Final output sent to browser
DEBUG - 2023-03-06 04:00:48 --> Total execution time: 0.0101
INFO - 2023-03-06 04:00:48 --> Config Class Initialized
INFO - 2023-03-06 04:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:00:48 --> Utf8 Class Initialized
INFO - 2023-03-06 04:00:48 --> URI Class Initialized
INFO - 2023-03-06 04:00:48 --> Router Class Initialized
INFO - 2023-03-06 04:00:48 --> Output Class Initialized
INFO - 2023-03-06 04:00:48 --> Security Class Initialized
DEBUG - 2023-03-06 04:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:00:48 --> Input Class Initialized
INFO - 2023-03-06 04:00:48 --> Language Class Initialized
INFO - 2023-03-06 04:00:48 --> Loader Class Initialized
INFO - 2023-03-06 04:00:48 --> Controller Class Initialized
DEBUG - 2023-03-06 04:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:00:48 --> Database Driver Class Initialized
INFO - 2023-03-06 04:00:48 --> Final output sent to browser
DEBUG - 2023-03-06 04:00:48 --> Total execution time: 0.0333
INFO - 2023-03-06 04:01:21 --> Config Class Initialized
INFO - 2023-03-06 04:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:01:21 --> Utf8 Class Initialized
INFO - 2023-03-06 04:01:21 --> URI Class Initialized
INFO - 2023-03-06 04:01:21 --> Router Class Initialized
INFO - 2023-03-06 04:01:21 --> Output Class Initialized
INFO - 2023-03-06 04:01:21 --> Security Class Initialized
DEBUG - 2023-03-06 04:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:01:21 --> Input Class Initialized
INFO - 2023-03-06 04:01:21 --> Language Class Initialized
INFO - 2023-03-06 04:01:21 --> Loader Class Initialized
INFO - 2023-03-06 04:01:21 --> Controller Class Initialized
DEBUG - 2023-03-06 04:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:01:21 --> Database Driver Class Initialized
INFO - 2023-03-06 04:01:21 --> Final output sent to browser
DEBUG - 2023-03-06 04:01:21 --> Total execution time: 0.0158
INFO - 2023-03-06 04:01:21 --> Config Class Initialized
INFO - 2023-03-06 04:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:01:21 --> Utf8 Class Initialized
INFO - 2023-03-06 04:01:21 --> URI Class Initialized
INFO - 2023-03-06 04:01:21 --> Router Class Initialized
INFO - 2023-03-06 04:01:21 --> Output Class Initialized
INFO - 2023-03-06 04:01:21 --> Security Class Initialized
DEBUG - 2023-03-06 04:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:01:21 --> Input Class Initialized
INFO - 2023-03-06 04:01:21 --> Language Class Initialized
INFO - 2023-03-06 04:01:21 --> Loader Class Initialized
INFO - 2023-03-06 04:01:21 --> Controller Class Initialized
DEBUG - 2023-03-06 04:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:01:21 --> Database Driver Class Initialized
INFO - 2023-03-06 04:01:21 --> Final output sent to browser
DEBUG - 2023-03-06 04:01:21 --> Total execution time: 0.1739
INFO - 2023-03-06 04:01:55 --> Config Class Initialized
INFO - 2023-03-06 04:01:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:01:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:01:55 --> Utf8 Class Initialized
INFO - 2023-03-06 04:01:55 --> URI Class Initialized
INFO - 2023-03-06 04:01:55 --> Router Class Initialized
INFO - 2023-03-06 04:01:55 --> Output Class Initialized
INFO - 2023-03-06 04:01:55 --> Security Class Initialized
DEBUG - 2023-03-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:01:55 --> Input Class Initialized
INFO - 2023-03-06 04:01:55 --> Language Class Initialized
INFO - 2023-03-06 04:01:55 --> Loader Class Initialized
INFO - 2023-03-06 04:01:55 --> Controller Class Initialized
DEBUG - 2023-03-06 04:01:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:01:55 --> Database Driver Class Initialized
INFO - 2023-03-06 04:01:55 --> Final output sent to browser
DEBUG - 2023-03-06 04:01:55 --> Total execution time: 0.0119
INFO - 2023-03-06 04:01:55 --> Config Class Initialized
INFO - 2023-03-06 04:01:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:01:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:01:55 --> Utf8 Class Initialized
INFO - 2023-03-06 04:01:55 --> URI Class Initialized
INFO - 2023-03-06 04:01:55 --> Router Class Initialized
INFO - 2023-03-06 04:01:55 --> Output Class Initialized
INFO - 2023-03-06 04:01:55 --> Security Class Initialized
DEBUG - 2023-03-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:01:55 --> Input Class Initialized
INFO - 2023-03-06 04:01:55 --> Language Class Initialized
INFO - 2023-03-06 04:01:55 --> Loader Class Initialized
INFO - 2023-03-06 04:01:55 --> Controller Class Initialized
DEBUG - 2023-03-06 04:01:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:01:55 --> Database Driver Class Initialized
INFO - 2023-03-06 04:01:55 --> Final output sent to browser
DEBUG - 2023-03-06 04:01:55 --> Total execution time: 0.1328
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
INFO - 2023-03-06 04:03:14 --> Helper loaded: form_helper
INFO - 2023-03-06 04:03:14 --> Helper loaded: url_helper
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Model "Change_model" initialized
INFO - 2023-03-06 04:03:14 --> Model "Grafana_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0208
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
INFO - 2023-03-06 04:03:14 --> Helper loaded: form_helper
INFO - 2023-03-06 04:03:14 --> Helper loaded: url_helper
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0419
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
INFO - 2023-03-06 04:03:14 --> Helper loaded: form_helper
INFO - 2023-03-06 04:03:14 --> Helper loaded: url_helper
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Login_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0167
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.1001
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0137
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Login_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0398
INFO - 2023-03-06 04:03:14 --> Config Class Initialized
INFO - 2023-03-06 04:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:03:14 --> Utf8 Class Initialized
INFO - 2023-03-06 04:03:14 --> URI Class Initialized
INFO - 2023-03-06 04:03:14 --> Router Class Initialized
INFO - 2023-03-06 04:03:14 --> Output Class Initialized
INFO - 2023-03-06 04:03:14 --> Security Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:03:14 --> Input Class Initialized
INFO - 2023-03-06 04:03:14 --> Language Class Initialized
INFO - 2023-03-06 04:03:14 --> Loader Class Initialized
INFO - 2023-03-06 04:03:14 --> Controller Class Initialized
DEBUG - 2023-03-06 04:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:03:14 --> Database Driver Class Initialized
INFO - 2023-03-06 04:03:14 --> Model "Login_model" initialized
INFO - 2023-03-06 04:03:14 --> Final output sent to browser
DEBUG - 2023-03-06 04:03:14 --> Total execution time: 0.0375
INFO - 2023-03-06 04:24:01 --> Config Class Initialized
INFO - 2023-03-06 04:24:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:24:01 --> Utf8 Class Initialized
INFO - 2023-03-06 04:24:01 --> URI Class Initialized
INFO - 2023-03-06 04:24:01 --> Router Class Initialized
INFO - 2023-03-06 04:24:01 --> Output Class Initialized
INFO - 2023-03-06 04:24:01 --> Security Class Initialized
DEBUG - 2023-03-06 04:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:24:01 --> Input Class Initialized
INFO - 2023-03-06 04:24:01 --> Language Class Initialized
INFO - 2023-03-06 04:24:01 --> Loader Class Initialized
INFO - 2023-03-06 04:24:01 --> Controller Class Initialized
DEBUG - 2023-03-06 04:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:24:01 --> Database Driver Class Initialized
INFO - 2023-03-06 04:24:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:24:01 --> Final output sent to browser
DEBUG - 2023-03-06 04:24:01 --> Total execution time: 0.0233
INFO - 2023-03-06 04:24:01 --> Config Class Initialized
INFO - 2023-03-06 04:24:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:24:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:24:01 --> Utf8 Class Initialized
INFO - 2023-03-06 04:24:01 --> URI Class Initialized
INFO - 2023-03-06 04:24:01 --> Router Class Initialized
INFO - 2023-03-06 04:24:01 --> Output Class Initialized
INFO - 2023-03-06 04:24:01 --> Security Class Initialized
DEBUG - 2023-03-06 04:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:24:01 --> Input Class Initialized
INFO - 2023-03-06 04:24:01 --> Language Class Initialized
INFO - 2023-03-06 04:24:01 --> Loader Class Initialized
INFO - 2023-03-06 04:24:01 --> Controller Class Initialized
DEBUG - 2023-03-06 04:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:24:01 --> Database Driver Class Initialized
INFO - 2023-03-06 04:24:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:24:01 --> Final output sent to browser
DEBUG - 2023-03-06 04:24:01 --> Total execution time: 0.0543
INFO - 2023-03-06 04:26:19 --> Config Class Initialized
INFO - 2023-03-06 04:26:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:19 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:19 --> URI Class Initialized
INFO - 2023-03-06 04:26:19 --> Router Class Initialized
INFO - 2023-03-06 04:26:19 --> Output Class Initialized
INFO - 2023-03-06 04:26:19 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:19 --> Input Class Initialized
INFO - 2023-03-06 04:26:19 --> Language Class Initialized
INFO - 2023-03-06 04:26:19 --> Loader Class Initialized
INFO - 2023-03-06 04:26:19 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:19 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:19 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:19 --> Total execution time: 0.1002
INFO - 2023-03-06 04:26:19 --> Config Class Initialized
INFO - 2023-03-06 04:26:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:19 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:19 --> URI Class Initialized
INFO - 2023-03-06 04:26:19 --> Router Class Initialized
INFO - 2023-03-06 04:26:19 --> Output Class Initialized
INFO - 2023-03-06 04:26:19 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:19 --> Input Class Initialized
INFO - 2023-03-06 04:26:19 --> Language Class Initialized
INFO - 2023-03-06 04:26:19 --> Loader Class Initialized
INFO - 2023-03-06 04:26:19 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:19 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:19 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:19 --> Total execution time: 0.0124
INFO - 2023-03-06 04:26:22 --> Config Class Initialized
INFO - 2023-03-06 04:26:22 --> Hooks Class Initialized
INFO - 2023-03-06 04:26:22 --> Config Class Initialized
INFO - 2023-03-06 04:26:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 04:26:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:22 --> URI Class Initialized
INFO - 2023-03-06 04:26:22 --> URI Class Initialized
INFO - 2023-03-06 04:26:22 --> Router Class Initialized
INFO - 2023-03-06 04:26:22 --> Router Class Initialized
INFO - 2023-03-06 04:26:22 --> Output Class Initialized
INFO - 2023-03-06 04:26:22 --> Output Class Initialized
INFO - 2023-03-06 04:26:22 --> Security Class Initialized
INFO - 2023-03-06 04:26:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 04:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:22 --> Input Class Initialized
INFO - 2023-03-06 04:26:22 --> Input Class Initialized
INFO - 2023-03-06 04:26:22 --> Language Class Initialized
INFO - 2023-03-06 04:26:22 --> Language Class Initialized
INFO - 2023-03-06 04:26:22 --> Loader Class Initialized
INFO - 2023-03-06 04:26:22 --> Loader Class Initialized
INFO - 2023-03-06 04:26:22 --> Controller Class Initialized
INFO - 2023-03-06 04:26:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 04:26:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:22 --> Total execution time: 0.0039
INFO - 2023-03-06 04:26:22 --> Config Class Initialized
INFO - 2023-03-06 04:26:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:22 --> URI Class Initialized
INFO - 2023-03-06 04:26:22 --> Router Class Initialized
INFO - 2023-03-06 04:26:22 --> Output Class Initialized
INFO - 2023-03-06 04:26:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:22 --> Input Class Initialized
INFO - 2023-03-06 04:26:22 --> Language Class Initialized
INFO - 2023-03-06 04:26:22 --> Loader Class Initialized
INFO - 2023-03-06 04:26:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:22 --> Total execution time: 0.0518
INFO - 2023-03-06 04:26:22 --> Config Class Initialized
INFO - 2023-03-06 04:26:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:22 --> URI Class Initialized
INFO - 2023-03-06 04:26:22 --> Router Class Initialized
INFO - 2023-03-06 04:26:22 --> Output Class Initialized
INFO - 2023-03-06 04:26:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:22 --> Input Class Initialized
INFO - 2023-03-06 04:26:22 --> Language Class Initialized
INFO - 2023-03-06 04:26:22 --> Loader Class Initialized
INFO - 2023-03-06 04:26:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:22 --> Model "Login_model" initialized
INFO - 2023-03-06 04:26:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:22 --> Final output sent to browser
INFO - 2023-03-06 04:26:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:22 --> Total execution time: 0.0638
DEBUG - 2023-03-06 04:26:22 --> Total execution time: 0.0166
INFO - 2023-03-06 04:26:24 --> Config Class Initialized
INFO - 2023-03-06 04:26:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:24 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:24 --> URI Class Initialized
INFO - 2023-03-06 04:26:24 --> Router Class Initialized
INFO - 2023-03-06 04:26:24 --> Output Class Initialized
INFO - 2023-03-06 04:26:24 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:24 --> Input Class Initialized
INFO - 2023-03-06 04:26:24 --> Language Class Initialized
INFO - 2023-03-06 04:26:24 --> Loader Class Initialized
INFO - 2023-03-06 04:26:24 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:24 --> Model "Login_model" initialized
INFO - 2023-03-06 04:26:24 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:24 --> Total execution time: 0.0401
INFO - 2023-03-06 04:26:24 --> Config Class Initialized
INFO - 2023-03-06 04:26:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:24 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:24 --> URI Class Initialized
INFO - 2023-03-06 04:26:24 --> Router Class Initialized
INFO - 2023-03-06 04:26:24 --> Output Class Initialized
INFO - 2023-03-06 04:26:24 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:24 --> Input Class Initialized
INFO - 2023-03-06 04:26:24 --> Language Class Initialized
INFO - 2023-03-06 04:26:24 --> Loader Class Initialized
INFO - 2023-03-06 04:26:24 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:25 --> Model "Login_model" initialized
INFO - 2023-03-06 04:26:25 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:25 --> Total execution time: 0.0857
INFO - 2023-03-06 04:26:28 --> Config Class Initialized
INFO - 2023-03-06 04:26:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:28 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:28 --> URI Class Initialized
INFO - 2023-03-06 04:26:28 --> Router Class Initialized
INFO - 2023-03-06 04:26:28 --> Output Class Initialized
INFO - 2023-03-06 04:26:28 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:28 --> Input Class Initialized
INFO - 2023-03-06 04:26:28 --> Language Class Initialized
INFO - 2023-03-06 04:26:28 --> Loader Class Initialized
INFO - 2023-03-06 04:26:28 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:28 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:28 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:28 --> Total execution time: 0.0261
INFO - 2023-03-06 04:26:28 --> Config Class Initialized
INFO - 2023-03-06 04:26:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:28 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:28 --> URI Class Initialized
INFO - 2023-03-06 04:26:28 --> Router Class Initialized
INFO - 2023-03-06 04:26:28 --> Output Class Initialized
INFO - 2023-03-06 04:26:28 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:28 --> Input Class Initialized
INFO - 2023-03-06 04:26:28 --> Language Class Initialized
INFO - 2023-03-06 04:26:28 --> Loader Class Initialized
INFO - 2023-03-06 04:26:28 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:28 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:28 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:28 --> Total execution time: 0.0658
INFO - 2023-03-06 04:26:38 --> Config Class Initialized
INFO - 2023-03-06 04:26:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:38 --> URI Class Initialized
INFO - 2023-03-06 04:26:38 --> Router Class Initialized
INFO - 2023-03-06 04:26:38 --> Output Class Initialized
INFO - 2023-03-06 04:26:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:38 --> Input Class Initialized
INFO - 2023-03-06 04:26:38 --> Language Class Initialized
INFO - 2023-03-06 04:26:38 --> Loader Class Initialized
INFO - 2023-03-06 04:26:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:38 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:38 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:38 --> Total execution time: 0.0564
INFO - 2023-03-06 04:26:38 --> Config Class Initialized
INFO - 2023-03-06 04:26:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:38 --> URI Class Initialized
INFO - 2023-03-06 04:26:38 --> Router Class Initialized
INFO - 2023-03-06 04:26:38 --> Output Class Initialized
INFO - 2023-03-06 04:26:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:38 --> Input Class Initialized
INFO - 2023-03-06 04:26:38 --> Language Class Initialized
INFO - 2023-03-06 04:26:38 --> Loader Class Initialized
INFO - 2023-03-06 04:26:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:38 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:38 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:38 --> Total execution time: 0.0543
INFO - 2023-03-06 04:26:39 --> Config Class Initialized
INFO - 2023-03-06 04:26:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:39 --> URI Class Initialized
INFO - 2023-03-06 04:26:39 --> Router Class Initialized
INFO - 2023-03-06 04:26:39 --> Output Class Initialized
INFO - 2023-03-06 04:26:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:39 --> Input Class Initialized
INFO - 2023-03-06 04:26:39 --> Language Class Initialized
INFO - 2023-03-06 04:26:39 --> Loader Class Initialized
INFO - 2023-03-06 04:26:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:39 --> Total execution time: 0.0129
INFO - 2023-03-06 04:26:39 --> Config Class Initialized
INFO - 2023-03-06 04:26:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:39 --> URI Class Initialized
INFO - 2023-03-06 04:26:39 --> Router Class Initialized
INFO - 2023-03-06 04:26:39 --> Output Class Initialized
INFO - 2023-03-06 04:26:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:39 --> Input Class Initialized
INFO - 2023-03-06 04:26:39 --> Language Class Initialized
INFO - 2023-03-06 04:26:39 --> Loader Class Initialized
INFO - 2023-03-06 04:26:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:39 --> Total execution time: 0.0510
INFO - 2023-03-06 04:26:41 --> Config Class Initialized
INFO - 2023-03-06 04:26:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:41 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:41 --> URI Class Initialized
INFO - 2023-03-06 04:26:41 --> Router Class Initialized
INFO - 2023-03-06 04:26:41 --> Output Class Initialized
INFO - 2023-03-06 04:26:41 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:41 --> Input Class Initialized
INFO - 2023-03-06 04:26:41 --> Language Class Initialized
INFO - 2023-03-06 04:26:41 --> Loader Class Initialized
INFO - 2023-03-06 04:26:41 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:41 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:41 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:41 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:41 --> Total execution time: 0.0163
INFO - 2023-03-06 04:26:41 --> Config Class Initialized
INFO - 2023-03-06 04:26:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:41 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:41 --> URI Class Initialized
INFO - 2023-03-06 04:26:41 --> Router Class Initialized
INFO - 2023-03-06 04:26:41 --> Output Class Initialized
INFO - 2023-03-06 04:26:41 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:41 --> Input Class Initialized
INFO - 2023-03-06 04:26:41 --> Language Class Initialized
INFO - 2023-03-06 04:26:41 --> Loader Class Initialized
INFO - 2023-03-06 04:26:41 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:41 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:41 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:41 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:41 --> Total execution time: 0.0551
INFO - 2023-03-06 04:26:43 --> Config Class Initialized
INFO - 2023-03-06 04:26:43 --> Config Class Initialized
INFO - 2023-03-06 04:26:43 --> Hooks Class Initialized
INFO - 2023-03-06 04:26:43 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 04:26:43 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:43 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:43 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:43 --> URI Class Initialized
INFO - 2023-03-06 04:26:43 --> URI Class Initialized
INFO - 2023-03-06 04:26:43 --> Router Class Initialized
INFO - 2023-03-06 04:26:43 --> Router Class Initialized
INFO - 2023-03-06 04:26:43 --> Output Class Initialized
INFO - 2023-03-06 04:26:43 --> Output Class Initialized
INFO - 2023-03-06 04:26:43 --> Security Class Initialized
INFO - 2023-03-06 04:26:43 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:43 --> Input Class Initialized
INFO - 2023-03-06 04:26:43 --> Input Class Initialized
INFO - 2023-03-06 04:26:43 --> Language Class Initialized
INFO - 2023-03-06 04:26:43 --> Language Class Initialized
INFO - 2023-03-06 04:26:43 --> Loader Class Initialized
INFO - 2023-03-06 04:26:43 --> Loader Class Initialized
INFO - 2023-03-06 04:26:43 --> Controller Class Initialized
INFO - 2023-03-06 04:26:43 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 04:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:43 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:43 --> Total execution time: 0.0064
INFO - 2023-03-06 04:26:43 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:43 --> Config Class Initialized
INFO - 2023-03-06 04:26:43 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:43 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:43 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:43 --> URI Class Initialized
INFO - 2023-03-06 04:26:43 --> Router Class Initialized
INFO - 2023-03-06 04:26:43 --> Output Class Initialized
INFO - 2023-03-06 04:26:43 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:43 --> Input Class Initialized
INFO - 2023-03-06 04:26:43 --> Language Class Initialized
INFO - 2023-03-06 04:26:43 --> Loader Class Initialized
INFO - 2023-03-06 04:26:43 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:43 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:43 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:43 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:43 --> Total execution time: 0.0163
INFO - 2023-03-06 04:26:43 --> Config Class Initialized
INFO - 2023-03-06 04:26:43 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:43 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:43 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:43 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:43 --> URI Class Initialized
INFO - 2023-03-06 04:26:43 --> Router Class Initialized
INFO - 2023-03-06 04:26:43 --> Output Class Initialized
INFO - 2023-03-06 04:26:43 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:43 --> Input Class Initialized
INFO - 2023-03-06 04:26:43 --> Language Class Initialized
INFO - 2023-03-06 04:26:43 --> Final output sent to browser
INFO - 2023-03-06 04:26:43 --> Loader Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Total execution time: 0.0511
INFO - 2023-03-06 04:26:43 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:43 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:43 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:43 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:43 --> Total execution time: 0.0912
INFO - 2023-03-06 04:26:44 --> Config Class Initialized
INFO - 2023-03-06 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:44 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:44 --> URI Class Initialized
INFO - 2023-03-06 04:26:44 --> Router Class Initialized
INFO - 2023-03-06 04:26:44 --> Output Class Initialized
INFO - 2023-03-06 04:26:44 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:44 --> Input Class Initialized
INFO - 2023-03-06 04:26:44 --> Language Class Initialized
INFO - 2023-03-06 04:26:44 --> Loader Class Initialized
INFO - 2023-03-06 04:26:44 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:44 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:44 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:44 --> Total execution time: 0.0615
INFO - 2023-03-06 04:26:44 --> Config Class Initialized
INFO - 2023-03-06 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:44 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:44 --> URI Class Initialized
INFO - 2023-03-06 04:26:44 --> Router Class Initialized
INFO - 2023-03-06 04:26:44 --> Output Class Initialized
INFO - 2023-03-06 04:26:44 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:44 --> Input Class Initialized
INFO - 2023-03-06 04:26:44 --> Language Class Initialized
INFO - 2023-03-06 04:26:44 --> Loader Class Initialized
INFO - 2023-03-06 04:26:44 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:44 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:44 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:44 --> Total execution time: 0.0586
INFO - 2023-03-06 04:26:47 --> Config Class Initialized
INFO - 2023-03-06 04:26:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:47 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:47 --> URI Class Initialized
INFO - 2023-03-06 04:26:47 --> Router Class Initialized
INFO - 2023-03-06 04:26:47 --> Output Class Initialized
INFO - 2023-03-06 04:26:47 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:47 --> Input Class Initialized
INFO - 2023-03-06 04:26:47 --> Language Class Initialized
INFO - 2023-03-06 04:26:47 --> Loader Class Initialized
INFO - 2023-03-06 04:26:47 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:47 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:47 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:47 --> Total execution time: 0.0176
INFO - 2023-03-06 04:26:47 --> Config Class Initialized
INFO - 2023-03-06 04:26:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:47 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:47 --> URI Class Initialized
INFO - 2023-03-06 04:26:47 --> Router Class Initialized
INFO - 2023-03-06 04:26:47 --> Output Class Initialized
INFO - 2023-03-06 04:26:47 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:47 --> Input Class Initialized
INFO - 2023-03-06 04:26:47 --> Language Class Initialized
INFO - 2023-03-06 04:26:47 --> Loader Class Initialized
INFO - 2023-03-06 04:26:47 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:47 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:47 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:47 --> Total execution time: 0.0553
INFO - 2023-03-06 04:26:56 --> Config Class Initialized
INFO - 2023-03-06 04:26:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:56 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:56 --> URI Class Initialized
INFO - 2023-03-06 04:26:56 --> Router Class Initialized
INFO - 2023-03-06 04:26:56 --> Output Class Initialized
INFO - 2023-03-06 04:26:56 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:56 --> Input Class Initialized
INFO - 2023-03-06 04:26:56 --> Language Class Initialized
INFO - 2023-03-06 04:26:56 --> Loader Class Initialized
INFO - 2023-03-06 04:26:56 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:56 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:56 --> Total execution time: 0.0045
INFO - 2023-03-06 04:26:56 --> Config Class Initialized
INFO - 2023-03-06 04:26:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:26:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:26:56 --> Utf8 Class Initialized
INFO - 2023-03-06 04:26:56 --> URI Class Initialized
INFO - 2023-03-06 04:26:56 --> Router Class Initialized
INFO - 2023-03-06 04:26:56 --> Output Class Initialized
INFO - 2023-03-06 04:26:56 --> Security Class Initialized
DEBUG - 2023-03-06 04:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:26:56 --> Input Class Initialized
INFO - 2023-03-06 04:26:56 --> Language Class Initialized
INFO - 2023-03-06 04:26:56 --> Loader Class Initialized
INFO - 2023-03-06 04:26:56 --> Controller Class Initialized
DEBUG - 2023-03-06 04:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:26:56 --> Database Driver Class Initialized
INFO - 2023-03-06 04:26:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:26:56 --> Model "PGsql_model" initialized
INFO - 2023-03-06 04:26:56 --> Model "Grafana_model" initialized
INFO - 2023-03-06 04:26:56 --> Final output sent to browser
DEBUG - 2023-03-06 04:26:56 --> Total execution time: 0.0241
INFO - 2023-03-06 04:32:09 --> Config Class Initialized
INFO - 2023-03-06 04:32:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:09 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:09 --> URI Class Initialized
INFO - 2023-03-06 04:32:09 --> Router Class Initialized
INFO - 2023-03-06 04:32:09 --> Output Class Initialized
INFO - 2023-03-06 04:32:09 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:09 --> Input Class Initialized
INFO - 2023-03-06 04:32:09 --> Language Class Initialized
INFO - 2023-03-06 04:32:09 --> Loader Class Initialized
INFO - 2023-03-06 04:32:09 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:09 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:09 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:09 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:09 --> Total execution time: 0.1484
INFO - 2023-03-06 04:32:09 --> Config Class Initialized
INFO - 2023-03-06 04:32:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:09 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:09 --> URI Class Initialized
INFO - 2023-03-06 04:32:09 --> Router Class Initialized
INFO - 2023-03-06 04:32:09 --> Output Class Initialized
INFO - 2023-03-06 04:32:09 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:09 --> Input Class Initialized
INFO - 2023-03-06 04:32:09 --> Language Class Initialized
INFO - 2023-03-06 04:32:09 --> Loader Class Initialized
INFO - 2023-03-06 04:32:09 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:09 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:09 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:09 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:09 --> Total execution time: 0.0252
INFO - 2023-03-06 04:32:21 --> Config Class Initialized
INFO - 2023-03-06 04:32:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:21 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:21 --> URI Class Initialized
INFO - 2023-03-06 04:32:21 --> Router Class Initialized
INFO - 2023-03-06 04:32:21 --> Output Class Initialized
INFO - 2023-03-06 04:32:21 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:21 --> Input Class Initialized
INFO - 2023-03-06 04:32:21 --> Language Class Initialized
INFO - 2023-03-06 04:32:21 --> Loader Class Initialized
INFO - 2023-03-06 04:32:21 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:21 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:21 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:21 --> Total execution time: 0.0217
INFO - 2023-03-06 04:32:21 --> Config Class Initialized
INFO - 2023-03-06 04:32:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:21 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:21 --> URI Class Initialized
INFO - 2023-03-06 04:32:21 --> Router Class Initialized
INFO - 2023-03-06 04:32:21 --> Output Class Initialized
INFO - 2023-03-06 04:32:21 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:21 --> Input Class Initialized
INFO - 2023-03-06 04:32:21 --> Language Class Initialized
INFO - 2023-03-06 04:32:21 --> Loader Class Initialized
INFO - 2023-03-06 04:32:21 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:21 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:21 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:21 --> Total execution time: 0.0173
INFO - 2023-03-06 04:32:22 --> Config Class Initialized
INFO - 2023-03-06 04:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:22 --> URI Class Initialized
INFO - 2023-03-06 04:32:22 --> Router Class Initialized
INFO - 2023-03-06 04:32:22 --> Output Class Initialized
INFO - 2023-03-06 04:32:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:22 --> Input Class Initialized
INFO - 2023-03-06 04:32:22 --> Language Class Initialized
INFO - 2023-03-06 04:32:22 --> Loader Class Initialized
INFO - 2023-03-06 04:32:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:22 --> Total execution time: 0.0239
INFO - 2023-03-06 04:32:22 --> Config Class Initialized
INFO - 2023-03-06 04:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:22 --> URI Class Initialized
INFO - 2023-03-06 04:32:22 --> Router Class Initialized
INFO - 2023-03-06 04:32:22 --> Output Class Initialized
INFO - 2023-03-06 04:32:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:22 --> Input Class Initialized
INFO - 2023-03-06 04:32:22 --> Language Class Initialized
INFO - 2023-03-06 04:32:22 --> Loader Class Initialized
INFO - 2023-03-06 04:32:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:22 --> Total execution time: 0.0105
INFO - 2023-03-06 04:32:23 --> Config Class Initialized
INFO - 2023-03-06 04:32:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:23 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:23 --> URI Class Initialized
INFO - 2023-03-06 04:32:23 --> Router Class Initialized
INFO - 2023-03-06 04:32:23 --> Output Class Initialized
INFO - 2023-03-06 04:32:23 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:23 --> Input Class Initialized
INFO - 2023-03-06 04:32:23 --> Language Class Initialized
INFO - 2023-03-06 04:32:23 --> Loader Class Initialized
INFO - 2023-03-06 04:32:23 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:23 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:23 --> Total execution time: 0.0043
INFO - 2023-03-06 04:32:23 --> Config Class Initialized
INFO - 2023-03-06 04:32:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:23 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:23 --> URI Class Initialized
INFO - 2023-03-06 04:32:23 --> Router Class Initialized
INFO - 2023-03-06 04:32:23 --> Output Class Initialized
INFO - 2023-03-06 04:32:23 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:23 --> Input Class Initialized
INFO - 2023-03-06 04:32:23 --> Language Class Initialized
INFO - 2023-03-06 04:32:23 --> Loader Class Initialized
INFO - 2023-03-06 04:32:23 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:23 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:23 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:23 --> Total execution time: 0.0138
INFO - 2023-03-06 04:32:27 --> Config Class Initialized
INFO - 2023-03-06 04:32:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:27 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:27 --> URI Class Initialized
INFO - 2023-03-06 04:32:27 --> Router Class Initialized
INFO - 2023-03-06 04:32:27 --> Output Class Initialized
INFO - 2023-03-06 04:32:27 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:27 --> Input Class Initialized
INFO - 2023-03-06 04:32:27 --> Language Class Initialized
INFO - 2023-03-06 04:32:27 --> Loader Class Initialized
INFO - 2023-03-06 04:32:27 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:27 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:27 --> Total execution time: 0.0049
INFO - 2023-03-06 04:32:27 --> Config Class Initialized
INFO - 2023-03-06 04:32:27 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:27 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:27 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:27 --> URI Class Initialized
INFO - 2023-03-06 04:32:27 --> Router Class Initialized
INFO - 2023-03-06 04:32:27 --> Output Class Initialized
INFO - 2023-03-06 04:32:27 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:27 --> Input Class Initialized
INFO - 2023-03-06 04:32:27 --> Language Class Initialized
INFO - 2023-03-06 04:32:27 --> Loader Class Initialized
INFO - 2023-03-06 04:32:27 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:27 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:27 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:27 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:27 --> Total execution time: 0.0535
INFO - 2023-03-06 04:32:29 --> Config Class Initialized
INFO - 2023-03-06 04:32:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:29 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:29 --> URI Class Initialized
INFO - 2023-03-06 04:32:29 --> Router Class Initialized
INFO - 2023-03-06 04:32:29 --> Output Class Initialized
INFO - 2023-03-06 04:32:29 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:29 --> Input Class Initialized
INFO - 2023-03-06 04:32:29 --> Language Class Initialized
INFO - 2023-03-06 04:32:29 --> Loader Class Initialized
INFO - 2023-03-06 04:32:29 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:29 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:29 --> Total execution time: 0.0043
INFO - 2023-03-06 04:32:29 --> Config Class Initialized
INFO - 2023-03-06 04:32:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:29 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:29 --> URI Class Initialized
INFO - 2023-03-06 04:32:29 --> Router Class Initialized
INFO - 2023-03-06 04:32:29 --> Output Class Initialized
INFO - 2023-03-06 04:32:29 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:29 --> Input Class Initialized
INFO - 2023-03-06 04:32:29 --> Language Class Initialized
INFO - 2023-03-06 04:32:29 --> Loader Class Initialized
INFO - 2023-03-06 04:32:29 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:29 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:29 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:29 --> Total execution time: 0.0121
INFO - 2023-03-06 04:32:32 --> Config Class Initialized
INFO - 2023-03-06 04:32:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:32 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:32 --> URI Class Initialized
INFO - 2023-03-06 04:32:32 --> Router Class Initialized
INFO - 2023-03-06 04:32:32 --> Output Class Initialized
INFO - 2023-03-06 04:32:32 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:32 --> Input Class Initialized
INFO - 2023-03-06 04:32:32 --> Language Class Initialized
INFO - 2023-03-06 04:32:32 --> Loader Class Initialized
INFO - 2023-03-06 04:32:32 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:32 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:32 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:32 --> Total execution time: 0.0346
INFO - 2023-03-06 04:32:32 --> Config Class Initialized
INFO - 2023-03-06 04:32:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:32 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:32 --> URI Class Initialized
INFO - 2023-03-06 04:32:32 --> Router Class Initialized
INFO - 2023-03-06 04:32:32 --> Output Class Initialized
INFO - 2023-03-06 04:32:32 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:32 --> Input Class Initialized
INFO - 2023-03-06 04:32:32 --> Language Class Initialized
INFO - 2023-03-06 04:32:32 --> Loader Class Initialized
INFO - 2023-03-06 04:32:32 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:32 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:32 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:32 --> Total execution time: 0.0127
INFO - 2023-03-06 04:32:34 --> Config Class Initialized
INFO - 2023-03-06 04:32:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:34 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:34 --> URI Class Initialized
INFO - 2023-03-06 04:32:34 --> Router Class Initialized
INFO - 2023-03-06 04:32:34 --> Output Class Initialized
INFO - 2023-03-06 04:32:34 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:34 --> Input Class Initialized
INFO - 2023-03-06 04:32:34 --> Language Class Initialized
INFO - 2023-03-06 04:32:34 --> Loader Class Initialized
INFO - 2023-03-06 04:32:34 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:34 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:34 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:34 --> Total execution time: 0.0283
INFO - 2023-03-06 04:32:34 --> Config Class Initialized
INFO - 2023-03-06 04:32:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:34 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:34 --> URI Class Initialized
INFO - 2023-03-06 04:32:34 --> Router Class Initialized
INFO - 2023-03-06 04:32:34 --> Output Class Initialized
INFO - 2023-03-06 04:32:34 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:34 --> Input Class Initialized
INFO - 2023-03-06 04:32:34 --> Language Class Initialized
INFO - 2023-03-06 04:32:34 --> Loader Class Initialized
INFO - 2023-03-06 04:32:34 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:34 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:34 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:34 --> Total execution time: 0.0226
INFO - 2023-03-06 04:32:38 --> Config Class Initialized
INFO - 2023-03-06 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:38 --> URI Class Initialized
INFO - 2023-03-06 04:32:38 --> Router Class Initialized
INFO - 2023-03-06 04:32:38 --> Output Class Initialized
INFO - 2023-03-06 04:32:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:38 --> Input Class Initialized
INFO - 2023-03-06 04:32:38 --> Language Class Initialized
INFO - 2023-03-06 04:32:38 --> Loader Class Initialized
INFO - 2023-03-06 04:32:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:38 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:38 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:38 --> Total execution time: 0.0159
INFO - 2023-03-06 04:32:38 --> Config Class Initialized
INFO - 2023-03-06 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:38 --> URI Class Initialized
INFO - 2023-03-06 04:32:38 --> Router Class Initialized
INFO - 2023-03-06 04:32:38 --> Output Class Initialized
INFO - 2023-03-06 04:32:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:38 --> Input Class Initialized
INFO - 2023-03-06 04:32:38 --> Language Class Initialized
INFO - 2023-03-06 04:32:38 --> Loader Class Initialized
INFO - 2023-03-06 04:32:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:38 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:38 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:38 --> Total execution time: 0.0531
INFO - 2023-03-06 04:32:38 --> Config Class Initialized
INFO - 2023-03-06 04:32:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:38 --> URI Class Initialized
INFO - 2023-03-06 04:32:38 --> Router Class Initialized
INFO - 2023-03-06 04:32:38 --> Output Class Initialized
INFO - 2023-03-06 04:32:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:38 --> Input Class Initialized
INFO - 2023-03-06 04:32:38 --> Language Class Initialized
INFO - 2023-03-06 04:32:39 --> Loader Class Initialized
INFO - 2023-03-06 04:32:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:39 --> Total execution time: 0.0183
INFO - 2023-03-06 04:32:39 --> Config Class Initialized
INFO - 2023-03-06 04:32:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:39 --> URI Class Initialized
INFO - 2023-03-06 04:32:39 --> Router Class Initialized
INFO - 2023-03-06 04:32:39 --> Output Class Initialized
INFO - 2023-03-06 04:32:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:39 --> Input Class Initialized
INFO - 2023-03-06 04:32:39 --> Language Class Initialized
INFO - 2023-03-06 04:32:39 --> Loader Class Initialized
INFO - 2023-03-06 04:32:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:39 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:39 --> Total execution time: 0.0277
INFO - 2023-03-06 04:32:39 --> Config Class Initialized
INFO - 2023-03-06 04:32:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:39 --> URI Class Initialized
INFO - 2023-03-06 04:32:39 --> Router Class Initialized
INFO - 2023-03-06 04:32:39 --> Output Class Initialized
INFO - 2023-03-06 04:32:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:39 --> Input Class Initialized
INFO - 2023-03-06 04:32:39 --> Language Class Initialized
INFO - 2023-03-06 04:32:39 --> Loader Class Initialized
INFO - 2023-03-06 04:32:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:39 --> Total execution time: 0.0428
INFO - 2023-03-06 04:32:39 --> Config Class Initialized
INFO - 2023-03-06 04:32:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:39 --> URI Class Initialized
INFO - 2023-03-06 04:32:39 --> Router Class Initialized
INFO - 2023-03-06 04:32:39 --> Output Class Initialized
INFO - 2023-03-06 04:32:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:39 --> Input Class Initialized
INFO - 2023-03-06 04:32:39 --> Language Class Initialized
INFO - 2023-03-06 04:32:39 --> Loader Class Initialized
INFO - 2023-03-06 04:32:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:39 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:39 --> Total execution time: 0.0235
INFO - 2023-03-06 04:32:40 --> Config Class Initialized
INFO - 2023-03-06 04:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:40 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:40 --> URI Class Initialized
INFO - 2023-03-06 04:32:40 --> Router Class Initialized
INFO - 2023-03-06 04:32:40 --> Output Class Initialized
INFO - 2023-03-06 04:32:40 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:40 --> Input Class Initialized
INFO - 2023-03-06 04:32:40 --> Language Class Initialized
INFO - 2023-03-06 04:32:40 --> Loader Class Initialized
INFO - 2023-03-06 04:32:40 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:40 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:40 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:40 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:40 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:40 --> Total execution time: 0.1009
INFO - 2023-03-06 04:32:40 --> Config Class Initialized
INFO - 2023-03-06 04:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:40 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:40 --> URI Class Initialized
INFO - 2023-03-06 04:32:40 --> Router Class Initialized
INFO - 2023-03-06 04:32:40 --> Output Class Initialized
INFO - 2023-03-06 04:32:40 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:40 --> Input Class Initialized
INFO - 2023-03-06 04:32:40 --> Language Class Initialized
INFO - 2023-03-06 04:32:40 --> Loader Class Initialized
INFO - 2023-03-06 04:32:40 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:40 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:40 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:40 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:40 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:40 --> Total execution time: 0.0375
INFO - 2023-03-06 04:32:45 --> Config Class Initialized
INFO - 2023-03-06 04:32:45 --> Config Class Initialized
INFO - 2023-03-06 04:32:45 --> Hooks Class Initialized
INFO - 2023-03-06 04:32:45 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:45 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 04:32:45 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:45 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:45 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:45 --> URI Class Initialized
INFO - 2023-03-06 04:32:45 --> URI Class Initialized
INFO - 2023-03-06 04:32:45 --> Router Class Initialized
INFO - 2023-03-06 04:32:45 --> Router Class Initialized
INFO - 2023-03-06 04:32:45 --> Output Class Initialized
INFO - 2023-03-06 04:32:45 --> Output Class Initialized
INFO - 2023-03-06 04:32:45 --> Security Class Initialized
INFO - 2023-03-06 04:32:45 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:45 --> Input Class Initialized
INFO - 2023-03-06 04:32:45 --> Input Class Initialized
INFO - 2023-03-06 04:32:45 --> Language Class Initialized
INFO - 2023-03-06 04:32:45 --> Language Class Initialized
INFO - 2023-03-06 04:32:45 --> Loader Class Initialized
INFO - 2023-03-06 04:32:45 --> Loader Class Initialized
INFO - 2023-03-06 04:32:45 --> Controller Class Initialized
INFO - 2023-03-06 04:32:45 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 04:32:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:45 --> Final output sent to browser
INFO - 2023-03-06 04:32:45 --> Database Driver Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Total execution time: 0.0044
INFO - 2023-03-06 04:32:45 --> Config Class Initialized
INFO - 2023-03-06 04:32:45 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:45 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:45 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:45 --> URI Class Initialized
INFO - 2023-03-06 04:32:45 --> Router Class Initialized
INFO - 2023-03-06 04:32:45 --> Output Class Initialized
INFO - 2023-03-06 04:32:45 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:45 --> Input Class Initialized
INFO - 2023-03-06 04:32:45 --> Language Class Initialized
INFO - 2023-03-06 04:32:45 --> Loader Class Initialized
INFO - 2023-03-06 04:32:45 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:45 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:45 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:45 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:45 --> Total execution time: 0.0151
INFO - 2023-03-06 04:32:45 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:45 --> Config Class Initialized
INFO - 2023-03-06 04:32:45 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:45 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:45 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:45 --> URI Class Initialized
INFO - 2023-03-06 04:32:45 --> Router Class Initialized
INFO - 2023-03-06 04:32:45 --> Output Class Initialized
INFO - 2023-03-06 04:32:45 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:45 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:45 --> Input Class Initialized
INFO - 2023-03-06 04:32:45 --> Language Class Initialized
INFO - 2023-03-06 04:32:45 --> Loader Class Initialized
INFO - 2023-03-06 04:32:45 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:45 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:45 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:45 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:45 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:45 --> Total execution time: 0.0277
INFO - 2023-03-06 04:32:45 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:45 --> Total execution time: 0.0189
INFO - 2023-03-06 04:32:47 --> Config Class Initialized
INFO - 2023-03-06 04:32:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:47 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:47 --> URI Class Initialized
INFO - 2023-03-06 04:32:47 --> Router Class Initialized
INFO - 2023-03-06 04:32:47 --> Output Class Initialized
INFO - 2023-03-06 04:32:47 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:47 --> Input Class Initialized
INFO - 2023-03-06 04:32:47 --> Language Class Initialized
INFO - 2023-03-06 04:32:47 --> Loader Class Initialized
INFO - 2023-03-06 04:32:47 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:47 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:47 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:47 --> Total execution time: 0.0261
INFO - 2023-03-06 04:32:47 --> Config Class Initialized
INFO - 2023-03-06 04:32:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:48 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:48 --> URI Class Initialized
INFO - 2023-03-06 04:32:48 --> Router Class Initialized
INFO - 2023-03-06 04:32:48 --> Output Class Initialized
INFO - 2023-03-06 04:32:48 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:48 --> Input Class Initialized
INFO - 2023-03-06 04:32:48 --> Language Class Initialized
INFO - 2023-03-06 04:32:48 --> Loader Class Initialized
INFO - 2023-03-06 04:32:48 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:48 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:48 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:48 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:48 --> Total execution time: 0.0682
INFO - 2023-03-06 04:32:51 --> Config Class Initialized
INFO - 2023-03-06 04:32:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:51 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:51 --> URI Class Initialized
INFO - 2023-03-06 04:32:51 --> Router Class Initialized
INFO - 2023-03-06 04:32:51 --> Output Class Initialized
INFO - 2023-03-06 04:32:51 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:51 --> Input Class Initialized
INFO - 2023-03-06 04:32:51 --> Language Class Initialized
INFO - 2023-03-06 04:32:51 --> Loader Class Initialized
INFO - 2023-03-06 04:32:51 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:51 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:51 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:51 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:51 --> Total execution time: 0.0177
INFO - 2023-03-06 04:32:51 --> Config Class Initialized
INFO - 2023-03-06 04:32:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:51 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:51 --> URI Class Initialized
INFO - 2023-03-06 04:32:51 --> Router Class Initialized
INFO - 2023-03-06 04:32:51 --> Output Class Initialized
INFO - 2023-03-06 04:32:51 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:51 --> Input Class Initialized
INFO - 2023-03-06 04:32:51 --> Language Class Initialized
INFO - 2023-03-06 04:32:51 --> Loader Class Initialized
INFO - 2023-03-06 04:32:51 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:51 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:51 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:51 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:51 --> Total execution time: 0.0129
INFO - 2023-03-06 04:32:54 --> Config Class Initialized
INFO - 2023-03-06 04:32:54 --> Config Class Initialized
INFO - 2023-03-06 04:32:54 --> Hooks Class Initialized
INFO - 2023-03-06 04:32:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:54 --> Utf8 Class Initialized
DEBUG - 2023-03-06 04:32:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:54 --> URI Class Initialized
INFO - 2023-03-06 04:32:54 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:54 --> Router Class Initialized
INFO - 2023-03-06 04:32:54 --> URI Class Initialized
INFO - 2023-03-06 04:32:54 --> Output Class Initialized
INFO - 2023-03-06 04:32:54 --> Router Class Initialized
INFO - 2023-03-06 04:32:54 --> Security Class Initialized
INFO - 2023-03-06 04:32:54 --> Output Class Initialized
DEBUG - 2023-03-06 04:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:54 --> Security Class Initialized
INFO - 2023-03-06 04:32:54 --> Input Class Initialized
DEBUG - 2023-03-06 04:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:54 --> Language Class Initialized
INFO - 2023-03-06 04:32:54 --> Input Class Initialized
INFO - 2023-03-06 04:32:54 --> Language Class Initialized
INFO - 2023-03-06 04:32:54 --> Loader Class Initialized
INFO - 2023-03-06 04:32:54 --> Loader Class Initialized
INFO - 2023-03-06 04:32:54 --> Controller Class Initialized
INFO - 2023-03-06 04:32:54 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 04:32:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:54 --> Final output sent to browser
INFO - 2023-03-06 04:32:54 --> Database Driver Class Initialized
DEBUG - 2023-03-06 04:32:54 --> Total execution time: 0.0044
INFO - 2023-03-06 04:32:55 --> Config Class Initialized
INFO - 2023-03-06 04:32:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:55 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:55 --> URI Class Initialized
INFO - 2023-03-06 04:32:55 --> Router Class Initialized
INFO - 2023-03-06 04:32:55 --> Output Class Initialized
INFO - 2023-03-06 04:32:55 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:55 --> Input Class Initialized
INFO - 2023-03-06 04:32:55 --> Language Class Initialized
INFO - 2023-03-06 04:32:55 --> Loader Class Initialized
INFO - 2023-03-06 04:32:55 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:55 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:55 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:55 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:55 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:55 --> Total execution time: 0.0210
INFO - 2023-03-06 04:32:55 --> Config Class Initialized
INFO - 2023-03-06 04:32:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:55 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:55 --> URI Class Initialized
INFO - 2023-03-06 04:32:55 --> Router Class Initialized
INFO - 2023-03-06 04:32:55 --> Output Class Initialized
INFO - 2023-03-06 04:32:55 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:55 --> Input Class Initialized
INFO - 2023-03-06 04:32:55 --> Language Class Initialized
INFO - 2023-03-06 04:32:55 --> Loader Class Initialized
INFO - 2023-03-06 04:32:55 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:55 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:55 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:55 --> Total execution time: 0.0205
INFO - 2023-03-06 04:32:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:55 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:55 --> Total execution time: 0.0519
INFO - 2023-03-06 04:32:56 --> Config Class Initialized
INFO - 2023-03-06 04:32:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:56 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:56 --> URI Class Initialized
INFO - 2023-03-06 04:32:56 --> Router Class Initialized
INFO - 2023-03-06 04:32:56 --> Output Class Initialized
INFO - 2023-03-06 04:32:56 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:56 --> Input Class Initialized
INFO - 2023-03-06 04:32:56 --> Language Class Initialized
INFO - 2023-03-06 04:32:56 --> Loader Class Initialized
INFO - 2023-03-06 04:32:56 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:56 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:56 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:56 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:56 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:56 --> Total execution time: 0.0411
INFO - 2023-03-06 04:32:56 --> Config Class Initialized
INFO - 2023-03-06 04:32:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:32:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:32:56 --> Utf8 Class Initialized
INFO - 2023-03-06 04:32:56 --> URI Class Initialized
INFO - 2023-03-06 04:32:56 --> Router Class Initialized
INFO - 2023-03-06 04:32:56 --> Output Class Initialized
INFO - 2023-03-06 04:32:56 --> Security Class Initialized
DEBUG - 2023-03-06 04:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:32:56 --> Input Class Initialized
INFO - 2023-03-06 04:32:56 --> Language Class Initialized
INFO - 2023-03-06 04:32:56 --> Loader Class Initialized
INFO - 2023-03-06 04:32:56 --> Controller Class Initialized
DEBUG - 2023-03-06 04:32:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:32:56 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:32:56 --> Database Driver Class Initialized
INFO - 2023-03-06 04:32:56 --> Model "Login_model" initialized
INFO - 2023-03-06 04:32:56 --> Final output sent to browser
DEBUG - 2023-03-06 04:32:56 --> Total execution time: 0.0375
INFO - 2023-03-06 04:33:05 --> Config Class Initialized
INFO - 2023-03-06 04:33:05 --> Config Class Initialized
INFO - 2023-03-06 04:33:05 --> Hooks Class Initialized
INFO - 2023-03-06 04:33:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 04:33:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:05 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:05 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:05 --> URI Class Initialized
INFO - 2023-03-06 04:33:05 --> URI Class Initialized
INFO - 2023-03-06 04:33:05 --> Router Class Initialized
INFO - 2023-03-06 04:33:05 --> Output Class Initialized
INFO - 2023-03-06 04:33:05 --> Router Class Initialized
INFO - 2023-03-06 04:33:05 --> Security Class Initialized
INFO - 2023-03-06 04:33:05 --> Output Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:05 --> Security Class Initialized
INFO - 2023-03-06 04:33:05 --> Input Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:05 --> Language Class Initialized
INFO - 2023-03-06 04:33:05 --> Input Class Initialized
INFO - 2023-03-06 04:33:05 --> Language Class Initialized
INFO - 2023-03-06 04:33:05 --> Loader Class Initialized
INFO - 2023-03-06 04:33:05 --> Controller Class Initialized
INFO - 2023-03-06 04:33:05 --> Loader Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:05 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:05 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:05 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:05 --> Total execution time: 0.0049
INFO - 2023-03-06 04:33:05 --> Config Class Initialized
INFO - 2023-03-06 04:33:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:05 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:05 --> URI Class Initialized
INFO - 2023-03-06 04:33:05 --> Router Class Initialized
INFO - 2023-03-06 04:33:05 --> Output Class Initialized
INFO - 2023-03-06 04:33:05 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:05 --> Input Class Initialized
INFO - 2023-03-06 04:33:05 --> Language Class Initialized
INFO - 2023-03-06 04:33:05 --> Loader Class Initialized
INFO - 2023-03-06 04:33:05 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:05 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:05 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:05 --> Model "Login_model" initialized
INFO - 2023-03-06 04:33:05 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:05 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:05 --> Total execution time: 0.0361
INFO - 2023-03-06 04:33:05 --> Config Class Initialized
INFO - 2023-03-06 04:33:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:05 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:05 --> URI Class Initialized
INFO - 2023-03-06 04:33:05 --> Router Class Initialized
INFO - 2023-03-06 04:33:05 --> Output Class Initialized
INFO - 2023-03-06 04:33:05 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:05 --> Input Class Initialized
INFO - 2023-03-06 04:33:05 --> Language Class Initialized
INFO - 2023-03-06 04:33:05 --> Loader Class Initialized
INFO - 2023-03-06 04:33:05 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:05 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:05 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:05 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:05 --> Total execution time: 0.0597
INFO - 2023-03-06 04:33:05 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:05 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:05 --> Total execution time: 0.0779
INFO - 2023-03-06 04:33:07 --> Config Class Initialized
INFO - 2023-03-06 04:33:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:07 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:07 --> URI Class Initialized
INFO - 2023-03-06 04:33:07 --> Router Class Initialized
INFO - 2023-03-06 04:33:07 --> Output Class Initialized
INFO - 2023-03-06 04:33:07 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:07 --> Input Class Initialized
INFO - 2023-03-06 04:33:07 --> Language Class Initialized
INFO - 2023-03-06 04:33:07 --> Loader Class Initialized
INFO - 2023-03-06 04:33:07 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:07 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:07 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:07 --> Total execution time: 0.0300
INFO - 2023-03-06 04:33:07 --> Config Class Initialized
INFO - 2023-03-06 04:33:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:07 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:07 --> URI Class Initialized
INFO - 2023-03-06 04:33:07 --> Router Class Initialized
INFO - 2023-03-06 04:33:07 --> Output Class Initialized
INFO - 2023-03-06 04:33:07 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:07 --> Input Class Initialized
INFO - 2023-03-06 04:33:07 --> Language Class Initialized
INFO - 2023-03-06 04:33:07 --> Loader Class Initialized
INFO - 2023-03-06 04:33:07 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:07 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:07 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:07 --> Total execution time: 0.0251
INFO - 2023-03-06 04:33:10 --> Config Class Initialized
INFO - 2023-03-06 04:33:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:10 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:10 --> URI Class Initialized
INFO - 2023-03-06 04:33:10 --> Router Class Initialized
INFO - 2023-03-06 04:33:10 --> Output Class Initialized
INFO - 2023-03-06 04:33:10 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:10 --> Input Class Initialized
INFO - 2023-03-06 04:33:10 --> Language Class Initialized
INFO - 2023-03-06 04:33:10 --> Loader Class Initialized
INFO - 2023-03-06 04:33:10 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:10 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:10 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:10 --> Total execution time: 0.0946
INFO - 2023-03-06 04:33:10 --> Config Class Initialized
INFO - 2023-03-06 04:33:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:10 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:10 --> URI Class Initialized
INFO - 2023-03-06 04:33:10 --> Router Class Initialized
INFO - 2023-03-06 04:33:10 --> Output Class Initialized
INFO - 2023-03-06 04:33:10 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:10 --> Input Class Initialized
INFO - 2023-03-06 04:33:10 --> Language Class Initialized
INFO - 2023-03-06 04:33:10 --> Loader Class Initialized
INFO - 2023-03-06 04:33:10 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:10 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:10 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:10 --> Total execution time: 0.0129
INFO - 2023-03-06 04:33:15 --> Config Class Initialized
INFO - 2023-03-06 04:33:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:15 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:15 --> URI Class Initialized
INFO - 2023-03-06 04:33:15 --> Router Class Initialized
INFO - 2023-03-06 04:33:15 --> Output Class Initialized
INFO - 2023-03-06 04:33:15 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:15 --> Input Class Initialized
INFO - 2023-03-06 04:33:15 --> Language Class Initialized
INFO - 2023-03-06 04:33:15 --> Loader Class Initialized
INFO - 2023-03-06 04:33:15 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:15 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:15 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:15 --> Model "Login_model" initialized
INFO - 2023-03-06 04:33:15 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:15 --> Total execution time: 0.0444
INFO - 2023-03-06 04:33:15 --> Config Class Initialized
INFO - 2023-03-06 04:33:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:15 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:15 --> URI Class Initialized
INFO - 2023-03-06 04:33:15 --> Router Class Initialized
INFO - 2023-03-06 04:33:15 --> Output Class Initialized
INFO - 2023-03-06 04:33:15 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:15 --> Input Class Initialized
INFO - 2023-03-06 04:33:15 --> Language Class Initialized
INFO - 2023-03-06 04:33:15 --> Loader Class Initialized
INFO - 2023-03-06 04:33:15 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:15 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:15 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:15 --> Model "Login_model" initialized
INFO - 2023-03-06 04:33:15 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:15 --> Total execution time: 0.0375
INFO - 2023-03-06 04:33:22 --> Config Class Initialized
INFO - 2023-03-06 04:33:22 --> Config Class Initialized
INFO - 2023-03-06 04:33:22 --> Hooks Class Initialized
INFO - 2023-03-06 04:33:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:22 --> Utf8 Class Initialized
DEBUG - 2023-03-06 04:33:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:22 --> URI Class Initialized
INFO - 2023-03-06 04:33:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:22 --> Router Class Initialized
INFO - 2023-03-06 04:33:22 --> URI Class Initialized
INFO - 2023-03-06 04:33:22 --> Output Class Initialized
INFO - 2023-03-06 04:33:22 --> Router Class Initialized
INFO - 2023-03-06 04:33:22 --> Security Class Initialized
INFO - 2023-03-06 04:33:22 --> Output Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:22 --> Security Class Initialized
INFO - 2023-03-06 04:33:22 --> Input Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:22 --> Language Class Initialized
INFO - 2023-03-06 04:33:22 --> Input Class Initialized
INFO - 2023-03-06 04:33:22 --> Loader Class Initialized
INFO - 2023-03-06 04:33:22 --> Language Class Initialized
INFO - 2023-03-06 04:33:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:22 --> Loader Class Initialized
INFO - 2023-03-06 04:33:22 --> Final output sent to browser
INFO - 2023-03-06 04:33:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Total execution time: 0.0051
DEBUG - 2023-03-06 04:33:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:22 --> Config Class Initialized
INFO - 2023-03-06 04:33:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:22 --> URI Class Initialized
INFO - 2023-03-06 04:33:22 --> Router Class Initialized
INFO - 2023-03-06 04:33:22 --> Output Class Initialized
INFO - 2023-03-06 04:33:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:22 --> Input Class Initialized
INFO - 2023-03-06 04:33:22 --> Language Class Initialized
INFO - 2023-03-06 04:33:22 --> Loader Class Initialized
INFO - 2023-03-06 04:33:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:22 --> Model "Login_model" initialized
INFO - 2023-03-06 04:33:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:22 --> Total execution time: 0.0208
INFO - 2023-03-06 04:33:22 --> Config Class Initialized
INFO - 2023-03-06 04:33:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:22 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:22 --> URI Class Initialized
INFO - 2023-03-06 04:33:22 --> Router Class Initialized
INFO - 2023-03-06 04:33:22 --> Output Class Initialized
INFO - 2023-03-06 04:33:22 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:22 --> Input Class Initialized
INFO - 2023-03-06 04:33:22 --> Language Class Initialized
INFO - 2023-03-06 04:33:22 --> Loader Class Initialized
INFO - 2023-03-06 04:33:22 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:22 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:22 --> Total execution time: 0.0215
INFO - 2023-03-06 04:33:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:22 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:22 --> Total execution time: 0.0519
INFO - 2023-03-06 04:33:24 --> Config Class Initialized
INFO - 2023-03-06 04:33:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:24 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:24 --> URI Class Initialized
INFO - 2023-03-06 04:33:24 --> Router Class Initialized
INFO - 2023-03-06 04:33:24 --> Output Class Initialized
INFO - 2023-03-06 04:33:24 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:24 --> Input Class Initialized
INFO - 2023-03-06 04:33:24 --> Language Class Initialized
INFO - 2023-03-06 04:33:24 --> Loader Class Initialized
INFO - 2023-03-06 04:33:24 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:24 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:24 --> Total execution time: 0.0263
INFO - 2023-03-06 04:33:24 --> Config Class Initialized
INFO - 2023-03-06 04:33:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:24 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:24 --> URI Class Initialized
INFO - 2023-03-06 04:33:24 --> Router Class Initialized
INFO - 2023-03-06 04:33:24 --> Output Class Initialized
INFO - 2023-03-06 04:33:24 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:24 --> Input Class Initialized
INFO - 2023-03-06 04:33:24 --> Language Class Initialized
INFO - 2023-03-06 04:33:24 --> Loader Class Initialized
INFO - 2023-03-06 04:33:24 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:24 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:24 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:24 --> Total execution time: 0.0215
INFO - 2023-03-06 04:33:36 --> Config Class Initialized
INFO - 2023-03-06 04:33:36 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:36 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:36 --> URI Class Initialized
INFO - 2023-03-06 04:33:36 --> Router Class Initialized
INFO - 2023-03-06 04:33:36 --> Output Class Initialized
INFO - 2023-03-06 04:33:36 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:36 --> Input Class Initialized
INFO - 2023-03-06 04:33:36 --> Language Class Initialized
INFO - 2023-03-06 04:33:36 --> Loader Class Initialized
INFO - 2023-03-06 04:33:36 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:36 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:36 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:36 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:36 --> Total execution time: 0.0144
INFO - 2023-03-06 04:33:36 --> Config Class Initialized
INFO - 2023-03-06 04:33:36 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:36 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:36 --> URI Class Initialized
INFO - 2023-03-06 04:33:36 --> Router Class Initialized
INFO - 2023-03-06 04:33:36 --> Output Class Initialized
INFO - 2023-03-06 04:33:36 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:36 --> Input Class Initialized
INFO - 2023-03-06 04:33:36 --> Language Class Initialized
INFO - 2023-03-06 04:33:36 --> Loader Class Initialized
INFO - 2023-03-06 04:33:36 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:36 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:36 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:36 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:36 --> Total execution time: 0.0575
INFO - 2023-03-06 04:33:38 --> Config Class Initialized
INFO - 2023-03-06 04:33:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:38 --> URI Class Initialized
INFO - 2023-03-06 04:33:38 --> Router Class Initialized
INFO - 2023-03-06 04:33:38 --> Output Class Initialized
INFO - 2023-03-06 04:33:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:38 --> Input Class Initialized
INFO - 2023-03-06 04:33:38 --> Language Class Initialized
INFO - 2023-03-06 04:33:38 --> Loader Class Initialized
INFO - 2023-03-06 04:33:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:38 --> Total execution time: 0.0044
INFO - 2023-03-06 04:33:38 --> Config Class Initialized
INFO - 2023-03-06 04:33:38 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:38 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:38 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:38 --> URI Class Initialized
INFO - 2023-03-06 04:33:38 --> Router Class Initialized
INFO - 2023-03-06 04:33:38 --> Output Class Initialized
INFO - 2023-03-06 04:33:38 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:38 --> Input Class Initialized
INFO - 2023-03-06 04:33:38 --> Language Class Initialized
INFO - 2023-03-06 04:33:38 --> Loader Class Initialized
INFO - 2023-03-06 04:33:38 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:38 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:38 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:38 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:38 --> Total execution time: 0.0524
INFO - 2023-03-06 04:33:39 --> Config Class Initialized
INFO - 2023-03-06 04:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:39 --> URI Class Initialized
INFO - 2023-03-06 04:33:39 --> Router Class Initialized
INFO - 2023-03-06 04:33:39 --> Output Class Initialized
INFO - 2023-03-06 04:33:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:39 --> Input Class Initialized
INFO - 2023-03-06 04:33:39 --> Language Class Initialized
INFO - 2023-03-06 04:33:39 --> Loader Class Initialized
INFO - 2023-03-06 04:33:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:39 --> Total execution time: 0.0320
INFO - 2023-03-06 04:33:39 --> Config Class Initialized
INFO - 2023-03-06 04:33:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 04:33:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 04:33:39 --> Utf8 Class Initialized
INFO - 2023-03-06 04:33:39 --> URI Class Initialized
INFO - 2023-03-06 04:33:39 --> Router Class Initialized
INFO - 2023-03-06 04:33:39 --> Output Class Initialized
INFO - 2023-03-06 04:33:39 --> Security Class Initialized
DEBUG - 2023-03-06 04:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 04:33:39 --> Input Class Initialized
INFO - 2023-03-06 04:33:39 --> Language Class Initialized
INFO - 2023-03-06 04:33:39 --> Loader Class Initialized
INFO - 2023-03-06 04:33:39 --> Controller Class Initialized
DEBUG - 2023-03-06 04:33:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 04:33:39 --> Database Driver Class Initialized
INFO - 2023-03-06 04:33:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 04:33:39 --> Final output sent to browser
DEBUG - 2023-03-06 04:33:39 --> Total execution time: 0.0529
INFO - 2023-03-06 05:33:28 --> Config Class Initialized
INFO - 2023-03-06 05:33:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:33:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:33:29 --> Utf8 Class Initialized
INFO - 2023-03-06 05:33:29 --> URI Class Initialized
INFO - 2023-03-06 05:33:29 --> Router Class Initialized
INFO - 2023-03-06 05:33:29 --> Output Class Initialized
INFO - 2023-03-06 05:33:29 --> Security Class Initialized
DEBUG - 2023-03-06 05:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:33:29 --> Input Class Initialized
INFO - 2023-03-06 05:33:29 --> Language Class Initialized
INFO - 2023-03-06 05:33:29 --> Loader Class Initialized
INFO - 2023-03-06 05:33:29 --> Controller Class Initialized
DEBUG - 2023-03-06 05:33:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:33:29 --> Database Driver Class Initialized
INFO - 2023-03-06 05:33:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:33:29 --> Final output sent to browser
DEBUG - 2023-03-06 05:33:29 --> Total execution time: 0.1052
INFO - 2023-03-06 05:33:29 --> Config Class Initialized
INFO - 2023-03-06 05:33:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:33:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:33:29 --> Utf8 Class Initialized
INFO - 2023-03-06 05:33:29 --> URI Class Initialized
INFO - 2023-03-06 05:33:29 --> Router Class Initialized
INFO - 2023-03-06 05:33:29 --> Output Class Initialized
INFO - 2023-03-06 05:33:29 --> Security Class Initialized
DEBUG - 2023-03-06 05:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:33:29 --> Input Class Initialized
INFO - 2023-03-06 05:33:29 --> Language Class Initialized
INFO - 2023-03-06 05:33:29 --> Loader Class Initialized
INFO - 2023-03-06 05:33:29 --> Controller Class Initialized
DEBUG - 2023-03-06 05:33:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:33:29 --> Database Driver Class Initialized
INFO - 2023-03-06 05:33:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:33:29 --> Final output sent to browser
DEBUG - 2023-03-06 05:33:29 --> Total execution time: 0.0565
INFO - 2023-03-06 05:34:13 --> Config Class Initialized
INFO - 2023-03-06 05:34:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:34:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:34:13 --> Utf8 Class Initialized
INFO - 2023-03-06 05:34:13 --> URI Class Initialized
INFO - 2023-03-06 05:34:13 --> Router Class Initialized
INFO - 2023-03-06 05:34:13 --> Output Class Initialized
INFO - 2023-03-06 05:34:13 --> Security Class Initialized
DEBUG - 2023-03-06 05:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:34:13 --> Input Class Initialized
INFO - 2023-03-06 05:34:13 --> Language Class Initialized
INFO - 2023-03-06 05:34:13 --> Loader Class Initialized
INFO - 2023-03-06 05:34:13 --> Controller Class Initialized
DEBUG - 2023-03-06 05:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:34:13 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:34:13 --> Final output sent to browser
DEBUG - 2023-03-06 05:34:13 --> Total execution time: 0.0634
INFO - 2023-03-06 05:34:13 --> Config Class Initialized
INFO - 2023-03-06 05:34:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:34:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:34:13 --> Utf8 Class Initialized
INFO - 2023-03-06 05:34:13 --> URI Class Initialized
INFO - 2023-03-06 05:34:13 --> Router Class Initialized
INFO - 2023-03-06 05:34:13 --> Output Class Initialized
INFO - 2023-03-06 05:34:13 --> Security Class Initialized
DEBUG - 2023-03-06 05:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:34:13 --> Input Class Initialized
INFO - 2023-03-06 05:34:13 --> Language Class Initialized
INFO - 2023-03-06 05:34:13 --> Loader Class Initialized
INFO - 2023-03-06 05:34:13 --> Controller Class Initialized
DEBUG - 2023-03-06 05:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:34:13 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:34:13 --> Final output sent to browser
DEBUG - 2023-03-06 05:34:13 --> Total execution time: 0.0578
INFO - 2023-03-06 05:34:16 --> Config Class Initialized
INFO - 2023-03-06 05:34:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:34:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:34:16 --> Utf8 Class Initialized
INFO - 2023-03-06 05:34:16 --> URI Class Initialized
INFO - 2023-03-06 05:34:16 --> Router Class Initialized
INFO - 2023-03-06 05:34:16 --> Output Class Initialized
INFO - 2023-03-06 05:34:16 --> Security Class Initialized
DEBUG - 2023-03-06 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:34:16 --> Input Class Initialized
INFO - 2023-03-06 05:34:16 --> Language Class Initialized
INFO - 2023-03-06 05:34:16 --> Loader Class Initialized
INFO - 2023-03-06 05:34:16 --> Controller Class Initialized
DEBUG - 2023-03-06 05:34:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:34:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:34:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:17 --> Model "Login_model" initialized
INFO - 2023-03-06 05:34:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:34:17 --> Total execution time: 0.0498
INFO - 2023-03-06 05:34:17 --> Config Class Initialized
INFO - 2023-03-06 05:34:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:34:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:34:17 --> Utf8 Class Initialized
INFO - 2023-03-06 05:34:17 --> URI Class Initialized
INFO - 2023-03-06 05:34:17 --> Router Class Initialized
INFO - 2023-03-06 05:34:17 --> Output Class Initialized
INFO - 2023-03-06 05:34:17 --> Security Class Initialized
DEBUG - 2023-03-06 05:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:34:17 --> Input Class Initialized
INFO - 2023-03-06 05:34:17 --> Language Class Initialized
INFO - 2023-03-06 05:34:17 --> Loader Class Initialized
INFO - 2023-03-06 05:34:17 --> Controller Class Initialized
DEBUG - 2023-03-06 05:34:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:34:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:34:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:34:17 --> Model "Login_model" initialized
INFO - 2023-03-06 05:34:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:34:17 --> Total execution time: 0.0828
INFO - 2023-03-06 05:35:10 --> Config Class Initialized
INFO - 2023-03-06 05:35:10 --> Hooks Class Initialized
INFO - 2023-03-06 05:35:10 --> Config Class Initialized
INFO - 2023-03-06 05:35:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 05:35:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:10 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:10 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:10 --> URI Class Initialized
INFO - 2023-03-06 05:35:10 --> URI Class Initialized
INFO - 2023-03-06 05:35:10 --> Router Class Initialized
INFO - 2023-03-06 05:35:10 --> Router Class Initialized
INFO - 2023-03-06 05:35:10 --> Output Class Initialized
INFO - 2023-03-06 05:35:10 --> Output Class Initialized
INFO - 2023-03-06 05:35:10 --> Security Class Initialized
INFO - 2023-03-06 05:35:10 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 05:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:10 --> Input Class Initialized
INFO - 2023-03-06 05:35:10 --> Input Class Initialized
INFO - 2023-03-06 05:35:10 --> Language Class Initialized
INFO - 2023-03-06 05:35:10 --> Language Class Initialized
INFO - 2023-03-06 05:35:10 --> Loader Class Initialized
INFO - 2023-03-06 05:35:10 --> Loader Class Initialized
INFO - 2023-03-06 05:35:10 --> Controller Class Initialized
INFO - 2023-03-06 05:35:10 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:10 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:10 --> Total execution time: 0.0042
INFO - 2023-03-06 05:35:10 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:10 --> Config Class Initialized
INFO - 2023-03-06 05:35:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:10 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:10 --> URI Class Initialized
INFO - 2023-03-06 05:35:10 --> Router Class Initialized
INFO - 2023-03-06 05:35:10 --> Output Class Initialized
INFO - 2023-03-06 05:35:10 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:10 --> Input Class Initialized
INFO - 2023-03-06 05:35:10 --> Language Class Initialized
INFO - 2023-03-06 05:35:10 --> Loader Class Initialized
INFO - 2023-03-06 05:35:10 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:10 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:10 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:10 --> Total execution time: 0.0505
INFO - 2023-03-06 05:35:10 --> Config Class Initialized
INFO - 2023-03-06 05:35:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:10 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:10 --> URI Class Initialized
INFO - 2023-03-06 05:35:10 --> Router Class Initialized
INFO - 2023-03-06 05:35:10 --> Output Class Initialized
INFO - 2023-03-06 05:35:10 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:10 --> Input Class Initialized
INFO - 2023-03-06 05:35:10 --> Language Class Initialized
INFO - 2023-03-06 05:35:10 --> Loader Class Initialized
INFO - 2023-03-06 05:35:10 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:10 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:10 --> Model "Login_model" initialized
INFO - 2023-03-06 05:35:10 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:10 --> Final output sent to browser
INFO - 2023-03-06 05:35:10 --> Model "Cluster_model" initialized
DEBUG - 2023-03-06 05:35:10 --> Total execution time: 0.0160
INFO - 2023-03-06 05:35:10 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:10 --> Total execution time: 0.0659
INFO - 2023-03-06 05:35:11 --> Config Class Initialized
INFO - 2023-03-06 05:35:11 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:11 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:11 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:11 --> URI Class Initialized
INFO - 2023-03-06 05:35:11 --> Router Class Initialized
INFO - 2023-03-06 05:35:11 --> Output Class Initialized
INFO - 2023-03-06 05:35:11 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:11 --> Input Class Initialized
INFO - 2023-03-06 05:35:11 --> Language Class Initialized
INFO - 2023-03-06 05:35:11 --> Loader Class Initialized
INFO - 2023-03-06 05:35:11 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:11 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:11 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:11 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:11 --> Model "Login_model" initialized
INFO - 2023-03-06 05:35:11 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:11 --> Total execution time: 0.0399
INFO - 2023-03-06 05:35:11 --> Config Class Initialized
INFO - 2023-03-06 05:35:11 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:11 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:11 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:11 --> URI Class Initialized
INFO - 2023-03-06 05:35:11 --> Router Class Initialized
INFO - 2023-03-06 05:35:11 --> Output Class Initialized
INFO - 2023-03-06 05:35:11 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:11 --> Input Class Initialized
INFO - 2023-03-06 05:35:11 --> Language Class Initialized
INFO - 2023-03-06 05:35:11 --> Loader Class Initialized
INFO - 2023-03-06 05:35:11 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:11 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:11 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:11 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:11 --> Model "Login_model" initialized
INFO - 2023-03-06 05:35:11 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:11 --> Total execution time: 0.0375
INFO - 2023-03-06 05:35:15 --> Config Class Initialized
INFO - 2023-03-06 05:35:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:15 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:15 --> URI Class Initialized
INFO - 2023-03-06 05:35:15 --> Router Class Initialized
INFO - 2023-03-06 05:35:15 --> Output Class Initialized
INFO - 2023-03-06 05:35:15 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:15 --> Input Class Initialized
INFO - 2023-03-06 05:35:15 --> Language Class Initialized
INFO - 2023-03-06 05:35:15 --> Loader Class Initialized
INFO - 2023-03-06 05:35:15 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:15 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:15 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:15 --> Total execution time: 0.0221
INFO - 2023-03-06 05:35:15 --> Config Class Initialized
INFO - 2023-03-06 05:35:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:15 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:15 --> URI Class Initialized
INFO - 2023-03-06 05:35:15 --> Router Class Initialized
INFO - 2023-03-06 05:35:15 --> Output Class Initialized
INFO - 2023-03-06 05:35:15 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:15 --> Input Class Initialized
INFO - 2023-03-06 05:35:15 --> Language Class Initialized
INFO - 2023-03-06 05:35:15 --> Loader Class Initialized
INFO - 2023-03-06 05:35:15 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:15 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:15 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:15 --> Total execution time: 0.0584
INFO - 2023-03-06 05:35:17 --> Config Class Initialized
INFO - 2023-03-06 05:35:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:17 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:17 --> URI Class Initialized
INFO - 2023-03-06 05:35:17 --> Router Class Initialized
INFO - 2023-03-06 05:35:17 --> Output Class Initialized
INFO - 2023-03-06 05:35:17 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:17 --> Input Class Initialized
INFO - 2023-03-06 05:35:17 --> Language Class Initialized
INFO - 2023-03-06 05:35:17 --> Loader Class Initialized
INFO - 2023-03-06 05:35:17 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:17 --> Model "Login_model" initialized
INFO - 2023-03-06 05:35:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:17 --> Total execution time: 0.0501
INFO - 2023-03-06 05:35:17 --> Config Class Initialized
INFO - 2023-03-06 05:35:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:35:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:35:17 --> Utf8 Class Initialized
INFO - 2023-03-06 05:35:17 --> URI Class Initialized
INFO - 2023-03-06 05:35:17 --> Router Class Initialized
INFO - 2023-03-06 05:35:17 --> Output Class Initialized
INFO - 2023-03-06 05:35:17 --> Security Class Initialized
DEBUG - 2023-03-06 05:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:35:17 --> Input Class Initialized
INFO - 2023-03-06 05:35:17 --> Language Class Initialized
INFO - 2023-03-06 05:35:17 --> Loader Class Initialized
INFO - 2023-03-06 05:35:17 --> Controller Class Initialized
DEBUG - 2023-03-06 05:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:35:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:35:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:35:17 --> Model "Login_model" initialized
INFO - 2023-03-06 05:35:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:35:17 --> Total execution time: 0.0400
INFO - 2023-03-06 05:40:17 --> Config Class Initialized
INFO - 2023-03-06 05:40:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:17 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:17 --> URI Class Initialized
INFO - 2023-03-06 05:40:17 --> Router Class Initialized
INFO - 2023-03-06 05:40:17 --> Output Class Initialized
INFO - 2023-03-06 05:40:17 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:17 --> Input Class Initialized
INFO - 2023-03-06 05:40:17 --> Language Class Initialized
INFO - 2023-03-06 05:40:17 --> Loader Class Initialized
INFO - 2023-03-06 05:40:17 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:17 --> Total execution time: 0.0487
INFO - 2023-03-06 05:40:17 --> Config Class Initialized
INFO - 2023-03-06 05:40:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:17 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:17 --> URI Class Initialized
INFO - 2023-03-06 05:40:17 --> Router Class Initialized
INFO - 2023-03-06 05:40:17 --> Output Class Initialized
INFO - 2023-03-06 05:40:17 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:17 --> Input Class Initialized
INFO - 2023-03-06 05:40:17 --> Language Class Initialized
INFO - 2023-03-06 05:40:17 --> Loader Class Initialized
INFO - 2023-03-06 05:40:17 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:17 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:17 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:17 --> Total execution time: 0.0933
INFO - 2023-03-06 05:40:19 --> Config Class Initialized
INFO - 2023-03-06 05:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:19 --> Config Class Initialized
INFO - 2023-03-06 05:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:19 --> Hooks Class Initialized
INFO - 2023-03-06 05:40:19 --> URI Class Initialized
DEBUG - 2023-03-06 05:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:19 --> Router Class Initialized
INFO - 2023-03-06 05:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:19 --> Output Class Initialized
INFO - 2023-03-06 05:40:19 --> URI Class Initialized
INFO - 2023-03-06 05:40:19 --> Security Class Initialized
INFO - 2023-03-06 05:40:19 --> Router Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:19 --> Output Class Initialized
INFO - 2023-03-06 05:40:19 --> Input Class Initialized
INFO - 2023-03-06 05:40:19 --> Security Class Initialized
INFO - 2023-03-06 05:40:19 --> Language Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:19 --> Loader Class Initialized
INFO - 2023-03-06 05:40:19 --> Input Class Initialized
INFO - 2023-03-06 05:40:19 --> Controller Class Initialized
INFO - 2023-03-06 05:40:19 --> Language Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:19 --> Loader Class Initialized
INFO - 2023-03-06 05:40:19 --> Controller Class Initialized
INFO - 2023-03-06 05:40:19 --> Database Driver Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:19 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:19 --> Total execution time: 0.0034
INFO - 2023-03-06 05:40:19 --> Config Class Initialized
INFO - 2023-03-06 05:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:19 --> URI Class Initialized
INFO - 2023-03-06 05:40:19 --> Router Class Initialized
INFO - 2023-03-06 05:40:19 --> Output Class Initialized
INFO - 2023-03-06 05:40:19 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:19 --> Input Class Initialized
INFO - 2023-03-06 05:40:19 --> Language Class Initialized
INFO - 2023-03-06 05:40:19 --> Loader Class Initialized
INFO - 2023-03-06 05:40:19 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:19 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:19 --> Model "Login_model" initialized
INFO - 2023-03-06 05:40:19 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:19 --> Total execution time: 0.0432
INFO - 2023-03-06 05:40:19 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:19 --> Config Class Initialized
INFO - 2023-03-06 05:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:19 --> URI Class Initialized
INFO - 2023-03-06 05:40:19 --> Router Class Initialized
INFO - 2023-03-06 05:40:19 --> Output Class Initialized
INFO - 2023-03-06 05:40:19 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:19 --> Input Class Initialized
INFO - 2023-03-06 05:40:19 --> Language Class Initialized
INFO - 2023-03-06 05:40:19 --> Loader Class Initialized
INFO - 2023-03-06 05:40:19 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:19 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:19 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:19 --> Total execution time: 0.0531
INFO - 2023-03-06 05:40:19 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:19 --> Total execution time: 0.1031
INFO - 2023-03-06 05:40:22 --> Config Class Initialized
INFO - 2023-03-06 05:40:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:22 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:22 --> URI Class Initialized
INFO - 2023-03-06 05:40:22 --> Router Class Initialized
INFO - 2023-03-06 05:40:22 --> Output Class Initialized
INFO - 2023-03-06 05:40:22 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:22 --> Input Class Initialized
INFO - 2023-03-06 05:40:22 --> Language Class Initialized
INFO - 2023-03-06 05:40:22 --> Loader Class Initialized
INFO - 2023-03-06 05:40:22 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:22 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:22 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:22 --> Model "Login_model" initialized
INFO - 2023-03-06 05:40:22 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:22 --> Total execution time: 0.0855
INFO - 2023-03-06 05:40:22 --> Config Class Initialized
INFO - 2023-03-06 05:40:22 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:22 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:22 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:22 --> URI Class Initialized
INFO - 2023-03-06 05:40:22 --> Router Class Initialized
INFO - 2023-03-06 05:40:22 --> Output Class Initialized
INFO - 2023-03-06 05:40:22 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:22 --> Input Class Initialized
INFO - 2023-03-06 05:40:22 --> Language Class Initialized
INFO - 2023-03-06 05:40:22 --> Loader Class Initialized
INFO - 2023-03-06 05:40:22 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:22 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:22 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:22 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:22 --> Model "Login_model" initialized
INFO - 2023-03-06 05:40:22 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:22 --> Total execution time: 0.0927
INFO - 2023-03-06 05:40:24 --> Config Class Initialized
INFO - 2023-03-06 05:40:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:24 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:24 --> URI Class Initialized
INFO - 2023-03-06 05:40:24 --> Router Class Initialized
INFO - 2023-03-06 05:40:24 --> Output Class Initialized
INFO - 2023-03-06 05:40:24 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:24 --> Input Class Initialized
INFO - 2023-03-06 05:40:24 --> Language Class Initialized
INFO - 2023-03-06 05:40:24 --> Loader Class Initialized
INFO - 2023-03-06 05:40:24 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:24 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:24 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:24 --> Total execution time: 0.0752
INFO - 2023-03-06 05:40:24 --> Config Class Initialized
INFO - 2023-03-06 05:40:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:40:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:40:24 --> Utf8 Class Initialized
INFO - 2023-03-06 05:40:24 --> URI Class Initialized
INFO - 2023-03-06 05:40:24 --> Router Class Initialized
INFO - 2023-03-06 05:40:24 --> Output Class Initialized
INFO - 2023-03-06 05:40:24 --> Security Class Initialized
DEBUG - 2023-03-06 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:40:24 --> Input Class Initialized
INFO - 2023-03-06 05:40:24 --> Language Class Initialized
INFO - 2023-03-06 05:40:24 --> Loader Class Initialized
INFO - 2023-03-06 05:40:24 --> Controller Class Initialized
DEBUG - 2023-03-06 05:40:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:40:24 --> Database Driver Class Initialized
INFO - 2023-03-06 05:40:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:40:24 --> Final output sent to browser
DEBUG - 2023-03-06 05:40:24 --> Total execution time: 0.0801
INFO - 2023-03-06 05:44:16 --> Config Class Initialized
INFO - 2023-03-06 05:44:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:16 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:16 --> URI Class Initialized
INFO - 2023-03-06 05:44:16 --> Router Class Initialized
INFO - 2023-03-06 05:44:16 --> Output Class Initialized
INFO - 2023-03-06 05:44:16 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:16 --> Input Class Initialized
INFO - 2023-03-06 05:44:16 --> Language Class Initialized
INFO - 2023-03-06 05:44:16 --> Loader Class Initialized
INFO - 2023-03-06 05:44:16 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:16 --> Model "Login_model" initialized
INFO - 2023-03-06 05:44:16 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:16 --> Total execution time: 0.0664
INFO - 2023-03-06 05:44:16 --> Config Class Initialized
INFO - 2023-03-06 05:44:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:16 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:16 --> URI Class Initialized
INFO - 2023-03-06 05:44:16 --> Router Class Initialized
INFO - 2023-03-06 05:44:16 --> Output Class Initialized
INFO - 2023-03-06 05:44:16 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:16 --> Input Class Initialized
INFO - 2023-03-06 05:44:16 --> Language Class Initialized
INFO - 2023-03-06 05:44:16 --> Loader Class Initialized
INFO - 2023-03-06 05:44:16 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:16 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:16 --> Model "Login_model" initialized
INFO - 2023-03-06 05:44:16 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:16 --> Total execution time: 0.0615
INFO - 2023-03-06 05:44:36 --> Config Class Initialized
INFO - 2023-03-06 05:44:36 --> Hooks Class Initialized
INFO - 2023-03-06 05:44:36 --> Config Class Initialized
DEBUG - 2023-03-06 05:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:36 --> Hooks Class Initialized
INFO - 2023-03-06 05:44:36 --> Utf8 Class Initialized
DEBUG - 2023-03-06 05:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:36 --> URI Class Initialized
INFO - 2023-03-06 05:44:36 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:36 --> Router Class Initialized
INFO - 2023-03-06 05:44:36 --> URI Class Initialized
INFO - 2023-03-06 05:44:36 --> Output Class Initialized
INFO - 2023-03-06 05:44:36 --> Router Class Initialized
INFO - 2023-03-06 05:44:36 --> Security Class Initialized
INFO - 2023-03-06 05:44:36 --> Output Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:36 --> Security Class Initialized
INFO - 2023-03-06 05:44:36 --> Input Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:36 --> Language Class Initialized
INFO - 2023-03-06 05:44:36 --> Input Class Initialized
INFO - 2023-03-06 05:44:36 --> Language Class Initialized
INFO - 2023-03-06 05:44:36 --> Loader Class Initialized
INFO - 2023-03-06 05:44:36 --> Loader Class Initialized
INFO - 2023-03-06 05:44:36 --> Controller Class Initialized
INFO - 2023-03-06 05:44:36 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:36 --> Final output sent to browser
INFO - 2023-03-06 05:44:36 --> Database Driver Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Total execution time: 0.0045
INFO - 2023-03-06 05:44:36 --> Config Class Initialized
INFO - 2023-03-06 05:44:36 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:36 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:36 --> URI Class Initialized
INFO - 2023-03-06 05:44:36 --> Router Class Initialized
INFO - 2023-03-06 05:44:36 --> Output Class Initialized
INFO - 2023-03-06 05:44:36 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:36 --> Input Class Initialized
INFO - 2023-03-06 05:44:36 --> Language Class Initialized
INFO - 2023-03-06 05:44:36 --> Loader Class Initialized
INFO - 2023-03-06 05:44:36 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:36 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:36 --> Model "Login_model" initialized
INFO - 2023-03-06 05:44:36 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:36 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:36 --> Total execution time: 0.0231
INFO - 2023-03-06 05:44:36 --> Config Class Initialized
INFO - 2023-03-06 05:44:36 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:36 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:36 --> URI Class Initialized
INFO - 2023-03-06 05:44:36 --> Router Class Initialized
INFO - 2023-03-06 05:44:36 --> Output Class Initialized
INFO - 2023-03-06 05:44:36 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:36 --> Input Class Initialized
INFO - 2023-03-06 05:44:36 --> Language Class Initialized
INFO - 2023-03-06 05:44:36 --> Loader Class Initialized
INFO - 2023-03-06 05:44:36 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:36 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:36 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:36 --> Total execution time: 0.0268
INFO - 2023-03-06 05:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:36 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:36 --> Total execution time: 0.0552
INFO - 2023-03-06 05:44:39 --> Config Class Initialized
INFO - 2023-03-06 05:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:39 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:39 --> URI Class Initialized
INFO - 2023-03-06 05:44:39 --> Router Class Initialized
INFO - 2023-03-06 05:44:39 --> Output Class Initialized
INFO - 2023-03-06 05:44:39 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:39 --> Input Class Initialized
INFO - 2023-03-06 05:44:39 --> Language Class Initialized
INFO - 2023-03-06 05:44:39 --> Loader Class Initialized
INFO - 2023-03-06 05:44:39 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:39 --> Model "Login_model" initialized
INFO - 2023-03-06 05:44:39 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:39 --> Total execution time: 0.0549
INFO - 2023-03-06 05:44:39 --> Config Class Initialized
INFO - 2023-03-06 05:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:44:39 --> Utf8 Class Initialized
INFO - 2023-03-06 05:44:39 --> URI Class Initialized
INFO - 2023-03-06 05:44:39 --> Router Class Initialized
INFO - 2023-03-06 05:44:39 --> Output Class Initialized
INFO - 2023-03-06 05:44:39 --> Security Class Initialized
DEBUG - 2023-03-06 05:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:44:39 --> Input Class Initialized
INFO - 2023-03-06 05:44:39 --> Language Class Initialized
INFO - 2023-03-06 05:44:39 --> Loader Class Initialized
INFO - 2023-03-06 05:44:39 --> Controller Class Initialized
DEBUG - 2023-03-06 05:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:44:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:44:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:44:39 --> Model "Login_model" initialized
INFO - 2023-03-06 05:44:39 --> Final output sent to browser
DEBUG - 2023-03-06 05:44:39 --> Total execution time: 0.0533
INFO - 2023-03-06 05:45:09 --> Config Class Initialized
INFO - 2023-03-06 05:45:09 --> Config Class Initialized
INFO - 2023-03-06 05:45:09 --> Hooks Class Initialized
INFO - 2023-03-06 05:45:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:09 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 05:45:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:09 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:09 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:09 --> URI Class Initialized
INFO - 2023-03-06 05:45:09 --> URI Class Initialized
INFO - 2023-03-06 05:45:09 --> Router Class Initialized
INFO - 2023-03-06 05:45:09 --> Router Class Initialized
INFO - 2023-03-06 05:45:09 --> Output Class Initialized
INFO - 2023-03-06 05:45:09 --> Security Class Initialized
INFO - 2023-03-06 05:45:09 --> Output Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:09 --> Input Class Initialized
INFO - 2023-03-06 05:45:09 --> Security Class Initialized
INFO - 2023-03-06 05:45:09 --> Language Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:09 --> Input Class Initialized
INFO - 2023-03-06 05:45:09 --> Loader Class Initialized
INFO - 2023-03-06 05:45:09 --> Language Class Initialized
INFO - 2023-03-06 05:45:09 --> Controller Class Initialized
INFO - 2023-03-06 05:45:09 --> Loader Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:09 --> Controller Class Initialized
INFO - 2023-03-06 05:45:09 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:45:09 --> Total execution time: 0.0034
INFO - 2023-03-06 05:45:09 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:09 --> Config Class Initialized
INFO - 2023-03-06 05:45:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:09 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:09 --> URI Class Initialized
INFO - 2023-03-06 05:45:09 --> Router Class Initialized
INFO - 2023-03-06 05:45:09 --> Output Class Initialized
INFO - 2023-03-06 05:45:09 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:09 --> Input Class Initialized
INFO - 2023-03-06 05:45:09 --> Language Class Initialized
INFO - 2023-03-06 05:45:09 --> Loader Class Initialized
INFO - 2023-03-06 05:45:09 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:09 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:09 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:09 --> Model "Login_model" initialized
INFO - 2023-03-06 05:45:09 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:09 --> Total execution time: 0.0732
INFO - 2023-03-06 05:45:09 --> Config Class Initialized
INFO - 2023-03-06 05:45:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:09 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:09 --> URI Class Initialized
INFO - 2023-03-06 05:45:09 --> Router Class Initialized
INFO - 2023-03-06 05:45:09 --> Output Class Initialized
INFO - 2023-03-06 05:45:09 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:09 --> Input Class Initialized
INFO - 2023-03-06 05:45:09 --> Language Class Initialized
INFO - 2023-03-06 05:45:09 --> Loader Class Initialized
INFO - 2023-03-06 05:45:09 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:09 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:09 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:09 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:09 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:09 --> Total execution time: 0.0521
INFO - 2023-03-06 05:45:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:10 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:10 --> Total execution time: 0.1711
INFO - 2023-03-06 05:45:12 --> Config Class Initialized
INFO - 2023-03-06 05:45:12 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:12 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:12 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:12 --> URI Class Initialized
INFO - 2023-03-06 05:45:12 --> Router Class Initialized
INFO - 2023-03-06 05:45:12 --> Output Class Initialized
INFO - 2023-03-06 05:45:12 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:12 --> Input Class Initialized
INFO - 2023-03-06 05:45:12 --> Language Class Initialized
INFO - 2023-03-06 05:45:12 --> Loader Class Initialized
INFO - 2023-03-06 05:45:12 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:12 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:13 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:13 --> Total execution time: 0.1561
INFO - 2023-03-06 05:45:13 --> Config Class Initialized
INFO - 2023-03-06 05:45:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:13 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:13 --> URI Class Initialized
INFO - 2023-03-06 05:45:13 --> Router Class Initialized
INFO - 2023-03-06 05:45:13 --> Output Class Initialized
INFO - 2023-03-06 05:45:13 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:13 --> Input Class Initialized
INFO - 2023-03-06 05:45:13 --> Language Class Initialized
INFO - 2023-03-06 05:45:13 --> Loader Class Initialized
INFO - 2023-03-06 05:45:13 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:13 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:13 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:13 --> Total execution time: 0.0835
INFO - 2023-03-06 05:45:14 --> Config Class Initialized
INFO - 2023-03-06 05:45:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:14 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:14 --> URI Class Initialized
INFO - 2023-03-06 05:45:14 --> Router Class Initialized
INFO - 2023-03-06 05:45:14 --> Output Class Initialized
INFO - 2023-03-06 05:45:14 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:14 --> Input Class Initialized
INFO - 2023-03-06 05:45:14 --> Language Class Initialized
INFO - 2023-03-06 05:45:14 --> Loader Class Initialized
INFO - 2023-03-06 05:45:14 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:14 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:14 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:14 --> Model "Login_model" initialized
INFO - 2023-03-06 05:45:14 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:14 --> Total execution time: 0.1979
INFO - 2023-03-06 05:45:14 --> Config Class Initialized
INFO - 2023-03-06 05:45:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:45:14 --> Utf8 Class Initialized
INFO - 2023-03-06 05:45:14 --> URI Class Initialized
INFO - 2023-03-06 05:45:14 --> Router Class Initialized
INFO - 2023-03-06 05:45:14 --> Output Class Initialized
INFO - 2023-03-06 05:45:14 --> Security Class Initialized
DEBUG - 2023-03-06 05:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:45:14 --> Input Class Initialized
INFO - 2023-03-06 05:45:14 --> Language Class Initialized
INFO - 2023-03-06 05:45:14 --> Loader Class Initialized
INFO - 2023-03-06 05:45:14 --> Controller Class Initialized
DEBUG - 2023-03-06 05:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:45:14 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:45:14 --> Database Driver Class Initialized
INFO - 2023-03-06 05:45:14 --> Model "Login_model" initialized
INFO - 2023-03-06 05:45:14 --> Final output sent to browser
DEBUG - 2023-03-06 05:45:14 --> Total execution time: 0.1162
INFO - 2023-03-06 05:47:28 --> Config Class Initialized
INFO - 2023-03-06 05:47:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:28 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:28 --> URI Class Initialized
INFO - 2023-03-06 05:47:28 --> Router Class Initialized
INFO - 2023-03-06 05:47:28 --> Output Class Initialized
INFO - 2023-03-06 05:47:28 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:28 --> Input Class Initialized
INFO - 2023-03-06 05:47:28 --> Language Class Initialized
INFO - 2023-03-06 05:47:28 --> Loader Class Initialized
INFO - 2023-03-06 05:47:28 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:28 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:28 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:28 --> Total execution time: 0.0636
INFO - 2023-03-06 05:47:28 --> Config Class Initialized
INFO - 2023-03-06 05:47:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:28 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:28 --> URI Class Initialized
INFO - 2023-03-06 05:47:28 --> Router Class Initialized
INFO - 2023-03-06 05:47:28 --> Output Class Initialized
INFO - 2023-03-06 05:47:28 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:28 --> Input Class Initialized
INFO - 2023-03-06 05:47:28 --> Language Class Initialized
INFO - 2023-03-06 05:47:28 --> Loader Class Initialized
INFO - 2023-03-06 05:47:28 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:28 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:28 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:28 --> Total execution time: 0.0593
INFO - 2023-03-06 05:47:29 --> Config Class Initialized
INFO - 2023-03-06 05:47:29 --> Hooks Class Initialized
INFO - 2023-03-06 05:47:29 --> Config Class Initialized
DEBUG - 2023-03-06 05:47:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:29 --> Hooks Class Initialized
INFO - 2023-03-06 05:47:29 --> Utf8 Class Initialized
DEBUG - 2023-03-06 05:47:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:29 --> URI Class Initialized
INFO - 2023-03-06 05:47:29 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:29 --> Router Class Initialized
INFO - 2023-03-06 05:47:29 --> URI Class Initialized
INFO - 2023-03-06 05:47:29 --> Output Class Initialized
INFO - 2023-03-06 05:47:29 --> Router Class Initialized
INFO - 2023-03-06 05:47:29 --> Security Class Initialized
INFO - 2023-03-06 05:47:29 --> Output Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:29 --> Security Class Initialized
INFO - 2023-03-06 05:47:29 --> Input Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:29 --> Language Class Initialized
INFO - 2023-03-06 05:47:29 --> Input Class Initialized
INFO - 2023-03-06 05:47:29 --> Language Class Initialized
INFO - 2023-03-06 05:47:29 --> Loader Class Initialized
INFO - 2023-03-06 05:47:29 --> Loader Class Initialized
INFO - 2023-03-06 05:47:29 --> Controller Class Initialized
INFO - 2023-03-06 05:47:29 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:29 --> Final output sent to browser
INFO - 2023-03-06 05:47:29 --> Database Driver Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Total execution time: 0.0047
INFO - 2023-03-06 05:47:29 --> Config Class Initialized
INFO - 2023-03-06 05:47:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:29 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:29 --> URI Class Initialized
INFO - 2023-03-06 05:47:29 --> Router Class Initialized
INFO - 2023-03-06 05:47:29 --> Output Class Initialized
INFO - 2023-03-06 05:47:29 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:29 --> Input Class Initialized
INFO - 2023-03-06 05:47:29 --> Language Class Initialized
INFO - 2023-03-06 05:47:29 --> Loader Class Initialized
INFO - 2023-03-06 05:47:29 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:29 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:29 --> Model "Login_model" initialized
INFO - 2023-03-06 05:47:29 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:29 --> Total execution time: 0.0299
INFO - 2023-03-06 05:47:29 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:29 --> Config Class Initialized
INFO - 2023-03-06 05:47:29 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:29 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:29 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:29 --> URI Class Initialized
INFO - 2023-03-06 05:47:29 --> Router Class Initialized
INFO - 2023-03-06 05:47:29 --> Output Class Initialized
INFO - 2023-03-06 05:47:29 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:29 --> Input Class Initialized
INFO - 2023-03-06 05:47:29 --> Language Class Initialized
INFO - 2023-03-06 05:47:29 --> Loader Class Initialized
INFO - 2023-03-06 05:47:29 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:29 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:29 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:29 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:29 --> Total execution time: 0.0392
INFO - 2023-03-06 05:47:29 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:29 --> Total execution time: 0.0180
INFO - 2023-03-06 05:47:30 --> Config Class Initialized
INFO - 2023-03-06 05:47:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:30 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:30 --> URI Class Initialized
INFO - 2023-03-06 05:47:30 --> Router Class Initialized
INFO - 2023-03-06 05:47:30 --> Output Class Initialized
INFO - 2023-03-06 05:47:30 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:30 --> Input Class Initialized
INFO - 2023-03-06 05:47:30 --> Language Class Initialized
INFO - 2023-03-06 05:47:30 --> Loader Class Initialized
INFO - 2023-03-06 05:47:30 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:30 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:30 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:30 --> Model "Login_model" initialized
INFO - 2023-03-06 05:47:30 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:30 --> Total execution time: 0.0938
INFO - 2023-03-06 05:47:30 --> Config Class Initialized
INFO - 2023-03-06 05:47:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:30 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:30 --> URI Class Initialized
INFO - 2023-03-06 05:47:30 --> Router Class Initialized
INFO - 2023-03-06 05:47:30 --> Output Class Initialized
INFO - 2023-03-06 05:47:30 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:30 --> Input Class Initialized
INFO - 2023-03-06 05:47:30 --> Language Class Initialized
INFO - 2023-03-06 05:47:30 --> Loader Class Initialized
INFO - 2023-03-06 05:47:30 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:30 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:30 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:30 --> Model "Login_model" initialized
INFO - 2023-03-06 05:47:30 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:30 --> Total execution time: 0.0431
INFO - 2023-03-06 05:47:47 --> Config Class Initialized
INFO - 2023-03-06 05:47:47 --> Config Class Initialized
INFO - 2023-03-06 05:47:47 --> Hooks Class Initialized
INFO - 2023-03-06 05:47:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:47 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 05:47:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:47 --> URI Class Initialized
INFO - 2023-03-06 05:47:47 --> URI Class Initialized
INFO - 2023-03-06 05:47:47 --> Router Class Initialized
INFO - 2023-03-06 05:47:47 --> Router Class Initialized
INFO - 2023-03-06 05:47:47 --> Output Class Initialized
INFO - 2023-03-06 05:47:47 --> Output Class Initialized
INFO - 2023-03-06 05:47:47 --> Security Class Initialized
INFO - 2023-03-06 05:47:47 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:47 --> Input Class Initialized
INFO - 2023-03-06 05:47:47 --> Input Class Initialized
INFO - 2023-03-06 05:47:47 --> Language Class Initialized
INFO - 2023-03-06 05:47:47 --> Language Class Initialized
INFO - 2023-03-06 05:47:47 --> Loader Class Initialized
INFO - 2023-03-06 05:47:47 --> Loader Class Initialized
INFO - 2023-03-06 05:47:47 --> Controller Class Initialized
INFO - 2023-03-06 05:47:47 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:47 --> Final output sent to browser
INFO - 2023-03-06 05:47:47 --> Database Driver Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Total execution time: 0.0046
INFO - 2023-03-06 05:47:47 --> Config Class Initialized
INFO - 2023-03-06 05:47:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:47 --> URI Class Initialized
INFO - 2023-03-06 05:47:47 --> Router Class Initialized
INFO - 2023-03-06 05:47:47 --> Output Class Initialized
INFO - 2023-03-06 05:47:47 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:47 --> Input Class Initialized
INFO - 2023-03-06 05:47:47 --> Language Class Initialized
INFO - 2023-03-06 05:47:47 --> Loader Class Initialized
INFO - 2023-03-06 05:47:47 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:47 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:47 --> Total execution time: 0.0169
INFO - 2023-03-06 05:47:47 --> Model "Login_model" initialized
INFO - 2023-03-06 05:47:47 --> Config Class Initialized
INFO - 2023-03-06 05:47:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:47:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:47:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:47:47 --> URI Class Initialized
INFO - 2023-03-06 05:47:47 --> Router Class Initialized
INFO - 2023-03-06 05:47:47 --> Output Class Initialized
INFO - 2023-03-06 05:47:47 --> Security Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:47:47 --> Input Class Initialized
INFO - 2023-03-06 05:47:47 --> Language Class Initialized
INFO - 2023-03-06 05:47:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:47 --> Loader Class Initialized
INFO - 2023-03-06 05:47:47 --> Controller Class Initialized
DEBUG - 2023-03-06 05:47:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:47:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:47:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:47:47 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:47 --> Total execution time: 0.0393
INFO - 2023-03-06 05:47:47 --> Final output sent to browser
DEBUG - 2023-03-06 05:47:47 --> Total execution time: 0.0319
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Login_model" initialized
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0495
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Login_model" initialized
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0460
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0032
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
INFO - 2023-03-06 05:49:23 --> Model "Login_model" initialized
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0162
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Config Class Initialized
INFO - 2023-03-06 05:49:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:23 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:23 --> URI Class Initialized
INFO - 2023-03-06 05:49:23 --> Router Class Initialized
INFO - 2023-03-06 05:49:23 --> Output Class Initialized
INFO - 2023-03-06 05:49:23 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:23 --> Input Class Initialized
INFO - 2023-03-06 05:49:23 --> Language Class Initialized
INFO - 2023-03-06 05:49:23 --> Loader Class Initialized
INFO - 2023-03-06 05:49:23 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:23 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0629
INFO - 2023-03-06 05:49:23 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:23 --> Total execution time: 0.0143
INFO - 2023-03-06 05:49:25 --> Config Class Initialized
INFO - 2023-03-06 05:49:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:25 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:25 --> URI Class Initialized
INFO - 2023-03-06 05:49:25 --> Router Class Initialized
INFO - 2023-03-06 05:49:25 --> Output Class Initialized
INFO - 2023-03-06 05:49:25 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:25 --> Input Class Initialized
INFO - 2023-03-06 05:49:25 --> Language Class Initialized
INFO - 2023-03-06 05:49:25 --> Loader Class Initialized
INFO - 2023-03-06 05:49:25 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:25 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:25 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:25 --> Total execution time: 0.0370
INFO - 2023-03-06 05:49:25 --> Config Class Initialized
INFO - 2023-03-06 05:49:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:25 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:25 --> URI Class Initialized
INFO - 2023-03-06 05:49:25 --> Router Class Initialized
INFO - 2023-03-06 05:49:25 --> Output Class Initialized
INFO - 2023-03-06 05:49:25 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:25 --> Input Class Initialized
INFO - 2023-03-06 05:49:25 --> Language Class Initialized
INFO - 2023-03-06 05:49:25 --> Loader Class Initialized
INFO - 2023-03-06 05:49:25 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:25 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:25 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:25 --> Total execution time: 0.0255
INFO - 2023-03-06 05:49:47 --> Config Class Initialized
INFO - 2023-03-06 05:49:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:47 --> URI Class Initialized
INFO - 2023-03-06 05:49:47 --> Router Class Initialized
INFO - 2023-03-06 05:49:47 --> Output Class Initialized
INFO - 2023-03-06 05:49:47 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:47 --> Input Class Initialized
INFO - 2023-03-06 05:49:47 --> Language Class Initialized
INFO - 2023-03-06 05:49:47 --> Loader Class Initialized
INFO - 2023-03-06 05:49:47 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:47 --> Model "Login_model" initialized
INFO - 2023-03-06 05:49:47 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:47 --> Total execution time: 0.0474
INFO - 2023-03-06 05:49:47 --> Config Class Initialized
INFO - 2023-03-06 05:49:47 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:49:47 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:49:47 --> Utf8 Class Initialized
INFO - 2023-03-06 05:49:47 --> URI Class Initialized
INFO - 2023-03-06 05:49:47 --> Router Class Initialized
INFO - 2023-03-06 05:49:47 --> Output Class Initialized
INFO - 2023-03-06 05:49:47 --> Security Class Initialized
DEBUG - 2023-03-06 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:49:47 --> Input Class Initialized
INFO - 2023-03-06 05:49:47 --> Language Class Initialized
INFO - 2023-03-06 05:49:47 --> Loader Class Initialized
INFO - 2023-03-06 05:49:47 --> Controller Class Initialized
DEBUG - 2023-03-06 05:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:49:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:47 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:49:47 --> Database Driver Class Initialized
INFO - 2023-03-06 05:49:47 --> Model "Login_model" initialized
INFO - 2023-03-06 05:49:47 --> Final output sent to browser
DEBUG - 2023-03-06 05:49:47 --> Total execution time: 0.0442
INFO - 2023-03-06 05:59:39 --> Config Class Initialized
INFO - 2023-03-06 05:59:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:39 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:39 --> URI Class Initialized
INFO - 2023-03-06 05:59:39 --> Router Class Initialized
INFO - 2023-03-06 05:59:39 --> Output Class Initialized
INFO - 2023-03-06 05:59:39 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:39 --> Input Class Initialized
INFO - 2023-03-06 05:59:39 --> Language Class Initialized
INFO - 2023-03-06 05:59:39 --> Loader Class Initialized
INFO - 2023-03-06 05:59:39 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:39 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:39 --> Total execution time: 0.0310
INFO - 2023-03-06 05:59:39 --> Config Class Initialized
INFO - 2023-03-06 05:59:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:39 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:39 --> URI Class Initialized
INFO - 2023-03-06 05:59:39 --> Router Class Initialized
INFO - 2023-03-06 05:59:39 --> Output Class Initialized
INFO - 2023-03-06 05:59:39 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:39 --> Input Class Initialized
INFO - 2023-03-06 05:59:39 --> Language Class Initialized
INFO - 2023-03-06 05:59:39 --> Loader Class Initialized
INFO - 2023-03-06 05:59:39 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:39 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:39 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:39 --> Total execution time: 0.0263
INFO - 2023-03-06 05:59:44 --> Config Class Initialized
INFO - 2023-03-06 05:59:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:44 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:44 --> URI Class Initialized
INFO - 2023-03-06 05:59:44 --> Router Class Initialized
INFO - 2023-03-06 05:59:44 --> Output Class Initialized
INFO - 2023-03-06 05:59:44 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:44 --> Input Class Initialized
INFO - 2023-03-06 05:59:44 --> Language Class Initialized
INFO - 2023-03-06 05:59:44 --> Loader Class Initialized
INFO - 2023-03-06 05:59:44 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:44 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:44 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:44 --> Model "Login_model" initialized
INFO - 2023-03-06 05:59:44 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:44 --> Total execution time: 0.0568
INFO - 2023-03-06 05:59:44 --> Config Class Initialized
INFO - 2023-03-06 05:59:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:44 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:44 --> URI Class Initialized
INFO - 2023-03-06 05:59:44 --> Router Class Initialized
INFO - 2023-03-06 05:59:44 --> Output Class Initialized
INFO - 2023-03-06 05:59:44 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:44 --> Input Class Initialized
INFO - 2023-03-06 05:59:44 --> Language Class Initialized
INFO - 2023-03-06 05:59:44 --> Loader Class Initialized
INFO - 2023-03-06 05:59:44 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:44 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:44 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:44 --> Model "Login_model" initialized
INFO - 2023-03-06 05:59:44 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:44 --> Total execution time: 0.0342
INFO - 2023-03-06 05:59:49 --> Config Class Initialized
INFO - 2023-03-06 05:59:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:49 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:49 --> URI Class Initialized
INFO - 2023-03-06 05:59:49 --> Router Class Initialized
INFO - 2023-03-06 05:59:49 --> Output Class Initialized
INFO - 2023-03-06 05:59:49 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:49 --> Input Class Initialized
INFO - 2023-03-06 05:59:49 --> Language Class Initialized
INFO - 2023-03-06 05:59:49 --> Loader Class Initialized
INFO - 2023-03-06 05:59:49 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:49 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:49 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:49 --> Total execution time: 0.0445
INFO - 2023-03-06 05:59:49 --> Config Class Initialized
INFO - 2023-03-06 05:59:50 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:50 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:50 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:50 --> URI Class Initialized
INFO - 2023-03-06 05:59:50 --> Router Class Initialized
INFO - 2023-03-06 05:59:50 --> Output Class Initialized
INFO - 2023-03-06 05:59:50 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:50 --> Input Class Initialized
INFO - 2023-03-06 05:59:50 --> Language Class Initialized
INFO - 2023-03-06 05:59:50 --> Loader Class Initialized
INFO - 2023-03-06 05:59:50 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:50 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:50 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:50 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:50 --> Total execution time: 0.0659
INFO - 2023-03-06 05:59:51 --> Config Class Initialized
INFO - 2023-03-06 05:59:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:51 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:51 --> URI Class Initialized
INFO - 2023-03-06 05:59:51 --> Router Class Initialized
INFO - 2023-03-06 05:59:51 --> Output Class Initialized
INFO - 2023-03-06 05:59:51 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:51 --> Input Class Initialized
INFO - 2023-03-06 05:59:51 --> Language Class Initialized
INFO - 2023-03-06 05:59:51 --> Loader Class Initialized
INFO - 2023-03-06 05:59:51 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:51 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:51 --> Total execution time: 0.0023
INFO - 2023-03-06 05:59:51 --> Config Class Initialized
INFO - 2023-03-06 05:59:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:51 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:51 --> URI Class Initialized
INFO - 2023-03-06 05:59:51 --> Router Class Initialized
INFO - 2023-03-06 05:59:51 --> Output Class Initialized
INFO - 2023-03-06 05:59:51 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:51 --> Input Class Initialized
INFO - 2023-03-06 05:59:51 --> Language Class Initialized
INFO - 2023-03-06 05:59:51 --> Loader Class Initialized
INFO - 2023-03-06 05:59:51 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:51 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:51 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:51 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:51 --> Total execution time: 0.0110
INFO - 2023-03-06 05:59:52 --> Config Class Initialized
INFO - 2023-03-06 05:59:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:52 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:52 --> URI Class Initialized
INFO - 2023-03-06 05:59:52 --> Router Class Initialized
INFO - 2023-03-06 05:59:52 --> Output Class Initialized
INFO - 2023-03-06 05:59:52 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:52 --> Input Class Initialized
INFO - 2023-03-06 05:59:52 --> Language Class Initialized
INFO - 2023-03-06 05:59:52 --> Loader Class Initialized
INFO - 2023-03-06 05:59:52 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:52 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:52 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:52 --> Total execution time: 0.0155
INFO - 2023-03-06 05:59:52 --> Config Class Initialized
INFO - 2023-03-06 05:59:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:52 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:52 --> URI Class Initialized
INFO - 2023-03-06 05:59:52 --> Router Class Initialized
INFO - 2023-03-06 05:59:52 --> Output Class Initialized
INFO - 2023-03-06 05:59:52 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:52 --> Input Class Initialized
INFO - 2023-03-06 05:59:52 --> Language Class Initialized
INFO - 2023-03-06 05:59:52 --> Loader Class Initialized
INFO - 2023-03-06 05:59:52 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:52 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:52 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:52 --> Total execution time: 0.0595
INFO - 2023-03-06 05:59:54 --> Config Class Initialized
INFO - 2023-03-06 05:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:54 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:54 --> URI Class Initialized
INFO - 2023-03-06 05:59:54 --> Router Class Initialized
INFO - 2023-03-06 05:59:54 --> Output Class Initialized
INFO - 2023-03-06 05:59:54 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:54 --> Input Class Initialized
INFO - 2023-03-06 05:59:54 --> Language Class Initialized
INFO - 2023-03-06 05:59:54 --> Loader Class Initialized
INFO - 2023-03-06 05:59:54 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:54 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:54 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:54 --> Total execution time: 0.0367
INFO - 2023-03-06 05:59:54 --> Config Class Initialized
INFO - 2023-03-06 05:59:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:54 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:54 --> URI Class Initialized
INFO - 2023-03-06 05:59:54 --> Router Class Initialized
INFO - 2023-03-06 05:59:54 --> Output Class Initialized
INFO - 2023-03-06 05:59:54 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:54 --> Input Class Initialized
INFO - 2023-03-06 05:59:54 --> Language Class Initialized
INFO - 2023-03-06 05:59:54 --> Loader Class Initialized
INFO - 2023-03-06 05:59:54 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:54 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:54 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:54 --> Total execution time: 0.0523
INFO - 2023-03-06 05:59:55 --> Config Class Initialized
INFO - 2023-03-06 05:59:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:55 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:55 --> URI Class Initialized
INFO - 2023-03-06 05:59:55 --> Router Class Initialized
INFO - 2023-03-06 05:59:55 --> Output Class Initialized
INFO - 2023-03-06 05:59:55 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:55 --> Input Class Initialized
INFO - 2023-03-06 05:59:55 --> Language Class Initialized
INFO - 2023-03-06 05:59:55 --> Loader Class Initialized
INFO - 2023-03-06 05:59:55 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:55 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:55 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:55 --> Total execution time: 0.0134
INFO - 2023-03-06 05:59:57 --> Config Class Initialized
INFO - 2023-03-06 05:59:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:57 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:57 --> URI Class Initialized
INFO - 2023-03-06 05:59:57 --> Router Class Initialized
INFO - 2023-03-06 05:59:57 --> Output Class Initialized
INFO - 2023-03-06 05:59:57 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:57 --> Input Class Initialized
INFO - 2023-03-06 05:59:57 --> Language Class Initialized
INFO - 2023-03-06 05:59:57 --> Loader Class Initialized
INFO - 2023-03-06 05:59:57 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:57 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:57 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:57 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:57 --> Total execution time: 0.1414
INFO - 2023-03-06 05:59:57 --> Config Class Initialized
INFO - 2023-03-06 05:59:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 05:59:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 05:59:57 --> Utf8 Class Initialized
INFO - 2023-03-06 05:59:57 --> URI Class Initialized
INFO - 2023-03-06 05:59:57 --> Router Class Initialized
INFO - 2023-03-06 05:59:57 --> Output Class Initialized
INFO - 2023-03-06 05:59:57 --> Security Class Initialized
DEBUG - 2023-03-06 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 05:59:57 --> Input Class Initialized
INFO - 2023-03-06 05:59:57 --> Language Class Initialized
INFO - 2023-03-06 05:59:57 --> Loader Class Initialized
INFO - 2023-03-06 05:59:57 --> Controller Class Initialized
DEBUG - 2023-03-06 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 05:59:57 --> Database Driver Class Initialized
INFO - 2023-03-06 05:59:57 --> Model "Cluster_model" initialized
INFO - 2023-03-06 05:59:57 --> Final output sent to browser
DEBUG - 2023-03-06 05:59:57 --> Total execution time: 0.0584
INFO - 2023-03-06 06:00:01 --> Config Class Initialized
INFO - 2023-03-06 06:00:01 --> Config Class Initialized
INFO - 2023-03-06 06:00:01 --> Hooks Class Initialized
INFO - 2023-03-06 06:00:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:00:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:01 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:01 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:01 --> URI Class Initialized
INFO - 2023-03-06 06:00:01 --> URI Class Initialized
INFO - 2023-03-06 06:00:01 --> Router Class Initialized
INFO - 2023-03-06 06:00:01 --> Router Class Initialized
INFO - 2023-03-06 06:00:01 --> Output Class Initialized
INFO - 2023-03-06 06:00:01 --> Output Class Initialized
INFO - 2023-03-06 06:00:01 --> Security Class Initialized
INFO - 2023-03-06 06:00:01 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:01 --> Input Class Initialized
INFO - 2023-03-06 06:00:01 --> Input Class Initialized
INFO - 2023-03-06 06:00:01 --> Language Class Initialized
INFO - 2023-03-06 06:00:01 --> Language Class Initialized
INFO - 2023-03-06 06:00:01 --> Loader Class Initialized
INFO - 2023-03-06 06:00:01 --> Loader Class Initialized
INFO - 2023-03-06 06:00:01 --> Controller Class Initialized
INFO - 2023-03-06 06:00:01 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:00:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:01 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:01 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:01 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:01 --> Total execution time: 0.0168
INFO - 2023-03-06 06:00:01 --> Config Class Initialized
INFO - 2023-03-06 06:00:01 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:01 --> Total execution time: 0.0268
INFO - 2023-03-06 06:00:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:01 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:01 --> URI Class Initialized
INFO - 2023-03-06 06:00:01 --> Router Class Initialized
INFO - 2023-03-06 06:00:01 --> Output Class Initialized
INFO - 2023-03-06 06:00:01 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:01 --> Input Class Initialized
INFO - 2023-03-06 06:00:01 --> Language Class Initialized
INFO - 2023-03-06 06:00:01 --> Loader Class Initialized
INFO - 2023-03-06 06:00:01 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:01 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:01 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:01 --> Total execution time: 0.0957
INFO - 2023-03-06 06:00:02 --> Config Class Initialized
INFO - 2023-03-06 06:00:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:02 --> URI Class Initialized
INFO - 2023-03-06 06:00:02 --> Router Class Initialized
INFO - 2023-03-06 06:00:02 --> Output Class Initialized
INFO - 2023-03-06 06:00:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:02 --> Input Class Initialized
INFO - 2023-03-06 06:00:02 --> Language Class Initialized
INFO - 2023-03-06 06:00:02 --> Loader Class Initialized
INFO - 2023-03-06 06:00:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:02 --> Total execution time: 0.0627
INFO - 2023-03-06 06:00:03 --> Config Class Initialized
INFO - 2023-03-06 06:00:03 --> Config Class Initialized
INFO - 2023-03-06 06:00:03 --> Hooks Class Initialized
INFO - 2023-03-06 06:00:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:00:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:03 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:03 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:03 --> URI Class Initialized
INFO - 2023-03-06 06:00:03 --> URI Class Initialized
INFO - 2023-03-06 06:00:03 --> Router Class Initialized
INFO - 2023-03-06 06:00:03 --> Router Class Initialized
INFO - 2023-03-06 06:00:03 --> Output Class Initialized
INFO - 2023-03-06 06:00:03 --> Output Class Initialized
INFO - 2023-03-06 06:00:03 --> Security Class Initialized
INFO - 2023-03-06 06:00:03 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:03 --> Input Class Initialized
INFO - 2023-03-06 06:00:03 --> Input Class Initialized
INFO - 2023-03-06 06:00:03 --> Language Class Initialized
INFO - 2023-03-06 06:00:03 --> Language Class Initialized
INFO - 2023-03-06 06:00:03 --> Loader Class Initialized
INFO - 2023-03-06 06:00:03 --> Loader Class Initialized
INFO - 2023-03-06 06:00:03 --> Controller Class Initialized
INFO - 2023-03-06 06:00:03 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:03 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:03 --> Total execution time: 0.0162
INFO - 2023-03-06 06:00:03 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:03 --> Total execution time: 0.0218
INFO - 2023-03-06 06:00:03 --> Config Class Initialized
INFO - 2023-03-06 06:00:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:03 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:03 --> URI Class Initialized
INFO - 2023-03-06 06:00:03 --> Router Class Initialized
INFO - 2023-03-06 06:00:03 --> Output Class Initialized
INFO - 2023-03-06 06:00:03 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:03 --> Input Class Initialized
INFO - 2023-03-06 06:00:03 --> Language Class Initialized
INFO - 2023-03-06 06:00:03 --> Loader Class Initialized
INFO - 2023-03-06 06:00:03 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:03 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:03 --> Total execution time: 0.0613
INFO - 2023-03-06 06:00:04 --> Config Class Initialized
INFO - 2023-03-06 06:00:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:04 --> URI Class Initialized
INFO - 2023-03-06 06:00:04 --> Router Class Initialized
INFO - 2023-03-06 06:00:04 --> Output Class Initialized
INFO - 2023-03-06 06:00:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:04 --> Input Class Initialized
INFO - 2023-03-06 06:00:04 --> Language Class Initialized
INFO - 2023-03-06 06:00:04 --> Loader Class Initialized
INFO - 2023-03-06 06:00:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:04 --> Total execution time: 0.0038
INFO - 2023-03-06 06:00:04 --> Config Class Initialized
INFO - 2023-03-06 06:00:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:04 --> URI Class Initialized
INFO - 2023-03-06 06:00:04 --> Router Class Initialized
INFO - 2023-03-06 06:00:04 --> Output Class Initialized
INFO - 2023-03-06 06:00:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:04 --> Input Class Initialized
INFO - 2023-03-06 06:00:04 --> Language Class Initialized
INFO - 2023-03-06 06:00:04 --> Loader Class Initialized
INFO - 2023-03-06 06:00:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:04 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:04 --> Total execution time: 0.0125
INFO - 2023-03-06 06:00:05 --> Config Class Initialized
INFO - 2023-03-06 06:00:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:05 --> URI Class Initialized
INFO - 2023-03-06 06:00:05 --> Router Class Initialized
INFO - 2023-03-06 06:00:05 --> Output Class Initialized
INFO - 2023-03-06 06:00:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:05 --> Input Class Initialized
INFO - 2023-03-06 06:00:05 --> Language Class Initialized
INFO - 2023-03-06 06:00:05 --> Loader Class Initialized
INFO - 2023-03-06 06:00:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:05 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:05 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:05 --> Total execution time: 0.0164
INFO - 2023-03-06 06:00:06 --> Config Class Initialized
INFO - 2023-03-06 06:00:06 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:06 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:06 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:06 --> URI Class Initialized
INFO - 2023-03-06 06:00:06 --> Router Class Initialized
INFO - 2023-03-06 06:00:06 --> Output Class Initialized
INFO - 2023-03-06 06:00:06 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:06 --> Input Class Initialized
INFO - 2023-03-06 06:00:06 --> Language Class Initialized
INFO - 2023-03-06 06:00:06 --> Loader Class Initialized
INFO - 2023-03-06 06:00:06 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:06 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:06 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:06 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:06 --> Total execution time: 0.0235
INFO - 2023-03-06 06:00:07 --> Config Class Initialized
INFO - 2023-03-06 06:00:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:07 --> URI Class Initialized
INFO - 2023-03-06 06:00:07 --> Router Class Initialized
INFO - 2023-03-06 06:00:07 --> Output Class Initialized
INFO - 2023-03-06 06:00:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:07 --> Input Class Initialized
INFO - 2023-03-06 06:00:07 --> Language Class Initialized
INFO - 2023-03-06 06:00:07 --> Loader Class Initialized
INFO - 2023-03-06 06:00:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:07 --> Total execution time: 0.0179
INFO - 2023-03-06 06:00:07 --> Config Class Initialized
INFO - 2023-03-06 06:00:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:07 --> URI Class Initialized
INFO - 2023-03-06 06:00:07 --> Router Class Initialized
INFO - 2023-03-06 06:00:07 --> Output Class Initialized
INFO - 2023-03-06 06:00:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:07 --> Input Class Initialized
INFO - 2023-03-06 06:00:07 --> Language Class Initialized
INFO - 2023-03-06 06:00:07 --> Loader Class Initialized
INFO - 2023-03-06 06:00:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:07 --> Total execution time: 0.0120
INFO - 2023-03-06 06:00:07 --> Config Class Initialized
INFO - 2023-03-06 06:00:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:07 --> URI Class Initialized
INFO - 2023-03-06 06:00:07 --> Router Class Initialized
INFO - 2023-03-06 06:00:07 --> Output Class Initialized
INFO - 2023-03-06 06:00:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:07 --> Input Class Initialized
INFO - 2023-03-06 06:00:07 --> Language Class Initialized
INFO - 2023-03-06 06:00:07 --> Loader Class Initialized
INFO - 2023-03-06 06:00:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:07 --> Total execution time: 0.0269
INFO - 2023-03-06 06:00:07 --> Config Class Initialized
INFO - 2023-03-06 06:00:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:07 --> URI Class Initialized
INFO - 2023-03-06 06:00:07 --> Router Class Initialized
INFO - 2023-03-06 06:00:07 --> Output Class Initialized
INFO - 2023-03-06 06:00:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:07 --> Input Class Initialized
INFO - 2023-03-06 06:00:07 --> Language Class Initialized
INFO - 2023-03-06 06:00:07 --> Loader Class Initialized
INFO - 2023-03-06 06:00:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:07 --> Total execution time: 0.0601
INFO - 2023-03-06 06:00:08 --> Config Class Initialized
INFO - 2023-03-06 06:00:08 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:08 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:08 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:08 --> URI Class Initialized
INFO - 2023-03-06 06:00:08 --> Router Class Initialized
INFO - 2023-03-06 06:00:08 --> Output Class Initialized
INFO - 2023-03-06 06:00:08 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:08 --> Input Class Initialized
INFO - 2023-03-06 06:00:08 --> Language Class Initialized
INFO - 2023-03-06 06:00:08 --> Loader Class Initialized
INFO - 2023-03-06 06:00:08 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:08 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:08 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:08 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:08 --> Total execution time: 0.0161
INFO - 2023-03-06 06:00:09 --> Config Class Initialized
INFO - 2023-03-06 06:00:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:09 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:09 --> URI Class Initialized
INFO - 2023-03-06 06:00:09 --> Router Class Initialized
INFO - 2023-03-06 06:00:09 --> Output Class Initialized
INFO - 2023-03-06 06:00:09 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:09 --> Input Class Initialized
INFO - 2023-03-06 06:00:09 --> Language Class Initialized
INFO - 2023-03-06 06:00:09 --> Loader Class Initialized
INFO - 2023-03-06 06:00:09 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:09 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:09 --> Total execution time: 0.0035
INFO - 2023-03-06 06:00:09 --> Config Class Initialized
INFO - 2023-03-06 06:00:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:00:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:00:09 --> Utf8 Class Initialized
INFO - 2023-03-06 06:00:09 --> URI Class Initialized
INFO - 2023-03-06 06:00:09 --> Router Class Initialized
INFO - 2023-03-06 06:00:09 --> Output Class Initialized
INFO - 2023-03-06 06:00:09 --> Security Class Initialized
DEBUG - 2023-03-06 06:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:00:09 --> Input Class Initialized
INFO - 2023-03-06 06:00:09 --> Language Class Initialized
INFO - 2023-03-06 06:00:09 --> Loader Class Initialized
INFO - 2023-03-06 06:00:09 --> Controller Class Initialized
DEBUG - 2023-03-06 06:00:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:00:09 --> Database Driver Class Initialized
INFO - 2023-03-06 06:00:09 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:00:09 --> Final output sent to browser
DEBUG - 2023-03-06 06:00:09 --> Total execution time: 0.0133
INFO - 2023-03-06 06:01:26 --> Config Class Initialized
INFO - 2023-03-06 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:26 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:26 --> URI Class Initialized
INFO - 2023-03-06 06:01:26 --> Router Class Initialized
INFO - 2023-03-06 06:01:26 --> Output Class Initialized
INFO - 2023-03-06 06:01:26 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:26 --> Input Class Initialized
INFO - 2023-03-06 06:01:26 --> Language Class Initialized
INFO - 2023-03-06 06:01:26 --> Loader Class Initialized
INFO - 2023-03-06 06:01:26 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:26 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:26 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:26 --> Total execution time: 0.0619
INFO - 2023-03-06 06:01:26 --> Config Class Initialized
INFO - 2023-03-06 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:26 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:26 --> URI Class Initialized
INFO - 2023-03-06 06:01:26 --> Router Class Initialized
INFO - 2023-03-06 06:01:26 --> Output Class Initialized
INFO - 2023-03-06 06:01:26 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:26 --> Input Class Initialized
INFO - 2023-03-06 06:01:26 --> Language Class Initialized
INFO - 2023-03-06 06:01:26 --> Loader Class Initialized
INFO - 2023-03-06 06:01:26 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:26 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:26 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:26 --> Total execution time: 0.0148
INFO - 2023-03-06 06:01:28 --> Config Class Initialized
INFO - 2023-03-06 06:01:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:28 --> URI Class Initialized
INFO - 2023-03-06 06:01:28 --> Router Class Initialized
INFO - 2023-03-06 06:01:28 --> Output Class Initialized
INFO - 2023-03-06 06:01:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:28 --> Input Class Initialized
INFO - 2023-03-06 06:01:28 --> Language Class Initialized
INFO - 2023-03-06 06:01:28 --> Loader Class Initialized
INFO - 2023-03-06 06:01:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:28 --> Total execution time: 0.0036
INFO - 2023-03-06 06:01:28 --> Config Class Initialized
INFO - 2023-03-06 06:01:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:28 --> URI Class Initialized
INFO - 2023-03-06 06:01:28 --> Router Class Initialized
INFO - 2023-03-06 06:01:28 --> Output Class Initialized
INFO - 2023-03-06 06:01:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:28 --> Input Class Initialized
INFO - 2023-03-06 06:01:28 --> Language Class Initialized
INFO - 2023-03-06 06:01:28 --> Loader Class Initialized
INFO - 2023-03-06 06:01:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:28 --> Model "Login_model" initialized
INFO - 2023-03-06 06:01:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:28 --> Total execution time: 0.0216
INFO - 2023-03-06 06:01:28 --> Config Class Initialized
INFO - 2023-03-06 06:01:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:28 --> URI Class Initialized
INFO - 2023-03-06 06:01:28 --> Router Class Initialized
INFO - 2023-03-06 06:01:28 --> Output Class Initialized
INFO - 2023-03-06 06:01:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:28 --> Input Class Initialized
INFO - 2023-03-06 06:01:28 --> Language Class Initialized
INFO - 2023-03-06 06:01:28 --> Loader Class Initialized
INFO - 2023-03-06 06:01:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:28 --> Total execution time: 0.0430
INFO - 2023-03-06 06:01:28 --> Config Class Initialized
INFO - 2023-03-06 06:01:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:28 --> URI Class Initialized
INFO - 2023-03-06 06:01:28 --> Router Class Initialized
INFO - 2023-03-06 06:01:28 --> Output Class Initialized
INFO - 2023-03-06 06:01:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:28 --> Input Class Initialized
INFO - 2023-03-06 06:01:28 --> Language Class Initialized
INFO - 2023-03-06 06:01:28 --> Loader Class Initialized
INFO - 2023-03-06 06:01:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:28 --> Model "Login_model" initialized
INFO - 2023-03-06 06:01:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:28 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:28 --> Total execution time: 0.0218
INFO - 2023-03-06 06:01:33 --> Config Class Initialized
INFO - 2023-03-06 06:01:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:33 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:33 --> URI Class Initialized
INFO - 2023-03-06 06:01:33 --> Router Class Initialized
INFO - 2023-03-06 06:01:33 --> Output Class Initialized
INFO - 2023-03-06 06:01:33 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:33 --> Input Class Initialized
INFO - 2023-03-06 06:01:33 --> Language Class Initialized
INFO - 2023-03-06 06:01:33 --> Loader Class Initialized
INFO - 2023-03-06 06:01:33 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:33 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:33 --> Model "Login_model" initialized
INFO - 2023-03-06 06:01:33 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:33 --> Total execution time: 0.0429
INFO - 2023-03-06 06:01:33 --> Config Class Initialized
INFO - 2023-03-06 06:01:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:01:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:01:33 --> Utf8 Class Initialized
INFO - 2023-03-06 06:01:33 --> URI Class Initialized
INFO - 2023-03-06 06:01:33 --> Router Class Initialized
INFO - 2023-03-06 06:01:33 --> Output Class Initialized
INFO - 2023-03-06 06:01:33 --> Security Class Initialized
DEBUG - 2023-03-06 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:01:33 --> Input Class Initialized
INFO - 2023-03-06 06:01:33 --> Language Class Initialized
INFO - 2023-03-06 06:01:33 --> Loader Class Initialized
INFO - 2023-03-06 06:01:33 --> Controller Class Initialized
DEBUG - 2023-03-06 06:01:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:01:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:33 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:01:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:01:33 --> Model "Login_model" initialized
INFO - 2023-03-06 06:01:33 --> Final output sent to browser
DEBUG - 2023-03-06 06:01:33 --> Total execution time: 0.0366
INFO - 2023-03-06 06:09:00 --> Config Class Initialized
INFO - 2023-03-06 06:09:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:00 --> URI Class Initialized
INFO - 2023-03-06 06:09:00 --> Router Class Initialized
INFO - 2023-03-06 06:09:00 --> Output Class Initialized
INFO - 2023-03-06 06:09:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:00 --> Input Class Initialized
INFO - 2023-03-06 06:09:00 --> Language Class Initialized
INFO - 2023-03-06 06:09:00 --> Loader Class Initialized
INFO - 2023-03-06 06:09:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:00 --> Total execution time: 0.0144
INFO - 2023-03-06 06:09:00 --> Config Class Initialized
INFO - 2023-03-06 06:09:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:00 --> URI Class Initialized
INFO - 2023-03-06 06:09:00 --> Router Class Initialized
INFO - 2023-03-06 06:09:00 --> Output Class Initialized
INFO - 2023-03-06 06:09:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:00 --> Input Class Initialized
INFO - 2023-03-06 06:09:00 --> Language Class Initialized
INFO - 2023-03-06 06:09:00 --> Loader Class Initialized
INFO - 2023-03-06 06:09:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:00 --> Total execution time: 0.0132
INFO - 2023-03-06 06:09:03 --> Config Class Initialized
INFO - 2023-03-06 06:09:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:03 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:03 --> URI Class Initialized
INFO - 2023-03-06 06:09:03 --> Router Class Initialized
INFO - 2023-03-06 06:09:03 --> Output Class Initialized
INFO - 2023-03-06 06:09:03 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:03 --> Input Class Initialized
INFO - 2023-03-06 06:09:03 --> Language Class Initialized
INFO - 2023-03-06 06:09:03 --> Loader Class Initialized
INFO - 2023-03-06 06:09:03 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:03 --> Model "Login_model" initialized
INFO - 2023-03-06 06:09:03 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:03 --> Total execution time: 0.1379
INFO - 2023-03-06 06:09:03 --> Config Class Initialized
INFO - 2023-03-06 06:09:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:03 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:03 --> URI Class Initialized
INFO - 2023-03-06 06:09:03 --> Router Class Initialized
INFO - 2023-03-06 06:09:03 --> Output Class Initialized
INFO - 2023-03-06 06:09:03 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:03 --> Input Class Initialized
INFO - 2023-03-06 06:09:03 --> Language Class Initialized
INFO - 2023-03-06 06:09:03 --> Loader Class Initialized
INFO - 2023-03-06 06:09:03 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:03 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:03 --> Model "Login_model" initialized
INFO - 2023-03-06 06:09:03 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:03 --> Total execution time: 0.0397
INFO - 2023-03-06 06:09:59 --> Config Class Initialized
INFO - 2023-03-06 06:09:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:59 --> Config Class Initialized
INFO - 2023-03-06 06:09:59 --> URI Class Initialized
INFO - 2023-03-06 06:09:59 --> Hooks Class Initialized
INFO - 2023-03-06 06:09:59 --> Router Class Initialized
DEBUG - 2023-03-06 06:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:59 --> Output Class Initialized
INFO - 2023-03-06 06:09:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:59 --> Security Class Initialized
INFO - 2023-03-06 06:09:59 --> URI Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:59 --> Router Class Initialized
INFO - 2023-03-06 06:09:59 --> Input Class Initialized
INFO - 2023-03-06 06:09:59 --> Output Class Initialized
INFO - 2023-03-06 06:09:59 --> Language Class Initialized
INFO - 2023-03-06 06:09:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:59 --> Loader Class Initialized
INFO - 2023-03-06 06:09:59 --> Input Class Initialized
INFO - 2023-03-06 06:09:59 --> Language Class Initialized
INFO - 2023-03-06 06:09:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:59 --> Loader Class Initialized
INFO - 2023-03-06 06:09:59 --> Controller Class Initialized
INFO - 2023-03-06 06:09:59 --> Database Driver Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:59 --> Total execution time: 0.0072
INFO - 2023-03-06 06:09:59 --> Config Class Initialized
INFO - 2023-03-06 06:09:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:59 --> URI Class Initialized
INFO - 2023-03-06 06:09:59 --> Router Class Initialized
INFO - 2023-03-06 06:09:59 --> Output Class Initialized
INFO - 2023-03-06 06:09:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:59 --> Input Class Initialized
INFO - 2023-03-06 06:09:59 --> Language Class Initialized
INFO - 2023-03-06 06:09:59 --> Loader Class Initialized
INFO - 2023-03-06 06:09:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:59 --> Model "Login_model" initialized
INFO - 2023-03-06 06:09:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:59 --> Total execution time: 0.0274
INFO - 2023-03-06 06:09:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:59 --> Config Class Initialized
INFO - 2023-03-06 06:09:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:09:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:09:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:09:59 --> URI Class Initialized
INFO - 2023-03-06 06:09:59 --> Router Class Initialized
INFO - 2023-03-06 06:09:59 --> Output Class Initialized
INFO - 2023-03-06 06:09:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:09:59 --> Input Class Initialized
INFO - 2023-03-06 06:09:59 --> Language Class Initialized
INFO - 2023-03-06 06:09:59 --> Loader Class Initialized
INFO - 2023-03-06 06:09:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:09:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:09:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:09:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:09:59 --> Total execution time: 0.0302
INFO - 2023-03-06 06:09:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:00 --> Total execution time: 0.0571
INFO - 2023-03-06 06:10:02 --> Config Class Initialized
INFO - 2023-03-06 06:10:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:02 --> URI Class Initialized
INFO - 2023-03-06 06:10:02 --> Router Class Initialized
INFO - 2023-03-06 06:10:02 --> Output Class Initialized
INFO - 2023-03-06 06:10:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:02 --> Input Class Initialized
INFO - 2023-03-06 06:10:02 --> Language Class Initialized
INFO - 2023-03-06 06:10:02 --> Loader Class Initialized
INFO - 2023-03-06 06:10:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:02 --> Total execution time: 0.0864
INFO - 2023-03-06 06:10:02 --> Config Class Initialized
INFO - 2023-03-06 06:10:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:02 --> URI Class Initialized
INFO - 2023-03-06 06:10:02 --> Router Class Initialized
INFO - 2023-03-06 06:10:02 --> Output Class Initialized
INFO - 2023-03-06 06:10:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:02 --> Input Class Initialized
INFO - 2023-03-06 06:10:02 --> Language Class Initialized
INFO - 2023-03-06 06:10:02 --> Loader Class Initialized
INFO - 2023-03-06 06:10:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:02 --> Total execution time: 0.0337
INFO - 2023-03-06 06:10:04 --> Config Class Initialized
INFO - 2023-03-06 06:10:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:04 --> URI Class Initialized
INFO - 2023-03-06 06:10:04 --> Router Class Initialized
INFO - 2023-03-06 06:10:04 --> Output Class Initialized
INFO - 2023-03-06 06:10:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:04 --> Input Class Initialized
INFO - 2023-03-06 06:10:04 --> Language Class Initialized
INFO - 2023-03-06 06:10:04 --> Loader Class Initialized
INFO - 2023-03-06 06:10:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:04 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:04 --> Total execution time: 0.0179
INFO - 2023-03-06 06:10:04 --> Config Class Initialized
INFO - 2023-03-06 06:10:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:04 --> URI Class Initialized
INFO - 2023-03-06 06:10:04 --> Router Class Initialized
INFO - 2023-03-06 06:10:04 --> Output Class Initialized
INFO - 2023-03-06 06:10:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:04 --> Input Class Initialized
INFO - 2023-03-06 06:10:04 --> Language Class Initialized
INFO - 2023-03-06 06:10:04 --> Loader Class Initialized
INFO - 2023-03-06 06:10:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:04 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:04 --> Total execution time: 0.0149
INFO - 2023-03-06 06:10:07 --> Config Class Initialized
INFO - 2023-03-06 06:10:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:07 --> URI Class Initialized
INFO - 2023-03-06 06:10:07 --> Router Class Initialized
INFO - 2023-03-06 06:10:07 --> Output Class Initialized
INFO - 2023-03-06 06:10:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:07 --> Input Class Initialized
INFO - 2023-03-06 06:10:07 --> Language Class Initialized
INFO - 2023-03-06 06:10:07 --> Loader Class Initialized
INFO - 2023-03-06 06:10:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:07 --> Model "Login_model" initialized
INFO - 2023-03-06 06:10:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:07 --> Total execution time: 0.0440
INFO - 2023-03-06 06:10:07 --> Config Class Initialized
INFO - 2023-03-06 06:10:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:10:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:10:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:10:07 --> URI Class Initialized
INFO - 2023-03-06 06:10:07 --> Router Class Initialized
INFO - 2023-03-06 06:10:07 --> Output Class Initialized
INFO - 2023-03-06 06:10:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:10:07 --> Input Class Initialized
INFO - 2023-03-06 06:10:07 --> Language Class Initialized
INFO - 2023-03-06 06:10:07 --> Loader Class Initialized
INFO - 2023-03-06 06:10:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:10:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:10:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:10:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:10:07 --> Model "Login_model" initialized
INFO - 2023-03-06 06:10:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:10:07 --> Total execution time: 0.0356
INFO - 2023-03-06 06:11:00 --> Config Class Initialized
INFO - 2023-03-06 06:11:00 --> Config Class Initialized
INFO - 2023-03-06 06:11:00 --> Hooks Class Initialized
INFO - 2023-03-06 06:11:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:11:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:11:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:00 --> URI Class Initialized
INFO - 2023-03-06 06:11:00 --> URI Class Initialized
INFO - 2023-03-06 06:11:00 --> Router Class Initialized
INFO - 2023-03-06 06:11:00 --> Router Class Initialized
INFO - 2023-03-06 06:11:00 --> Output Class Initialized
INFO - 2023-03-06 06:11:00 --> Output Class Initialized
INFO - 2023-03-06 06:11:00 --> Security Class Initialized
INFO - 2023-03-06 06:11:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:11:00 --> Input Class Initialized
INFO - 2023-03-06 06:11:00 --> Input Class Initialized
INFO - 2023-03-06 06:11:00 --> Language Class Initialized
INFO - 2023-03-06 06:11:00 --> Language Class Initialized
INFO - 2023-03-06 06:11:00 --> Loader Class Initialized
INFO - 2023-03-06 06:11:00 --> Loader Class Initialized
INFO - 2023-03-06 06:11:00 --> Controller Class Initialized
INFO - 2023-03-06 06:11:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:11:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:11:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:00 --> Total execution time: 0.0052
INFO - 2023-03-06 06:11:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:00 --> Config Class Initialized
INFO - 2023-03-06 06:11:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:11:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:11:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:00 --> URI Class Initialized
INFO - 2023-03-06 06:11:00 --> Router Class Initialized
INFO - 2023-03-06 06:11:00 --> Output Class Initialized
INFO - 2023-03-06 06:11:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:11:00 --> Input Class Initialized
INFO - 2023-03-06 06:11:00 --> Language Class Initialized
INFO - 2023-03-06 06:11:00 --> Loader Class Initialized
INFO - 2023-03-06 06:11:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:11:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:11:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:00 --> Total execution time: 0.0281
INFO - 2023-03-06 06:11:00 --> Config Class Initialized
INFO - 2023-03-06 06:11:00 --> Hooks Class Initialized
INFO - 2023-03-06 06:11:00 --> Model "Login_model" initialized
DEBUG - 2023-03-06 06:11:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:11:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:00 --> URI Class Initialized
INFO - 2023-03-06 06:11:00 --> Router Class Initialized
INFO - 2023-03-06 06:11:00 --> Output Class Initialized
INFO - 2023-03-06 06:11:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:11:00 --> Input Class Initialized
INFO - 2023-03-06 06:11:00 --> Language Class Initialized
INFO - 2023-03-06 06:11:00 --> Loader Class Initialized
INFO - 2023-03-06 06:11:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:11:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:11:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:11:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:11:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:00 --> Total execution time: 0.0160
INFO - 2023-03-06 06:11:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:00 --> Total execution time: 0.0419
INFO - 2023-03-06 06:11:02 --> Config Class Initialized
INFO - 2023-03-06 06:11:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:11:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:11:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:02 --> URI Class Initialized
INFO - 2023-03-06 06:11:02 --> Router Class Initialized
INFO - 2023-03-06 06:11:02 --> Output Class Initialized
INFO - 2023-03-06 06:11:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:11:02 --> Input Class Initialized
INFO - 2023-03-06 06:11:02 --> Language Class Initialized
INFO - 2023-03-06 06:11:02 --> Loader Class Initialized
INFO - 2023-03-06 06:11:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:11:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:11:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:11:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:02 --> Model "Login_model" initialized
INFO - 2023-03-06 06:11:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:02 --> Total execution time: 0.0451
INFO - 2023-03-06 06:11:02 --> Config Class Initialized
INFO - 2023-03-06 06:11:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:11:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:11:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:11:02 --> URI Class Initialized
INFO - 2023-03-06 06:11:02 --> Router Class Initialized
INFO - 2023-03-06 06:11:02 --> Output Class Initialized
INFO - 2023-03-06 06:11:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:11:02 --> Input Class Initialized
INFO - 2023-03-06 06:11:02 --> Language Class Initialized
INFO - 2023-03-06 06:11:02 --> Loader Class Initialized
INFO - 2023-03-06 06:11:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:11:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:11:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:11:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:11:02 --> Model "Login_model" initialized
INFO - 2023-03-06 06:11:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:11:02 --> Total execution time: 0.0392
INFO - 2023-03-06 06:18:07 --> Config Class Initialized
INFO - 2023-03-06 06:18:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:18:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:18:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:18:07 --> URI Class Initialized
INFO - 2023-03-06 06:18:07 --> Router Class Initialized
INFO - 2023-03-06 06:18:07 --> Output Class Initialized
INFO - 2023-03-06 06:18:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:18:07 --> Input Class Initialized
INFO - 2023-03-06 06:18:07 --> Language Class Initialized
INFO - 2023-03-06 06:18:07 --> Loader Class Initialized
INFO - 2023-03-06 06:18:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:18:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:18:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:18:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:18:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:18:07 --> Total execution time: 0.0150
INFO - 2023-03-06 06:18:07 --> Config Class Initialized
INFO - 2023-03-06 06:18:07 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:18:07 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:18:07 --> Utf8 Class Initialized
INFO - 2023-03-06 06:18:07 --> URI Class Initialized
INFO - 2023-03-06 06:18:07 --> Router Class Initialized
INFO - 2023-03-06 06:18:07 --> Output Class Initialized
INFO - 2023-03-06 06:18:07 --> Security Class Initialized
DEBUG - 2023-03-06 06:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:18:07 --> Input Class Initialized
INFO - 2023-03-06 06:18:07 --> Language Class Initialized
INFO - 2023-03-06 06:18:07 --> Loader Class Initialized
INFO - 2023-03-06 06:18:07 --> Controller Class Initialized
DEBUG - 2023-03-06 06:18:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:18:07 --> Database Driver Class Initialized
INFO - 2023-03-06 06:18:07 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:18:07 --> Final output sent to browser
DEBUG - 2023-03-06 06:18:07 --> Total execution time: 0.0134
INFO - 2023-03-06 06:26:49 --> Config Class Initialized
INFO - 2023-03-06 06:26:49 --> Config Class Initialized
INFO - 2023-03-06 06:26:49 --> Hooks Class Initialized
INFO - 2023-03-06 06:26:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:26:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:49 --> URI Class Initialized
INFO - 2023-03-06 06:26:49 --> URI Class Initialized
INFO - 2023-03-06 06:26:49 --> Router Class Initialized
INFO - 2023-03-06 06:26:49 --> Router Class Initialized
INFO - 2023-03-06 06:26:49 --> Output Class Initialized
INFO - 2023-03-06 06:26:49 --> Output Class Initialized
INFO - 2023-03-06 06:26:49 --> Security Class Initialized
INFO - 2023-03-06 06:26:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:49 --> Input Class Initialized
INFO - 2023-03-06 06:26:49 --> Input Class Initialized
INFO - 2023-03-06 06:26:49 --> Language Class Initialized
INFO - 2023-03-06 06:26:49 --> Language Class Initialized
INFO - 2023-03-06 06:26:49 --> Loader Class Initialized
INFO - 2023-03-06 06:26:49 --> Loader Class Initialized
INFO - 2023-03-06 06:26:49 --> Controller Class Initialized
INFO - 2023-03-06 06:26:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:26:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:49 --> Final output sent to browser
INFO - 2023-03-06 06:26:49 --> Database Driver Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Total execution time: 0.0034
INFO - 2023-03-06 06:26:49 --> Config Class Initialized
INFO - 2023-03-06 06:26:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:49 --> URI Class Initialized
INFO - 2023-03-06 06:26:49 --> Router Class Initialized
INFO - 2023-03-06 06:26:49 --> Output Class Initialized
INFO - 2023-03-06 06:26:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:49 --> Input Class Initialized
INFO - 2023-03-06 06:26:49 --> Language Class Initialized
INFO - 2023-03-06 06:26:49 --> Loader Class Initialized
INFO - 2023-03-06 06:26:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:49 --> Total execution time: 0.0179
INFO - 2023-03-06 06:26:49 --> Model "Login_model" initialized
INFO - 2023-03-06 06:26:49 --> Config Class Initialized
INFO - 2023-03-06 06:26:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:49 --> URI Class Initialized
INFO - 2023-03-06 06:26:49 --> Router Class Initialized
INFO - 2023-03-06 06:26:49 --> Output Class Initialized
INFO - 2023-03-06 06:26:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:49 --> Input Class Initialized
INFO - 2023-03-06 06:26:49 --> Language Class Initialized
INFO - 2023-03-06 06:26:49 --> Loader Class Initialized
INFO - 2023-03-06 06:26:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:49 --> Total execution time: 0.0363
INFO - 2023-03-06 06:26:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:49 --> Total execution time: 0.0258
INFO - 2023-03-06 06:26:51 --> Config Class Initialized
INFO - 2023-03-06 06:26:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:51 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:51 --> URI Class Initialized
INFO - 2023-03-06 06:26:51 --> Router Class Initialized
INFO - 2023-03-06 06:26:51 --> Output Class Initialized
INFO - 2023-03-06 06:26:51 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:51 --> Input Class Initialized
INFO - 2023-03-06 06:26:51 --> Language Class Initialized
INFO - 2023-03-06 06:26:51 --> Loader Class Initialized
INFO - 2023-03-06 06:26:51 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:51 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:51 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:51 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:51 --> Total execution time: 0.1411
INFO - 2023-03-06 06:26:51 --> Config Class Initialized
INFO - 2023-03-06 06:26:51 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:51 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:51 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:51 --> URI Class Initialized
INFO - 2023-03-06 06:26:51 --> Router Class Initialized
INFO - 2023-03-06 06:26:51 --> Output Class Initialized
INFO - 2023-03-06 06:26:51 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:51 --> Input Class Initialized
INFO - 2023-03-06 06:26:51 --> Language Class Initialized
INFO - 2023-03-06 06:26:51 --> Loader Class Initialized
INFO - 2023-03-06 06:26:51 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:51 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:51 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:51 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:51 --> Total execution time: 0.0247
INFO - 2023-03-06 06:26:52 --> Config Class Initialized
INFO - 2023-03-06 06:26:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:52 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:52 --> URI Class Initialized
INFO - 2023-03-06 06:26:52 --> Router Class Initialized
INFO - 2023-03-06 06:26:52 --> Output Class Initialized
INFO - 2023-03-06 06:26:52 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:52 --> Input Class Initialized
INFO - 2023-03-06 06:26:52 --> Language Class Initialized
INFO - 2023-03-06 06:26:52 --> Loader Class Initialized
INFO - 2023-03-06 06:26:52 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:52 --> Model "Login_model" initialized
INFO - 2023-03-06 06:26:52 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:52 --> Total execution time: 0.0421
INFO - 2023-03-06 06:26:52 --> Config Class Initialized
INFO - 2023-03-06 06:26:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:52 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:52 --> URI Class Initialized
INFO - 2023-03-06 06:26:52 --> Router Class Initialized
INFO - 2023-03-06 06:26:52 --> Output Class Initialized
INFO - 2023-03-06 06:26:52 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:52 --> Input Class Initialized
INFO - 2023-03-06 06:26:52 --> Language Class Initialized
INFO - 2023-03-06 06:26:52 --> Loader Class Initialized
INFO - 2023-03-06 06:26:52 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:52 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:52 --> Model "Login_model" initialized
INFO - 2023-03-06 06:26:52 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:52 --> Total execution time: 0.0382
INFO - 2023-03-06 06:26:56 --> Config Class Initialized
INFO - 2023-03-06 06:26:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:56 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:56 --> URI Class Initialized
INFO - 2023-03-06 06:26:56 --> Router Class Initialized
INFO - 2023-03-06 06:26:56 --> Output Class Initialized
INFO - 2023-03-06 06:26:56 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:56 --> Input Class Initialized
INFO - 2023-03-06 06:26:56 --> Language Class Initialized
INFO - 2023-03-06 06:26:56 --> Loader Class Initialized
INFO - 2023-03-06 06:26:56 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:56 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:56 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:56 --> Total execution time: 0.0265
INFO - 2023-03-06 06:26:56 --> Config Class Initialized
INFO - 2023-03-06 06:26:56 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:56 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:56 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:56 --> URI Class Initialized
INFO - 2023-03-06 06:26:56 --> Router Class Initialized
INFO - 2023-03-06 06:26:56 --> Output Class Initialized
INFO - 2023-03-06 06:26:56 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:56 --> Input Class Initialized
INFO - 2023-03-06 06:26:56 --> Language Class Initialized
INFO - 2023-03-06 06:26:56 --> Loader Class Initialized
INFO - 2023-03-06 06:26:56 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:56 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:56 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:56 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:56 --> Total execution time: 0.0204
INFO - 2023-03-06 06:26:57 --> Config Class Initialized
INFO - 2023-03-06 06:26:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:57 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:57 --> URI Class Initialized
INFO - 2023-03-06 06:26:57 --> Router Class Initialized
INFO - 2023-03-06 06:26:57 --> Output Class Initialized
INFO - 2023-03-06 06:26:57 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:57 --> Input Class Initialized
INFO - 2023-03-06 06:26:57 --> Language Class Initialized
INFO - 2023-03-06 06:26:57 --> Loader Class Initialized
INFO - 2023-03-06 06:26:57 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:57 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:57 --> Total execution time: 0.0047
INFO - 2023-03-06 06:26:57 --> Config Class Initialized
INFO - 2023-03-06 06:26:57 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:57 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:57 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:57 --> URI Class Initialized
INFO - 2023-03-06 06:26:57 --> Router Class Initialized
INFO - 2023-03-06 06:26:57 --> Output Class Initialized
INFO - 2023-03-06 06:26:57 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:57 --> Input Class Initialized
INFO - 2023-03-06 06:26:57 --> Language Class Initialized
INFO - 2023-03-06 06:26:57 --> Loader Class Initialized
INFO - 2023-03-06 06:26:57 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:57 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:57 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:57 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:57 --> Total execution time: 0.0124
INFO - 2023-03-06 06:26:59 --> Config Class Initialized
INFO - 2023-03-06 06:26:59 --> Config Class Initialized
INFO - 2023-03-06 06:26:59 --> Hooks Class Initialized
INFO - 2023-03-06 06:26:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:26:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:59 --> URI Class Initialized
INFO - 2023-03-06 06:26:59 --> URI Class Initialized
INFO - 2023-03-06 06:26:59 --> Router Class Initialized
INFO - 2023-03-06 06:26:59 --> Router Class Initialized
INFO - 2023-03-06 06:26:59 --> Output Class Initialized
INFO - 2023-03-06 06:26:59 --> Output Class Initialized
INFO - 2023-03-06 06:26:59 --> Security Class Initialized
INFO - 2023-03-06 06:26:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:59 --> Input Class Initialized
INFO - 2023-03-06 06:26:59 --> Input Class Initialized
INFO - 2023-03-06 06:26:59 --> Language Class Initialized
INFO - 2023-03-06 06:26:59 --> Language Class Initialized
INFO - 2023-03-06 06:26:59 --> Loader Class Initialized
INFO - 2023-03-06 06:26:59 --> Loader Class Initialized
INFO - 2023-03-06 06:26:59 --> Controller Class Initialized
INFO - 2023-03-06 06:26:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:59 --> Total execution time: 0.0410
INFO - 2023-03-06 06:26:59 --> Config Class Initialized
INFO - 2023-03-06 06:26:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:59 --> URI Class Initialized
INFO - 2023-03-06 06:26:59 --> Router Class Initialized
INFO - 2023-03-06 06:26:59 --> Output Class Initialized
INFO - 2023-03-06 06:26:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:59 --> Input Class Initialized
INFO - 2023-03-06 06:26:59 --> Language Class Initialized
INFO - 2023-03-06 06:26:59 --> Loader Class Initialized
INFO - 2023-03-06 06:26:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:59 --> Total execution time: 0.0487
INFO - 2023-03-06 06:26:59 --> Config Class Initialized
INFO - 2023-03-06 06:26:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:26:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:26:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:26:59 --> URI Class Initialized
INFO - 2023-03-06 06:26:59 --> Router Class Initialized
INFO - 2023-03-06 06:26:59 --> Output Class Initialized
INFO - 2023-03-06 06:26:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:26:59 --> Input Class Initialized
INFO - 2023-03-06 06:26:59 --> Language Class Initialized
INFO - 2023-03-06 06:26:59 --> Loader Class Initialized
INFO - 2023-03-06 06:26:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:26:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:26:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:59 --> Total execution time: 0.0167
INFO - 2023-03-06 06:26:59 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:26:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:26:59 --> Total execution time: 0.0620
INFO - 2023-03-06 06:27:00 --> Config Class Initialized
INFO - 2023-03-06 06:27:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:00 --> URI Class Initialized
INFO - 2023-03-06 06:27:00 --> Router Class Initialized
INFO - 2023-03-06 06:27:00 --> Output Class Initialized
INFO - 2023-03-06 06:27:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:00 --> Input Class Initialized
INFO - 2023-03-06 06:27:00 --> Language Class Initialized
INFO - 2023-03-06 06:27:00 --> Loader Class Initialized
INFO - 2023-03-06 06:27:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:00 --> Total execution time: 0.0180
INFO - 2023-03-06 06:27:00 --> Config Class Initialized
INFO - 2023-03-06 06:27:00 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:00 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:00 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:00 --> URI Class Initialized
INFO - 2023-03-06 06:27:00 --> Router Class Initialized
INFO - 2023-03-06 06:27:00 --> Output Class Initialized
INFO - 2023-03-06 06:27:00 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:00 --> Input Class Initialized
INFO - 2023-03-06 06:27:00 --> Language Class Initialized
INFO - 2023-03-06 06:27:00 --> Loader Class Initialized
INFO - 2023-03-06 06:27:00 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:00 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:00 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:00 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:00 --> Total execution time: 0.0157
INFO - 2023-03-06 06:27:02 --> Config Class Initialized
INFO - 2023-03-06 06:27:02 --> Config Class Initialized
INFO - 2023-03-06 06:27:02 --> Hooks Class Initialized
INFO - 2023-03-06 06:27:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:27:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:02 --> URI Class Initialized
INFO - 2023-03-06 06:27:02 --> URI Class Initialized
INFO - 2023-03-06 06:27:02 --> Router Class Initialized
INFO - 2023-03-06 06:27:02 --> Router Class Initialized
INFO - 2023-03-06 06:27:02 --> Output Class Initialized
INFO - 2023-03-06 06:27:02 --> Output Class Initialized
INFO - 2023-03-06 06:27:02 --> Security Class Initialized
INFO - 2023-03-06 06:27:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:02 --> Input Class Initialized
INFO - 2023-03-06 06:27:02 --> Input Class Initialized
INFO - 2023-03-06 06:27:02 --> Language Class Initialized
INFO - 2023-03-06 06:27:02 --> Language Class Initialized
INFO - 2023-03-06 06:27:02 --> Loader Class Initialized
INFO - 2023-03-06 06:27:02 --> Loader Class Initialized
INFO - 2023-03-06 06:27:02 --> Controller Class Initialized
INFO - 2023-03-06 06:27:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:27:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:02 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:02 --> Total execution time: 0.0494
INFO - 2023-03-06 06:27:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:02 --> Total execution time: 0.0721
INFO - 2023-03-06 06:27:37 --> Config Class Initialized
INFO - 2023-03-06 06:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:37 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:37 --> URI Class Initialized
INFO - 2023-03-06 06:27:37 --> Router Class Initialized
INFO - 2023-03-06 06:27:37 --> Output Class Initialized
INFO - 2023-03-06 06:27:37 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:37 --> Input Class Initialized
INFO - 2023-03-06 06:27:37 --> Language Class Initialized
INFO - 2023-03-06 06:27:37 --> Loader Class Initialized
INFO - 2023-03-06 06:27:37 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:37 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:37 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:37 --> Total execution time: 0.0212
INFO - 2023-03-06 06:27:37 --> Config Class Initialized
INFO - 2023-03-06 06:27:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:37 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:37 --> URI Class Initialized
INFO - 2023-03-06 06:27:37 --> Router Class Initialized
INFO - 2023-03-06 06:27:37 --> Output Class Initialized
INFO - 2023-03-06 06:27:37 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:37 --> Input Class Initialized
INFO - 2023-03-06 06:27:37 --> Language Class Initialized
INFO - 2023-03-06 06:27:37 --> Loader Class Initialized
INFO - 2023-03-06 06:27:37 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:37 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:37 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:37 --> Total execution time: 0.0150
INFO - 2023-03-06 06:27:40 --> Config Class Initialized
INFO - 2023-03-06 06:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:40 --> URI Class Initialized
INFO - 2023-03-06 06:27:40 --> Router Class Initialized
INFO - 2023-03-06 06:27:40 --> Output Class Initialized
INFO - 2023-03-06 06:27:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:40 --> Input Class Initialized
INFO - 2023-03-06 06:27:40 --> Language Class Initialized
INFO - 2023-03-06 06:27:40 --> Loader Class Initialized
INFO - 2023-03-06 06:27:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:40 --> Total execution time: 0.0039
INFO - 2023-03-06 06:27:40 --> Config Class Initialized
INFO - 2023-03-06 06:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:40 --> URI Class Initialized
INFO - 2023-03-06 06:27:40 --> Router Class Initialized
INFO - 2023-03-06 06:27:40 --> Output Class Initialized
INFO - 2023-03-06 06:27:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:40 --> Input Class Initialized
INFO - 2023-03-06 06:27:40 --> Language Class Initialized
INFO - 2023-03-06 06:27:40 --> Loader Class Initialized
INFO - 2023-03-06 06:27:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:40 --> Model "Login_model" initialized
INFO - 2023-03-06 06:27:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:40 --> Total execution time: 0.0514
INFO - 2023-03-06 06:27:40 --> Config Class Initialized
INFO - 2023-03-06 06:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:40 --> URI Class Initialized
INFO - 2023-03-06 06:27:40 --> Router Class Initialized
INFO - 2023-03-06 06:27:40 --> Output Class Initialized
INFO - 2023-03-06 06:27:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:40 --> Input Class Initialized
INFO - 2023-03-06 06:27:40 --> Language Class Initialized
INFO - 2023-03-06 06:27:40 --> Loader Class Initialized
INFO - 2023-03-06 06:27:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:40 --> Total execution time: 0.0020
INFO - 2023-03-06 06:27:40 --> Config Class Initialized
INFO - 2023-03-06 06:27:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:40 --> URI Class Initialized
INFO - 2023-03-06 06:27:40 --> Router Class Initialized
INFO - 2023-03-06 06:27:40 --> Output Class Initialized
INFO - 2023-03-06 06:27:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:40 --> Input Class Initialized
INFO - 2023-03-06 06:27:40 --> Language Class Initialized
INFO - 2023-03-06 06:27:40 --> Loader Class Initialized
INFO - 2023-03-06 06:27:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:40 --> Model "Login_model" initialized
INFO - 2023-03-06 06:27:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:40 --> Total execution time: 0.0246
INFO - 2023-03-06 06:27:41 --> Config Class Initialized
INFO - 2023-03-06 06:27:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:41 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:41 --> URI Class Initialized
INFO - 2023-03-06 06:27:41 --> Router Class Initialized
INFO - 2023-03-06 06:27:41 --> Output Class Initialized
INFO - 2023-03-06 06:27:41 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:41 --> Input Class Initialized
INFO - 2023-03-06 06:27:41 --> Language Class Initialized
INFO - 2023-03-06 06:27:41 --> Loader Class Initialized
INFO - 2023-03-06 06:27:41 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:41 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:41 --> Model "Login_model" initialized
INFO - 2023-03-06 06:27:41 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:41 --> Total execution time: 0.0636
INFO - 2023-03-06 06:27:41 --> Config Class Initialized
INFO - 2023-03-06 06:27:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:41 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:41 --> URI Class Initialized
INFO - 2023-03-06 06:27:41 --> Router Class Initialized
INFO - 2023-03-06 06:27:41 --> Output Class Initialized
INFO - 2023-03-06 06:27:41 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:41 --> Input Class Initialized
INFO - 2023-03-06 06:27:41 --> Language Class Initialized
INFO - 2023-03-06 06:27:41 --> Loader Class Initialized
INFO - 2023-03-06 06:27:41 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:41 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:41 --> Model "Login_model" initialized
INFO - 2023-03-06 06:27:41 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:41 --> Total execution time: 0.0326
INFO - 2023-03-06 06:27:49 --> Config Class Initialized
INFO - 2023-03-06 06:27:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:49 --> URI Class Initialized
INFO - 2023-03-06 06:27:49 --> Router Class Initialized
INFO - 2023-03-06 06:27:49 --> Output Class Initialized
INFO - 2023-03-06 06:27:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:49 --> Input Class Initialized
INFO - 2023-03-06 06:27:49 --> Language Class Initialized
INFO - 2023-03-06 06:27:49 --> Loader Class Initialized
INFO - 2023-03-06 06:27:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:49 --> Total execution time: 0.0254
INFO - 2023-03-06 06:27:49 --> Config Class Initialized
INFO - 2023-03-06 06:27:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:49 --> URI Class Initialized
INFO - 2023-03-06 06:27:49 --> Router Class Initialized
INFO - 2023-03-06 06:27:49 --> Output Class Initialized
INFO - 2023-03-06 06:27:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:49 --> Input Class Initialized
INFO - 2023-03-06 06:27:49 --> Language Class Initialized
INFO - 2023-03-06 06:27:49 --> Loader Class Initialized
INFO - 2023-03-06 06:27:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:49 --> Total execution time: 0.0248
INFO - 2023-03-06 06:27:50 --> Config Class Initialized
INFO - 2023-03-06 06:27:50 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:50 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:50 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:50 --> URI Class Initialized
INFO - 2023-03-06 06:27:50 --> Router Class Initialized
INFO - 2023-03-06 06:27:50 --> Output Class Initialized
INFO - 2023-03-06 06:27:50 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:50 --> Input Class Initialized
INFO - 2023-03-06 06:27:50 --> Language Class Initialized
INFO - 2023-03-06 06:27:50 --> Loader Class Initialized
INFO - 2023-03-06 06:27:50 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:50 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:50 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:50 --> Total execution time: 0.0151
INFO - 2023-03-06 06:27:50 --> Config Class Initialized
INFO - 2023-03-06 06:27:50 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:50 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:50 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:50 --> URI Class Initialized
INFO - 2023-03-06 06:27:50 --> Router Class Initialized
INFO - 2023-03-06 06:27:50 --> Output Class Initialized
INFO - 2023-03-06 06:27:50 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:50 --> Input Class Initialized
INFO - 2023-03-06 06:27:50 --> Language Class Initialized
INFO - 2023-03-06 06:27:50 --> Loader Class Initialized
INFO - 2023-03-06 06:27:50 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:50 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:50 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:50 --> Total execution time: 0.0117
INFO - 2023-03-06 06:27:54 --> Config Class Initialized
INFO - 2023-03-06 06:27:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:54 --> URI Class Initialized
INFO - 2023-03-06 06:27:54 --> Router Class Initialized
INFO - 2023-03-06 06:27:54 --> Output Class Initialized
INFO - 2023-03-06 06:27:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:54 --> Input Class Initialized
INFO - 2023-03-06 06:27:54 --> Language Class Initialized
INFO - 2023-03-06 06:27:54 --> Loader Class Initialized
INFO - 2023-03-06 06:27:54 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:54 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:54 --> Total execution time: 0.0257
INFO - 2023-03-06 06:27:55 --> Config Class Initialized
INFO - 2023-03-06 06:27:55 --> Config Class Initialized
INFO - 2023-03-06 06:27:55 --> Hooks Class Initialized
INFO - 2023-03-06 06:27:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:27:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:55 --> URI Class Initialized
INFO - 2023-03-06 06:27:55 --> URI Class Initialized
INFO - 2023-03-06 06:27:55 --> Router Class Initialized
INFO - 2023-03-06 06:27:55 --> Router Class Initialized
INFO - 2023-03-06 06:27:55 --> Output Class Initialized
INFO - 2023-03-06 06:27:55 --> Output Class Initialized
INFO - 2023-03-06 06:27:55 --> Security Class Initialized
INFO - 2023-03-06 06:27:55 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:55 --> Input Class Initialized
INFO - 2023-03-06 06:27:55 --> Input Class Initialized
INFO - 2023-03-06 06:27:55 --> Language Class Initialized
INFO - 2023-03-06 06:27:55 --> Language Class Initialized
INFO - 2023-03-06 06:27:55 --> Loader Class Initialized
INFO - 2023-03-06 06:27:55 --> Loader Class Initialized
INFO - 2023-03-06 06:27:55 --> Controller Class Initialized
INFO - 2023-03-06 06:27:55 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:27:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:55 --> Total execution time: 0.0041
INFO - 2023-03-06 06:27:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:55 --> Config Class Initialized
INFO - 2023-03-06 06:27:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:55 --> URI Class Initialized
INFO - 2023-03-06 06:27:55 --> Router Class Initialized
INFO - 2023-03-06 06:27:55 --> Output Class Initialized
INFO - 2023-03-06 06:27:55 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:55 --> Input Class Initialized
INFO - 2023-03-06 06:27:55 --> Language Class Initialized
INFO - 2023-03-06 06:27:55 --> Loader Class Initialized
INFO - 2023-03-06 06:27:55 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:55 --> Model "Login_model" initialized
INFO - 2023-03-06 06:27:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:55 --> Total execution time: 0.0215
INFO - 2023-03-06 06:27:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:55 --> Config Class Initialized
INFO - 2023-03-06 06:27:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:27:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:27:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:27:55 --> URI Class Initialized
INFO - 2023-03-06 06:27:55 --> Router Class Initialized
INFO - 2023-03-06 06:27:55 --> Output Class Initialized
INFO - 2023-03-06 06:27:55 --> Security Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:27:55 --> Input Class Initialized
INFO - 2023-03-06 06:27:55 --> Language Class Initialized
INFO - 2023-03-06 06:27:55 --> Loader Class Initialized
INFO - 2023-03-06 06:27:55 --> Controller Class Initialized
DEBUG - 2023-03-06 06:27:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:27:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:27:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:27:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:55 --> Total execution time: 0.0305
INFO - 2023-03-06 06:27:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:27:55 --> Total execution time: 0.0168
INFO - 2023-03-06 06:31:19 --> Config Class Initialized
INFO - 2023-03-06 06:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:31:19 --> Utf8 Class Initialized
INFO - 2023-03-06 06:31:19 --> URI Class Initialized
INFO - 2023-03-06 06:31:19 --> Router Class Initialized
INFO - 2023-03-06 06:31:19 --> Output Class Initialized
INFO - 2023-03-06 06:31:19 --> Security Class Initialized
DEBUG - 2023-03-06 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:31:19 --> Input Class Initialized
INFO - 2023-03-06 06:31:19 --> Language Class Initialized
INFO - 2023-03-06 06:31:19 --> Loader Class Initialized
INFO - 2023-03-06 06:31:19 --> Controller Class Initialized
DEBUG - 2023-03-06 06:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:31:19 --> Final output sent to browser
DEBUG - 2023-03-06 06:31:19 --> Total execution time: 0.0042
INFO - 2023-03-06 06:31:19 --> Config Class Initialized
INFO - 2023-03-06 06:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:31:19 --> Utf8 Class Initialized
INFO - 2023-03-06 06:31:19 --> URI Class Initialized
INFO - 2023-03-06 06:31:19 --> Router Class Initialized
INFO - 2023-03-06 06:31:19 --> Output Class Initialized
INFO - 2023-03-06 06:31:19 --> Security Class Initialized
DEBUG - 2023-03-06 06:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:31:19 --> Input Class Initialized
INFO - 2023-03-06 06:31:19 --> Language Class Initialized
INFO - 2023-03-06 06:31:19 --> Loader Class Initialized
INFO - 2023-03-06 06:31:19 --> Controller Class Initialized
DEBUG - 2023-03-06 06:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:31:19 --> Database Driver Class Initialized
INFO - 2023-03-06 06:31:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:31:19 --> Final output sent to browser
DEBUG - 2023-03-06 06:31:19 --> Total execution time: 0.0536
INFO - 2023-03-06 06:31:21 --> Config Class Initialized
INFO - 2023-03-06 06:31:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:31:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:31:21 --> Utf8 Class Initialized
INFO - 2023-03-06 06:31:21 --> URI Class Initialized
INFO - 2023-03-06 06:31:21 --> Router Class Initialized
INFO - 2023-03-06 06:31:21 --> Output Class Initialized
INFO - 2023-03-06 06:31:21 --> Security Class Initialized
DEBUG - 2023-03-06 06:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:31:21 --> Input Class Initialized
INFO - 2023-03-06 06:31:21 --> Language Class Initialized
INFO - 2023-03-06 06:31:21 --> Loader Class Initialized
INFO - 2023-03-06 06:31:21 --> Controller Class Initialized
DEBUG - 2023-03-06 06:31:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:31:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:31:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:31:21 --> Final output sent to browser
DEBUG - 2023-03-06 06:31:21 --> Total execution time: 0.0168
INFO - 2023-03-06 06:31:21 --> Config Class Initialized
INFO - 2023-03-06 06:31:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:31:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:31:21 --> Utf8 Class Initialized
INFO - 2023-03-06 06:31:21 --> URI Class Initialized
INFO - 2023-03-06 06:31:21 --> Router Class Initialized
INFO - 2023-03-06 06:31:21 --> Output Class Initialized
INFO - 2023-03-06 06:31:21 --> Security Class Initialized
DEBUG - 2023-03-06 06:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:31:21 --> Input Class Initialized
INFO - 2023-03-06 06:31:21 --> Language Class Initialized
INFO - 2023-03-06 06:31:21 --> Loader Class Initialized
INFO - 2023-03-06 06:31:21 --> Controller Class Initialized
DEBUG - 2023-03-06 06:31:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:31:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:31:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:31:21 --> Final output sent to browser
DEBUG - 2023-03-06 06:31:21 --> Total execution time: 0.0140
INFO - 2023-03-06 06:33:11 --> Config Class Initialized
INFO - 2023-03-06 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:11 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:11 --> URI Class Initialized
INFO - 2023-03-06 06:33:11 --> Router Class Initialized
INFO - 2023-03-06 06:33:11 --> Output Class Initialized
INFO - 2023-03-06 06:33:11 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:11 --> Input Class Initialized
INFO - 2023-03-06 06:33:11 --> Language Class Initialized
INFO - 2023-03-06 06:33:11 --> Loader Class Initialized
INFO - 2023-03-06 06:33:11 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:11 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:11 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:11 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:11 --> Model "Login_model" initialized
INFO - 2023-03-06 06:33:11 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:11 --> Total execution time: 0.0465
INFO - 2023-03-06 06:33:11 --> Config Class Initialized
INFO - 2023-03-06 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:11 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:11 --> URI Class Initialized
INFO - 2023-03-06 06:33:11 --> Router Class Initialized
INFO - 2023-03-06 06:33:11 --> Output Class Initialized
INFO - 2023-03-06 06:33:11 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:11 --> Input Class Initialized
INFO - 2023-03-06 06:33:11 --> Language Class Initialized
INFO - 2023-03-06 06:33:11 --> Loader Class Initialized
INFO - 2023-03-06 06:33:11 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:11 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:11 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:11 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:11 --> Model "Login_model" initialized
INFO - 2023-03-06 06:33:12 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:12 --> Total execution time: 0.0343
INFO - 2023-03-06 06:33:15 --> Config Class Initialized
INFO - 2023-03-06 06:33:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:15 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:15 --> URI Class Initialized
INFO - 2023-03-06 06:33:15 --> Router Class Initialized
INFO - 2023-03-06 06:33:15 --> Output Class Initialized
INFO - 2023-03-06 06:33:15 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:15 --> Input Class Initialized
INFO - 2023-03-06 06:33:15 --> Language Class Initialized
INFO - 2023-03-06 06:33:15 --> Loader Class Initialized
INFO - 2023-03-06 06:33:15 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:15 --> Total execution time: 0.0048
INFO - 2023-03-06 06:33:15 --> Config Class Initialized
INFO - 2023-03-06 06:33:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:15 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:15 --> URI Class Initialized
INFO - 2023-03-06 06:33:15 --> Router Class Initialized
INFO - 2023-03-06 06:33:15 --> Output Class Initialized
INFO - 2023-03-06 06:33:15 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:15 --> Input Class Initialized
INFO - 2023-03-06 06:33:15 --> Language Class Initialized
INFO - 2023-03-06 06:33:15 --> Loader Class Initialized
INFO - 2023-03-06 06:33:15 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:15 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:15 --> Total execution time: 0.0128
INFO - 2023-03-06 06:33:16 --> Config Class Initialized
INFO - 2023-03-06 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:16 --> URI Class Initialized
INFO - 2023-03-06 06:33:16 --> Router Class Initialized
INFO - 2023-03-06 06:33:16 --> Output Class Initialized
INFO - 2023-03-06 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:16 --> Input Class Initialized
INFO - 2023-03-06 06:33:16 --> Language Class Initialized
INFO - 2023-03-06 06:33:16 --> Loader Class Initialized
INFO - 2023-03-06 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:16 --> Config Class Initialized
INFO - 2023-03-06 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:16 --> URI Class Initialized
INFO - 2023-03-06 06:33:16 --> Router Class Initialized
INFO - 2023-03-06 06:33:16 --> Output Class Initialized
INFO - 2023-03-06 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:16 --> Input Class Initialized
INFO - 2023-03-06 06:33:16 --> Language Class Initialized
INFO - 2023-03-06 06:33:16 --> Loader Class Initialized
INFO - 2023-03-06 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:16 --> Config Class Initialized
INFO - 2023-03-06 06:33:16 --> Config Class Initialized
INFO - 2023-03-06 06:33:16 --> Hooks Class Initialized
INFO - 2023-03-06 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:16 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:16 --> URI Class Initialized
INFO - 2023-03-06 06:33:16 --> URI Class Initialized
INFO - 2023-03-06 06:33:16 --> Router Class Initialized
INFO - 2023-03-06 06:33:16 --> Router Class Initialized
INFO - 2023-03-06 06:33:16 --> Output Class Initialized
INFO - 2023-03-06 06:33:16 --> Output Class Initialized
INFO - 2023-03-06 06:33:16 --> Security Class Initialized
INFO - 2023-03-06 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:16 --> Input Class Initialized
INFO - 2023-03-06 06:33:16 --> Input Class Initialized
INFO - 2023-03-06 06:33:16 --> Language Class Initialized
INFO - 2023-03-06 06:33:16 --> Language Class Initialized
INFO - 2023-03-06 06:33:16 --> Loader Class Initialized
INFO - 2023-03-06 06:33:16 --> Loader Class Initialized
INFO - 2023-03-06 06:33:16 --> Controller Class Initialized
INFO - 2023-03-06 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:16 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:16 --> Total execution time: 0.0174
INFO - 2023-03-06 06:33:16 --> Config Class Initialized
INFO - 2023-03-06 06:33:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:33:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:33:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:33:16 --> URI Class Initialized
INFO - 2023-03-06 06:33:16 --> Router Class Initialized
INFO - 2023-03-06 06:33:16 --> Output Class Initialized
INFO - 2023-03-06 06:33:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:33:16 --> Input Class Initialized
INFO - 2023-03-06 06:33:16 --> Language Class Initialized
INFO - 2023-03-06 06:33:16 --> Loader Class Initialized
INFO - 2023-03-06 06:33:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:33:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:33:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:33:16 --> Final output sent to browser
DEBUG - 2023-03-06 06:33:16 --> Total execution time: 0.0144
INFO - 2023-03-06 06:37:48 --> Config Class Initialized
INFO - 2023-03-06 06:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 06:37:48 --> URI Class Initialized
INFO - 2023-03-06 06:37:48 --> Router Class Initialized
INFO - 2023-03-06 06:37:48 --> Output Class Initialized
INFO - 2023-03-06 06:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:37:48 --> Input Class Initialized
INFO - 2023-03-06 06:37:48 --> Language Class Initialized
INFO - 2023-03-06 06:37:48 --> Loader Class Initialized
INFO - 2023-03-06 06:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 06:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 06:37:48 --> Total execution time: 0.0173
INFO - 2023-03-06 06:37:48 --> Config Class Initialized
INFO - 2023-03-06 06:37:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:37:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:37:48 --> Utf8 Class Initialized
INFO - 2023-03-06 06:37:48 --> URI Class Initialized
INFO - 2023-03-06 06:37:48 --> Router Class Initialized
INFO - 2023-03-06 06:37:48 --> Output Class Initialized
INFO - 2023-03-06 06:37:48 --> Security Class Initialized
DEBUG - 2023-03-06 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:37:48 --> Input Class Initialized
INFO - 2023-03-06 06:37:48 --> Language Class Initialized
INFO - 2023-03-06 06:37:48 --> Loader Class Initialized
INFO - 2023-03-06 06:37:48 --> Controller Class Initialized
DEBUG - 2023-03-06 06:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:37:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:37:48 --> Final output sent to browser
DEBUG - 2023-03-06 06:37:48 --> Total execution time: 0.0209
INFO - 2023-03-06 06:38:08 --> Config Class Initialized
INFO - 2023-03-06 06:38:08 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:08 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:08 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:08 --> URI Class Initialized
INFO - 2023-03-06 06:38:08 --> Router Class Initialized
INFO - 2023-03-06 06:38:08 --> Output Class Initialized
INFO - 2023-03-06 06:38:08 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:08 --> Input Class Initialized
INFO - 2023-03-06 06:38:08 --> Language Class Initialized
INFO - 2023-03-06 06:38:08 --> Loader Class Initialized
INFO - 2023-03-06 06:38:08 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:08 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:08 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:08 --> Total execution time: 0.0133
INFO - 2023-03-06 06:38:08 --> Config Class Initialized
INFO - 2023-03-06 06:38:08 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:08 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:08 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:08 --> URI Class Initialized
INFO - 2023-03-06 06:38:08 --> Router Class Initialized
INFO - 2023-03-06 06:38:08 --> Output Class Initialized
INFO - 2023-03-06 06:38:08 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:08 --> Input Class Initialized
INFO - 2023-03-06 06:38:08 --> Language Class Initialized
INFO - 2023-03-06 06:38:08 --> Loader Class Initialized
INFO - 2023-03-06 06:38:08 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:08 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:09 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:09 --> Total execution time: 1.0545
INFO - 2023-03-06 06:38:54 --> Config Class Initialized
INFO - 2023-03-06 06:38:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:54 --> URI Class Initialized
INFO - 2023-03-06 06:38:54 --> Router Class Initialized
INFO - 2023-03-06 06:38:54 --> Output Class Initialized
INFO - 2023-03-06 06:38:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:54 --> Input Class Initialized
INFO - 2023-03-06 06:38:54 --> Language Class Initialized
INFO - 2023-03-06 06:38:54 --> Loader Class Initialized
INFO - 2023-03-06 06:38:54 --> Controller Class Initialized
INFO - 2023-03-06 06:38:54 --> Helper loaded: form_helper
INFO - 2023-03-06 06:38:54 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:54 --> Model "Change_model" initialized
INFO - 2023-03-06 06:38:54 --> Model "Grafana_model" initialized
INFO - 2023-03-06 06:38:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:54 --> Total execution time: 0.0249
INFO - 2023-03-06 06:38:54 --> Config Class Initialized
INFO - 2023-03-06 06:38:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:54 --> URI Class Initialized
INFO - 2023-03-06 06:38:54 --> Router Class Initialized
INFO - 2023-03-06 06:38:54 --> Output Class Initialized
INFO - 2023-03-06 06:38:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:54 --> Input Class Initialized
INFO - 2023-03-06 06:38:54 --> Language Class Initialized
INFO - 2023-03-06 06:38:54 --> Loader Class Initialized
INFO - 2023-03-06 06:38:54 --> Controller Class Initialized
INFO - 2023-03-06 06:38:54 --> Helper loaded: form_helper
INFO - 2023-03-06 06:38:54 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:54 --> Total execution time: 0.0434
INFO - 2023-03-06 06:38:54 --> Config Class Initialized
INFO - 2023-03-06 06:38:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:54 --> URI Class Initialized
INFO - 2023-03-06 06:38:54 --> Router Class Initialized
INFO - 2023-03-06 06:38:54 --> Output Class Initialized
INFO - 2023-03-06 06:38:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:54 --> Input Class Initialized
INFO - 2023-03-06 06:38:54 --> Language Class Initialized
INFO - 2023-03-06 06:38:54 --> Loader Class Initialized
INFO - 2023-03-06 06:38:54 --> Controller Class Initialized
INFO - 2023-03-06 06:38:54 --> Helper loaded: form_helper
INFO - 2023-03-06 06:38:54 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:54 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:54 --> Model "Login_model" initialized
INFO - 2023-03-06 06:38:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:54 --> Total execution time: 0.0177
INFO - 2023-03-06 06:38:54 --> Config Class Initialized
INFO - 2023-03-06 06:38:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:54 --> URI Class Initialized
INFO - 2023-03-06 06:38:54 --> Router Class Initialized
INFO - 2023-03-06 06:38:54 --> Output Class Initialized
INFO - 2023-03-06 06:38:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:54 --> Input Class Initialized
INFO - 2023-03-06 06:38:54 --> Language Class Initialized
INFO - 2023-03-06 06:38:54 --> Loader Class Initialized
INFO - 2023-03-06 06:38:54 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:54 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:38:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:54 --> Total execution time: 0.0170
INFO - 2023-03-06 06:38:54 --> Config Class Initialized
INFO - 2023-03-06 06:38:54 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:54 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:54 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:54 --> URI Class Initialized
INFO - 2023-03-06 06:38:54 --> Router Class Initialized
INFO - 2023-03-06 06:38:54 --> Output Class Initialized
INFO - 2023-03-06 06:38:54 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:54 --> Input Class Initialized
INFO - 2023-03-06 06:38:54 --> Language Class Initialized
INFO - 2023-03-06 06:38:54 --> Loader Class Initialized
INFO - 2023-03-06 06:38:54 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:54 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:54 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:38:54 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:54 --> Total execution time: 0.0133
INFO - 2023-03-06 06:38:55 --> Config Class Initialized
INFO - 2023-03-06 06:38:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:55 --> URI Class Initialized
INFO - 2023-03-06 06:38:55 --> Router Class Initialized
INFO - 2023-03-06 06:38:55 --> Output Class Initialized
INFO - 2023-03-06 06:38:55 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:55 --> Input Class Initialized
INFO - 2023-03-06 06:38:55 --> Language Class Initialized
INFO - 2023-03-06 06:38:55 --> Loader Class Initialized
INFO - 2023-03-06 06:38:55 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:38:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:55 --> Model "Login_model" initialized
INFO - 2023-03-06 06:38:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:55 --> Total execution time: 0.0913
INFO - 2023-03-06 06:38:55 --> Config Class Initialized
INFO - 2023-03-06 06:38:55 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:38:55 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:38:55 --> Utf8 Class Initialized
INFO - 2023-03-06 06:38:55 --> URI Class Initialized
INFO - 2023-03-06 06:38:55 --> Router Class Initialized
INFO - 2023-03-06 06:38:55 --> Output Class Initialized
INFO - 2023-03-06 06:38:55 --> Security Class Initialized
DEBUG - 2023-03-06 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:38:55 --> Input Class Initialized
INFO - 2023-03-06 06:38:55 --> Language Class Initialized
INFO - 2023-03-06 06:38:55 --> Loader Class Initialized
INFO - 2023-03-06 06:38:55 --> Controller Class Initialized
DEBUG - 2023-03-06 06:38:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:38:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:55 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:38:55 --> Database Driver Class Initialized
INFO - 2023-03-06 06:38:55 --> Model "Login_model" initialized
INFO - 2023-03-06 06:38:55 --> Final output sent to browser
DEBUG - 2023-03-06 06:38:55 --> Total execution time: 0.2076
INFO - 2023-03-06 06:39:01 --> Config Class Initialized
INFO - 2023-03-06 06:39:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:01 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:01 --> URI Class Initialized
INFO - 2023-03-06 06:39:01 --> Router Class Initialized
INFO - 2023-03-06 06:39:01 --> Output Class Initialized
INFO - 2023-03-06 06:39:01 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:01 --> Input Class Initialized
INFO - 2023-03-06 06:39:01 --> Language Class Initialized
INFO - 2023-03-06 06:39:01 --> Loader Class Initialized
INFO - 2023-03-06 06:39:01 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:01 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:01 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:01 --> Total execution time: 0.0320
INFO - 2023-03-06 06:39:01 --> Config Class Initialized
INFO - 2023-03-06 06:39:01 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:01 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:01 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:01 --> URI Class Initialized
INFO - 2023-03-06 06:39:01 --> Router Class Initialized
INFO - 2023-03-06 06:39:01 --> Output Class Initialized
INFO - 2023-03-06 06:39:01 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:01 --> Input Class Initialized
INFO - 2023-03-06 06:39:01 --> Language Class Initialized
INFO - 2023-03-06 06:39:01 --> Loader Class Initialized
INFO - 2023-03-06 06:39:01 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:01 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:01 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:01 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:01 --> Total execution time: 0.0305
INFO - 2023-03-06 06:39:04 --> Config Class Initialized
INFO - 2023-03-06 06:39:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:04 --> URI Class Initialized
INFO - 2023-03-06 06:39:04 --> Router Class Initialized
INFO - 2023-03-06 06:39:04 --> Output Class Initialized
INFO - 2023-03-06 06:39:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:04 --> Input Class Initialized
INFO - 2023-03-06 06:39:04 --> Language Class Initialized
INFO - 2023-03-06 06:39:04 --> Loader Class Initialized
INFO - 2023-03-06 06:39:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:04 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:04 --> Total execution time: 0.0711
INFO - 2023-03-06 06:39:04 --> Config Class Initialized
INFO - 2023-03-06 06:39:04 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:04 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:04 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:04 --> URI Class Initialized
INFO - 2023-03-06 06:39:04 --> Router Class Initialized
INFO - 2023-03-06 06:39:04 --> Output Class Initialized
INFO - 2023-03-06 06:39:04 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:04 --> Input Class Initialized
INFO - 2023-03-06 06:39:04 --> Language Class Initialized
INFO - 2023-03-06 06:39:04 --> Loader Class Initialized
INFO - 2023-03-06 06:39:04 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:04 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:04 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:04 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:04 --> Total execution time: 0.0253
INFO - 2023-03-06 06:39:05 --> Config Class Initialized
INFO - 2023-03-06 06:39:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:05 --> URI Class Initialized
INFO - 2023-03-06 06:39:05 --> Router Class Initialized
INFO - 2023-03-06 06:39:05 --> Output Class Initialized
INFO - 2023-03-06 06:39:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:05 --> Input Class Initialized
INFO - 2023-03-06 06:39:05 --> Language Class Initialized
INFO - 2023-03-06 06:39:05 --> Loader Class Initialized
INFO - 2023-03-06 06:39:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:06 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:06 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:06 --> Total execution time: 0.0153
INFO - 2023-03-06 06:39:06 --> Config Class Initialized
INFO - 2023-03-06 06:39:06 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:06 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:06 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:06 --> URI Class Initialized
INFO - 2023-03-06 06:39:06 --> Router Class Initialized
INFO - 2023-03-06 06:39:06 --> Output Class Initialized
INFO - 2023-03-06 06:39:06 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:06 --> Input Class Initialized
INFO - 2023-03-06 06:39:06 --> Language Class Initialized
INFO - 2023-03-06 06:39:06 --> Loader Class Initialized
INFO - 2023-03-06 06:39:06 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:06 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:06 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:06 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:06 --> Total execution time: 0.0136
INFO - 2023-03-06 06:39:09 --> Config Class Initialized
INFO - 2023-03-06 06:39:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:09 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:09 --> URI Class Initialized
INFO - 2023-03-06 06:39:09 --> Router Class Initialized
INFO - 2023-03-06 06:39:09 --> Output Class Initialized
INFO - 2023-03-06 06:39:09 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:09 --> Input Class Initialized
INFO - 2023-03-06 06:39:09 --> Language Class Initialized
INFO - 2023-03-06 06:39:09 --> Loader Class Initialized
INFO - 2023-03-06 06:39:09 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:09 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:09 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:09 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:09 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:09 --> Total execution time: 0.0250
INFO - 2023-03-06 06:39:09 --> Config Class Initialized
INFO - 2023-03-06 06:39:09 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:09 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:09 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:09 --> URI Class Initialized
INFO - 2023-03-06 06:39:09 --> Router Class Initialized
INFO - 2023-03-06 06:39:09 --> Output Class Initialized
INFO - 2023-03-06 06:39:09 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:09 --> Input Class Initialized
INFO - 2023-03-06 06:39:09 --> Language Class Initialized
INFO - 2023-03-06 06:39:09 --> Loader Class Initialized
INFO - 2023-03-06 06:39:09 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:09 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:09 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:09 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:09 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:09 --> Total execution time: 0.0244
INFO - 2023-03-06 06:39:14 --> Config Class Initialized
INFO - 2023-03-06 06:39:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:14 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:14 --> URI Class Initialized
INFO - 2023-03-06 06:39:14 --> Router Class Initialized
INFO - 2023-03-06 06:39:14 --> Output Class Initialized
INFO - 2023-03-06 06:39:14 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:14 --> Input Class Initialized
INFO - 2023-03-06 06:39:14 --> Language Class Initialized
INFO - 2023-03-06 06:39:14 --> Loader Class Initialized
INFO - 2023-03-06 06:39:14 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:14 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:14 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:14 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:15 --> Total execution time: 0.0435
INFO - 2023-03-06 06:39:15 --> Config Class Initialized
INFO - 2023-03-06 06:39:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:15 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:15 --> URI Class Initialized
INFO - 2023-03-06 06:39:15 --> Router Class Initialized
INFO - 2023-03-06 06:39:15 --> Output Class Initialized
INFO - 2023-03-06 06:39:15 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:15 --> Input Class Initialized
INFO - 2023-03-06 06:39:15 --> Language Class Initialized
INFO - 2023-03-06 06:39:15 --> Loader Class Initialized
INFO - 2023-03-06 06:39:15 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:15 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:15 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:15 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:15 --> Total execution time: 0.0540
INFO - 2023-03-06 06:39:18 --> Config Class Initialized
INFO - 2023-03-06 06:39:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:18 --> URI Class Initialized
INFO - 2023-03-06 06:39:18 --> Router Class Initialized
INFO - 2023-03-06 06:39:18 --> Output Class Initialized
INFO - 2023-03-06 06:39:18 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:18 --> Input Class Initialized
INFO - 2023-03-06 06:39:18 --> Language Class Initialized
INFO - 2023-03-06 06:39:18 --> Loader Class Initialized
INFO - 2023-03-06 06:39:18 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:18 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:18 --> Total execution time: 0.0278
INFO - 2023-03-06 06:39:18 --> Config Class Initialized
INFO - 2023-03-06 06:39:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:18 --> URI Class Initialized
INFO - 2023-03-06 06:39:18 --> Router Class Initialized
INFO - 2023-03-06 06:39:18 --> Output Class Initialized
INFO - 2023-03-06 06:39:18 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:18 --> Input Class Initialized
INFO - 2023-03-06 06:39:18 --> Language Class Initialized
INFO - 2023-03-06 06:39:18 --> Loader Class Initialized
INFO - 2023-03-06 06:39:18 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:18 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:18 --> Total execution time: 0.0224
INFO - 2023-03-06 06:39:20 --> Config Class Initialized
INFO - 2023-03-06 06:39:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:20 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:20 --> URI Class Initialized
INFO - 2023-03-06 06:39:20 --> Router Class Initialized
INFO - 2023-03-06 06:39:20 --> Output Class Initialized
INFO - 2023-03-06 06:39:20 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:20 --> Input Class Initialized
INFO - 2023-03-06 06:39:20 --> Language Class Initialized
INFO - 2023-03-06 06:39:20 --> Loader Class Initialized
INFO - 2023-03-06 06:39:20 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:20 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:20 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:20 --> Total execution time: 0.0157
INFO - 2023-03-06 06:39:20 --> Config Class Initialized
INFO - 2023-03-06 06:39:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:20 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:20 --> URI Class Initialized
INFO - 2023-03-06 06:39:20 --> Router Class Initialized
INFO - 2023-03-06 06:39:20 --> Output Class Initialized
INFO - 2023-03-06 06:39:20 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:20 --> Input Class Initialized
INFO - 2023-03-06 06:39:20 --> Language Class Initialized
INFO - 2023-03-06 06:39:20 --> Loader Class Initialized
INFO - 2023-03-06 06:39:20 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:20 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:20 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:20 --> Total execution time: 0.0155
INFO - 2023-03-06 06:39:21 --> Config Class Initialized
INFO - 2023-03-06 06:39:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:21 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:21 --> URI Class Initialized
INFO - 2023-03-06 06:39:21 --> Router Class Initialized
INFO - 2023-03-06 06:39:21 --> Output Class Initialized
INFO - 2023-03-06 06:39:21 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:21 --> Input Class Initialized
INFO - 2023-03-06 06:39:21 --> Language Class Initialized
INFO - 2023-03-06 06:39:21 --> Loader Class Initialized
INFO - 2023-03-06 06:39:21 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:21 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:21 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:21 --> Total execution time: 0.0482
INFO - 2023-03-06 06:39:21 --> Config Class Initialized
INFO - 2023-03-06 06:39:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:21 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:21 --> URI Class Initialized
INFO - 2023-03-06 06:39:21 --> Router Class Initialized
INFO - 2023-03-06 06:39:21 --> Output Class Initialized
INFO - 2023-03-06 06:39:21 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:21 --> Input Class Initialized
INFO - 2023-03-06 06:39:21 --> Language Class Initialized
INFO - 2023-03-06 06:39:21 --> Loader Class Initialized
INFO - 2023-03-06 06:39:21 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:21 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:21 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:21 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:21 --> Total execution time: 0.0405
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
INFO - 2023-03-06 06:39:30 --> Helper loaded: form_helper
INFO - 2023-03-06 06:39:30 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Model "Change_model" initialized
INFO - 2023-03-06 06:39:30 --> Model "Grafana_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0234
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
INFO - 2023-03-06 06:39:30 --> Helper loaded: form_helper
INFO - 2023-03-06 06:39:30 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0022
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
INFO - 2023-03-06 06:39:30 --> Helper loaded: form_helper
INFO - 2023-03-06 06:39:30 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0162
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0145
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0146
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.1019
INFO - 2023-03-06 06:39:30 --> Config Class Initialized
INFO - 2023-03-06 06:39:30 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:30 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:30 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:30 --> URI Class Initialized
INFO - 2023-03-06 06:39:30 --> Router Class Initialized
INFO - 2023-03-06 06:39:30 --> Output Class Initialized
INFO - 2023-03-06 06:39:30 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:30 --> Input Class Initialized
INFO - 2023-03-06 06:39:30 --> Language Class Initialized
INFO - 2023-03-06 06:39:30 --> Loader Class Initialized
INFO - 2023-03-06 06:39:30 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:30 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:30 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:30 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:30 --> Total execution time: 0.0408
INFO - 2023-03-06 06:39:31 --> Config Class Initialized
INFO - 2023-03-06 06:39:31 --> Config Class Initialized
INFO - 2023-03-06 06:39:31 --> Hooks Class Initialized
INFO - 2023-03-06 06:39:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:39:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:32 --> URI Class Initialized
INFO - 2023-03-06 06:39:32 --> URI Class Initialized
INFO - 2023-03-06 06:39:32 --> Router Class Initialized
INFO - 2023-03-06 06:39:32 --> Router Class Initialized
INFO - 2023-03-06 06:39:32 --> Output Class Initialized
INFO - 2023-03-06 06:39:32 --> Output Class Initialized
INFO - 2023-03-06 06:39:32 --> Security Class Initialized
INFO - 2023-03-06 06:39:32 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:32 --> Input Class Initialized
INFO - 2023-03-06 06:39:32 --> Input Class Initialized
INFO - 2023-03-06 06:39:32 --> Language Class Initialized
INFO - 2023-03-06 06:39:32 --> Language Class Initialized
INFO - 2023-03-06 06:39:32 --> Loader Class Initialized
INFO - 2023-03-06 06:39:32 --> Loader Class Initialized
INFO - 2023-03-06 06:39:32 --> Controller Class Initialized
INFO - 2023-03-06 06:39:32 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:32 --> Total execution time: 0.0053
INFO - 2023-03-06 06:39:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:32 --> Config Class Initialized
INFO - 2023-03-06 06:39:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:32 --> URI Class Initialized
INFO - 2023-03-06 06:39:32 --> Router Class Initialized
INFO - 2023-03-06 06:39:32 --> Output Class Initialized
INFO - 2023-03-06 06:39:32 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:32 --> Input Class Initialized
INFO - 2023-03-06 06:39:32 --> Language Class Initialized
INFO - 2023-03-06 06:39:32 --> Loader Class Initialized
INFO - 2023-03-06 06:39:32 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:32 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:32 --> Total execution time: 0.0918
INFO - 2023-03-06 06:39:32 --> Config Class Initialized
INFO - 2023-03-06 06:39:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:32 --> URI Class Initialized
INFO - 2023-03-06 06:39:32 --> Router Class Initialized
INFO - 2023-03-06 06:39:32 --> Output Class Initialized
INFO - 2023-03-06 06:39:32 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:32 --> Input Class Initialized
INFO - 2023-03-06 06:39:32 --> Language Class Initialized
INFO - 2023-03-06 06:39:32 --> Loader Class Initialized
INFO - 2023-03-06 06:39:32 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:32 --> Total execution time: 0.1384
INFO - 2023-03-06 06:39:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:32 --> Total execution time: 0.0578
INFO - 2023-03-06 06:39:34 --> Config Class Initialized
INFO - 2023-03-06 06:39:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:34 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:34 --> URI Class Initialized
INFO - 2023-03-06 06:39:34 --> Router Class Initialized
INFO - 2023-03-06 06:39:34 --> Output Class Initialized
INFO - 2023-03-06 06:39:34 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:34 --> Input Class Initialized
INFO - 2023-03-06 06:39:34 --> Language Class Initialized
INFO - 2023-03-06 06:39:34 --> Loader Class Initialized
INFO - 2023-03-06 06:39:34 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:34 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:34 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:34 --> Total execution time: 0.0275
INFO - 2023-03-06 06:39:34 --> Config Class Initialized
INFO - 2023-03-06 06:39:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:34 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:34 --> URI Class Initialized
INFO - 2023-03-06 06:39:34 --> Router Class Initialized
INFO - 2023-03-06 06:39:34 --> Output Class Initialized
INFO - 2023-03-06 06:39:34 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:34 --> Input Class Initialized
INFO - 2023-03-06 06:39:34 --> Language Class Initialized
INFO - 2023-03-06 06:39:34 --> Loader Class Initialized
INFO - 2023-03-06 06:39:34 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:34 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:34 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:34 --> Total execution time: 0.0257
INFO - 2023-03-06 06:39:37 --> Config Class Initialized
INFO - 2023-03-06 06:39:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:37 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:37 --> URI Class Initialized
INFO - 2023-03-06 06:39:37 --> Router Class Initialized
INFO - 2023-03-06 06:39:37 --> Output Class Initialized
INFO - 2023-03-06 06:39:37 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:37 --> Input Class Initialized
INFO - 2023-03-06 06:39:37 --> Language Class Initialized
INFO - 2023-03-06 06:39:37 --> Loader Class Initialized
INFO - 2023-03-06 06:39:37 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:37 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:37 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:37 --> Total execution time: 0.0142
INFO - 2023-03-06 06:39:37 --> Config Class Initialized
INFO - 2023-03-06 06:39:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:37 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:37 --> URI Class Initialized
INFO - 2023-03-06 06:39:37 --> Router Class Initialized
INFO - 2023-03-06 06:39:37 --> Output Class Initialized
INFO - 2023-03-06 06:39:37 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:37 --> Input Class Initialized
INFO - 2023-03-06 06:39:37 --> Language Class Initialized
INFO - 2023-03-06 06:39:37 --> Loader Class Initialized
INFO - 2023-03-06 06:39:37 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:37 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:37 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:37 --> Total execution time: 0.0131
INFO - 2023-03-06 06:39:40 --> Config Class Initialized
INFO - 2023-03-06 06:39:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:40 --> URI Class Initialized
INFO - 2023-03-06 06:39:40 --> Router Class Initialized
INFO - 2023-03-06 06:39:40 --> Output Class Initialized
INFO - 2023-03-06 06:39:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:40 --> Input Class Initialized
INFO - 2023-03-06 06:39:40 --> Language Class Initialized
INFO - 2023-03-06 06:39:40 --> Loader Class Initialized
INFO - 2023-03-06 06:39:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:40 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:40 --> Total execution time: 0.0372
INFO - 2023-03-06 06:39:40 --> Config Class Initialized
INFO - 2023-03-06 06:39:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:40 --> URI Class Initialized
INFO - 2023-03-06 06:39:40 --> Router Class Initialized
INFO - 2023-03-06 06:39:40 --> Output Class Initialized
INFO - 2023-03-06 06:39:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:40 --> Input Class Initialized
INFO - 2023-03-06 06:39:40 --> Language Class Initialized
INFO - 2023-03-06 06:39:40 --> Loader Class Initialized
INFO - 2023-03-06 06:39:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:40 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:40 --> Total execution time: 0.0342
INFO - 2023-03-06 06:39:44 --> Config Class Initialized
INFO - 2023-03-06 06:39:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:44 --> URI Class Initialized
INFO - 2023-03-06 06:39:44 --> Router Class Initialized
INFO - 2023-03-06 06:39:44 --> Output Class Initialized
INFO - 2023-03-06 06:39:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:44 --> Input Class Initialized
INFO - 2023-03-06 06:39:44 --> Language Class Initialized
INFO - 2023-03-06 06:39:44 --> Loader Class Initialized
INFO - 2023-03-06 06:39:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:44 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:44 --> Total execution time: 0.0189
INFO - 2023-03-06 06:39:44 --> Config Class Initialized
INFO - 2023-03-06 06:39:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:44 --> URI Class Initialized
INFO - 2023-03-06 06:39:44 --> Router Class Initialized
INFO - 2023-03-06 06:39:44 --> Output Class Initialized
INFO - 2023-03-06 06:39:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:44 --> Input Class Initialized
INFO - 2023-03-06 06:39:44 --> Language Class Initialized
INFO - 2023-03-06 06:39:44 --> Loader Class Initialized
INFO - 2023-03-06 06:39:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:45 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:39:45 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:45 --> Total execution time: 0.0533
INFO - 2023-03-06 06:39:46 --> Config Class Initialized
INFO - 2023-03-06 06:39:46 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:46 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:46 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:46 --> URI Class Initialized
INFO - 2023-03-06 06:39:46 --> Router Class Initialized
INFO - 2023-03-06 06:39:46 --> Output Class Initialized
INFO - 2023-03-06 06:39:46 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:46 --> Input Class Initialized
INFO - 2023-03-06 06:39:46 --> Language Class Initialized
INFO - 2023-03-06 06:39:46 --> Loader Class Initialized
INFO - 2023-03-06 06:39:46 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:46 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:46 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:46 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:46 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:46 --> Total execution time: 0.0244
INFO - 2023-03-06 06:39:46 --> Config Class Initialized
INFO - 2023-03-06 06:39:46 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:46 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:46 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:46 --> URI Class Initialized
INFO - 2023-03-06 06:39:46 --> Router Class Initialized
INFO - 2023-03-06 06:39:46 --> Output Class Initialized
INFO - 2023-03-06 06:39:46 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:46 --> Input Class Initialized
INFO - 2023-03-06 06:39:46 --> Language Class Initialized
INFO - 2023-03-06 06:39:46 --> Loader Class Initialized
INFO - 2023-03-06 06:39:46 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:46 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:46 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:46 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:46 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:46 --> Total execution time: 0.0580
INFO - 2023-03-06 06:39:50 --> Config Class Initialized
INFO - 2023-03-06 06:39:50 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:50 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:50 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:50 --> URI Class Initialized
INFO - 2023-03-06 06:39:50 --> Router Class Initialized
INFO - 2023-03-06 06:39:50 --> Output Class Initialized
INFO - 2023-03-06 06:39:50 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:50 --> Input Class Initialized
INFO - 2023-03-06 06:39:50 --> Language Class Initialized
INFO - 2023-03-06 06:39:50 --> Loader Class Initialized
INFO - 2023-03-06 06:39:50 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:50 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:50 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:50 --> Total execution time: 0.0257
INFO - 2023-03-06 06:39:50 --> Config Class Initialized
INFO - 2023-03-06 06:39:50 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:50 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:50 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:50 --> URI Class Initialized
INFO - 2023-03-06 06:39:50 --> Router Class Initialized
INFO - 2023-03-06 06:39:50 --> Output Class Initialized
INFO - 2023-03-06 06:39:50 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:50 --> Input Class Initialized
INFO - 2023-03-06 06:39:50 --> Language Class Initialized
INFO - 2023-03-06 06:39:50 --> Loader Class Initialized
INFO - 2023-03-06 06:39:50 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:50 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:50 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:50 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:50 --> Total execution time: 0.0702
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
INFO - 2023-03-06 06:39:53 --> Model "Login_model" initialized
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0181
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0185
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0356
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0829
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Config Class Initialized
INFO - 2023-03-06 06:39:53 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:53 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:53 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> URI Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Router Class Initialized
INFO - 2023-03-06 06:39:53 --> Output Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Security Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Input Class Initialized
INFO - 2023-03-06 06:39:53 --> Language Class Initialized
INFO - 2023-03-06 06:39:53 --> Loader Class Initialized
INFO - 2023-03-06 06:39:53 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:53 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:53 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:53 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.1022
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
INFO - 2023-03-06 06:39:53 --> Model "Cluster_model" initialized
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0679
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.0620
INFO - 2023-03-06 06:39:53 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:53 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:53 --> Total execution time: 0.2138
INFO - 2023-03-06 06:39:59 --> Config Class Initialized
INFO - 2023-03-06 06:39:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:59 --> URI Class Initialized
INFO - 2023-03-06 06:39:59 --> Router Class Initialized
INFO - 2023-03-06 06:39:59 --> Output Class Initialized
INFO - 2023-03-06 06:39:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:59 --> Input Class Initialized
INFO - 2023-03-06 06:39:59 --> Language Class Initialized
INFO - 2023-03-06 06:39:59 --> Loader Class Initialized
INFO - 2023-03-06 06:39:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:59 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:59 --> Total execution time: 0.0266
INFO - 2023-03-06 06:39:59 --> Config Class Initialized
INFO - 2023-03-06 06:39:59 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:39:59 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:39:59 --> Utf8 Class Initialized
INFO - 2023-03-06 06:39:59 --> URI Class Initialized
INFO - 2023-03-06 06:39:59 --> Router Class Initialized
INFO - 2023-03-06 06:39:59 --> Output Class Initialized
INFO - 2023-03-06 06:39:59 --> Security Class Initialized
DEBUG - 2023-03-06 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:39:59 --> Input Class Initialized
INFO - 2023-03-06 06:39:59 --> Language Class Initialized
INFO - 2023-03-06 06:39:59 --> Loader Class Initialized
INFO - 2023-03-06 06:39:59 --> Controller Class Initialized
DEBUG - 2023-03-06 06:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:39:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:59 --> Database Driver Class Initialized
INFO - 2023-03-06 06:39:59 --> Model "Login_model" initialized
INFO - 2023-03-06 06:39:59 --> Final output sent to browser
DEBUG - 2023-03-06 06:39:59 --> Total execution time: 0.0211
INFO - 2023-03-06 06:40:02 --> Config Class Initialized
INFO - 2023-03-06 06:40:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:02 --> URI Class Initialized
INFO - 2023-03-06 06:40:02 --> Router Class Initialized
INFO - 2023-03-06 06:40:02 --> Output Class Initialized
INFO - 2023-03-06 06:40:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:02 --> Input Class Initialized
INFO - 2023-03-06 06:40:02 --> Language Class Initialized
INFO - 2023-03-06 06:40:02 --> Loader Class Initialized
INFO - 2023-03-06 06:40:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:02 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:02 --> Total execution time: 0.0641
INFO - 2023-03-06 06:40:02 --> Config Class Initialized
INFO - 2023-03-06 06:40:02 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:02 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:02 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:02 --> URI Class Initialized
INFO - 2023-03-06 06:40:02 --> Router Class Initialized
INFO - 2023-03-06 06:40:02 --> Output Class Initialized
INFO - 2023-03-06 06:40:02 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:02 --> Input Class Initialized
INFO - 2023-03-06 06:40:02 --> Language Class Initialized
INFO - 2023-03-06 06:40:02 --> Loader Class Initialized
INFO - 2023-03-06 06:40:02 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:02 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:02 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:02 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:02 --> Total execution time: 0.0627
INFO - 2023-03-06 06:40:05 --> Config Class Initialized
INFO - 2023-03-06 06:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:05 --> URI Class Initialized
INFO - 2023-03-06 06:40:05 --> Router Class Initialized
INFO - 2023-03-06 06:40:05 --> Output Class Initialized
INFO - 2023-03-06 06:40:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:05 --> Input Class Initialized
INFO - 2023-03-06 06:40:05 --> Language Class Initialized
INFO - 2023-03-06 06:40:05 --> Loader Class Initialized
INFO - 2023-03-06 06:40:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:05 --> Total execution time: 0.0119
INFO - 2023-03-06 06:40:05 --> Config Class Initialized
INFO - 2023-03-06 06:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:05 --> URI Class Initialized
INFO - 2023-03-06 06:40:05 --> Router Class Initialized
INFO - 2023-03-06 06:40:05 --> Output Class Initialized
INFO - 2023-03-06 06:40:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:05 --> Input Class Initialized
INFO - 2023-03-06 06:40:05 --> Language Class Initialized
INFO - 2023-03-06 06:40:05 --> Loader Class Initialized
INFO - 2023-03-06 06:40:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:05 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:05 --> Total execution time: 0.0251
INFO - 2023-03-06 06:40:05 --> Config Class Initialized
INFO - 2023-03-06 06:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:05 --> URI Class Initialized
INFO - 2023-03-06 06:40:05 --> Router Class Initialized
INFO - 2023-03-06 06:40:05 --> Output Class Initialized
INFO - 2023-03-06 06:40:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:05 --> Input Class Initialized
INFO - 2023-03-06 06:40:05 --> Language Class Initialized
INFO - 2023-03-06 06:40:05 --> Loader Class Initialized
INFO - 2023-03-06 06:40:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:05 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:05 --> Total execution time: 0.0207
INFO - 2023-03-06 06:40:05 --> Config Class Initialized
INFO - 2023-03-06 06:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:05 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:05 --> URI Class Initialized
INFO - 2023-03-06 06:40:05 --> Router Class Initialized
INFO - 2023-03-06 06:40:05 --> Output Class Initialized
INFO - 2023-03-06 06:40:05 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:05 --> Input Class Initialized
INFO - 2023-03-06 06:40:05 --> Language Class Initialized
INFO - 2023-03-06 06:40:05 --> Loader Class Initialized
INFO - 2023-03-06 06:40:05 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:05 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:05 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:05 --> Total execution time: 0.0225
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
INFO - 2023-03-06 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-06 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Model "Change_model" initialized
INFO - 2023-03-06 06:40:13 --> Model "Grafana_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0441
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
INFO - 2023-03-06 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-06 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0019
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
INFO - 2023-03-06 06:40:13 --> Helper loaded: form_helper
INFO - 2023-03-06 06:40:13 --> Helper loaded: url_helper
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0132
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0119
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0113
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0875
INFO - 2023-03-06 06:40:13 --> Config Class Initialized
INFO - 2023-03-06 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:13 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:13 --> URI Class Initialized
INFO - 2023-03-06 06:40:13 --> Router Class Initialized
INFO - 2023-03-06 06:40:13 --> Output Class Initialized
INFO - 2023-03-06 06:40:13 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:13 --> Input Class Initialized
INFO - 2023-03-06 06:40:13 --> Language Class Initialized
INFO - 2023-03-06 06:40:13 --> Loader Class Initialized
INFO - 2023-03-06 06:40:13 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:13 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:13 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:13 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:13 --> Total execution time: 0.0335
INFO - 2023-03-06 06:40:18 --> Config Class Initialized
INFO - 2023-03-06 06:40:18 --> Config Class Initialized
INFO - 2023-03-06 06:40:18 --> Hooks Class Initialized
INFO - 2023-03-06 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:18 --> URI Class Initialized
INFO - 2023-03-06 06:40:18 --> URI Class Initialized
INFO - 2023-03-06 06:40:18 --> Router Class Initialized
INFO - 2023-03-06 06:40:18 --> Output Class Initialized
INFO - 2023-03-06 06:40:18 --> Router Class Initialized
INFO - 2023-03-06 06:40:18 --> Security Class Initialized
INFO - 2023-03-06 06:40:18 --> Output Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:18 --> Security Class Initialized
INFO - 2023-03-06 06:40:18 --> Input Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:18 --> Language Class Initialized
INFO - 2023-03-06 06:40:18 --> Input Class Initialized
INFO - 2023-03-06 06:40:18 --> Language Class Initialized
INFO - 2023-03-06 06:40:18 --> Loader Class Initialized
INFO - 2023-03-06 06:40:18 --> Loader Class Initialized
INFO - 2023-03-06 06:40:18 --> Controller Class Initialized
INFO - 2023-03-06 06:40:18 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:18 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:18 --> Total execution time: 0.0188
INFO - 2023-03-06 06:40:18 --> Config Class Initialized
INFO - 2023-03-06 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:18 --> URI Class Initialized
INFO - 2023-03-06 06:40:18 --> Router Class Initialized
INFO - 2023-03-06 06:40:18 --> Output Class Initialized
INFO - 2023-03-06 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:18 --> Input Class Initialized
INFO - 2023-03-06 06:40:18 --> Language Class Initialized
INFO - 2023-03-06 06:40:18 --> Loader Class Initialized
INFO - 2023-03-06 06:40:18 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:18 --> Final output sent to browser
INFO - 2023-03-06 06:40:18 --> Config Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Total execution time: 0.0526
INFO - 2023-03-06 06:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:18 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:18 --> URI Class Initialized
INFO - 2023-03-06 06:40:18 --> Router Class Initialized
INFO - 2023-03-06 06:40:18 --> Output Class Initialized
INFO - 2023-03-06 06:40:18 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:18 --> Input Class Initialized
INFO - 2023-03-06 06:40:18 --> Language Class Initialized
INFO - 2023-03-06 06:40:18 --> Loader Class Initialized
INFO - 2023-03-06 06:40:18 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:18 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:19 --> Config Class Initialized
INFO - 2023-03-06 06:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:19 --> URI Class Initialized
INFO - 2023-03-06 06:40:19 --> Router Class Initialized
INFO - 2023-03-06 06:40:19 --> Output Class Initialized
INFO - 2023-03-06 06:40:19 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:19 --> Input Class Initialized
INFO - 2023-03-06 06:40:19 --> Language Class Initialized
INFO - 2023-03-06 06:40:19 --> Loader Class Initialized
INFO - 2023-03-06 06:40:19 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:19 --> Config Class Initialized
INFO - 2023-03-06 06:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:19 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:19 --> URI Class Initialized
INFO - 2023-03-06 06:40:19 --> Router Class Initialized
INFO - 2023-03-06 06:40:19 --> Output Class Initialized
INFO - 2023-03-06 06:40:19 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:19 --> Input Class Initialized
INFO - 2023-03-06 06:40:19 --> Language Class Initialized
INFO - 2023-03-06 06:40:19 --> Loader Class Initialized
INFO - 2023-03-06 06:40:19 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:19 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:26 --> Config Class Initialized
INFO - 2023-03-06 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:26 --> URI Class Initialized
INFO - 2023-03-06 06:40:26 --> Router Class Initialized
INFO - 2023-03-06 06:40:26 --> Output Class Initialized
INFO - 2023-03-06 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:26 --> Input Class Initialized
INFO - 2023-03-06 06:40:26 --> Language Class Initialized
INFO - 2023-03-06 06:40:26 --> Loader Class Initialized
INFO - 2023-03-06 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:26 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:26 --> Config Class Initialized
INFO - 2023-03-06 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:26 --> URI Class Initialized
INFO - 2023-03-06 06:40:26 --> Router Class Initialized
INFO - 2023-03-06 06:40:26 --> Output Class Initialized
INFO - 2023-03-06 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:26 --> Input Class Initialized
INFO - 2023-03-06 06:40:26 --> Language Class Initialized
INFO - 2023-03-06 06:40:26 --> Loader Class Initialized
INFO - 2023-03-06 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:26 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:31 --> Config Class Initialized
INFO - 2023-03-06 06:40:31 --> Hooks Class Initialized
INFO - 2023-03-06 06:40:31 --> Config Class Initialized
INFO - 2023-03-06 06:40:31 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:40:31 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:31 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:31 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:31 --> URI Class Initialized
INFO - 2023-03-06 06:40:31 --> URI Class Initialized
INFO - 2023-03-06 06:40:31 --> Router Class Initialized
INFO - 2023-03-06 06:40:31 --> Router Class Initialized
INFO - 2023-03-06 06:40:31 --> Output Class Initialized
INFO - 2023-03-06 06:40:31 --> Output Class Initialized
INFO - 2023-03-06 06:40:31 --> Security Class Initialized
INFO - 2023-03-06 06:40:31 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:31 --> Input Class Initialized
INFO - 2023-03-06 06:40:31 --> Input Class Initialized
INFO - 2023-03-06 06:40:31 --> Language Class Initialized
INFO - 2023-03-06 06:40:31 --> Language Class Initialized
INFO - 2023-03-06 06:40:31 --> Loader Class Initialized
INFO - 2023-03-06 06:40:31 --> Loader Class Initialized
INFO - 2023-03-06 06:40:31 --> Controller Class Initialized
INFO - 2023-03-06 06:40:31 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:31 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:31 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:31 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:31 --> Total execution time: 0.0164
INFO - 2023-03-06 06:40:31 --> Config Class Initialized
INFO - 2023-03-06 06:40:31 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:31 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:31 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:31 --> URI Class Initialized
INFO - 2023-03-06 06:40:31 --> Router Class Initialized
INFO - 2023-03-06 06:40:31 --> Output Class Initialized
INFO - 2023-03-06 06:40:31 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:31 --> Input Class Initialized
INFO - 2023-03-06 06:40:31 --> Language Class Initialized
INFO - 2023-03-06 06:40:31 --> Loader Class Initialized
INFO - 2023-03-06 06:40:31 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:31 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:31 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:31 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:31 --> Total execution time: 0.0116
INFO - 2023-03-06 06:40:39 --> Config Class Initialized
INFO - 2023-03-06 06:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:39 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:39 --> URI Class Initialized
INFO - 2023-03-06 06:40:39 --> Router Class Initialized
INFO - 2023-03-06 06:40:39 --> Output Class Initialized
INFO - 2023-03-06 06:40:39 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:39 --> Input Class Initialized
INFO - 2023-03-06 06:40:39 --> Language Class Initialized
INFO - 2023-03-06 06:40:39 --> Loader Class Initialized
INFO - 2023-03-06 06:40:39 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:39 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:39 --> Config Class Initialized
INFO - 2023-03-06 06:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:39 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:39 --> URI Class Initialized
INFO - 2023-03-06 06:40:39 --> Router Class Initialized
INFO - 2023-03-06 06:40:39 --> Output Class Initialized
INFO - 2023-03-06 06:40:39 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:39 --> Input Class Initialized
INFO - 2023-03-06 06:40:39 --> Language Class Initialized
INFO - 2023-03-06 06:40:39 --> Loader Class Initialized
INFO - 2023-03-06 06:40:39 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:39 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:44 --> Config Class Initialized
INFO - 2023-03-06 06:40:44 --> Config Class Initialized
INFO - 2023-03-06 06:40:44 --> Hooks Class Initialized
INFO - 2023-03-06 06:40:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 06:40:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:44 --> URI Class Initialized
INFO - 2023-03-06 06:40:44 --> URI Class Initialized
INFO - 2023-03-06 06:40:44 --> Router Class Initialized
INFO - 2023-03-06 06:40:44 --> Router Class Initialized
INFO - 2023-03-06 06:40:44 --> Output Class Initialized
INFO - 2023-03-06 06:40:44 --> Output Class Initialized
INFO - 2023-03-06 06:40:44 --> Security Class Initialized
INFO - 2023-03-06 06:40:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:44 --> Input Class Initialized
INFO - 2023-03-06 06:40:44 --> Input Class Initialized
INFO - 2023-03-06 06:40:44 --> Language Class Initialized
INFO - 2023-03-06 06:40:44 --> Language Class Initialized
INFO - 2023-03-06 06:40:44 --> Loader Class Initialized
INFO - 2023-03-06 06:40:44 --> Loader Class Initialized
INFO - 2023-03-06 06:40:44 --> Controller Class Initialized
INFO - 2023-03-06 06:40:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 06:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:44 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:44 --> Total execution time: 0.0182
INFO - 2023-03-06 06:40:44 --> Config Class Initialized
INFO - 2023-03-06 06:40:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:44 --> URI Class Initialized
INFO - 2023-03-06 06:40:44 --> Router Class Initialized
INFO - 2023-03-06 06:40:44 --> Output Class Initialized
INFO - 2023-03-06 06:40:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:44 --> Input Class Initialized
INFO - 2023-03-06 06:40:44 --> Language Class Initialized
INFO - 2023-03-06 06:40:44 --> Loader Class Initialized
INFO - 2023-03-06 06:40:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:44 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:44 --> Total execution time: 0.0153
INFO - 2023-03-06 06:40:44 --> Config Class Initialized
INFO - 2023-03-06 06:40:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:44 --> URI Class Initialized
INFO - 2023-03-06 06:40:44 --> Router Class Initialized
INFO - 2023-03-06 06:40:44 --> Output Class Initialized
INFO - 2023-03-06 06:40:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:44 --> Input Class Initialized
INFO - 2023-03-06 06:40:44 --> Language Class Initialized
INFO - 2023-03-06 06:40:44 --> Loader Class Initialized
INFO - 2023-03-06 06:40:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:48 --> Config Class Initialized
INFO - 2023-03-06 06:40:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:48 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:48 --> URI Class Initialized
INFO - 2023-03-06 06:40:48 --> Router Class Initialized
INFO - 2023-03-06 06:40:48 --> Output Class Initialized
INFO - 2023-03-06 06:40:48 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:48 --> Input Class Initialized
INFO - 2023-03-06 06:40:48 --> Language Class Initialized
INFO - 2023-03-06 06:40:48 --> Loader Class Initialized
INFO - 2023-03-06 06:40:48 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:48 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:48 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:48 --> Total execution time: 0.0459
INFO - 2023-03-06 06:40:48 --> Config Class Initialized
INFO - 2023-03-06 06:40:48 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:48 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:48 --> URI Class Initialized
INFO - 2023-03-06 06:40:48 --> Router Class Initialized
INFO - 2023-03-06 06:40:48 --> Output Class Initialized
INFO - 2023-03-06 06:40:48 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:48 --> Input Class Initialized
INFO - 2023-03-06 06:40:48 --> Language Class Initialized
INFO - 2023-03-06 06:40:48 --> Loader Class Initialized
INFO - 2023-03-06 06:40:48 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:48 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:48 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:48 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:48 --> Total execution time: 0.0421
INFO - 2023-03-06 06:40:49 --> Config Class Initialized
INFO - 2023-03-06 06:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:49 --> URI Class Initialized
INFO - 2023-03-06 06:40:49 --> Router Class Initialized
INFO - 2023-03-06 06:40:49 --> Output Class Initialized
INFO - 2023-03-06 06:40:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:49 --> Input Class Initialized
INFO - 2023-03-06 06:40:49 --> Language Class Initialized
INFO - 2023-03-06 06:40:49 --> Loader Class Initialized
INFO - 2023-03-06 06:40:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:49 --> Total execution time: 0.0277
INFO - 2023-03-06 06:40:49 --> Config Class Initialized
INFO - 2023-03-06 06:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:49 --> URI Class Initialized
INFO - 2023-03-06 06:40:49 --> Router Class Initialized
INFO - 2023-03-06 06:40:49 --> Output Class Initialized
INFO - 2023-03-06 06:40:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:49 --> Input Class Initialized
INFO - 2023-03-06 06:40:49 --> Language Class Initialized
INFO - 2023-03-06 06:40:49 --> Loader Class Initialized
INFO - 2023-03-06 06:40:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:49 --> Total execution time: 0.0249
INFO - 2023-03-06 06:40:49 --> Config Class Initialized
INFO - 2023-03-06 06:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:49 --> URI Class Initialized
INFO - 2023-03-06 06:40:49 --> Router Class Initialized
INFO - 2023-03-06 06:40:49 --> Output Class Initialized
INFO - 2023-03-06 06:40:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:49 --> Input Class Initialized
INFO - 2023-03-06 06:40:49 --> Language Class Initialized
INFO - 2023-03-06 06:40:49 --> Loader Class Initialized
INFO - 2023-03-06 06:40:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:49 --> Total execution time: 0.0190
INFO - 2023-03-06 06:40:49 --> Config Class Initialized
INFO - 2023-03-06 06:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:49 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:49 --> URI Class Initialized
INFO - 2023-03-06 06:40:49 --> Router Class Initialized
INFO - 2023-03-06 06:40:49 --> Output Class Initialized
INFO - 2023-03-06 06:40:49 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:49 --> Input Class Initialized
INFO - 2023-03-06 06:40:49 --> Language Class Initialized
INFO - 2023-03-06 06:40:49 --> Loader Class Initialized
INFO - 2023-03-06 06:40:49 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:49 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:49 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:40:49 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:49 --> Total execution time: 0.0111
INFO - 2023-03-06 06:40:52 --> Config Class Initialized
INFO - 2023-03-06 06:40:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:52 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:52 --> URI Class Initialized
INFO - 2023-03-06 06:40:52 --> Router Class Initialized
INFO - 2023-03-06 06:40:52 --> Output Class Initialized
INFO - 2023-03-06 06:40:52 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:52 --> Input Class Initialized
INFO - 2023-03-06 06:40:52 --> Language Class Initialized
INFO - 2023-03-06 06:40:52 --> Loader Class Initialized
INFO - 2023-03-06 06:40:52 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:52 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:52 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:52 --> Total execution time: 0.1117
INFO - 2023-03-06 06:40:52 --> Config Class Initialized
INFO - 2023-03-06 06:40:52 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:40:52 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:40:52 --> Utf8 Class Initialized
INFO - 2023-03-06 06:40:52 --> URI Class Initialized
INFO - 2023-03-06 06:40:52 --> Router Class Initialized
INFO - 2023-03-06 06:40:52 --> Output Class Initialized
INFO - 2023-03-06 06:40:52 --> Security Class Initialized
DEBUG - 2023-03-06 06:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:40:52 --> Input Class Initialized
INFO - 2023-03-06 06:40:52 --> Language Class Initialized
INFO - 2023-03-06 06:40:52 --> Loader Class Initialized
INFO - 2023-03-06 06:40:52 --> Controller Class Initialized
DEBUG - 2023-03-06 06:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:40:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:52 --> Database Driver Class Initialized
INFO - 2023-03-06 06:40:52 --> Model "Login_model" initialized
INFO - 2023-03-06 06:40:52 --> Final output sent to browser
DEBUG - 2023-03-06 06:40:52 --> Total execution time: 0.0249
INFO - 2023-03-06 06:41:15 --> Config Class Initialized
INFO - 2023-03-06 06:41:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:15 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:15 --> URI Class Initialized
INFO - 2023-03-06 06:41:15 --> Router Class Initialized
INFO - 2023-03-06 06:41:15 --> Output Class Initialized
INFO - 2023-03-06 06:41:15 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:15 --> Input Class Initialized
INFO - 2023-03-06 06:41:15 --> Language Class Initialized
INFO - 2023-03-06 06:41:15 --> Loader Class Initialized
INFO - 2023-03-06 06:41:15 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:15 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:15 --> Total execution time: 0.0177
INFO - 2023-03-06 06:41:15 --> Config Class Initialized
INFO - 2023-03-06 06:41:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:15 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:15 --> URI Class Initialized
INFO - 2023-03-06 06:41:15 --> Router Class Initialized
INFO - 2023-03-06 06:41:15 --> Output Class Initialized
INFO - 2023-03-06 06:41:15 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:15 --> Input Class Initialized
INFO - 2023-03-06 06:41:15 --> Language Class Initialized
INFO - 2023-03-06 06:41:15 --> Loader Class Initialized
INFO - 2023-03-06 06:41:15 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:15 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:15 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:15 --> Total execution time: 0.0220
INFO - 2023-03-06 06:41:16 --> Config Class Initialized
INFO - 2023-03-06 06:41:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:16 --> URI Class Initialized
INFO - 2023-03-06 06:41:16 --> Router Class Initialized
INFO - 2023-03-06 06:41:16 --> Output Class Initialized
INFO - 2023-03-06 06:41:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:16 --> Input Class Initialized
INFO - 2023-03-06 06:41:16 --> Language Class Initialized
INFO - 2023-03-06 06:41:16 --> Loader Class Initialized
INFO - 2023-03-06 06:41:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:16 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:16 --> Total execution time: 0.0267
INFO - 2023-03-06 06:41:16 --> Config Class Initialized
INFO - 2023-03-06 06:41:16 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:16 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:16 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:16 --> URI Class Initialized
INFO - 2023-03-06 06:41:16 --> Router Class Initialized
INFO - 2023-03-06 06:41:16 --> Output Class Initialized
INFO - 2023-03-06 06:41:16 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:16 --> Input Class Initialized
INFO - 2023-03-06 06:41:16 --> Language Class Initialized
INFO - 2023-03-06 06:41:16 --> Loader Class Initialized
INFO - 2023-03-06 06:41:16 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:16 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:16 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:16 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:16 --> Total execution time: 0.0256
INFO - 2023-03-06 06:41:17 --> Config Class Initialized
INFO - 2023-03-06 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:17 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:17 --> URI Class Initialized
INFO - 2023-03-06 06:41:17 --> Router Class Initialized
INFO - 2023-03-06 06:41:17 --> Output Class Initialized
INFO - 2023-03-06 06:41:17 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:17 --> Input Class Initialized
INFO - 2023-03-06 06:41:17 --> Language Class Initialized
INFO - 2023-03-06 06:41:17 --> Loader Class Initialized
INFO - 2023-03-06 06:41:17 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:17 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:17 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:17 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:17 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:17 --> Total execution time: 0.0355
INFO - 2023-03-06 06:41:17 --> Config Class Initialized
INFO - 2023-03-06 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:17 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:17 --> URI Class Initialized
INFO - 2023-03-06 06:41:17 --> Router Class Initialized
INFO - 2023-03-06 06:41:17 --> Output Class Initialized
INFO - 2023-03-06 06:41:17 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:17 --> Input Class Initialized
INFO - 2023-03-06 06:41:17 --> Language Class Initialized
INFO - 2023-03-06 06:41:17 --> Loader Class Initialized
INFO - 2023-03-06 06:41:17 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:17 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:17 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:17 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:17 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:17 --> Total execution time: 0.0360
INFO - 2023-03-06 06:41:19 --> Config Class Initialized
INFO - 2023-03-06 06:41:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:19 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:19 --> URI Class Initialized
INFO - 2023-03-06 06:41:19 --> Router Class Initialized
INFO - 2023-03-06 06:41:19 --> Output Class Initialized
INFO - 2023-03-06 06:41:19 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:19 --> Input Class Initialized
INFO - 2023-03-06 06:41:19 --> Language Class Initialized
INFO - 2023-03-06 06:41:19 --> Loader Class Initialized
INFO - 2023-03-06 06:41:19 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:19 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:19 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:19 --> Total execution time: 0.0355
INFO - 2023-03-06 06:41:20 --> Config Class Initialized
INFO - 2023-03-06 06:41:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:20 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:20 --> URI Class Initialized
INFO - 2023-03-06 06:41:20 --> Router Class Initialized
INFO - 2023-03-06 06:41:20 --> Output Class Initialized
INFO - 2023-03-06 06:41:20 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:20 --> Input Class Initialized
INFO - 2023-03-06 06:41:20 --> Language Class Initialized
INFO - 2023-03-06 06:41:20 --> Loader Class Initialized
INFO - 2023-03-06 06:41:20 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:20 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:20 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:20 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:20 --> Total execution time: 0.0437
INFO - 2023-03-06 06:41:23 --> Config Class Initialized
INFO - 2023-03-06 06:41:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:23 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:23 --> URI Class Initialized
INFO - 2023-03-06 06:41:23 --> Router Class Initialized
INFO - 2023-03-06 06:41:23 --> Output Class Initialized
INFO - 2023-03-06 06:41:23 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:23 --> Input Class Initialized
INFO - 2023-03-06 06:41:23 --> Language Class Initialized
INFO - 2023-03-06 06:41:23 --> Loader Class Initialized
INFO - 2023-03-06 06:41:23 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:23 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:23 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:23 --> Total execution time: 0.0178
INFO - 2023-03-06 06:41:23 --> Config Class Initialized
INFO - 2023-03-06 06:41:23 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:23 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:23 --> URI Class Initialized
INFO - 2023-03-06 06:41:23 --> Router Class Initialized
INFO - 2023-03-06 06:41:23 --> Output Class Initialized
INFO - 2023-03-06 06:41:23 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:23 --> Input Class Initialized
INFO - 2023-03-06 06:41:23 --> Language Class Initialized
INFO - 2023-03-06 06:41:23 --> Loader Class Initialized
INFO - 2023-03-06 06:41:23 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:23 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:23 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:23 --> Total execution time: 0.0618
INFO - 2023-03-06 06:41:24 --> Config Class Initialized
INFO - 2023-03-06 06:41:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:24 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:24 --> URI Class Initialized
INFO - 2023-03-06 06:41:24 --> Router Class Initialized
INFO - 2023-03-06 06:41:24 --> Output Class Initialized
INFO - 2023-03-06 06:41:24 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:24 --> Input Class Initialized
INFO - 2023-03-06 06:41:24 --> Language Class Initialized
INFO - 2023-03-06 06:41:24 --> Loader Class Initialized
INFO - 2023-03-06 06:41:24 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:24 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:24 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:24 --> Total execution time: 0.0161
INFO - 2023-03-06 06:41:24 --> Config Class Initialized
INFO - 2023-03-06 06:41:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:24 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:24 --> URI Class Initialized
INFO - 2023-03-06 06:41:24 --> Router Class Initialized
INFO - 2023-03-06 06:41:24 --> Output Class Initialized
INFO - 2023-03-06 06:41:24 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:24 --> Input Class Initialized
INFO - 2023-03-06 06:41:24 --> Language Class Initialized
INFO - 2023-03-06 06:41:24 --> Loader Class Initialized
INFO - 2023-03-06 06:41:24 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:24 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:24 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:24 --> Total execution time: 0.0254
INFO - 2023-03-06 06:41:24 --> Config Class Initialized
INFO - 2023-03-06 06:41:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:24 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:24 --> URI Class Initialized
INFO - 2023-03-06 06:41:24 --> Router Class Initialized
INFO - 2023-03-06 06:41:24 --> Output Class Initialized
INFO - 2023-03-06 06:41:24 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:24 --> Input Class Initialized
INFO - 2023-03-06 06:41:24 --> Language Class Initialized
INFO - 2023-03-06 06:41:24 --> Loader Class Initialized
INFO - 2023-03-06 06:41:24 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:24 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:25 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:25 --> Total execution time: 0.0304
INFO - 2023-03-06 06:41:25 --> Config Class Initialized
INFO - 2023-03-06 06:41:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:25 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:25 --> URI Class Initialized
INFO - 2023-03-06 06:41:25 --> Router Class Initialized
INFO - 2023-03-06 06:41:25 --> Output Class Initialized
INFO - 2023-03-06 06:41:25 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:25 --> Input Class Initialized
INFO - 2023-03-06 06:41:25 --> Language Class Initialized
INFO - 2023-03-06 06:41:25 --> Loader Class Initialized
INFO - 2023-03-06 06:41:25 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:25 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:25 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:25 --> Total execution time: 0.0245
INFO - 2023-03-06 06:41:28 --> Config Class Initialized
INFO - 2023-03-06 06:41:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:28 --> URI Class Initialized
INFO - 2023-03-06 06:41:28 --> Router Class Initialized
INFO - 2023-03-06 06:41:28 --> Output Class Initialized
INFO - 2023-03-06 06:41:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:28 --> Input Class Initialized
INFO - 2023-03-06 06:41:28 --> Language Class Initialized
INFO - 2023-03-06 06:41:28 --> Loader Class Initialized
INFO - 2023-03-06 06:41:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:28 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:28 --> Total execution time: 0.0311
INFO - 2023-03-06 06:41:28 --> Config Class Initialized
INFO - 2023-03-06 06:41:28 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:28 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:28 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:28 --> URI Class Initialized
INFO - 2023-03-06 06:41:28 --> Router Class Initialized
INFO - 2023-03-06 06:41:28 --> Output Class Initialized
INFO - 2023-03-06 06:41:28 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:28 --> Input Class Initialized
INFO - 2023-03-06 06:41:28 --> Language Class Initialized
INFO - 2023-03-06 06:41:28 --> Loader Class Initialized
INFO - 2023-03-06 06:41:28 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:28 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:28 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:28 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:28 --> Total execution time: 0.0222
INFO - 2023-03-06 06:41:32 --> Config Class Initialized
INFO - 2023-03-06 06:41:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:32 --> URI Class Initialized
INFO - 2023-03-06 06:41:32 --> Router Class Initialized
INFO - 2023-03-06 06:41:32 --> Output Class Initialized
INFO - 2023-03-06 06:41:32 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:32 --> Input Class Initialized
INFO - 2023-03-06 06:41:32 --> Language Class Initialized
INFO - 2023-03-06 06:41:32 --> Loader Class Initialized
INFO - 2023-03-06 06:41:32 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:32 --> Total execution time: 0.0202
INFO - 2023-03-06 06:41:32 --> Config Class Initialized
INFO - 2023-03-06 06:41:32 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:32 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:32 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:32 --> URI Class Initialized
INFO - 2023-03-06 06:41:32 --> Router Class Initialized
INFO - 2023-03-06 06:41:32 --> Output Class Initialized
INFO - 2023-03-06 06:41:32 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:32 --> Input Class Initialized
INFO - 2023-03-06 06:41:32 --> Language Class Initialized
INFO - 2023-03-06 06:41:32 --> Loader Class Initialized
INFO - 2023-03-06 06:41:32 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:32 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:32 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:32 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:32 --> Total execution time: 0.0152
INFO - 2023-03-06 06:41:33 --> Config Class Initialized
INFO - 2023-03-06 06:41:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:33 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:33 --> URI Class Initialized
INFO - 2023-03-06 06:41:33 --> Router Class Initialized
INFO - 2023-03-06 06:41:33 --> Output Class Initialized
INFO - 2023-03-06 06:41:33 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:33 --> Input Class Initialized
INFO - 2023-03-06 06:41:33 --> Language Class Initialized
INFO - 2023-03-06 06:41:33 --> Loader Class Initialized
INFO - 2023-03-06 06:41:33 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:33 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:33 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:33 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:33 --> Total execution time: 0.0389
INFO - 2023-03-06 06:41:33 --> Config Class Initialized
INFO - 2023-03-06 06:41:33 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:33 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:33 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:33 --> URI Class Initialized
INFO - 2023-03-06 06:41:33 --> Router Class Initialized
INFO - 2023-03-06 06:41:33 --> Output Class Initialized
INFO - 2023-03-06 06:41:33 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:33 --> Input Class Initialized
INFO - 2023-03-06 06:41:33 --> Language Class Initialized
INFO - 2023-03-06 06:41:33 --> Loader Class Initialized
INFO - 2023-03-06 06:41:33 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:33 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:33 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:33 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:33 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:33 --> Total execution time: 0.0368
INFO - 2023-03-06 06:41:39 --> Config Class Initialized
INFO - 2023-03-06 06:41:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:39 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:39 --> URI Class Initialized
INFO - 2023-03-06 06:41:39 --> Router Class Initialized
INFO - 2023-03-06 06:41:39 --> Output Class Initialized
INFO - 2023-03-06 06:41:39 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:39 --> Input Class Initialized
INFO - 2023-03-06 06:41:39 --> Language Class Initialized
INFO - 2023-03-06 06:41:39 --> Loader Class Initialized
INFO - 2023-03-06 06:41:39 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:39 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:39 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:39 --> Total execution time: 0.0323
INFO - 2023-03-06 06:41:39 --> Config Class Initialized
INFO - 2023-03-06 06:41:39 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:39 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:39 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:39 --> URI Class Initialized
INFO - 2023-03-06 06:41:39 --> Router Class Initialized
INFO - 2023-03-06 06:41:39 --> Output Class Initialized
INFO - 2023-03-06 06:41:39 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:39 --> Input Class Initialized
INFO - 2023-03-06 06:41:39 --> Language Class Initialized
INFO - 2023-03-06 06:41:39 --> Loader Class Initialized
INFO - 2023-03-06 06:41:39 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:39 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:39 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:39 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:39 --> Total execution time: 0.0263
INFO - 2023-03-06 06:41:40 --> Config Class Initialized
INFO - 2023-03-06 06:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:40 --> URI Class Initialized
INFO - 2023-03-06 06:41:40 --> Router Class Initialized
INFO - 2023-03-06 06:41:40 --> Output Class Initialized
INFO - 2023-03-06 06:41:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:40 --> Input Class Initialized
INFO - 2023-03-06 06:41:40 --> Language Class Initialized
INFO - 2023-03-06 06:41:40 --> Loader Class Initialized
INFO - 2023-03-06 06:41:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:40 --> Total execution time: 0.0131
INFO - 2023-03-06 06:41:40 --> Config Class Initialized
INFO - 2023-03-06 06:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:40 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:40 --> URI Class Initialized
INFO - 2023-03-06 06:41:40 --> Router Class Initialized
INFO - 2023-03-06 06:41:40 --> Output Class Initialized
INFO - 2023-03-06 06:41:40 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:40 --> Input Class Initialized
INFO - 2023-03-06 06:41:40 --> Language Class Initialized
INFO - 2023-03-06 06:41:40 --> Loader Class Initialized
INFO - 2023-03-06 06:41:40 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:40 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:40 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:40 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:40 --> Total execution time: 0.0109
INFO - 2023-03-06 06:41:41 --> Config Class Initialized
INFO - 2023-03-06 06:41:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:41 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:41 --> URI Class Initialized
INFO - 2023-03-06 06:41:41 --> Router Class Initialized
INFO - 2023-03-06 06:41:41 --> Output Class Initialized
INFO - 2023-03-06 06:41:41 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:41 --> Input Class Initialized
INFO - 2023-03-06 06:41:41 --> Language Class Initialized
INFO - 2023-03-06 06:41:41 --> Loader Class Initialized
INFO - 2023-03-06 06:41:41 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:41 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:41 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:41 --> Total execution time: 0.0968
INFO - 2023-03-06 06:41:41 --> Config Class Initialized
INFO - 2023-03-06 06:41:41 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:41 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:41 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:41 --> URI Class Initialized
INFO - 2023-03-06 06:41:41 --> Router Class Initialized
INFO - 2023-03-06 06:41:41 --> Output Class Initialized
INFO - 2023-03-06 06:41:41 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:41 --> Input Class Initialized
INFO - 2023-03-06 06:41:41 --> Language Class Initialized
INFO - 2023-03-06 06:41:41 --> Loader Class Initialized
INFO - 2023-03-06 06:41:41 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:41 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:41 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:41 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:41 --> Total execution time: 0.0411
INFO - 2023-03-06 06:41:43 --> Config Class Initialized
INFO - 2023-03-06 06:41:43 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:43 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:43 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:43 --> URI Class Initialized
INFO - 2023-03-06 06:41:43 --> Router Class Initialized
INFO - 2023-03-06 06:41:43 --> Output Class Initialized
INFO - 2023-03-06 06:41:43 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:43 --> Input Class Initialized
INFO - 2023-03-06 06:41:43 --> Language Class Initialized
INFO - 2023-03-06 06:41:43 --> Loader Class Initialized
INFO - 2023-03-06 06:41:43 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:43 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:43 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:43 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:43 --> Total execution time: 0.0175
INFO - 2023-03-06 06:41:43 --> Config Class Initialized
INFO - 2023-03-06 06:41:43 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:43 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:43 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:43 --> URI Class Initialized
INFO - 2023-03-06 06:41:43 --> Router Class Initialized
INFO - 2023-03-06 06:41:43 --> Output Class Initialized
INFO - 2023-03-06 06:41:43 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:43 --> Input Class Initialized
INFO - 2023-03-06 06:41:43 --> Language Class Initialized
INFO - 2023-03-06 06:41:43 --> Loader Class Initialized
INFO - 2023-03-06 06:41:43 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:43 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:43 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:43 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:43 --> Total execution time: 0.0258
INFO - 2023-03-06 06:41:44 --> Config Class Initialized
INFO - 2023-03-06 06:41:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:44 --> URI Class Initialized
INFO - 2023-03-06 06:41:44 --> Router Class Initialized
INFO - 2023-03-06 06:41:44 --> Output Class Initialized
INFO - 2023-03-06 06:41:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:44 --> Input Class Initialized
INFO - 2023-03-06 06:41:44 --> Language Class Initialized
INFO - 2023-03-06 06:41:44 --> Loader Class Initialized
INFO - 2023-03-06 06:41:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:44 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:44 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:44 --> Total execution time: 0.0420
INFO - 2023-03-06 06:41:44 --> Config Class Initialized
INFO - 2023-03-06 06:41:44 --> Hooks Class Initialized
DEBUG - 2023-03-06 06:41:44 --> UTF-8 Support Enabled
INFO - 2023-03-06 06:41:44 --> Utf8 Class Initialized
INFO - 2023-03-06 06:41:44 --> URI Class Initialized
INFO - 2023-03-06 06:41:44 --> Router Class Initialized
INFO - 2023-03-06 06:41:44 --> Output Class Initialized
INFO - 2023-03-06 06:41:44 --> Security Class Initialized
DEBUG - 2023-03-06 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 06:41:44 --> Input Class Initialized
INFO - 2023-03-06 06:41:44 --> Language Class Initialized
INFO - 2023-03-06 06:41:44 --> Loader Class Initialized
INFO - 2023-03-06 06:41:44 --> Controller Class Initialized
DEBUG - 2023-03-06 06:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 06:41:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:44 --> Model "Cluster_model" initialized
INFO - 2023-03-06 06:41:44 --> Database Driver Class Initialized
INFO - 2023-03-06 06:41:44 --> Model "Login_model" initialized
INFO - 2023-03-06 06:41:44 --> Final output sent to browser
DEBUG - 2023-03-06 06:41:44 --> Total execution time: 0.0337
INFO - 2023-03-06 07:08:18 --> Config Class Initialized
INFO - 2023-03-06 07:08:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:18 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:18 --> URI Class Initialized
INFO - 2023-03-06 07:08:18 --> Router Class Initialized
INFO - 2023-03-06 07:08:18 --> Output Class Initialized
INFO - 2023-03-06 07:08:18 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:18 --> Input Class Initialized
INFO - 2023-03-06 07:08:18 --> Language Class Initialized
INFO - 2023-03-06 07:08:18 --> Loader Class Initialized
INFO - 2023-03-06 07:08:18 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:18 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:18 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:18 --> Total execution time: 0.0221
INFO - 2023-03-06 07:08:18 --> Config Class Initialized
INFO - 2023-03-06 07:08:18 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:18 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:18 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:18 --> URI Class Initialized
INFO - 2023-03-06 07:08:18 --> Router Class Initialized
INFO - 2023-03-06 07:08:18 --> Output Class Initialized
INFO - 2023-03-06 07:08:18 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:18 --> Input Class Initialized
INFO - 2023-03-06 07:08:18 --> Language Class Initialized
INFO - 2023-03-06 07:08:18 --> Loader Class Initialized
INFO - 2023-03-06 07:08:18 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:18 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:18 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:18 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:18 --> Total execution time: 0.0641
INFO - 2023-03-06 07:08:19 --> Config Class Initialized
INFO - 2023-03-06 07:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:19 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:19 --> URI Class Initialized
INFO - 2023-03-06 07:08:19 --> Router Class Initialized
INFO - 2023-03-06 07:08:19 --> Output Class Initialized
INFO - 2023-03-06 07:08:19 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:19 --> Input Class Initialized
INFO - 2023-03-06 07:08:19 --> Language Class Initialized
INFO - 2023-03-06 07:08:19 --> Loader Class Initialized
INFO - 2023-03-06 07:08:19 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:19 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:19 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:19 --> Total execution time: 0.0179
INFO - 2023-03-06 07:08:19 --> Config Class Initialized
INFO - 2023-03-06 07:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:19 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:19 --> URI Class Initialized
INFO - 2023-03-06 07:08:19 --> Router Class Initialized
INFO - 2023-03-06 07:08:19 --> Output Class Initialized
INFO - 2023-03-06 07:08:19 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:19 --> Input Class Initialized
INFO - 2023-03-06 07:08:19 --> Language Class Initialized
INFO - 2023-03-06 07:08:19 --> Loader Class Initialized
INFO - 2023-03-06 07:08:19 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:19 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:19 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:19 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:19 --> Total execution time: 0.0512
INFO - 2023-03-06 07:08:20 --> Config Class Initialized
INFO - 2023-03-06 07:08:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:20 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:20 --> URI Class Initialized
INFO - 2023-03-06 07:08:20 --> Router Class Initialized
INFO - 2023-03-06 07:08:20 --> Output Class Initialized
INFO - 2023-03-06 07:08:20 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:20 --> Input Class Initialized
INFO - 2023-03-06 07:08:20 --> Language Class Initialized
INFO - 2023-03-06 07:08:20 --> Loader Class Initialized
INFO - 2023-03-06 07:08:20 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:20 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:20 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:20 --> Total execution time: 0.0651
INFO - 2023-03-06 07:08:20 --> Config Class Initialized
INFO - 2023-03-06 07:08:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:20 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:20 --> URI Class Initialized
INFO - 2023-03-06 07:08:20 --> Router Class Initialized
INFO - 2023-03-06 07:08:20 --> Output Class Initialized
INFO - 2023-03-06 07:08:20 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:20 --> Input Class Initialized
INFO - 2023-03-06 07:08:20 --> Language Class Initialized
INFO - 2023-03-06 07:08:20 --> Loader Class Initialized
INFO - 2023-03-06 07:08:20 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:20 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:21 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:21 --> Model "Login_model" initialized
INFO - 2023-03-06 07:08:21 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:21 --> Total execution time: 0.1690
INFO - 2023-03-06 07:08:21 --> Config Class Initialized
INFO - 2023-03-06 07:08:21 --> Hooks Class Initialized
DEBUG - 2023-03-06 07:08:21 --> UTF-8 Support Enabled
INFO - 2023-03-06 07:08:21 --> Utf8 Class Initialized
INFO - 2023-03-06 07:08:21 --> URI Class Initialized
INFO - 2023-03-06 07:08:21 --> Router Class Initialized
INFO - 2023-03-06 07:08:21 --> Output Class Initialized
INFO - 2023-03-06 07:08:21 --> Security Class Initialized
DEBUG - 2023-03-06 07:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 07:08:21 --> Input Class Initialized
INFO - 2023-03-06 07:08:21 --> Language Class Initialized
INFO - 2023-03-06 07:08:21 --> Loader Class Initialized
INFO - 2023-03-06 07:08:21 --> Controller Class Initialized
DEBUG - 2023-03-06 07:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 07:08:21 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:21 --> Model "Cluster_model" initialized
INFO - 2023-03-06 07:08:21 --> Database Driver Class Initialized
INFO - 2023-03-06 07:08:21 --> Model "Login_model" initialized
INFO - 2023-03-06 07:08:21 --> Final output sent to browser
DEBUG - 2023-03-06 07:08:21 --> Total execution time: 0.0381
INFO - 2023-03-06 09:04:03 --> Config Class Initialized
INFO - 2023-03-06 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:03 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:03 --> URI Class Initialized
INFO - 2023-03-06 09:04:03 --> Router Class Initialized
INFO - 2023-03-06 09:04:03 --> Output Class Initialized
INFO - 2023-03-06 09:04:03 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:03 --> Input Class Initialized
INFO - 2023-03-06 09:04:03 --> Language Class Initialized
INFO - 2023-03-06 09:04:03 --> Loader Class Initialized
INFO - 2023-03-06 09:04:03 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:03 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:03 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:03 --> Total execution time: 0.0200
INFO - 2023-03-06 09:04:03 --> Config Class Initialized
INFO - 2023-03-06 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:03 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:03 --> URI Class Initialized
INFO - 2023-03-06 09:04:03 --> Router Class Initialized
INFO - 2023-03-06 09:04:03 --> Output Class Initialized
INFO - 2023-03-06 09:04:03 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:03 --> Input Class Initialized
INFO - 2023-03-06 09:04:03 --> Language Class Initialized
INFO - 2023-03-06 09:04:03 --> Loader Class Initialized
INFO - 2023-03-06 09:04:03 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:03 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:03 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:03 --> Total execution time: 0.0613
INFO - 2023-03-06 09:04:06 --> Config Class Initialized
INFO - 2023-03-06 09:04:06 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:06 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:06 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:06 --> URI Class Initialized
INFO - 2023-03-06 09:04:06 --> Router Class Initialized
INFO - 2023-03-06 09:04:06 --> Output Class Initialized
INFO - 2023-03-06 09:04:06 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:06 --> Input Class Initialized
INFO - 2023-03-06 09:04:06 --> Language Class Initialized
INFO - 2023-03-06 09:04:06 --> Loader Class Initialized
INFO - 2023-03-06 09:04:06 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:06 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:06 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:06 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:06 --> Total execution time: 0.0305
INFO - 2023-03-06 09:04:06 --> Config Class Initialized
INFO - 2023-03-06 09:04:06 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:06 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:06 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:06 --> URI Class Initialized
INFO - 2023-03-06 09:04:06 --> Router Class Initialized
INFO - 2023-03-06 09:04:06 --> Output Class Initialized
INFO - 2023-03-06 09:04:06 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:06 --> Input Class Initialized
INFO - 2023-03-06 09:04:06 --> Language Class Initialized
INFO - 2023-03-06 09:04:06 --> Loader Class Initialized
INFO - 2023-03-06 09:04:06 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:06 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:06 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:06 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:06 --> Total execution time: 0.0690
INFO - 2023-03-06 09:04:10 --> Config Class Initialized
INFO - 2023-03-06 09:04:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:10 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:10 --> URI Class Initialized
INFO - 2023-03-06 09:04:10 --> Router Class Initialized
INFO - 2023-03-06 09:04:10 --> Output Class Initialized
INFO - 2023-03-06 09:04:10 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:10 --> Input Class Initialized
INFO - 2023-03-06 09:04:10 --> Language Class Initialized
INFO - 2023-03-06 09:04:10 --> Loader Class Initialized
INFO - 2023-03-06 09:04:10 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:10 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:10 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:10 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:10 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:10 --> Total execution time: 0.0422
INFO - 2023-03-06 09:04:10 --> Config Class Initialized
INFO - 2023-03-06 09:04:10 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:10 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:10 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:10 --> URI Class Initialized
INFO - 2023-03-06 09:04:10 --> Router Class Initialized
INFO - 2023-03-06 09:04:10 --> Output Class Initialized
INFO - 2023-03-06 09:04:10 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:10 --> Input Class Initialized
INFO - 2023-03-06 09:04:10 --> Language Class Initialized
INFO - 2023-03-06 09:04:10 --> Loader Class Initialized
INFO - 2023-03-06 09:04:10 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:10 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:10 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:10 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:10 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:10 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:10 --> Total execution time: 0.0340
INFO - 2023-03-06 09:04:14 --> Config Class Initialized
INFO - 2023-03-06 09:04:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:14 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:14 --> URI Class Initialized
INFO - 2023-03-06 09:04:14 --> Router Class Initialized
INFO - 2023-03-06 09:04:14 --> Output Class Initialized
INFO - 2023-03-06 09:04:14 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:14 --> Input Class Initialized
INFO - 2023-03-06 09:04:14 --> Language Class Initialized
INFO - 2023-03-06 09:04:14 --> Loader Class Initialized
INFO - 2023-03-06 09:04:14 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:14 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:14 --> Config Class Initialized
INFO - 2023-03-06 09:04:14 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:14 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:14 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:14 --> URI Class Initialized
INFO - 2023-03-06 09:04:14 --> Router Class Initialized
INFO - 2023-03-06 09:04:14 --> Output Class Initialized
INFO - 2023-03-06 09:04:14 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:14 --> Input Class Initialized
INFO - 2023-03-06 09:04:14 --> Language Class Initialized
INFO - 2023-03-06 09:04:14 --> Loader Class Initialized
INFO - 2023-03-06 09:04:14 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:14 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:14 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:15 --> Config Class Initialized
INFO - 2023-03-06 09:04:15 --> Hooks Class Initialized
INFO - 2023-03-06 09:04:15 --> Config Class Initialized
INFO - 2023-03-06 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:15 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:15 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:15 --> URI Class Initialized
INFO - 2023-03-06 09:04:15 --> URI Class Initialized
INFO - 2023-03-06 09:04:15 --> Router Class Initialized
INFO - 2023-03-06 09:04:15 --> Router Class Initialized
INFO - 2023-03-06 09:04:15 --> Output Class Initialized
INFO - 2023-03-06 09:04:15 --> Output Class Initialized
INFO - 2023-03-06 09:04:15 --> Security Class Initialized
INFO - 2023-03-06 09:04:15 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:15 --> Input Class Initialized
INFO - 2023-03-06 09:04:15 --> Language Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:15 --> Input Class Initialized
INFO - 2023-03-06 09:04:15 --> Loader Class Initialized
INFO - 2023-03-06 09:04:15 --> Language Class Initialized
INFO - 2023-03-06 09:04:15 --> Controller Class Initialized
INFO - 2023-03-06 09:04:15 --> Loader Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:15 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:15 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:15 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:15 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:15 --> Total execution time: 0.0264
INFO - 2023-03-06 09:04:15 --> Config Class Initialized
INFO - 2023-03-06 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:15 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:15 --> URI Class Initialized
INFO - 2023-03-06 09:04:15 --> Router Class Initialized
INFO - 2023-03-06 09:04:15 --> Output Class Initialized
INFO - 2023-03-06 09:04:15 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:15 --> Input Class Initialized
INFO - 2023-03-06 09:04:15 --> Language Class Initialized
INFO - 2023-03-06 09:04:15 --> Loader Class Initialized
INFO - 2023-03-06 09:04:15 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:15 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:15 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:15 --> Total execution time: 0.0139
INFO - 2023-03-06 09:04:20 --> Config Class Initialized
INFO - 2023-03-06 09:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:20 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:20 --> URI Class Initialized
INFO - 2023-03-06 09:04:20 --> Router Class Initialized
INFO - 2023-03-06 09:04:20 --> Output Class Initialized
INFO - 2023-03-06 09:04:20 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:20 --> Input Class Initialized
INFO - 2023-03-06 09:04:20 --> Language Class Initialized
INFO - 2023-03-06 09:04:20 --> Loader Class Initialized
INFO - 2023-03-06 09:04:20 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:20 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:20 --> Config Class Initialized
INFO - 2023-03-06 09:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:20 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:20 --> URI Class Initialized
INFO - 2023-03-06 09:04:20 --> Router Class Initialized
INFO - 2023-03-06 09:04:20 --> Output Class Initialized
INFO - 2023-03-06 09:04:20 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:20 --> Input Class Initialized
INFO - 2023-03-06 09:04:20 --> Language Class Initialized
INFO - 2023-03-06 09:04:20 --> Loader Class Initialized
INFO - 2023-03-06 09:04:20 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:20 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:20 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:24 --> Config Class Initialized
INFO - 2023-03-06 09:04:24 --> Config Class Initialized
INFO - 2023-03-06 09:04:24 --> Hooks Class Initialized
INFO - 2023-03-06 09:04:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-06 09:04:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:24 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:24 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:24 --> URI Class Initialized
INFO - 2023-03-06 09:04:24 --> URI Class Initialized
INFO - 2023-03-06 09:04:24 --> Router Class Initialized
INFO - 2023-03-06 09:04:24 --> Router Class Initialized
INFO - 2023-03-06 09:04:24 --> Output Class Initialized
INFO - 2023-03-06 09:04:24 --> Output Class Initialized
INFO - 2023-03-06 09:04:24 --> Security Class Initialized
INFO - 2023-03-06 09:04:24 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-06 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:24 --> Input Class Initialized
INFO - 2023-03-06 09:04:24 --> Input Class Initialized
INFO - 2023-03-06 09:04:24 --> Language Class Initialized
INFO - 2023-03-06 09:04:24 --> Language Class Initialized
INFO - 2023-03-06 09:04:24 --> Loader Class Initialized
INFO - 2023-03-06 09:04:24 --> Loader Class Initialized
INFO - 2023-03-06 09:04:24 --> Controller Class Initialized
INFO - 2023-03-06 09:04:24 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-06 09:04:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:24 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:24 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:24 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:24 --> Total execution time: 0.0206
INFO - 2023-03-06 09:04:24 --> Config Class Initialized
INFO - 2023-03-06 09:04:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:24 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:24 --> URI Class Initialized
INFO - 2023-03-06 09:04:24 --> Router Class Initialized
INFO - 2023-03-06 09:04:24 --> Output Class Initialized
INFO - 2023-03-06 09:04:24 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:24 --> Input Class Initialized
INFO - 2023-03-06 09:04:24 --> Language Class Initialized
INFO - 2023-03-06 09:04:24 --> Loader Class Initialized
INFO - 2023-03-06 09:04:24 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:24 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:24 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:24 --> Total execution time: 0.0152
INFO - 2023-03-06 09:04:24 --> Config Class Initialized
INFO - 2023-03-06 09:04:24 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:24 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:24 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:24 --> URI Class Initialized
INFO - 2023-03-06 09:04:24 --> Router Class Initialized
INFO - 2023-03-06 09:04:24 --> Output Class Initialized
INFO - 2023-03-06 09:04:24 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:24 --> Input Class Initialized
INFO - 2023-03-06 09:04:24 --> Language Class Initialized
INFO - 2023-03-06 09:04:24 --> Loader Class Initialized
INFO - 2023-03-06 09:04:24 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:24 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:24 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:25 --> Config Class Initialized
INFO - 2023-03-06 09:04:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:25 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:25 --> URI Class Initialized
INFO - 2023-03-06 09:04:25 --> Router Class Initialized
INFO - 2023-03-06 09:04:25 --> Output Class Initialized
INFO - 2023-03-06 09:04:25 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:25 --> Input Class Initialized
INFO - 2023-03-06 09:04:25 --> Language Class Initialized
INFO - 2023-03-06 09:04:25 --> Loader Class Initialized
INFO - 2023-03-06 09:04:25 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:25 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:25 --> Config Class Initialized
INFO - 2023-03-06 09:04:25 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:25 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:25 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:25 --> URI Class Initialized
INFO - 2023-03-06 09:04:25 --> Router Class Initialized
INFO - 2023-03-06 09:04:25 --> Output Class Initialized
INFO - 2023-03-06 09:04:25 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:25 --> Input Class Initialized
INFO - 2023-03-06 09:04:25 --> Language Class Initialized
INFO - 2023-03-06 09:04:25 --> Loader Class Initialized
INFO - 2023-03-06 09:04:25 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:25 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:25 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:34 --> Config Class Initialized
INFO - 2023-03-06 09:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:34 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:34 --> URI Class Initialized
INFO - 2023-03-06 09:04:34 --> Router Class Initialized
INFO - 2023-03-06 09:04:34 --> Output Class Initialized
INFO - 2023-03-06 09:04:34 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:34 --> Input Class Initialized
INFO - 2023-03-06 09:04:34 --> Language Class Initialized
INFO - 2023-03-06 09:04:34 --> Loader Class Initialized
INFO - 2023-03-06 09:04:34 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:34 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:34 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:34 --> Total execution time: 0.0165
INFO - 2023-03-06 09:04:34 --> Config Class Initialized
INFO - 2023-03-06 09:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:34 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:34 --> URI Class Initialized
INFO - 2023-03-06 09:04:34 --> Router Class Initialized
INFO - 2023-03-06 09:04:34 --> Output Class Initialized
INFO - 2023-03-06 09:04:34 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:34 --> Input Class Initialized
INFO - 2023-03-06 09:04:34 --> Language Class Initialized
INFO - 2023-03-06 09:04:34 --> Loader Class Initialized
INFO - 2023-03-06 09:04:34 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:34 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:34 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:34 --> Total execution time: 0.0141
INFO - 2023-03-06 09:04:35 --> Config Class Initialized
INFO - 2023-03-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:35 --> URI Class Initialized
INFO - 2023-03-06 09:04:35 --> Router Class Initialized
INFO - 2023-03-06 09:04:35 --> Output Class Initialized
INFO - 2023-03-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:35 --> Input Class Initialized
INFO - 2023-03-06 09:04:35 --> Language Class Initialized
INFO - 2023-03-06 09:04:35 --> Loader Class Initialized
INFO - 2023-03-06 09:04:35 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:35 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:35 --> Total execution time: 0.0037
INFO - 2023-03-06 09:04:35 --> Config Class Initialized
INFO - 2023-03-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:35 --> URI Class Initialized
INFO - 2023-03-06 09:04:35 --> Router Class Initialized
INFO - 2023-03-06 09:04:35 --> Output Class Initialized
INFO - 2023-03-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:35 --> Input Class Initialized
INFO - 2023-03-06 09:04:35 --> Language Class Initialized
INFO - 2023-03-06 09:04:35 --> Loader Class Initialized
INFO - 2023-03-06 09:04:35 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:35 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:35 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:35 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:35 --> Total execution time: 0.0286
INFO - 2023-03-06 09:04:35 --> Config Class Initialized
INFO - 2023-03-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:35 --> URI Class Initialized
INFO - 2023-03-06 09:04:35 --> Router Class Initialized
INFO - 2023-03-06 09:04:35 --> Output Class Initialized
INFO - 2023-03-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:35 --> Input Class Initialized
INFO - 2023-03-06 09:04:35 --> Language Class Initialized
INFO - 2023-03-06 09:04:35 --> Loader Class Initialized
INFO - 2023-03-06 09:04:35 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:35 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:35 --> Total execution time: 0.0828
INFO - 2023-03-06 09:04:35 --> Config Class Initialized
INFO - 2023-03-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:35 --> URI Class Initialized
INFO - 2023-03-06 09:04:35 --> Router Class Initialized
INFO - 2023-03-06 09:04:35 --> Output Class Initialized
INFO - 2023-03-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:35 --> Input Class Initialized
INFO - 2023-03-06 09:04:35 --> Language Class Initialized
INFO - 2023-03-06 09:04:35 --> Loader Class Initialized
INFO - 2023-03-06 09:04:35 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:35 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:35 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:35 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:35 --> Total execution time: 0.0250
INFO - 2023-03-06 09:04:37 --> Config Class Initialized
INFO - 2023-03-06 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:37 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:37 --> URI Class Initialized
INFO - 2023-03-06 09:04:37 --> Router Class Initialized
INFO - 2023-03-06 09:04:37 --> Output Class Initialized
INFO - 2023-03-06 09:04:37 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:37 --> Input Class Initialized
INFO - 2023-03-06 09:04:37 --> Language Class Initialized
INFO - 2023-03-06 09:04:37 --> Loader Class Initialized
INFO - 2023-03-06 09:04:37 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:37 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:37 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:37 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:37 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:37 --> Total execution time: 0.0708
INFO - 2023-03-06 09:04:37 --> Config Class Initialized
INFO - 2023-03-06 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-03-06 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-03-06 09:04:37 --> Utf8 Class Initialized
INFO - 2023-03-06 09:04:37 --> URI Class Initialized
INFO - 2023-03-06 09:04:37 --> Router Class Initialized
INFO - 2023-03-06 09:04:37 --> Output Class Initialized
INFO - 2023-03-06 09:04:37 --> Security Class Initialized
DEBUG - 2023-03-06 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-06 09:04:37 --> Input Class Initialized
INFO - 2023-03-06 09:04:37 --> Language Class Initialized
INFO - 2023-03-06 09:04:37 --> Loader Class Initialized
INFO - 2023-03-06 09:04:37 --> Controller Class Initialized
DEBUG - 2023-03-06 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-06 09:04:37 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-03-06 09:04:37 --> Database Driver Class Initialized
INFO - 2023-03-06 09:04:37 --> Model "Login_model" initialized
INFO - 2023-03-06 09:04:37 --> Final output sent to browser
DEBUG - 2023-03-06 09:04:37 --> Total execution time: 0.0409
