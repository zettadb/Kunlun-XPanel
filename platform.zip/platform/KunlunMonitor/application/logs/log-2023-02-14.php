<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-14 02:20:48 --> Config Class Initialized
INFO - 2023-02-14 02:20:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:48 --> URI Class Initialized
INFO - 2023-02-14 02:20:48 --> Router Class Initialized
INFO - 2023-02-14 02:20:48 --> Output Class Initialized
INFO - 2023-02-14 02:20:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:48 --> Input Class Initialized
INFO - 2023-02-14 02:20:48 --> Language Class Initialized
INFO - 2023-02-14 02:20:48 --> Loader Class Initialized
INFO - 2023-02-14 02:20:48 --> Controller Class Initialized
INFO - 2023-02-14 02:20:48 --> Helper loaded: form_helper
INFO - 2023-02-14 02:20:48 --> Helper loaded: url_helper
DEBUG - 2023-02-14 02:20:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:48 --> Model "Change_model" initialized
INFO - 2023-02-14 02:20:48 --> Model "Grafana_model" initialized
INFO - 2023-02-14 02:20:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:48 --> Total execution time: 0.1128
INFO - 2023-02-14 02:20:48 --> Config Class Initialized
INFO - 2023-02-14 02:20:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:48 --> URI Class Initialized
INFO - 2023-02-14 02:20:48 --> Router Class Initialized
INFO - 2023-02-14 02:20:48 --> Output Class Initialized
INFO - 2023-02-14 02:20:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:48 --> Input Class Initialized
INFO - 2023-02-14 02:20:48 --> Language Class Initialized
INFO - 2023-02-14 02:20:48 --> Loader Class Initialized
INFO - 2023-02-14 02:20:48 --> Controller Class Initialized
INFO - 2023-02-14 02:20:48 --> Helper loaded: form_helper
INFO - 2023-02-14 02:20:48 --> Helper loaded: url_helper
DEBUG - 2023-02-14 02:20:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:48 --> Total execution time: 0.0445
INFO - 2023-02-14 02:20:48 --> Config Class Initialized
INFO - 2023-02-14 02:20:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:48 --> URI Class Initialized
INFO - 2023-02-14 02:20:48 --> Router Class Initialized
INFO - 2023-02-14 02:20:48 --> Output Class Initialized
INFO - 2023-02-14 02:20:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:48 --> Input Class Initialized
INFO - 2023-02-14 02:20:48 --> Language Class Initialized
INFO - 2023-02-14 02:20:48 --> Loader Class Initialized
INFO - 2023-02-14 02:20:48 --> Controller Class Initialized
INFO - 2023-02-14 02:20:48 --> Helper loaded: form_helper
INFO - 2023-02-14 02:20:48 --> Helper loaded: url_helper
DEBUG - 2023-02-14 02:20:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:20:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:49 --> Total execution time: 0.0323
INFO - 2023-02-14 02:20:49 --> Config Class Initialized
INFO - 2023-02-14 02:20:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:49 --> URI Class Initialized
INFO - 2023-02-14 02:20:49 --> Router Class Initialized
INFO - 2023-02-14 02:20:49 --> Output Class Initialized
INFO - 2023-02-14 02:20:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:49 --> Input Class Initialized
INFO - 2023-02-14 02:20:49 --> Language Class Initialized
INFO - 2023-02-14 02:20:49 --> Loader Class Initialized
INFO - 2023-02-14 02:20:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:49 --> Total execution time: 0.0419
INFO - 2023-02-14 02:20:49 --> Config Class Initialized
INFO - 2023-02-14 02:20:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:49 --> URI Class Initialized
INFO - 2023-02-14 02:20:49 --> Router Class Initialized
INFO - 2023-02-14 02:20:49 --> Output Class Initialized
INFO - 2023-02-14 02:20:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:49 --> Input Class Initialized
INFO - 2023-02-14 02:20:49 --> Language Class Initialized
INFO - 2023-02-14 02:20:49 --> Loader Class Initialized
INFO - 2023-02-14 02:20:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:49 --> Total execution time: 0.0126
INFO - 2023-02-14 02:20:49 --> Config Class Initialized
INFO - 2023-02-14 02:20:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:49 --> URI Class Initialized
INFO - 2023-02-14 02:20:49 --> Router Class Initialized
INFO - 2023-02-14 02:20:49 --> Output Class Initialized
INFO - 2023-02-14 02:20:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:49 --> Input Class Initialized
INFO - 2023-02-14 02:20:49 --> Language Class Initialized
INFO - 2023-02-14 02:20:49 --> Loader Class Initialized
INFO - 2023-02-14 02:20:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Login_model" initialized
INFO - 2023-02-14 02:20:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:49 --> Total execution time: 0.0797
INFO - 2023-02-14 02:20:49 --> Config Class Initialized
INFO - 2023-02-14 02:20:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:49 --> URI Class Initialized
INFO - 2023-02-14 02:20:49 --> Router Class Initialized
INFO - 2023-02-14 02:20:49 --> Output Class Initialized
INFO - 2023-02-14 02:20:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:49 --> Input Class Initialized
INFO - 2023-02-14 02:20:49 --> Language Class Initialized
INFO - 2023-02-14 02:20:49 --> Loader Class Initialized
INFO - 2023-02-14 02:20:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:49 --> Model "Login_model" initialized
INFO - 2023-02-14 02:20:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:49 --> Total execution time: 0.0380
INFO - 2023-02-14 02:20:55 --> Config Class Initialized
INFO - 2023-02-14 02:20:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:55 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:55 --> URI Class Initialized
INFO - 2023-02-14 02:20:55 --> Router Class Initialized
INFO - 2023-02-14 02:20:55 --> Output Class Initialized
INFO - 2023-02-14 02:20:55 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:55 --> Input Class Initialized
INFO - 2023-02-14 02:20:55 --> Language Class Initialized
INFO - 2023-02-14 02:20:55 --> Loader Class Initialized
INFO - 2023-02-14 02:20:55 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:55 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:55 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:55 --> Total execution time: 0.0156
INFO - 2023-02-14 02:20:55 --> Config Class Initialized
INFO - 2023-02-14 02:20:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:55 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:55 --> URI Class Initialized
INFO - 2023-02-14 02:20:55 --> Router Class Initialized
INFO - 2023-02-14 02:20:55 --> Output Class Initialized
INFO - 2023-02-14 02:20:55 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:55 --> Input Class Initialized
INFO - 2023-02-14 02:20:55 --> Language Class Initialized
INFO - 2023-02-14 02:20:55 --> Loader Class Initialized
INFO - 2023-02-14 02:20:55 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:55 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:55 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:55 --> Total execution time: 0.0117
INFO - 2023-02-14 02:20:58 --> Config Class Initialized
INFO - 2023-02-14 02:20:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:58 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:58 --> URI Class Initialized
INFO - 2023-02-14 02:20:58 --> Router Class Initialized
INFO - 2023-02-14 02:20:58 --> Output Class Initialized
INFO - 2023-02-14 02:20:58 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:58 --> Input Class Initialized
INFO - 2023-02-14 02:20:58 --> Language Class Initialized
INFO - 2023-02-14 02:20:58 --> Loader Class Initialized
INFO - 2023-02-14 02:20:58 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:58 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:58 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:58 --> Total execution time: 0.0450
INFO - 2023-02-14 02:20:58 --> Config Class Initialized
INFO - 2023-02-14 02:20:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:20:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:20:58 --> Utf8 Class Initialized
INFO - 2023-02-14 02:20:58 --> URI Class Initialized
INFO - 2023-02-14 02:20:58 --> Router Class Initialized
INFO - 2023-02-14 02:20:58 --> Output Class Initialized
INFO - 2023-02-14 02:20:58 --> Security Class Initialized
DEBUG - 2023-02-14 02:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:20:58 --> Input Class Initialized
INFO - 2023-02-14 02:20:58 --> Language Class Initialized
INFO - 2023-02-14 02:20:58 --> Loader Class Initialized
INFO - 2023-02-14 02:20:58 --> Controller Class Initialized
DEBUG - 2023-02-14 02:20:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:20:58 --> Database Driver Class Initialized
INFO - 2023-02-14 02:20:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:20:58 --> Final output sent to browser
DEBUG - 2023-02-14 02:20:58 --> Total execution time: 0.0481
INFO - 2023-02-14 02:21:05 --> Config Class Initialized
INFO - 2023-02-14 02:21:05 --> Config Class Initialized
INFO - 2023-02-14 02:21:05 --> Hooks Class Initialized
INFO - 2023-02-14 02:21:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:21:05 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:21:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:21:05 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:05 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:05 --> URI Class Initialized
INFO - 2023-02-14 02:21:05 --> URI Class Initialized
INFO - 2023-02-14 02:21:05 --> Router Class Initialized
INFO - 2023-02-14 02:21:05 --> Router Class Initialized
INFO - 2023-02-14 02:21:05 --> Output Class Initialized
INFO - 2023-02-14 02:21:05 --> Output Class Initialized
INFO - 2023-02-14 02:21:05 --> Security Class Initialized
INFO - 2023-02-14 02:21:05 --> Security Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:21:05 --> Input Class Initialized
INFO - 2023-02-14 02:21:05 --> Input Class Initialized
INFO - 2023-02-14 02:21:05 --> Language Class Initialized
INFO - 2023-02-14 02:21:05 --> Language Class Initialized
INFO - 2023-02-14 02:21:05 --> Loader Class Initialized
INFO - 2023-02-14 02:21:05 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:05 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:05 --> Loader Class Initialized
INFO - 2023-02-14 02:21:05 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:05 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:05 --> Total execution time: 0.0488
INFO - 2023-02-14 02:21:05 --> Config Class Initialized
INFO - 2023-02-14 02:21:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:21:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:21:05 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:05 --> URI Class Initialized
INFO - 2023-02-14 02:21:05 --> Router Class Initialized
INFO - 2023-02-14 02:21:05 --> Output Class Initialized
INFO - 2023-02-14 02:21:05 --> Security Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:21:05 --> Input Class Initialized
INFO - 2023-02-14 02:21:05 --> Language Class Initialized
INFO - 2023-02-14 02:21:05 --> Loader Class Initialized
INFO - 2023-02-14 02:21:05 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:05 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:21:05 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:05 --> Total execution time: 0.0584
INFO - 2023-02-14 02:21:05 --> Model "Login_model" initialized
INFO - 2023-02-14 02:21:05 --> Config Class Initialized
INFO - 2023-02-14 02:21:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:21:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:21:05 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:05 --> URI Class Initialized
INFO - 2023-02-14 02:21:05 --> Router Class Initialized
INFO - 2023-02-14 02:21:05 --> Output Class Initialized
INFO - 2023-02-14 02:21:05 --> Security Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:21:05 --> Input Class Initialized
INFO - 2023-02-14 02:21:05 --> Language Class Initialized
INFO - 2023-02-14 02:21:05 --> Loader Class Initialized
INFO - 2023-02-14 02:21:05 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:05 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:05 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:21:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:21:05 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:05 --> Total execution time: 0.0216
INFO - 2023-02-14 02:21:05 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:05 --> Total execution time: 0.0130
INFO - 2023-02-14 02:21:07 --> Config Class Initialized
INFO - 2023-02-14 02:21:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:21:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:21:07 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:07 --> URI Class Initialized
INFO - 2023-02-14 02:21:07 --> Router Class Initialized
INFO - 2023-02-14 02:21:07 --> Output Class Initialized
INFO - 2023-02-14 02:21:07 --> Security Class Initialized
DEBUG - 2023-02-14 02:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:21:07 --> Input Class Initialized
INFO - 2023-02-14 02:21:07 --> Language Class Initialized
INFO - 2023-02-14 02:21:07 --> Loader Class Initialized
INFO - 2023-02-14 02:21:07 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:21:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:07 --> Model "Login_model" initialized
INFO - 2023-02-14 02:21:07 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:07 --> Total execution time: 0.0439
INFO - 2023-02-14 02:21:07 --> Config Class Initialized
INFO - 2023-02-14 02:21:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:21:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:21:07 --> Utf8 Class Initialized
INFO - 2023-02-14 02:21:07 --> URI Class Initialized
INFO - 2023-02-14 02:21:07 --> Router Class Initialized
INFO - 2023-02-14 02:21:07 --> Output Class Initialized
INFO - 2023-02-14 02:21:07 --> Security Class Initialized
DEBUG - 2023-02-14 02:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:21:07 --> Input Class Initialized
INFO - 2023-02-14 02:21:07 --> Language Class Initialized
INFO - 2023-02-14 02:21:07 --> Loader Class Initialized
INFO - 2023-02-14 02:21:07 --> Controller Class Initialized
DEBUG - 2023-02-14 02:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:21:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:21:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:21:07 --> Model "Login_model" initialized
INFO - 2023-02-14 02:21:07 --> Final output sent to browser
DEBUG - 2023-02-14 02:21:07 --> Total execution time: 0.0349
INFO - 2023-02-14 02:34:04 --> Config Class Initialized
INFO - 2023-02-14 02:34:04 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:04 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:04 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:04 --> URI Class Initialized
INFO - 2023-02-14 02:34:04 --> Router Class Initialized
INFO - 2023-02-14 02:34:04 --> Output Class Initialized
INFO - 2023-02-14 02:34:04 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:04 --> Input Class Initialized
INFO - 2023-02-14 02:34:04 --> Language Class Initialized
INFO - 2023-02-14 02:34:04 --> Loader Class Initialized
INFO - 2023-02-14 02:34:04 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:04 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:04 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:04 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:04 --> Total execution time: 0.0167
INFO - 2023-02-14 02:34:04 --> Config Class Initialized
INFO - 2023-02-14 02:34:04 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:04 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:04 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:04 --> URI Class Initialized
INFO - 2023-02-14 02:34:04 --> Router Class Initialized
INFO - 2023-02-14 02:34:04 --> Output Class Initialized
INFO - 2023-02-14 02:34:04 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:04 --> Input Class Initialized
INFO - 2023-02-14 02:34:04 --> Language Class Initialized
INFO - 2023-02-14 02:34:04 --> Loader Class Initialized
INFO - 2023-02-14 02:34:04 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:04 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:04 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:04 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:04 --> Total execution time: 0.0534
INFO - 2023-02-14 02:34:07 --> Config Class Initialized
INFO - 2023-02-14 02:34:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:07 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:07 --> URI Class Initialized
INFO - 2023-02-14 02:34:07 --> Router Class Initialized
INFO - 2023-02-14 02:34:07 --> Output Class Initialized
INFO - 2023-02-14 02:34:07 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:07 --> Input Class Initialized
INFO - 2023-02-14 02:34:07 --> Language Class Initialized
INFO - 2023-02-14 02:34:07 --> Loader Class Initialized
INFO - 2023-02-14 02:34:07 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:07 --> Config Class Initialized
INFO - 2023-02-14 02:34:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:07 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:07 --> URI Class Initialized
INFO - 2023-02-14 02:34:07 --> Router Class Initialized
INFO - 2023-02-14 02:34:07 --> Output Class Initialized
INFO - 2023-02-14 02:34:07 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:07 --> Input Class Initialized
INFO - 2023-02-14 02:34:07 --> Language Class Initialized
INFO - 2023-02-14 02:34:07 --> Loader Class Initialized
INFO - 2023-02-14 02:34:07 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:07 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:09 --> Config Class Initialized
INFO - 2023-02-14 02:34:09 --> Config Class Initialized
INFO - 2023-02-14 02:34:09 --> Hooks Class Initialized
INFO - 2023-02-14 02:34:09 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:34:09 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:09 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:09 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:09 --> URI Class Initialized
INFO - 2023-02-14 02:34:09 --> URI Class Initialized
INFO - 2023-02-14 02:34:09 --> Router Class Initialized
INFO - 2023-02-14 02:34:09 --> Router Class Initialized
INFO - 2023-02-14 02:34:09 --> Output Class Initialized
INFO - 2023-02-14 02:34:09 --> Output Class Initialized
INFO - 2023-02-14 02:34:09 --> Security Class Initialized
INFO - 2023-02-14 02:34:09 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:09 --> Input Class Initialized
INFO - 2023-02-14 02:34:09 --> Input Class Initialized
INFO - 2023-02-14 02:34:09 --> Language Class Initialized
INFO - 2023-02-14 02:34:09 --> Language Class Initialized
INFO - 2023-02-14 02:34:09 --> Loader Class Initialized
INFO - 2023-02-14 02:34:09 --> Loader Class Initialized
INFO - 2023-02-14 02:34:09 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:09 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:09 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:09 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:09 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:09 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:09 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:09 --> Total execution time: 0.0199
INFO - 2023-02-14 02:34:09 --> Config Class Initialized
INFO - 2023-02-14 02:34:09 --> Config Class Initialized
INFO - 2023-02-14 02:34:09 --> Hooks Class Initialized
INFO - 2023-02-14 02:34:09 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:34:09 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:09 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:09 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:09 --> URI Class Initialized
INFO - 2023-02-14 02:34:09 --> URI Class Initialized
INFO - 2023-02-14 02:34:09 --> Router Class Initialized
INFO - 2023-02-14 02:34:09 --> Router Class Initialized
INFO - 2023-02-14 02:34:09 --> Output Class Initialized
INFO - 2023-02-14 02:34:09 --> Output Class Initialized
INFO - 2023-02-14 02:34:09 --> Security Class Initialized
INFO - 2023-02-14 02:34:09 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:09 --> Input Class Initialized
INFO - 2023-02-14 02:34:09 --> Input Class Initialized
INFO - 2023-02-14 02:34:09 --> Language Class Initialized
INFO - 2023-02-14 02:34:09 --> Language Class Initialized
INFO - 2023-02-14 02:34:09 --> Loader Class Initialized
INFO - 2023-02-14 02:34:09 --> Loader Class Initialized
INFO - 2023-02-14 02:34:09 --> Controller Class Initialized
INFO - 2023-02-14 02:34:09 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:09 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:09 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:09 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:09 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:09 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:09 --> Total execution time: 0.0605
INFO - 2023-02-14 02:34:09 --> Config Class Initialized
INFO - 2023-02-14 02:34:09 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:09 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:09 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:09 --> URI Class Initialized
INFO - 2023-02-14 02:34:09 --> Router Class Initialized
INFO - 2023-02-14 02:34:09 --> Output Class Initialized
INFO - 2023-02-14 02:34:09 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:09 --> Input Class Initialized
INFO - 2023-02-14 02:34:09 --> Language Class Initialized
INFO - 2023-02-14 02:34:09 --> Loader Class Initialized
INFO - 2023-02-14 02:34:09 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:09 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:09 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:10 --> Config Class Initialized
INFO - 2023-02-14 02:34:10 --> Config Class Initialized
INFO - 2023-02-14 02:34:10 --> Hooks Class Initialized
INFO - 2023-02-14 02:34:10 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:10 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:10 --> Utf8 Class Initialized
DEBUG - 2023-02-14 02:34:10 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:10 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:10 --> URI Class Initialized
INFO - 2023-02-14 02:34:10 --> URI Class Initialized
INFO - 2023-02-14 02:34:10 --> Router Class Initialized
INFO - 2023-02-14 02:34:10 --> Router Class Initialized
INFO - 2023-02-14 02:34:10 --> Output Class Initialized
INFO - 2023-02-14 02:34:10 --> Output Class Initialized
INFO - 2023-02-14 02:34:10 --> Security Class Initialized
INFO - 2023-02-14 02:34:10 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:10 --> Input Class Initialized
INFO - 2023-02-14 02:34:10 --> Input Class Initialized
INFO - 2023-02-14 02:34:10 --> Language Class Initialized
INFO - 2023-02-14 02:34:10 --> Language Class Initialized
INFO - 2023-02-14 02:34:10 --> Loader Class Initialized
INFO - 2023-02-14 02:34:10 --> Loader Class Initialized
INFO - 2023-02-14 02:34:10 --> Controller Class Initialized
INFO - 2023-02-14 02:34:10 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:10 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:10 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:10 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:10 --> Total execution time: 0.0435
INFO - 2023-02-14 02:34:29 --> Config Class Initialized
INFO - 2023-02-14 02:34:29 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:29 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:29 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:29 --> URI Class Initialized
INFO - 2023-02-14 02:34:29 --> Router Class Initialized
INFO - 2023-02-14 02:34:29 --> Output Class Initialized
INFO - 2023-02-14 02:34:29 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:29 --> Input Class Initialized
INFO - 2023-02-14 02:34:29 --> Language Class Initialized
INFO - 2023-02-14 02:34:29 --> Loader Class Initialized
INFO - 2023-02-14 02:34:29 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:29 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:29 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:29 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:29 --> Total execution time: 0.0491
INFO - 2023-02-14 02:34:29 --> Config Class Initialized
INFO - 2023-02-14 02:34:29 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:29 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:29 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:29 --> URI Class Initialized
INFO - 2023-02-14 02:34:29 --> Router Class Initialized
INFO - 2023-02-14 02:34:29 --> Output Class Initialized
INFO - 2023-02-14 02:34:29 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:29 --> Input Class Initialized
INFO - 2023-02-14 02:34:29 --> Language Class Initialized
INFO - 2023-02-14 02:34:29 --> Loader Class Initialized
INFO - 2023-02-14 02:34:29 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:29 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:29 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:29 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:29 --> Total execution time: 0.0621
INFO - 2023-02-14 02:34:40 --> Config Class Initialized
INFO - 2023-02-14 02:34:40 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:40 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:40 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:40 --> URI Class Initialized
INFO - 2023-02-14 02:34:40 --> Router Class Initialized
INFO - 2023-02-14 02:34:40 --> Output Class Initialized
INFO - 2023-02-14 02:34:40 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:40 --> Input Class Initialized
INFO - 2023-02-14 02:34:40 --> Language Class Initialized
INFO - 2023-02-14 02:34:40 --> Loader Class Initialized
INFO - 2023-02-14 02:34:40 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:40 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:40 --> Total execution time: 0.0432
INFO - 2023-02-14 02:34:40 --> Config Class Initialized
INFO - 2023-02-14 02:34:41 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:41 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:41 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:41 --> URI Class Initialized
INFO - 2023-02-14 02:34:41 --> Router Class Initialized
INFO - 2023-02-14 02:34:41 --> Output Class Initialized
INFO - 2023-02-14 02:34:41 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:41 --> Input Class Initialized
INFO - 2023-02-14 02:34:41 --> Language Class Initialized
INFO - 2023-02-14 02:34:41 --> Loader Class Initialized
INFO - 2023-02-14 02:34:41 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:41 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:41 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:41 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:41 --> Total execution time: 0.0550
INFO - 2023-02-14 02:34:46 --> Config Class Initialized
INFO - 2023-02-14 02:34:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:46 --> URI Class Initialized
INFO - 2023-02-14 02:34:46 --> Router Class Initialized
INFO - 2023-02-14 02:34:46 --> Output Class Initialized
INFO - 2023-02-14 02:34:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:46 --> Input Class Initialized
INFO - 2023-02-14 02:34:46 --> Language Class Initialized
INFO - 2023-02-14 02:34:46 --> Loader Class Initialized
INFO - 2023-02-14 02:34:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:46 --> Total execution time: 0.0344
INFO - 2023-02-14 02:34:46 --> Config Class Initialized
INFO - 2023-02-14 02:34:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:34:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:34:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:34:46 --> URI Class Initialized
INFO - 2023-02-14 02:34:46 --> Router Class Initialized
INFO - 2023-02-14 02:34:46 --> Output Class Initialized
INFO - 2023-02-14 02:34:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:34:46 --> Input Class Initialized
INFO - 2023-02-14 02:34:46 --> Language Class Initialized
INFO - 2023-02-14 02:34:46 --> Loader Class Initialized
INFO - 2023-02-14 02:34:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:34:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:34:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:34:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:34:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:34:46 --> Total execution time: 0.0545
INFO - 2023-02-14 02:35:46 --> Config Class Initialized
INFO - 2023-02-14 02:35:46 --> Hooks Class Initialized
INFO - 2023-02-14 02:35:46 --> Config Class Initialized
INFO - 2023-02-14 02:35:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:35:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:35:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:35:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:35:46 --> URI Class Initialized
INFO - 2023-02-14 02:35:46 --> URI Class Initialized
INFO - 2023-02-14 02:35:46 --> Router Class Initialized
INFO - 2023-02-14 02:35:46 --> Router Class Initialized
INFO - 2023-02-14 02:35:46 --> Output Class Initialized
INFO - 2023-02-14 02:35:46 --> Output Class Initialized
INFO - 2023-02-14 02:35:46 --> Security Class Initialized
INFO - 2023-02-14 02:35:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:35:46 --> Input Class Initialized
INFO - 2023-02-14 02:35:46 --> Input Class Initialized
INFO - 2023-02-14 02:35:46 --> Language Class Initialized
INFO - 2023-02-14 02:35:46 --> Language Class Initialized
INFO - 2023-02-14 02:35:46 --> Loader Class Initialized
INFO - 2023-02-14 02:35:46 --> Loader Class Initialized
INFO - 2023-02-14 02:35:46 --> Controller Class Initialized
INFO - 2023-02-14 02:35:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:35:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:35:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:35:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:35:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:35:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:35:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:35:46 --> Final output sent to browser
INFO - 2023-02-14 02:35:46 --> Database Driver Class Initialized
DEBUG - 2023-02-14 02:35:46 --> Total execution time: 0.0189
INFO - 2023-02-14 02:35:46 --> Config Class Initialized
INFO - 2023-02-14 02:35:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:35:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:35:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:35:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:35:46 --> URI Class Initialized
INFO - 2023-02-14 02:35:46 --> Router Class Initialized
INFO - 2023-02-14 02:35:46 --> Output Class Initialized
INFO - 2023-02-14 02:35:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:35:46 --> Input Class Initialized
INFO - 2023-02-14 02:35:46 --> Language Class Initialized
INFO - 2023-02-14 02:35:46 --> Loader Class Initialized
INFO - 2023-02-14 02:35:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:35:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:35:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:35:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:35:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:35:46 --> Total execution time: 0.0545
INFO - 2023-02-14 02:36:46 --> Config Class Initialized
INFO - 2023-02-14 02:36:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:36:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:36:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:36:46 --> URI Class Initialized
INFO - 2023-02-14 02:36:46 --> Router Class Initialized
INFO - 2023-02-14 02:36:46 --> Output Class Initialized
INFO - 2023-02-14 02:36:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:36:46 --> Input Class Initialized
INFO - 2023-02-14 02:36:46 --> Language Class Initialized
INFO - 2023-02-14 02:36:46 --> Loader Class Initialized
INFO - 2023-02-14 02:36:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:36:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:36:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:36:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:36:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:36:46 --> Total execution time: 0.0166
INFO - 2023-02-14 02:36:46 --> Config Class Initialized
INFO - 2023-02-14 02:36:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:36:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:36:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:36:46 --> URI Class Initialized
INFO - 2023-02-14 02:36:46 --> Router Class Initialized
INFO - 2023-02-14 02:36:46 --> Output Class Initialized
INFO - 2023-02-14 02:36:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:36:46 --> Input Class Initialized
INFO - 2023-02-14 02:36:46 --> Language Class Initialized
INFO - 2023-02-14 02:36:46 --> Loader Class Initialized
INFO - 2023-02-14 02:36:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:36:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:36:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:36:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:36:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:36:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:36:47 --> Config Class Initialized
INFO - 2023-02-14 02:36:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:36:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:36:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:36:47 --> URI Class Initialized
INFO - 2023-02-14 02:36:47 --> Router Class Initialized
INFO - 2023-02-14 02:36:47 --> Output Class Initialized
INFO - 2023-02-14 02:36:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:36:47 --> Input Class Initialized
INFO - 2023-02-14 02:36:47 --> Language Class Initialized
INFO - 2023-02-14 02:36:47 --> Loader Class Initialized
INFO - 2023-02-14 02:36:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:36:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:36:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:36:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:36:47 --> Total execution time: 0.0190
INFO - 2023-02-14 02:37:46 --> Config Class Initialized
INFO - 2023-02-14 02:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:37:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:37:46 --> URI Class Initialized
INFO - 2023-02-14 02:37:46 --> Router Class Initialized
INFO - 2023-02-14 02:37:46 --> Output Class Initialized
INFO - 2023-02-14 02:37:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:37:46 --> Input Class Initialized
INFO - 2023-02-14 02:37:46 --> Language Class Initialized
INFO - 2023-02-14 02:37:46 --> Loader Class Initialized
INFO - 2023-02-14 02:37:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:37:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:37:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:37:46 --> Total execution time: 0.0193
INFO - 2023-02-14 02:37:46 --> Config Class Initialized
INFO - 2023-02-14 02:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:37:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:37:46 --> URI Class Initialized
INFO - 2023-02-14 02:37:46 --> Router Class Initialized
INFO - 2023-02-14 02:37:46 --> Output Class Initialized
INFO - 2023-02-14 02:37:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:37:46 --> Input Class Initialized
INFO - 2023-02-14 02:37:46 --> Language Class Initialized
INFO - 2023-02-14 02:37:46 --> Loader Class Initialized
INFO - 2023-02-14 02:37:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:37:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:37:46 --> Config Class Initialized
INFO - 2023-02-14 02:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:37:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:37:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:37:46 --> URI Class Initialized
INFO - 2023-02-14 02:37:46 --> Router Class Initialized
INFO - 2023-02-14 02:37:46 --> Output Class Initialized
INFO - 2023-02-14 02:37:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:37:46 --> Input Class Initialized
INFO - 2023-02-14 02:37:46 --> Language Class Initialized
INFO - 2023-02-14 02:37:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:37:46 --> Loader Class Initialized
INFO - 2023-02-14 02:37:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:37:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:37:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:37:46 --> Total execution time: 0.0164
INFO - 2023-02-14 02:38:32 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:32 --> Total execution time: 165.6329
INFO - 2023-02-14 02:38:32 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:32 --> Total execution time: 46.0669
INFO - 2023-02-14 02:38:32 --> Config Class Initialized
INFO - 2023-02-14 02:38:32 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:32 --> Total execution time: 106.0879
INFO - 2023-02-14 02:38:32 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:38:32 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:38:32 --> Utf8 Class Initialized
INFO - 2023-02-14 02:38:32 --> URI Class Initialized
INFO - 2023-02-14 02:38:32 --> Router Class Initialized
INFO - 2023-02-14 02:38:32 --> Output Class Initialized
INFO - 2023-02-14 02:38:32 --> Security Class Initialized
DEBUG - 2023-02-14 02:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:38:32 --> Input Class Initialized
INFO - 2023-02-14 02:38:32 --> Language Class Initialized
INFO - 2023-02-14 02:38:32 --> Loader Class Initialized
INFO - 2023-02-14 02:38:32 --> Controller Class Initialized
DEBUG - 2023-02-14 02:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:38:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:32 --> Model "Login_model" initialized
INFO - 2023-02-14 02:38:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:32 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:38:33 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:33 --> Total execution time: 0.5456
INFO - 2023-02-14 02:38:46 --> Config Class Initialized
INFO - 2023-02-14 02:38:46 --> Config Class Initialized
INFO - 2023-02-14 02:38:46 --> Hooks Class Initialized
INFO - 2023-02-14 02:38:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:38:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:38:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:38:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:38:46 --> URI Class Initialized
INFO - 2023-02-14 02:38:46 --> URI Class Initialized
INFO - 2023-02-14 02:38:46 --> Router Class Initialized
INFO - 2023-02-14 02:38:46 --> Router Class Initialized
INFO - 2023-02-14 02:38:46 --> Output Class Initialized
INFO - 2023-02-14 02:38:46 --> Output Class Initialized
INFO - 2023-02-14 02:38:46 --> Security Class Initialized
INFO - 2023-02-14 02:38:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:38:46 --> Input Class Initialized
INFO - 2023-02-14 02:38:46 --> Input Class Initialized
INFO - 2023-02-14 02:38:46 --> Language Class Initialized
INFO - 2023-02-14 02:38:46 --> Language Class Initialized
INFO - 2023-02-14 02:38:46 --> Loader Class Initialized
INFO - 2023-02-14 02:38:46 --> Loader Class Initialized
INFO - 2023-02-14 02:38:46 --> Controller Class Initialized
INFO - 2023-02-14 02:38:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:38:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:38:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:38:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:38:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:46 --> Total execution time: 0.0618
INFO - 2023-02-14 02:38:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:38:46 --> Config Class Initialized
INFO - 2023-02-14 02:38:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:38:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:38:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:38:46 --> URI Class Initialized
INFO - 2023-02-14 02:38:46 --> Router Class Initialized
INFO - 2023-02-14 02:38:46 --> Output Class Initialized
INFO - 2023-02-14 02:38:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:38:46 --> Input Class Initialized
INFO - 2023-02-14 02:38:46 --> Language Class Initialized
INFO - 2023-02-14 02:38:46 --> Loader Class Initialized
INFO - 2023-02-14 02:38:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:38:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:38:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:46 --> Total execution time: 0.0144
INFO - 2023-02-14 02:38:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:46 --> Total execution time: 0.4320
INFO - 2023-02-14 02:38:46 --> Config Class Initialized
INFO - 2023-02-14 02:38:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:38:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:38:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:38:46 --> URI Class Initialized
INFO - 2023-02-14 02:38:46 --> Router Class Initialized
INFO - 2023-02-14 02:38:46 --> Output Class Initialized
INFO - 2023-02-14 02:38:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:38:46 --> Input Class Initialized
INFO - 2023-02-14 02:38:46 --> Language Class Initialized
INFO - 2023-02-14 02:38:46 --> Loader Class Initialized
INFO - 2023-02-14 02:38:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:38:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:38:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:38:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:38:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:38:47 --> Total execution time: 0.4250
INFO - 2023-02-14 02:39:46 --> Config Class Initialized
INFO - 2023-02-14 02:39:46 --> Config Class Initialized
INFO - 2023-02-14 02:39:46 --> Hooks Class Initialized
INFO - 2023-02-14 02:39:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:39:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:39:46 --> Utf8 Class Initialized
DEBUG - 2023-02-14 02:39:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:39:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:39:46 --> URI Class Initialized
INFO - 2023-02-14 02:39:46 --> URI Class Initialized
INFO - 2023-02-14 02:39:46 --> Router Class Initialized
INFO - 2023-02-14 02:39:46 --> Router Class Initialized
INFO - 2023-02-14 02:39:46 --> Output Class Initialized
INFO - 2023-02-14 02:39:46 --> Output Class Initialized
INFO - 2023-02-14 02:39:46 --> Security Class Initialized
INFO - 2023-02-14 02:39:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:39:46 --> Input Class Initialized
INFO - 2023-02-14 02:39:46 --> Input Class Initialized
INFO - 2023-02-14 02:39:46 --> Language Class Initialized
INFO - 2023-02-14 02:39:46 --> Language Class Initialized
INFO - 2023-02-14 02:39:46 --> Loader Class Initialized
INFO - 2023-02-14 02:39:46 --> Loader Class Initialized
INFO - 2023-02-14 02:39:46 --> Controller Class Initialized
INFO - 2023-02-14 02:39:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:39:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:39:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:39:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:39:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:39:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:39:46 --> Total execution time: 0.1396
INFO - 2023-02-14 02:39:46 --> Config Class Initialized
INFO - 2023-02-14 02:39:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:39:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:39:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:39:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:39:46 --> URI Class Initialized
INFO - 2023-02-14 02:39:46 --> Router Class Initialized
INFO - 2023-02-14 02:39:46 --> Output Class Initialized
INFO - 2023-02-14 02:39:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:39:46 --> Input Class Initialized
INFO - 2023-02-14 02:39:46 --> Language Class Initialized
INFO - 2023-02-14 02:39:46 --> Loader Class Initialized
INFO - 2023-02-14 02:39:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:39:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:39:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:39:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:39:46 --> Total execution time: 0.0412
INFO - 2023-02-14 02:39:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:39:47 --> Total execution time: 1.0241
INFO - 2023-02-14 02:39:47 --> Config Class Initialized
INFO - 2023-02-14 02:39:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:39:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:39:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:39:47 --> URI Class Initialized
INFO - 2023-02-14 02:39:47 --> Router Class Initialized
INFO - 2023-02-14 02:39:47 --> Output Class Initialized
INFO - 2023-02-14 02:39:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:39:47 --> Input Class Initialized
INFO - 2023-02-14 02:39:47 --> Language Class Initialized
INFO - 2023-02-14 02:39:47 --> Loader Class Initialized
INFO - 2023-02-14 02:39:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:39:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:39:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:47 --> Model "Login_model" initialized
INFO - 2023-02-14 02:39:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:39:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:39:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:39:48 --> Total execution time: 0.5857
INFO - 2023-02-14 02:40:46 --> Config Class Initialized
INFO - 2023-02-14 02:40:46 --> Hooks Class Initialized
INFO - 2023-02-14 02:40:46 --> Config Class Initialized
INFO - 2023-02-14 02:40:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:46 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:40:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:46 --> URI Class Initialized
INFO - 2023-02-14 02:40:46 --> URI Class Initialized
INFO - 2023-02-14 02:40:46 --> Router Class Initialized
INFO - 2023-02-14 02:40:46 --> Router Class Initialized
INFO - 2023-02-14 02:40:46 --> Output Class Initialized
INFO - 2023-02-14 02:40:46 --> Output Class Initialized
INFO - 2023-02-14 02:40:46 --> Security Class Initialized
INFO - 2023-02-14 02:40:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:46 --> Input Class Initialized
INFO - 2023-02-14 02:40:46 --> Input Class Initialized
INFO - 2023-02-14 02:40:46 --> Language Class Initialized
INFO - 2023-02-14 02:40:46 --> Language Class Initialized
INFO - 2023-02-14 02:40:46 --> Loader Class Initialized
INFO - 2023-02-14 02:40:46 --> Controller Class Initialized
INFO - 2023-02-14 02:40:46 --> Loader Class Initialized
DEBUG - 2023-02-14 02:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:46 --> Model "Login_model" initialized
INFO - 2023-02-14 02:40:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:46 --> Total execution time: 0.0237
INFO - 2023-02-14 02:40:46 --> Config Class Initialized
INFO - 2023-02-14 02:40:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:46 --> URI Class Initialized
INFO - 2023-02-14 02:40:46 --> Router Class Initialized
INFO - 2023-02-14 02:40:46 --> Output Class Initialized
INFO - 2023-02-14 02:40:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:46 --> Input Class Initialized
INFO - 2023-02-14 02:40:46 --> Language Class Initialized
INFO - 2023-02-14 02:40:46 --> Loader Class Initialized
INFO - 2023-02-14 02:40:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:46 --> Total execution time: 0.0219
INFO - 2023-02-14 02:40:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:47 --> Total execution time: 0.5166
INFO - 2023-02-14 02:40:47 --> Config Class Initialized
INFO - 2023-02-14 02:40:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:47 --> URI Class Initialized
INFO - 2023-02-14 02:40:47 --> Router Class Initialized
INFO - 2023-02-14 02:40:47 --> Output Class Initialized
INFO - 2023-02-14 02:40:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:47 --> Input Class Initialized
INFO - 2023-02-14 02:40:47 --> Language Class Initialized
INFO - 2023-02-14 02:40:47 --> Loader Class Initialized
INFO - 2023-02-14 02:40:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:47 --> Model "Login_model" initialized
INFO - 2023-02-14 02:40:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:47 --> Total execution time: 0.4108
INFO - 2023-02-14 02:40:50 --> Config Class Initialized
INFO - 2023-02-14 02:40:50 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:50 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:50 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:50 --> URI Class Initialized
INFO - 2023-02-14 02:40:50 --> Router Class Initialized
INFO - 2023-02-14 02:40:50 --> Output Class Initialized
INFO - 2023-02-14 02:40:50 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:50 --> Input Class Initialized
INFO - 2023-02-14 02:40:50 --> Language Class Initialized
INFO - 2023-02-14 02:40:50 --> Loader Class Initialized
INFO - 2023-02-14 02:40:50 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:50 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:50 --> Total execution time: 0.0051
INFO - 2023-02-14 02:40:50 --> Config Class Initialized
INFO - 2023-02-14 02:40:50 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:50 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:50 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:50 --> URI Class Initialized
INFO - 2023-02-14 02:40:50 --> Router Class Initialized
INFO - 2023-02-14 02:40:50 --> Output Class Initialized
INFO - 2023-02-14 02:40:50 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:50 --> Input Class Initialized
INFO - 2023-02-14 02:40:50 --> Language Class Initialized
INFO - 2023-02-14 02:40:50 --> Loader Class Initialized
INFO - 2023-02-14 02:40:50 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:50 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:50 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:50 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:50 --> Total execution time: 0.0527
INFO - 2023-02-14 02:40:51 --> Config Class Initialized
INFO - 2023-02-14 02:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:51 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:51 --> URI Class Initialized
INFO - 2023-02-14 02:40:51 --> Router Class Initialized
INFO - 2023-02-14 02:40:51 --> Output Class Initialized
INFO - 2023-02-14 02:40:51 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:51 --> Input Class Initialized
INFO - 2023-02-14 02:40:51 --> Language Class Initialized
INFO - 2023-02-14 02:40:51 --> Loader Class Initialized
INFO - 2023-02-14 02:40:51 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:51 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:51 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:51 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:51 --> Total execution time: 0.0242
INFO - 2023-02-14 02:40:51 --> Config Class Initialized
INFO - 2023-02-14 02:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:51 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:51 --> URI Class Initialized
INFO - 2023-02-14 02:40:51 --> Router Class Initialized
INFO - 2023-02-14 02:40:51 --> Output Class Initialized
INFO - 2023-02-14 02:40:51 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:51 --> Input Class Initialized
INFO - 2023-02-14 02:40:51 --> Language Class Initialized
INFO - 2023-02-14 02:40:51 --> Loader Class Initialized
INFO - 2023-02-14 02:40:51 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:51 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:51 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:51 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:51 --> Total execution time: 0.0767
INFO - 2023-02-14 02:40:55 --> Config Class Initialized
INFO - 2023-02-14 02:40:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:55 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:55 --> URI Class Initialized
INFO - 2023-02-14 02:40:55 --> Router Class Initialized
INFO - 2023-02-14 02:40:55 --> Output Class Initialized
INFO - 2023-02-14 02:40:55 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:55 --> Input Class Initialized
INFO - 2023-02-14 02:40:55 --> Language Class Initialized
INFO - 2023-02-14 02:40:55 --> Loader Class Initialized
INFO - 2023-02-14 02:40:55 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:55 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:55 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:55 --> Total execution time: 0.0210
INFO - 2023-02-14 02:40:55 --> Config Class Initialized
INFO - 2023-02-14 02:40:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:55 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:55 --> URI Class Initialized
INFO - 2023-02-14 02:40:55 --> Router Class Initialized
INFO - 2023-02-14 02:40:55 --> Output Class Initialized
INFO - 2023-02-14 02:40:55 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:55 --> Input Class Initialized
INFO - 2023-02-14 02:40:55 --> Language Class Initialized
INFO - 2023-02-14 02:40:55 --> Loader Class Initialized
INFO - 2023-02-14 02:40:55 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:55 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:55 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:55 --> Total execution time: 0.0531
INFO - 2023-02-14 02:40:56 --> Config Class Initialized
INFO - 2023-02-14 02:40:56 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:56 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:56 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:56 --> URI Class Initialized
INFO - 2023-02-14 02:40:56 --> Router Class Initialized
INFO - 2023-02-14 02:40:56 --> Output Class Initialized
INFO - 2023-02-14 02:40:56 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:56 --> Input Class Initialized
INFO - 2023-02-14 02:40:56 --> Language Class Initialized
INFO - 2023-02-14 02:40:56 --> Loader Class Initialized
INFO - 2023-02-14 02:40:56 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:56 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:56 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:56 --> Model "Login_model" initialized
INFO - 2023-02-14 02:40:56 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:56 --> Total execution time: 0.0244
INFO - 2023-02-14 02:40:56 --> Config Class Initialized
INFO - 2023-02-14 02:40:56 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:56 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:56 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:56 --> URI Class Initialized
INFO - 2023-02-14 02:40:56 --> Router Class Initialized
INFO - 2023-02-14 02:40:56 --> Output Class Initialized
INFO - 2023-02-14 02:40:56 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:56 --> Input Class Initialized
INFO - 2023-02-14 02:40:56 --> Language Class Initialized
INFO - 2023-02-14 02:40:56 --> Loader Class Initialized
INFO - 2023-02-14 02:40:56 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:56 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:56 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:56 --> Model "Login_model" initialized
INFO - 2023-02-14 02:40:56 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:56 --> Total execution time: 0.0594
INFO - 2023-02-14 02:40:57 --> Config Class Initialized
INFO - 2023-02-14 02:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:57 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:57 --> URI Class Initialized
INFO - 2023-02-14 02:40:57 --> Router Class Initialized
INFO - 2023-02-14 02:40:57 --> Output Class Initialized
INFO - 2023-02-14 02:40:57 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:57 --> Input Class Initialized
INFO - 2023-02-14 02:40:57 --> Language Class Initialized
INFO - 2023-02-14 02:40:57 --> Loader Class Initialized
INFO - 2023-02-14 02:40:57 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:57 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:58 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:58 --> Total execution time: 0.8541
INFO - 2023-02-14 02:40:58 --> Config Class Initialized
INFO - 2023-02-14 02:40:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:40:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:40:58 --> Utf8 Class Initialized
INFO - 2023-02-14 02:40:58 --> URI Class Initialized
INFO - 2023-02-14 02:40:58 --> Router Class Initialized
INFO - 2023-02-14 02:40:58 --> Output Class Initialized
INFO - 2023-02-14 02:40:58 --> Security Class Initialized
DEBUG - 2023-02-14 02:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:40:58 --> Input Class Initialized
INFO - 2023-02-14 02:40:58 --> Language Class Initialized
INFO - 2023-02-14 02:40:58 --> Loader Class Initialized
INFO - 2023-02-14 02:40:58 --> Controller Class Initialized
DEBUG - 2023-02-14 02:40:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:40:58 --> Database Driver Class Initialized
INFO - 2023-02-14 02:40:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:40:58 --> Final output sent to browser
DEBUG - 2023-02-14 02:40:58 --> Total execution time: 0.3622
INFO - 2023-02-14 02:42:49 --> Config Class Initialized
INFO - 2023-02-14 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:42:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:42:49 --> URI Class Initialized
INFO - 2023-02-14 02:42:49 --> Router Class Initialized
INFO - 2023-02-14 02:42:49 --> Output Class Initialized
INFO - 2023-02-14 02:42:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:42:49 --> Input Class Initialized
INFO - 2023-02-14 02:42:49 --> Language Class Initialized
INFO - 2023-02-14 02:42:49 --> Loader Class Initialized
INFO - 2023-02-14 02:42:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:42:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:42:49 --> Total execution time: 0.0038
INFO - 2023-02-14 02:42:49 --> Config Class Initialized
INFO - 2023-02-14 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:42:49 --> Utf8 Class Initialized
INFO - 2023-02-14 02:42:49 --> URI Class Initialized
INFO - 2023-02-14 02:42:49 --> Router Class Initialized
INFO - 2023-02-14 02:42:49 --> Output Class Initialized
INFO - 2023-02-14 02:42:49 --> Security Class Initialized
DEBUG - 2023-02-14 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:42:49 --> Input Class Initialized
INFO - 2023-02-14 02:42:49 --> Language Class Initialized
INFO - 2023-02-14 02:42:49 --> Loader Class Initialized
INFO - 2023-02-14 02:42:49 --> Controller Class Initialized
DEBUG - 2023-02-14 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:42:49 --> Database Driver Class Initialized
INFO - 2023-02-14 02:42:49 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:42:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:42:49 --> Total execution time: 0.0102
INFO - 2023-02-14 02:44:32 --> Config Class Initialized
INFO - 2023-02-14 02:44:32 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:32 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:32 --> URI Class Initialized
INFO - 2023-02-14 02:44:32 --> Router Class Initialized
INFO - 2023-02-14 02:44:32 --> Output Class Initialized
INFO - 2023-02-14 02:44:32 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:32 --> Input Class Initialized
INFO - 2023-02-14 02:44:32 --> Language Class Initialized
INFO - 2023-02-14 02:44:32 --> Loader Class Initialized
INFO - 2023-02-14 02:44:32 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:32 --> Model "Login_model" initialized
INFO - 2023-02-14 02:44:32 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:32 --> Total execution time: 0.0207
INFO - 2023-02-14 02:44:32 --> Config Class Initialized
INFO - 2023-02-14 02:44:32 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:32 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:32 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:32 --> URI Class Initialized
INFO - 2023-02-14 02:44:32 --> Router Class Initialized
INFO - 2023-02-14 02:44:32 --> Output Class Initialized
INFO - 2023-02-14 02:44:32 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:32 --> Input Class Initialized
INFO - 2023-02-14 02:44:32 --> Language Class Initialized
INFO - 2023-02-14 02:44:32 --> Loader Class Initialized
INFO - 2023-02-14 02:44:32 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:32 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:32 --> Model "Login_model" initialized
INFO - 2023-02-14 02:44:32 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:32 --> Total execution time: 0.0596
INFO - 2023-02-14 02:44:35 --> Config Class Initialized
INFO - 2023-02-14 02:44:35 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:35 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:35 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:35 --> URI Class Initialized
INFO - 2023-02-14 02:44:35 --> Router Class Initialized
INFO - 2023-02-14 02:44:35 --> Output Class Initialized
INFO - 2023-02-14 02:44:35 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:35 --> Input Class Initialized
INFO - 2023-02-14 02:44:35 --> Language Class Initialized
INFO - 2023-02-14 02:44:35 --> Loader Class Initialized
INFO - 2023-02-14 02:44:35 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:35 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:35 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:35 --> Model "Login_model" initialized
INFO - 2023-02-14 02:44:35 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:35 --> Total execution time: 0.0291
INFO - 2023-02-14 02:44:35 --> Config Class Initialized
INFO - 2023-02-14 02:44:35 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:35 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:35 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:35 --> URI Class Initialized
INFO - 2023-02-14 02:44:35 --> Router Class Initialized
INFO - 2023-02-14 02:44:35 --> Output Class Initialized
INFO - 2023-02-14 02:44:35 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:35 --> Input Class Initialized
INFO - 2023-02-14 02:44:35 --> Language Class Initialized
INFO - 2023-02-14 02:44:35 --> Loader Class Initialized
INFO - 2023-02-14 02:44:35 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:35 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:35 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:35 --> Model "Login_model" initialized
INFO - 2023-02-14 02:44:35 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:35 --> Total execution time: 0.0219
INFO - 2023-02-14 02:44:39 --> Config Class Initialized
INFO - 2023-02-14 02:44:39 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:39 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:39 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:39 --> URI Class Initialized
INFO - 2023-02-14 02:44:39 --> Router Class Initialized
INFO - 2023-02-14 02:44:39 --> Output Class Initialized
INFO - 2023-02-14 02:44:39 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:39 --> Input Class Initialized
INFO - 2023-02-14 02:44:39 --> Language Class Initialized
INFO - 2023-02-14 02:44:39 --> Loader Class Initialized
INFO - 2023-02-14 02:44:39 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:39 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:39 --> Total execution time: 0.0041
INFO - 2023-02-14 02:44:39 --> Config Class Initialized
INFO - 2023-02-14 02:44:39 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:39 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:39 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:39 --> URI Class Initialized
INFO - 2023-02-14 02:44:39 --> Router Class Initialized
INFO - 2023-02-14 02:44:39 --> Output Class Initialized
INFO - 2023-02-14 02:44:39 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:39 --> Input Class Initialized
INFO - 2023-02-14 02:44:39 --> Language Class Initialized
INFO - 2023-02-14 02:44:39 --> Loader Class Initialized
INFO - 2023-02-14 02:44:39 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:39 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:39 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:44:39 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:39 --> Total execution time: 0.0570
INFO - 2023-02-14 02:44:45 --> Config Class Initialized
INFO - 2023-02-14 02:44:45 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:45 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:45 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:45 --> URI Class Initialized
INFO - 2023-02-14 02:44:45 --> Router Class Initialized
INFO - 2023-02-14 02:44:45 --> Output Class Initialized
INFO - 2023-02-14 02:44:45 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:45 --> Input Class Initialized
INFO - 2023-02-14 02:44:45 --> Language Class Initialized
INFO - 2023-02-14 02:44:45 --> Loader Class Initialized
INFO - 2023-02-14 02:44:45 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:45 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:45 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:44:45 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:45 --> Total execution time: 0.0171
INFO - 2023-02-14 02:44:45 --> Config Class Initialized
INFO - 2023-02-14 02:44:45 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:44:45 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:44:45 --> Utf8 Class Initialized
INFO - 2023-02-14 02:44:45 --> URI Class Initialized
INFO - 2023-02-14 02:44:45 --> Router Class Initialized
INFO - 2023-02-14 02:44:45 --> Output Class Initialized
INFO - 2023-02-14 02:44:45 --> Security Class Initialized
DEBUG - 2023-02-14 02:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:44:45 --> Input Class Initialized
INFO - 2023-02-14 02:44:45 --> Language Class Initialized
INFO - 2023-02-14 02:44:45 --> Loader Class Initialized
INFO - 2023-02-14 02:44:45 --> Controller Class Initialized
DEBUG - 2023-02-14 02:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:44:45 --> Database Driver Class Initialized
INFO - 2023-02-14 02:44:45 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:44:45 --> Final output sent to browser
DEBUG - 2023-02-14 02:44:45 --> Total execution time: 0.0161
INFO - 2023-02-14 02:45:47 --> Config Class Initialized
INFO - 2023-02-14 02:45:47 --> Config Class Initialized
INFO - 2023-02-14 02:45:47 --> Hooks Class Initialized
INFO - 2023-02-14 02:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:45:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:45:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:45:47 --> URI Class Initialized
INFO - 2023-02-14 02:45:47 --> URI Class Initialized
INFO - 2023-02-14 02:45:47 --> Router Class Initialized
INFO - 2023-02-14 02:45:47 --> Router Class Initialized
INFO - 2023-02-14 02:45:47 --> Output Class Initialized
INFO - 2023-02-14 02:45:47 --> Output Class Initialized
INFO - 2023-02-14 02:45:47 --> Security Class Initialized
INFO - 2023-02-14 02:45:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:45:48 --> Input Class Initialized
INFO - 2023-02-14 02:45:48 --> Input Class Initialized
INFO - 2023-02-14 02:45:48 --> Language Class Initialized
INFO - 2023-02-14 02:45:48 --> Language Class Initialized
INFO - 2023-02-14 02:45:48 --> Loader Class Initialized
INFO - 2023-02-14 02:45:48 --> Loader Class Initialized
INFO - 2023-02-14 02:45:48 --> Controller Class Initialized
INFO - 2023-02-14 02:45:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:45:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:45:48 --> Total execution time: 0.7455
INFO - 2023-02-14 02:45:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:45:48 --> Config Class Initialized
INFO - 2023-02-14 02:45:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:45:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:45:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:45:48 --> URI Class Initialized
INFO - 2023-02-14 02:45:48 --> Router Class Initialized
INFO - 2023-02-14 02:45:48 --> Output Class Initialized
INFO - 2023-02-14 02:45:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:45:48 --> Input Class Initialized
INFO - 2023-02-14 02:45:48 --> Language Class Initialized
INFO - 2023-02-14 02:45:48 --> Loader Class Initialized
INFO - 2023-02-14 02:45:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:45:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:45:48 --> Total execution time: 0.1781
INFO - 2023-02-14 02:45:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:45:48 --> Total execution time: 1.1664
INFO - 2023-02-14 02:45:48 --> Config Class Initialized
INFO - 2023-02-14 02:45:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:45:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:45:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:45:48 --> URI Class Initialized
INFO - 2023-02-14 02:45:48 --> Router Class Initialized
INFO - 2023-02-14 02:45:48 --> Output Class Initialized
INFO - 2023-02-14 02:45:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:45:48 --> Input Class Initialized
INFO - 2023-02-14 02:45:48 --> Language Class Initialized
INFO - 2023-02-14 02:45:48 --> Loader Class Initialized
INFO - 2023-02-14 02:45:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:45:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:45:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:45:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:45:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:45:48 --> Total execution time: 0.4178
INFO - 2023-02-14 02:46:47 --> Config Class Initialized
INFO - 2023-02-14 02:46:47 --> Config Class Initialized
INFO - 2023-02-14 02:46:47 --> Hooks Class Initialized
INFO - 2023-02-14 02:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:46:47 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:46:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:46:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:46:47 --> URI Class Initialized
INFO - 2023-02-14 02:46:47 --> URI Class Initialized
INFO - 2023-02-14 02:46:47 --> Router Class Initialized
INFO - 2023-02-14 02:46:47 --> Router Class Initialized
INFO - 2023-02-14 02:46:47 --> Output Class Initialized
INFO - 2023-02-14 02:46:47 --> Output Class Initialized
INFO - 2023-02-14 02:46:47 --> Security Class Initialized
INFO - 2023-02-14 02:46:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:46:47 --> Input Class Initialized
INFO - 2023-02-14 02:46:47 --> Input Class Initialized
INFO - 2023-02-14 02:46:47 --> Language Class Initialized
INFO - 2023-02-14 02:46:47 --> Language Class Initialized
INFO - 2023-02-14 02:46:47 --> Loader Class Initialized
INFO - 2023-02-14 02:46:47 --> Loader Class Initialized
INFO - 2023-02-14 02:46:47 --> Controller Class Initialized
INFO - 2023-02-14 02:46:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:46:47 --> Model "Login_model" initialized
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:46:47 --> Total execution time: 0.0220
INFO - 2023-02-14 02:46:47 --> Config Class Initialized
INFO - 2023-02-14 02:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:46:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:46:47 --> URI Class Initialized
INFO - 2023-02-14 02:46:47 --> Router Class Initialized
INFO - 2023-02-14 02:46:47 --> Output Class Initialized
INFO - 2023-02-14 02:46:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:46:47 --> Input Class Initialized
INFO - 2023-02-14 02:46:47 --> Language Class Initialized
INFO - 2023-02-14 02:46:47 --> Loader Class Initialized
INFO - 2023-02-14 02:46:47 --> Controller Class Initialized
INFO - 2023-02-14 02:46:47 --> Model "Cluster_model" initialized
DEBUG - 2023-02-14 02:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:46:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:46:47 --> Total execution time: 0.0154
INFO - 2023-02-14 02:46:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:46:47 --> Total execution time: 0.4292
INFO - 2023-02-14 02:46:47 --> Config Class Initialized
INFO - 2023-02-14 02:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:46:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:46:47 --> URI Class Initialized
INFO - 2023-02-14 02:46:47 --> Router Class Initialized
INFO - 2023-02-14 02:46:47 --> Output Class Initialized
INFO - 2023-02-14 02:46:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:46:47 --> Input Class Initialized
INFO - 2023-02-14 02:46:47 --> Language Class Initialized
INFO - 2023-02-14 02:46:47 --> Loader Class Initialized
INFO - 2023-02-14 02:46:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Model "Login_model" initialized
INFO - 2023-02-14 02:46:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:46:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:46:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:46:48 --> Total execution time: 0.4802
INFO - 2023-02-14 02:47:48 --> Config Class Initialized
INFO - 2023-02-14 02:47:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:47:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:47:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:47:48 --> URI Class Initialized
INFO - 2023-02-14 02:47:48 --> Router Class Initialized
INFO - 2023-02-14 02:47:48 --> Output Class Initialized
INFO - 2023-02-14 02:47:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:47:48 --> Input Class Initialized
INFO - 2023-02-14 02:47:48 --> Language Class Initialized
INFO - 2023-02-14 02:47:48 --> Loader Class Initialized
INFO - 2023-02-14 02:47:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:47:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:47:48 --> Total execution time: 0.1160
INFO - 2023-02-14 02:47:48 --> Config Class Initialized
INFO - 2023-02-14 02:47:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:47:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:47:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:47:48 --> URI Class Initialized
INFO - 2023-02-14 02:47:48 --> Router Class Initialized
INFO - 2023-02-14 02:47:48 --> Output Class Initialized
INFO - 2023-02-14 02:47:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:47:48 --> Input Class Initialized
INFO - 2023-02-14 02:47:48 --> Language Class Initialized
INFO - 2023-02-14 02:47:48 --> Loader Class Initialized
INFO - 2023-02-14 02:47:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:47:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:47:48 --> Total execution time: 0.0165
INFO - 2023-02-14 02:47:48 --> Config Class Initialized
INFO - 2023-02-14 02:47:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:47:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:47:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:47:48 --> URI Class Initialized
INFO - 2023-02-14 02:47:48 --> Router Class Initialized
INFO - 2023-02-14 02:47:48 --> Output Class Initialized
INFO - 2023-02-14 02:47:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:47:48 --> Input Class Initialized
INFO - 2023-02-14 02:47:48 --> Language Class Initialized
INFO - 2023-02-14 02:47:48 --> Loader Class Initialized
INFO - 2023-02-14 02:47:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:47:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:47:48 --> Total execution time: 0.4193
INFO - 2023-02-14 02:47:48 --> Config Class Initialized
INFO - 2023-02-14 02:47:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:47:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:47:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:47:48 --> URI Class Initialized
INFO - 2023-02-14 02:47:48 --> Router Class Initialized
INFO - 2023-02-14 02:47:48 --> Output Class Initialized
INFO - 2023-02-14 02:47:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:47:48 --> Input Class Initialized
INFO - 2023-02-14 02:47:48 --> Language Class Initialized
INFO - 2023-02-14 02:47:48 --> Loader Class Initialized
INFO - 2023-02-14 02:47:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:47:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:47:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:47:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:47:49 --> Final output sent to browser
DEBUG - 2023-02-14 02:47:49 --> Total execution time: 0.4613
INFO - 2023-02-14 02:48:46 --> Config Class Initialized
INFO - 2023-02-14 02:48:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:48:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:48:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:48:46 --> URI Class Initialized
INFO - 2023-02-14 02:48:46 --> Router Class Initialized
INFO - 2023-02-14 02:48:46 --> Output Class Initialized
INFO - 2023-02-14 02:48:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:48:46 --> Input Class Initialized
INFO - 2023-02-14 02:48:46 --> Language Class Initialized
INFO - 2023-02-14 02:48:46 --> Loader Class Initialized
INFO - 2023-02-14 02:48:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:48:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:48:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:48:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:48:46 --> Total execution time: 0.0210
INFO - 2023-02-14 02:48:46 --> Config Class Initialized
INFO - 2023-02-14 02:48:46 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:48:46 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:48:46 --> Utf8 Class Initialized
INFO - 2023-02-14 02:48:46 --> URI Class Initialized
INFO - 2023-02-14 02:48:46 --> Router Class Initialized
INFO - 2023-02-14 02:48:46 --> Output Class Initialized
INFO - 2023-02-14 02:48:46 --> Security Class Initialized
DEBUG - 2023-02-14 02:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:48:46 --> Input Class Initialized
INFO - 2023-02-14 02:48:46 --> Language Class Initialized
INFO - 2023-02-14 02:48:46 --> Loader Class Initialized
INFO - 2023-02-14 02:48:46 --> Controller Class Initialized
DEBUG - 2023-02-14 02:48:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:48:46 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:46 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:48:46 --> Final output sent to browser
DEBUG - 2023-02-14 02:48:46 --> Total execution time: 0.0617
INFO - 2023-02-14 02:48:48 --> Config Class Initialized
INFO - 2023-02-14 02:48:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:48:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:48:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:48:48 --> URI Class Initialized
INFO - 2023-02-14 02:48:48 --> Router Class Initialized
INFO - 2023-02-14 02:48:48 --> Output Class Initialized
INFO - 2023-02-14 02:48:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:48:48 --> Input Class Initialized
INFO - 2023-02-14 02:48:48 --> Language Class Initialized
INFO - 2023-02-14 02:48:48 --> Loader Class Initialized
INFO - 2023-02-14 02:48:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:48:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:48:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:48:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:48:48 --> Total execution time: 0.4213
INFO - 2023-02-14 02:48:48 --> Config Class Initialized
INFO - 2023-02-14 02:48:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:48:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:48:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:48:48 --> URI Class Initialized
INFO - 2023-02-14 02:48:48 --> Router Class Initialized
INFO - 2023-02-14 02:48:48 --> Output Class Initialized
INFO - 2023-02-14 02:48:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:48:48 --> Input Class Initialized
INFO - 2023-02-14 02:48:48 --> Language Class Initialized
INFO - 2023-02-14 02:48:48 --> Loader Class Initialized
INFO - 2023-02-14 02:48:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:48:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:48:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:48:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:48:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:48:48 --> Total execution time: 0.4380
INFO - 2023-02-14 02:49:47 --> Config Class Initialized
INFO - 2023-02-14 02:49:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:49:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:49:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:49:47 --> URI Class Initialized
INFO - 2023-02-14 02:49:47 --> Router Class Initialized
INFO - 2023-02-14 02:49:47 --> Output Class Initialized
INFO - 2023-02-14 02:49:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:49:47 --> Input Class Initialized
INFO - 2023-02-14 02:49:47 --> Language Class Initialized
INFO - 2023-02-14 02:49:47 --> Loader Class Initialized
INFO - 2023-02-14 02:49:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:49:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:49:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:49:47 --> Total execution time: 0.0208
INFO - 2023-02-14 02:49:47 --> Config Class Initialized
INFO - 2023-02-14 02:49:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:49:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:49:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:49:47 --> URI Class Initialized
INFO - 2023-02-14 02:49:47 --> Router Class Initialized
INFO - 2023-02-14 02:49:47 --> Output Class Initialized
INFO - 2023-02-14 02:49:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:49:47 --> Input Class Initialized
INFO - 2023-02-14 02:49:47 --> Language Class Initialized
INFO - 2023-02-14 02:49:47 --> Loader Class Initialized
INFO - 2023-02-14 02:49:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:49:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:49:47 --> Final output sent to browser
DEBUG - 2023-02-14 02:49:47 --> Total execution time: 0.0146
INFO - 2023-02-14 02:49:47 --> Config Class Initialized
INFO - 2023-02-14 02:49:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:49:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:49:47 --> Utf8 Class Initialized
INFO - 2023-02-14 02:49:47 --> URI Class Initialized
INFO - 2023-02-14 02:49:47 --> Router Class Initialized
INFO - 2023-02-14 02:49:47 --> Output Class Initialized
INFO - 2023-02-14 02:49:47 --> Security Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:49:47 --> Input Class Initialized
INFO - 2023-02-14 02:49:47 --> Language Class Initialized
INFO - 2023-02-14 02:49:47 --> Loader Class Initialized
INFO - 2023-02-14 02:49:47 --> Controller Class Initialized
DEBUG - 2023-02-14 02:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:49:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:47 --> Model "Login_model" initialized
INFO - 2023-02-14 02:49:47 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:49:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:49:48 --> Total execution time: 0.4535
INFO - 2023-02-14 02:49:48 --> Config Class Initialized
INFO - 2023-02-14 02:49:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:49:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:49:48 --> Utf8 Class Initialized
INFO - 2023-02-14 02:49:48 --> URI Class Initialized
INFO - 2023-02-14 02:49:48 --> Router Class Initialized
INFO - 2023-02-14 02:49:48 --> Output Class Initialized
INFO - 2023-02-14 02:49:48 --> Security Class Initialized
DEBUG - 2023-02-14 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:49:48 --> Input Class Initialized
INFO - 2023-02-14 02:49:48 --> Language Class Initialized
INFO - 2023-02-14 02:49:48 --> Loader Class Initialized
INFO - 2023-02-14 02:49:48 --> Controller Class Initialized
DEBUG - 2023-02-14 02:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:49:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:48 --> Model "Login_model" initialized
INFO - 2023-02-14 02:49:48 --> Database Driver Class Initialized
INFO - 2023-02-14 02:49:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:49:48 --> Final output sent to browser
DEBUG - 2023-02-14 02:49:48 --> Total execution time: 0.4534
INFO - 2023-02-14 02:51:02 --> Config Class Initialized
INFO - 2023-02-14 02:51:02 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:51:02 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:51:02 --> Utf8 Class Initialized
INFO - 2023-02-14 02:51:02 --> URI Class Initialized
INFO - 2023-02-14 02:51:02 --> Router Class Initialized
INFO - 2023-02-14 02:51:02 --> Output Class Initialized
INFO - 2023-02-14 02:51:02 --> Security Class Initialized
DEBUG - 2023-02-14 02:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:51:02 --> Input Class Initialized
INFO - 2023-02-14 02:51:02 --> Language Class Initialized
INFO - 2023-02-14 02:51:02 --> Loader Class Initialized
INFO - 2023-02-14 02:51:02 --> Controller Class Initialized
DEBUG - 2023-02-14 02:51:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:51:02 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:02 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:51:02 --> Final output sent to browser
DEBUG - 2023-02-14 02:51:02 --> Total execution time: 0.0161
INFO - 2023-02-14 02:51:02 --> Config Class Initialized
INFO - 2023-02-14 02:51:02 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:51:02 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:51:02 --> Utf8 Class Initialized
INFO - 2023-02-14 02:51:02 --> URI Class Initialized
INFO - 2023-02-14 02:51:02 --> Router Class Initialized
INFO - 2023-02-14 02:51:02 --> Output Class Initialized
INFO - 2023-02-14 02:51:02 --> Security Class Initialized
DEBUG - 2023-02-14 02:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:51:02 --> Input Class Initialized
INFO - 2023-02-14 02:51:02 --> Language Class Initialized
INFO - 2023-02-14 02:51:02 --> Loader Class Initialized
INFO - 2023-02-14 02:51:02 --> Controller Class Initialized
DEBUG - 2023-02-14 02:51:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:51:02 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:02 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:51:02 --> Final output sent to browser
DEBUG - 2023-02-14 02:51:02 --> Total execution time: 0.0168
INFO - 2023-02-14 02:51:08 --> Config Class Initialized
INFO - 2023-02-14 02:51:08 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:51:08 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:51:08 --> Utf8 Class Initialized
INFO - 2023-02-14 02:51:08 --> URI Class Initialized
INFO - 2023-02-14 02:51:08 --> Router Class Initialized
INFO - 2023-02-14 02:51:08 --> Output Class Initialized
INFO - 2023-02-14 02:51:08 --> Security Class Initialized
DEBUG - 2023-02-14 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:51:08 --> Input Class Initialized
INFO - 2023-02-14 02:51:08 --> Language Class Initialized
INFO - 2023-02-14 02:51:08 --> Loader Class Initialized
INFO - 2023-02-14 02:51:08 --> Controller Class Initialized
DEBUG - 2023-02-14 02:51:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:51:08 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:08 --> Model "Login_model" initialized
INFO - 2023-02-14 02:51:08 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:08 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:51:08 --> Final output sent to browser
DEBUG - 2023-02-14 02:51:08 --> Total execution time: 0.4339
INFO - 2023-02-14 02:51:08 --> Config Class Initialized
INFO - 2023-02-14 02:51:08 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:51:08 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:51:08 --> Utf8 Class Initialized
INFO - 2023-02-14 02:51:08 --> URI Class Initialized
INFO - 2023-02-14 02:51:08 --> Router Class Initialized
INFO - 2023-02-14 02:51:08 --> Output Class Initialized
INFO - 2023-02-14 02:51:08 --> Security Class Initialized
DEBUG - 2023-02-14 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:51:08 --> Input Class Initialized
INFO - 2023-02-14 02:51:08 --> Language Class Initialized
INFO - 2023-02-14 02:51:08 --> Loader Class Initialized
INFO - 2023-02-14 02:51:08 --> Controller Class Initialized
DEBUG - 2023-02-14 02:51:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:51:08 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:08 --> Model "Login_model" initialized
INFO - 2023-02-14 02:51:08 --> Database Driver Class Initialized
INFO - 2023-02-14 02:51:08 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:51:09 --> Final output sent to browser
DEBUG - 2023-02-14 02:51:09 --> Total execution time: 0.3978
INFO - 2023-02-14 02:52:34 --> Config Class Initialized
INFO - 2023-02-14 02:52:34 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:52:34 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:52:34 --> Utf8 Class Initialized
INFO - 2023-02-14 02:52:34 --> URI Class Initialized
INFO - 2023-02-14 02:52:34 --> Router Class Initialized
INFO - 2023-02-14 02:52:34 --> Output Class Initialized
INFO - 2023-02-14 02:52:34 --> Security Class Initialized
DEBUG - 2023-02-14 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:52:34 --> Input Class Initialized
INFO - 2023-02-14 02:52:34 --> Language Class Initialized
INFO - 2023-02-14 02:52:34 --> Loader Class Initialized
INFO - 2023-02-14 02:52:34 --> Controller Class Initialized
DEBUG - 2023-02-14 02:52:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:52:34 --> Database Driver Class Initialized
INFO - 2023-02-14 02:52:34 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:52:34 --> Final output sent to browser
DEBUG - 2023-02-14 02:52:34 --> Total execution time: 0.0216
INFO - 2023-02-14 02:52:34 --> Config Class Initialized
INFO - 2023-02-14 02:52:34 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:52:34 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:52:34 --> Utf8 Class Initialized
INFO - 2023-02-14 02:52:34 --> URI Class Initialized
INFO - 2023-02-14 02:52:34 --> Router Class Initialized
INFO - 2023-02-14 02:52:34 --> Output Class Initialized
INFO - 2023-02-14 02:52:34 --> Security Class Initialized
DEBUG - 2023-02-14 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:52:34 --> Input Class Initialized
INFO - 2023-02-14 02:52:34 --> Language Class Initialized
INFO - 2023-02-14 02:52:34 --> Loader Class Initialized
INFO - 2023-02-14 02:52:34 --> Controller Class Initialized
DEBUG - 2023-02-14 02:52:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:52:34 --> Database Driver Class Initialized
INFO - 2023-02-14 02:52:34 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:52:34 --> Final output sent to browser
DEBUG - 2023-02-14 02:52:34 --> Total execution time: 0.0162
INFO - 2023-02-14 02:53:24 --> Config Class Initialized
INFO - 2023-02-14 02:53:24 --> Hooks Class Initialized
INFO - 2023-02-14 02:53:24 --> Config Class Initialized
INFO - 2023-02-14 02:53:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:53:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:53:24 --> Utf8 Class Initialized
INFO - 2023-02-14 02:53:24 --> Utf8 Class Initialized
INFO - 2023-02-14 02:53:24 --> URI Class Initialized
INFO - 2023-02-14 02:53:24 --> URI Class Initialized
INFO - 2023-02-14 02:53:24 --> Router Class Initialized
INFO - 2023-02-14 02:53:24 --> Router Class Initialized
INFO - 2023-02-14 02:53:24 --> Output Class Initialized
INFO - 2023-02-14 02:53:24 --> Output Class Initialized
INFO - 2023-02-14 02:53:24 --> Security Class Initialized
INFO - 2023-02-14 02:53:24 --> Security Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:53:24 --> Input Class Initialized
INFO - 2023-02-14 02:53:24 --> Input Class Initialized
INFO - 2023-02-14 02:53:24 --> Language Class Initialized
INFO - 2023-02-14 02:53:24 --> Language Class Initialized
INFO - 2023-02-14 02:53:24 --> Loader Class Initialized
INFO - 2023-02-14 02:53:24 --> Loader Class Initialized
INFO - 2023-02-14 02:53:24 --> Controller Class Initialized
INFO - 2023-02-14 02:53:24 --> Controller Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:53:24 --> Model "Login_model" initialized
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Final output sent to browser
DEBUG - 2023-02-14 02:53:24 --> Total execution time: 0.0205
INFO - 2023-02-14 02:53:24 --> Config Class Initialized
INFO - 2023-02-14 02:53:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:53:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:53:24 --> Utf8 Class Initialized
INFO - 2023-02-14 02:53:24 --> URI Class Initialized
INFO - 2023-02-14 02:53:24 --> Router Class Initialized
INFO - 2023-02-14 02:53:24 --> Output Class Initialized
INFO - 2023-02-14 02:53:24 --> Security Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:53:24 --> Input Class Initialized
INFO - 2023-02-14 02:53:24 --> Language Class Initialized
INFO - 2023-02-14 02:53:24 --> Loader Class Initialized
INFO - 2023-02-14 02:53:24 --> Controller Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:53:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:53:24 --> Final output sent to browser
DEBUG - 2023-02-14 02:53:24 --> Total execution time: 0.0249
INFO - 2023-02-14 02:53:24 --> Final output sent to browser
DEBUG - 2023-02-14 02:53:24 --> Total execution time: 0.4634
INFO - 2023-02-14 02:53:24 --> Config Class Initialized
INFO - 2023-02-14 02:53:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:53:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:53:24 --> Utf8 Class Initialized
INFO - 2023-02-14 02:53:24 --> URI Class Initialized
INFO - 2023-02-14 02:53:24 --> Router Class Initialized
INFO - 2023-02-14 02:53:24 --> Output Class Initialized
INFO - 2023-02-14 02:53:24 --> Security Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:53:24 --> Input Class Initialized
INFO - 2023-02-14 02:53:24 --> Language Class Initialized
INFO - 2023-02-14 02:53:24 --> Loader Class Initialized
INFO - 2023-02-14 02:53:24 --> Controller Class Initialized
DEBUG - 2023-02-14 02:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Model "Login_model" initialized
INFO - 2023-02-14 02:53:24 --> Database Driver Class Initialized
INFO - 2023-02-14 02:53:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:53:24 --> Final output sent to browser
DEBUG - 2023-02-14 02:53:24 --> Total execution time: 0.3867
INFO - 2023-02-14 02:54:21 --> Config Class Initialized
INFO - 2023-02-14 02:54:21 --> Config Class Initialized
INFO - 2023-02-14 02:54:21 --> Hooks Class Initialized
INFO - 2023-02-14 02:54:21 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:54:21 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:54:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:54:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:54:21 --> URI Class Initialized
INFO - 2023-02-14 02:54:21 --> URI Class Initialized
INFO - 2023-02-14 02:54:21 --> Router Class Initialized
INFO - 2023-02-14 02:54:21 --> Router Class Initialized
INFO - 2023-02-14 02:54:21 --> Output Class Initialized
INFO - 2023-02-14 02:54:21 --> Output Class Initialized
INFO - 2023-02-14 02:54:21 --> Security Class Initialized
INFO - 2023-02-14 02:54:21 --> Security Class Initialized
DEBUG - 2023-02-14 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:54:21 --> Input Class Initialized
INFO - 2023-02-14 02:54:21 --> Input Class Initialized
INFO - 2023-02-14 02:54:21 --> Language Class Initialized
INFO - 2023-02-14 02:54:21 --> Language Class Initialized
INFO - 2023-02-14 02:54:21 --> Loader Class Initialized
INFO - 2023-02-14 02:54:21 --> Loader Class Initialized
INFO - 2023-02-14 02:54:21 --> Controller Class Initialized
INFO - 2023-02-14 02:54:21 --> Controller Class Initialized
DEBUG - 2023-02-14 02:54:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:54:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:54:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:21 --> Model "Login_model" initialized
INFO - 2023-02-14 02:54:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:54:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:21 --> Final output sent to browser
DEBUG - 2023-02-14 02:54:21 --> Total execution time: 0.0206
INFO - 2023-02-14 02:54:21 --> Config Class Initialized
INFO - 2023-02-14 02:54:21 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:54:21 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:54:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:54:21 --> URI Class Initialized
INFO - 2023-02-14 02:54:21 --> Router Class Initialized
INFO - 2023-02-14 02:54:21 --> Output Class Initialized
INFO - 2023-02-14 02:54:21 --> Security Class Initialized
DEBUG - 2023-02-14 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:54:21 --> Input Class Initialized
INFO - 2023-02-14 02:54:21 --> Language Class Initialized
INFO - 2023-02-14 02:54:21 --> Loader Class Initialized
INFO - 2023-02-14 02:54:21 --> Controller Class Initialized
DEBUG - 2023-02-14 02:54:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:54:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:54:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:54:21 --> Final output sent to browser
DEBUG - 2023-02-14 02:54:21 --> Total execution time: 0.0152
INFO - 2023-02-14 02:54:22 --> Final output sent to browser
DEBUG - 2023-02-14 02:54:22 --> Total execution time: 0.4005
INFO - 2023-02-14 02:54:22 --> Config Class Initialized
INFO - 2023-02-14 02:54:22 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:54:22 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:54:22 --> Utf8 Class Initialized
INFO - 2023-02-14 02:54:22 --> URI Class Initialized
INFO - 2023-02-14 02:54:22 --> Router Class Initialized
INFO - 2023-02-14 02:54:22 --> Output Class Initialized
INFO - 2023-02-14 02:54:22 --> Security Class Initialized
DEBUG - 2023-02-14 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:54:22 --> Input Class Initialized
INFO - 2023-02-14 02:54:22 --> Language Class Initialized
INFO - 2023-02-14 02:54:22 --> Loader Class Initialized
INFO - 2023-02-14 02:54:22 --> Controller Class Initialized
DEBUG - 2023-02-14 02:54:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:54:22 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:22 --> Model "Login_model" initialized
INFO - 2023-02-14 02:54:22 --> Database Driver Class Initialized
INFO - 2023-02-14 02:54:22 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:54:22 --> Final output sent to browser
DEBUG - 2023-02-14 02:54:22 --> Total execution time: 0.4456
INFO - 2023-02-14 02:55:17 --> Config Class Initialized
INFO - 2023-02-14 02:55:17 --> Config Class Initialized
INFO - 2023-02-14 02:55:17 --> Hooks Class Initialized
INFO - 2023-02-14 02:55:17 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:55:17 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:55:17 --> Utf8 Class Initialized
INFO - 2023-02-14 02:55:17 --> Utf8 Class Initialized
INFO - 2023-02-14 02:55:17 --> URI Class Initialized
INFO - 2023-02-14 02:55:17 --> URI Class Initialized
INFO - 2023-02-14 02:55:17 --> Router Class Initialized
INFO - 2023-02-14 02:55:17 --> Router Class Initialized
INFO - 2023-02-14 02:55:17 --> Output Class Initialized
INFO - 2023-02-14 02:55:17 --> Output Class Initialized
INFO - 2023-02-14 02:55:17 --> Security Class Initialized
INFO - 2023-02-14 02:55:17 --> Security Class Initialized
DEBUG - 2023-02-14 02:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:55:17 --> Input Class Initialized
INFO - 2023-02-14 02:55:17 --> Input Class Initialized
INFO - 2023-02-14 02:55:17 --> Language Class Initialized
INFO - 2023-02-14 02:55:17 --> Language Class Initialized
INFO - 2023-02-14 02:55:17 --> Loader Class Initialized
INFO - 2023-02-14 02:55:17 --> Loader Class Initialized
INFO - 2023-02-14 02:55:17 --> Controller Class Initialized
INFO - 2023-02-14 02:55:17 --> Controller Class Initialized
DEBUG - 2023-02-14 02:55:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:55:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:55:17 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:17 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:17 --> Model "Login_model" initialized
INFO - 2023-02-14 02:55:17 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:55:17 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:17 --> Final output sent to browser
DEBUG - 2023-02-14 02:55:17 --> Total execution time: 0.0217
INFO - 2023-02-14 02:55:17 --> Config Class Initialized
INFO - 2023-02-14 02:55:17 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:55:17 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:55:17 --> Utf8 Class Initialized
INFO - 2023-02-14 02:55:17 --> URI Class Initialized
INFO - 2023-02-14 02:55:17 --> Router Class Initialized
INFO - 2023-02-14 02:55:17 --> Output Class Initialized
INFO - 2023-02-14 02:55:17 --> Security Class Initialized
DEBUG - 2023-02-14 02:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:55:17 --> Input Class Initialized
INFO - 2023-02-14 02:55:17 --> Language Class Initialized
INFO - 2023-02-14 02:55:17 --> Loader Class Initialized
INFO - 2023-02-14 02:55:17 --> Controller Class Initialized
DEBUG - 2023-02-14 02:55:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:55:17 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:17 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:55:17 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:55:17 --> Final output sent to browser
DEBUG - 2023-02-14 02:55:17 --> Total execution time: 0.0191
INFO - 2023-02-14 02:55:18 --> Final output sent to browser
DEBUG - 2023-02-14 02:55:18 --> Total execution time: 0.4610
INFO - 2023-02-14 02:55:18 --> Config Class Initialized
INFO - 2023-02-14 02:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:55:18 --> Utf8 Class Initialized
INFO - 2023-02-14 02:55:18 --> URI Class Initialized
INFO - 2023-02-14 02:55:18 --> Router Class Initialized
INFO - 2023-02-14 02:55:18 --> Output Class Initialized
INFO - 2023-02-14 02:55:18 --> Security Class Initialized
DEBUG - 2023-02-14 02:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:55:18 --> Input Class Initialized
INFO - 2023-02-14 02:55:18 --> Language Class Initialized
INFO - 2023-02-14 02:55:18 --> Loader Class Initialized
INFO - 2023-02-14 02:55:18 --> Controller Class Initialized
DEBUG - 2023-02-14 02:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:55:18 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:18 --> Model "Login_model" initialized
INFO - 2023-02-14 02:55:18 --> Database Driver Class Initialized
INFO - 2023-02-14 02:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:55:18 --> Final output sent to browser
DEBUG - 2023-02-14 02:55:18 --> Total execution time: 0.4306
INFO - 2023-02-14 02:56:10 --> Config Class Initialized
INFO - 2023-02-14 02:56:10 --> Config Class Initialized
INFO - 2023-02-14 02:56:10 --> Hooks Class Initialized
INFO - 2023-02-14 02:56:10 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:56:10 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:56:10 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:56:10 --> Utf8 Class Initialized
INFO - 2023-02-14 02:56:10 --> Utf8 Class Initialized
INFO - 2023-02-14 02:56:10 --> URI Class Initialized
INFO - 2023-02-14 02:56:10 --> URI Class Initialized
INFO - 2023-02-14 02:56:10 --> Router Class Initialized
INFO - 2023-02-14 02:56:10 --> Router Class Initialized
INFO - 2023-02-14 02:56:10 --> Output Class Initialized
INFO - 2023-02-14 02:56:10 --> Output Class Initialized
INFO - 2023-02-14 02:56:10 --> Security Class Initialized
INFO - 2023-02-14 02:56:10 --> Security Class Initialized
DEBUG - 2023-02-14 02:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:56:10 --> Input Class Initialized
INFO - 2023-02-14 02:56:10 --> Input Class Initialized
INFO - 2023-02-14 02:56:10 --> Language Class Initialized
INFO - 2023-02-14 02:56:10 --> Language Class Initialized
INFO - 2023-02-14 02:56:10 --> Loader Class Initialized
INFO - 2023-02-14 02:56:10 --> Loader Class Initialized
INFO - 2023-02-14 02:56:10 --> Controller Class Initialized
INFO - 2023-02-14 02:56:10 --> Controller Class Initialized
DEBUG - 2023-02-14 02:56:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:56:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:56:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:10 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:56:10 --> Model "Login_model" initialized
INFO - 2023-02-14 02:56:10 --> Final output sent to browser
INFO - 2023-02-14 02:56:10 --> Config Class Initialized
INFO - 2023-02-14 02:56:10 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:56:10 --> Total execution time: 0.0210
DEBUG - 2023-02-14 02:56:10 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:56:10 --> Utf8 Class Initialized
INFO - 2023-02-14 02:56:10 --> URI Class Initialized
INFO - 2023-02-14 02:56:10 --> Router Class Initialized
INFO - 2023-02-14 02:56:10 --> Output Class Initialized
INFO - 2023-02-14 02:56:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:10 --> Security Class Initialized
DEBUG - 2023-02-14 02:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:56:10 --> Input Class Initialized
INFO - 2023-02-14 02:56:10 --> Language Class Initialized
INFO - 2023-02-14 02:56:10 --> Loader Class Initialized
INFO - 2023-02-14 02:56:10 --> Controller Class Initialized
DEBUG - 2023-02-14 02:56:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:56:10 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:10 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:56:10 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:56:10 --> Final output sent to browser
DEBUG - 2023-02-14 02:56:10 --> Total execution time: 0.0503
INFO - 2023-02-14 02:56:11 --> Final output sent to browser
DEBUG - 2023-02-14 02:56:11 --> Total execution time: 0.4672
INFO - 2023-02-14 02:56:11 --> Config Class Initialized
INFO - 2023-02-14 02:56:11 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:56:11 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:56:11 --> Utf8 Class Initialized
INFO - 2023-02-14 02:56:11 --> URI Class Initialized
INFO - 2023-02-14 02:56:11 --> Router Class Initialized
INFO - 2023-02-14 02:56:11 --> Output Class Initialized
INFO - 2023-02-14 02:56:11 --> Security Class Initialized
DEBUG - 2023-02-14 02:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:56:11 --> Input Class Initialized
INFO - 2023-02-14 02:56:11 --> Language Class Initialized
INFO - 2023-02-14 02:56:11 --> Loader Class Initialized
INFO - 2023-02-14 02:56:11 --> Controller Class Initialized
DEBUG - 2023-02-14 02:56:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:56:11 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:11 --> Model "Login_model" initialized
INFO - 2023-02-14 02:56:11 --> Database Driver Class Initialized
INFO - 2023-02-14 02:56:11 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:56:11 --> Final output sent to browser
DEBUG - 2023-02-14 02:56:11 --> Total execution time: 0.3985
INFO - 2023-02-14 02:57:21 --> Config Class Initialized
INFO - 2023-02-14 02:57:21 --> Config Class Initialized
INFO - 2023-02-14 02:57:21 --> Hooks Class Initialized
INFO - 2023-02-14 02:57:21 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:57:21 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:57:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:57:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:57:21 --> URI Class Initialized
INFO - 2023-02-14 02:57:21 --> URI Class Initialized
INFO - 2023-02-14 02:57:21 --> Router Class Initialized
INFO - 2023-02-14 02:57:21 --> Router Class Initialized
INFO - 2023-02-14 02:57:21 --> Output Class Initialized
INFO - 2023-02-14 02:57:21 --> Output Class Initialized
INFO - 2023-02-14 02:57:21 --> Security Class Initialized
INFO - 2023-02-14 02:57:21 --> Security Class Initialized
DEBUG - 2023-02-14 02:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:57:21 --> Input Class Initialized
INFO - 2023-02-14 02:57:21 --> Input Class Initialized
INFO - 2023-02-14 02:57:21 --> Language Class Initialized
INFO - 2023-02-14 02:57:21 --> Language Class Initialized
INFO - 2023-02-14 02:57:21 --> Loader Class Initialized
INFO - 2023-02-14 02:57:21 --> Loader Class Initialized
INFO - 2023-02-14 02:57:21 --> Controller Class Initialized
INFO - 2023-02-14 02:57:21 --> Controller Class Initialized
DEBUG - 2023-02-14 02:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:57:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:57:21 --> Model "Login_model" initialized
INFO - 2023-02-14 02:57:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:21 --> Final output sent to browser
DEBUG - 2023-02-14 02:57:21 --> Total execution time: 0.0576
INFO - 2023-02-14 02:57:21 --> Config Class Initialized
INFO - 2023-02-14 02:57:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:57:21 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:57:21 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:57:21 --> Utf8 Class Initialized
INFO - 2023-02-14 02:57:21 --> URI Class Initialized
INFO - 2023-02-14 02:57:21 --> Router Class Initialized
INFO - 2023-02-14 02:57:21 --> Output Class Initialized
INFO - 2023-02-14 02:57:21 --> Security Class Initialized
DEBUG - 2023-02-14 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:57:21 --> Input Class Initialized
INFO - 2023-02-14 02:57:21 --> Language Class Initialized
INFO - 2023-02-14 02:57:21 --> Loader Class Initialized
INFO - 2023-02-14 02:57:21 --> Controller Class Initialized
DEBUG - 2023-02-14 02:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:57:21 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:21 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:57:21 --> Final output sent to browser
DEBUG - 2023-02-14 02:57:21 --> Total execution time: 0.0404
INFO - 2023-02-14 02:57:22 --> Final output sent to browser
DEBUG - 2023-02-14 02:57:22 --> Total execution time: 0.4422
INFO - 2023-02-14 02:57:22 --> Config Class Initialized
INFO - 2023-02-14 02:57:22 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:57:22 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:57:22 --> Utf8 Class Initialized
INFO - 2023-02-14 02:57:22 --> URI Class Initialized
INFO - 2023-02-14 02:57:22 --> Router Class Initialized
INFO - 2023-02-14 02:57:22 --> Output Class Initialized
INFO - 2023-02-14 02:57:22 --> Security Class Initialized
DEBUG - 2023-02-14 02:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:57:22 --> Input Class Initialized
INFO - 2023-02-14 02:57:22 --> Language Class Initialized
INFO - 2023-02-14 02:57:22 --> Loader Class Initialized
INFO - 2023-02-14 02:57:22 --> Controller Class Initialized
DEBUG - 2023-02-14 02:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:57:22 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:22 --> Model "Login_model" initialized
INFO - 2023-02-14 02:57:22 --> Database Driver Class Initialized
INFO - 2023-02-14 02:57:22 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:57:22 --> Final output sent to browser
DEBUG - 2023-02-14 02:57:22 --> Total execution time: 0.4292
INFO - 2023-02-14 02:58:30 --> Config Class Initialized
INFO - 2023-02-14 02:58:30 --> Config Class Initialized
INFO - 2023-02-14 02:58:30 --> Hooks Class Initialized
INFO - 2023-02-14 02:58:30 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:58:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:58:30 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:58:30 --> Utf8 Class Initialized
INFO - 2023-02-14 02:58:30 --> Utf8 Class Initialized
INFO - 2023-02-14 02:58:30 --> URI Class Initialized
INFO - 2023-02-14 02:58:30 --> URI Class Initialized
INFO - 2023-02-14 02:58:30 --> Router Class Initialized
INFO - 2023-02-14 02:58:30 --> Router Class Initialized
INFO - 2023-02-14 02:58:30 --> Output Class Initialized
INFO - 2023-02-14 02:58:30 --> Output Class Initialized
INFO - 2023-02-14 02:58:30 --> Security Class Initialized
INFO - 2023-02-14 02:58:30 --> Security Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:58:30 --> Input Class Initialized
INFO - 2023-02-14 02:58:30 --> Input Class Initialized
INFO - 2023-02-14 02:58:30 --> Language Class Initialized
INFO - 2023-02-14 02:58:30 --> Language Class Initialized
INFO - 2023-02-14 02:58:30 --> Loader Class Initialized
INFO - 2023-02-14 02:58:30 --> Loader Class Initialized
INFO - 2023-02-14 02:58:30 --> Controller Class Initialized
INFO - 2023-02-14 02:58:30 --> Controller Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:58:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:58:30 --> Model "Login_model" initialized
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Final output sent to browser
DEBUG - 2023-02-14 02:58:30 --> Total execution time: 0.0190
INFO - 2023-02-14 02:58:30 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:58:30 --> Config Class Initialized
INFO - 2023-02-14 02:58:30 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:58:30 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:58:30 --> Utf8 Class Initialized
INFO - 2023-02-14 02:58:30 --> URI Class Initialized
INFO - 2023-02-14 02:58:30 --> Router Class Initialized
INFO - 2023-02-14 02:58:30 --> Output Class Initialized
INFO - 2023-02-14 02:58:30 --> Security Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:58:30 --> Input Class Initialized
INFO - 2023-02-14 02:58:30 --> Language Class Initialized
INFO - 2023-02-14 02:58:30 --> Loader Class Initialized
INFO - 2023-02-14 02:58:30 --> Controller Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:58:30 --> Final output sent to browser
DEBUG - 2023-02-14 02:58:30 --> Total execution time: 0.0164
INFO - 2023-02-14 02:58:30 --> Final output sent to browser
DEBUG - 2023-02-14 02:58:30 --> Total execution time: 0.4360
INFO - 2023-02-14 02:58:30 --> Config Class Initialized
INFO - 2023-02-14 02:58:30 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:58:30 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:58:30 --> Utf8 Class Initialized
INFO - 2023-02-14 02:58:30 --> URI Class Initialized
INFO - 2023-02-14 02:58:30 --> Router Class Initialized
INFO - 2023-02-14 02:58:30 --> Output Class Initialized
INFO - 2023-02-14 02:58:30 --> Security Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:58:30 --> Input Class Initialized
INFO - 2023-02-14 02:58:30 --> Language Class Initialized
INFO - 2023-02-14 02:58:30 --> Loader Class Initialized
INFO - 2023-02-14 02:58:30 --> Controller Class Initialized
DEBUG - 2023-02-14 02:58:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Model "Login_model" initialized
INFO - 2023-02-14 02:58:30 --> Database Driver Class Initialized
INFO - 2023-02-14 02:58:30 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:58:31 --> Final output sent to browser
DEBUG - 2023-02-14 02:58:31 --> Total execution time: 0.4526
INFO - 2023-02-14 02:59:25 --> Config Class Initialized
INFO - 2023-02-14 02:59:25 --> Config Class Initialized
INFO - 2023-02-14 02:59:25 --> Hooks Class Initialized
INFO - 2023-02-14 02:59:25 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:59:25 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 02:59:25 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:59:25 --> Utf8 Class Initialized
INFO - 2023-02-14 02:59:25 --> Utf8 Class Initialized
INFO - 2023-02-14 02:59:25 --> URI Class Initialized
INFO - 2023-02-14 02:59:25 --> URI Class Initialized
INFO - 2023-02-14 02:59:25 --> Router Class Initialized
INFO - 2023-02-14 02:59:25 --> Router Class Initialized
INFO - 2023-02-14 02:59:25 --> Output Class Initialized
INFO - 2023-02-14 02:59:25 --> Output Class Initialized
INFO - 2023-02-14 02:59:25 --> Security Class Initialized
INFO - 2023-02-14 02:59:25 --> Security Class Initialized
DEBUG - 2023-02-14 02:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 02:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:59:25 --> Input Class Initialized
INFO - 2023-02-14 02:59:25 --> Input Class Initialized
INFO - 2023-02-14 02:59:25 --> Language Class Initialized
INFO - 2023-02-14 02:59:25 --> Language Class Initialized
INFO - 2023-02-14 02:59:25 --> Loader Class Initialized
INFO - 2023-02-14 02:59:25 --> Loader Class Initialized
INFO - 2023-02-14 02:59:25 --> Controller Class Initialized
INFO - 2023-02-14 02:59:25 --> Controller Class Initialized
DEBUG - 2023-02-14 02:59:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 02:59:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:59:25 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:25 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:25 --> Model "Login_model" initialized
INFO - 2023-02-14 02:59:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:59:25 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:25 --> Final output sent to browser
DEBUG - 2023-02-14 02:59:25 --> Total execution time: 0.0219
INFO - 2023-02-14 02:59:25 --> Config Class Initialized
INFO - 2023-02-14 02:59:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:59:25 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:59:25 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:59:25 --> Utf8 Class Initialized
INFO - 2023-02-14 02:59:25 --> URI Class Initialized
INFO - 2023-02-14 02:59:25 --> Router Class Initialized
INFO - 2023-02-14 02:59:25 --> Output Class Initialized
INFO - 2023-02-14 02:59:25 --> Security Class Initialized
DEBUG - 2023-02-14 02:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:59:25 --> Input Class Initialized
INFO - 2023-02-14 02:59:25 --> Language Class Initialized
INFO - 2023-02-14 02:59:25 --> Loader Class Initialized
INFO - 2023-02-14 02:59:25 --> Controller Class Initialized
DEBUG - 2023-02-14 02:59:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:59:25 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:59:25 --> Final output sent to browser
DEBUG - 2023-02-14 02:59:25 --> Total execution time: 0.0446
INFO - 2023-02-14 02:59:26 --> Final output sent to browser
DEBUG - 2023-02-14 02:59:26 --> Total execution time: 0.4066
INFO - 2023-02-14 02:59:26 --> Config Class Initialized
INFO - 2023-02-14 02:59:26 --> Hooks Class Initialized
DEBUG - 2023-02-14 02:59:26 --> UTF-8 Support Enabled
INFO - 2023-02-14 02:59:26 --> Utf8 Class Initialized
INFO - 2023-02-14 02:59:26 --> URI Class Initialized
INFO - 2023-02-14 02:59:26 --> Router Class Initialized
INFO - 2023-02-14 02:59:26 --> Output Class Initialized
INFO - 2023-02-14 02:59:26 --> Security Class Initialized
DEBUG - 2023-02-14 02:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 02:59:26 --> Input Class Initialized
INFO - 2023-02-14 02:59:26 --> Language Class Initialized
INFO - 2023-02-14 02:59:26 --> Loader Class Initialized
INFO - 2023-02-14 02:59:26 --> Controller Class Initialized
DEBUG - 2023-02-14 02:59:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 02:59:26 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:26 --> Model "Login_model" initialized
INFO - 2023-02-14 02:59:26 --> Database Driver Class Initialized
INFO - 2023-02-14 02:59:26 --> Model "Cluster_model" initialized
INFO - 2023-02-14 02:59:26 --> Final output sent to browser
DEBUG - 2023-02-14 02:59:26 --> Total execution time: 0.3832
INFO - 2023-02-14 03:00:25 --> Config Class Initialized
INFO - 2023-02-14 03:00:25 --> Config Class Initialized
INFO - 2023-02-14 03:00:25 --> Hooks Class Initialized
INFO - 2023-02-14 03:00:25 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:00:25 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:00:25 --> Utf8 Class Initialized
INFO - 2023-02-14 03:00:25 --> Utf8 Class Initialized
INFO - 2023-02-14 03:00:25 --> URI Class Initialized
INFO - 2023-02-14 03:00:25 --> URI Class Initialized
INFO - 2023-02-14 03:00:25 --> Router Class Initialized
INFO - 2023-02-14 03:00:25 --> Router Class Initialized
INFO - 2023-02-14 03:00:25 --> Output Class Initialized
INFO - 2023-02-14 03:00:25 --> Output Class Initialized
INFO - 2023-02-14 03:00:25 --> Security Class Initialized
INFO - 2023-02-14 03:00:25 --> Security Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:00:25 --> Input Class Initialized
INFO - 2023-02-14 03:00:25 --> Input Class Initialized
INFO - 2023-02-14 03:00:25 --> Language Class Initialized
INFO - 2023-02-14 03:00:25 --> Language Class Initialized
INFO - 2023-02-14 03:00:25 --> Loader Class Initialized
INFO - 2023-02-14 03:00:25 --> Loader Class Initialized
INFO - 2023-02-14 03:00:25 --> Controller Class Initialized
INFO - 2023-02-14 03:00:25 --> Controller Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Model "Login_model" initialized
INFO - 2023-02-14 03:00:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Final output sent to browser
DEBUG - 2023-02-14 03:00:25 --> Total execution time: 0.0190
INFO - 2023-02-14 03:00:25 --> Config Class Initialized
INFO - 2023-02-14 03:00:25 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:00:25 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:00:25 --> Utf8 Class Initialized
INFO - 2023-02-14 03:00:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:00:25 --> URI Class Initialized
INFO - 2023-02-14 03:00:25 --> Router Class Initialized
INFO - 2023-02-14 03:00:25 --> Output Class Initialized
INFO - 2023-02-14 03:00:25 --> Security Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:00:25 --> Input Class Initialized
INFO - 2023-02-14 03:00:25 --> Language Class Initialized
INFO - 2023-02-14 03:00:25 --> Loader Class Initialized
INFO - 2023-02-14 03:00:25 --> Controller Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:00:25 --> Final output sent to browser
DEBUG - 2023-02-14 03:00:25 --> Total execution time: 0.0171
INFO - 2023-02-14 03:00:25 --> Final output sent to browser
DEBUG - 2023-02-14 03:00:25 --> Total execution time: 0.3912
INFO - 2023-02-14 03:00:25 --> Config Class Initialized
INFO - 2023-02-14 03:00:25 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:00:25 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:00:25 --> Utf8 Class Initialized
INFO - 2023-02-14 03:00:25 --> URI Class Initialized
INFO - 2023-02-14 03:00:25 --> Router Class Initialized
INFO - 2023-02-14 03:00:25 --> Output Class Initialized
INFO - 2023-02-14 03:00:25 --> Security Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:00:25 --> Input Class Initialized
INFO - 2023-02-14 03:00:25 --> Language Class Initialized
INFO - 2023-02-14 03:00:25 --> Loader Class Initialized
INFO - 2023-02-14 03:00:25 --> Controller Class Initialized
DEBUG - 2023-02-14 03:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Model "Login_model" initialized
INFO - 2023-02-14 03:00:25 --> Database Driver Class Initialized
INFO - 2023-02-14 03:00:25 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:00:26 --> Final output sent to browser
DEBUG - 2023-02-14 03:00:26 --> Total execution time: 0.3956
INFO - 2023-02-14 03:01:24 --> Config Class Initialized
INFO - 2023-02-14 03:01:24 --> Config Class Initialized
INFO - 2023-02-14 03:01:24 --> Hooks Class Initialized
INFO - 2023-02-14 03:01:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:01:24 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:01:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:01:24 --> Utf8 Class Initialized
INFO - 2023-02-14 03:01:24 --> Utf8 Class Initialized
INFO - 2023-02-14 03:01:24 --> URI Class Initialized
INFO - 2023-02-14 03:01:24 --> URI Class Initialized
INFO - 2023-02-14 03:01:24 --> Router Class Initialized
INFO - 2023-02-14 03:01:24 --> Router Class Initialized
INFO - 2023-02-14 03:01:24 --> Output Class Initialized
INFO - 2023-02-14 03:01:24 --> Output Class Initialized
INFO - 2023-02-14 03:01:24 --> Security Class Initialized
INFO - 2023-02-14 03:01:24 --> Security Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:01:24 --> Input Class Initialized
INFO - 2023-02-14 03:01:24 --> Input Class Initialized
INFO - 2023-02-14 03:01:24 --> Language Class Initialized
INFO - 2023-02-14 03:01:24 --> Language Class Initialized
INFO - 2023-02-14 03:01:24 --> Loader Class Initialized
INFO - 2023-02-14 03:01:24 --> Loader Class Initialized
INFO - 2023-02-14 03:01:24 --> Controller Class Initialized
INFO - 2023-02-14 03:01:24 --> Controller Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:01:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:01:24 --> Model "Login_model" initialized
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Final output sent to browser
DEBUG - 2023-02-14 03:01:24 --> Total execution time: 0.0200
INFO - 2023-02-14 03:01:24 --> Config Class Initialized
INFO - 2023-02-14 03:01:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:01:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:01:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:01:24 --> Utf8 Class Initialized
INFO - 2023-02-14 03:01:24 --> URI Class Initialized
INFO - 2023-02-14 03:01:24 --> Router Class Initialized
INFO - 2023-02-14 03:01:24 --> Output Class Initialized
INFO - 2023-02-14 03:01:24 --> Security Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:01:24 --> Input Class Initialized
INFO - 2023-02-14 03:01:24 --> Language Class Initialized
INFO - 2023-02-14 03:01:24 --> Loader Class Initialized
INFO - 2023-02-14 03:01:24 --> Controller Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:01:24 --> Final output sent to browser
DEBUG - 2023-02-14 03:01:24 --> Total execution time: 0.0584
INFO - 2023-02-14 03:01:24 --> Final output sent to browser
DEBUG - 2023-02-14 03:01:24 --> Total execution time: 0.4279
INFO - 2023-02-14 03:01:24 --> Config Class Initialized
INFO - 2023-02-14 03:01:24 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:01:24 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:01:24 --> Utf8 Class Initialized
INFO - 2023-02-14 03:01:24 --> URI Class Initialized
INFO - 2023-02-14 03:01:24 --> Router Class Initialized
INFO - 2023-02-14 03:01:24 --> Output Class Initialized
INFO - 2023-02-14 03:01:24 --> Security Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:01:24 --> Input Class Initialized
INFO - 2023-02-14 03:01:24 --> Language Class Initialized
INFO - 2023-02-14 03:01:24 --> Loader Class Initialized
INFO - 2023-02-14 03:01:24 --> Controller Class Initialized
DEBUG - 2023-02-14 03:01:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Model "Login_model" initialized
INFO - 2023-02-14 03:01:24 --> Database Driver Class Initialized
INFO - 2023-02-14 03:01:24 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:01:25 --> Final output sent to browser
DEBUG - 2023-02-14 03:01:25 --> Total execution time: 0.5162
INFO - 2023-02-14 03:02:07 --> Config Class Initialized
INFO - 2023-02-14 03:02:07 --> Config Class Initialized
INFO - 2023-02-14 03:02:07 --> Hooks Class Initialized
INFO - 2023-02-14 03:02:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:02:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:02:07 --> Utf8 Class Initialized
DEBUG - 2023-02-14 03:02:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:02:07 --> URI Class Initialized
INFO - 2023-02-14 03:02:07 --> Utf8 Class Initialized
INFO - 2023-02-14 03:02:07 --> Router Class Initialized
INFO - 2023-02-14 03:02:07 --> URI Class Initialized
INFO - 2023-02-14 03:02:07 --> Output Class Initialized
INFO - 2023-02-14 03:02:07 --> Router Class Initialized
INFO - 2023-02-14 03:02:07 --> Security Class Initialized
INFO - 2023-02-14 03:02:07 --> Output Class Initialized
DEBUG - 2023-02-14 03:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:02:07 --> Security Class Initialized
INFO - 2023-02-14 03:02:07 --> Input Class Initialized
DEBUG - 2023-02-14 03:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:02:07 --> Input Class Initialized
INFO - 2023-02-14 03:02:07 --> Language Class Initialized
INFO - 2023-02-14 03:02:07 --> Language Class Initialized
INFO - 2023-02-14 03:02:07 --> Loader Class Initialized
INFO - 2023-02-14 03:02:07 --> Loader Class Initialized
INFO - 2023-02-14 03:02:07 --> Controller Class Initialized
INFO - 2023-02-14 03:02:07 --> Controller Class Initialized
DEBUG - 2023-02-14 03:02:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:02:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:02:07 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:07 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:07 --> Model "Login_model" initialized
INFO - 2023-02-14 03:02:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:02:07 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:07 --> Final output sent to browser
DEBUG - 2023-02-14 03:02:07 --> Total execution time: 0.0218
INFO - 2023-02-14 03:02:07 --> Config Class Initialized
INFO - 2023-02-14 03:02:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:02:07 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:02:07 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:02:07 --> Utf8 Class Initialized
INFO - 2023-02-14 03:02:07 --> URI Class Initialized
INFO - 2023-02-14 03:02:07 --> Router Class Initialized
INFO - 2023-02-14 03:02:07 --> Output Class Initialized
INFO - 2023-02-14 03:02:07 --> Security Class Initialized
DEBUG - 2023-02-14 03:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:02:07 --> Input Class Initialized
INFO - 2023-02-14 03:02:07 --> Language Class Initialized
INFO - 2023-02-14 03:02:07 --> Loader Class Initialized
INFO - 2023-02-14 03:02:07 --> Controller Class Initialized
DEBUG - 2023-02-14 03:02:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:02:07 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:07 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:02:07 --> Final output sent to browser
DEBUG - 2023-02-14 03:02:07 --> Total execution time: 0.0163
INFO - 2023-02-14 03:02:08 --> Final output sent to browser
DEBUG - 2023-02-14 03:02:08 --> Total execution time: 0.3881
INFO - 2023-02-14 03:02:08 --> Config Class Initialized
INFO - 2023-02-14 03:02:08 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:02:08 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:02:08 --> Utf8 Class Initialized
INFO - 2023-02-14 03:02:08 --> URI Class Initialized
INFO - 2023-02-14 03:02:08 --> Router Class Initialized
INFO - 2023-02-14 03:02:08 --> Output Class Initialized
INFO - 2023-02-14 03:02:08 --> Security Class Initialized
DEBUG - 2023-02-14 03:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:02:08 --> Input Class Initialized
INFO - 2023-02-14 03:02:08 --> Language Class Initialized
INFO - 2023-02-14 03:02:08 --> Loader Class Initialized
INFO - 2023-02-14 03:02:08 --> Controller Class Initialized
DEBUG - 2023-02-14 03:02:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:02:08 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:08 --> Model "Login_model" initialized
INFO - 2023-02-14 03:02:08 --> Database Driver Class Initialized
INFO - 2023-02-14 03:02:08 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:02:08 --> Final output sent to browser
DEBUG - 2023-02-14 03:02:08 --> Total execution time: 0.3765
INFO - 2023-02-14 03:21:26 --> Config Class Initialized
INFO - 2023-02-14 03:21:26 --> Config Class Initialized
INFO - 2023-02-14 03:21:26 --> Hooks Class Initialized
INFO - 2023-02-14 03:21:26 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:21:26 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:21:26 --> Utf8 Class Initialized
INFO - 2023-02-14 03:21:26 --> Utf8 Class Initialized
INFO - 2023-02-14 03:21:26 --> URI Class Initialized
INFO - 2023-02-14 03:21:26 --> URI Class Initialized
INFO - 2023-02-14 03:21:26 --> Router Class Initialized
INFO - 2023-02-14 03:21:26 --> Router Class Initialized
INFO - 2023-02-14 03:21:26 --> Output Class Initialized
INFO - 2023-02-14 03:21:26 --> Output Class Initialized
INFO - 2023-02-14 03:21:26 --> Security Class Initialized
INFO - 2023-02-14 03:21:26 --> Security Class Initialized
DEBUG - 2023-02-14 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:21:26 --> Input Class Initialized
INFO - 2023-02-14 03:21:26 --> Input Class Initialized
INFO - 2023-02-14 03:21:26 --> Language Class Initialized
INFO - 2023-02-14 03:21:26 --> Language Class Initialized
INFO - 2023-02-14 03:21:26 --> Loader Class Initialized
INFO - 2023-02-14 03:21:26 --> Loader Class Initialized
INFO - 2023-02-14 03:21:26 --> Controller Class Initialized
INFO - 2023-02-14 03:21:26 --> Controller Class Initialized
DEBUG - 2023-02-14 03:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:21:26 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:26 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:21:26 --> Model "Login_model" initialized
INFO - 2023-02-14 03:21:26 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:26 --> Final output sent to browser
DEBUG - 2023-02-14 03:21:26 --> Total execution time: 0.0809
INFO - 2023-02-14 03:21:26 --> Config Class Initialized
INFO - 2023-02-14 03:21:26 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:21:26 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:21:26 --> Utf8 Class Initialized
INFO - 2023-02-14 03:21:26 --> URI Class Initialized
INFO - 2023-02-14 03:21:26 --> Router Class Initialized
INFO - 2023-02-14 03:21:26 --> Output Class Initialized
INFO - 2023-02-14 03:21:26 --> Security Class Initialized
DEBUG - 2023-02-14 03:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:21:26 --> Input Class Initialized
INFO - 2023-02-14 03:21:26 --> Language Class Initialized
INFO - 2023-02-14 03:21:26 --> Loader Class Initialized
INFO - 2023-02-14 03:21:26 --> Controller Class Initialized
DEBUG - 2023-02-14 03:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:21:26 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:21:26 --> Final output sent to browser
DEBUG - 2023-02-14 03:21:26 --> Total execution time: 0.0767
INFO - 2023-02-14 03:21:28 --> Final output sent to browser
DEBUG - 2023-02-14 03:21:28 --> Total execution time: 1.3281
INFO - 2023-02-14 03:21:28 --> Config Class Initialized
INFO - 2023-02-14 03:21:28 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:21:28 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:21:28 --> Utf8 Class Initialized
INFO - 2023-02-14 03:21:28 --> URI Class Initialized
INFO - 2023-02-14 03:21:28 --> Router Class Initialized
INFO - 2023-02-14 03:21:28 --> Output Class Initialized
INFO - 2023-02-14 03:21:28 --> Security Class Initialized
DEBUG - 2023-02-14 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:21:28 --> Input Class Initialized
INFO - 2023-02-14 03:21:28 --> Language Class Initialized
INFO - 2023-02-14 03:21:28 --> Loader Class Initialized
INFO - 2023-02-14 03:21:28 --> Controller Class Initialized
DEBUG - 2023-02-14 03:21:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:21:28 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:28 --> Model "Login_model" initialized
INFO - 2023-02-14 03:21:28 --> Database Driver Class Initialized
INFO - 2023-02-14 03:21:28 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:21:29 --> Final output sent to browser
DEBUG - 2023-02-14 03:21:29 --> Total execution time: 1.0752
INFO - 2023-02-14 03:26:42 --> Config Class Initialized
INFO - 2023-02-14 03:26:42 --> Config Class Initialized
INFO - 2023-02-14 03:26:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:26:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:26:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:26:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:26:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:26:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:26:42 --> URI Class Initialized
INFO - 2023-02-14 03:26:42 --> URI Class Initialized
INFO - 2023-02-14 03:26:42 --> Router Class Initialized
INFO - 2023-02-14 03:26:42 --> Router Class Initialized
INFO - 2023-02-14 03:26:42 --> Output Class Initialized
INFO - 2023-02-14 03:26:42 --> Output Class Initialized
INFO - 2023-02-14 03:26:42 --> Security Class Initialized
INFO - 2023-02-14 03:26:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:26:42 --> Input Class Initialized
INFO - 2023-02-14 03:26:42 --> Language Class Initialized
INFO - 2023-02-14 03:26:42 --> Input Class Initialized
INFO - 2023-02-14 03:26:42 --> Language Class Initialized
INFO - 2023-02-14 03:26:42 --> Loader Class Initialized
INFO - 2023-02-14 03:26:42 --> Controller Class Initialized
INFO - 2023-02-14 03:26:42 --> Loader Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:26:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:26:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:26:42 --> Total execution time: 0.0209
INFO - 2023-02-14 03:26:42 --> Config Class Initialized
INFO - 2023-02-14 03:26:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:26:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:26:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:26:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:26:42 --> URI Class Initialized
INFO - 2023-02-14 03:26:42 --> Router Class Initialized
INFO - 2023-02-14 03:26:42 --> Output Class Initialized
INFO - 2023-02-14 03:26:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:26:42 --> Input Class Initialized
INFO - 2023-02-14 03:26:42 --> Language Class Initialized
INFO - 2023-02-14 03:26:42 --> Loader Class Initialized
INFO - 2023-02-14 03:26:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:26:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:26:42 --> Total execution time: 0.0501
INFO - 2023-02-14 03:26:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:26:42 --> Total execution time: 0.4306
INFO - 2023-02-14 03:26:42 --> Config Class Initialized
INFO - 2023-02-14 03:26:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:26:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:26:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:26:42 --> URI Class Initialized
INFO - 2023-02-14 03:26:42 --> Router Class Initialized
INFO - 2023-02-14 03:26:42 --> Output Class Initialized
INFO - 2023-02-14 03:26:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:26:42 --> Input Class Initialized
INFO - 2023-02-14 03:26:42 --> Language Class Initialized
INFO - 2023-02-14 03:26:42 --> Loader Class Initialized
INFO - 2023-02-14 03:26:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:26:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:26:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:26:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:26:43 --> Total execution time: 0.4230
INFO - 2023-02-14 03:27:47 --> Config Class Initialized
INFO - 2023-02-14 03:27:47 --> Hooks Class Initialized
INFO - 2023-02-14 03:27:47 --> Config Class Initialized
INFO - 2023-02-14 03:27:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:27:47 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:27:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:27:47 --> Utf8 Class Initialized
INFO - 2023-02-14 03:27:47 --> Utf8 Class Initialized
INFO - 2023-02-14 03:27:47 --> URI Class Initialized
INFO - 2023-02-14 03:27:47 --> URI Class Initialized
INFO - 2023-02-14 03:27:47 --> Router Class Initialized
INFO - 2023-02-14 03:27:47 --> Router Class Initialized
INFO - 2023-02-14 03:27:47 --> Output Class Initialized
INFO - 2023-02-14 03:27:47 --> Output Class Initialized
INFO - 2023-02-14 03:27:47 --> Security Class Initialized
INFO - 2023-02-14 03:27:47 --> Security Class Initialized
DEBUG - 2023-02-14 03:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:27:47 --> Input Class Initialized
INFO - 2023-02-14 03:27:47 --> Input Class Initialized
INFO - 2023-02-14 03:27:47 --> Language Class Initialized
INFO - 2023-02-14 03:27:47 --> Language Class Initialized
INFO - 2023-02-14 03:27:47 --> Loader Class Initialized
INFO - 2023-02-14 03:27:47 --> Loader Class Initialized
INFO - 2023-02-14 03:27:47 --> Controller Class Initialized
INFO - 2023-02-14 03:27:47 --> Controller Class Initialized
DEBUG - 2023-02-14 03:27:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:27:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:27:47 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:47 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:47 --> Model "Login_model" initialized
INFO - 2023-02-14 03:27:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:27:47 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:47 --> Final output sent to browser
DEBUG - 2023-02-14 03:27:47 --> Total execution time: 0.0300
INFO - 2023-02-14 03:27:47 --> Config Class Initialized
INFO - 2023-02-14 03:27:47 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:27:47 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:27:47 --> Utf8 Class Initialized
INFO - 2023-02-14 03:27:47 --> URI Class Initialized
INFO - 2023-02-14 03:27:47 --> Router Class Initialized
INFO - 2023-02-14 03:27:47 --> Output Class Initialized
INFO - 2023-02-14 03:27:47 --> Security Class Initialized
DEBUG - 2023-02-14 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:27:47 --> Input Class Initialized
INFO - 2023-02-14 03:27:47 --> Language Class Initialized
INFO - 2023-02-14 03:27:47 --> Loader Class Initialized
INFO - 2023-02-14 03:27:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:27:47 --> Controller Class Initialized
DEBUG - 2023-02-14 03:27:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:27:47 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:47 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:27:47 --> Final output sent to browser
DEBUG - 2023-02-14 03:27:47 --> Total execution time: 0.0156
INFO - 2023-02-14 03:27:48 --> Final output sent to browser
DEBUG - 2023-02-14 03:27:48 --> Total execution time: 0.4336
INFO - 2023-02-14 03:27:48 --> Config Class Initialized
INFO - 2023-02-14 03:27:48 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:27:48 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:27:48 --> Utf8 Class Initialized
INFO - 2023-02-14 03:27:48 --> URI Class Initialized
INFO - 2023-02-14 03:27:48 --> Router Class Initialized
INFO - 2023-02-14 03:27:48 --> Output Class Initialized
INFO - 2023-02-14 03:27:48 --> Security Class Initialized
DEBUG - 2023-02-14 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:27:48 --> Input Class Initialized
INFO - 2023-02-14 03:27:48 --> Language Class Initialized
INFO - 2023-02-14 03:27:48 --> Loader Class Initialized
INFO - 2023-02-14 03:27:48 --> Controller Class Initialized
DEBUG - 2023-02-14 03:27:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:27:48 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:48 --> Model "Login_model" initialized
INFO - 2023-02-14 03:27:48 --> Database Driver Class Initialized
INFO - 2023-02-14 03:27:48 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:27:48 --> Final output sent to browser
DEBUG - 2023-02-14 03:27:48 --> Total execution time: 0.4309
INFO - 2023-02-14 03:28:51 --> Config Class Initialized
INFO - 2023-02-14 03:28:51 --> Config Class Initialized
INFO - 2023-02-14 03:28:51 --> Hooks Class Initialized
INFO - 2023-02-14 03:28:51 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:28:51 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:28:51 --> Utf8 Class Initialized
INFO - 2023-02-14 03:28:51 --> Utf8 Class Initialized
INFO - 2023-02-14 03:28:51 --> URI Class Initialized
INFO - 2023-02-14 03:28:51 --> URI Class Initialized
INFO - 2023-02-14 03:28:51 --> Router Class Initialized
INFO - 2023-02-14 03:28:51 --> Router Class Initialized
INFO - 2023-02-14 03:28:51 --> Output Class Initialized
INFO - 2023-02-14 03:28:51 --> Output Class Initialized
INFO - 2023-02-14 03:28:51 --> Security Class Initialized
INFO - 2023-02-14 03:28:51 --> Security Class Initialized
DEBUG - 2023-02-14 03:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:28:51 --> Input Class Initialized
INFO - 2023-02-14 03:28:51 --> Input Class Initialized
INFO - 2023-02-14 03:28:51 --> Language Class Initialized
INFO - 2023-02-14 03:28:51 --> Language Class Initialized
INFO - 2023-02-14 03:28:51 --> Loader Class Initialized
INFO - 2023-02-14 03:28:51 --> Loader Class Initialized
INFO - 2023-02-14 03:28:51 --> Controller Class Initialized
INFO - 2023-02-14 03:28:51 --> Controller Class Initialized
DEBUG - 2023-02-14 03:28:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:28:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:28:51 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:51 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:51 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:28:51 --> Model "Login_model" initialized
INFO - 2023-02-14 03:28:51 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:51 --> Final output sent to browser
DEBUG - 2023-02-14 03:28:51 --> Total execution time: 0.0254
INFO - 2023-02-14 03:28:51 --> Config Class Initialized
INFO - 2023-02-14 03:28:51 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:28:51 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:28:51 --> Utf8 Class Initialized
INFO - 2023-02-14 03:28:51 --> URI Class Initialized
INFO - 2023-02-14 03:28:51 --> Router Class Initialized
INFO - 2023-02-14 03:28:51 --> Output Class Initialized
INFO - 2023-02-14 03:28:51 --> Security Class Initialized
DEBUG - 2023-02-14 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:28:51 --> Input Class Initialized
INFO - 2023-02-14 03:28:51 --> Language Class Initialized
INFO - 2023-02-14 03:28:51 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:28:51 --> Loader Class Initialized
INFO - 2023-02-14 03:28:51 --> Controller Class Initialized
DEBUG - 2023-02-14 03:28:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:28:51 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:51 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:28:51 --> Final output sent to browser
DEBUG - 2023-02-14 03:28:51 --> Total execution time: 0.0146
INFO - 2023-02-14 03:28:52 --> Final output sent to browser
DEBUG - 2023-02-14 03:28:52 --> Total execution time: 0.4311
INFO - 2023-02-14 03:28:52 --> Config Class Initialized
INFO - 2023-02-14 03:28:52 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:28:52 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:28:52 --> Utf8 Class Initialized
INFO - 2023-02-14 03:28:52 --> URI Class Initialized
INFO - 2023-02-14 03:28:52 --> Router Class Initialized
INFO - 2023-02-14 03:28:52 --> Output Class Initialized
INFO - 2023-02-14 03:28:52 --> Security Class Initialized
DEBUG - 2023-02-14 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:28:52 --> Input Class Initialized
INFO - 2023-02-14 03:28:52 --> Language Class Initialized
INFO - 2023-02-14 03:28:52 --> Loader Class Initialized
INFO - 2023-02-14 03:28:52 --> Controller Class Initialized
DEBUG - 2023-02-14 03:28:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:28:52 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:52 --> Model "Login_model" initialized
INFO - 2023-02-14 03:28:52 --> Database Driver Class Initialized
INFO - 2023-02-14 03:28:52 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:28:52 --> Final output sent to browser
DEBUG - 2023-02-14 03:28:52 --> Total execution time: 0.4288
INFO - 2023-02-14 03:29:42 --> Config Class Initialized
INFO - 2023-02-14 03:29:42 --> Config Class Initialized
INFO - 2023-02-14 03:29:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:29:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:29:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:29:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:29:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:29:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:29:42 --> URI Class Initialized
INFO - 2023-02-14 03:29:42 --> URI Class Initialized
INFO - 2023-02-14 03:29:42 --> Router Class Initialized
INFO - 2023-02-14 03:29:42 --> Router Class Initialized
INFO - 2023-02-14 03:29:42 --> Output Class Initialized
INFO - 2023-02-14 03:29:42 --> Output Class Initialized
INFO - 2023-02-14 03:29:42 --> Security Class Initialized
INFO - 2023-02-14 03:29:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:29:42 --> Input Class Initialized
INFO - 2023-02-14 03:29:42 --> Input Class Initialized
INFO - 2023-02-14 03:29:42 --> Language Class Initialized
INFO - 2023-02-14 03:29:42 --> Language Class Initialized
INFO - 2023-02-14 03:29:42 --> Loader Class Initialized
INFO - 2023-02-14 03:29:42 --> Loader Class Initialized
INFO - 2023-02-14 03:29:42 --> Controller Class Initialized
INFO - 2023-02-14 03:29:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:29:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:29:42 --> Total execution time: 0.0279
INFO - 2023-02-14 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:29:42 --> Config Class Initialized
INFO - 2023-02-14 03:29:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:29:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:29:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:29:42 --> URI Class Initialized
INFO - 2023-02-14 03:29:42 --> Router Class Initialized
INFO - 2023-02-14 03:29:42 --> Output Class Initialized
INFO - 2023-02-14 03:29:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:29:42 --> Input Class Initialized
INFO - 2023-02-14 03:29:42 --> Language Class Initialized
INFO - 2023-02-14 03:29:42 --> Loader Class Initialized
INFO - 2023-02-14 03:29:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:29:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:29:42 --> Total execution time: 0.0351
INFO - 2023-02-14 03:29:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:29:42 --> Total execution time: 0.5070
INFO - 2023-02-14 03:29:42 --> Config Class Initialized
INFO - 2023-02-14 03:29:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:29:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:29:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:29:42 --> URI Class Initialized
INFO - 2023-02-14 03:29:42 --> Router Class Initialized
INFO - 2023-02-14 03:29:42 --> Output Class Initialized
INFO - 2023-02-14 03:29:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:29:42 --> Input Class Initialized
INFO - 2023-02-14 03:29:42 --> Language Class Initialized
INFO - 2023-02-14 03:29:42 --> Loader Class Initialized
INFO - 2023-02-14 03:29:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:29:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:29:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:29:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:29:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:29:43 --> Total execution time: 0.4678
INFO - 2023-02-14 03:31:05 --> Config Class Initialized
INFO - 2023-02-14 03:31:05 --> Config Class Initialized
INFO - 2023-02-14 03:31:05 --> Hooks Class Initialized
INFO - 2023-02-14 03:31:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:31:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:31:05 --> Utf8 Class Initialized
INFO - 2023-02-14 03:31:05 --> Utf8 Class Initialized
INFO - 2023-02-14 03:31:05 --> URI Class Initialized
INFO - 2023-02-14 03:31:05 --> URI Class Initialized
INFO - 2023-02-14 03:31:05 --> Router Class Initialized
INFO - 2023-02-14 03:31:05 --> Router Class Initialized
INFO - 2023-02-14 03:31:05 --> Output Class Initialized
INFO - 2023-02-14 03:31:05 --> Output Class Initialized
INFO - 2023-02-14 03:31:05 --> Security Class Initialized
INFO - 2023-02-14 03:31:05 --> Security Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:31:05 --> Input Class Initialized
INFO - 2023-02-14 03:31:05 --> Input Class Initialized
INFO - 2023-02-14 03:31:05 --> Language Class Initialized
INFO - 2023-02-14 03:31:05 --> Language Class Initialized
INFO - 2023-02-14 03:31:05 --> Loader Class Initialized
INFO - 2023-02-14 03:31:05 --> Loader Class Initialized
INFO - 2023-02-14 03:31:05 --> Controller Class Initialized
INFO - 2023-02-14 03:31:05 --> Controller Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:31:05 --> Model "Login_model" initialized
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Final output sent to browser
DEBUG - 2023-02-14 03:31:05 --> Total execution time: 0.0234
INFO - 2023-02-14 03:31:05 --> Config Class Initialized
INFO - 2023-02-14 03:31:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:31:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:31:05 --> Utf8 Class Initialized
INFO - 2023-02-14 03:31:05 --> URI Class Initialized
INFO - 2023-02-14 03:31:05 --> Router Class Initialized
INFO - 2023-02-14 03:31:05 --> Output Class Initialized
INFO - 2023-02-14 03:31:05 --> Security Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:31:05 --> Input Class Initialized
INFO - 2023-02-14 03:31:05 --> Language Class Initialized
INFO - 2023-02-14 03:31:05 --> Loader Class Initialized
INFO - 2023-02-14 03:31:05 --> Controller Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:31:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:31:05 --> Final output sent to browser
DEBUG - 2023-02-14 03:31:05 --> Total execution time: 0.0185
INFO - 2023-02-14 03:31:05 --> Final output sent to browser
DEBUG - 2023-02-14 03:31:05 --> Total execution time: 0.4666
INFO - 2023-02-14 03:31:05 --> Config Class Initialized
INFO - 2023-02-14 03:31:05 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:31:05 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:31:05 --> Utf8 Class Initialized
INFO - 2023-02-14 03:31:05 --> URI Class Initialized
INFO - 2023-02-14 03:31:05 --> Router Class Initialized
INFO - 2023-02-14 03:31:05 --> Output Class Initialized
INFO - 2023-02-14 03:31:05 --> Security Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:31:05 --> Input Class Initialized
INFO - 2023-02-14 03:31:05 --> Language Class Initialized
INFO - 2023-02-14 03:31:05 --> Loader Class Initialized
INFO - 2023-02-14 03:31:05 --> Controller Class Initialized
DEBUG - 2023-02-14 03:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Model "Login_model" initialized
INFO - 2023-02-14 03:31:05 --> Database Driver Class Initialized
INFO - 2023-02-14 03:31:05 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:31:06 --> Final output sent to browser
DEBUG - 2023-02-14 03:31:06 --> Total execution time: 0.5012
INFO - 2023-02-14 03:32:00 --> Config Class Initialized
INFO - 2023-02-14 03:32:00 --> Config Class Initialized
INFO - 2023-02-14 03:32:00 --> Hooks Class Initialized
INFO - 2023-02-14 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:32:00 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:00 --> URI Class Initialized
INFO - 2023-02-14 03:32:00 --> URI Class Initialized
INFO - 2023-02-14 03:32:00 --> Router Class Initialized
INFO - 2023-02-14 03:32:00 --> Router Class Initialized
INFO - 2023-02-14 03:32:00 --> Output Class Initialized
INFO - 2023-02-14 03:32:00 --> Output Class Initialized
INFO - 2023-02-14 03:32:00 --> Security Class Initialized
INFO - 2023-02-14 03:32:00 --> Security Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:32:00 --> Input Class Initialized
INFO - 2023-02-14 03:32:00 --> Input Class Initialized
INFO - 2023-02-14 03:32:00 --> Language Class Initialized
INFO - 2023-02-14 03:32:00 --> Language Class Initialized
INFO - 2023-02-14 03:32:00 --> Loader Class Initialized
INFO - 2023-02-14 03:32:00 --> Loader Class Initialized
INFO - 2023-02-14 03:32:00 --> Controller Class Initialized
INFO - 2023-02-14 03:32:00 --> Controller Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Model "Login_model" initialized
INFO - 2023-02-14 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:00 --> Total execution time: 0.0259
INFO - 2023-02-14 03:32:00 --> Config Class Initialized
INFO - 2023-02-14 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:00 --> URI Class Initialized
INFO - 2023-02-14 03:32:00 --> Router Class Initialized
INFO - 2023-02-14 03:32:00 --> Output Class Initialized
INFO - 2023-02-14 03:32:00 --> Security Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:00 --> Input Class Initialized
INFO - 2023-02-14 03:32:00 --> Language Class Initialized
INFO - 2023-02-14 03:32:00 --> Loader Class Initialized
INFO - 2023-02-14 03:32:00 --> Controller Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:00 --> Total execution time: 0.0136
INFO - 2023-02-14 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:00 --> Total execution time: 0.4554
INFO - 2023-02-14 03:32:00 --> Config Class Initialized
INFO - 2023-02-14 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:00 --> URI Class Initialized
INFO - 2023-02-14 03:32:00 --> Router Class Initialized
INFO - 2023-02-14 03:32:00 --> Output Class Initialized
INFO - 2023-02-14 03:32:00 --> Security Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:32:00 --> Input Class Initialized
INFO - 2023-02-14 03:32:00 --> Language Class Initialized
INFO - 2023-02-14 03:32:00 --> Loader Class Initialized
INFO - 2023-02-14 03:32:00 --> Controller Class Initialized
DEBUG - 2023-02-14 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Model "Login_model" initialized
INFO - 2023-02-14 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:00 --> Total execution time: 0.4256
INFO - 2023-02-14 03:32:59 --> Config Class Initialized
INFO - 2023-02-14 03:32:59 --> Config Class Initialized
INFO - 2023-02-14 03:32:59 --> Hooks Class Initialized
INFO - 2023-02-14 03:32:59 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:32:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:32:59 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:32:59 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:59 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:59 --> URI Class Initialized
INFO - 2023-02-14 03:32:59 --> URI Class Initialized
INFO - 2023-02-14 03:32:59 --> Router Class Initialized
INFO - 2023-02-14 03:32:59 --> Router Class Initialized
INFO - 2023-02-14 03:32:59 --> Output Class Initialized
INFO - 2023-02-14 03:32:59 --> Output Class Initialized
INFO - 2023-02-14 03:32:59 --> Security Class Initialized
INFO - 2023-02-14 03:32:59 --> Security Class Initialized
DEBUG - 2023-02-14 03:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:32:59 --> Input Class Initialized
INFO - 2023-02-14 03:32:59 --> Input Class Initialized
INFO - 2023-02-14 03:32:59 --> Language Class Initialized
INFO - 2023-02-14 03:32:59 --> Language Class Initialized
INFO - 2023-02-14 03:32:59 --> Loader Class Initialized
INFO - 2023-02-14 03:32:59 --> Loader Class Initialized
INFO - 2023-02-14 03:32:59 --> Controller Class Initialized
INFO - 2023-02-14 03:32:59 --> Controller Class Initialized
DEBUG - 2023-02-14 03:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:32:59 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:59 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:59 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:59 --> Model "Login_model" initialized
INFO - 2023-02-14 03:32:59 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:59 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:59 --> Total execution time: 0.0229
INFO - 2023-02-14 03:32:59 --> Config Class Initialized
INFO - 2023-02-14 03:32:59 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:32:59 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:32:59 --> Utf8 Class Initialized
INFO - 2023-02-14 03:32:59 --> URI Class Initialized
INFO - 2023-02-14 03:32:59 --> Router Class Initialized
INFO - 2023-02-14 03:32:59 --> Output Class Initialized
INFO - 2023-02-14 03:32:59 --> Security Class Initialized
DEBUG - 2023-02-14 03:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:32:59 --> Input Class Initialized
INFO - 2023-02-14 03:32:59 --> Language Class Initialized
INFO - 2023-02-14 03:32:59 --> Loader Class Initialized
INFO - 2023-02-14 03:32:59 --> Controller Class Initialized
DEBUG - 2023-02-14 03:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:32:59 --> Database Driver Class Initialized
INFO - 2023-02-14 03:32:59 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:59 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:32:59 --> Final output sent to browser
DEBUG - 2023-02-14 03:32:59 --> Total execution time: 0.0238
INFO - 2023-02-14 03:33:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:00 --> Total execution time: 0.4599
INFO - 2023-02-14 03:33:00 --> Config Class Initialized
INFO - 2023-02-14 03:33:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:33:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:33:00 --> Utf8 Class Initialized
INFO - 2023-02-14 03:33:00 --> URI Class Initialized
INFO - 2023-02-14 03:33:00 --> Router Class Initialized
INFO - 2023-02-14 03:33:00 --> Output Class Initialized
INFO - 2023-02-14 03:33:00 --> Security Class Initialized
DEBUG - 2023-02-14 03:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:33:00 --> Input Class Initialized
INFO - 2023-02-14 03:33:00 --> Language Class Initialized
INFO - 2023-02-14 03:33:00 --> Loader Class Initialized
INFO - 2023-02-14 03:33:00 --> Controller Class Initialized
DEBUG - 2023-02-14 03:33:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:33:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:00 --> Model "Login_model" initialized
INFO - 2023-02-14 03:33:00 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:00 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:33:00 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:00 --> Total execution time: 0.4095
INFO - 2023-02-14 03:33:57 --> Config Class Initialized
INFO - 2023-02-14 03:33:57 --> Config Class Initialized
INFO - 2023-02-14 03:33:57 --> Hooks Class Initialized
INFO - 2023-02-14 03:33:57 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:33:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:33:57 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:33:57 --> Utf8 Class Initialized
INFO - 2023-02-14 03:33:57 --> Utf8 Class Initialized
INFO - 2023-02-14 03:33:57 --> URI Class Initialized
INFO - 2023-02-14 03:33:57 --> URI Class Initialized
INFO - 2023-02-14 03:33:57 --> Router Class Initialized
INFO - 2023-02-14 03:33:57 --> Router Class Initialized
INFO - 2023-02-14 03:33:57 --> Output Class Initialized
INFO - 2023-02-14 03:33:57 --> Output Class Initialized
INFO - 2023-02-14 03:33:57 --> Security Class Initialized
INFO - 2023-02-14 03:33:57 --> Security Class Initialized
DEBUG - 2023-02-14 03:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:33:57 --> Input Class Initialized
INFO - 2023-02-14 03:33:57 --> Input Class Initialized
INFO - 2023-02-14 03:33:57 --> Language Class Initialized
INFO - 2023-02-14 03:33:57 --> Language Class Initialized
INFO - 2023-02-14 03:33:57 --> Loader Class Initialized
INFO - 2023-02-14 03:33:57 --> Loader Class Initialized
INFO - 2023-02-14 03:33:57 --> Controller Class Initialized
INFO - 2023-02-14 03:33:57 --> Controller Class Initialized
DEBUG - 2023-02-14 03:33:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:33:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:33:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:33:57 --> Model "Login_model" initialized
INFO - 2023-02-14 03:33:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:57 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:57 --> Total execution time: 0.0203
INFO - 2023-02-14 03:33:57 --> Config Class Initialized
INFO - 2023-02-14 03:33:57 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:33:57 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:33:57 --> Utf8 Class Initialized
INFO - 2023-02-14 03:33:57 --> URI Class Initialized
INFO - 2023-02-14 03:33:57 --> Router Class Initialized
INFO - 2023-02-14 03:33:57 --> Output Class Initialized
INFO - 2023-02-14 03:33:57 --> Security Class Initialized
DEBUG - 2023-02-14 03:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:33:57 --> Input Class Initialized
INFO - 2023-02-14 03:33:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:33:57 --> Language Class Initialized
INFO - 2023-02-14 03:33:57 --> Loader Class Initialized
INFO - 2023-02-14 03:33:57 --> Controller Class Initialized
DEBUG - 2023-02-14 03:33:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:33:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:33:57 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:57 --> Total execution time: 0.0138
INFO - 2023-02-14 03:33:58 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:58 --> Total execution time: 0.4085
INFO - 2023-02-14 03:33:58 --> Config Class Initialized
INFO - 2023-02-14 03:33:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:33:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:33:58 --> Utf8 Class Initialized
INFO - 2023-02-14 03:33:58 --> URI Class Initialized
INFO - 2023-02-14 03:33:58 --> Router Class Initialized
INFO - 2023-02-14 03:33:58 --> Output Class Initialized
INFO - 2023-02-14 03:33:58 --> Security Class Initialized
DEBUG - 2023-02-14 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:33:58 --> Input Class Initialized
INFO - 2023-02-14 03:33:58 --> Language Class Initialized
INFO - 2023-02-14 03:33:58 --> Loader Class Initialized
INFO - 2023-02-14 03:33:58 --> Controller Class Initialized
DEBUG - 2023-02-14 03:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:33:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:58 --> Model "Login_model" initialized
INFO - 2023-02-14 03:33:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:33:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:33:58 --> Final output sent to browser
DEBUG - 2023-02-14 03:33:58 --> Total execution time: 0.4186
INFO - 2023-02-14 03:34:55 --> Config Class Initialized
INFO - 2023-02-14 03:34:55 --> Config Class Initialized
INFO - 2023-02-14 03:34:55 --> Hooks Class Initialized
INFO - 2023-02-14 03:34:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:34:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:34:55 --> Utf8 Class Initialized
INFO - 2023-02-14 03:34:55 --> Utf8 Class Initialized
INFO - 2023-02-14 03:34:55 --> URI Class Initialized
INFO - 2023-02-14 03:34:55 --> URI Class Initialized
INFO - 2023-02-14 03:34:55 --> Router Class Initialized
INFO - 2023-02-14 03:34:55 --> Router Class Initialized
INFO - 2023-02-14 03:34:55 --> Output Class Initialized
INFO - 2023-02-14 03:34:55 --> Output Class Initialized
INFO - 2023-02-14 03:34:55 --> Security Class Initialized
INFO - 2023-02-14 03:34:55 --> Security Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:34:55 --> Input Class Initialized
INFO - 2023-02-14 03:34:55 --> Input Class Initialized
INFO - 2023-02-14 03:34:55 --> Language Class Initialized
INFO - 2023-02-14 03:34:55 --> Language Class Initialized
INFO - 2023-02-14 03:34:55 --> Loader Class Initialized
INFO - 2023-02-14 03:34:55 --> Loader Class Initialized
INFO - 2023-02-14 03:34:55 --> Controller Class Initialized
INFO - 2023-02-14 03:34:55 --> Controller Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Model "Login_model" initialized
INFO - 2023-02-14 03:34:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Final output sent to browser
DEBUG - 2023-02-14 03:34:55 --> Total execution time: 0.0247
INFO - 2023-02-14 03:34:55 --> Config Class Initialized
INFO - 2023-02-14 03:34:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:34:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:34:55 --> Utf8 Class Initialized
INFO - 2023-02-14 03:34:55 --> URI Class Initialized
INFO - 2023-02-14 03:34:55 --> Router Class Initialized
INFO - 2023-02-14 03:34:55 --> Output Class Initialized
INFO - 2023-02-14 03:34:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:34:55 --> Security Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:34:55 --> Input Class Initialized
INFO - 2023-02-14 03:34:55 --> Language Class Initialized
INFO - 2023-02-14 03:34:55 --> Loader Class Initialized
INFO - 2023-02-14 03:34:55 --> Controller Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:34:55 --> Final output sent to browser
DEBUG - 2023-02-14 03:34:55 --> Total execution time: 0.0227
INFO - 2023-02-14 03:34:55 --> Final output sent to browser
DEBUG - 2023-02-14 03:34:55 --> Total execution time: 0.5079
INFO - 2023-02-14 03:34:55 --> Config Class Initialized
INFO - 2023-02-14 03:34:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:34:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:34:55 --> Utf8 Class Initialized
INFO - 2023-02-14 03:34:55 --> URI Class Initialized
INFO - 2023-02-14 03:34:55 --> Router Class Initialized
INFO - 2023-02-14 03:34:55 --> Output Class Initialized
INFO - 2023-02-14 03:34:55 --> Security Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:34:55 --> Input Class Initialized
INFO - 2023-02-14 03:34:55 --> Language Class Initialized
INFO - 2023-02-14 03:34:55 --> Loader Class Initialized
INFO - 2023-02-14 03:34:55 --> Controller Class Initialized
DEBUG - 2023-02-14 03:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Model "Login_model" initialized
INFO - 2023-02-14 03:34:55 --> Database Driver Class Initialized
INFO - 2023-02-14 03:34:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:34:56 --> Final output sent to browser
DEBUG - 2023-02-14 03:34:56 --> Total execution time: 0.4604
INFO - 2023-02-14 03:35:50 --> Config Class Initialized
INFO - 2023-02-14 03:35:50 --> Config Class Initialized
INFO - 2023-02-14 03:35:50 --> Hooks Class Initialized
INFO - 2023-02-14 03:35:50 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:35:50 --> Utf8 Class Initialized
INFO - 2023-02-14 03:35:50 --> Utf8 Class Initialized
INFO - 2023-02-14 03:35:50 --> URI Class Initialized
INFO - 2023-02-14 03:35:50 --> URI Class Initialized
INFO - 2023-02-14 03:35:50 --> Router Class Initialized
INFO - 2023-02-14 03:35:50 --> Router Class Initialized
INFO - 2023-02-14 03:35:50 --> Output Class Initialized
INFO - 2023-02-14 03:35:50 --> Output Class Initialized
INFO - 2023-02-14 03:35:50 --> Security Class Initialized
INFO - 2023-02-14 03:35:50 --> Security Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:35:50 --> Input Class Initialized
INFO - 2023-02-14 03:35:50 --> Input Class Initialized
INFO - 2023-02-14 03:35:50 --> Language Class Initialized
INFO - 2023-02-14 03:35:50 --> Language Class Initialized
INFO - 2023-02-14 03:35:50 --> Loader Class Initialized
INFO - 2023-02-14 03:35:50 --> Loader Class Initialized
INFO - 2023-02-14 03:35:50 --> Controller Class Initialized
INFO - 2023-02-14 03:35:50 --> Controller Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:35:50 --> Model "Login_model" initialized
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Final output sent to browser
DEBUG - 2023-02-14 03:35:50 --> Total execution time: 0.0190
INFO - 2023-02-14 03:35:50 --> Config Class Initialized
INFO - 2023-02-14 03:35:50 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:35:50 --> Utf8 Class Initialized
INFO - 2023-02-14 03:35:50 --> URI Class Initialized
INFO - 2023-02-14 03:35:50 --> Router Class Initialized
INFO - 2023-02-14 03:35:50 --> Output Class Initialized
INFO - 2023-02-14 03:35:50 --> Security Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:35:50 --> Input Class Initialized
INFO - 2023-02-14 03:35:50 --> Language Class Initialized
INFO - 2023-02-14 03:35:50 --> Loader Class Initialized
INFO - 2023-02-14 03:35:50 --> Controller Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:35:50 --> Final output sent to browser
DEBUG - 2023-02-14 03:35:50 --> Total execution time: 0.0141
INFO - 2023-02-14 03:35:50 --> Final output sent to browser
DEBUG - 2023-02-14 03:35:50 --> Total execution time: 0.4079
INFO - 2023-02-14 03:35:50 --> Config Class Initialized
INFO - 2023-02-14 03:35:50 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:35:50 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:35:50 --> Utf8 Class Initialized
INFO - 2023-02-14 03:35:50 --> URI Class Initialized
INFO - 2023-02-14 03:35:50 --> Router Class Initialized
INFO - 2023-02-14 03:35:50 --> Output Class Initialized
INFO - 2023-02-14 03:35:50 --> Security Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:35:50 --> Input Class Initialized
INFO - 2023-02-14 03:35:50 --> Language Class Initialized
INFO - 2023-02-14 03:35:50 --> Loader Class Initialized
INFO - 2023-02-14 03:35:50 --> Controller Class Initialized
DEBUG - 2023-02-14 03:35:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Model "Login_model" initialized
INFO - 2023-02-14 03:35:50 --> Database Driver Class Initialized
INFO - 2023-02-14 03:35:50 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:35:50 --> Final output sent to browser
DEBUG - 2023-02-14 03:35:50 --> Total execution time: 0.4088
INFO - 2023-02-14 03:36:43 --> Config Class Initialized
INFO - 2023-02-14 03:36:43 --> Config Class Initialized
INFO - 2023-02-14 03:36:43 --> Hooks Class Initialized
INFO - 2023-02-14 03:36:43 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:36:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:36:43 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:36:43 --> Utf8 Class Initialized
INFO - 2023-02-14 03:36:43 --> Utf8 Class Initialized
INFO - 2023-02-14 03:36:43 --> URI Class Initialized
INFO - 2023-02-14 03:36:43 --> URI Class Initialized
INFO - 2023-02-14 03:36:43 --> Router Class Initialized
INFO - 2023-02-14 03:36:43 --> Router Class Initialized
INFO - 2023-02-14 03:36:43 --> Output Class Initialized
INFO - 2023-02-14 03:36:43 --> Output Class Initialized
INFO - 2023-02-14 03:36:43 --> Security Class Initialized
INFO - 2023-02-14 03:36:43 --> Security Class Initialized
DEBUG - 2023-02-14 03:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:36:43 --> Input Class Initialized
INFO - 2023-02-14 03:36:43 --> Input Class Initialized
INFO - 2023-02-14 03:36:43 --> Language Class Initialized
INFO - 2023-02-14 03:36:43 --> Language Class Initialized
INFO - 2023-02-14 03:36:43 --> Loader Class Initialized
INFO - 2023-02-14 03:36:43 --> Loader Class Initialized
INFO - 2023-02-14 03:36:43 --> Controller Class Initialized
INFO - 2023-02-14 03:36:43 --> Controller Class Initialized
DEBUG - 2023-02-14 03:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:36:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:43 --> Model "Login_model" initialized
INFO - 2023-02-14 03:36:43 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:36:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:36:43 --> Total execution time: 0.0256
INFO - 2023-02-14 03:36:43 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:36:43 --> Config Class Initialized
INFO - 2023-02-14 03:36:43 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:36:43 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:36:43 --> Utf8 Class Initialized
INFO - 2023-02-14 03:36:43 --> URI Class Initialized
INFO - 2023-02-14 03:36:43 --> Router Class Initialized
INFO - 2023-02-14 03:36:43 --> Output Class Initialized
INFO - 2023-02-14 03:36:43 --> Security Class Initialized
DEBUG - 2023-02-14 03:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:36:43 --> Input Class Initialized
INFO - 2023-02-14 03:36:43 --> Language Class Initialized
INFO - 2023-02-14 03:36:43 --> Loader Class Initialized
INFO - 2023-02-14 03:36:43 --> Controller Class Initialized
DEBUG - 2023-02-14 03:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:36:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:43 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:36:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:36:43 --> Total execution time: 0.0151
INFO - 2023-02-14 03:36:44 --> Final output sent to browser
DEBUG - 2023-02-14 03:36:44 --> Total execution time: 0.4280
INFO - 2023-02-14 03:36:44 --> Config Class Initialized
INFO - 2023-02-14 03:36:44 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:36:44 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:36:44 --> Utf8 Class Initialized
INFO - 2023-02-14 03:36:44 --> URI Class Initialized
INFO - 2023-02-14 03:36:44 --> Router Class Initialized
INFO - 2023-02-14 03:36:44 --> Output Class Initialized
INFO - 2023-02-14 03:36:44 --> Security Class Initialized
DEBUG - 2023-02-14 03:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:36:44 --> Input Class Initialized
INFO - 2023-02-14 03:36:44 --> Language Class Initialized
INFO - 2023-02-14 03:36:44 --> Loader Class Initialized
INFO - 2023-02-14 03:36:44 --> Controller Class Initialized
DEBUG - 2023-02-14 03:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:36:44 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:44 --> Model "Login_model" initialized
INFO - 2023-02-14 03:36:44 --> Database Driver Class Initialized
INFO - 2023-02-14 03:36:44 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:36:44 --> Final output sent to browser
DEBUG - 2023-02-14 03:36:44 --> Total execution time: 0.3997
INFO - 2023-02-14 03:37:58 --> Config Class Initialized
INFO - 2023-02-14 03:37:58 --> Config Class Initialized
INFO - 2023-02-14 03:37:58 --> Hooks Class Initialized
INFO - 2023-02-14 03:37:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:37:58 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:37:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:37:58 --> Utf8 Class Initialized
INFO - 2023-02-14 03:37:58 --> Utf8 Class Initialized
INFO - 2023-02-14 03:37:58 --> URI Class Initialized
INFO - 2023-02-14 03:37:58 --> URI Class Initialized
INFO - 2023-02-14 03:37:58 --> Router Class Initialized
INFO - 2023-02-14 03:37:58 --> Router Class Initialized
INFO - 2023-02-14 03:37:58 --> Output Class Initialized
INFO - 2023-02-14 03:37:58 --> Output Class Initialized
INFO - 2023-02-14 03:37:58 --> Security Class Initialized
INFO - 2023-02-14 03:37:58 --> Security Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:37:58 --> Input Class Initialized
INFO - 2023-02-14 03:37:58 --> Input Class Initialized
INFO - 2023-02-14 03:37:58 --> Language Class Initialized
INFO - 2023-02-14 03:37:58 --> Language Class Initialized
INFO - 2023-02-14 03:37:58 --> Loader Class Initialized
INFO - 2023-02-14 03:37:58 --> Loader Class Initialized
INFO - 2023-02-14 03:37:58 --> Controller Class Initialized
INFO - 2023-02-14 03:37:58 --> Controller Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Model "Login_model" initialized
INFO - 2023-02-14 03:37:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Final output sent to browser
DEBUG - 2023-02-14 03:37:58 --> Total execution time: 0.0617
INFO - 2023-02-14 03:37:58 --> Config Class Initialized
INFO - 2023-02-14 03:37:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:37:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:37:58 --> Utf8 Class Initialized
INFO - 2023-02-14 03:37:58 --> URI Class Initialized
INFO - 2023-02-14 03:37:58 --> Router Class Initialized
INFO - 2023-02-14 03:37:58 --> Output Class Initialized
INFO - 2023-02-14 03:37:58 --> Security Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:37:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:37:58 --> Input Class Initialized
INFO - 2023-02-14 03:37:58 --> Language Class Initialized
INFO - 2023-02-14 03:37:58 --> Loader Class Initialized
INFO - 2023-02-14 03:37:58 --> Controller Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:37:58 --> Final output sent to browser
DEBUG - 2023-02-14 03:37:58 --> Total execution time: 0.0143
INFO - 2023-02-14 03:37:58 --> Final output sent to browser
DEBUG - 2023-02-14 03:37:58 --> Total execution time: 0.4705
INFO - 2023-02-14 03:37:58 --> Config Class Initialized
INFO - 2023-02-14 03:37:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:37:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:37:58 --> Utf8 Class Initialized
INFO - 2023-02-14 03:37:58 --> URI Class Initialized
INFO - 2023-02-14 03:37:58 --> Router Class Initialized
INFO - 2023-02-14 03:37:58 --> Output Class Initialized
INFO - 2023-02-14 03:37:58 --> Security Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:37:58 --> Input Class Initialized
INFO - 2023-02-14 03:37:58 --> Language Class Initialized
INFO - 2023-02-14 03:37:58 --> Loader Class Initialized
INFO - 2023-02-14 03:37:58 --> Controller Class Initialized
DEBUG - 2023-02-14 03:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Model "Login_model" initialized
INFO - 2023-02-14 03:37:58 --> Database Driver Class Initialized
INFO - 2023-02-14 03:37:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:37:59 --> Final output sent to browser
DEBUG - 2023-02-14 03:37:59 --> Total execution time: 0.3895
INFO - 2023-02-14 03:38:42 --> Config Class Initialized
INFO - 2023-02-14 03:38:42 --> Config Class Initialized
INFO - 2023-02-14 03:38:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:38:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:38:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:38:42 --> URI Class Initialized
INFO - 2023-02-14 03:38:42 --> URI Class Initialized
INFO - 2023-02-14 03:38:42 --> Router Class Initialized
INFO - 2023-02-14 03:38:42 --> Router Class Initialized
INFO - 2023-02-14 03:38:42 --> Output Class Initialized
INFO - 2023-02-14 03:38:42 --> Output Class Initialized
INFO - 2023-02-14 03:38:42 --> Security Class Initialized
INFO - 2023-02-14 03:38:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:38:42 --> Input Class Initialized
INFO - 2023-02-14 03:38:42 --> Input Class Initialized
INFO - 2023-02-14 03:38:42 --> Language Class Initialized
INFO - 2023-02-14 03:38:42 --> Language Class Initialized
INFO - 2023-02-14 03:38:42 --> Loader Class Initialized
INFO - 2023-02-14 03:38:42 --> Loader Class Initialized
INFO - 2023-02-14 03:38:42 --> Controller Class Initialized
INFO - 2023-02-14 03:38:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:38:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:38:42 --> Total execution time: 0.0247
INFO - 2023-02-14 03:38:42 --> Config Class Initialized
INFO - 2023-02-14 03:38:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:38:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:38:42 --> URI Class Initialized
INFO - 2023-02-14 03:38:42 --> Router Class Initialized
INFO - 2023-02-14 03:38:42 --> Output Class Initialized
INFO - 2023-02-14 03:38:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:38:42 --> Input Class Initialized
INFO - 2023-02-14 03:38:42 --> Language Class Initialized
INFO - 2023-02-14 03:38:42 --> Loader Class Initialized
INFO - 2023-02-14 03:38:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:38:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:38:42 --> Total execution time: 0.0627
INFO - 2023-02-14 03:38:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:38:42 --> Total execution time: 0.5812
INFO - 2023-02-14 03:38:42 --> Config Class Initialized
INFO - 2023-02-14 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:38:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:38:42 --> URI Class Initialized
INFO - 2023-02-14 03:38:42 --> Router Class Initialized
INFO - 2023-02-14 03:38:42 --> Output Class Initialized
INFO - 2023-02-14 03:38:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:38:42 --> Input Class Initialized
INFO - 2023-02-14 03:38:42 --> Language Class Initialized
INFO - 2023-02-14 03:38:42 --> Loader Class Initialized
INFO - 2023-02-14 03:38:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:38:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:38:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:38:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:38:43 --> Total execution time: 0.4277
INFO - 2023-02-14 03:39:42 --> Config Class Initialized
INFO - 2023-02-14 03:39:42 --> Config Class Initialized
INFO - 2023-02-14 03:39:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:39:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:39:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:39:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:39:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:39:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:39:42 --> URI Class Initialized
INFO - 2023-02-14 03:39:42 --> URI Class Initialized
INFO - 2023-02-14 03:39:42 --> Router Class Initialized
INFO - 2023-02-14 03:39:42 --> Router Class Initialized
INFO - 2023-02-14 03:39:42 --> Output Class Initialized
INFO - 2023-02-14 03:39:42 --> Output Class Initialized
INFO - 2023-02-14 03:39:42 --> Security Class Initialized
INFO - 2023-02-14 03:39:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:39:42 --> Input Class Initialized
INFO - 2023-02-14 03:39:42 --> Input Class Initialized
INFO - 2023-02-14 03:39:42 --> Language Class Initialized
INFO - 2023-02-14 03:39:42 --> Language Class Initialized
INFO - 2023-02-14 03:39:42 --> Loader Class Initialized
INFO - 2023-02-14 03:39:42 --> Loader Class Initialized
INFO - 2023-02-14 03:39:42 --> Controller Class Initialized
INFO - 2023-02-14 03:39:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:39:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:39:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:39:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:39:42 --> Total execution time: 0.1816
INFO - 2023-02-14 03:39:42 --> Config Class Initialized
INFO - 2023-02-14 03:39:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:39:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:39:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:39:42 --> URI Class Initialized
INFO - 2023-02-14 03:39:42 --> Router Class Initialized
INFO - 2023-02-14 03:39:42 --> Output Class Initialized
INFO - 2023-02-14 03:39:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:39:42 --> Input Class Initialized
INFO - 2023-02-14 03:39:42 --> Language Class Initialized
INFO - 2023-02-14 03:39:42 --> Loader Class Initialized
INFO - 2023-02-14 03:39:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:39:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:39:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:39:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:39:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:39:42 --> Total execution time: 0.1040
INFO - 2023-02-14 03:39:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:39:43 --> Total execution time: 0.8770
INFO - 2023-02-14 03:39:43 --> Config Class Initialized
INFO - 2023-02-14 03:39:43 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:39:43 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:39:43 --> Utf8 Class Initialized
INFO - 2023-02-14 03:39:43 --> URI Class Initialized
INFO - 2023-02-14 03:39:43 --> Router Class Initialized
INFO - 2023-02-14 03:39:43 --> Output Class Initialized
INFO - 2023-02-14 03:39:43 --> Security Class Initialized
DEBUG - 2023-02-14 03:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:39:43 --> Input Class Initialized
INFO - 2023-02-14 03:39:43 --> Language Class Initialized
INFO - 2023-02-14 03:39:43 --> Loader Class Initialized
INFO - 2023-02-14 03:39:43 --> Controller Class Initialized
DEBUG - 2023-02-14 03:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:39:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:43 --> Model "Login_model" initialized
INFO - 2023-02-14 03:39:43 --> Database Driver Class Initialized
INFO - 2023-02-14 03:39:43 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:39:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:39:43 --> Total execution time: 0.9364
INFO - 2023-02-14 03:40:42 --> Config Class Initialized
INFO - 2023-02-14 03:40:42 --> Config Class Initialized
INFO - 2023-02-14 03:40:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:40:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:40:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:40:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:40:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:40:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:40:42 --> URI Class Initialized
INFO - 2023-02-14 03:40:42 --> URI Class Initialized
INFO - 2023-02-14 03:40:42 --> Router Class Initialized
INFO - 2023-02-14 03:40:42 --> Router Class Initialized
INFO - 2023-02-14 03:40:42 --> Output Class Initialized
INFO - 2023-02-14 03:40:42 --> Output Class Initialized
INFO - 2023-02-14 03:40:42 --> Security Class Initialized
INFO - 2023-02-14 03:40:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:40:42 --> Input Class Initialized
INFO - 2023-02-14 03:40:42 --> Input Class Initialized
INFO - 2023-02-14 03:40:42 --> Language Class Initialized
INFO - 2023-02-14 03:40:42 --> Language Class Initialized
INFO - 2023-02-14 03:40:42 --> Loader Class Initialized
INFO - 2023-02-14 03:40:42 --> Loader Class Initialized
INFO - 2023-02-14 03:40:42 --> Controller Class Initialized
INFO - 2023-02-14 03:40:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:40:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:40:42 --> Total execution time: 0.0222
INFO - 2023-02-14 03:40:42 --> Config Class Initialized
INFO - 2023-02-14 03:40:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:40:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:40:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:40:42 --> URI Class Initialized
INFO - 2023-02-14 03:40:42 --> Router Class Initialized
INFO - 2023-02-14 03:40:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:40:42 --> Output Class Initialized
INFO - 2023-02-14 03:40:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:40:42 --> Input Class Initialized
INFO - 2023-02-14 03:40:42 --> Language Class Initialized
INFO - 2023-02-14 03:40:42 --> Loader Class Initialized
INFO - 2023-02-14 03:40:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:40:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:40:42 --> Total execution time: 0.0173
INFO - 2023-02-14 03:40:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:40:42 --> Total execution time: 0.3987
INFO - 2023-02-14 03:40:42 --> Config Class Initialized
INFO - 2023-02-14 03:40:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:40:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:40:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:40:42 --> URI Class Initialized
INFO - 2023-02-14 03:40:42 --> Router Class Initialized
INFO - 2023-02-14 03:40:42 --> Output Class Initialized
INFO - 2023-02-14 03:40:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:40:42 --> Input Class Initialized
INFO - 2023-02-14 03:40:42 --> Language Class Initialized
INFO - 2023-02-14 03:40:42 --> Loader Class Initialized
INFO - 2023-02-14 03:40:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:40:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:40:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:40:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:40:42 --> Total execution time: 0.4206
INFO - 2023-02-14 03:41:42 --> Config Class Initialized
INFO - 2023-02-14 03:41:42 --> Config Class Initialized
INFO - 2023-02-14 03:41:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:41:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:41:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:41:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:41:42 --> URI Class Initialized
INFO - 2023-02-14 03:41:42 --> URI Class Initialized
INFO - 2023-02-14 03:41:42 --> Router Class Initialized
INFO - 2023-02-14 03:41:42 --> Router Class Initialized
INFO - 2023-02-14 03:41:42 --> Output Class Initialized
INFO - 2023-02-14 03:41:42 --> Output Class Initialized
INFO - 2023-02-14 03:41:42 --> Security Class Initialized
INFO - 2023-02-14 03:41:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:41:42 --> Input Class Initialized
INFO - 2023-02-14 03:41:42 --> Input Class Initialized
INFO - 2023-02-14 03:41:42 --> Language Class Initialized
INFO - 2023-02-14 03:41:42 --> Language Class Initialized
INFO - 2023-02-14 03:41:42 --> Loader Class Initialized
INFO - 2023-02-14 03:41:42 --> Loader Class Initialized
INFO - 2023-02-14 03:41:42 --> Controller Class Initialized
INFO - 2023-02-14 03:41:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:41:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:41:42 --> Total execution time: 0.0221
INFO - 2023-02-14 03:41:42 --> Config Class Initialized
INFO - 2023-02-14 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:41:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:41:42 --> URI Class Initialized
INFO - 2023-02-14 03:41:42 --> Router Class Initialized
INFO - 2023-02-14 03:41:42 --> Output Class Initialized
INFO - 2023-02-14 03:41:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:41:42 --> Input Class Initialized
INFO - 2023-02-14 03:41:42 --> Language Class Initialized
INFO - 2023-02-14 03:41:42 --> Loader Class Initialized
INFO - 2023-02-14 03:41:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:41:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:41:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:41:42 --> Total execution time: 0.0174
INFO - 2023-02-14 03:41:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:41:42 --> Total execution time: 0.4263
INFO - 2023-02-14 03:41:42 --> Config Class Initialized
INFO - 2023-02-14 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:41:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:41:42 --> URI Class Initialized
INFO - 2023-02-14 03:41:42 --> Router Class Initialized
INFO - 2023-02-14 03:41:42 --> Output Class Initialized
INFO - 2023-02-14 03:41:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:41:42 --> Input Class Initialized
INFO - 2023-02-14 03:41:42 --> Language Class Initialized
INFO - 2023-02-14 03:41:42 --> Loader Class Initialized
INFO - 2023-02-14 03:41:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:41:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:41:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:41:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:41:42 --> Total execution time: 0.3910
INFO - 2023-02-14 03:42:42 --> Config Class Initialized
INFO - 2023-02-14 03:42:42 --> Config Class Initialized
INFO - 2023-02-14 03:42:42 --> Hooks Class Initialized
INFO - 2023-02-14 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:42:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:42:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:42:42 --> URI Class Initialized
INFO - 2023-02-14 03:42:42 --> URI Class Initialized
INFO - 2023-02-14 03:42:42 --> Router Class Initialized
INFO - 2023-02-14 03:42:42 --> Router Class Initialized
INFO - 2023-02-14 03:42:42 --> Output Class Initialized
INFO - 2023-02-14 03:42:42 --> Output Class Initialized
INFO - 2023-02-14 03:42:42 --> Security Class Initialized
INFO - 2023-02-14 03:42:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-14 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:42:42 --> Input Class Initialized
INFO - 2023-02-14 03:42:42 --> Input Class Initialized
INFO - 2023-02-14 03:42:42 --> Language Class Initialized
INFO - 2023-02-14 03:42:42 --> Language Class Initialized
INFO - 2023-02-14 03:42:42 --> Loader Class Initialized
INFO - 2023-02-14 03:42:42 --> Loader Class Initialized
INFO - 2023-02-14 03:42:42 --> Controller Class Initialized
INFO - 2023-02-14 03:42:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:42:42 --> Total execution time: 0.0229
INFO - 2023-02-14 03:42:42 --> Config Class Initialized
INFO - 2023-02-14 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:42:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:42:42 --> URI Class Initialized
INFO - 2023-02-14 03:42:42 --> Router Class Initialized
INFO - 2023-02-14 03:42:42 --> Output Class Initialized
INFO - 2023-02-14 03:42:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:42:42 --> Input Class Initialized
INFO - 2023-02-14 03:42:42 --> Language Class Initialized
INFO - 2023-02-14 03:42:42 --> Loader Class Initialized
INFO - 2023-02-14 03:42:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:42:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:42:42 --> Total execution time: 0.0195
INFO - 2023-02-14 03:42:42 --> Final output sent to browser
DEBUG - 2023-02-14 03:42:42 --> Total execution time: 0.7854
INFO - 2023-02-14 03:42:42 --> Config Class Initialized
INFO - 2023-02-14 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:42:42 --> Utf8 Class Initialized
INFO - 2023-02-14 03:42:42 --> URI Class Initialized
INFO - 2023-02-14 03:42:42 --> Router Class Initialized
INFO - 2023-02-14 03:42:42 --> Output Class Initialized
INFO - 2023-02-14 03:42:42 --> Security Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:42:42 --> Input Class Initialized
INFO - 2023-02-14 03:42:42 --> Language Class Initialized
INFO - 2023-02-14 03:42:42 --> Loader Class Initialized
INFO - 2023-02-14 03:42:42 --> Controller Class Initialized
DEBUG - 2023-02-14 03:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Model "Login_model" initialized
INFO - 2023-02-14 03:42:42 --> Database Driver Class Initialized
INFO - 2023-02-14 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:42:43 --> Final output sent to browser
DEBUG - 2023-02-14 03:42:43 --> Total execution time: 0.8869
INFO - 2023-02-14 03:43:37 --> Config Class Initialized
INFO - 2023-02-14 03:43:37 --> Config Class Initialized
INFO - 2023-02-14 03:43:37 --> Hooks Class Initialized
INFO - 2023-02-14 03:43:37 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2023-02-14 03:43:37 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:37 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:37 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:37 --> URI Class Initialized
INFO - 2023-02-14 03:43:37 --> URI Class Initialized
INFO - 2023-02-14 03:43:37 --> Router Class Initialized
INFO - 2023-02-14 03:43:37 --> Output Class Initialized
INFO - 2023-02-14 03:43:37 --> Router Class Initialized
INFO - 2023-02-14 03:43:37 --> Security Class Initialized
INFO - 2023-02-14 03:43:37 --> Output Class Initialized
INFO - 2023-02-14 03:43:37 --> Config Class Initialized
INFO - 2023-02-14 03:43:37 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:37 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:37 --> Input Class Initialized
INFO - 2023-02-14 03:43:37 --> Input Class Initialized
DEBUG - 2023-02-14 03:43:37 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:37 --> Language Class Initialized
INFO - 2023-02-14 03:43:37 --> Language Class Initialized
INFO - 2023-02-14 03:43:37 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:37 --> Loader Class Initialized
INFO - 2023-02-14 03:43:37 --> Loader Class Initialized
INFO - 2023-02-14 03:43:37 --> URI Class Initialized
INFO - 2023-02-14 03:43:37 --> Controller Class Initialized
INFO - 2023-02-14 03:43:37 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-14 03:43:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:37 --> Router Class Initialized
INFO - 2023-02-14 03:43:37 --> Output Class Initialized
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:37 --> Input Class Initialized
INFO - 2023-02-14 03:43:37 --> Language Class Initialized
INFO - 2023-02-14 03:43:37 --> Loader Class Initialized
INFO - 2023-02-14 03:43:37 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Model "Login_model" initialized
INFO - 2023-02-14 03:43:37 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:37 --> Model "Login_model" initialized
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:37 --> Total execution time: 0.0208
INFO - 2023-02-14 03:43:37 --> Config Class Initialized
INFO - 2023-02-14 03:43:37 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:37 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:37 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:37 --> URI Class Initialized
INFO - 2023-02-14 03:43:37 --> Router Class Initialized
INFO - 2023-02-14 03:43:37 --> Output Class Initialized
INFO - 2023-02-14 03:43:37 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:37 --> Input Class Initialized
INFO - 2023-02-14 03:43:37 --> Language Class Initialized
INFO - 2023-02-14 03:43:37 --> Loader Class Initialized
INFO - 2023-02-14 03:43:37 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:37 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:37 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:37 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:37 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:37 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:37 --> Total execution time: 0.0170
INFO - 2023-02-14 03:43:38 --> Final output sent to browser
INFO - 2023-02-14 03:43:38 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:38 --> Total execution time: 0.4626
DEBUG - 2023-02-14 03:43:38 --> Total execution time: 0.4595
INFO - 2023-02-14 03:43:38 --> Config Class Initialized
INFO - 2023-02-14 03:43:38 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:38 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:38 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:38 --> URI Class Initialized
INFO - 2023-02-14 03:43:38 --> Router Class Initialized
INFO - 2023-02-14 03:43:38 --> Output Class Initialized
INFO - 2023-02-14 03:43:38 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:38 --> Input Class Initialized
INFO - 2023-02-14 03:43:38 --> Language Class Initialized
INFO - 2023-02-14 03:43:38 --> Loader Class Initialized
INFO - 2023-02-14 03:43:38 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:38 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:38 --> Model "Login_model" initialized
INFO - 2023-02-14 03:43:38 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:38 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:38 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:38 --> Total execution time: 0.4204
INFO - 2023-02-14 03:43:38 --> Config Class Initialized
INFO - 2023-02-14 03:43:38 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:38 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:38 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:38 --> URI Class Initialized
INFO - 2023-02-14 03:43:38 --> Router Class Initialized
INFO - 2023-02-14 03:43:38 --> Output Class Initialized
INFO - 2023-02-14 03:43:38 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:38 --> Input Class Initialized
INFO - 2023-02-14 03:43:38 --> Language Class Initialized
INFO - 2023-02-14 03:43:38 --> Loader Class Initialized
INFO - 2023-02-14 03:43:38 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:38 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:38 --> Model "Login_model" initialized
INFO - 2023-02-14 03:43:38 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:38 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:38 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:38 --> Total execution time: 0.3544
INFO - 2023-02-14 03:43:41 --> Config Class Initialized
INFO - 2023-02-14 03:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:41 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:41 --> URI Class Initialized
INFO - 2023-02-14 03:43:41 --> Router Class Initialized
INFO - 2023-02-14 03:43:41 --> Output Class Initialized
INFO - 2023-02-14 03:43:41 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:41 --> Input Class Initialized
INFO - 2023-02-14 03:43:41 --> Language Class Initialized
INFO - 2023-02-14 03:43:41 --> Loader Class Initialized
INFO - 2023-02-14 03:43:41 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:41 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:41 --> Total execution time: 0.0049
INFO - 2023-02-14 03:43:41 --> Config Class Initialized
INFO - 2023-02-14 03:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:43:41 --> Utf8 Class Initialized
INFO - 2023-02-14 03:43:41 --> URI Class Initialized
INFO - 2023-02-14 03:43:41 --> Router Class Initialized
INFO - 2023-02-14 03:43:41 --> Output Class Initialized
INFO - 2023-02-14 03:43:41 --> Security Class Initialized
DEBUG - 2023-02-14 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:43:41 --> Input Class Initialized
INFO - 2023-02-14 03:43:41 --> Language Class Initialized
INFO - 2023-02-14 03:43:41 --> Loader Class Initialized
INFO - 2023-02-14 03:43:41 --> Controller Class Initialized
DEBUG - 2023-02-14 03:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:43:41 --> Database Driver Class Initialized
INFO - 2023-02-14 03:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:43:41 --> Final output sent to browser
DEBUG - 2023-02-14 03:43:41 --> Total execution time: 0.0524
INFO - 2023-02-14 03:47:57 --> Config Class Initialized
INFO - 2023-02-14 03:47:57 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:47:57 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:47:57 --> Utf8 Class Initialized
INFO - 2023-02-14 03:47:57 --> URI Class Initialized
INFO - 2023-02-14 03:47:57 --> Router Class Initialized
INFO - 2023-02-14 03:47:57 --> Output Class Initialized
INFO - 2023-02-14 03:47:57 --> Security Class Initialized
DEBUG - 2023-02-14 03:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:47:57 --> Input Class Initialized
INFO - 2023-02-14 03:47:57 --> Language Class Initialized
INFO - 2023-02-14 03:47:57 --> Loader Class Initialized
INFO - 2023-02-14 03:47:57 --> Controller Class Initialized
DEBUG - 2023-02-14 03:47:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:47:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:47:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:47:57 --> Final output sent to browser
DEBUG - 2023-02-14 03:47:57 --> Total execution time: 0.0181
INFO - 2023-02-14 03:47:57 --> Config Class Initialized
INFO - 2023-02-14 03:47:57 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:47:57 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:47:57 --> Utf8 Class Initialized
INFO - 2023-02-14 03:47:57 --> URI Class Initialized
INFO - 2023-02-14 03:47:57 --> Router Class Initialized
INFO - 2023-02-14 03:47:57 --> Output Class Initialized
INFO - 2023-02-14 03:47:57 --> Security Class Initialized
DEBUG - 2023-02-14 03:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:47:57 --> Input Class Initialized
INFO - 2023-02-14 03:47:57 --> Language Class Initialized
INFO - 2023-02-14 03:47:57 --> Loader Class Initialized
INFO - 2023-02-14 03:47:57 --> Controller Class Initialized
DEBUG - 2023-02-14 03:47:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:47:57 --> Database Driver Class Initialized
INFO - 2023-02-14 03:47:57 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:47:57 --> Final output sent to browser
DEBUG - 2023-02-14 03:47:57 --> Total execution time: 0.0548
INFO - 2023-02-14 03:47:59 --> Config Class Initialized
INFO - 2023-02-14 03:47:59 --> Hooks Class Initialized
DEBUG - 2023-02-14 03:47:59 --> UTF-8 Support Enabled
INFO - 2023-02-14 03:47:59 --> Utf8 Class Initialized
INFO - 2023-02-14 03:47:59 --> URI Class Initialized
INFO - 2023-02-14 03:47:59 --> Router Class Initialized
INFO - 2023-02-14 03:47:59 --> Output Class Initialized
INFO - 2023-02-14 03:47:59 --> Security Class Initialized
DEBUG - 2023-02-14 03:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 03:47:59 --> Input Class Initialized
INFO - 2023-02-14 03:47:59 --> Language Class Initialized
INFO - 2023-02-14 03:47:59 --> Loader Class Initialized
INFO - 2023-02-14 03:47:59 --> Controller Class Initialized
DEBUG - 2023-02-14 03:47:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 03:47:59 --> Database Driver Class Initialized
INFO - 2023-02-14 03:48:03 --> Model "Cluster_model" initialized
INFO - 2023-02-14 03:48:03 --> Final output sent to browser
DEBUG - 2023-02-14 03:48:03 --> Total execution time: 4.1001
INFO - 2023-02-14 04:05:55 --> Config Class Initialized
INFO - 2023-02-14 04:05:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:05:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:05:55 --> Utf8 Class Initialized
INFO - 2023-02-14 04:05:55 --> URI Class Initialized
INFO - 2023-02-14 04:05:55 --> Router Class Initialized
INFO - 2023-02-14 04:05:55 --> Output Class Initialized
INFO - 2023-02-14 04:05:55 --> Security Class Initialized
DEBUG - 2023-02-14 04:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:05:55 --> Input Class Initialized
INFO - 2023-02-14 04:05:55 --> Language Class Initialized
INFO - 2023-02-14 04:05:55 --> Loader Class Initialized
INFO - 2023-02-14 04:05:55 --> Controller Class Initialized
DEBUG - 2023-02-14 04:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:05:55 --> Final output sent to browser
DEBUG - 2023-02-14 04:05:55 --> Total execution time: 0.0466
INFO - 2023-02-14 04:05:55 --> Config Class Initialized
INFO - 2023-02-14 04:05:55 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:05:55 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:05:55 --> Utf8 Class Initialized
INFO - 2023-02-14 04:05:55 --> URI Class Initialized
INFO - 2023-02-14 04:05:55 --> Router Class Initialized
INFO - 2023-02-14 04:05:55 --> Output Class Initialized
INFO - 2023-02-14 04:05:55 --> Security Class Initialized
DEBUG - 2023-02-14 04:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:05:55 --> Input Class Initialized
INFO - 2023-02-14 04:05:55 --> Language Class Initialized
INFO - 2023-02-14 04:05:55 --> Loader Class Initialized
INFO - 2023-02-14 04:05:55 --> Controller Class Initialized
DEBUG - 2023-02-14 04:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:05:55 --> Database Driver Class Initialized
INFO - 2023-02-14 04:05:55 --> Model "Cluster_model" initialized
INFO - 2023-02-14 04:05:55 --> Final output sent to browser
DEBUG - 2023-02-14 04:05:55 --> Total execution time: 0.0127
INFO - 2023-02-14 04:05:58 --> Config Class Initialized
INFO - 2023-02-14 04:05:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:05:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:05:58 --> Utf8 Class Initialized
INFO - 2023-02-14 04:05:58 --> URI Class Initialized
INFO - 2023-02-14 04:05:58 --> Router Class Initialized
INFO - 2023-02-14 04:05:58 --> Output Class Initialized
INFO - 2023-02-14 04:05:58 --> Security Class Initialized
DEBUG - 2023-02-14 04:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:05:58 --> Input Class Initialized
INFO - 2023-02-14 04:05:58 --> Language Class Initialized
INFO - 2023-02-14 04:05:58 --> Loader Class Initialized
INFO - 2023-02-14 04:05:58 --> Controller Class Initialized
DEBUG - 2023-02-14 04:05:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:05:58 --> Database Driver Class Initialized
INFO - 2023-02-14 04:05:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 04:05:58 --> Final output sent to browser
DEBUG - 2023-02-14 04:05:58 --> Total execution time: 0.0139
INFO - 2023-02-14 04:05:58 --> Config Class Initialized
INFO - 2023-02-14 04:05:58 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:05:58 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:05:58 --> Utf8 Class Initialized
INFO - 2023-02-14 04:05:58 --> URI Class Initialized
INFO - 2023-02-14 04:05:58 --> Router Class Initialized
INFO - 2023-02-14 04:05:58 --> Output Class Initialized
INFO - 2023-02-14 04:05:58 --> Security Class Initialized
DEBUG - 2023-02-14 04:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:05:58 --> Input Class Initialized
INFO - 2023-02-14 04:05:58 --> Language Class Initialized
INFO - 2023-02-14 04:05:58 --> Loader Class Initialized
INFO - 2023-02-14 04:05:58 --> Controller Class Initialized
DEBUG - 2023-02-14 04:05:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:05:58 --> Database Driver Class Initialized
INFO - 2023-02-14 04:05:58 --> Model "Cluster_model" initialized
INFO - 2023-02-14 04:05:58 --> Final output sent to browser
DEBUG - 2023-02-14 04:05:58 --> Total execution time: 0.0093
INFO - 2023-02-14 04:07:31 --> Config Class Initialized
INFO - 2023-02-14 04:07:31 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:07:31 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:07:31 --> Utf8 Class Initialized
INFO - 2023-02-14 04:07:31 --> URI Class Initialized
INFO - 2023-02-14 04:07:31 --> Router Class Initialized
INFO - 2023-02-14 04:07:31 --> Output Class Initialized
INFO - 2023-02-14 04:07:31 --> Security Class Initialized
DEBUG - 2023-02-14 04:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:07:31 --> Input Class Initialized
INFO - 2023-02-14 04:07:31 --> Language Class Initialized
INFO - 2023-02-14 04:07:31 --> Loader Class Initialized
INFO - 2023-02-14 04:07:31 --> Controller Class Initialized
DEBUG - 2023-02-14 04:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:07:31 --> Database Driver Class Initialized
INFO - 2023-02-14 04:07:31 --> Model "Cluster_model" initialized
INFO - 2023-02-14 04:07:31 --> Final output sent to browser
DEBUG - 2023-02-14 04:07:31 --> Total execution time: 0.0271
INFO - 2023-02-14 04:07:31 --> Config Class Initialized
INFO - 2023-02-14 04:07:32 --> Hooks Class Initialized
DEBUG - 2023-02-14 04:07:32 --> UTF-8 Support Enabled
INFO - 2023-02-14 04:07:32 --> Utf8 Class Initialized
INFO - 2023-02-14 04:07:32 --> URI Class Initialized
INFO - 2023-02-14 04:07:32 --> Router Class Initialized
INFO - 2023-02-14 04:07:32 --> Output Class Initialized
INFO - 2023-02-14 04:07:32 --> Security Class Initialized
DEBUG - 2023-02-14 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 04:07:32 --> Input Class Initialized
INFO - 2023-02-14 04:07:32 --> Language Class Initialized
INFO - 2023-02-14 04:07:32 --> Loader Class Initialized
INFO - 2023-02-14 04:07:32 --> Controller Class Initialized
DEBUG - 2023-02-14 04:07:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 04:07:32 --> Database Driver Class Initialized
INFO - 2023-02-14 04:07:32 --> Model "Cluster_model" initialized
INFO - 2023-02-14 04:07:32 --> Final output sent to browser
DEBUG - 2023-02-14 04:07:32 --> Total execution time: 0.0630
INFO - 2023-02-14 05:35:34 --> Config Class Initialized
INFO - 2023-02-14 05:35:34 --> Hooks Class Initialized
DEBUG - 2023-02-14 05:35:34 --> UTF-8 Support Enabled
INFO - 2023-02-14 05:35:34 --> Utf8 Class Initialized
INFO - 2023-02-14 05:35:34 --> URI Class Initialized
INFO - 2023-02-14 05:35:34 --> Router Class Initialized
INFO - 2023-02-14 05:35:34 --> Output Class Initialized
INFO - 2023-02-14 05:35:34 --> Security Class Initialized
DEBUG - 2023-02-14 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 05:35:34 --> Input Class Initialized
INFO - 2023-02-14 05:35:34 --> Language Class Initialized
INFO - 2023-02-14 05:35:34 --> Loader Class Initialized
INFO - 2023-02-14 05:35:34 --> Controller Class Initialized
DEBUG - 2023-02-14 05:35:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 05:35:34 --> Database Driver Class Initialized
INFO - 2023-02-14 05:35:34 --> Database Driver Class Initialized
INFO - 2023-02-14 05:35:34 --> Model "Login_model" initialized
INFO - 2023-02-14 05:35:34 --> Final output sent to browser
DEBUG - 2023-02-14 05:35:34 --> Total execution time: 0.0287
INFO - 2023-02-14 05:35:34 --> Config Class Initialized
INFO - 2023-02-14 05:35:34 --> Hooks Class Initialized
DEBUG - 2023-02-14 05:35:34 --> UTF-8 Support Enabled
INFO - 2023-02-14 05:35:34 --> Utf8 Class Initialized
INFO - 2023-02-14 05:35:34 --> URI Class Initialized
INFO - 2023-02-14 05:35:34 --> Router Class Initialized
INFO - 2023-02-14 05:35:34 --> Output Class Initialized
INFO - 2023-02-14 05:35:34 --> Security Class Initialized
DEBUG - 2023-02-14 05:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 05:35:34 --> Input Class Initialized
INFO - 2023-02-14 05:35:34 --> Language Class Initialized
INFO - 2023-02-14 05:35:34 --> Loader Class Initialized
INFO - 2023-02-14 05:35:34 --> Controller Class Initialized
DEBUG - 2023-02-14 05:35:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 05:35:34 --> Database Driver Class Initialized
INFO - 2023-02-14 05:35:34 --> Database Driver Class Initialized
INFO - 2023-02-14 05:35:34 --> Model "Login_model" initialized
INFO - 2023-02-14 05:35:34 --> Final output sent to browser
DEBUG - 2023-02-14 05:35:34 --> Total execution time: 0.0631
INFO - 2023-02-14 06:50:00 --> Config Class Initialized
INFO - 2023-02-14 06:50:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 06:50:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 06:50:00 --> Utf8 Class Initialized
INFO - 2023-02-14 06:50:00 --> URI Class Initialized
INFO - 2023-02-14 06:50:00 --> Router Class Initialized
INFO - 2023-02-14 06:50:00 --> Output Class Initialized
INFO - 2023-02-14 06:50:00 --> Security Class Initialized
DEBUG - 2023-02-14 06:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 06:50:00 --> Input Class Initialized
INFO - 2023-02-14 06:50:00 --> Language Class Initialized
INFO - 2023-02-14 06:50:00 --> Loader Class Initialized
INFO - 2023-02-14 06:50:00 --> Controller Class Initialized
DEBUG - 2023-02-14 06:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 06:50:00 --> Final output sent to browser
DEBUG - 2023-02-14 06:50:00 --> Total execution time: 0.0068
INFO - 2023-02-14 06:50:00 --> Config Class Initialized
INFO - 2023-02-14 06:50:00 --> Hooks Class Initialized
DEBUG - 2023-02-14 06:50:00 --> UTF-8 Support Enabled
INFO - 2023-02-14 06:50:00 --> Utf8 Class Initialized
INFO - 2023-02-14 06:50:00 --> URI Class Initialized
INFO - 2023-02-14 06:50:00 --> Router Class Initialized
INFO - 2023-02-14 06:50:00 --> Output Class Initialized
INFO - 2023-02-14 06:50:00 --> Security Class Initialized
DEBUG - 2023-02-14 06:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 06:50:00 --> Input Class Initialized
INFO - 2023-02-14 06:50:00 --> Language Class Initialized
INFO - 2023-02-14 06:50:00 --> Loader Class Initialized
INFO - 2023-02-14 06:50:00 --> Controller Class Initialized
DEBUG - 2023-02-14 06:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 06:50:00 --> Database Driver Class Initialized
INFO - 2023-02-14 06:50:01 --> Config Class Initialized
INFO - 2023-02-14 06:50:01 --> Hooks Class Initialized
DEBUG - 2023-02-14 06:50:01 --> UTF-8 Support Enabled
INFO - 2023-02-14 06:50:01 --> Utf8 Class Initialized
INFO - 2023-02-14 06:50:01 --> URI Class Initialized
INFO - 2023-02-14 06:50:01 --> Router Class Initialized
INFO - 2023-02-14 06:50:01 --> Output Class Initialized
INFO - 2023-02-14 06:50:01 --> Security Class Initialized
DEBUG - 2023-02-14 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-14 06:50:01 --> Input Class Initialized
INFO - 2023-02-14 06:50:01 --> Language Class Initialized
INFO - 2023-02-14 06:50:01 --> Loader Class Initialized
INFO - 2023-02-14 06:50:01 --> Controller Class Initialized
DEBUG - 2023-02-14 06:50:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-14 06:50:01 --> Database Driver Class Initialized
ERROR - 2023-02-14 06:50:10 --> Unable to connect to the database
INFO - 2023-02-14 06:50:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-02-14 06:50:11 --> Unable to connect to the database
INFO - 2023-02-14 06:50:11 --> Language file loaded: language/english/db_lang.php
