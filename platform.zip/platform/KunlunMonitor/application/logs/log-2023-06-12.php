<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-12 07:38:26 --> Config Class Initialized
INFO - 2023-06-12 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:26 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:26 --> URI Class Initialized
INFO - 2023-06-12 07:38:26 --> Router Class Initialized
INFO - 2023-06-12 07:38:26 --> Output Class Initialized
INFO - 2023-06-12 07:38:26 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:26 --> Input Class Initialized
INFO - 2023-06-12 07:38:26 --> Language Class Initialized
INFO - 2023-06-12 07:38:26 --> Loader Class Initialized
INFO - 2023-06-12 07:38:26 --> Controller Class Initialized
INFO - 2023-06-12 07:38:26 --> Helper loaded: form_helper
INFO - 2023-06-12 07:38:26 --> Helper loaded: url_helper
DEBUG - 2023-06-12 07:38:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:26 --> Model "Change_model" initialized
INFO - 2023-06-12 07:38:26 --> Model "Grafana_model" initialized
INFO - 2023-06-12 07:38:26 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:26 --> Total execution time: 0.1339
INFO - 2023-06-12 07:38:26 --> Config Class Initialized
INFO - 2023-06-12 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:26 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:26 --> URI Class Initialized
INFO - 2023-06-12 07:38:26 --> Router Class Initialized
INFO - 2023-06-12 07:38:26 --> Output Class Initialized
INFO - 2023-06-12 07:38:26 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:26 --> Input Class Initialized
INFO - 2023-06-12 07:38:26 --> Language Class Initialized
INFO - 2023-06-12 07:38:26 --> Loader Class Initialized
INFO - 2023-06-12 07:38:26 --> Controller Class Initialized
INFO - 2023-06-12 07:38:26 --> Helper loaded: form_helper
INFO - 2023-06-12 07:38:26 --> Helper loaded: url_helper
DEBUG - 2023-06-12 07:38:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:26 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:26 --> Total execution time: 0.0307
INFO - 2023-06-12 07:38:26 --> Config Class Initialized
INFO - 2023-06-12 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:26 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:26 --> URI Class Initialized
INFO - 2023-06-12 07:38:26 --> Router Class Initialized
INFO - 2023-06-12 07:38:26 --> Output Class Initialized
INFO - 2023-06-12 07:38:26 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:26 --> Input Class Initialized
INFO - 2023-06-12 07:38:26 --> Language Class Initialized
INFO - 2023-06-12 07:38:26 --> Loader Class Initialized
INFO - 2023-06-12 07:38:26 --> Controller Class Initialized
INFO - 2023-06-12 07:38:26 --> Helper loaded: form_helper
INFO - 2023-06-12 07:38:26 --> Helper loaded: url_helper
DEBUG - 2023-06-12 07:38:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:26 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:26 --> Model "Login_model" initialized
INFO - 2023-06-12 07:38:26 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:26 --> Total execution time: 0.0778
INFO - 2023-06-12 07:38:26 --> Config Class Initialized
INFO - 2023-06-12 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:26 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:26 --> URI Class Initialized
INFO - 2023-06-12 07:38:26 --> Router Class Initialized
INFO - 2023-06-12 07:38:26 --> Output Class Initialized
INFO - 2023-06-12 07:38:26 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:26 --> Input Class Initialized
INFO - 2023-06-12 07:38:26 --> Language Class Initialized
INFO - 2023-06-12 07:38:26 --> Loader Class Initialized
INFO - 2023-06-12 07:38:26 --> Controller Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:26 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:26 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:26 --> Total execution time: 0.1001
INFO - 2023-06-12 07:38:26 --> Config Class Initialized
INFO - 2023-06-12 07:38:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:26 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:26 --> URI Class Initialized
INFO - 2023-06-12 07:38:26 --> Router Class Initialized
INFO - 2023-06-12 07:38:26 --> Output Class Initialized
INFO - 2023-06-12 07:38:26 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:26 --> Input Class Initialized
INFO - 2023-06-12 07:38:26 --> Language Class Initialized
INFO - 2023-06-12 07:38:26 --> Loader Class Initialized
INFO - 2023-06-12 07:38:26 --> Controller Class Initialized
DEBUG - 2023-06-12 07:38:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:26 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:26 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:26 --> Total execution time: 0.0630
INFO - 2023-06-12 07:38:27 --> Config Class Initialized
INFO - 2023-06-12 07:38:27 --> Hooks Class Initialized
INFO - 2023-06-12 07:38:27 --> Config Class Initialized
INFO - 2023-06-12 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:27 --> Utf8 Class Initialized
DEBUG - 2023-06-12 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:27 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:27 --> URI Class Initialized
INFO - 2023-06-12 07:38:27 --> URI Class Initialized
INFO - 2023-06-12 07:38:27 --> Router Class Initialized
INFO - 2023-06-12 07:38:27 --> Router Class Initialized
INFO - 2023-06-12 07:38:27 --> Output Class Initialized
INFO - 2023-06-12 07:38:27 --> Output Class Initialized
INFO - 2023-06-12 07:38:27 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:27 --> Security Class Initialized
INFO - 2023-06-12 07:38:27 --> Input Class Initialized
INFO - 2023-06-12 07:38:27 --> Language Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:27 --> Input Class Initialized
INFO - 2023-06-12 07:38:27 --> Language Class Initialized
INFO - 2023-06-12 07:38:27 --> Loader Class Initialized
INFO - 2023-06-12 07:38:27 --> Controller Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:27 --> Loader Class Initialized
INFO - 2023-06-12 07:38:27 --> Controller Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:27 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:27 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:27 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:27 --> Total execution time: 0.0790
INFO - 2023-06-12 07:38:27 --> Config Class Initialized
INFO - 2023-06-12 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:27 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:27 --> URI Class Initialized
INFO - 2023-06-12 07:38:27 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:27 --> Total execution time: 0.0994
INFO - 2023-06-12 07:38:27 --> Router Class Initialized
INFO - 2023-06-12 07:38:27 --> Output Class Initialized
INFO - 2023-06-12 07:38:27 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:27 --> Input Class Initialized
INFO - 2023-06-12 07:38:27 --> Language Class Initialized
INFO - 2023-06-12 07:38:27 --> Loader Class Initialized
INFO - 2023-06-12 07:38:27 --> Controller Class Initialized
INFO - 2023-06-12 07:38:27 --> Config Class Initialized
INFO - 2023-06-12 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:38:27 --> Utf8 Class Initialized
INFO - 2023-06-12 07:38:27 --> URI Class Initialized
INFO - 2023-06-12 07:38:27 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:27 --> Router Class Initialized
INFO - 2023-06-12 07:38:27 --> Output Class Initialized
INFO - 2023-06-12 07:38:27 --> Security Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:38:27 --> Input Class Initialized
INFO - 2023-06-12 07:38:27 --> Language Class Initialized
INFO - 2023-06-12 07:38:27 --> Loader Class Initialized
INFO - 2023-06-12 07:38:27 --> Controller Class Initialized
DEBUG - 2023-06-12 07:38:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:38:27 --> Database Driver Class Initialized
INFO - 2023-06-12 07:38:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:27 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:27 --> Total execution time: 0.0855
INFO - 2023-06-12 07:38:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:38:27 --> Final output sent to browser
DEBUG - 2023-06-12 07:38:27 --> Total execution time: 0.1020
INFO - 2023-06-12 07:44:10 --> Config Class Initialized
INFO - 2023-06-12 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:10 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:10 --> URI Class Initialized
INFO - 2023-06-12 07:44:10 --> Router Class Initialized
INFO - 2023-06-12 07:44:10 --> Output Class Initialized
INFO - 2023-06-12 07:44:10 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:10 --> Input Class Initialized
INFO - 2023-06-12 07:44:10 --> Language Class Initialized
INFO - 2023-06-12 07:44:10 --> Loader Class Initialized
INFO - 2023-06-12 07:44:10 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Login_model" initialized
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:44:10 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:44:10 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:10 --> Total execution time: 0.1282
INFO - 2023-06-12 07:44:10 --> Config Class Initialized
INFO - 2023-06-12 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:10 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:10 --> URI Class Initialized
INFO - 2023-06-12 07:44:10 --> Router Class Initialized
INFO - 2023-06-12 07:44:10 --> Output Class Initialized
INFO - 2023-06-12 07:44:10 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:10 --> Input Class Initialized
INFO - 2023-06-12 07:44:10 --> Language Class Initialized
INFO - 2023-06-12 07:44:10 --> Loader Class Initialized
INFO - 2023-06-12 07:44:10 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Login_model" initialized
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:44:10 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:44:10 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:10 --> Total execution time: 0.1137
INFO - 2023-06-12 07:44:10 --> Config Class Initialized
INFO - 2023-06-12 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:10 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:10 --> URI Class Initialized
INFO - 2023-06-12 07:44:10 --> Router Class Initialized
INFO - 2023-06-12 07:44:10 --> Output Class Initialized
INFO - 2023-06-12 07:44:10 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:10 --> Input Class Initialized
INFO - 2023-06-12 07:44:10 --> Language Class Initialized
INFO - 2023-06-12 07:44:10 --> Loader Class Initialized
INFO - 2023-06-12 07:44:10 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:10 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:10 --> Total execution time: 0.0309
INFO - 2023-06-12 07:44:10 --> Config Class Initialized
INFO - 2023-06-12 07:44:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:10 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:10 --> URI Class Initialized
INFO - 2023-06-12 07:44:10 --> Router Class Initialized
INFO - 2023-06-12 07:44:10 --> Output Class Initialized
INFO - 2023-06-12 07:44:10 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:10 --> Input Class Initialized
INFO - 2023-06-12 07:44:10 --> Language Class Initialized
INFO - 2023-06-12 07:44:10 --> Loader Class Initialized
INFO - 2023-06-12 07:44:10 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Login_model" initialized
INFO - 2023-06-12 07:44:10 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:10 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:44:10 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:10 --> Total execution time: 0.0876
INFO - 2023-06-12 07:44:12 --> Config Class Initialized
INFO - 2023-06-12 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:12 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:12 --> URI Class Initialized
INFO - 2023-06-12 07:44:12 --> Router Class Initialized
INFO - 2023-06-12 07:44:12 --> Output Class Initialized
INFO - 2023-06-12 07:44:12 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:12 --> Input Class Initialized
INFO - 2023-06-12 07:44:12 --> Language Class Initialized
INFO - 2023-06-12 07:44:12 --> Loader Class Initialized
INFO - 2023-06-12 07:44:12 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:12 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:12 --> Model "Login_model" initialized
INFO - 2023-06-12 07:44:12 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:12 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:44:12 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:44:12 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:12 --> Total execution time: 0.1240
INFO - 2023-06-12 07:44:12 --> Config Class Initialized
INFO - 2023-06-12 07:44:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:44:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:44:12 --> Utf8 Class Initialized
INFO - 2023-06-12 07:44:12 --> URI Class Initialized
INFO - 2023-06-12 07:44:12 --> Router Class Initialized
INFO - 2023-06-12 07:44:12 --> Output Class Initialized
INFO - 2023-06-12 07:44:12 --> Security Class Initialized
DEBUG - 2023-06-12 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:44:12 --> Input Class Initialized
INFO - 2023-06-12 07:44:12 --> Language Class Initialized
INFO - 2023-06-12 07:44:12 --> Loader Class Initialized
INFO - 2023-06-12 07:44:12 --> Controller Class Initialized
DEBUG - 2023-06-12 07:44:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:44:12 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:12 --> Model "Login_model" initialized
INFO - 2023-06-12 07:44:12 --> Database Driver Class Initialized
INFO - 2023-06-12 07:44:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:44:12 --> Final output sent to browser
DEBUG - 2023-06-12 07:44:12 --> Total execution time: 0.1045
INFO - 2023-06-12 07:54:09 --> Config Class Initialized
INFO - 2023-06-12 07:54:09 --> Config Class Initialized
INFO - 2023-06-12 07:54:09 --> Hooks Class Initialized
INFO - 2023-06-12 07:54:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 07:54:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:54:09 --> Utf8 Class Initialized
INFO - 2023-06-12 07:54:09 --> Utf8 Class Initialized
INFO - 2023-06-12 07:54:09 --> URI Class Initialized
INFO - 2023-06-12 07:54:09 --> URI Class Initialized
INFO - 2023-06-12 07:54:09 --> Router Class Initialized
INFO - 2023-06-12 07:54:09 --> Router Class Initialized
INFO - 2023-06-12 07:54:09 --> Output Class Initialized
INFO - 2023-06-12 07:54:09 --> Output Class Initialized
INFO - 2023-06-12 07:54:09 --> Security Class Initialized
INFO - 2023-06-12 07:54:09 --> Security Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:54:09 --> Input Class Initialized
INFO - 2023-06-12 07:54:09 --> Input Class Initialized
INFO - 2023-06-12 07:54:09 --> Language Class Initialized
INFO - 2023-06-12 07:54:09 --> Language Class Initialized
INFO - 2023-06-12 07:54:09 --> Loader Class Initialized
INFO - 2023-06-12 07:54:09 --> Controller Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:54:09 --> Loader Class Initialized
INFO - 2023-06-12 07:54:09 --> Controller Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 07:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 07:54:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:54:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:54:09 --> Final output sent to browser
DEBUG - 2023-06-12 07:54:09 --> Total execution time: 0.0784
INFO - 2023-06-12 07:54:09 --> Final output sent to browser
DEBUG - 2023-06-12 07:54:09 --> Total execution time: 0.0877
INFO - 2023-06-12 07:54:09 --> Config Class Initialized
INFO - 2023-06-12 07:54:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:54:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:54:09 --> Utf8 Class Initialized
INFO - 2023-06-12 07:54:09 --> URI Class Initialized
INFO - 2023-06-12 07:54:09 --> Router Class Initialized
INFO - 2023-06-12 07:54:09 --> Config Class Initialized
INFO - 2023-06-12 07:54:09 --> Hooks Class Initialized
INFO - 2023-06-12 07:54:09 --> Output Class Initialized
INFO - 2023-06-12 07:54:09 --> Security Class Initialized
DEBUG - 2023-06-12 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:54:09 --> Utf8 Class Initialized
INFO - 2023-06-12 07:54:09 --> Input Class Initialized
INFO - 2023-06-12 07:54:09 --> Language Class Initialized
INFO - 2023-06-12 07:54:09 --> URI Class Initialized
INFO - 2023-06-12 07:54:09 --> Router Class Initialized
INFO - 2023-06-12 07:54:09 --> Loader Class Initialized
INFO - 2023-06-12 07:54:09 --> Output Class Initialized
INFO - 2023-06-12 07:54:09 --> Controller Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:54:09 --> Security Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:54:09 --> Input Class Initialized
INFO - 2023-06-12 07:54:09 --> Language Class Initialized
INFO - 2023-06-12 07:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 07:54:09 --> Loader Class Initialized
INFO - 2023-06-12 07:54:09 --> Controller Class Initialized
DEBUG - 2023-06-12 07:54:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 07:54:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:54:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:54:09 --> Final output sent to browser
DEBUG - 2023-06-12 07:54:09 --> Total execution time: 0.0812
INFO - 2023-06-12 07:54:09 --> Final output sent to browser
DEBUG - 2023-06-12 07:54:09 --> Total execution time: 0.0859
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.0760
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.1213
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.0649
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.1178
INFO - 2023-06-12 07:58:33 --> Model "Login_model" initialized
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:58:33 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.1375
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Login_model" initialized
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:58:33 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.1410
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.0271
INFO - 2023-06-12 07:58:33 --> Config Class Initialized
INFO - 2023-06-12 07:58:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:33 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:33 --> URI Class Initialized
INFO - 2023-06-12 07:58:33 --> Router Class Initialized
INFO - 2023-06-12 07:58:33 --> Output Class Initialized
INFO - 2023-06-12 07:58:33 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:33 --> Input Class Initialized
INFO - 2023-06-12 07:58:33 --> Language Class Initialized
INFO - 2023-06-12 07:58:33 --> Loader Class Initialized
INFO - 2023-06-12 07:58:33 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Login_model" initialized
INFO - 2023-06-12 07:58:33 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:33 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:33 --> Total execution time: 0.1397
INFO - 2023-06-12 07:58:35 --> Config Class Initialized
INFO - 2023-06-12 07:58:35 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:35 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:35 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:35 --> URI Class Initialized
INFO - 2023-06-12 07:58:35 --> Router Class Initialized
INFO - 2023-06-12 07:58:35 --> Output Class Initialized
INFO - 2023-06-12 07:58:35 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:35 --> Input Class Initialized
INFO - 2023-06-12 07:58:35 --> Language Class Initialized
INFO - 2023-06-12 07:58:35 --> Loader Class Initialized
INFO - 2023-06-12 07:58:35 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:35 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:35 --> Model "Login_model" initialized
INFO - 2023-06-12 07:58:35 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:35 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 07:58:35 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 07:58:35 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:35 --> Total execution time: 0.1359
INFO - 2023-06-12 07:58:35 --> Config Class Initialized
INFO - 2023-06-12 07:58:35 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:35 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:35 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:35 --> URI Class Initialized
INFO - 2023-06-12 07:58:35 --> Router Class Initialized
INFO - 2023-06-12 07:58:35 --> Output Class Initialized
INFO - 2023-06-12 07:58:35 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:35 --> Input Class Initialized
INFO - 2023-06-12 07:58:35 --> Language Class Initialized
INFO - 2023-06-12 07:58:35 --> Loader Class Initialized
INFO - 2023-06-12 07:58:35 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:35 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:35 --> Model "Login_model" initialized
INFO - 2023-06-12 07:58:35 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:35 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:35 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:35 --> Total execution time: 0.1460
INFO - 2023-06-12 07:58:39 --> Config Class Initialized
INFO - 2023-06-12 07:58:39 --> Config Class Initialized
INFO - 2023-06-12 07:58:39 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:39 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:39 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:39 --> URI Class Initialized
INFO - 2023-06-12 07:58:39 --> URI Class Initialized
INFO - 2023-06-12 07:58:39 --> Router Class Initialized
INFO - 2023-06-12 07:58:39 --> Router Class Initialized
INFO - 2023-06-12 07:58:39 --> Output Class Initialized
INFO - 2023-06-12 07:58:39 --> Output Class Initialized
INFO - 2023-06-12 07:58:39 --> Security Class Initialized
INFO - 2023-06-12 07:58:39 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:39 --> Input Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:39 --> Language Class Initialized
INFO - 2023-06-12 07:58:39 --> Input Class Initialized
INFO - 2023-06-12 07:58:39 --> Language Class Initialized
INFO - 2023-06-12 07:58:39 --> Loader Class Initialized
INFO - 2023-06-12 07:58:39 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:39 --> Loader Class Initialized
INFO - 2023-06-12 07:58:39 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:39 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:39 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:39 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:39 --> Total execution time: 0.0664
INFO - 2023-06-12 07:58:39 --> Config Class Initialized
INFO - 2023-06-12 07:58:39 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:39 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:39 --> Total execution time: 0.0825
DEBUG - 2023-06-12 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:39 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:39 --> URI Class Initialized
INFO - 2023-06-12 07:58:39 --> Router Class Initialized
INFO - 2023-06-12 07:58:39 --> Output Class Initialized
INFO - 2023-06-12 07:58:39 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:39 --> Input Class Initialized
INFO - 2023-06-12 07:58:39 --> Config Class Initialized
INFO - 2023-06-12 07:58:39 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:39 --> Language Class Initialized
INFO - 2023-06-12 07:58:39 --> Loader Class Initialized
DEBUG - 2023-06-12 07:58:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:39 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:39 --> Controller Class Initialized
INFO - 2023-06-12 07:58:39 --> URI Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:39 --> Router Class Initialized
INFO - 2023-06-12 07:58:39 --> Output Class Initialized
INFO - 2023-06-12 07:58:39 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:39 --> Input Class Initialized
INFO - 2023-06-12 07:58:39 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:39 --> Language Class Initialized
INFO - 2023-06-12 07:58:39 --> Loader Class Initialized
INFO - 2023-06-12 07:58:39 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:39 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:39 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:39 --> Total execution time: 0.0656
INFO - 2023-06-12 07:58:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:39 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:39 --> Total execution time: 0.0781
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0567
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0560
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0814
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0938
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0695
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0875
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:50 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:50 --> Total execution time: 0.0491
INFO - 2023-06-12 07:58:50 --> Config Class Initialized
INFO - 2023-06-12 07:58:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 07:58:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 07:58:50 --> Utf8 Class Initialized
INFO - 2023-06-12 07:58:50 --> URI Class Initialized
INFO - 2023-06-12 07:58:50 --> Router Class Initialized
INFO - 2023-06-12 07:58:50 --> Output Class Initialized
INFO - 2023-06-12 07:58:50 --> Security Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 07:58:50 --> Input Class Initialized
INFO - 2023-06-12 07:58:50 --> Language Class Initialized
INFO - 2023-06-12 07:58:50 --> Loader Class Initialized
INFO - 2023-06-12 07:58:50 --> Controller Class Initialized
DEBUG - 2023-06-12 07:58:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 07:58:50 --> Database Driver Class Initialized
INFO - 2023-06-12 07:58:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 07:58:51 --> Final output sent to browser
DEBUG - 2023-06-12 07:58:51 --> Total execution time: 0.0980
INFO - 2023-06-12 08:04:48 --> Config Class Initialized
INFO - 2023-06-12 08:04:48 --> Hooks Class Initialized
INFO - 2023-06-12 08:04:48 --> Config Class Initialized
INFO - 2023-06-12 08:04:48 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:48 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:04:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:48 --> URI Class Initialized
INFO - 2023-06-12 08:04:48 --> URI Class Initialized
INFO - 2023-06-12 08:04:48 --> Router Class Initialized
INFO - 2023-06-12 08:04:48 --> Router Class Initialized
INFO - 2023-06-12 08:04:48 --> Output Class Initialized
INFO - 2023-06-12 08:04:48 --> Output Class Initialized
INFO - 2023-06-12 08:04:48 --> Security Class Initialized
INFO - 2023-06-12 08:04:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:48 --> Input Class Initialized
INFO - 2023-06-12 08:04:48 --> Input Class Initialized
INFO - 2023-06-12 08:04:48 --> Language Class Initialized
INFO - 2023-06-12 08:04:48 --> Language Class Initialized
INFO - 2023-06-12 08:04:48 --> Loader Class Initialized
INFO - 2023-06-12 08:04:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:48 --> Loader Class Initialized
INFO - 2023-06-12 08:04:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:48 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:48 --> Total execution time: 0.0773
INFO - 2023-06-12 08:04:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:48 --> Config Class Initialized
INFO - 2023-06-12 08:04:48 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:48 --> URI Class Initialized
INFO - 2023-06-12 08:04:48 --> Router Class Initialized
INFO - 2023-06-12 08:04:48 --> Output Class Initialized
INFO - 2023-06-12 08:04:48 --> Final output sent to browser
INFO - 2023-06-12 08:04:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Total execution time: 0.1103
DEBUG - 2023-06-12 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:48 --> Input Class Initialized
INFO - 2023-06-12 08:04:48 --> Language Class Initialized
INFO - 2023-06-12 08:04:48 --> Loader Class Initialized
INFO - 2023-06-12 08:04:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:48 --> Config Class Initialized
INFO - 2023-06-12 08:04:48 --> Hooks Class Initialized
INFO - 2023-06-12 08:04:48 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:04:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:48 --> URI Class Initialized
INFO - 2023-06-12 08:04:48 --> Router Class Initialized
INFO - 2023-06-12 08:04:48 --> Output Class Initialized
INFO - 2023-06-12 08:04:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:48 --> Final output sent to browser
INFO - 2023-06-12 08:04:48 --> Input Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Total execution time: 0.0604
INFO - 2023-06-12 08:04:48 --> Language Class Initialized
INFO - 2023-06-12 08:04:48 --> Loader Class Initialized
INFO - 2023-06-12 08:04:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:48 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:48 --> Total execution time: 0.0876
INFO - 2023-06-12 08:04:51 --> Config Class Initialized
INFO - 2023-06-12 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:51 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:51 --> URI Class Initialized
INFO - 2023-06-12 08:04:51 --> Router Class Initialized
INFO - 2023-06-12 08:04:51 --> Output Class Initialized
INFO - 2023-06-12 08:04:51 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:51 --> Input Class Initialized
INFO - 2023-06-12 08:04:51 --> Language Class Initialized
INFO - 2023-06-12 08:04:51 --> Loader Class Initialized
INFO - 2023-06-12 08:04:51 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:51 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:51 --> Total execution time: 0.0624
INFO - 2023-06-12 08:04:51 --> Config Class Initialized
INFO - 2023-06-12 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:51 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:51 --> URI Class Initialized
INFO - 2023-06-12 08:04:51 --> Router Class Initialized
INFO - 2023-06-12 08:04:51 --> Output Class Initialized
INFO - 2023-06-12 08:04:51 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:51 --> Input Class Initialized
INFO - 2023-06-12 08:04:51 --> Language Class Initialized
INFO - 2023-06-12 08:04:51 --> Loader Class Initialized
INFO - 2023-06-12 08:04:51 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Login_model" initialized
INFO - 2023-06-12 08:04:51 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:51 --> Total execution time: 0.0844
INFO - 2023-06-12 08:04:51 --> Config Class Initialized
INFO - 2023-06-12 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:51 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:51 --> URI Class Initialized
INFO - 2023-06-12 08:04:51 --> Router Class Initialized
INFO - 2023-06-12 08:04:51 --> Output Class Initialized
INFO - 2023-06-12 08:04:51 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:51 --> Input Class Initialized
INFO - 2023-06-12 08:04:51 --> Language Class Initialized
INFO - 2023-06-12 08:04:51 --> Loader Class Initialized
INFO - 2023-06-12 08:04:51 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:51 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:51 --> Total execution time: 0.0657
INFO - 2023-06-12 08:04:51 --> Config Class Initialized
INFO - 2023-06-12 08:04:51 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:51 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:51 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:51 --> URI Class Initialized
INFO - 2023-06-12 08:04:51 --> Router Class Initialized
INFO - 2023-06-12 08:04:51 --> Output Class Initialized
INFO - 2023-06-12 08:04:51 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:51 --> Input Class Initialized
INFO - 2023-06-12 08:04:51 --> Language Class Initialized
INFO - 2023-06-12 08:04:51 --> Loader Class Initialized
INFO - 2023-06-12 08:04:51 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:51 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:51 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:51 --> Model "Login_model" initialized
INFO - 2023-06-12 08:04:51 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:51 --> Total execution time: 0.1028
INFO - 2023-06-12 08:04:54 --> Config Class Initialized
INFO - 2023-06-12 08:04:54 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:54 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:54 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:54 --> URI Class Initialized
INFO - 2023-06-12 08:04:54 --> Router Class Initialized
INFO - 2023-06-12 08:04:54 --> Output Class Initialized
INFO - 2023-06-12 08:04:54 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:54 --> Input Class Initialized
INFO - 2023-06-12 08:04:54 --> Language Class Initialized
INFO - 2023-06-12 08:04:54 --> Loader Class Initialized
INFO - 2023-06-12 08:04:54 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:54 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:54 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:54 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:54 --> Total execution time: 0.0698
INFO - 2023-06-12 08:04:54 --> Config Class Initialized
INFO - 2023-06-12 08:04:54 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:04:54 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:04:54 --> Utf8 Class Initialized
INFO - 2023-06-12 08:04:54 --> URI Class Initialized
INFO - 2023-06-12 08:04:54 --> Router Class Initialized
INFO - 2023-06-12 08:04:54 --> Output Class Initialized
INFO - 2023-06-12 08:04:54 --> Security Class Initialized
DEBUG - 2023-06-12 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:04:54 --> Input Class Initialized
INFO - 2023-06-12 08:04:54 --> Language Class Initialized
INFO - 2023-06-12 08:04:54 --> Loader Class Initialized
INFO - 2023-06-12 08:04:54 --> Controller Class Initialized
DEBUG - 2023-06-12 08:04:54 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:04:54 --> Database Driver Class Initialized
INFO - 2023-06-12 08:04:54 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:04:54 --> Final output sent to browser
DEBUG - 2023-06-12 08:04:54 --> Total execution time: 0.0632
INFO - 2023-06-12 08:05:04 --> Config Class Initialized
INFO - 2023-06-12 08:05:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:04 --> URI Class Initialized
INFO - 2023-06-12 08:05:04 --> Router Class Initialized
INFO - 2023-06-12 08:05:04 --> Output Class Initialized
INFO - 2023-06-12 08:05:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:04 --> Input Class Initialized
INFO - 2023-06-12 08:05:04 --> Language Class Initialized
INFO - 2023-06-12 08:05:04 --> Loader Class Initialized
INFO - 2023-06-12 08:05:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:04 --> Total execution time: 0.0557
INFO - 2023-06-12 08:05:04 --> Config Class Initialized
INFO - 2023-06-12 08:05:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:04 --> URI Class Initialized
INFO - 2023-06-12 08:05:04 --> Router Class Initialized
INFO - 2023-06-12 08:05:04 --> Output Class Initialized
INFO - 2023-06-12 08:05:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:04 --> Input Class Initialized
INFO - 2023-06-12 08:05:04 --> Language Class Initialized
INFO - 2023-06-12 08:05:04 --> Loader Class Initialized
INFO - 2023-06-12 08:05:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Login_model" initialized
INFO - 2023-06-12 08:05:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:04 --> Total execution time: 0.1038
INFO - 2023-06-12 08:05:04 --> Config Class Initialized
INFO - 2023-06-12 08:05:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:04 --> URI Class Initialized
INFO - 2023-06-12 08:05:04 --> Router Class Initialized
INFO - 2023-06-12 08:05:04 --> Output Class Initialized
INFO - 2023-06-12 08:05:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:04 --> Input Class Initialized
INFO - 2023-06-12 08:05:04 --> Language Class Initialized
INFO - 2023-06-12 08:05:04 --> Loader Class Initialized
INFO - 2023-06-12 08:05:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:04 --> Total execution time: 0.0683
INFO - 2023-06-12 08:05:04 --> Config Class Initialized
INFO - 2023-06-12 08:05:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:04 --> URI Class Initialized
INFO - 2023-06-12 08:05:04 --> Router Class Initialized
INFO - 2023-06-12 08:05:04 --> Output Class Initialized
INFO - 2023-06-12 08:05:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:04 --> Input Class Initialized
INFO - 2023-06-12 08:05:04 --> Language Class Initialized
INFO - 2023-06-12 08:05:04 --> Loader Class Initialized
INFO - 2023-06-12 08:05:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:04 --> Model "Login_model" initialized
INFO - 2023-06-12 08:05:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:04 --> Total execution time: 0.1049
INFO - 2023-06-12 08:05:06 --> Config Class Initialized
INFO - 2023-06-12 08:05:06 --> Config Class Initialized
INFO - 2023-06-12 08:05:06 --> Hooks Class Initialized
INFO - 2023-06-12 08:05:06 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:06 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:06 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:05:06 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:06 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:06 --> URI Class Initialized
INFO - 2023-06-12 08:05:06 --> URI Class Initialized
INFO - 2023-06-12 08:05:06 --> Router Class Initialized
INFO - 2023-06-12 08:05:06 --> Router Class Initialized
INFO - 2023-06-12 08:05:06 --> Output Class Initialized
INFO - 2023-06-12 08:05:06 --> Output Class Initialized
INFO - 2023-06-12 08:05:06 --> Security Class Initialized
INFO - 2023-06-12 08:05:06 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:06 --> Input Class Initialized
DEBUG - 2023-06-12 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:06 --> Input Class Initialized
INFO - 2023-06-12 08:05:06 --> Language Class Initialized
INFO - 2023-06-12 08:05:06 --> Language Class Initialized
INFO - 2023-06-12 08:05:07 --> Loader Class Initialized
INFO - 2023-06-12 08:05:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:07 --> Loader Class Initialized
INFO - 2023-06-12 08:05:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:07 --> Total execution time: 0.0616
INFO - 2023-06-12 08:05:07 --> Config Class Initialized
INFO - 2023-06-12 08:05:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:05:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:07 --> URI Class Initialized
INFO - 2023-06-12 08:05:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:07 --> Total execution time: 0.0798
INFO - 2023-06-12 08:05:07 --> Router Class Initialized
INFO - 2023-06-12 08:05:07 --> Output Class Initialized
INFO - 2023-06-12 08:05:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:07 --> Input Class Initialized
INFO - 2023-06-12 08:05:07 --> Language Class Initialized
INFO - 2023-06-12 08:05:07 --> Loader Class Initialized
INFO - 2023-06-12 08:05:07 --> Config Class Initialized
INFO - 2023-06-12 08:05:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:05:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:05:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:05:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:05:07 --> URI Class Initialized
INFO - 2023-06-12 08:05:07 --> Router Class Initialized
INFO - 2023-06-12 08:05:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:07 --> Output Class Initialized
INFO - 2023-06-12 08:05:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:05:07 --> Input Class Initialized
INFO - 2023-06-12 08:05:07 --> Language Class Initialized
INFO - 2023-06-12 08:05:07 --> Loader Class Initialized
INFO - 2023-06-12 08:05:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:05:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:05:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:05:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:07 --> Total execution time: 0.0671
INFO - 2023-06-12 08:05:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:05:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:05:07 --> Total execution time: 0.0768
INFO - 2023-06-12 08:07:19 --> Config Class Initialized
INFO - 2023-06-12 08:07:19 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:07:19 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:07:19 --> Utf8 Class Initialized
INFO - 2023-06-12 08:07:19 --> URI Class Initialized
INFO - 2023-06-12 08:07:19 --> Router Class Initialized
INFO - 2023-06-12 08:07:19 --> Output Class Initialized
INFO - 2023-06-12 08:07:19 --> Security Class Initialized
DEBUG - 2023-06-12 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:07:19 --> Input Class Initialized
INFO - 2023-06-12 08:07:19 --> Language Class Initialized
INFO - 2023-06-12 08:07:19 --> Loader Class Initialized
INFO - 2023-06-12 08:07:19 --> Controller Class Initialized
DEBUG - 2023-06-12 08:07:19 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:07:19 --> Database Driver Class Initialized
INFO - 2023-06-12 08:07:19 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:07:19 --> Final output sent to browser
DEBUG - 2023-06-12 08:07:19 --> Total execution time: 0.0560
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0810
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0939
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.1207
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.1251
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0859
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0955
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Config Class Initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0520
INFO - 2023-06-12 08:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:36 --> URI Class Initialized
INFO - 2023-06-12 08:09:36 --> Router Class Initialized
INFO - 2023-06-12 08:09:36 --> Output Class Initialized
INFO - 2023-06-12 08:09:36 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:36 --> Input Class Initialized
INFO - 2023-06-12 08:09:36 --> Language Class Initialized
INFO - 2023-06-12 08:09:36 --> Loader Class Initialized
INFO - 2023-06-12 08:09:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:36 --> Total execution time: 0.0826
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0593
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0729
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0787
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0936
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0716
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0944
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Config Class Initialized
INFO - 2023-06-12 08:09:46 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0621
DEBUG - 2023-06-12 08:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:46 --> URI Class Initialized
INFO - 2023-06-12 08:09:46 --> Router Class Initialized
INFO - 2023-06-12 08:09:46 --> Output Class Initialized
INFO - 2023-06-12 08:09:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:46 --> Input Class Initialized
INFO - 2023-06-12 08:09:46 --> Language Class Initialized
INFO - 2023-06-12 08:09:46 --> Loader Class Initialized
INFO - 2023-06-12 08:09:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:46 --> Total execution time: 0.0833
INFO - 2023-06-12 08:09:52 --> Config Class Initialized
INFO - 2023-06-12 08:09:52 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:52 --> Config Class Initialized
INFO - 2023-06-12 08:09:52 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:52 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:09:52 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:52 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:52 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:52 --> URI Class Initialized
INFO - 2023-06-12 08:09:52 --> URI Class Initialized
INFO - 2023-06-12 08:09:52 --> Router Class Initialized
INFO - 2023-06-12 08:09:52 --> Router Class Initialized
INFO - 2023-06-12 08:09:52 --> Output Class Initialized
INFO - 2023-06-12 08:09:52 --> Output Class Initialized
INFO - 2023-06-12 08:09:52 --> Security Class Initialized
INFO - 2023-06-12 08:09:52 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:52 --> Input Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:52 --> Language Class Initialized
INFO - 2023-06-12 08:09:52 --> Input Class Initialized
INFO - 2023-06-12 08:09:52 --> Language Class Initialized
INFO - 2023-06-12 08:09:52 --> Loader Class Initialized
INFO - 2023-06-12 08:09:52 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:52 --> Loader Class Initialized
INFO - 2023-06-12 08:09:52 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:52 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:52 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:52 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:52 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:52 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:52 --> Total execution time: 0.0778
INFO - 2023-06-12 08:09:52 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:52 --> Total execution time: 0.0810
INFO - 2023-06-12 08:09:52 --> Config Class Initialized
INFO - 2023-06-12 08:09:52 --> Hooks Class Initialized
INFO - 2023-06-12 08:09:52 --> Config Class Initialized
INFO - 2023-06-12 08:09:52 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:09:52 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:52 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:09:52 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:09:52 --> Utf8 Class Initialized
INFO - 2023-06-12 08:09:52 --> URI Class Initialized
INFO - 2023-06-12 08:09:52 --> URI Class Initialized
INFO - 2023-06-12 08:09:52 --> Router Class Initialized
INFO - 2023-06-12 08:09:52 --> Router Class Initialized
INFO - 2023-06-12 08:09:52 --> Output Class Initialized
INFO - 2023-06-12 08:09:52 --> Output Class Initialized
INFO - 2023-06-12 08:09:52 --> Security Class Initialized
INFO - 2023-06-12 08:09:52 --> Security Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:52 --> Input Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:09:52 --> Language Class Initialized
INFO - 2023-06-12 08:09:52 --> Input Class Initialized
INFO - 2023-06-12 08:09:52 --> Language Class Initialized
INFO - 2023-06-12 08:09:52 --> Loader Class Initialized
INFO - 2023-06-12 08:09:52 --> Controller Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:52 --> Loader Class Initialized
INFO - 2023-06-12 08:09:52 --> Controller Class Initialized
INFO - 2023-06-12 08:09:52 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:09:52 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:09:52 --> Database Driver Class Initialized
INFO - 2023-06-12 08:09:52 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:52 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:09:52 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:52 --> Total execution time: 0.0791
INFO - 2023-06-12 08:09:52 --> Final output sent to browser
DEBUG - 2023-06-12 08:09:52 --> Total execution time: 0.0789
INFO - 2023-06-12 08:10:02 --> Config Class Initialized
INFO - 2023-06-12 08:10:02 --> Config Class Initialized
INFO - 2023-06-12 08:10:02 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:02 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:10:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:02 --> URI Class Initialized
INFO - 2023-06-12 08:10:02 --> URI Class Initialized
INFO - 2023-06-12 08:10:02 --> Router Class Initialized
INFO - 2023-06-12 08:10:02 --> Router Class Initialized
INFO - 2023-06-12 08:10:02 --> Output Class Initialized
INFO - 2023-06-12 08:10:02 --> Output Class Initialized
INFO - 2023-06-12 08:10:02 --> Security Class Initialized
INFO - 2023-06-12 08:10:02 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:02 --> Input Class Initialized
INFO - 2023-06-12 08:10:02 --> Input Class Initialized
INFO - 2023-06-12 08:10:02 --> Language Class Initialized
INFO - 2023-06-12 08:10:02 --> Language Class Initialized
INFO - 2023-06-12 08:10:02 --> Loader Class Initialized
INFO - 2023-06-12 08:10:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:02 --> Loader Class Initialized
INFO - 2023-06-12 08:10:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:02 --> Total execution time: 0.0667
INFO - 2023-06-12 08:10:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:02 --> Config Class Initialized
INFO - 2023-06-12 08:10:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:02 --> URI Class Initialized
INFO - 2023-06-12 08:10:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:02 --> Total execution time: 0.0903
INFO - 2023-06-12 08:10:02 --> Router Class Initialized
INFO - 2023-06-12 08:10:02 --> Output Class Initialized
INFO - 2023-06-12 08:10:02 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:02 --> Input Class Initialized
INFO - 2023-06-12 08:10:02 --> Language Class Initialized
INFO - 2023-06-12 08:10:02 --> Loader Class Initialized
INFO - 2023-06-12 08:10:02 --> Config Class Initialized
INFO - 2023-06-12 08:10:02 --> Controller Class Initialized
INFO - 2023-06-12 08:10:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:10:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:02 --> URI Class Initialized
INFO - 2023-06-12 08:10:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:02 --> Router Class Initialized
INFO - 2023-06-12 08:10:02 --> Output Class Initialized
INFO - 2023-06-12 08:10:02 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:02 --> Input Class Initialized
INFO - 2023-06-12 08:10:02 --> Language Class Initialized
INFO - 2023-06-12 08:10:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:02 --> Total execution time: 0.0556
INFO - 2023-06-12 08:10:02 --> Loader Class Initialized
INFO - 2023-06-12 08:10:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:02 --> Total execution time: 0.0927
INFO - 2023-06-12 08:10:03 --> Config Class Initialized
INFO - 2023-06-12 08:10:03 --> Config Class Initialized
INFO - 2023-06-12 08:10:03 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:03 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:03 --> URI Class Initialized
INFO - 2023-06-12 08:10:03 --> URI Class Initialized
INFO - 2023-06-12 08:10:03 --> Router Class Initialized
INFO - 2023-06-12 08:10:03 --> Router Class Initialized
INFO - 2023-06-12 08:10:03 --> Output Class Initialized
INFO - 2023-06-12 08:10:03 --> Output Class Initialized
INFO - 2023-06-12 08:10:03 --> Security Class Initialized
INFO - 2023-06-12 08:10:03 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:03 --> Input Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:03 --> Language Class Initialized
INFO - 2023-06-12 08:10:03 --> Input Class Initialized
INFO - 2023-06-12 08:10:03 --> Language Class Initialized
INFO - 2023-06-12 08:10:03 --> Loader Class Initialized
INFO - 2023-06-12 08:10:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:03 --> Loader Class Initialized
INFO - 2023-06-12 08:10:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:03 --> Total execution time: 0.0945
INFO - 2023-06-12 08:10:03 --> Config Class Initialized
INFO - 2023-06-12 08:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:03 --> URI Class Initialized
INFO - 2023-06-12 08:10:03 --> Router Class Initialized
INFO - 2023-06-12 08:10:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:03 --> Total execution time: 0.1264
INFO - 2023-06-12 08:10:03 --> Output Class Initialized
INFO - 2023-06-12 08:10:03 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:03 --> Input Class Initialized
INFO - 2023-06-12 08:10:03 --> Language Class Initialized
INFO - 2023-06-12 08:10:03 --> Loader Class Initialized
INFO - 2023-06-12 08:10:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:03 --> Config Class Initialized
INFO - 2023-06-12 08:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:03 --> URI Class Initialized
INFO - 2023-06-12 08:10:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:03 --> Router Class Initialized
INFO - 2023-06-12 08:10:03 --> Output Class Initialized
INFO - 2023-06-12 08:10:03 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:03 --> Input Class Initialized
INFO - 2023-06-12 08:10:03 --> Language Class Initialized
INFO - 2023-06-12 08:10:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:03 --> Total execution time: 0.0674
INFO - 2023-06-12 08:10:03 --> Loader Class Initialized
INFO - 2023-06-12 08:10:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:04 --> Total execution time: 0.0995
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0605
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0627
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0836
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.1020
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0824
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0953
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Config Class Initialized
INFO - 2023-06-12 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:10:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:10:24 --> URI Class Initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Router Class Initialized
INFO - 2023-06-12 08:10:24 --> Output Class Initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.0571
INFO - 2023-06-12 08:10:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:10:24 --> Input Class Initialized
INFO - 2023-06-12 08:10:24 --> Language Class Initialized
INFO - 2023-06-12 08:10:24 --> Loader Class Initialized
INFO - 2023-06-12 08:10:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:10:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:10:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:10:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:10:24 --> Total execution time: 0.1053
INFO - 2023-06-12 08:16:24 --> Config Class Initialized
INFO - 2023-06-12 08:16:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:24 --> Config Class Initialized
INFO - 2023-06-12 08:16:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:16:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:24 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:16:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:24 --> URI Class Initialized
INFO - 2023-06-12 08:16:24 --> URI Class Initialized
INFO - 2023-06-12 08:16:24 --> Router Class Initialized
INFO - 2023-06-12 08:16:24 --> Router Class Initialized
INFO - 2023-06-12 08:16:24 --> Output Class Initialized
INFO - 2023-06-12 08:16:24 --> Output Class Initialized
INFO - 2023-06-12 08:16:24 --> Security Class Initialized
INFO - 2023-06-12 08:16:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:24 --> Input Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:24 --> Input Class Initialized
INFO - 2023-06-12 08:16:24 --> Language Class Initialized
INFO - 2023-06-12 08:16:24 --> Language Class Initialized
INFO - 2023-06-12 08:16:24 --> Loader Class Initialized
INFO - 2023-06-12 08:16:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:24 --> Loader Class Initialized
INFO - 2023-06-12 08:16:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:24 --> Total execution time: 0.0747
INFO - 2023-06-12 08:16:24 --> Config Class Initialized
INFO - 2023-06-12 08:16:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:24 --> Total execution time: 0.0880
DEBUG - 2023-06-12 08:16:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:24 --> URI Class Initialized
INFO - 2023-06-12 08:16:24 --> Router Class Initialized
INFO - 2023-06-12 08:16:24 --> Output Class Initialized
INFO - 2023-06-12 08:16:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:24 --> Input Class Initialized
INFO - 2023-06-12 08:16:24 --> Config Class Initialized
INFO - 2023-06-12 08:16:24 --> Language Class Initialized
INFO - 2023-06-12 08:16:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:24 --> Loader Class Initialized
DEBUG - 2023-06-12 08:16:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:24 --> Controller Class Initialized
INFO - 2023-06-12 08:16:24 --> URI Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:24 --> Router Class Initialized
INFO - 2023-06-12 08:16:24 --> Output Class Initialized
INFO - 2023-06-12 08:16:24 --> Security Class Initialized
INFO - 2023-06-12 08:16:24 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:24 --> Input Class Initialized
INFO - 2023-06-12 08:16:24 --> Language Class Initialized
INFO - 2023-06-12 08:16:24 --> Loader Class Initialized
INFO - 2023-06-12 08:16:24 --> Controller Class Initialized
INFO - 2023-06-12 08:16:24 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:16:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:24 --> Total execution time: 0.0587
INFO - 2023-06-12 08:16:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:25 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:25 --> Total execution time: 0.0789
INFO - 2023-06-12 08:16:25 --> Config Class Initialized
INFO - 2023-06-12 08:16:25 --> Config Class Initialized
INFO - 2023-06-12 08:16:25 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:25 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:16:25 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:25 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:25 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:25 --> URI Class Initialized
INFO - 2023-06-12 08:16:25 --> URI Class Initialized
INFO - 2023-06-12 08:16:25 --> Router Class Initialized
INFO - 2023-06-12 08:16:25 --> Router Class Initialized
INFO - 2023-06-12 08:16:25 --> Output Class Initialized
INFO - 2023-06-12 08:16:25 --> Output Class Initialized
INFO - 2023-06-12 08:16:25 --> Security Class Initialized
INFO - 2023-06-12 08:16:25 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:25 --> Input Class Initialized
INFO - 2023-06-12 08:16:25 --> Input Class Initialized
INFO - 2023-06-12 08:16:25 --> Language Class Initialized
INFO - 2023-06-12 08:16:25 --> Language Class Initialized
INFO - 2023-06-12 08:16:25 --> Loader Class Initialized
INFO - 2023-06-12 08:16:25 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:25 --> Loader Class Initialized
INFO - 2023-06-12 08:16:25 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:25 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:25 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:25 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:25 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:25 --> Total execution time: 0.0711
INFO - 2023-06-12 08:16:25 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:25 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:25 --> Total execution time: 0.1071
INFO - 2023-06-12 08:16:28 --> Config Class Initialized
INFO - 2023-06-12 08:16:28 --> Config Class Initialized
INFO - 2023-06-12 08:16:28 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:16:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:16:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:28 --> URI Class Initialized
INFO - 2023-06-12 08:16:28 --> URI Class Initialized
INFO - 2023-06-12 08:16:28 --> Router Class Initialized
INFO - 2023-06-12 08:16:28 --> Router Class Initialized
INFO - 2023-06-12 08:16:28 --> Output Class Initialized
INFO - 2023-06-12 08:16:28 --> Output Class Initialized
INFO - 2023-06-12 08:16:28 --> Security Class Initialized
INFO - 2023-06-12 08:16:28 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:28 --> Input Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:28 --> Input Class Initialized
INFO - 2023-06-12 08:16:28 --> Language Class Initialized
INFO - 2023-06-12 08:16:28 --> Language Class Initialized
INFO - 2023-06-12 08:16:28 --> Loader Class Initialized
INFO - 2023-06-12 08:16:28 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:28 --> Loader Class Initialized
INFO - 2023-06-12 08:16:28 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:28 --> Total execution time: 0.0828
INFO - 2023-06-12 08:16:28 --> Config Class Initialized
INFO - 2023-06-12 08:16:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:16:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:28 --> Total execution time: 0.1030
INFO - 2023-06-12 08:16:28 --> URI Class Initialized
INFO - 2023-06-12 08:16:28 --> Router Class Initialized
INFO - 2023-06-12 08:16:28 --> Output Class Initialized
INFO - 2023-06-12 08:16:28 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:28 --> Input Class Initialized
INFO - 2023-06-12 08:16:28 --> Language Class Initialized
INFO - 2023-06-12 08:16:28 --> Config Class Initialized
INFO - 2023-06-12 08:16:28 --> Loader Class Initialized
INFO - 2023-06-12 08:16:28 --> Hooks Class Initialized
INFO - 2023-06-12 08:16:28 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:16:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:16:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:16:28 --> URI Class Initialized
INFO - 2023-06-12 08:16:28 --> Router Class Initialized
INFO - 2023-06-12 08:16:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:28 --> Output Class Initialized
INFO - 2023-06-12 08:16:29 --> Security Class Initialized
DEBUG - 2023-06-12 08:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:16:29 --> Input Class Initialized
INFO - 2023-06-12 08:16:29 --> Language Class Initialized
INFO - 2023-06-12 08:16:29 --> Loader Class Initialized
INFO - 2023-06-12 08:16:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:16:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:16:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:16:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:16:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:29 --> Total execution time: 0.0805
INFO - 2023-06-12 08:16:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:16:29 --> Total execution time: 0.0767
INFO - 2023-06-12 08:17:02 --> Config Class Initialized
INFO - 2023-06-12 08:17:02 --> Config Class Initialized
INFO - 2023-06-12 08:17:02 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:02 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:17:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:02 --> URI Class Initialized
INFO - 2023-06-12 08:17:02 --> URI Class Initialized
INFO - 2023-06-12 08:17:02 --> Router Class Initialized
INFO - 2023-06-12 08:17:02 --> Router Class Initialized
INFO - 2023-06-12 08:17:02 --> Output Class Initialized
INFO - 2023-06-12 08:17:02 --> Output Class Initialized
INFO - 2023-06-12 08:17:02 --> Security Class Initialized
INFO - 2023-06-12 08:17:02 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:02 --> Input Class Initialized
INFO - 2023-06-12 08:17:02 --> Input Class Initialized
INFO - 2023-06-12 08:17:02 --> Language Class Initialized
INFO - 2023-06-12 08:17:02 --> Language Class Initialized
INFO - 2023-06-12 08:17:02 --> Loader Class Initialized
INFO - 2023-06-12 08:17:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:02 --> Loader Class Initialized
INFO - 2023-06-12 08:17:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:02 --> Final output sent to browser
INFO - 2023-06-12 08:17:02 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:17:02 --> Total execution time: 0.0871
INFO - 2023-06-12 08:17:02 --> Config Class Initialized
INFO - 2023-06-12 08:17:02 --> Final output sent to browser
INFO - 2023-06-12 08:17:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Total execution time: 0.1181
DEBUG - 2023-06-12 08:17:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:02 --> URI Class Initialized
INFO - 2023-06-12 08:17:02 --> Router Class Initialized
INFO - 2023-06-12 08:17:02 --> Output Class Initialized
INFO - 2023-06-12 08:17:02 --> Security Class Initialized
INFO - 2023-06-12 08:17:02 --> Config Class Initialized
INFO - 2023-06-12 08:17:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:02 --> Input Class Initialized
INFO - 2023-06-12 08:17:02 --> Language Class Initialized
DEBUG - 2023-06-12 08:17:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:02 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:02 --> Loader Class Initialized
INFO - 2023-06-12 08:17:02 --> URI Class Initialized
INFO - 2023-06-12 08:17:02 --> Controller Class Initialized
INFO - 2023-06-12 08:17:02 --> Router Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:02 --> Output Class Initialized
INFO - 2023-06-12 08:17:02 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:02 --> Input Class Initialized
INFO - 2023-06-12 08:17:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:02 --> Language Class Initialized
INFO - 2023-06-12 08:17:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:02 --> Total execution time: 0.1090
INFO - 2023-06-12 08:17:02 --> Loader Class Initialized
INFO - 2023-06-12 08:17:02 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:02 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:02 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:02 --> Total execution time: 0.2100
INFO - 2023-06-12 08:17:04 --> Config Class Initialized
INFO - 2023-06-12 08:17:04 --> Config Class Initialized
INFO - 2023-06-12 08:17:04 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:04 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:04 --> URI Class Initialized
INFO - 2023-06-12 08:17:04 --> URI Class Initialized
INFO - 2023-06-12 08:17:04 --> Router Class Initialized
INFO - 2023-06-12 08:17:04 --> Router Class Initialized
INFO - 2023-06-12 08:17:04 --> Output Class Initialized
INFO - 2023-06-12 08:17:04 --> Output Class Initialized
INFO - 2023-06-12 08:17:04 --> Security Class Initialized
INFO - 2023-06-12 08:17:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:04 --> Input Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:04 --> Language Class Initialized
INFO - 2023-06-12 08:17:04 --> Input Class Initialized
INFO - 2023-06-12 08:17:04 --> Language Class Initialized
INFO - 2023-06-12 08:17:04 --> Loader Class Initialized
INFO - 2023-06-12 08:17:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:04 --> Loader Class Initialized
INFO - 2023-06-12 08:17:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:04 --> Total execution time: 0.0715
INFO - 2023-06-12 08:17:04 --> Config Class Initialized
INFO - 2023-06-12 08:17:04 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:04 --> URI Class Initialized
INFO - 2023-06-12 08:17:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:04 --> Total execution time: 0.0938
INFO - 2023-06-12 08:17:04 --> Router Class Initialized
INFO - 2023-06-12 08:17:04 --> Output Class Initialized
INFO - 2023-06-12 08:17:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:04 --> Input Class Initialized
INFO - 2023-06-12 08:17:04 --> Language Class Initialized
INFO - 2023-06-12 08:17:04 --> Loader Class Initialized
INFO - 2023-06-12 08:17:04 --> Config Class Initialized
INFO - 2023-06-12 08:17:04 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:17:04 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:04 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:04 --> URI Class Initialized
INFO - 2023-06-12 08:17:04 --> Router Class Initialized
INFO - 2023-06-12 08:17:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:04 --> Output Class Initialized
INFO - 2023-06-12 08:17:04 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:04 --> Input Class Initialized
INFO - 2023-06-12 08:17:04 --> Language Class Initialized
INFO - 2023-06-12 08:17:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:04 --> Total execution time: 0.0556
INFO - 2023-06-12 08:17:04 --> Loader Class Initialized
INFO - 2023-06-12 08:17:04 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:04 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:04 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:04 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:04 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:04 --> Total execution time: 0.0777
INFO - 2023-06-12 08:17:23 --> Config Class Initialized
INFO - 2023-06-12 08:17:23 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:23 --> Config Class Initialized
INFO - 2023-06-12 08:17:23 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:23 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:23 --> URI Class Initialized
INFO - 2023-06-12 08:17:23 --> URI Class Initialized
INFO - 2023-06-12 08:17:23 --> Router Class Initialized
INFO - 2023-06-12 08:17:23 --> Router Class Initialized
INFO - 2023-06-12 08:17:23 --> Output Class Initialized
INFO - 2023-06-12 08:17:23 --> Output Class Initialized
INFO - 2023-06-12 08:17:23 --> Security Class Initialized
INFO - 2023-06-12 08:17:23 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:23 --> Input Class Initialized
INFO - 2023-06-12 08:17:23 --> Input Class Initialized
INFO - 2023-06-12 08:17:23 --> Language Class Initialized
INFO - 2023-06-12 08:17:23 --> Language Class Initialized
INFO - 2023-06-12 08:17:23 --> Loader Class Initialized
INFO - 2023-06-12 08:17:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:23 --> Loader Class Initialized
INFO - 2023-06-12 08:17:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:23 --> Total execution time: 0.0676
INFO - 2023-06-12 08:17:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:23 --> Config Class Initialized
INFO - 2023-06-12 08:17:23 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:23 --> URI Class Initialized
INFO - 2023-06-12 08:17:23 --> Router Class Initialized
INFO - 2023-06-12 08:17:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:23 --> Total execution time: 0.0955
INFO - 2023-06-12 08:17:23 --> Output Class Initialized
INFO - 2023-06-12 08:17:23 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:23 --> Input Class Initialized
INFO - 2023-06-12 08:17:23 --> Language Class Initialized
INFO - 2023-06-12 08:17:23 --> Loader Class Initialized
INFO - 2023-06-12 08:17:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:23 --> Config Class Initialized
INFO - 2023-06-12 08:17:23 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:23 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:17:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:23 --> URI Class Initialized
INFO - 2023-06-12 08:17:23 --> Router Class Initialized
INFO - 2023-06-12 08:17:23 --> Output Class Initialized
INFO - 2023-06-12 08:17:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:23 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:23 --> Input Class Initialized
INFO - 2023-06-12 08:17:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:23 --> Total execution time: 0.0656
INFO - 2023-06-12 08:17:23 --> Language Class Initialized
INFO - 2023-06-12 08:17:23 --> Loader Class Initialized
INFO - 2023-06-12 08:17:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:23 --> Total execution time: 0.0820
INFO - 2023-06-12 08:17:24 --> Config Class Initialized
INFO - 2023-06-12 08:17:24 --> Config Class Initialized
INFO - 2023-06-12 08:17:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:17:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:24 --> URI Class Initialized
INFO - 2023-06-12 08:17:24 --> URI Class Initialized
INFO - 2023-06-12 08:17:24 --> Router Class Initialized
INFO - 2023-06-12 08:17:24 --> Router Class Initialized
INFO - 2023-06-12 08:17:24 --> Output Class Initialized
INFO - 2023-06-12 08:17:24 --> Output Class Initialized
INFO - 2023-06-12 08:17:24 --> Security Class Initialized
INFO - 2023-06-12 08:17:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:24 --> Input Class Initialized
DEBUG - 2023-06-12 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:24 --> Language Class Initialized
INFO - 2023-06-12 08:17:24 --> Input Class Initialized
INFO - 2023-06-12 08:17:24 --> Language Class Initialized
INFO - 2023-06-12 08:17:24 --> Loader Class Initialized
INFO - 2023-06-12 08:17:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:24 --> Loader Class Initialized
INFO - 2023-06-12 08:17:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:24 --> Total execution time: 0.0795
INFO - 2023-06-12 08:17:24 --> Config Class Initialized
INFO - 2023-06-12 08:17:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:24 --> Total execution time: 0.1007
DEBUG - 2023-06-12 08:17:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:24 --> URI Class Initialized
INFO - 2023-06-12 08:17:24 --> Router Class Initialized
INFO - 2023-06-12 08:17:24 --> Output Class Initialized
INFO - 2023-06-12 08:17:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:24 --> Input Class Initialized
INFO - 2023-06-12 08:17:25 --> Config Class Initialized
INFO - 2023-06-12 08:17:25 --> Language Class Initialized
INFO - 2023-06-12 08:17:25 --> Hooks Class Initialized
INFO - 2023-06-12 08:17:25 --> Loader Class Initialized
DEBUG - 2023-06-12 08:17:25 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:17:25 --> Utf8 Class Initialized
INFO - 2023-06-12 08:17:25 --> Controller Class Initialized
INFO - 2023-06-12 08:17:25 --> URI Class Initialized
DEBUG - 2023-06-12 08:17:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:25 --> Router Class Initialized
INFO - 2023-06-12 08:17:25 --> Output Class Initialized
INFO - 2023-06-12 08:17:25 --> Security Class Initialized
INFO - 2023-06-12 08:17:25 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:17:25 --> Input Class Initialized
INFO - 2023-06-12 08:17:25 --> Language Class Initialized
INFO - 2023-06-12 08:17:25 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:25 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:25 --> Total execution time: 0.0629
INFO - 2023-06-12 08:17:25 --> Loader Class Initialized
INFO - 2023-06-12 08:17:25 --> Controller Class Initialized
DEBUG - 2023-06-12 08:17:25 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:17:25 --> Database Driver Class Initialized
INFO - 2023-06-12 08:17:25 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:17:25 --> Final output sent to browser
DEBUG - 2023-06-12 08:17:25 --> Total execution time: 0.1037
INFO - 2023-06-12 08:18:38 --> Config Class Initialized
INFO - 2023-06-12 08:18:38 --> Config Class Initialized
INFO - 2023-06-12 08:18:38 --> Hooks Class Initialized
INFO - 2023-06-12 08:18:38 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:18:38 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:38 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:18:38 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:38 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:38 --> URI Class Initialized
INFO - 2023-06-12 08:18:38 --> URI Class Initialized
INFO - 2023-06-12 08:18:38 --> Router Class Initialized
INFO - 2023-06-12 08:18:38 --> Router Class Initialized
INFO - 2023-06-12 08:18:38 --> Output Class Initialized
INFO - 2023-06-12 08:18:38 --> Output Class Initialized
INFO - 2023-06-12 08:18:38 --> Security Class Initialized
INFO - 2023-06-12 08:18:38 --> Security Class Initialized
DEBUG - 2023-06-12 08:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:38 --> Input Class Initialized
INFO - 2023-06-12 08:18:38 --> Input Class Initialized
INFO - 2023-06-12 08:18:38 --> Language Class Initialized
INFO - 2023-06-12 08:18:38 --> Language Class Initialized
INFO - 2023-06-12 08:18:38 --> Loader Class Initialized
INFO - 2023-06-12 08:18:38 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:38 --> Loader Class Initialized
INFO - 2023-06-12 08:18:38 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:38 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:38 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:38 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:39 --> Total execution time: 0.0902
INFO - 2023-06-12 08:18:39 --> Config Class Initialized
INFO - 2023-06-12 08:18:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:18:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:39 --> URI Class Initialized
INFO - 2023-06-12 08:18:39 --> Router Class Initialized
INFO - 2023-06-12 08:18:39 --> Output Class Initialized
INFO - 2023-06-12 08:18:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:39 --> Input Class Initialized
INFO - 2023-06-12 08:18:39 --> Language Class Initialized
INFO - 2023-06-12 08:18:39 --> Loader Class Initialized
INFO - 2023-06-12 08:18:39 --> Controller Class Initialized
INFO - 2023-06-12 08:18:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:18:39 --> Total execution time: 0.1413
INFO - 2023-06-12 08:18:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:39 --> Config Class Initialized
INFO - 2023-06-12 08:18:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:18:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:39 --> URI Class Initialized
INFO - 2023-06-12 08:18:39 --> Router Class Initialized
INFO - 2023-06-12 08:18:39 --> Output Class Initialized
INFO - 2023-06-12 08:18:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:39 --> Input Class Initialized
INFO - 2023-06-12 08:18:39 --> Language Class Initialized
INFO - 2023-06-12 08:18:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:39 --> Loader Class Initialized
INFO - 2023-06-12 08:18:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:39 --> Total execution time: 0.0923
INFO - 2023-06-12 08:18:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:39 --> Total execution time: 0.1116
INFO - 2023-06-12 08:18:40 --> Config Class Initialized
INFO - 2023-06-12 08:18:40 --> Hooks Class Initialized
INFO - 2023-06-12 08:18:40 --> Config Class Initialized
INFO - 2023-06-12 08:18:40 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:18:40 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:40 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:18:40 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:40 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:40 --> URI Class Initialized
INFO - 2023-06-12 08:18:40 --> URI Class Initialized
INFO - 2023-06-12 08:18:40 --> Router Class Initialized
INFO - 2023-06-12 08:18:40 --> Router Class Initialized
INFO - 2023-06-12 08:18:40 --> Output Class Initialized
INFO - 2023-06-12 08:18:40 --> Output Class Initialized
INFO - 2023-06-12 08:18:40 --> Security Class Initialized
INFO - 2023-06-12 08:18:40 --> Security Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:40 --> Input Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:40 --> Input Class Initialized
INFO - 2023-06-12 08:18:40 --> Language Class Initialized
INFO - 2023-06-12 08:18:40 --> Language Class Initialized
INFO - 2023-06-12 08:18:40 --> Loader Class Initialized
INFO - 2023-06-12 08:18:40 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:40 --> Loader Class Initialized
INFO - 2023-06-12 08:18:40 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:40 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:40 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:40 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:40 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:40 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:40 --> Total execution time: 0.0733
INFO - 2023-06-12 08:18:40 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:40 --> Total execution time: 0.0793
INFO - 2023-06-12 08:18:40 --> Config Class Initialized
INFO - 2023-06-12 08:18:40 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:18:40 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:40 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:40 --> URI Class Initialized
INFO - 2023-06-12 08:18:40 --> Config Class Initialized
INFO - 2023-06-12 08:18:40 --> Hooks Class Initialized
INFO - 2023-06-12 08:18:40 --> Router Class Initialized
INFO - 2023-06-12 08:18:40 --> Output Class Initialized
DEBUG - 2023-06-12 08:18:40 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:18:40 --> Utf8 Class Initialized
INFO - 2023-06-12 08:18:40 --> Security Class Initialized
INFO - 2023-06-12 08:18:40 --> URI Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:40 --> Input Class Initialized
INFO - 2023-06-12 08:18:40 --> Router Class Initialized
INFO - 2023-06-12 08:18:40 --> Language Class Initialized
INFO - 2023-06-12 08:18:40 --> Output Class Initialized
INFO - 2023-06-12 08:18:40 --> Security Class Initialized
INFO - 2023-06-12 08:18:40 --> Loader Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:18:40 --> Input Class Initialized
INFO - 2023-06-12 08:18:40 --> Controller Class Initialized
INFO - 2023-06-12 08:18:40 --> Language Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:40 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:40 --> Loader Class Initialized
INFO - 2023-06-12 08:18:40 --> Controller Class Initialized
DEBUG - 2023-06-12 08:18:40 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:18:40 --> Database Driver Class Initialized
INFO - 2023-06-12 08:18:40 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:40 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:18:40 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:40 --> Total execution time: 0.0822
INFO - 2023-06-12 08:18:40 --> Final output sent to browser
DEBUG - 2023-06-12 08:18:40 --> Total execution time: 0.0897
INFO - 2023-06-12 08:21:12 --> Config Class Initialized
INFO - 2023-06-12 08:21:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:12 --> URI Class Initialized
INFO - 2023-06-12 08:21:12 --> Router Class Initialized
INFO - 2023-06-12 08:21:12 --> Output Class Initialized
INFO - 2023-06-12 08:21:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:12 --> Input Class Initialized
INFO - 2023-06-12 08:21:12 --> Language Class Initialized
INFO - 2023-06-12 08:21:12 --> Loader Class Initialized
INFO - 2023-06-12 08:21:12 --> Controller Class Initialized
INFO - 2023-06-12 08:21:12 --> Helper loaded: form_helper
INFO - 2023-06-12 08:21:12 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:21:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:12 --> Model "Change_model" initialized
INFO - 2023-06-12 08:21:12 --> Model "Grafana_model" initialized
INFO - 2023-06-12 08:21:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:12 --> Total execution time: 0.1480
INFO - 2023-06-12 08:21:12 --> Config Class Initialized
INFO - 2023-06-12 08:21:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:12 --> URI Class Initialized
INFO - 2023-06-12 08:21:12 --> Router Class Initialized
INFO - 2023-06-12 08:21:12 --> Output Class Initialized
INFO - 2023-06-12 08:21:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:12 --> Input Class Initialized
INFO - 2023-06-12 08:21:12 --> Language Class Initialized
INFO - 2023-06-12 08:21:12 --> Loader Class Initialized
INFO - 2023-06-12 08:21:12 --> Controller Class Initialized
INFO - 2023-06-12 08:21:12 --> Helper loaded: form_helper
INFO - 2023-06-12 08:21:12 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:21:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:12 --> Total execution time: 0.0322
INFO - 2023-06-12 08:21:12 --> Config Class Initialized
INFO - 2023-06-12 08:21:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:12 --> URI Class Initialized
INFO - 2023-06-12 08:21:12 --> Router Class Initialized
INFO - 2023-06-12 08:21:12 --> Output Class Initialized
INFO - 2023-06-12 08:21:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:12 --> Input Class Initialized
INFO - 2023-06-12 08:21:12 --> Language Class Initialized
INFO - 2023-06-12 08:21:12 --> Loader Class Initialized
INFO - 2023-06-12 08:21:12 --> Controller Class Initialized
INFO - 2023-06-12 08:21:12 --> Helper loaded: form_helper
INFO - 2023-06-12 08:21:12 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:21:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:12 --> Model "Login_model" initialized
INFO - 2023-06-12 08:21:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:12 --> Total execution time: 0.0735
INFO - 2023-06-12 08:21:12 --> Config Class Initialized
INFO - 2023-06-12 08:21:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:12 --> URI Class Initialized
INFO - 2023-06-12 08:21:12 --> Router Class Initialized
INFO - 2023-06-12 08:21:12 --> Output Class Initialized
INFO - 2023-06-12 08:21:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:12 --> Input Class Initialized
INFO - 2023-06-12 08:21:12 --> Language Class Initialized
INFO - 2023-06-12 08:21:12 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0950
INFO - 2023-06-12 08:21:13 --> Config Class Initialized
INFO - 2023-06-12 08:21:13 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:13 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:13 --> URI Class Initialized
INFO - 2023-06-12 08:21:13 --> Router Class Initialized
INFO - 2023-06-12 08:21:13 --> Output Class Initialized
INFO - 2023-06-12 08:21:13 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:13 --> Input Class Initialized
INFO - 2023-06-12 08:21:13 --> Language Class Initialized
INFO - 2023-06-12 08:21:13 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0950
INFO - 2023-06-12 08:21:13 --> Config Class Initialized
INFO - 2023-06-12 08:21:13 --> Hooks Class Initialized
INFO - 2023-06-12 08:21:13 --> Config Class Initialized
INFO - 2023-06-12 08:21:13 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:13 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:13 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:13 --> URI Class Initialized
INFO - 2023-06-12 08:21:13 --> URI Class Initialized
INFO - 2023-06-12 08:21:13 --> Router Class Initialized
INFO - 2023-06-12 08:21:13 --> Router Class Initialized
INFO - 2023-06-12 08:21:13 --> Output Class Initialized
INFO - 2023-06-12 08:21:13 --> Output Class Initialized
INFO - 2023-06-12 08:21:13 --> Security Class Initialized
INFO - 2023-06-12 08:21:13 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:13 --> Input Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:13 --> Input Class Initialized
INFO - 2023-06-12 08:21:13 --> Language Class Initialized
INFO - 2023-06-12 08:21:13 --> Language Class Initialized
INFO - 2023-06-12 08:21:13 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0699
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0757
INFO - 2023-06-12 08:21:13 --> Config Class Initialized
INFO - 2023-06-12 08:21:13 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:13 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:13 --> Config Class Initialized
INFO - 2023-06-12 08:21:13 --> Hooks Class Initialized
INFO - 2023-06-12 08:21:13 --> URI Class Initialized
INFO - 2023-06-12 08:21:13 --> Router Class Initialized
DEBUG - 2023-06-12 08:21:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:13 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:13 --> Output Class Initialized
INFO - 2023-06-12 08:21:13 --> URI Class Initialized
INFO - 2023-06-12 08:21:13 --> Security Class Initialized
INFO - 2023-06-12 08:21:13 --> Router Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:13 --> Input Class Initialized
INFO - 2023-06-12 08:21:13 --> Language Class Initialized
INFO - 2023-06-12 08:21:13 --> Output Class Initialized
INFO - 2023-06-12 08:21:13 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:13 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Input Class Initialized
INFO - 2023-06-12 08:21:13 --> Language Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Loader Class Initialized
INFO - 2023-06-12 08:21:13 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0570
INFO - 2023-06-12 08:21:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:13 --> Total execution time: 0.0893
INFO - 2023-06-12 08:21:20 --> Config Class Initialized
INFO - 2023-06-12 08:21:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:20 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:20 --> URI Class Initialized
INFO - 2023-06-12 08:21:20 --> Router Class Initialized
INFO - 2023-06-12 08:21:20 --> Output Class Initialized
INFO - 2023-06-12 08:21:20 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:20 --> Input Class Initialized
INFO - 2023-06-12 08:21:20 --> Language Class Initialized
INFO - 2023-06-12 08:21:20 --> Loader Class Initialized
INFO - 2023-06-12 08:21:20 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:20 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:20 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:20 --> Total execution time: 0.0933
INFO - 2023-06-12 08:21:20 --> Config Class Initialized
INFO - 2023-06-12 08:21:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:21:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:21:20 --> Utf8 Class Initialized
INFO - 2023-06-12 08:21:20 --> URI Class Initialized
INFO - 2023-06-12 08:21:20 --> Router Class Initialized
INFO - 2023-06-12 08:21:20 --> Output Class Initialized
INFO - 2023-06-12 08:21:20 --> Security Class Initialized
DEBUG - 2023-06-12 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:21:20 --> Input Class Initialized
INFO - 2023-06-12 08:21:20 --> Language Class Initialized
INFO - 2023-06-12 08:21:20 --> Loader Class Initialized
INFO - 2023-06-12 08:21:20 --> Controller Class Initialized
DEBUG - 2023-06-12 08:21:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:21:20 --> Database Driver Class Initialized
INFO - 2023-06-12 08:21:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:21:20 --> Final output sent to browser
DEBUG - 2023-06-12 08:21:20 --> Total execution time: 0.0715
INFO - 2023-06-12 08:22:07 --> Config Class Initialized
INFO - 2023-06-12 08:22:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:22:07 --> Config Class Initialized
INFO - 2023-06-12 08:22:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:07 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:22:07 --> URI Class Initialized
INFO - 2023-06-12 08:22:07 --> URI Class Initialized
INFO - 2023-06-12 08:22:07 --> Router Class Initialized
INFO - 2023-06-12 08:22:07 --> Router Class Initialized
INFO - 2023-06-12 08:22:07 --> Output Class Initialized
INFO - 2023-06-12 08:22:07 --> Output Class Initialized
INFO - 2023-06-12 08:22:07 --> Security Class Initialized
INFO - 2023-06-12 08:22:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:07 --> Input Class Initialized
INFO - 2023-06-12 08:22:07 --> Input Class Initialized
INFO - 2023-06-12 08:22:07 --> Language Class Initialized
INFO - 2023-06-12 08:22:07 --> Language Class Initialized
INFO - 2023-06-12 08:22:07 --> Loader Class Initialized
INFO - 2023-06-12 08:22:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:07 --> Loader Class Initialized
INFO - 2023-06-12 08:22:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:07 --> Total execution time: 0.0962
INFO - 2023-06-12 08:22:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:07 --> Total execution time: 0.1060
INFO - 2023-06-12 08:22:07 --> Config Class Initialized
INFO - 2023-06-12 08:22:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:22:07 --> URI Class Initialized
INFO - 2023-06-12 08:22:07 --> Router Class Initialized
INFO - 2023-06-12 08:22:07 --> Config Class Initialized
INFO - 2023-06-12 08:22:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:22:07 --> Output Class Initialized
INFO - 2023-06-12 08:22:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:07 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:07 --> Input Class Initialized
INFO - 2023-06-12 08:22:07 --> URI Class Initialized
INFO - 2023-06-12 08:22:07 --> Language Class Initialized
INFO - 2023-06-12 08:22:07 --> Router Class Initialized
INFO - 2023-06-12 08:22:07 --> Output Class Initialized
INFO - 2023-06-12 08:22:07 --> Loader Class Initialized
INFO - 2023-06-12 08:22:07 --> Security Class Initialized
INFO - 2023-06-12 08:22:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:07 --> Input Class Initialized
INFO - 2023-06-12 08:22:07 --> Language Class Initialized
INFO - 2023-06-12 08:22:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:07 --> Loader Class Initialized
INFO - 2023-06-12 08:22:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:07 --> Final output sent to browser
INFO - 2023-06-12 08:22:07 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:22:07 --> Total execution time: 0.0774
INFO - 2023-06-12 08:22:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:07 --> Total execution time: 0.0905
INFO - 2023-06-12 08:22:17 --> Config Class Initialized
INFO - 2023-06-12 08:22:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:22:17 --> Config Class Initialized
INFO - 2023-06-12 08:22:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:17 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:22:17 --> URI Class Initialized
INFO - 2023-06-12 08:22:17 --> URI Class Initialized
INFO - 2023-06-12 08:22:17 --> Router Class Initialized
INFO - 2023-06-12 08:22:17 --> Router Class Initialized
INFO - 2023-06-12 08:22:17 --> Output Class Initialized
INFO - 2023-06-12 08:22:17 --> Output Class Initialized
INFO - 2023-06-12 08:22:17 --> Security Class Initialized
INFO - 2023-06-12 08:22:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:17 --> Input Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:17 --> Input Class Initialized
INFO - 2023-06-12 08:22:17 --> Language Class Initialized
INFO - 2023-06-12 08:22:17 --> Language Class Initialized
INFO - 2023-06-12 08:22:17 --> Loader Class Initialized
INFO - 2023-06-12 08:22:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:17 --> Loader Class Initialized
INFO - 2023-06-12 08:22:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:17 --> Final output sent to browser
INFO - 2023-06-12 08:22:17 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:22:17 --> Total execution time: 0.0747
INFO - 2023-06-12 08:22:17 --> Config Class Initialized
INFO - 2023-06-12 08:22:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:22:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:17 --> Total execution time: 0.0960
DEBUG - 2023-06-12 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:22:17 --> URI Class Initialized
INFO - 2023-06-12 08:22:17 --> Router Class Initialized
INFO - 2023-06-12 08:22:17 --> Output Class Initialized
INFO - 2023-06-12 08:22:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:17 --> Input Class Initialized
INFO - 2023-06-12 08:22:17 --> Config Class Initialized
INFO - 2023-06-12 08:22:17 --> Language Class Initialized
INFO - 2023-06-12 08:22:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:22:17 --> Loader Class Initialized
DEBUG - 2023-06-12 08:22:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:22:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:22:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:17 --> URI Class Initialized
INFO - 2023-06-12 08:22:17 --> Router Class Initialized
INFO - 2023-06-12 08:22:17 --> Output Class Initialized
INFO - 2023-06-12 08:22:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:22:17 --> Input Class Initialized
INFO - 2023-06-12 08:22:17 --> Language Class Initialized
INFO - 2023-06-12 08:22:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:17 --> Total execution time: 0.0669
INFO - 2023-06-12 08:22:17 --> Loader Class Initialized
INFO - 2023-06-12 08:22:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:22:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:22:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:22:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:22:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:22:17 --> Total execution time: 0.0889
INFO - 2023-06-12 08:23:11 --> Config Class Initialized
INFO - 2023-06-12 08:23:11 --> Hooks Class Initialized
INFO - 2023-06-12 08:23:11 --> Config Class Initialized
INFO - 2023-06-12 08:23:11 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:23:11 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:23:11 --> Utf8 Class Initialized
INFO - 2023-06-12 08:23:11 --> URI Class Initialized
INFO - 2023-06-12 08:23:11 --> URI Class Initialized
INFO - 2023-06-12 08:23:11 --> Router Class Initialized
INFO - 2023-06-12 08:23:11 --> Router Class Initialized
INFO - 2023-06-12 08:23:11 --> Output Class Initialized
INFO - 2023-06-12 08:23:11 --> Output Class Initialized
INFO - 2023-06-12 08:23:11 --> Security Class Initialized
INFO - 2023-06-12 08:23:11 --> Security Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:23:11 --> Input Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:23:11 --> Input Class Initialized
INFO - 2023-06-12 08:23:11 --> Language Class Initialized
INFO - 2023-06-12 08:23:11 --> Language Class Initialized
INFO - 2023-06-12 08:23:11 --> Loader Class Initialized
INFO - 2023-06-12 08:23:11 --> Controller Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:23:11 --> Loader Class Initialized
INFO - 2023-06-12 08:23:11 --> Controller Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:23:11 --> Database Driver Class Initialized
INFO - 2023-06-12 08:23:11 --> Database Driver Class Initialized
INFO - 2023-06-12 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:23:11 --> Final output sent to browser
DEBUG - 2023-06-12 08:23:11 --> Total execution time: 0.0765
INFO - 2023-06-12 08:23:11 --> Config Class Initialized
INFO - 2023-06-12 08:23:11 --> Hooks Class Initialized
INFO - 2023-06-12 08:23:11 --> Final output sent to browser
DEBUG - 2023-06-12 08:23:11 --> Total execution time: 0.0985
DEBUG - 2023-06-12 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:23:11 --> Utf8 Class Initialized
INFO - 2023-06-12 08:23:11 --> URI Class Initialized
INFO - 2023-06-12 08:23:11 --> Router Class Initialized
INFO - 2023-06-12 08:23:11 --> Output Class Initialized
INFO - 2023-06-12 08:23:11 --> Security Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:23:11 --> Input Class Initialized
INFO - 2023-06-12 08:23:11 --> Language Class Initialized
INFO - 2023-06-12 08:23:11 --> Config Class Initialized
INFO - 2023-06-12 08:23:11 --> Hooks Class Initialized
INFO - 2023-06-12 08:23:11 --> Loader Class Initialized
DEBUG - 2023-06-12 08:23:11 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:23:11 --> Controller Class Initialized
INFO - 2023-06-12 08:23:11 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:23:11 --> URI Class Initialized
INFO - 2023-06-12 08:23:11 --> Router Class Initialized
INFO - 2023-06-12 08:23:11 --> Output Class Initialized
INFO - 2023-06-12 08:23:11 --> Security Class Initialized
INFO - 2023-06-12 08:23:11 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:23:11 --> Input Class Initialized
INFO - 2023-06-12 08:23:11 --> Language Class Initialized
INFO - 2023-06-12 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:23:11 --> Final output sent to browser
INFO - 2023-06-12 08:23:11 --> Loader Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Total execution time: 0.0667
INFO - 2023-06-12 08:23:11 --> Controller Class Initialized
DEBUG - 2023-06-12 08:23:11 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:23:11 --> Database Driver Class Initialized
INFO - 2023-06-12 08:23:11 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:23:11 --> Final output sent to browser
DEBUG - 2023-06-12 08:23:11 --> Total execution time: 0.0897
INFO - 2023-06-12 08:24:15 --> Config Class Initialized
INFO - 2023-06-12 08:24:15 --> Config Class Initialized
INFO - 2023-06-12 08:24:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:24:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:15 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:24:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:15 --> URI Class Initialized
INFO - 2023-06-12 08:24:15 --> URI Class Initialized
INFO - 2023-06-12 08:24:15 --> Router Class Initialized
INFO - 2023-06-12 08:24:15 --> Router Class Initialized
INFO - 2023-06-12 08:24:15 --> Output Class Initialized
INFO - 2023-06-12 08:24:15 --> Output Class Initialized
INFO - 2023-06-12 08:24:15 --> Security Class Initialized
INFO - 2023-06-12 08:24:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:15 --> Input Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:15 --> Input Class Initialized
INFO - 2023-06-12 08:24:15 --> Language Class Initialized
INFO - 2023-06-12 08:24:15 --> Language Class Initialized
INFO - 2023-06-12 08:24:15 --> Loader Class Initialized
INFO - 2023-06-12 08:24:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:15 --> Loader Class Initialized
INFO - 2023-06-12 08:24:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:15 --> Total execution time: 0.0710
INFO - 2023-06-12 08:24:15 --> Config Class Initialized
INFO - 2023-06-12 08:24:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:15 --> URI Class Initialized
INFO - 2023-06-12 08:24:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:15 --> Total execution time: 0.0927
INFO - 2023-06-12 08:24:15 --> Router Class Initialized
INFO - 2023-06-12 08:24:15 --> Output Class Initialized
INFO - 2023-06-12 08:24:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:15 --> Input Class Initialized
INFO - 2023-06-12 08:24:15 --> Language Class Initialized
INFO - 2023-06-12 08:24:15 --> Loader Class Initialized
INFO - 2023-06-12 08:24:15 --> Controller Class Initialized
INFO - 2023-06-12 08:24:15 --> Config Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:15 --> URI Class Initialized
INFO - 2023-06-12 08:24:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:15 --> Router Class Initialized
INFO - 2023-06-12 08:24:15 --> Output Class Initialized
INFO - 2023-06-12 08:24:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:15 --> Input Class Initialized
INFO - 2023-06-12 08:24:15 --> Language Class Initialized
INFO - 2023-06-12 08:24:15 --> Loader Class Initialized
INFO - 2023-06-12 08:24:15 --> Controller Class Initialized
INFO - 2023-06-12 08:24:15 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:24:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:15 --> Total execution time: 0.0658
INFO - 2023-06-12 08:24:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:15 --> Total execution time: 0.0896
INFO - 2023-06-12 08:24:17 --> Config Class Initialized
INFO - 2023-06-12 08:24:17 --> Config Class Initialized
INFO - 2023-06-12 08:24:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:24:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:17 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:24:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:17 --> URI Class Initialized
INFO - 2023-06-12 08:24:17 --> URI Class Initialized
INFO - 2023-06-12 08:24:17 --> Router Class Initialized
INFO - 2023-06-12 08:24:17 --> Router Class Initialized
INFO - 2023-06-12 08:24:17 --> Output Class Initialized
INFO - 2023-06-12 08:24:17 --> Output Class Initialized
INFO - 2023-06-12 08:24:17 --> Security Class Initialized
INFO - 2023-06-12 08:24:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:17 --> Input Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:17 --> Input Class Initialized
INFO - 2023-06-12 08:24:17 --> Language Class Initialized
INFO - 2023-06-12 08:24:17 --> Language Class Initialized
INFO - 2023-06-12 08:24:17 --> Loader Class Initialized
INFO - 2023-06-12 08:24:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:17 --> Loader Class Initialized
INFO - 2023-06-12 08:24:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:17 --> Total execution time: 0.0768
INFO - 2023-06-12 08:24:17 --> Config Class Initialized
INFO - 2023-06-12 08:24:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:17 --> Total execution time: 0.1022
INFO - 2023-06-12 08:24:17 --> URI Class Initialized
INFO - 2023-06-12 08:24:17 --> Router Class Initialized
INFO - 2023-06-12 08:24:17 --> Output Class Initialized
INFO - 2023-06-12 08:24:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:17 --> Input Class Initialized
INFO - 2023-06-12 08:24:17 --> Language Class Initialized
INFO - 2023-06-12 08:24:17 --> Loader Class Initialized
INFO - 2023-06-12 08:24:17 --> Config Class Initialized
INFO - 2023-06-12 08:24:17 --> Controller Class Initialized
INFO - 2023-06-12 08:24:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:24:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:24:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:24:17 --> URI Class Initialized
INFO - 2023-06-12 08:24:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:17 --> Router Class Initialized
INFO - 2023-06-12 08:24:17 --> Output Class Initialized
INFO - 2023-06-12 08:24:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:24:17 --> Input Class Initialized
INFO - 2023-06-12 08:24:17 --> Language Class Initialized
INFO - 2023-06-12 08:24:17 --> Loader Class Initialized
INFO - 2023-06-12 08:24:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:24:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:24:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:24:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:17 --> Total execution time: 0.0890
INFO - 2023-06-12 08:24:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:24:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:24:17 --> Total execution time: 0.1112
INFO - 2023-06-12 08:26:16 --> Config Class Initialized
INFO - 2023-06-12 08:26:16 --> Hooks Class Initialized
INFO - 2023-06-12 08:26:16 --> Config Class Initialized
INFO - 2023-06-12 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:16 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:16 --> URI Class Initialized
INFO - 2023-06-12 08:26:16 --> URI Class Initialized
INFO - 2023-06-12 08:26:16 --> Router Class Initialized
INFO - 2023-06-12 08:26:16 --> Router Class Initialized
INFO - 2023-06-12 08:26:16 --> Output Class Initialized
INFO - 2023-06-12 08:26:16 --> Security Class Initialized
INFO - 2023-06-12 08:26:16 --> Output Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:16 --> Input Class Initialized
INFO - 2023-06-12 08:26:16 --> Security Class Initialized
INFO - 2023-06-12 08:26:16 --> Language Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:16 --> Input Class Initialized
INFO - 2023-06-12 08:26:16 --> Language Class Initialized
INFO - 2023-06-12 08:26:16 --> Loader Class Initialized
INFO - 2023-06-12 08:26:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:16 --> Loader Class Initialized
INFO - 2023-06-12 08:26:16 --> Controller Class Initialized
INFO - 2023-06-12 08:26:16 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:16 --> Total execution time: 0.0537
INFO - 2023-06-12 08:26:16 --> Config Class Initialized
INFO - 2023-06-12 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:16 --> URI Class Initialized
INFO - 2023-06-12 08:26:16 --> Router Class Initialized
INFO - 2023-06-12 08:26:16 --> Output Class Initialized
INFO - 2023-06-12 08:26:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:16 --> Input Class Initialized
INFO - 2023-06-12 08:26:16 --> Language Class Initialized
INFO - 2023-06-12 08:26:16 --> Loader Class Initialized
INFO - 2023-06-12 08:26:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:16 --> Total execution time: 0.0883
INFO - 2023-06-12 08:26:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:16 --> Config Class Initialized
INFO - 2023-06-12 08:26:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:16 --> URI Class Initialized
INFO - 2023-06-12 08:26:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:16 --> Router Class Initialized
INFO - 2023-06-12 08:26:16 --> Final output sent to browser
INFO - 2023-06-12 08:26:16 --> Output Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Total execution time: 0.0539
INFO - 2023-06-12 08:26:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:16 --> Input Class Initialized
INFO - 2023-06-12 08:26:16 --> Language Class Initialized
INFO - 2023-06-12 08:26:16 --> Loader Class Initialized
INFO - 2023-06-12 08:26:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:16 --> Total execution time: 0.0707
INFO - 2023-06-12 08:26:22 --> Config Class Initialized
INFO - 2023-06-12 08:26:22 --> Hooks Class Initialized
INFO - 2023-06-12 08:26:22 --> Config Class Initialized
INFO - 2023-06-12 08:26:22 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:22 --> URI Class Initialized
INFO - 2023-06-12 08:26:22 --> Router Class Initialized
DEBUG - 2023-06-12 08:26:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:22 --> Output Class Initialized
INFO - 2023-06-12 08:26:22 --> URI Class Initialized
INFO - 2023-06-12 08:26:22 --> Security Class Initialized
INFO - 2023-06-12 08:26:22 --> Router Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:22 --> Input Class Initialized
INFO - 2023-06-12 08:26:22 --> Output Class Initialized
INFO - 2023-06-12 08:26:22 --> Language Class Initialized
INFO - 2023-06-12 08:26:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:22 --> Input Class Initialized
INFO - 2023-06-12 08:26:22 --> Language Class Initialized
INFO - 2023-06-12 08:26:22 --> Loader Class Initialized
INFO - 2023-06-12 08:26:22 --> Loader Class Initialized
INFO - 2023-06-12 08:26:22 --> Controller Class Initialized
INFO - 2023-06-12 08:26:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:26:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:22 --> Total execution time: 0.0629
INFO - 2023-06-12 08:26:22 --> Config Class Initialized
INFO - 2023-06-12 08:26:22 --> Hooks Class Initialized
INFO - 2023-06-12 08:26:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:22 --> Total execution time: 0.0867
DEBUG - 2023-06-12 08:26:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:22 --> URI Class Initialized
INFO - 2023-06-12 08:26:22 --> Router Class Initialized
INFO - 2023-06-12 08:26:22 --> Output Class Initialized
INFO - 2023-06-12 08:26:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:22 --> Input Class Initialized
INFO - 2023-06-12 08:26:22 --> Language Class Initialized
INFO - 2023-06-12 08:26:22 --> Config Class Initialized
INFO - 2023-06-12 08:26:22 --> Hooks Class Initialized
INFO - 2023-06-12 08:26:22 --> Loader Class Initialized
DEBUG - 2023-06-12 08:26:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:22 --> URI Class Initialized
INFO - 2023-06-12 08:26:22 --> Router Class Initialized
INFO - 2023-06-12 08:26:22 --> Output Class Initialized
INFO - 2023-06-12 08:26:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:22 --> Input Class Initialized
INFO - 2023-06-12 08:26:22 --> Language Class Initialized
INFO - 2023-06-12 08:26:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:22 --> Loader Class Initialized
INFO - 2023-06-12 08:26:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:22 --> Total execution time: 0.0798
INFO - 2023-06-12 08:26:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:22 --> Total execution time: 0.1048
INFO - 2023-06-12 08:26:41 --> Config Class Initialized
INFO - 2023-06-12 08:26:41 --> Hooks Class Initialized
INFO - 2023-06-12 08:26:41 --> Config Class Initialized
INFO - 2023-06-12 08:26:41 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:26:41 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:41 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:41 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:41 --> URI Class Initialized
INFO - 2023-06-12 08:26:41 --> URI Class Initialized
INFO - 2023-06-12 08:26:41 --> Router Class Initialized
INFO - 2023-06-12 08:26:41 --> Router Class Initialized
INFO - 2023-06-12 08:26:41 --> Output Class Initialized
INFO - 2023-06-12 08:26:41 --> Output Class Initialized
INFO - 2023-06-12 08:26:41 --> Security Class Initialized
INFO - 2023-06-12 08:26:41 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:41 --> Input Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:41 --> Language Class Initialized
INFO - 2023-06-12 08:26:41 --> Input Class Initialized
INFO - 2023-06-12 08:26:41 --> Language Class Initialized
INFO - 2023-06-12 08:26:41 --> Loader Class Initialized
INFO - 2023-06-12 08:26:41 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:41 --> Loader Class Initialized
INFO - 2023-06-12 08:26:41 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:41 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:41 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:41 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:41 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:41 --> Total execution time: 0.0649
INFO - 2023-06-12 08:26:41 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:41 --> Config Class Initialized
INFO - 2023-06-12 08:26:41 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:41 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:41 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:41 --> URI Class Initialized
INFO - 2023-06-12 08:26:41 --> Router Class Initialized
INFO - 2023-06-12 08:26:41 --> Final output sent to browser
INFO - 2023-06-12 08:26:41 --> Output Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Total execution time: 0.0896
INFO - 2023-06-12 08:26:41 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:41 --> Input Class Initialized
INFO - 2023-06-12 08:26:41 --> Language Class Initialized
INFO - 2023-06-12 08:26:41 --> Loader Class Initialized
INFO - 2023-06-12 08:26:41 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:41 --> Config Class Initialized
INFO - 2023-06-12 08:26:41 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:26:41 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:26:41 --> Utf8 Class Initialized
INFO - 2023-06-12 08:26:41 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:41 --> URI Class Initialized
INFO - 2023-06-12 08:26:41 --> Router Class Initialized
INFO - 2023-06-12 08:26:41 --> Output Class Initialized
INFO - 2023-06-12 08:26:41 --> Security Class Initialized
DEBUG - 2023-06-12 08:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:26:41 --> Input Class Initialized
INFO - 2023-06-12 08:26:41 --> Language Class Initialized
INFO - 2023-06-12 08:26:42 --> Loader Class Initialized
INFO - 2023-06-12 08:26:42 --> Controller Class Initialized
DEBUG - 2023-06-12 08:26:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:26:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:42 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:42 --> Total execution time: 0.0748
INFO - 2023-06-12 08:26:42 --> Database Driver Class Initialized
INFO - 2023-06-12 08:26:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:26:42 --> Final output sent to browser
DEBUG - 2023-06-12 08:26:42 --> Total execution time: 0.0829
INFO - 2023-06-12 08:27:14 --> Config Class Initialized
INFO - 2023-06-12 08:27:14 --> Config Class Initialized
INFO - 2023-06-12 08:27:14 --> Hooks Class Initialized
INFO - 2023-06-12 08:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:27:14 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:27:14 --> Utf8 Class Initialized
INFO - 2023-06-12 08:27:14 --> URI Class Initialized
INFO - 2023-06-12 08:27:14 --> URI Class Initialized
INFO - 2023-06-12 08:27:14 --> Router Class Initialized
INFO - 2023-06-12 08:27:14 --> Output Class Initialized
INFO - 2023-06-12 08:27:14 --> Router Class Initialized
INFO - 2023-06-12 08:27:14 --> Security Class Initialized
INFO - 2023-06-12 08:27:14 --> Output Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:27:14 --> Input Class Initialized
INFO - 2023-06-12 08:27:14 --> Security Class Initialized
INFO - 2023-06-12 08:27:14 --> Language Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:27:14 --> Input Class Initialized
INFO - 2023-06-12 08:27:14 --> Language Class Initialized
INFO - 2023-06-12 08:27:14 --> Loader Class Initialized
INFO - 2023-06-12 08:27:14 --> Controller Class Initialized
INFO - 2023-06-12 08:27:14 --> Loader Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:27:14 --> Controller Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:27:14 --> Database Driver Class Initialized
INFO - 2023-06-12 08:27:14 --> Database Driver Class Initialized
INFO - 2023-06-12 08:27:14 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:27:14 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:27:14 --> Final output sent to browser
DEBUG - 2023-06-12 08:27:14 --> Total execution time: 0.0830
INFO - 2023-06-12 08:27:14 --> Final output sent to browser
DEBUG - 2023-06-12 08:27:14 --> Total execution time: 0.0905
INFO - 2023-06-12 08:27:14 --> Config Class Initialized
INFO - 2023-06-12 08:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:27:14 --> Utf8 Class Initialized
INFO - 2023-06-12 08:27:14 --> URI Class Initialized
INFO - 2023-06-12 08:27:14 --> Config Class Initialized
INFO - 2023-06-12 08:27:14 --> Hooks Class Initialized
INFO - 2023-06-12 08:27:14 --> Router Class Initialized
INFO - 2023-06-12 08:27:14 --> Output Class Initialized
INFO - 2023-06-12 08:27:14 --> Security Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:27:14 --> Input Class Initialized
INFO - 2023-06-12 08:27:14 --> Utf8 Class Initialized
INFO - 2023-06-12 08:27:14 --> URI Class Initialized
INFO - 2023-06-12 08:27:14 --> Language Class Initialized
INFO - 2023-06-12 08:27:14 --> Router Class Initialized
INFO - 2023-06-12 08:27:14 --> Loader Class Initialized
INFO - 2023-06-12 08:27:14 --> Output Class Initialized
INFO - 2023-06-12 08:27:14 --> Controller Class Initialized
INFO - 2023-06-12 08:27:14 --> Security Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:27:14 --> Input Class Initialized
INFO - 2023-06-12 08:27:14 --> Language Class Initialized
INFO - 2023-06-12 08:27:14 --> Database Driver Class Initialized
INFO - 2023-06-12 08:27:14 --> Loader Class Initialized
INFO - 2023-06-12 08:27:14 --> Controller Class Initialized
DEBUG - 2023-06-12 08:27:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:27:14 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:27:14 --> Database Driver Class Initialized
INFO - 2023-06-12 08:27:14 --> Final output sent to browser
DEBUG - 2023-06-12 08:27:14 --> Total execution time: 0.0634
INFO - 2023-06-12 08:27:14 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:27:14 --> Final output sent to browser
DEBUG - 2023-06-12 08:27:14 --> Total execution time: 0.0846
INFO - 2023-06-12 08:28:27 --> Config Class Initialized
INFO - 2023-06-12 08:28:27 --> Config Class Initialized
INFO - 2023-06-12 08:28:27 --> Hooks Class Initialized
INFO - 2023-06-12 08:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:27 --> URI Class Initialized
DEBUG - 2023-06-12 08:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:27 --> Router Class Initialized
INFO - 2023-06-12 08:28:27 --> URI Class Initialized
INFO - 2023-06-12 08:28:27 --> Output Class Initialized
INFO - 2023-06-12 08:28:27 --> Security Class Initialized
INFO - 2023-06-12 08:28:27 --> Router Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:27 --> Input Class Initialized
INFO - 2023-06-12 08:28:27 --> Output Class Initialized
INFO - 2023-06-12 08:28:27 --> Language Class Initialized
INFO - 2023-06-12 08:28:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:27 --> Loader Class Initialized
INFO - 2023-06-12 08:28:27 --> Input Class Initialized
INFO - 2023-06-12 08:28:27 --> Language Class Initialized
INFO - 2023-06-12 08:28:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:27 --> Loader Class Initialized
INFO - 2023-06-12 08:28:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:27 --> Total execution time: 0.1034
INFO - 2023-06-12 08:28:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:27 --> Config Class Initialized
INFO - 2023-06-12 08:28:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:27 --> URI Class Initialized
INFO - 2023-06-12 08:28:27 --> Router Class Initialized
INFO - 2023-06-12 08:28:27 --> Output Class Initialized
INFO - 2023-06-12 08:28:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:27 --> Total execution time: 0.1392
INFO - 2023-06-12 08:28:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:27 --> Input Class Initialized
INFO - 2023-06-12 08:28:27 --> Language Class Initialized
INFO - 2023-06-12 08:28:27 --> Loader Class Initialized
INFO - 2023-06-12 08:28:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:27 --> Config Class Initialized
INFO - 2023-06-12 08:28:27 --> Hooks Class Initialized
INFO - 2023-06-12 08:28:27 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:28:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:27 --> URI Class Initialized
INFO - 2023-06-12 08:28:27 --> Router Class Initialized
INFO - 2023-06-12 08:28:27 --> Output Class Initialized
INFO - 2023-06-12 08:28:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:27 --> Input Class Initialized
INFO - 2023-06-12 08:28:27 --> Language Class Initialized
INFO - 2023-06-12 08:28:27 --> Loader Class Initialized
INFO - 2023-06-12 08:28:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:27 --> Total execution time: 0.0864
INFO - 2023-06-12 08:28:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:27 --> Total execution time: 0.0963
INFO - 2023-06-12 08:28:59 --> Config Class Initialized
INFO - 2023-06-12 08:28:59 --> Config Class Initialized
INFO - 2023-06-12 08:28:59 --> Hooks Class Initialized
INFO - 2023-06-12 08:28:59 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:28:59 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:59 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:59 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:59 --> URI Class Initialized
INFO - 2023-06-12 08:28:59 --> URI Class Initialized
INFO - 2023-06-12 08:28:59 --> Router Class Initialized
INFO - 2023-06-12 08:28:59 --> Router Class Initialized
INFO - 2023-06-12 08:28:59 --> Output Class Initialized
INFO - 2023-06-12 08:28:59 --> Output Class Initialized
INFO - 2023-06-12 08:28:59 --> Security Class Initialized
INFO - 2023-06-12 08:28:59 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:59 --> Input Class Initialized
INFO - 2023-06-12 08:28:59 --> Input Class Initialized
INFO - 2023-06-12 08:28:59 --> Language Class Initialized
INFO - 2023-06-12 08:28:59 --> Language Class Initialized
INFO - 2023-06-12 08:28:59 --> Loader Class Initialized
INFO - 2023-06-12 08:28:59 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:59 --> Loader Class Initialized
INFO - 2023-06-12 08:28:59 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:59 --> Total execution time: 0.0696
INFO - 2023-06-12 08:28:59 --> Config Class Initialized
INFO - 2023-06-12 08:28:59 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:28:59 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:59 --> Total execution time: 0.0869
INFO - 2023-06-12 08:28:59 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:59 --> URI Class Initialized
INFO - 2023-06-12 08:28:59 --> Router Class Initialized
INFO - 2023-06-12 08:28:59 --> Output Class Initialized
INFO - 2023-06-12 08:28:59 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:59 --> Input Class Initialized
INFO - 2023-06-12 08:28:59 --> Language Class Initialized
INFO - 2023-06-12 08:28:59 --> Config Class Initialized
INFO - 2023-06-12 08:28:59 --> Loader Class Initialized
INFO - 2023-06-12 08:28:59 --> Hooks Class Initialized
INFO - 2023-06-12 08:28:59 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:28:59 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:28:59 --> Utf8 Class Initialized
INFO - 2023-06-12 08:28:59 --> URI Class Initialized
INFO - 2023-06-12 08:28:59 --> Router Class Initialized
INFO - 2023-06-12 08:28:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:59 --> Output Class Initialized
INFO - 2023-06-12 08:28:59 --> Security Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:28:59 --> Input Class Initialized
INFO - 2023-06-12 08:28:59 --> Language Class Initialized
INFO - 2023-06-12 08:28:59 --> Loader Class Initialized
INFO - 2023-06-12 08:28:59 --> Controller Class Initialized
DEBUG - 2023-06-12 08:28:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:28:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:28:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:59 --> Total execution time: 0.0715
INFO - 2023-06-12 08:28:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:28:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:28:59 --> Total execution time: 0.0975
INFO - 2023-06-12 08:29:05 --> Config Class Initialized
INFO - 2023-06-12 08:29:05 --> Config Class Initialized
INFO - 2023-06-12 08:29:05 --> Hooks Class Initialized
INFO - 2023-06-12 08:29:05 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:05 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:05 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:05 --> URI Class Initialized
INFO - 2023-06-12 08:29:05 --> URI Class Initialized
INFO - 2023-06-12 08:29:05 --> Router Class Initialized
INFO - 2023-06-12 08:29:05 --> Router Class Initialized
INFO - 2023-06-12 08:29:05 --> Output Class Initialized
INFO - 2023-06-12 08:29:05 --> Output Class Initialized
INFO - 2023-06-12 08:29:05 --> Security Class Initialized
INFO - 2023-06-12 08:29:05 --> Security Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:05 --> Input Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:05 --> Language Class Initialized
INFO - 2023-06-12 08:29:05 --> Input Class Initialized
INFO - 2023-06-12 08:29:05 --> Language Class Initialized
INFO - 2023-06-12 08:29:05 --> Loader Class Initialized
INFO - 2023-06-12 08:29:05 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:05 --> Loader Class Initialized
INFO - 2023-06-12 08:29:05 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:05 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:05 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:05 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:05 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:05 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:05 --> Total execution time: 0.0774
INFO - 2023-06-12 08:29:05 --> Config Class Initialized
INFO - 2023-06-12 08:29:05 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:05 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:05 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:05 --> Total execution time: 0.1022
INFO - 2023-06-12 08:29:05 --> URI Class Initialized
INFO - 2023-06-12 08:29:05 --> Router Class Initialized
INFO - 2023-06-12 08:29:05 --> Output Class Initialized
INFO - 2023-06-12 08:29:05 --> Security Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:05 --> Input Class Initialized
INFO - 2023-06-12 08:29:05 --> Language Class Initialized
INFO - 2023-06-12 08:29:05 --> Config Class Initialized
INFO - 2023-06-12 08:29:05 --> Hooks Class Initialized
INFO - 2023-06-12 08:29:05 --> Loader Class Initialized
INFO - 2023-06-12 08:29:05 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:05 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:05 --> URI Class Initialized
INFO - 2023-06-12 08:29:05 --> Router Class Initialized
INFO - 2023-06-12 08:29:05 --> Output Class Initialized
INFO - 2023-06-12 08:29:05 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:05 --> Security Class Initialized
DEBUG - 2023-06-12 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:05 --> Input Class Initialized
INFO - 2023-06-12 08:29:05 --> Language Class Initialized
INFO - 2023-06-12 08:29:06 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:06 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:06 --> Total execution time: 0.0714
INFO - 2023-06-12 08:29:06 --> Loader Class Initialized
INFO - 2023-06-12 08:29:06 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:06 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:06 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:06 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:06 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:06 --> Total execution time: 0.1085
INFO - 2023-06-12 08:29:32 --> Config Class Initialized
INFO - 2023-06-12 08:29:32 --> Config Class Initialized
INFO - 2023-06-12 08:29:32 --> Hooks Class Initialized
INFO - 2023-06-12 08:29:32 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:29:32 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:29:32 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:32 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:32 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:32 --> URI Class Initialized
INFO - 2023-06-12 08:29:32 --> URI Class Initialized
INFO - 2023-06-12 08:29:32 --> Router Class Initialized
INFO - 2023-06-12 08:29:32 --> Router Class Initialized
INFO - 2023-06-12 08:29:32 --> Output Class Initialized
INFO - 2023-06-12 08:29:32 --> Output Class Initialized
INFO - 2023-06-12 08:29:32 --> Security Class Initialized
INFO - 2023-06-12 08:29:32 --> Security Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:32 --> Input Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:32 --> Input Class Initialized
INFO - 2023-06-12 08:29:32 --> Language Class Initialized
INFO - 2023-06-12 08:29:32 --> Language Class Initialized
INFO - 2023-06-12 08:29:32 --> Loader Class Initialized
INFO - 2023-06-12 08:29:32 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:32 --> Loader Class Initialized
INFO - 2023-06-12 08:29:32 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:32 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:32 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:32 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:32 --> Final output sent to browser
INFO - 2023-06-12 08:29:32 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:29:32 --> Total execution time: 0.0779
INFO - 2023-06-12 08:29:32 --> Config Class Initialized
INFO - 2023-06-12 08:29:32 --> Hooks Class Initialized
INFO - 2023-06-12 08:29:32 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:32 --> Total execution time: 0.0971
DEBUG - 2023-06-12 08:29:32 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:32 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:32 --> URI Class Initialized
INFO - 2023-06-12 08:29:32 --> Router Class Initialized
INFO - 2023-06-12 08:29:32 --> Output Class Initialized
INFO - 2023-06-12 08:29:32 --> Security Class Initialized
INFO - 2023-06-12 08:29:32 --> Config Class Initialized
INFO - 2023-06-12 08:29:32 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:32 --> Input Class Initialized
INFO - 2023-06-12 08:29:32 --> Language Class Initialized
DEBUG - 2023-06-12 08:29:32 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:29:32 --> Utf8 Class Initialized
INFO - 2023-06-12 08:29:32 --> URI Class Initialized
INFO - 2023-06-12 08:29:32 --> Loader Class Initialized
INFO - 2023-06-12 08:29:32 --> Router Class Initialized
INFO - 2023-06-12 08:29:32 --> Controller Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:29:32 --> Output Class Initialized
INFO - 2023-06-12 08:29:32 --> Security Class Initialized
DEBUG - 2023-06-12 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:29:32 --> Input Class Initialized
INFO - 2023-06-12 08:29:32 --> Language Class Initialized
INFO - 2023-06-12 08:29:32 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:32 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:32 --> Loader Class Initialized
INFO - 2023-06-12 08:29:32 --> Controller Class Initialized
INFO - 2023-06-12 08:29:32 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:32 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:29:32 --> Total execution time: 0.0689
INFO - 2023-06-12 08:29:32 --> Database Driver Class Initialized
INFO - 2023-06-12 08:29:32 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:29:32 --> Final output sent to browser
DEBUG - 2023-06-12 08:29:32 --> Total execution time: 0.0891
INFO - 2023-06-12 08:30:12 --> Config Class Initialized
INFO - 2023-06-12 08:30:12 --> Config Class Initialized
INFO - 2023-06-12 08:30:12 --> Hooks Class Initialized
INFO - 2023-06-12 08:30:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:30:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:30:12 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:30:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:30:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:30:12 --> URI Class Initialized
INFO - 2023-06-12 08:30:12 --> URI Class Initialized
INFO - 2023-06-12 08:30:12 --> Router Class Initialized
INFO - 2023-06-12 08:30:12 --> Router Class Initialized
INFO - 2023-06-12 08:30:12 --> Output Class Initialized
INFO - 2023-06-12 08:30:12 --> Output Class Initialized
INFO - 2023-06-12 08:30:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:30:12 --> Security Class Initialized
INFO - 2023-06-12 08:30:12 --> Input Class Initialized
INFO - 2023-06-12 08:30:12 --> Language Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:30:12 --> Input Class Initialized
INFO - 2023-06-12 08:30:12 --> Language Class Initialized
INFO - 2023-06-12 08:30:12 --> Loader Class Initialized
INFO - 2023-06-12 08:30:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:30:12 --> Loader Class Initialized
INFO - 2023-06-12 08:30:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:30:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:30:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:30:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:30:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:30:12 --> Total execution time: 0.0659
INFO - 2023-06-12 08:30:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:30:12 --> Config Class Initialized
INFO - 2023-06-12 08:30:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:30:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:30:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:30:12 --> URI Class Initialized
INFO - 2023-06-12 08:30:12 --> Router Class Initialized
INFO - 2023-06-12 08:30:12 --> Output Class Initialized
INFO - 2023-06-12 08:30:12 --> Security Class Initialized
INFO - 2023-06-12 08:30:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:30:12 --> Total execution time: 0.0932
DEBUG - 2023-06-12 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:30:12 --> Input Class Initialized
INFO - 2023-06-12 08:30:12 --> Language Class Initialized
INFO - 2023-06-12 08:30:12 --> Loader Class Initialized
INFO - 2023-06-12 08:30:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:30:12 --> Config Class Initialized
INFO - 2023-06-12 08:30:12 --> Hooks Class Initialized
INFO - 2023-06-12 08:30:12 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:30:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:30:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:30:12 --> URI Class Initialized
INFO - 2023-06-12 08:30:12 --> Router Class Initialized
INFO - 2023-06-12 08:30:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:30:12 --> Output Class Initialized
INFO - 2023-06-12 08:30:12 --> Security Class Initialized
INFO - 2023-06-12 08:30:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:30:12 --> Total execution time: 0.0525
DEBUG - 2023-06-12 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:30:12 --> Input Class Initialized
INFO - 2023-06-12 08:30:12 --> Language Class Initialized
INFO - 2023-06-12 08:30:12 --> Loader Class Initialized
INFO - 2023-06-12 08:30:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:30:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:30:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:30:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:30:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:30:12 --> Total execution time: 0.0824
INFO - 2023-06-12 08:32:57 --> Config Class Initialized
INFO - 2023-06-12 08:32:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:32:57 --> Config Class Initialized
INFO - 2023-06-12 08:32:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:32:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:32:57 --> URI Class Initialized
DEBUG - 2023-06-12 08:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:32:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:32:57 --> URI Class Initialized
INFO - 2023-06-12 08:32:57 --> Router Class Initialized
INFO - 2023-06-12 08:32:57 --> Output Class Initialized
INFO - 2023-06-12 08:32:57 --> Router Class Initialized
INFO - 2023-06-12 08:32:57 --> Security Class Initialized
INFO - 2023-06-12 08:32:57 --> Output Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:32:57 --> Input Class Initialized
INFO - 2023-06-12 08:32:57 --> Security Class Initialized
INFO - 2023-06-12 08:32:57 --> Language Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:32:57 --> Input Class Initialized
INFO - 2023-06-12 08:32:57 --> Language Class Initialized
INFO - 2023-06-12 08:32:57 --> Loader Class Initialized
INFO - 2023-06-12 08:32:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:32:57 --> Loader Class Initialized
INFO - 2023-06-12 08:32:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:32:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:32:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:32:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:32:57 --> Total execution time: 0.0759
INFO - 2023-06-12 08:32:57 --> Config Class Initialized
INFO - 2023-06-12 08:32:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:32:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:32:57 --> Total execution time: 0.0883
DEBUG - 2023-06-12 08:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:32:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:32:57 --> URI Class Initialized
INFO - 2023-06-12 08:32:57 --> Router Class Initialized
INFO - 2023-06-12 08:32:57 --> Output Class Initialized
INFO - 2023-06-12 08:32:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:32:57 --> Input Class Initialized
INFO - 2023-06-12 08:32:57 --> Config Class Initialized
INFO - 2023-06-12 08:32:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:32:57 --> Language Class Initialized
INFO - 2023-06-12 08:32:57 --> Loader Class Initialized
DEBUG - 2023-06-12 08:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:32:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:32:57 --> Controller Class Initialized
INFO - 2023-06-12 08:32:57 --> URI Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:32:57 --> Router Class Initialized
INFO - 2023-06-12 08:32:57 --> Output Class Initialized
INFO - 2023-06-12 08:32:57 --> Security Class Initialized
INFO - 2023-06-12 08:32:57 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:32:57 --> Input Class Initialized
INFO - 2023-06-12 08:32:57 --> Language Class Initialized
INFO - 2023-06-12 08:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:32:57 --> Loader Class Initialized
INFO - 2023-06-12 08:32:57 --> Controller Class Initialized
INFO - 2023-06-12 08:32:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:32:57 --> Total execution time: 0.0507
DEBUG - 2023-06-12 08:32:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:32:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:32:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:32:57 --> Total execution time: 0.1048
INFO - 2023-06-12 08:33:03 --> Config Class Initialized
INFO - 2023-06-12 08:33:03 --> Hooks Class Initialized
INFO - 2023-06-12 08:33:03 --> Config Class Initialized
INFO - 2023-06-12 08:33:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:33:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:33:03 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:33:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:33:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:33:03 --> URI Class Initialized
INFO - 2023-06-12 08:33:03 --> URI Class Initialized
INFO - 2023-06-12 08:33:03 --> Router Class Initialized
INFO - 2023-06-12 08:33:03 --> Router Class Initialized
INFO - 2023-06-12 08:33:03 --> Output Class Initialized
INFO - 2023-06-12 08:33:03 --> Output Class Initialized
INFO - 2023-06-12 08:33:03 --> Security Class Initialized
INFO - 2023-06-12 08:33:03 --> Security Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:33:03 --> Input Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:33:03 --> Input Class Initialized
INFO - 2023-06-12 08:33:03 --> Language Class Initialized
INFO - 2023-06-12 08:33:03 --> Language Class Initialized
INFO - 2023-06-12 08:33:03 --> Loader Class Initialized
INFO - 2023-06-12 08:33:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:33:03 --> Loader Class Initialized
INFO - 2023-06-12 08:33:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:33:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:33:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:33:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:33:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:33:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:33:03 --> Total execution time: 0.0712
INFO - 2023-06-12 08:33:03 --> Config Class Initialized
INFO - 2023-06-12 08:33:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:33:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:33:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:33:03 --> URI Class Initialized
INFO - 2023-06-12 08:33:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:33:03 --> Total execution time: 0.0991
INFO - 2023-06-12 08:33:03 --> Router Class Initialized
INFO - 2023-06-12 08:33:03 --> Output Class Initialized
INFO - 2023-06-12 08:33:03 --> Security Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:33:03 --> Input Class Initialized
INFO - 2023-06-12 08:33:03 --> Language Class Initialized
INFO - 2023-06-12 08:33:03 --> Loader Class Initialized
INFO - 2023-06-12 08:33:03 --> Config Class Initialized
INFO - 2023-06-12 08:33:03 --> Hooks Class Initialized
INFO - 2023-06-12 08:33:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:33:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:33:03 --> Utf8 Class Initialized
INFO - 2023-06-12 08:33:03 --> URI Class Initialized
INFO - 2023-06-12 08:33:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:33:03 --> Router Class Initialized
INFO - 2023-06-12 08:33:03 --> Output Class Initialized
INFO - 2023-06-12 08:33:03 --> Security Class Initialized
INFO - 2023-06-12 08:33:03 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:33:03 --> Input Class Initialized
INFO - 2023-06-12 08:33:03 --> Language Class Initialized
INFO - 2023-06-12 08:33:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:33:03 --> Total execution time: 0.0674
INFO - 2023-06-12 08:33:03 --> Loader Class Initialized
INFO - 2023-06-12 08:33:03 --> Controller Class Initialized
DEBUG - 2023-06-12 08:33:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:33:03 --> Database Driver Class Initialized
INFO - 2023-06-12 08:33:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:33:03 --> Final output sent to browser
DEBUG - 2023-06-12 08:33:03 --> Total execution time: 0.1021
INFO - 2023-06-12 08:34:33 --> Config Class Initialized
INFO - 2023-06-12 08:34:33 --> Hooks Class Initialized
INFO - 2023-06-12 08:34:33 --> Config Class Initialized
INFO - 2023-06-12 08:34:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:34:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:33 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:34:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:33 --> URI Class Initialized
INFO - 2023-06-12 08:34:33 --> URI Class Initialized
INFO - 2023-06-12 08:34:33 --> Router Class Initialized
INFO - 2023-06-12 08:34:33 --> Router Class Initialized
INFO - 2023-06-12 08:34:33 --> Output Class Initialized
INFO - 2023-06-12 08:34:33 --> Output Class Initialized
INFO - 2023-06-12 08:34:33 --> Security Class Initialized
INFO - 2023-06-12 08:34:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:33 --> Input Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:33 --> Input Class Initialized
INFO - 2023-06-12 08:34:33 --> Language Class Initialized
INFO - 2023-06-12 08:34:33 --> Language Class Initialized
INFO - 2023-06-12 08:34:33 --> Loader Class Initialized
INFO - 2023-06-12 08:34:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:33 --> Loader Class Initialized
INFO - 2023-06-12 08:34:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:33 --> Total execution time: 0.0485
INFO - 2023-06-12 08:34:33 --> Config Class Initialized
INFO - 2023-06-12 08:34:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:34:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:33 --> URI Class Initialized
INFO - 2023-06-12 08:34:33 --> Router Class Initialized
INFO - 2023-06-12 08:34:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:33 --> Output Class Initialized
INFO - 2023-06-12 08:34:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:33 --> Input Class Initialized
INFO - 2023-06-12 08:34:33 --> Language Class Initialized
INFO - 2023-06-12 08:34:33 --> Loader Class Initialized
INFO - 2023-06-12 08:34:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:33 --> Total execution time: 0.0929
INFO - 2023-06-12 08:34:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:33 --> Config Class Initialized
INFO - 2023-06-12 08:34:33 --> Hooks Class Initialized
INFO - 2023-06-12 08:34:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:33 --> Total execution time: 0.0488
DEBUG - 2023-06-12 08:34:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:33 --> URI Class Initialized
INFO - 2023-06-12 08:34:33 --> Router Class Initialized
INFO - 2023-06-12 08:34:33 --> Output Class Initialized
INFO - 2023-06-12 08:34:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:33 --> Input Class Initialized
INFO - 2023-06-12 08:34:33 --> Language Class Initialized
INFO - 2023-06-12 08:34:33 --> Loader Class Initialized
INFO - 2023-06-12 08:34:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:33 --> Total execution time: 0.0709
INFO - 2023-06-12 08:34:42 --> Config Class Initialized
INFO - 2023-06-12 08:34:42 --> Hooks Class Initialized
INFO - 2023-06-12 08:34:42 --> Config Class Initialized
INFO - 2023-06-12 08:34:42 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:34:42 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:42 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:42 --> URI Class Initialized
DEBUG - 2023-06-12 08:34:42 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:42 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:42 --> Router Class Initialized
INFO - 2023-06-12 08:34:42 --> URI Class Initialized
INFO - 2023-06-12 08:34:42 --> Output Class Initialized
INFO - 2023-06-12 08:34:42 --> Router Class Initialized
INFO - 2023-06-12 08:34:42 --> Security Class Initialized
INFO - 2023-06-12 08:34:42 --> Output Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:42 --> Input Class Initialized
INFO - 2023-06-12 08:34:42 --> Language Class Initialized
INFO - 2023-06-12 08:34:42 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:42 --> Input Class Initialized
INFO - 2023-06-12 08:34:42 --> Language Class Initialized
INFO - 2023-06-12 08:34:42 --> Loader Class Initialized
INFO - 2023-06-12 08:34:42 --> Loader Class Initialized
INFO - 2023-06-12 08:34:42 --> Controller Class Initialized
INFO - 2023-06-12 08:34:42 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:34:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:42 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:42 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:42 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:42 --> Total execution time: 0.0688
INFO - 2023-06-12 08:34:42 --> Config Class Initialized
INFO - 2023-06-12 08:34:42 --> Hooks Class Initialized
INFO - 2023-06-12 08:34:42 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:42 --> Total execution time: 0.0878
DEBUG - 2023-06-12 08:34:42 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:42 --> Utf8 Class Initialized
INFO - 2023-06-12 08:34:42 --> URI Class Initialized
INFO - 2023-06-12 08:34:42 --> Router Class Initialized
INFO - 2023-06-12 08:34:42 --> Output Class Initialized
INFO - 2023-06-12 08:34:42 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:42 --> Input Class Initialized
INFO - 2023-06-12 08:34:42 --> Language Class Initialized
INFO - 2023-06-12 08:34:42 --> Config Class Initialized
INFO - 2023-06-12 08:34:42 --> Hooks Class Initialized
INFO - 2023-06-12 08:34:42 --> Loader Class Initialized
INFO - 2023-06-12 08:34:42 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:42 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:34:42 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:42 --> URI Class Initialized
INFO - 2023-06-12 08:34:42 --> Router Class Initialized
INFO - 2023-06-12 08:34:42 --> Output Class Initialized
INFO - 2023-06-12 08:34:42 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:42 --> Security Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:34:42 --> Input Class Initialized
INFO - 2023-06-12 08:34:42 --> Language Class Initialized
INFO - 2023-06-12 08:34:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:42 --> Final output sent to browser
INFO - 2023-06-12 08:34:42 --> Loader Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Total execution time: 0.0487
INFO - 2023-06-12 08:34:42 --> Controller Class Initialized
DEBUG - 2023-06-12 08:34:42 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:34:42 --> Database Driver Class Initialized
INFO - 2023-06-12 08:34:42 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:34:42 --> Final output sent to browser
DEBUG - 2023-06-12 08:34:42 --> Total execution time: 0.0814
INFO - 2023-06-12 08:35:12 --> Config Class Initialized
INFO - 2023-06-12 08:35:12 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:12 --> Config Class Initialized
INFO - 2023-06-12 08:35:12 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:12 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:12 --> URI Class Initialized
INFO - 2023-06-12 08:35:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:12 --> URI Class Initialized
INFO - 2023-06-12 08:35:12 --> Router Class Initialized
INFO - 2023-06-12 08:35:12 --> Output Class Initialized
INFO - 2023-06-12 08:35:12 --> Router Class Initialized
INFO - 2023-06-12 08:35:12 --> Security Class Initialized
INFO - 2023-06-12 08:35:12 --> Output Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:12 --> Input Class Initialized
INFO - 2023-06-12 08:35:12 --> Security Class Initialized
INFO - 2023-06-12 08:35:12 --> Language Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:12 --> Input Class Initialized
INFO - 2023-06-12 08:35:12 --> Language Class Initialized
INFO - 2023-06-12 08:35:12 --> Loader Class Initialized
INFO - 2023-06-12 08:35:12 --> Loader Class Initialized
INFO - 2023-06-12 08:35:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:12 --> Total execution time: 0.0541
INFO - 2023-06-12 08:35:12 --> Config Class Initialized
INFO - 2023-06-12 08:35:12 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:12 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:12 --> URI Class Initialized
INFO - 2023-06-12 08:35:12 --> Router Class Initialized
INFO - 2023-06-12 08:35:12 --> Output Class Initialized
INFO - 2023-06-12 08:35:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:12 --> Input Class Initialized
INFO - 2023-06-12 08:35:12 --> Language Class Initialized
INFO - 2023-06-12 08:35:12 --> Loader Class Initialized
INFO - 2023-06-12 08:35:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:12 --> Total execution time: 0.0902
INFO - 2023-06-12 08:35:12 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:12 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:12 --> Config Class Initialized
INFO - 2023-06-12 08:35:12 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:12 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:12 --> Total execution time: 0.0469
DEBUG - 2023-06-12 08:35:12 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:12 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:12 --> URI Class Initialized
INFO - 2023-06-12 08:35:12 --> Router Class Initialized
INFO - 2023-06-12 08:35:12 --> Output Class Initialized
INFO - 2023-06-12 08:35:12 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:12 --> Input Class Initialized
INFO - 2023-06-12 08:35:12 --> Language Class Initialized
INFO - 2023-06-12 08:35:12 --> Loader Class Initialized
INFO - 2023-06-12 08:35:12 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:13 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:13 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:13 --> Total execution time: 0.0722
INFO - 2023-06-12 08:35:15 --> Config Class Initialized
INFO - 2023-06-12 08:35:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:15 --> Config Class Initialized
INFO - 2023-06-12 08:35:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:15 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:35:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:15 --> URI Class Initialized
INFO - 2023-06-12 08:35:15 --> URI Class Initialized
INFO - 2023-06-12 08:35:15 --> Router Class Initialized
INFO - 2023-06-12 08:35:15 --> Router Class Initialized
INFO - 2023-06-12 08:35:15 --> Output Class Initialized
INFO - 2023-06-12 08:35:15 --> Output Class Initialized
INFO - 2023-06-12 08:35:15 --> Security Class Initialized
INFO - 2023-06-12 08:35:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:15 --> Input Class Initialized
INFO - 2023-06-12 08:35:15 --> Language Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:15 --> Input Class Initialized
INFO - 2023-06-12 08:35:15 --> Language Class Initialized
INFO - 2023-06-12 08:35:15 --> Loader Class Initialized
INFO - 2023-06-12 08:35:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:15 --> Loader Class Initialized
INFO - 2023-06-12 08:35:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:15 --> Total execution time: 0.0632
INFO - 2023-06-12 08:35:15 --> Config Class Initialized
INFO - 2023-06-12 08:35:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:15 --> URI Class Initialized
INFO - 2023-06-12 08:35:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:15 --> Total execution time: 0.0836
INFO - 2023-06-12 08:35:15 --> Router Class Initialized
INFO - 2023-06-12 08:35:15 --> Output Class Initialized
INFO - 2023-06-12 08:35:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:15 --> Input Class Initialized
INFO - 2023-06-12 08:35:15 --> Language Class Initialized
INFO - 2023-06-12 08:35:15 --> Loader Class Initialized
INFO - 2023-06-12 08:35:15 --> Config Class Initialized
INFO - 2023-06-12 08:35:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:35:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:15 --> URI Class Initialized
INFO - 2023-06-12 08:35:15 --> Router Class Initialized
INFO - 2023-06-12 08:35:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:15 --> Output Class Initialized
INFO - 2023-06-12 08:35:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:15 --> Input Class Initialized
INFO - 2023-06-12 08:35:15 --> Language Class Initialized
INFO - 2023-06-12 08:35:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:15 --> Total execution time: 0.0536
INFO - 2023-06-12 08:35:15 --> Loader Class Initialized
INFO - 2023-06-12 08:35:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:15 --> Total execution time: 0.0800
INFO - 2023-06-12 08:35:39 --> Config Class Initialized
INFO - 2023-06-12 08:35:39 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:39 --> Config Class Initialized
INFO - 2023-06-12 08:35:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:39 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:35:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:39 --> URI Class Initialized
INFO - 2023-06-12 08:35:39 --> URI Class Initialized
INFO - 2023-06-12 08:35:39 --> Router Class Initialized
INFO - 2023-06-12 08:35:39 --> Router Class Initialized
INFO - 2023-06-12 08:35:39 --> Output Class Initialized
INFO - 2023-06-12 08:35:39 --> Output Class Initialized
INFO - 2023-06-12 08:35:39 --> Security Class Initialized
INFO - 2023-06-12 08:35:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:39 --> Input Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:39 --> Input Class Initialized
INFO - 2023-06-12 08:35:39 --> Language Class Initialized
INFO - 2023-06-12 08:35:39 --> Language Class Initialized
INFO - 2023-06-12 08:35:39 --> Loader Class Initialized
INFO - 2023-06-12 08:35:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:39 --> Loader Class Initialized
INFO - 2023-06-12 08:35:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:39 --> Total execution time: 0.0594
INFO - 2023-06-12 08:35:39 --> Config Class Initialized
INFO - 2023-06-12 08:35:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:39 --> Total execution time: 0.0811
INFO - 2023-06-12 08:35:39 --> URI Class Initialized
INFO - 2023-06-12 08:35:39 --> Router Class Initialized
INFO - 2023-06-12 08:35:39 --> Output Class Initialized
INFO - 2023-06-12 08:35:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:39 --> Input Class Initialized
INFO - 2023-06-12 08:35:39 --> Language Class Initialized
INFO - 2023-06-12 08:35:39 --> Config Class Initialized
INFO - 2023-06-12 08:35:39 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:39 --> Loader Class Initialized
INFO - 2023-06-12 08:35:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:35:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:39 --> URI Class Initialized
INFO - 2023-06-12 08:35:39 --> Router Class Initialized
INFO - 2023-06-12 08:35:39 --> Output Class Initialized
INFO - 2023-06-12 08:35:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:39 --> Input Class Initialized
INFO - 2023-06-12 08:35:39 --> Language Class Initialized
INFO - 2023-06-12 08:35:39 --> Loader Class Initialized
INFO - 2023-06-12 08:35:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:39 --> Total execution time: 0.0863
INFO - 2023-06-12 08:35:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:39 --> Total execution time: 0.1112
INFO - 2023-06-12 08:35:47 --> Config Class Initialized
INFO - 2023-06-12 08:35:47 --> Config Class Initialized
INFO - 2023-06-12 08:35:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:35:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:47 --> URI Class Initialized
INFO - 2023-06-12 08:35:47 --> URI Class Initialized
INFO - 2023-06-12 08:35:47 --> Router Class Initialized
INFO - 2023-06-12 08:35:47 --> Router Class Initialized
INFO - 2023-06-12 08:35:47 --> Output Class Initialized
INFO - 2023-06-12 08:35:47 --> Output Class Initialized
INFO - 2023-06-12 08:35:47 --> Security Class Initialized
INFO - 2023-06-12 08:35:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:47 --> Input Class Initialized
INFO - 2023-06-12 08:35:47 --> Input Class Initialized
INFO - 2023-06-12 08:35:47 --> Language Class Initialized
INFO - 2023-06-12 08:35:47 --> Language Class Initialized
INFO - 2023-06-12 08:35:47 --> Loader Class Initialized
INFO - 2023-06-12 08:35:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:47 --> Loader Class Initialized
INFO - 2023-06-12 08:35:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:47 --> Total execution time: 0.0825
INFO - 2023-06-12 08:35:47 --> Config Class Initialized
INFO - 2023-06-12 08:35:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:47 --> Total execution time: 0.1037
DEBUG - 2023-06-12 08:35:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:47 --> URI Class Initialized
INFO - 2023-06-12 08:35:47 --> Router Class Initialized
INFO - 2023-06-12 08:35:47 --> Output Class Initialized
INFO - 2023-06-12 08:35:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:47 --> Input Class Initialized
INFO - 2023-06-12 08:35:47 --> Language Class Initialized
INFO - 2023-06-12 08:35:47 --> Config Class Initialized
INFO - 2023-06-12 08:35:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:47 --> Loader Class Initialized
INFO - 2023-06-12 08:35:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:47 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:47 --> URI Class Initialized
INFO - 2023-06-12 08:35:47 --> Router Class Initialized
INFO - 2023-06-12 08:35:47 --> Output Class Initialized
INFO - 2023-06-12 08:35:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:47 --> Input Class Initialized
INFO - 2023-06-12 08:35:47 --> Language Class Initialized
INFO - 2023-06-12 08:35:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:47 --> Loader Class Initialized
INFO - 2023-06-12 08:35:47 --> Final output sent to browser
INFO - 2023-06-12 08:35:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:47 --> Total execution time: 0.0624
DEBUG - 2023-06-12 08:35:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:47 --> Total execution time: 0.0996
INFO - 2023-06-12 08:35:55 --> Config Class Initialized
INFO - 2023-06-12 08:35:55 --> Hooks Class Initialized
INFO - 2023-06-12 08:35:55 --> Config Class Initialized
INFO - 2023-06-12 08:35:55 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:55 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:55 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:35:55 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:55 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:56 --> URI Class Initialized
INFO - 2023-06-12 08:35:56 --> URI Class Initialized
INFO - 2023-06-12 08:35:56 --> Router Class Initialized
INFO - 2023-06-12 08:35:56 --> Router Class Initialized
INFO - 2023-06-12 08:35:56 --> Output Class Initialized
INFO - 2023-06-12 08:35:56 --> Output Class Initialized
INFO - 2023-06-12 08:35:56 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:56 --> Security Class Initialized
INFO - 2023-06-12 08:35:56 --> Input Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:56 --> Language Class Initialized
INFO - 2023-06-12 08:35:56 --> Input Class Initialized
INFO - 2023-06-12 08:35:56 --> Language Class Initialized
INFO - 2023-06-12 08:35:56 --> Loader Class Initialized
INFO - 2023-06-12 08:35:56 --> Controller Class Initialized
INFO - 2023-06-12 08:35:56 --> Loader Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:56 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:56 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:56 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:56 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:56 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:56 --> Total execution time: 0.0783
INFO - 2023-06-12 08:35:56 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:56 --> Config Class Initialized
INFO - 2023-06-12 08:35:56 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:56 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:56 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:56 --> URI Class Initialized
INFO - 2023-06-12 08:35:56 --> Router Class Initialized
INFO - 2023-06-12 08:35:56 --> Output Class Initialized
INFO - 2023-06-12 08:35:56 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:56 --> Input Class Initialized
INFO - 2023-06-12 08:35:56 --> Language Class Initialized
INFO - 2023-06-12 08:35:56 --> Loader Class Initialized
INFO - 2023-06-12 08:35:56 --> Controller Class Initialized
INFO - 2023-06-12 08:35:56 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:35:56 --> Total execution time: 0.1220
INFO - 2023-06-12 08:35:56 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:56 --> Config Class Initialized
INFO - 2023-06-12 08:35:56 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:35:56 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:35:56 --> Utf8 Class Initialized
INFO - 2023-06-12 08:35:56 --> URI Class Initialized
INFO - 2023-06-12 08:35:56 --> Router Class Initialized
INFO - 2023-06-12 08:35:56 --> Output Class Initialized
INFO - 2023-06-12 08:35:56 --> Security Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:35:56 --> Input Class Initialized
INFO - 2023-06-12 08:35:56 --> Language Class Initialized
INFO - 2023-06-12 08:35:56 --> Loader Class Initialized
INFO - 2023-06-12 08:35:56 --> Controller Class Initialized
DEBUG - 2023-06-12 08:35:56 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:35:56 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:56 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:56 --> Total execution time: 0.0852
INFO - 2023-06-12 08:35:56 --> Database Driver Class Initialized
INFO - 2023-06-12 08:35:56 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:35:56 --> Final output sent to browser
DEBUG - 2023-06-12 08:35:56 --> Total execution time: 0.0819
INFO - 2023-06-12 08:39:16 --> Config Class Initialized
INFO - 2023-06-12 08:39:16 --> Hooks Class Initialized
INFO - 2023-06-12 08:39:16 --> Config Class Initialized
INFO - 2023-06-12 08:39:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:16 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:16 --> URI Class Initialized
INFO - 2023-06-12 08:39:16 --> URI Class Initialized
INFO - 2023-06-12 08:39:16 --> Router Class Initialized
INFO - 2023-06-12 08:39:16 --> Router Class Initialized
INFO - 2023-06-12 08:39:16 --> Output Class Initialized
INFO - 2023-06-12 08:39:16 --> Output Class Initialized
INFO - 2023-06-12 08:39:16 --> Security Class Initialized
INFO - 2023-06-12 08:39:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:16 --> Input Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:16 --> Language Class Initialized
INFO - 2023-06-12 08:39:16 --> Input Class Initialized
INFO - 2023-06-12 08:39:16 --> Language Class Initialized
INFO - 2023-06-12 08:39:16 --> Loader Class Initialized
INFO - 2023-06-12 08:39:16 --> Controller Class Initialized
INFO - 2023-06-12 08:39:16 --> Loader Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:16 --> Total execution time: 0.1038
INFO - 2023-06-12 08:39:16 --> Config Class Initialized
INFO - 2023-06-12 08:39:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:16 --> URI Class Initialized
INFO - 2023-06-12 08:39:16 --> Router Class Initialized
INFO - 2023-06-12 08:39:16 --> Output Class Initialized
INFO - 2023-06-12 08:39:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:16 --> Input Class Initialized
INFO - 2023-06-12 08:39:16 --> Language Class Initialized
INFO - 2023-06-12 08:39:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:16 --> Total execution time: 0.1416
INFO - 2023-06-12 08:39:16 --> Loader Class Initialized
INFO - 2023-06-12 08:39:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:16 --> Config Class Initialized
INFO - 2023-06-12 08:39:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:16 --> URI Class Initialized
INFO - 2023-06-12 08:39:16 --> Router Class Initialized
INFO - 2023-06-12 08:39:16 --> Output Class Initialized
INFO - 2023-06-12 08:39:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:16 --> Input Class Initialized
INFO - 2023-06-12 08:39:16 --> Language Class Initialized
INFO - 2023-06-12 08:39:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:16 --> Loader Class Initialized
INFO - 2023-06-12 08:39:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:16 --> Total execution time: 0.0786
INFO - 2023-06-12 08:39:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:16 --> Total execution time: 0.1198
INFO - 2023-06-12 08:39:23 --> Config Class Initialized
INFO - 2023-06-12 08:39:23 --> Config Class Initialized
INFO - 2023-06-12 08:39:23 --> Hooks Class Initialized
INFO - 2023-06-12 08:39:23 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:39:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:23 --> URI Class Initialized
INFO - 2023-06-12 08:39:23 --> URI Class Initialized
INFO - 2023-06-12 08:39:23 --> Router Class Initialized
INFO - 2023-06-12 08:39:23 --> Router Class Initialized
INFO - 2023-06-12 08:39:23 --> Output Class Initialized
INFO - 2023-06-12 08:39:23 --> Output Class Initialized
INFO - 2023-06-12 08:39:23 --> Security Class Initialized
INFO - 2023-06-12 08:39:23 --> Security Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:23 --> Input Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:23 --> Input Class Initialized
INFO - 2023-06-12 08:39:23 --> Language Class Initialized
INFO - 2023-06-12 08:39:23 --> Language Class Initialized
INFO - 2023-06-12 08:39:23 --> Loader Class Initialized
INFO - 2023-06-12 08:39:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:23 --> Loader Class Initialized
INFO - 2023-06-12 08:39:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:23 --> Total execution time: 0.0865
INFO - 2023-06-12 08:39:23 --> Config Class Initialized
INFO - 2023-06-12 08:39:23 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:23 --> URI Class Initialized
INFO - 2023-06-12 08:39:23 --> Router Class Initialized
INFO - 2023-06-12 08:39:23 --> Output Class Initialized
INFO - 2023-06-12 08:39:23 --> Security Class Initialized
INFO - 2023-06-12 08:39:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:23 --> Total execution time: 0.1182
DEBUG - 2023-06-12 08:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:23 --> Input Class Initialized
INFO - 2023-06-12 08:39:23 --> Language Class Initialized
INFO - 2023-06-12 08:39:23 --> Loader Class Initialized
INFO - 2023-06-12 08:39:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:23 --> Config Class Initialized
INFO - 2023-06-12 08:39:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:23 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:39:23 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:39:23 --> Utf8 Class Initialized
INFO - 2023-06-12 08:39:23 --> URI Class Initialized
INFO - 2023-06-12 08:39:23 --> Router Class Initialized
INFO - 2023-06-12 08:39:23 --> Output Class Initialized
INFO - 2023-06-12 08:39:23 --> Security Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:39:23 --> Input Class Initialized
INFO - 2023-06-12 08:39:23 --> Language Class Initialized
INFO - 2023-06-12 08:39:23 --> Loader Class Initialized
INFO - 2023-06-12 08:39:23 --> Controller Class Initialized
DEBUG - 2023-06-12 08:39:23 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:39:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:23 --> Total execution time: 0.0816
INFO - 2023-06-12 08:39:23 --> Database Driver Class Initialized
INFO - 2023-06-12 08:39:23 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:39:23 --> Final output sent to browser
DEBUG - 2023-06-12 08:39:23 --> Total execution time: 0.1200
INFO - 2023-06-12 08:43:24 --> Config Class Initialized
INFO - 2023-06-12 08:43:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:43:24 --> Config Class Initialized
INFO - 2023-06-12 08:43:24 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:43:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:43:24 --> URI Class Initialized
DEBUG - 2023-06-12 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:43:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:43:24 --> Router Class Initialized
INFO - 2023-06-12 08:43:24 --> URI Class Initialized
INFO - 2023-06-12 08:43:24 --> Output Class Initialized
INFO - 2023-06-12 08:43:24 --> Router Class Initialized
INFO - 2023-06-12 08:43:24 --> Security Class Initialized
INFO - 2023-06-12 08:43:24 --> Output Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:43:24 --> Input Class Initialized
INFO - 2023-06-12 08:43:24 --> Security Class Initialized
INFO - 2023-06-12 08:43:24 --> Language Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:43:24 --> Input Class Initialized
INFO - 2023-06-12 08:43:24 --> Language Class Initialized
INFO - 2023-06-12 08:43:24 --> Loader Class Initialized
INFO - 2023-06-12 08:43:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:43:24 --> Loader Class Initialized
INFO - 2023-06-12 08:43:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:43:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:43:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:43:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:43:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:43:24 --> Total execution time: 0.0711
INFO - 2023-06-12 08:43:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:43:24 --> Config Class Initialized
INFO - 2023-06-12 08:43:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:43:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:43:24 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Total execution time: 0.0950
INFO - 2023-06-12 08:43:24 --> URI Class Initialized
INFO - 2023-06-12 08:43:24 --> Router Class Initialized
INFO - 2023-06-12 08:43:24 --> Output Class Initialized
INFO - 2023-06-12 08:43:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:43:24 --> Input Class Initialized
INFO - 2023-06-12 08:43:24 --> Language Class Initialized
INFO - 2023-06-12 08:43:24 --> Config Class Initialized
INFO - 2023-06-12 08:43:24 --> Hooks Class Initialized
INFO - 2023-06-12 08:43:24 --> Loader Class Initialized
INFO - 2023-06-12 08:43:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:43:24 --> Utf8 Class Initialized
INFO - 2023-06-12 08:43:24 --> URI Class Initialized
INFO - 2023-06-12 08:43:24 --> Router Class Initialized
INFO - 2023-06-12 08:43:24 --> Output Class Initialized
INFO - 2023-06-12 08:43:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:43:24 --> Security Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:43:24 --> Input Class Initialized
INFO - 2023-06-12 08:43:24 --> Language Class Initialized
INFO - 2023-06-12 08:43:24 --> Loader Class Initialized
INFO - 2023-06-12 08:43:24 --> Controller Class Initialized
DEBUG - 2023-06-12 08:43:24 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:43:24 --> Database Driver Class Initialized
INFO - 2023-06-12 08:43:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:43:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:43:24 --> Total execution time: 0.0747
INFO - 2023-06-12 08:43:24 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:43:24 --> Final output sent to browser
DEBUG - 2023-06-12 08:43:24 --> Total execution time: 0.0979
INFO - 2023-06-12 08:44:01 --> Config Class Initialized
INFO - 2023-06-12 08:44:01 --> Hooks Class Initialized
INFO - 2023-06-12 08:44:01 --> Config Class Initialized
INFO - 2023-06-12 08:44:01 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:44:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:44:01 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:44:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:44:01 --> Utf8 Class Initialized
INFO - 2023-06-12 08:44:01 --> URI Class Initialized
INFO - 2023-06-12 08:44:01 --> URI Class Initialized
INFO - 2023-06-12 08:44:01 --> Router Class Initialized
INFO - 2023-06-12 08:44:01 --> Router Class Initialized
INFO - 2023-06-12 08:44:01 --> Output Class Initialized
INFO - 2023-06-12 08:44:01 --> Output Class Initialized
INFO - 2023-06-12 08:44:01 --> Security Class Initialized
INFO - 2023-06-12 08:44:01 --> Security Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:44:01 --> Input Class Initialized
INFO - 2023-06-12 08:44:01 --> Language Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:44:01 --> Input Class Initialized
INFO - 2023-06-12 08:44:01 --> Language Class Initialized
INFO - 2023-06-12 08:44:01 --> Loader Class Initialized
INFO - 2023-06-12 08:44:01 --> Controller Class Initialized
INFO - 2023-06-12 08:44:01 --> Loader Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:44:01 --> Controller Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:44:01 --> Database Driver Class Initialized
INFO - 2023-06-12 08:44:01 --> Database Driver Class Initialized
INFO - 2023-06-12 08:44:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:44:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:44:01 --> Final output sent to browser
DEBUG - 2023-06-12 08:44:01 --> Total execution time: 0.0638
INFO - 2023-06-12 08:44:01 --> Config Class Initialized
INFO - 2023-06-12 08:44:01 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:44:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:44:01 --> Utf8 Class Initialized
INFO - 2023-06-12 08:44:01 --> URI Class Initialized
INFO - 2023-06-12 08:44:01 --> Router Class Initialized
INFO - 2023-06-12 08:44:01 --> Final output sent to browser
DEBUG - 2023-06-12 08:44:01 --> Total execution time: 0.0899
INFO - 2023-06-12 08:44:01 --> Output Class Initialized
INFO - 2023-06-12 08:44:01 --> Security Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:44:01 --> Input Class Initialized
INFO - 2023-06-12 08:44:01 --> Language Class Initialized
INFO - 2023-06-12 08:44:01 --> Loader Class Initialized
INFO - 2023-06-12 08:44:01 --> Controller Class Initialized
INFO - 2023-06-12 08:44:01 --> Config Class Initialized
INFO - 2023-06-12 08:44:01 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:44:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:44:01 --> Utf8 Class Initialized
INFO - 2023-06-12 08:44:01 --> URI Class Initialized
INFO - 2023-06-12 08:44:01 --> Database Driver Class Initialized
INFO - 2023-06-12 08:44:01 --> Router Class Initialized
INFO - 2023-06-12 08:44:01 --> Output Class Initialized
INFO - 2023-06-12 08:44:01 --> Security Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:44:01 --> Input Class Initialized
INFO - 2023-06-12 08:44:01 --> Language Class Initialized
INFO - 2023-06-12 08:44:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:44:01 --> Final output sent to browser
INFO - 2023-06-12 08:44:01 --> Loader Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Total execution time: 0.0659
INFO - 2023-06-12 08:44:01 --> Controller Class Initialized
DEBUG - 2023-06-12 08:44:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:44:01 --> Database Driver Class Initialized
INFO - 2023-06-12 08:44:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:44:01 --> Final output sent to browser
DEBUG - 2023-06-12 08:44:01 --> Total execution time: 0.0884
INFO - 2023-06-12 08:45:00 --> Config Class Initialized
INFO - 2023-06-12 08:45:00 --> Config Class Initialized
INFO - 2023-06-12 08:45:00 --> Hooks Class Initialized
INFO - 2023-06-12 08:45:00 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:45:00 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:45:00 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:00 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:00 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:00 --> URI Class Initialized
INFO - 2023-06-12 08:45:00 --> URI Class Initialized
INFO - 2023-06-12 08:45:00 --> Router Class Initialized
INFO - 2023-06-12 08:45:00 --> Router Class Initialized
INFO - 2023-06-12 08:45:00 --> Output Class Initialized
INFO - 2023-06-12 08:45:00 --> Output Class Initialized
INFO - 2023-06-12 08:45:00 --> Security Class Initialized
INFO - 2023-06-12 08:45:00 --> Security Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:00 --> Input Class Initialized
INFO - 2023-06-12 08:45:00 --> Input Class Initialized
INFO - 2023-06-12 08:45:00 --> Language Class Initialized
INFO - 2023-06-12 08:45:00 --> Language Class Initialized
INFO - 2023-06-12 08:45:00 --> Loader Class Initialized
INFO - 2023-06-12 08:45:00 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:00 --> Loader Class Initialized
INFO - 2023-06-12 08:45:00 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:00 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:00 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:00 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:00 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:00 --> Total execution time: 0.0774
INFO - 2023-06-12 08:45:00 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:00 --> Config Class Initialized
INFO - 2023-06-12 08:45:00 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:45:00 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:00 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:00 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:00 --> Total execution time: 0.1023
INFO - 2023-06-12 08:45:00 --> URI Class Initialized
INFO - 2023-06-12 08:45:00 --> Router Class Initialized
INFO - 2023-06-12 08:45:00 --> Output Class Initialized
INFO - 2023-06-12 08:45:00 --> Security Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:00 --> Input Class Initialized
INFO - 2023-06-12 08:45:00 --> Language Class Initialized
INFO - 2023-06-12 08:45:00 --> Config Class Initialized
INFO - 2023-06-12 08:45:00 --> Loader Class Initialized
INFO - 2023-06-12 08:45:00 --> Hooks Class Initialized
INFO - 2023-06-12 08:45:00 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:45:00 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:00 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:00 --> URI Class Initialized
INFO - 2023-06-12 08:45:00 --> Router Class Initialized
INFO - 2023-06-12 08:45:00 --> Output Class Initialized
INFO - 2023-06-12 08:45:00 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:00 --> Security Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:00 --> Input Class Initialized
INFO - 2023-06-12 08:45:00 --> Language Class Initialized
INFO - 2023-06-12 08:45:00 --> Loader Class Initialized
INFO - 2023-06-12 08:45:00 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:00 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:00 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:00 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:00 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:00 --> Total execution time: 0.0965
INFO - 2023-06-12 08:45:00 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:00 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:00 --> Total execution time: 0.1004
INFO - 2023-06-12 08:45:15 --> Config Class Initialized
INFO - 2023-06-12 08:45:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:45:15 --> Config Class Initialized
INFO - 2023-06-12 08:45:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:45:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:15 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:45:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:15 --> URI Class Initialized
INFO - 2023-06-12 08:45:15 --> URI Class Initialized
INFO - 2023-06-12 08:45:15 --> Router Class Initialized
INFO - 2023-06-12 08:45:15 --> Router Class Initialized
INFO - 2023-06-12 08:45:15 --> Output Class Initialized
INFO - 2023-06-12 08:45:15 --> Output Class Initialized
INFO - 2023-06-12 08:45:15 --> Security Class Initialized
INFO - 2023-06-12 08:45:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:15 --> Input Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:15 --> Input Class Initialized
INFO - 2023-06-12 08:45:15 --> Language Class Initialized
INFO - 2023-06-12 08:45:15 --> Language Class Initialized
INFO - 2023-06-12 08:45:15 --> Loader Class Initialized
INFO - 2023-06-12 08:45:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:15 --> Loader Class Initialized
INFO - 2023-06-12 08:45:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:15 --> Final output sent to browser
INFO - 2023-06-12 08:45:15 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 08:45:15 --> Total execution time: 0.0685
INFO - 2023-06-12 08:45:15 --> Config Class Initialized
INFO - 2023-06-12 08:45:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:45:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:15 --> Total execution time: 0.0910
DEBUG - 2023-06-12 08:45:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:45:15 --> URI Class Initialized
INFO - 2023-06-12 08:45:15 --> Router Class Initialized
INFO - 2023-06-12 08:45:15 --> Output Class Initialized
INFO - 2023-06-12 08:45:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:15 --> Input Class Initialized
INFO - 2023-06-12 08:45:15 --> Language Class Initialized
INFO - 2023-06-12 08:45:15 --> Config Class Initialized
INFO - 2023-06-12 08:45:15 --> Hooks Class Initialized
INFO - 2023-06-12 08:45:15 --> Loader Class Initialized
DEBUG - 2023-06-12 08:45:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:45:15 --> Controller Class Initialized
INFO - 2023-06-12 08:45:15 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:15 --> URI Class Initialized
INFO - 2023-06-12 08:45:15 --> Router Class Initialized
INFO - 2023-06-12 08:45:15 --> Output Class Initialized
INFO - 2023-06-12 08:45:15 --> Security Class Initialized
INFO - 2023-06-12 08:45:15 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:45:15 --> Input Class Initialized
INFO - 2023-06-12 08:45:15 --> Language Class Initialized
INFO - 2023-06-12 08:45:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:15 --> Total execution time: 0.0639
INFO - 2023-06-12 08:45:15 --> Loader Class Initialized
INFO - 2023-06-12 08:45:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:45:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:45:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:45:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:45:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:45:15 --> Total execution time: 0.0968
INFO - 2023-06-12 08:46:30 --> Config Class Initialized
INFO - 2023-06-12 08:46:30 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:30 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:30 --> URI Class Initialized
INFO - 2023-06-12 08:46:30 --> Router Class Initialized
INFO - 2023-06-12 08:46:30 --> Output Class Initialized
INFO - 2023-06-12 08:46:30 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:30 --> Input Class Initialized
INFO - 2023-06-12 08:46:30 --> Language Class Initialized
INFO - 2023-06-12 08:46:30 --> Loader Class Initialized
INFO - 2023-06-12 08:46:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:30 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:30 --> Total execution time: 0.0912
INFO - 2023-06-12 08:46:30 --> Config Class Initialized
INFO - 2023-06-12 08:46:30 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:30 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:30 --> URI Class Initialized
INFO - 2023-06-12 08:46:30 --> Router Class Initialized
INFO - 2023-06-12 08:46:30 --> Output Class Initialized
INFO - 2023-06-12 08:46:30 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:30 --> Input Class Initialized
INFO - 2023-06-12 08:46:30 --> Language Class Initialized
INFO - 2023-06-12 08:46:30 --> Loader Class Initialized
INFO - 2023-06-12 08:46:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:31 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:31 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:31 --> Total execution time: 0.0987
INFO - 2023-06-12 08:46:37 --> Config Class Initialized
INFO - 2023-06-12 08:46:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:46:37 --> Config Class Initialized
INFO - 2023-06-12 08:46:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:37 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:37 --> URI Class Initialized
INFO - 2023-06-12 08:46:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:37 --> URI Class Initialized
INFO - 2023-06-12 08:46:37 --> Router Class Initialized
INFO - 2023-06-12 08:46:37 --> Router Class Initialized
INFO - 2023-06-12 08:46:37 --> Output Class Initialized
INFO - 2023-06-12 08:46:37 --> Output Class Initialized
INFO - 2023-06-12 08:46:37 --> Security Class Initialized
INFO - 2023-06-12 08:46:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:37 --> Input Class Initialized
INFO - 2023-06-12 08:46:37 --> Language Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:37 --> Input Class Initialized
INFO - 2023-06-12 08:46:37 --> Language Class Initialized
INFO - 2023-06-12 08:46:37 --> Loader Class Initialized
INFO - 2023-06-12 08:46:37 --> Controller Class Initialized
INFO - 2023-06-12 08:46:37 --> Loader Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:37 --> Total execution time: 0.0777
INFO - 2023-06-12 08:46:37 --> Config Class Initialized
INFO - 2023-06-12 08:46:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:46:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:37 --> Total execution time: 0.1001
DEBUG - 2023-06-12 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:37 --> URI Class Initialized
INFO - 2023-06-12 08:46:37 --> Router Class Initialized
INFO - 2023-06-12 08:46:37 --> Output Class Initialized
INFO - 2023-06-12 08:46:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:37 --> Input Class Initialized
INFO - 2023-06-12 08:46:37 --> Language Class Initialized
INFO - 2023-06-12 08:46:37 --> Config Class Initialized
INFO - 2023-06-12 08:46:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:46:37 --> Loader Class Initialized
INFO - 2023-06-12 08:46:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:37 --> URI Class Initialized
INFO - 2023-06-12 08:46:37 --> Router Class Initialized
INFO - 2023-06-12 08:46:37 --> Output Class Initialized
INFO - 2023-06-12 08:46:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:37 --> Input Class Initialized
INFO - 2023-06-12 08:46:37 --> Language Class Initialized
INFO - 2023-06-12 08:46:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:37 --> Total execution time: 0.0700
INFO - 2023-06-12 08:46:37 --> Loader Class Initialized
INFO - 2023-06-12 08:46:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:37 --> Total execution time: 0.0905
INFO - 2023-06-12 08:46:46 --> Config Class Initialized
INFO - 2023-06-12 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:46 --> URI Class Initialized
INFO - 2023-06-12 08:46:46 --> Router Class Initialized
INFO - 2023-06-12 08:46:46 --> Output Class Initialized
INFO - 2023-06-12 08:46:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:46 --> Input Class Initialized
INFO - 2023-06-12 08:46:46 --> Language Class Initialized
INFO - 2023-06-12 08:46:46 --> Loader Class Initialized
INFO - 2023-06-12 08:46:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:46 --> Total execution time: 0.0702
INFO - 2023-06-12 08:46:46 --> Config Class Initialized
INFO - 2023-06-12 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:46 --> URI Class Initialized
INFO - 2023-06-12 08:46:46 --> Router Class Initialized
INFO - 2023-06-12 08:46:46 --> Output Class Initialized
INFO - 2023-06-12 08:46:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:46 --> Input Class Initialized
INFO - 2023-06-12 08:46:46 --> Language Class Initialized
INFO - 2023-06-12 08:46:46 --> Loader Class Initialized
INFO - 2023-06-12 08:46:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:46 --> Total execution time: 0.0578
INFO - 2023-06-12 08:46:46 --> Config Class Initialized
INFO - 2023-06-12 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:46 --> URI Class Initialized
INFO - 2023-06-12 08:46:46 --> Router Class Initialized
INFO - 2023-06-12 08:46:46 --> Output Class Initialized
INFO - 2023-06-12 08:46:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:46 --> Input Class Initialized
INFO - 2023-06-12 08:46:46 --> Language Class Initialized
INFO - 2023-06-12 08:46:46 --> Loader Class Initialized
INFO - 2023-06-12 08:46:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:46 --> Total execution time: 0.0634
INFO - 2023-06-12 08:46:46 --> Config Class Initialized
INFO - 2023-06-12 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:46:46 --> Utf8 Class Initialized
INFO - 2023-06-12 08:46:46 --> URI Class Initialized
INFO - 2023-06-12 08:46:46 --> Router Class Initialized
INFO - 2023-06-12 08:46:46 --> Output Class Initialized
INFO - 2023-06-12 08:46:46 --> Security Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:46:46 --> Input Class Initialized
INFO - 2023-06-12 08:46:46 --> Language Class Initialized
INFO - 2023-06-12 08:46:46 --> Loader Class Initialized
INFO - 2023-06-12 08:46:46 --> Controller Class Initialized
DEBUG - 2023-06-12 08:46:46 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:46:46 --> Database Driver Class Initialized
INFO - 2023-06-12 08:46:46 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:46:46 --> Final output sent to browser
DEBUG - 2023-06-12 08:46:46 --> Total execution time: 0.0574
INFO - 2023-06-12 08:47:07 --> Config Class Initialized
INFO - 2023-06-12 08:47:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:07 --> Config Class Initialized
INFO - 2023-06-12 08:47:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:07 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:47:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:07 --> URI Class Initialized
INFO - 2023-06-12 08:47:07 --> URI Class Initialized
INFO - 2023-06-12 08:47:07 --> Router Class Initialized
INFO - 2023-06-12 08:47:07 --> Router Class Initialized
INFO - 2023-06-12 08:47:07 --> Output Class Initialized
INFO - 2023-06-12 08:47:07 --> Output Class Initialized
INFO - 2023-06-12 08:47:07 --> Security Class Initialized
INFO - 2023-06-12 08:47:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:07 --> Input Class Initialized
INFO - 2023-06-12 08:47:07 --> Input Class Initialized
INFO - 2023-06-12 08:47:07 --> Language Class Initialized
INFO - 2023-06-12 08:47:07 --> Language Class Initialized
INFO - 2023-06-12 08:47:07 --> Loader Class Initialized
INFO - 2023-06-12 08:47:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:07 --> Loader Class Initialized
INFO - 2023-06-12 08:47:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:07 --> Total execution time: 0.0830
INFO - 2023-06-12 08:47:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:07 --> Total execution time: 0.0903
INFO - 2023-06-12 08:47:07 --> Config Class Initialized
INFO - 2023-06-12 08:47:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:07 --> URI Class Initialized
INFO - 2023-06-12 08:47:07 --> Config Class Initialized
INFO - 2023-06-12 08:47:07 --> Router Class Initialized
INFO - 2023-06-12 08:47:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:07 --> Output Class Initialized
INFO - 2023-06-12 08:47:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:07 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:07 --> Input Class Initialized
INFO - 2023-06-12 08:47:07 --> URI Class Initialized
INFO - 2023-06-12 08:47:07 --> Language Class Initialized
INFO - 2023-06-12 08:47:07 --> Router Class Initialized
INFO - 2023-06-12 08:47:07 --> Output Class Initialized
INFO - 2023-06-12 08:47:07 --> Loader Class Initialized
INFO - 2023-06-12 08:47:07 --> Security Class Initialized
INFO - 2023-06-12 08:47:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:07 --> Input Class Initialized
INFO - 2023-06-12 08:47:07 --> Language Class Initialized
INFO - 2023-06-12 08:47:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:07 --> Loader Class Initialized
INFO - 2023-06-12 08:47:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:08 --> Total execution time: 0.0789
INFO - 2023-06-12 08:47:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:08 --> Total execution time: 0.1082
INFO - 2023-06-12 08:47:14 --> Config Class Initialized
INFO - 2023-06-12 08:47:14 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:14 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:14 --> URI Class Initialized
INFO - 2023-06-12 08:47:14 --> Router Class Initialized
INFO - 2023-06-12 08:47:14 --> Output Class Initialized
INFO - 2023-06-12 08:47:14 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:14 --> Input Class Initialized
INFO - 2023-06-12 08:47:14 --> Language Class Initialized
INFO - 2023-06-12 08:47:14 --> Loader Class Initialized
INFO - 2023-06-12 08:47:14 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:14 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:14 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:14 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:14 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:14 --> Total execution time: 0.0749
INFO - 2023-06-12 08:47:14 --> Config Class Initialized
INFO - 2023-06-12 08:47:14 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:14 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:15 --> URI Class Initialized
INFO - 2023-06-12 08:47:15 --> Router Class Initialized
INFO - 2023-06-12 08:47:15 --> Output Class Initialized
INFO - 2023-06-12 08:47:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:15 --> Input Class Initialized
INFO - 2023-06-12 08:47:15 --> Language Class Initialized
INFO - 2023-06-12 08:47:15 --> Loader Class Initialized
INFO - 2023-06-12 08:47:15 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:15 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:15 --> Total execution time: 0.0762
INFO - 2023-06-12 08:47:22 --> Config Class Initialized
INFO - 2023-06-12 08:47:22 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:22 --> Config Class Initialized
INFO - 2023-06-12 08:47:22 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:22 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:47:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:22 --> URI Class Initialized
INFO - 2023-06-12 08:47:22 --> URI Class Initialized
INFO - 2023-06-12 08:47:22 --> Router Class Initialized
INFO - 2023-06-12 08:47:22 --> Router Class Initialized
INFO - 2023-06-12 08:47:22 --> Output Class Initialized
INFO - 2023-06-12 08:47:22 --> Output Class Initialized
INFO - 2023-06-12 08:47:22 --> Security Class Initialized
INFO - 2023-06-12 08:47:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:22 --> Input Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:22 --> Language Class Initialized
INFO - 2023-06-12 08:47:22 --> Input Class Initialized
INFO - 2023-06-12 08:47:22 --> Language Class Initialized
INFO - 2023-06-12 08:47:22 --> Loader Class Initialized
INFO - 2023-06-12 08:47:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:22 --> Loader Class Initialized
INFO - 2023-06-12 08:47:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:22 --> Total execution time: 0.0574
INFO - 2023-06-12 08:47:22 --> Config Class Initialized
INFO - 2023-06-12 08:47:22 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:22 --> URI Class Initialized
INFO - 2023-06-12 08:47:22 --> Router Class Initialized
INFO - 2023-06-12 08:47:22 --> Output Class Initialized
INFO - 2023-06-12 08:47:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:22 --> Input Class Initialized
INFO - 2023-06-12 08:47:22 --> Language Class Initialized
INFO - 2023-06-12 08:47:22 --> Loader Class Initialized
INFO - 2023-06-12 08:47:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:22 --> Total execution time: 0.0869
INFO - 2023-06-12 08:47:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:22 --> Total execution time: 0.1680
INFO - 2023-06-12 08:47:22 --> Config Class Initialized
INFO - 2023-06-12 08:47:22 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:22 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:22 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:22 --> URI Class Initialized
INFO - 2023-06-12 08:47:22 --> Router Class Initialized
INFO - 2023-06-12 08:47:22 --> Output Class Initialized
INFO - 2023-06-12 08:47:22 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:22 --> Input Class Initialized
INFO - 2023-06-12 08:47:22 --> Language Class Initialized
INFO - 2023-06-12 08:47:22 --> Loader Class Initialized
INFO - 2023-06-12 08:47:22 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:22 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:22 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:22 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:22 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:22 --> Total execution time: 0.0855
INFO - 2023-06-12 08:47:30 --> Config Class Initialized
INFO - 2023-06-12 08:47:30 --> Config Class Initialized
INFO - 2023-06-12 08:47:30 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:30 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:30 --> URI Class Initialized
INFO - 2023-06-12 08:47:30 --> URI Class Initialized
INFO - 2023-06-12 08:47:30 --> Router Class Initialized
INFO - 2023-06-12 08:47:30 --> Router Class Initialized
INFO - 2023-06-12 08:47:30 --> Output Class Initialized
INFO - 2023-06-12 08:47:30 --> Output Class Initialized
INFO - 2023-06-12 08:47:30 --> Security Class Initialized
INFO - 2023-06-12 08:47:30 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:30 --> Input Class Initialized
INFO - 2023-06-12 08:47:30 --> Input Class Initialized
INFO - 2023-06-12 08:47:30 --> Language Class Initialized
INFO - 2023-06-12 08:47:30 --> Language Class Initialized
INFO - 2023-06-12 08:47:30 --> Loader Class Initialized
INFO - 2023-06-12 08:47:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:30 --> Loader Class Initialized
INFO - 2023-06-12 08:47:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:30 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:30 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:30 --> Total execution time: 0.0978
INFO - 2023-06-12 08:47:30 --> Config Class Initialized
INFO - 2023-06-12 08:47:30 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:30 --> URI Class Initialized
INFO - 2023-06-12 08:47:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:30 --> Total execution time: 0.1323
INFO - 2023-06-12 08:47:30 --> Router Class Initialized
INFO - 2023-06-12 08:47:30 --> Output Class Initialized
INFO - 2023-06-12 08:47:30 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:30 --> Input Class Initialized
INFO - 2023-06-12 08:47:30 --> Language Class Initialized
INFO - 2023-06-12 08:47:30 --> Loader Class Initialized
INFO - 2023-06-12 08:47:30 --> Config Class Initialized
INFO - 2023-06-12 08:47:30 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:30 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:30 --> URI Class Initialized
INFO - 2023-06-12 08:47:30 --> Router Class Initialized
INFO - 2023-06-12 08:47:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:30 --> Output Class Initialized
INFO - 2023-06-12 08:47:30 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:30 --> Input Class Initialized
INFO - 2023-06-12 08:47:30 --> Language Class Initialized
INFO - 2023-06-12 08:47:30 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:30 --> Total execution time: 0.0848
INFO - 2023-06-12 08:47:30 --> Loader Class Initialized
INFO - 2023-06-12 08:47:30 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:30 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:30 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:30 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:30 --> Total execution time: 0.1150
INFO - 2023-06-12 08:47:33 --> Config Class Initialized
INFO - 2023-06-12 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:33 --> URI Class Initialized
INFO - 2023-06-12 08:47:33 --> Router Class Initialized
INFO - 2023-06-12 08:47:33 --> Output Class Initialized
INFO - 2023-06-12 08:47:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:33 --> Input Class Initialized
INFO - 2023-06-12 08:47:33 --> Language Class Initialized
INFO - 2023-06-12 08:47:33 --> Loader Class Initialized
INFO - 2023-06-12 08:47:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:33 --> Total execution time: 0.0655
INFO - 2023-06-12 08:47:33 --> Config Class Initialized
INFO - 2023-06-12 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:33 --> URI Class Initialized
INFO - 2023-06-12 08:47:33 --> Router Class Initialized
INFO - 2023-06-12 08:47:33 --> Output Class Initialized
INFO - 2023-06-12 08:47:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:33 --> Input Class Initialized
INFO - 2023-06-12 08:47:33 --> Language Class Initialized
INFO - 2023-06-12 08:47:33 --> Loader Class Initialized
INFO - 2023-06-12 08:47:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:33 --> Total execution time: 0.0750
INFO - 2023-06-12 08:47:33 --> Config Class Initialized
INFO - 2023-06-12 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:33 --> URI Class Initialized
INFO - 2023-06-12 08:47:33 --> Router Class Initialized
INFO - 2023-06-12 08:47:33 --> Output Class Initialized
INFO - 2023-06-12 08:47:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:33 --> Input Class Initialized
INFO - 2023-06-12 08:47:33 --> Language Class Initialized
INFO - 2023-06-12 08:47:33 --> Loader Class Initialized
INFO - 2023-06-12 08:47:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:33 --> Total execution time: 0.0783
INFO - 2023-06-12 08:47:33 --> Config Class Initialized
INFO - 2023-06-12 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:33 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:33 --> URI Class Initialized
INFO - 2023-06-12 08:47:33 --> Router Class Initialized
INFO - 2023-06-12 08:47:33 --> Output Class Initialized
INFO - 2023-06-12 08:47:33 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:33 --> Input Class Initialized
INFO - 2023-06-12 08:47:33 --> Language Class Initialized
INFO - 2023-06-12 08:47:33 --> Loader Class Initialized
INFO - 2023-06-12 08:47:33 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:33 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:33 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:33 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:33 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:33 --> Total execution time: 0.0903
INFO - 2023-06-12 08:47:34 --> Config Class Initialized
INFO - 2023-06-12 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:34 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:34 --> URI Class Initialized
INFO - 2023-06-12 08:47:34 --> Router Class Initialized
INFO - 2023-06-12 08:47:34 --> Output Class Initialized
INFO - 2023-06-12 08:47:34 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:34 --> Input Class Initialized
INFO - 2023-06-12 08:47:34 --> Language Class Initialized
INFO - 2023-06-12 08:47:34 --> Loader Class Initialized
INFO - 2023-06-12 08:47:34 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:34 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:34 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:34 --> Total execution time: 0.0810
INFO - 2023-06-12 08:47:34 --> Config Class Initialized
INFO - 2023-06-12 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:34 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:34 --> URI Class Initialized
INFO - 2023-06-12 08:47:34 --> Router Class Initialized
INFO - 2023-06-12 08:47:34 --> Output Class Initialized
INFO - 2023-06-12 08:47:34 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:34 --> Input Class Initialized
INFO - 2023-06-12 08:47:34 --> Language Class Initialized
INFO - 2023-06-12 08:47:34 --> Loader Class Initialized
INFO - 2023-06-12 08:47:34 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:34 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:34 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:34 --> Total execution time: 0.0701
INFO - 2023-06-12 08:47:35 --> Config Class Initialized
INFO - 2023-06-12 08:47:35 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:35 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:35 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:35 --> URI Class Initialized
INFO - 2023-06-12 08:47:35 --> Router Class Initialized
INFO - 2023-06-12 08:47:35 --> Output Class Initialized
INFO - 2023-06-12 08:47:35 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:35 --> Input Class Initialized
INFO - 2023-06-12 08:47:35 --> Language Class Initialized
INFO - 2023-06-12 08:47:35 --> Loader Class Initialized
INFO - 2023-06-12 08:47:35 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:35 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:35 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:35 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:35 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:35 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:35 --> Total execution time: 0.0824
INFO - 2023-06-12 08:47:35 --> Config Class Initialized
INFO - 2023-06-12 08:47:35 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:35 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:35 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:35 --> URI Class Initialized
INFO - 2023-06-12 08:47:35 --> Router Class Initialized
INFO - 2023-06-12 08:47:35 --> Output Class Initialized
INFO - 2023-06-12 08:47:35 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:35 --> Input Class Initialized
INFO - 2023-06-12 08:47:35 --> Language Class Initialized
INFO - 2023-06-12 08:47:35 --> Loader Class Initialized
INFO - 2023-06-12 08:47:35 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:35 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:35 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:35 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:35 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:35 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:35 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:35 --> Total execution time: 0.0879
INFO - 2023-06-12 08:47:36 --> Config Class Initialized
INFO - 2023-06-12 08:47:36 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:36 --> Config Class Initialized
INFO - 2023-06-12 08:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:36 --> URI Class Initialized
DEBUG - 2023-06-12 08:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:36 --> Router Class Initialized
INFO - 2023-06-12 08:47:36 --> URI Class Initialized
INFO - 2023-06-12 08:47:36 --> Output Class Initialized
INFO - 2023-06-12 08:47:36 --> Router Class Initialized
INFO - 2023-06-12 08:47:36 --> Security Class Initialized
INFO - 2023-06-12 08:47:36 --> Output Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:36 --> Input Class Initialized
INFO - 2023-06-12 08:47:36 --> Security Class Initialized
INFO - 2023-06-12 08:47:36 --> Language Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:36 --> Input Class Initialized
INFO - 2023-06-12 08:47:36 --> Language Class Initialized
INFO - 2023-06-12 08:47:36 --> Loader Class Initialized
INFO - 2023-06-12 08:47:36 --> Loader Class Initialized
INFO - 2023-06-12 08:47:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:36 --> Total execution time: 0.0564
INFO - 2023-06-12 08:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:36 --> Config Class Initialized
INFO - 2023-06-12 08:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:36 --> URI Class Initialized
INFO - 2023-06-12 08:47:36 --> Router Class Initialized
INFO - 2023-06-12 08:47:36 --> Output Class Initialized
INFO - 2023-06-12 08:47:36 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:36 --> Input Class Initialized
INFO - 2023-06-12 08:47:36 --> Language Class Initialized
INFO - 2023-06-12 08:47:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:36 --> Total execution time: 0.0937
INFO - 2023-06-12 08:47:36 --> Loader Class Initialized
INFO - 2023-06-12 08:47:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:36 --> Config Class Initialized
INFO - 2023-06-12 08:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:36 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:36 --> URI Class Initialized
INFO - 2023-06-12 08:47:36 --> Router Class Initialized
INFO - 2023-06-12 08:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:36 --> Output Class Initialized
INFO - 2023-06-12 08:47:36 --> Security Class Initialized
INFO - 2023-06-12 08:47:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:36 --> Total execution time: 0.0587
DEBUG - 2023-06-12 08:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:36 --> Input Class Initialized
INFO - 2023-06-12 08:47:36 --> Language Class Initialized
INFO - 2023-06-12 08:47:36 --> Loader Class Initialized
INFO - 2023-06-12 08:47:36 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:36 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:36 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:36 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:36 --> Total execution time: 0.0935
INFO - 2023-06-12 08:47:43 --> Config Class Initialized
INFO - 2023-06-12 08:47:43 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:43 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:43 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:43 --> URI Class Initialized
INFO - 2023-06-12 08:47:43 --> Router Class Initialized
INFO - 2023-06-12 08:47:43 --> Output Class Initialized
INFO - 2023-06-12 08:47:43 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:43 --> Input Class Initialized
INFO - 2023-06-12 08:47:43 --> Language Class Initialized
INFO - 2023-06-12 08:47:43 --> Loader Class Initialized
INFO - 2023-06-12 08:47:43 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 08:47:43 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 08:47:43 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:43 --> Total execution time: 0.0948
INFO - 2023-06-12 08:47:43 --> Config Class Initialized
INFO - 2023-06-12 08:47:43 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:43 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:43 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:43 --> URI Class Initialized
INFO - 2023-06-12 08:47:43 --> Router Class Initialized
INFO - 2023-06-12 08:47:43 --> Output Class Initialized
INFO - 2023-06-12 08:47:43 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:43 --> Input Class Initialized
INFO - 2023-06-12 08:47:43 --> Language Class Initialized
INFO - 2023-06-12 08:47:43 --> Loader Class Initialized
INFO - 2023-06-12 08:47:43 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Cluster_model" initialized
ERROR - 2023-06-12 08:47:43 --> Query error: Table 'kunlun_dba_tools_db.rcr_max_dalay' doesn't exist - Invalid query: select max_delay_time from rcr_max_dalay where user_id='1' and rcr_id='1';  
INFO - 2023-06-12 08:47:43 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:43 --> Total execution time: 0.0998
INFO - 2023-06-12 08:47:43 --> Config Class Initialized
INFO - 2023-06-12 08:47:43 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:43 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:43 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:43 --> URI Class Initialized
INFO - 2023-06-12 08:47:43 --> Router Class Initialized
INFO - 2023-06-12 08:47:43 --> Output Class Initialized
INFO - 2023-06-12 08:47:43 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:43 --> Input Class Initialized
INFO - 2023-06-12 08:47:43 --> Language Class Initialized
INFO - 2023-06-12 08:47:43 --> Loader Class Initialized
INFO - 2023-06-12 08:47:43 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:43 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:43 --> Total execution time: 0.0339
INFO - 2023-06-12 08:47:43 --> Config Class Initialized
INFO - 2023-06-12 08:47:43 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:43 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:43 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:43 --> URI Class Initialized
INFO - 2023-06-12 08:47:43 --> Router Class Initialized
INFO - 2023-06-12 08:47:43 --> Output Class Initialized
INFO - 2023-06-12 08:47:43 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:43 --> Input Class Initialized
INFO - 2023-06-12 08:47:43 --> Language Class Initialized
INFO - 2023-06-12 08:47:43 --> Loader Class Initialized
INFO - 2023-06-12 08:47:43 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:43 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:43 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:43 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:43 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:43 --> Total execution time: 0.1216
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1018
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1123
INFO - 2023-06-12 08:47:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1085
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1214
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
INFO - 2023-06-12 08:47:57 --> Config Class Initialized
INFO - 2023-06-12 08:47:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:47:57 --> URI Class Initialized
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Router Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Output Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Security Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Input Class Initialized
INFO - 2023-06-12 08:47:57 --> Language Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Loader Class Initialized
INFO - 2023-06-12 08:47:57 --> Controller Class Initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:47:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:47:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:47:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1060
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.0925
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1074
INFO - 2023-06-12 08:47:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:47:57 --> Total execution time: 0.1248
INFO - 2023-06-12 08:48:07 --> Config Class Initialized
INFO - 2023-06-12 08:48:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:07 --> Config Class Initialized
INFO - 2023-06-12 08:48:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:07 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:48:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:07 --> URI Class Initialized
INFO - 2023-06-12 08:48:07 --> URI Class Initialized
INFO - 2023-06-12 08:48:07 --> Router Class Initialized
INFO - 2023-06-12 08:48:07 --> Router Class Initialized
INFO - 2023-06-12 08:48:07 --> Output Class Initialized
INFO - 2023-06-12 08:48:07 --> Output Class Initialized
INFO - 2023-06-12 08:48:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:07 --> Security Class Initialized
INFO - 2023-06-12 08:48:07 --> Input Class Initialized
INFO - 2023-06-12 08:48:07 --> Language Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:07 --> Input Class Initialized
INFO - 2023-06-12 08:48:07 --> Language Class Initialized
INFO - 2023-06-12 08:48:07 --> Loader Class Initialized
INFO - 2023-06-12 08:48:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:07 --> Loader Class Initialized
INFO - 2023-06-12 08:48:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:07 --> Total execution time: 0.1067
INFO - 2023-06-12 08:48:07 --> Config Class Initialized
INFO - 2023-06-12 08:48:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:07 --> URI Class Initialized
INFO - 2023-06-12 08:48:07 --> Router Class Initialized
INFO - 2023-06-12 08:48:07 --> Output Class Initialized
INFO - 2023-06-12 08:48:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:07 --> Input Class Initialized
INFO - 2023-06-12 08:48:07 --> Language Class Initialized
INFO - 2023-06-12 08:48:07 --> Loader Class Initialized
INFO - 2023-06-12 08:48:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:07 --> Total execution time: 0.1247
INFO - 2023-06-12 08:48:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:07 --> Total execution time: 0.9980
INFO - 2023-06-12 08:48:08 --> Config Class Initialized
INFO - 2023-06-12 08:48:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:08 --> URI Class Initialized
INFO - 2023-06-12 08:48:08 --> Router Class Initialized
INFO - 2023-06-12 08:48:08 --> Output Class Initialized
INFO - 2023-06-12 08:48:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:08 --> Input Class Initialized
INFO - 2023-06-12 08:48:08 --> Language Class Initialized
INFO - 2023-06-12 08:48:08 --> Loader Class Initialized
INFO - 2023-06-12 08:48:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:08 --> Total execution time: 0.6558
INFO - 2023-06-12 08:48:17 --> Config Class Initialized
INFO - 2023-06-12 08:48:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:17 --> Config Class Initialized
INFO - 2023-06-12 08:48:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:17 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:48:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:17 --> URI Class Initialized
INFO - 2023-06-12 08:48:17 --> URI Class Initialized
INFO - 2023-06-12 08:48:17 --> Router Class Initialized
INFO - 2023-06-12 08:48:17 --> Router Class Initialized
INFO - 2023-06-12 08:48:17 --> Output Class Initialized
INFO - 2023-06-12 08:48:17 --> Output Class Initialized
INFO - 2023-06-12 08:48:17 --> Security Class Initialized
INFO - 2023-06-12 08:48:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:17 --> Input Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:17 --> Language Class Initialized
INFO - 2023-06-12 08:48:17 --> Input Class Initialized
INFO - 2023-06-12 08:48:17 --> Language Class Initialized
INFO - 2023-06-12 08:48:17 --> Loader Class Initialized
INFO - 2023-06-12 08:48:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:17 --> Loader Class Initialized
INFO - 2023-06-12 08:48:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:17 --> Total execution time: 0.1162
INFO - 2023-06-12 08:48:17 --> Config Class Initialized
INFO - 2023-06-12 08:48:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:17 --> URI Class Initialized
INFO - 2023-06-12 08:48:17 --> Router Class Initialized
INFO - 2023-06-12 08:48:17 --> Output Class Initialized
INFO - 2023-06-12 08:48:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:17 --> Input Class Initialized
INFO - 2023-06-12 08:48:17 --> Language Class Initialized
INFO - 2023-06-12 08:48:17 --> Loader Class Initialized
INFO - 2023-06-12 08:48:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:17 --> Total execution time: 0.1655
INFO - 2023-06-12 08:48:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:17 --> Total execution time: 0.7181
INFO - 2023-06-12 08:48:17 --> Config Class Initialized
INFO - 2023-06-12 08:48:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:17 --> URI Class Initialized
INFO - 2023-06-12 08:48:17 --> Router Class Initialized
INFO - 2023-06-12 08:48:17 --> Output Class Initialized
INFO - 2023-06-12 08:48:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:17 --> Input Class Initialized
INFO - 2023-06-12 08:48:17 --> Language Class Initialized
INFO - 2023-06-12 08:48:17 --> Loader Class Initialized
INFO - 2023-06-12 08:48:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:18 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:18 --> Total execution time: 0.5918
INFO - 2023-06-12 08:48:27 --> Config Class Initialized
INFO - 2023-06-12 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:27 --> URI Class Initialized
INFO - 2023-06-12 08:48:27 --> Config Class Initialized
INFO - 2023-06-12 08:48:27 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:27 --> Router Class Initialized
INFO - 2023-06-12 08:48:27 --> Output Class Initialized
DEBUG - 2023-06-12 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:27 --> Security Class Initialized
INFO - 2023-06-12 08:48:27 --> URI Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:27 --> Input Class Initialized
INFO - 2023-06-12 08:48:27 --> Language Class Initialized
INFO - 2023-06-12 08:48:27 --> Router Class Initialized
INFO - 2023-06-12 08:48:27 --> Output Class Initialized
INFO - 2023-06-12 08:48:27 --> Security Class Initialized
INFO - 2023-06-12 08:48:27 --> Loader Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:27 --> Controller Class Initialized
INFO - 2023-06-12 08:48:27 --> Input Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:27 --> Language Class Initialized
INFO - 2023-06-12 08:48:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:27 --> Loader Class Initialized
INFO - 2023-06-12 08:48:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:27 --> Total execution time: 0.1055
INFO - 2023-06-12 08:48:27 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:27 --> Config Class Initialized
INFO - 2023-06-12 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:27 --> URI Class Initialized
INFO - 2023-06-12 08:48:27 --> Router Class Initialized
INFO - 2023-06-12 08:48:27 --> Output Class Initialized
INFO - 2023-06-12 08:48:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:27 --> Input Class Initialized
INFO - 2023-06-12 08:48:27 --> Language Class Initialized
INFO - 2023-06-12 08:48:27 --> Loader Class Initialized
INFO - 2023-06-12 08:48:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:27 --> Total execution time: 0.3866
INFO - 2023-06-12 08:48:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:28 --> Total execution time: 1.0442
INFO - 2023-06-12 08:48:28 --> Config Class Initialized
INFO - 2023-06-12 08:48:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:28 --> URI Class Initialized
INFO - 2023-06-12 08:48:28 --> Router Class Initialized
INFO - 2023-06-12 08:48:28 --> Output Class Initialized
INFO - 2023-06-12 08:48:28 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:28 --> Input Class Initialized
INFO - 2023-06-12 08:48:28 --> Language Class Initialized
INFO - 2023-06-12 08:48:28 --> Loader Class Initialized
INFO - 2023-06-12 08:48:28 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:28 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:28 --> Total execution time: 0.5773
INFO - 2023-06-12 08:48:37 --> Config Class Initialized
INFO - 2023-06-12 08:48:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:37 --> Config Class Initialized
INFO - 2023-06-12 08:48:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:37 --> URI Class Initialized
DEBUG - 2023-06-12 08:48:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:37 --> Router Class Initialized
INFO - 2023-06-12 08:48:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:37 --> URI Class Initialized
INFO - 2023-06-12 08:48:37 --> Output Class Initialized
INFO - 2023-06-12 08:48:37 --> Router Class Initialized
INFO - 2023-06-12 08:48:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:37 --> Input Class Initialized
INFO - 2023-06-12 08:48:37 --> Output Class Initialized
INFO - 2023-06-12 08:48:37 --> Language Class Initialized
INFO - 2023-06-12 08:48:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:37 --> Input Class Initialized
INFO - 2023-06-12 08:48:37 --> Loader Class Initialized
INFO - 2023-06-12 08:48:37 --> Language Class Initialized
INFO - 2023-06-12 08:48:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:37 --> Loader Class Initialized
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:37 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:37 --> Total execution time: 0.1006
INFO - 2023-06-12 08:48:37 --> Config Class Initialized
INFO - 2023-06-12 08:48:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:37 --> URI Class Initialized
INFO - 2023-06-12 08:48:37 --> Router Class Initialized
INFO - 2023-06-12 08:48:37 --> Output Class Initialized
INFO - 2023-06-12 08:48:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:37 --> Input Class Initialized
INFO - 2023-06-12 08:48:37 --> Language Class Initialized
INFO - 2023-06-12 08:48:37 --> Loader Class Initialized
INFO - 2023-06-12 08:48:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:37 --> Total execution time: 0.0881
INFO - 2023-06-12 08:48:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:37 --> Total execution time: 0.5903
INFO - 2023-06-12 08:48:37 --> Config Class Initialized
INFO - 2023-06-12 08:48:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:37 --> URI Class Initialized
INFO - 2023-06-12 08:48:37 --> Router Class Initialized
INFO - 2023-06-12 08:48:37 --> Output Class Initialized
INFO - 2023-06-12 08:48:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:37 --> Input Class Initialized
INFO - 2023-06-12 08:48:37 --> Language Class Initialized
INFO - 2023-06-12 08:48:37 --> Loader Class Initialized
INFO - 2023-06-12 08:48:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:37 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:38 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:38 --> Total execution time: 0.7004
INFO - 2023-06-12 08:48:47 --> Config Class Initialized
INFO - 2023-06-12 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:47 --> Config Class Initialized
INFO - 2023-06-12 08:48:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:47 --> URI Class Initialized
INFO - 2023-06-12 08:48:47 --> Router Class Initialized
DEBUG - 2023-06-12 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:47 --> Output Class Initialized
INFO - 2023-06-12 08:48:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:47 --> URI Class Initialized
INFO - 2023-06-12 08:48:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:47 --> Input Class Initialized
INFO - 2023-06-12 08:48:47 --> Router Class Initialized
INFO - 2023-06-12 08:48:47 --> Language Class Initialized
INFO - 2023-06-12 08:48:47 --> Output Class Initialized
INFO - 2023-06-12 08:48:47 --> Security Class Initialized
INFO - 2023-06-12 08:48:47 --> Loader Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:47 --> Input Class Initialized
INFO - 2023-06-12 08:48:47 --> Language Class Initialized
INFO - 2023-06-12 08:48:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:47 --> Loader Class Initialized
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:47 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:47 --> Total execution time: 0.1135
INFO - 2023-06-12 08:48:47 --> Config Class Initialized
INFO - 2023-06-12 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:47 --> URI Class Initialized
INFO - 2023-06-12 08:48:47 --> Router Class Initialized
INFO - 2023-06-12 08:48:47 --> Output Class Initialized
INFO - 2023-06-12 08:48:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:47 --> Input Class Initialized
INFO - 2023-06-12 08:48:47 --> Language Class Initialized
INFO - 2023-06-12 08:48:47 --> Loader Class Initialized
INFO - 2023-06-12 08:48:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:47 --> Total execution time: 0.0818
INFO - 2023-06-12 08:48:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:47 --> Total execution time: 0.6228
INFO - 2023-06-12 08:48:47 --> Config Class Initialized
INFO - 2023-06-12 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:47 --> URI Class Initialized
INFO - 2023-06-12 08:48:47 --> Router Class Initialized
INFO - 2023-06-12 08:48:47 --> Output Class Initialized
INFO - 2023-06-12 08:48:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:47 --> Input Class Initialized
INFO - 2023-06-12 08:48:47 --> Language Class Initialized
INFO - 2023-06-12 08:48:47 --> Loader Class Initialized
INFO - 2023-06-12 08:48:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:47 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:48 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:48 --> Total execution time: 0.5994
INFO - 2023-06-12 08:48:57 --> Config Class Initialized
INFO - 2023-06-12 08:48:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:48:57 --> Config Class Initialized
INFO - 2023-06-12 08:48:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:57 --> URI Class Initialized
DEBUG - 2023-06-12 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:57 --> Router Class Initialized
INFO - 2023-06-12 08:48:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:57 --> URI Class Initialized
INFO - 2023-06-12 08:48:57 --> Output Class Initialized
INFO - 2023-06-12 08:48:57 --> Security Class Initialized
INFO - 2023-06-12 08:48:57 --> Router Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:57 --> Input Class Initialized
INFO - 2023-06-12 08:48:57 --> Output Class Initialized
INFO - 2023-06-12 08:48:57 --> Language Class Initialized
INFO - 2023-06-12 08:48:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:57 --> Input Class Initialized
INFO - 2023-06-12 08:48:57 --> Language Class Initialized
INFO - 2023-06-12 08:48:57 --> Loader Class Initialized
INFO - 2023-06-12 08:48:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:57 --> Loader Class Initialized
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:57 --> Total execution time: 0.1072
INFO - 2023-06-12 08:48:57 --> Config Class Initialized
INFO - 2023-06-12 08:48:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:57 --> URI Class Initialized
INFO - 2023-06-12 08:48:57 --> Router Class Initialized
INFO - 2023-06-12 08:48:57 --> Output Class Initialized
INFO - 2023-06-12 08:48:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:57 --> Input Class Initialized
INFO - 2023-06-12 08:48:57 --> Language Class Initialized
INFO - 2023-06-12 08:48:57 --> Loader Class Initialized
INFO - 2023-06-12 08:48:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:57 --> Total execution time: 0.1112
INFO - 2023-06-12 08:48:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:57 --> Total execution time: 0.6863
INFO - 2023-06-12 08:48:57 --> Config Class Initialized
INFO - 2023-06-12 08:48:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:48:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:48:57 --> URI Class Initialized
INFO - 2023-06-12 08:48:57 --> Router Class Initialized
INFO - 2023-06-12 08:48:57 --> Output Class Initialized
INFO - 2023-06-12 08:48:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:48:57 --> Input Class Initialized
INFO - 2023-06-12 08:48:57 --> Language Class Initialized
INFO - 2023-06-12 08:48:57 --> Loader Class Initialized
INFO - 2023-06-12 08:48:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:48:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:48:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:48:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:48:58 --> Final output sent to browser
DEBUG - 2023-06-12 08:48:58 --> Total execution time: 0.5914
INFO - 2023-06-12 08:49:07 --> Config Class Initialized
INFO - 2023-06-12 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:07 --> Config Class Initialized
INFO - 2023-06-12 08:49:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:07 --> URI Class Initialized
DEBUG - 2023-06-12 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:07 --> Router Class Initialized
INFO - 2023-06-12 08:49:07 --> URI Class Initialized
INFO - 2023-06-12 08:49:07 --> Output Class Initialized
INFO - 2023-06-12 08:49:07 --> Router Class Initialized
INFO - 2023-06-12 08:49:07 --> Security Class Initialized
INFO - 2023-06-12 08:49:07 --> Output Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:07 --> Security Class Initialized
INFO - 2023-06-12 08:49:07 --> Input Class Initialized
INFO - 2023-06-12 08:49:07 --> Language Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:07 --> Input Class Initialized
INFO - 2023-06-12 08:49:07 --> Language Class Initialized
INFO - 2023-06-12 08:49:07 --> Loader Class Initialized
INFO - 2023-06-12 08:49:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:07 --> Loader Class Initialized
INFO - 2023-06-12 08:49:07 --> Controller Class Initialized
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:07 --> Total execution time: 0.0932
INFO - 2023-06-12 08:49:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:07 --> Config Class Initialized
INFO - 2023-06-12 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:07 --> URI Class Initialized
INFO - 2023-06-12 08:49:07 --> Router Class Initialized
INFO - 2023-06-12 08:49:07 --> Output Class Initialized
INFO - 2023-06-12 08:49:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:07 --> Input Class Initialized
INFO - 2023-06-12 08:49:07 --> Language Class Initialized
INFO - 2023-06-12 08:49:07 --> Loader Class Initialized
INFO - 2023-06-12 08:49:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:07 --> Total execution time: 0.0844
INFO - 2023-06-12 08:49:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:07 --> Total execution time: 0.7378
INFO - 2023-06-12 08:49:07 --> Config Class Initialized
INFO - 2023-06-12 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:07 --> URI Class Initialized
INFO - 2023-06-12 08:49:07 --> Router Class Initialized
INFO - 2023-06-12 08:49:07 --> Output Class Initialized
INFO - 2023-06-12 08:49:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:07 --> Input Class Initialized
INFO - 2023-06-12 08:49:07 --> Language Class Initialized
INFO - 2023-06-12 08:49:07 --> Loader Class Initialized
INFO - 2023-06-12 08:49:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:08 --> Total execution time: 0.6901
INFO - 2023-06-12 08:49:17 --> Config Class Initialized
INFO - 2023-06-12 08:49:17 --> Config Class Initialized
INFO - 2023-06-12 08:49:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:17 --> URI Class Initialized
INFO - 2023-06-12 08:49:17 --> URI Class Initialized
INFO - 2023-06-12 08:49:17 --> Router Class Initialized
INFO - 2023-06-12 08:49:17 --> Router Class Initialized
INFO - 2023-06-12 08:49:17 --> Output Class Initialized
INFO - 2023-06-12 08:49:17 --> Output Class Initialized
INFO - 2023-06-12 08:49:17 --> Security Class Initialized
INFO - 2023-06-12 08:49:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:17 --> Input Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:17 --> Language Class Initialized
INFO - 2023-06-12 08:49:17 --> Input Class Initialized
INFO - 2023-06-12 08:49:17 --> Language Class Initialized
INFO - 2023-06-12 08:49:17 --> Loader Class Initialized
INFO - 2023-06-12 08:49:17 --> Controller Class Initialized
INFO - 2023-06-12 08:49:17 --> Loader Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:17 --> Total execution time: 0.1129
INFO - 2023-06-12 08:49:17 --> Config Class Initialized
INFO - 2023-06-12 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:17 --> URI Class Initialized
INFO - 2023-06-12 08:49:17 --> Router Class Initialized
INFO - 2023-06-12 08:49:17 --> Output Class Initialized
INFO - 2023-06-12 08:49:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:17 --> Input Class Initialized
INFO - 2023-06-12 08:49:17 --> Language Class Initialized
INFO - 2023-06-12 08:49:17 --> Loader Class Initialized
INFO - 2023-06-12 08:49:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:17 --> Total execution time: 0.0935
INFO - 2023-06-12 08:49:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:17 --> Total execution time: 0.6987
INFO - 2023-06-12 08:49:17 --> Config Class Initialized
INFO - 2023-06-12 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:17 --> URI Class Initialized
INFO - 2023-06-12 08:49:17 --> Router Class Initialized
INFO - 2023-06-12 08:49:17 --> Output Class Initialized
INFO - 2023-06-12 08:49:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:17 --> Input Class Initialized
INFO - 2023-06-12 08:49:17 --> Language Class Initialized
INFO - 2023-06-12 08:49:17 --> Loader Class Initialized
INFO - 2023-06-12 08:49:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:18 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:18 --> Total execution time: 0.7219
INFO - 2023-06-12 08:49:27 --> Config Class Initialized
INFO - 2023-06-12 08:49:27 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:27 --> Config Class Initialized
INFO - 2023-06-12 08:49:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:27 --> URI Class Initialized
INFO - 2023-06-12 08:49:27 --> Router Class Initialized
DEBUG - 2023-06-12 08:49:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:27 --> Output Class Initialized
INFO - 2023-06-12 08:49:27 --> URI Class Initialized
INFO - 2023-06-12 08:49:27 --> Security Class Initialized
INFO - 2023-06-12 08:49:27 --> Router Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:27 --> Input Class Initialized
INFO - 2023-06-12 08:49:27 --> Output Class Initialized
INFO - 2023-06-12 08:49:27 --> Language Class Initialized
INFO - 2023-06-12 08:49:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:27 --> Input Class Initialized
INFO - 2023-06-12 08:49:27 --> Language Class Initialized
INFO - 2023-06-12 08:49:27 --> Loader Class Initialized
INFO - 2023-06-12 08:49:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:27 --> Loader Class Initialized
INFO - 2023-06-12 08:49:27 --> Controller Class Initialized
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:27 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:27 --> Total execution time: 0.1511
INFO - 2023-06-12 08:49:27 --> Config Class Initialized
INFO - 2023-06-12 08:49:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:27 --> URI Class Initialized
INFO - 2023-06-12 08:49:27 --> Router Class Initialized
INFO - 2023-06-12 08:49:27 --> Output Class Initialized
INFO - 2023-06-12 08:49:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:27 --> Input Class Initialized
INFO - 2023-06-12 08:49:27 --> Language Class Initialized
INFO - 2023-06-12 08:49:27 --> Loader Class Initialized
INFO - 2023-06-12 08:49:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:27 --> Total execution time: 0.1062
INFO - 2023-06-12 08:49:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:27 --> Total execution time: 0.7292
INFO - 2023-06-12 08:49:27 --> Config Class Initialized
INFO - 2023-06-12 08:49:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:27 --> URI Class Initialized
INFO - 2023-06-12 08:49:27 --> Router Class Initialized
INFO - 2023-06-12 08:49:27 --> Output Class Initialized
INFO - 2023-06-12 08:49:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:27 --> Input Class Initialized
INFO - 2023-06-12 08:49:27 --> Language Class Initialized
INFO - 2023-06-12 08:49:27 --> Loader Class Initialized
INFO - 2023-06-12 08:49:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:27 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:28 --> Total execution time: 0.6014
INFO - 2023-06-12 08:49:37 --> Config Class Initialized
INFO - 2023-06-12 08:49:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:37 --> Config Class Initialized
INFO - 2023-06-12 08:49:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:37 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:49:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:37 --> URI Class Initialized
INFO - 2023-06-12 08:49:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:37 --> URI Class Initialized
INFO - 2023-06-12 08:49:37 --> Router Class Initialized
INFO - 2023-06-12 08:49:37 --> Router Class Initialized
INFO - 2023-06-12 08:49:37 --> Output Class Initialized
INFO - 2023-06-12 08:49:37 --> Security Class Initialized
INFO - 2023-06-12 08:49:37 --> Output Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:37 --> Input Class Initialized
INFO - 2023-06-12 08:49:37 --> Security Class Initialized
INFO - 2023-06-12 08:49:37 --> Language Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:37 --> Input Class Initialized
INFO - 2023-06-12 08:49:37 --> Language Class Initialized
INFO - 2023-06-12 08:49:37 --> Loader Class Initialized
INFO - 2023-06-12 08:49:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:37 --> Loader Class Initialized
INFO - 2023-06-12 08:49:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:37 --> Total execution time: 0.0895
INFO - 2023-06-12 08:49:37 --> Config Class Initialized
INFO - 2023-06-12 08:49:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:37 --> Model "Login_model" initialized
DEBUG - 2023-06-12 08:49:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:37 --> URI Class Initialized
INFO - 2023-06-12 08:49:37 --> Router Class Initialized
INFO - 2023-06-12 08:49:37 --> Output Class Initialized
INFO - 2023-06-12 08:49:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:37 --> Input Class Initialized
INFO - 2023-06-12 08:49:37 --> Language Class Initialized
INFO - 2023-06-12 08:49:37 --> Loader Class Initialized
INFO - 2023-06-12 08:49:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:37 --> Total execution time: 0.1046
INFO - 2023-06-12 08:49:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:37 --> Total execution time: 0.7134
INFO - 2023-06-12 08:49:37 --> Config Class Initialized
INFO - 2023-06-12 08:49:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:37 --> URI Class Initialized
INFO - 2023-06-12 08:49:37 --> Router Class Initialized
INFO - 2023-06-12 08:49:37 --> Output Class Initialized
INFO - 2023-06-12 08:49:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:37 --> Input Class Initialized
INFO - 2023-06-12 08:49:37 --> Language Class Initialized
INFO - 2023-06-12 08:49:37 --> Loader Class Initialized
INFO - 2023-06-12 08:49:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:37 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:38 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:38 --> Total execution time: 0.6799
INFO - 2023-06-12 08:49:47 --> Config Class Initialized
INFO - 2023-06-12 08:49:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:47 --> Config Class Initialized
INFO - 2023-06-12 08:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:47 --> URI Class Initialized
DEBUG - 2023-06-12 08:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:47 --> Router Class Initialized
INFO - 2023-06-12 08:49:47 --> URI Class Initialized
INFO - 2023-06-12 08:49:47 --> Output Class Initialized
INFO - 2023-06-12 08:49:47 --> Router Class Initialized
INFO - 2023-06-12 08:49:47 --> Security Class Initialized
INFO - 2023-06-12 08:49:47 --> Output Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:47 --> Input Class Initialized
INFO - 2023-06-12 08:49:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:47 --> Language Class Initialized
INFO - 2023-06-12 08:49:47 --> Input Class Initialized
INFO - 2023-06-12 08:49:47 --> Language Class Initialized
INFO - 2023-06-12 08:49:47 --> Loader Class Initialized
INFO - 2023-06-12 08:49:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:47 --> Loader Class Initialized
INFO - 2023-06-12 08:49:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:47 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:47 --> Total execution time: 0.1027
INFO - 2023-06-12 08:49:47 --> Config Class Initialized
INFO - 2023-06-12 08:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:47 --> URI Class Initialized
INFO - 2023-06-12 08:49:47 --> Router Class Initialized
INFO - 2023-06-12 08:49:47 --> Output Class Initialized
INFO - 2023-06-12 08:49:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:47 --> Input Class Initialized
INFO - 2023-06-12 08:49:47 --> Language Class Initialized
INFO - 2023-06-12 08:49:47 --> Loader Class Initialized
INFO - 2023-06-12 08:49:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:47 --> Total execution time: 0.1048
INFO - 2023-06-12 08:49:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:47 --> Total execution time: 0.6810
INFO - 2023-06-12 08:49:47 --> Config Class Initialized
INFO - 2023-06-12 08:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:47 --> URI Class Initialized
INFO - 2023-06-12 08:49:47 --> Router Class Initialized
INFO - 2023-06-12 08:49:47 --> Output Class Initialized
INFO - 2023-06-12 08:49:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:47 --> Input Class Initialized
INFO - 2023-06-12 08:49:47 --> Language Class Initialized
INFO - 2023-06-12 08:49:47 --> Loader Class Initialized
INFO - 2023-06-12 08:49:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:47 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:48 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:48 --> Total execution time: 0.6844
INFO - 2023-06-12 08:49:57 --> Config Class Initialized
INFO - 2023-06-12 08:49:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:57 --> Config Class Initialized
DEBUG - 2023-06-12 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:49:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:57 --> URI Class Initialized
INFO - 2023-06-12 08:49:57 --> Router Class Initialized
DEBUG - 2023-06-12 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:57 --> URI Class Initialized
INFO - 2023-06-12 08:49:57 --> Output Class Initialized
INFO - 2023-06-12 08:49:57 --> Router Class Initialized
INFO - 2023-06-12 08:49:57 --> Security Class Initialized
INFO - 2023-06-12 08:49:57 --> Output Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:57 --> Input Class Initialized
INFO - 2023-06-12 08:49:57 --> Security Class Initialized
INFO - 2023-06-12 08:49:57 --> Language Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:57 --> Input Class Initialized
INFO - 2023-06-12 08:49:57 --> Language Class Initialized
INFO - 2023-06-12 08:49:57 --> Loader Class Initialized
INFO - 2023-06-12 08:49:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:57 --> Loader Class Initialized
INFO - 2023-06-12 08:49:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:57 --> Total execution time: 0.1088
INFO - 2023-06-12 08:49:57 --> Config Class Initialized
INFO - 2023-06-12 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:57 --> URI Class Initialized
INFO - 2023-06-12 08:49:57 --> Router Class Initialized
INFO - 2023-06-12 08:49:57 --> Output Class Initialized
INFO - 2023-06-12 08:49:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:57 --> Input Class Initialized
INFO - 2023-06-12 08:49:57 --> Language Class Initialized
INFO - 2023-06-12 08:49:57 --> Loader Class Initialized
INFO - 2023-06-12 08:49:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:57 --> Total execution time: 0.0966
INFO - 2023-06-12 08:49:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:57 --> Total execution time: 0.6234
INFO - 2023-06-12 08:49:57 --> Config Class Initialized
INFO - 2023-06-12 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:49:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:49:57 --> URI Class Initialized
INFO - 2023-06-12 08:49:57 --> Router Class Initialized
INFO - 2023-06-12 08:49:57 --> Output Class Initialized
INFO - 2023-06-12 08:49:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:49:57 --> Input Class Initialized
INFO - 2023-06-12 08:49:57 --> Language Class Initialized
INFO - 2023-06-12 08:49:57 --> Loader Class Initialized
INFO - 2023-06-12 08:49:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:49:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:49:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:49:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:49:58 --> Final output sent to browser
DEBUG - 2023-06-12 08:49:58 --> Total execution time: 0.6107
INFO - 2023-06-12 08:50:07 --> Config Class Initialized
INFO - 2023-06-12 08:50:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:07 --> Config Class Initialized
INFO - 2023-06-12 08:50:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:50:07 --> URI Class Initialized
INFO - 2023-06-12 08:50:07 --> Router Class Initialized
DEBUG - 2023-06-12 08:50:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:07 --> Output Class Initialized
INFO - 2023-06-12 08:50:07 --> URI Class Initialized
INFO - 2023-06-12 08:50:07 --> Security Class Initialized
INFO - 2023-06-12 08:50:07 --> Router Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:07 --> Input Class Initialized
INFO - 2023-06-12 08:50:07 --> Output Class Initialized
INFO - 2023-06-12 08:50:07 --> Language Class Initialized
INFO - 2023-06-12 08:50:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:07 --> Input Class Initialized
INFO - 2023-06-12 08:50:07 --> Language Class Initialized
INFO - 2023-06-12 08:50:07 --> Loader Class Initialized
INFO - 2023-06-12 08:50:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:07 --> Loader Class Initialized
INFO - 2023-06-12 08:50:07 --> Controller Class Initialized
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:07 --> Total execution time: 0.0951
INFO - 2023-06-12 08:50:07 --> Config Class Initialized
INFO - 2023-06-12 08:50:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:07 --> URI Class Initialized
INFO - 2023-06-12 08:50:07 --> Router Class Initialized
INFO - 2023-06-12 08:50:07 --> Output Class Initialized
INFO - 2023-06-12 08:50:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:07 --> Input Class Initialized
INFO - 2023-06-12 08:50:07 --> Language Class Initialized
INFO - 2023-06-12 08:50:07 --> Loader Class Initialized
INFO - 2023-06-12 08:50:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:07 --> Total execution time: 0.0928
INFO - 2023-06-12 08:50:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:07 --> Total execution time: 0.6002
INFO - 2023-06-12 08:50:07 --> Config Class Initialized
INFO - 2023-06-12 08:50:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:07 --> URI Class Initialized
INFO - 2023-06-12 08:50:07 --> Router Class Initialized
INFO - 2023-06-12 08:50:07 --> Output Class Initialized
INFO - 2023-06-12 08:50:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:07 --> Input Class Initialized
INFO - 2023-06-12 08:50:07 --> Language Class Initialized
INFO - 2023-06-12 08:50:07 --> Loader Class Initialized
INFO - 2023-06-12 08:50:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:08 --> Total execution time: 0.6771
INFO - 2023-06-12 08:50:17 --> Config Class Initialized
INFO - 2023-06-12 08:50:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:17 --> Config Class Initialized
INFO - 2023-06-12 08:50:17 --> Hooks Class Initialized
INFO - 2023-06-12 08:50:17 --> URI Class Initialized
INFO - 2023-06-12 08:50:17 --> Router Class Initialized
DEBUG - 2023-06-12 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:17 --> Output Class Initialized
INFO - 2023-06-12 08:50:17 --> URI Class Initialized
INFO - 2023-06-12 08:50:17 --> Security Class Initialized
INFO - 2023-06-12 08:50:17 --> Router Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:17 --> Input Class Initialized
INFO - 2023-06-12 08:50:17 --> Language Class Initialized
INFO - 2023-06-12 08:50:17 --> Output Class Initialized
INFO - 2023-06-12 08:50:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:17 --> Input Class Initialized
INFO - 2023-06-12 08:50:17 --> Loader Class Initialized
INFO - 2023-06-12 08:50:17 --> Language Class Initialized
INFO - 2023-06-12 08:50:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:17 --> Loader Class Initialized
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:17 --> Total execution time: 0.0946
INFO - 2023-06-12 08:50:17 --> Config Class Initialized
INFO - 2023-06-12 08:50:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:17 --> URI Class Initialized
INFO - 2023-06-12 08:50:17 --> Router Class Initialized
INFO - 2023-06-12 08:50:17 --> Output Class Initialized
INFO - 2023-06-12 08:50:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:17 --> Input Class Initialized
INFO - 2023-06-12 08:50:17 --> Language Class Initialized
INFO - 2023-06-12 08:50:17 --> Loader Class Initialized
INFO - 2023-06-12 08:50:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:17 --> Total execution time: 0.1156
INFO - 2023-06-12 08:50:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:17 --> Total execution time: 0.6518
INFO - 2023-06-12 08:50:17 --> Config Class Initialized
INFO - 2023-06-12 08:50:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:17 --> URI Class Initialized
INFO - 2023-06-12 08:50:17 --> Router Class Initialized
INFO - 2023-06-12 08:50:17 --> Output Class Initialized
INFO - 2023-06-12 08:50:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:17 --> Input Class Initialized
INFO - 2023-06-12 08:50:17 --> Language Class Initialized
INFO - 2023-06-12 08:50:17 --> Loader Class Initialized
INFO - 2023-06-12 08:50:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:17 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:18 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:18 --> Total execution time: 0.6589
INFO - 2023-06-12 08:50:27 --> Config Class Initialized
INFO - 2023-06-12 08:50:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:27 --> URI Class Initialized
INFO - 2023-06-12 08:50:27 --> Config Class Initialized
INFO - 2023-06-12 08:50:27 --> Hooks Class Initialized
INFO - 2023-06-12 08:50:27 --> Router Class Initialized
INFO - 2023-06-12 08:50:27 --> Output Class Initialized
DEBUG - 2023-06-12 08:50:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:27 --> Security Class Initialized
INFO - 2023-06-12 08:50:27 --> URI Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:27 --> Input Class Initialized
INFO - 2023-06-12 08:50:27 --> Language Class Initialized
INFO - 2023-06-12 08:50:27 --> Router Class Initialized
INFO - 2023-06-12 08:50:27 --> Output Class Initialized
INFO - 2023-06-12 08:50:27 --> Loader Class Initialized
INFO - 2023-06-12 08:50:27 --> Security Class Initialized
INFO - 2023-06-12 08:50:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:27 --> Input Class Initialized
INFO - 2023-06-12 08:50:27 --> Language Class Initialized
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Loader Class Initialized
INFO - 2023-06-12 08:50:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:27 --> Total execution time: 0.1068
INFO - 2023-06-12 08:50:27 --> Config Class Initialized
INFO - 2023-06-12 08:50:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:27 --> URI Class Initialized
INFO - 2023-06-12 08:50:27 --> Router Class Initialized
INFO - 2023-06-12 08:50:27 --> Output Class Initialized
INFO - 2023-06-12 08:50:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:27 --> Input Class Initialized
INFO - 2023-06-12 08:50:27 --> Language Class Initialized
INFO - 2023-06-12 08:50:27 --> Loader Class Initialized
INFO - 2023-06-12 08:50:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:27 --> Total execution time: 0.1497
INFO - 2023-06-12 08:50:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:27 --> Total execution time: 0.7318
INFO - 2023-06-12 08:50:27 --> Config Class Initialized
INFO - 2023-06-12 08:50:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:27 --> URI Class Initialized
INFO - 2023-06-12 08:50:27 --> Router Class Initialized
INFO - 2023-06-12 08:50:27 --> Output Class Initialized
INFO - 2023-06-12 08:50:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:27 --> Input Class Initialized
INFO - 2023-06-12 08:50:27 --> Language Class Initialized
INFO - 2023-06-12 08:50:27 --> Loader Class Initialized
INFO - 2023-06-12 08:50:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:27 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:28 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:28 --> Total execution time: 0.6568
INFO - 2023-06-12 08:50:37 --> Config Class Initialized
INFO - 2023-06-12 08:50:37 --> Hooks Class Initialized
INFO - 2023-06-12 08:50:37 --> Config Class Initialized
INFO - 2023-06-12 08:50:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:37 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:50:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:37 --> URI Class Initialized
INFO - 2023-06-12 08:50:37 --> URI Class Initialized
INFO - 2023-06-12 08:50:37 --> Router Class Initialized
INFO - 2023-06-12 08:50:37 --> Router Class Initialized
INFO - 2023-06-12 08:50:37 --> Output Class Initialized
INFO - 2023-06-12 08:50:37 --> Security Class Initialized
INFO - 2023-06-12 08:50:37 --> Output Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:37 --> Security Class Initialized
INFO - 2023-06-12 08:50:37 --> Input Class Initialized
INFO - 2023-06-12 08:50:37 --> Language Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:37 --> Input Class Initialized
INFO - 2023-06-12 08:50:37 --> Language Class Initialized
INFO - 2023-06-12 08:50:37 --> Loader Class Initialized
INFO - 2023-06-12 08:50:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:37 --> Loader Class Initialized
INFO - 2023-06-12 08:50:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:37 --> Total execution time: 0.1102
INFO - 2023-06-12 08:50:37 --> Config Class Initialized
INFO - 2023-06-12 08:50:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:37 --> URI Class Initialized
INFO - 2023-06-12 08:50:37 --> Router Class Initialized
INFO - 2023-06-12 08:50:37 --> Output Class Initialized
INFO - 2023-06-12 08:50:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:37 --> Input Class Initialized
INFO - 2023-06-12 08:50:37 --> Language Class Initialized
INFO - 2023-06-12 08:50:37 --> Loader Class Initialized
INFO - 2023-06-12 08:50:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:37 --> Total execution time: 0.1416
INFO - 2023-06-12 08:50:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:37 --> Total execution time: 0.8160
INFO - 2023-06-12 08:50:37 --> Config Class Initialized
INFO - 2023-06-12 08:50:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:37 --> URI Class Initialized
INFO - 2023-06-12 08:50:37 --> Router Class Initialized
INFO - 2023-06-12 08:50:37 --> Output Class Initialized
INFO - 2023-06-12 08:50:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:37 --> Input Class Initialized
INFO - 2023-06-12 08:50:37 --> Language Class Initialized
INFO - 2023-06-12 08:50:37 --> Loader Class Initialized
INFO - 2023-06-12 08:50:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:37 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:38 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:38 --> Total execution time: 0.6507
INFO - 2023-06-12 08:50:47 --> Config Class Initialized
INFO - 2023-06-12 08:50:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:47 --> URI Class Initialized
INFO - 2023-06-12 08:50:47 --> Router Class Initialized
INFO - 2023-06-12 08:50:47 --> Output Class Initialized
INFO - 2023-06-12 08:50:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:47 --> Input Class Initialized
INFO - 2023-06-12 08:50:47 --> Language Class Initialized
INFO - 2023-06-12 08:50:47 --> Loader Class Initialized
INFO - 2023-06-12 08:50:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:47 --> Total execution time: 0.0909
INFO - 2023-06-12 08:50:47 --> Config Class Initialized
INFO - 2023-06-12 08:50:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:47 --> URI Class Initialized
INFO - 2023-06-12 08:50:47 --> Router Class Initialized
INFO - 2023-06-12 08:50:47 --> Output Class Initialized
INFO - 2023-06-12 08:50:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:47 --> Input Class Initialized
INFO - 2023-06-12 08:50:47 --> Language Class Initialized
INFO - 2023-06-12 08:50:47 --> Loader Class Initialized
INFO - 2023-06-12 08:50:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:47 --> Total execution time: 0.0923
INFO - 2023-06-12 08:50:48 --> Config Class Initialized
INFO - 2023-06-12 08:50:48 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:48 --> URI Class Initialized
INFO - 2023-06-12 08:50:48 --> Router Class Initialized
INFO - 2023-06-12 08:50:48 --> Output Class Initialized
INFO - 2023-06-12 08:50:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:48 --> Input Class Initialized
INFO - 2023-06-12 08:50:48 --> Language Class Initialized
INFO - 2023-06-12 08:50:48 --> Loader Class Initialized
INFO - 2023-06-12 08:50:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:48 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:49 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:49 --> Total execution time: 0.7576
INFO - 2023-06-12 08:50:49 --> Config Class Initialized
INFO - 2023-06-12 08:50:49 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:49 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:49 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:49 --> URI Class Initialized
INFO - 2023-06-12 08:50:49 --> Router Class Initialized
INFO - 2023-06-12 08:50:49 --> Output Class Initialized
INFO - 2023-06-12 08:50:49 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:49 --> Input Class Initialized
INFO - 2023-06-12 08:50:49 --> Language Class Initialized
INFO - 2023-06-12 08:50:49 --> Loader Class Initialized
INFO - 2023-06-12 08:50:49 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:49 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:49 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:49 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:49 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:49 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:49 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:49 --> Total execution time: 0.6492
INFO - 2023-06-12 08:50:57 --> Config Class Initialized
INFO - 2023-06-12 08:50:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:57 --> URI Class Initialized
INFO - 2023-06-12 08:50:57 --> Router Class Initialized
INFO - 2023-06-12 08:50:57 --> Output Class Initialized
INFO - 2023-06-12 08:50:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:57 --> Input Class Initialized
INFO - 2023-06-12 08:50:57 --> Language Class Initialized
INFO - 2023-06-12 08:50:57 --> Loader Class Initialized
INFO - 2023-06-12 08:50:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:57 --> Total execution time: 0.0996
INFO - 2023-06-12 08:50:57 --> Config Class Initialized
INFO - 2023-06-12 08:50:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:57 --> URI Class Initialized
INFO - 2023-06-12 08:50:57 --> Router Class Initialized
INFO - 2023-06-12 08:50:57 --> Output Class Initialized
INFO - 2023-06-12 08:50:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:57 --> Input Class Initialized
INFO - 2023-06-12 08:50:57 --> Language Class Initialized
INFO - 2023-06-12 08:50:57 --> Loader Class Initialized
INFO - 2023-06-12 08:50:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:57 --> Total execution time: 0.0886
INFO - 2023-06-12 08:50:58 --> Config Class Initialized
INFO - 2023-06-12 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:58 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:58 --> URI Class Initialized
INFO - 2023-06-12 08:50:58 --> Router Class Initialized
INFO - 2023-06-12 08:50:58 --> Output Class Initialized
INFO - 2023-06-12 08:50:58 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:58 --> Input Class Initialized
INFO - 2023-06-12 08:50:58 --> Language Class Initialized
INFO - 2023-06-12 08:50:58 --> Loader Class Initialized
INFO - 2023-06-12 08:50:58 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:58 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:58 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:58 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:58 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:58 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:58 --> Total execution time: 0.6324
INFO - 2023-06-12 08:50:58 --> Config Class Initialized
INFO - 2023-06-12 08:50:58 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:50:58 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:50:58 --> Utf8 Class Initialized
INFO - 2023-06-12 08:50:58 --> URI Class Initialized
INFO - 2023-06-12 08:50:58 --> Router Class Initialized
INFO - 2023-06-12 08:50:58 --> Output Class Initialized
INFO - 2023-06-12 08:50:58 --> Security Class Initialized
DEBUG - 2023-06-12 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:50:58 --> Input Class Initialized
INFO - 2023-06-12 08:50:58 --> Language Class Initialized
INFO - 2023-06-12 08:50:58 --> Loader Class Initialized
INFO - 2023-06-12 08:50:58 --> Controller Class Initialized
DEBUG - 2023-06-12 08:50:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:50:58 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:50:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:50:59 --> Model "Login_model" initialized
INFO - 2023-06-12 08:50:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:50:59 --> Total execution time: 0.6088
INFO - 2023-06-12 08:51:07 --> Config Class Initialized
INFO - 2023-06-12 08:51:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:07 --> URI Class Initialized
INFO - 2023-06-12 08:51:07 --> Router Class Initialized
INFO - 2023-06-12 08:51:07 --> Output Class Initialized
INFO - 2023-06-12 08:51:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:07 --> Input Class Initialized
INFO - 2023-06-12 08:51:07 --> Language Class Initialized
INFO - 2023-06-12 08:51:07 --> Loader Class Initialized
INFO - 2023-06-12 08:51:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:07 --> Total execution time: 0.1033
INFO - 2023-06-12 08:51:07 --> Config Class Initialized
INFO - 2023-06-12 08:51:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:07 --> URI Class Initialized
INFO - 2023-06-12 08:51:07 --> Router Class Initialized
INFO - 2023-06-12 08:51:07 --> Output Class Initialized
INFO - 2023-06-12 08:51:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:07 --> Input Class Initialized
INFO - 2023-06-12 08:51:07 --> Language Class Initialized
INFO - 2023-06-12 08:51:07 --> Loader Class Initialized
INFO - 2023-06-12 08:51:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:07 --> Total execution time: 0.1001
INFO - 2023-06-12 08:51:08 --> Config Class Initialized
INFO - 2023-06-12 08:51:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:08 --> URI Class Initialized
INFO - 2023-06-12 08:51:08 --> Router Class Initialized
INFO - 2023-06-12 08:51:08 --> Output Class Initialized
INFO - 2023-06-12 08:51:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:08 --> Input Class Initialized
INFO - 2023-06-12 08:51:08 --> Language Class Initialized
INFO - 2023-06-12 08:51:08 --> Loader Class Initialized
INFO - 2023-06-12 08:51:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:08 --> Total execution time: 0.6442
INFO - 2023-06-12 08:51:08 --> Config Class Initialized
INFO - 2023-06-12 08:51:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:08 --> URI Class Initialized
INFO - 2023-06-12 08:51:08 --> Router Class Initialized
INFO - 2023-06-12 08:51:08 --> Output Class Initialized
INFO - 2023-06-12 08:51:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:08 --> Input Class Initialized
INFO - 2023-06-12 08:51:08 --> Language Class Initialized
INFO - 2023-06-12 08:51:08 --> Loader Class Initialized
INFO - 2023-06-12 08:51:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:09 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:09 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:09 --> Total execution time: 0.6552
INFO - 2023-06-12 08:51:17 --> Config Class Initialized
INFO - 2023-06-12 08:51:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:17 --> URI Class Initialized
INFO - 2023-06-12 08:51:17 --> Router Class Initialized
INFO - 2023-06-12 08:51:17 --> Output Class Initialized
INFO - 2023-06-12 08:51:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:17 --> Input Class Initialized
INFO - 2023-06-12 08:51:17 --> Language Class Initialized
INFO - 2023-06-12 08:51:17 --> Loader Class Initialized
INFO - 2023-06-12 08:51:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:17 --> Total execution time: 0.1412
INFO - 2023-06-12 08:51:17 --> Config Class Initialized
INFO - 2023-06-12 08:51:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:17 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:17 --> URI Class Initialized
INFO - 2023-06-12 08:51:17 --> Router Class Initialized
INFO - 2023-06-12 08:51:17 --> Output Class Initialized
INFO - 2023-06-12 08:51:17 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:17 --> Input Class Initialized
INFO - 2023-06-12 08:51:17 --> Language Class Initialized
INFO - 2023-06-12 08:51:17 --> Loader Class Initialized
INFO - 2023-06-12 08:51:17 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:17 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:17 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:17 --> Total execution time: 0.1262
INFO - 2023-06-12 08:51:18 --> Config Class Initialized
INFO - 2023-06-12 08:51:18 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:18 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:18 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:18 --> URI Class Initialized
INFO - 2023-06-12 08:51:18 --> Router Class Initialized
INFO - 2023-06-12 08:51:18 --> Output Class Initialized
INFO - 2023-06-12 08:51:18 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:18 --> Input Class Initialized
INFO - 2023-06-12 08:51:18 --> Language Class Initialized
INFO - 2023-06-12 08:51:18 --> Loader Class Initialized
INFO - 2023-06-12 08:51:18 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:18 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:18 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:18 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:18 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:18 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:19 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:19 --> Total execution time: 0.8895
INFO - 2023-06-12 08:51:19 --> Config Class Initialized
INFO - 2023-06-12 08:51:19 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:19 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:19 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:19 --> URI Class Initialized
INFO - 2023-06-12 08:51:19 --> Router Class Initialized
INFO - 2023-06-12 08:51:19 --> Output Class Initialized
INFO - 2023-06-12 08:51:19 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:19 --> Input Class Initialized
INFO - 2023-06-12 08:51:19 --> Language Class Initialized
INFO - 2023-06-12 08:51:19 --> Loader Class Initialized
INFO - 2023-06-12 08:51:19 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:19 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:19 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:19 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:19 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:19 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:19 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:19 --> Total execution time: 0.7314
INFO - 2023-06-12 08:51:27 --> Config Class Initialized
INFO - 2023-06-12 08:51:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:27 --> URI Class Initialized
INFO - 2023-06-12 08:51:27 --> Router Class Initialized
INFO - 2023-06-12 08:51:27 --> Output Class Initialized
INFO - 2023-06-12 08:51:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:27 --> Input Class Initialized
INFO - 2023-06-12 08:51:27 --> Language Class Initialized
INFO - 2023-06-12 08:51:27 --> Loader Class Initialized
INFO - 2023-06-12 08:51:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:27 --> Total execution time: 0.0829
INFO - 2023-06-12 08:51:27 --> Config Class Initialized
INFO - 2023-06-12 08:51:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:27 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:27 --> URI Class Initialized
INFO - 2023-06-12 08:51:27 --> Router Class Initialized
INFO - 2023-06-12 08:51:27 --> Output Class Initialized
INFO - 2023-06-12 08:51:27 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:27 --> Input Class Initialized
INFO - 2023-06-12 08:51:27 --> Language Class Initialized
INFO - 2023-06-12 08:51:27 --> Loader Class Initialized
INFO - 2023-06-12 08:51:27 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:27 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:27 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:27 --> Total execution time: 0.0987
INFO - 2023-06-12 08:51:28 --> Config Class Initialized
INFO - 2023-06-12 08:51:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:28 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:28 --> URI Class Initialized
INFO - 2023-06-12 08:51:28 --> Router Class Initialized
INFO - 2023-06-12 08:51:28 --> Output Class Initialized
INFO - 2023-06-12 08:51:28 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:28 --> Input Class Initialized
INFO - 2023-06-12 08:51:28 --> Language Class Initialized
INFO - 2023-06-12 08:51:28 --> Loader Class Initialized
INFO - 2023-06-12 08:51:28 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:28 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:28 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:29 --> Total execution time: 0.7090
INFO - 2023-06-12 08:51:29 --> Config Class Initialized
INFO - 2023-06-12 08:51:29 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:29 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:29 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:29 --> URI Class Initialized
INFO - 2023-06-12 08:51:29 --> Router Class Initialized
INFO - 2023-06-12 08:51:29 --> Output Class Initialized
INFO - 2023-06-12 08:51:29 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:29 --> Input Class Initialized
INFO - 2023-06-12 08:51:29 --> Language Class Initialized
INFO - 2023-06-12 08:51:29 --> Loader Class Initialized
INFO - 2023-06-12 08:51:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:29 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:29 --> Total execution time: 0.6088
INFO - 2023-06-12 08:51:37 --> Config Class Initialized
INFO - 2023-06-12 08:51:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:37 --> URI Class Initialized
INFO - 2023-06-12 08:51:37 --> Router Class Initialized
INFO - 2023-06-12 08:51:37 --> Output Class Initialized
INFO - 2023-06-12 08:51:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:37 --> Input Class Initialized
INFO - 2023-06-12 08:51:37 --> Language Class Initialized
INFO - 2023-06-12 08:51:37 --> Loader Class Initialized
INFO - 2023-06-12 08:51:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:37 --> Total execution time: 0.1085
INFO - 2023-06-12 08:51:37 --> Config Class Initialized
INFO - 2023-06-12 08:51:37 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:37 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:37 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:37 --> URI Class Initialized
INFO - 2023-06-12 08:51:37 --> Router Class Initialized
INFO - 2023-06-12 08:51:37 --> Output Class Initialized
INFO - 2023-06-12 08:51:37 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:37 --> Input Class Initialized
INFO - 2023-06-12 08:51:37 --> Language Class Initialized
INFO - 2023-06-12 08:51:37 --> Loader Class Initialized
INFO - 2023-06-12 08:51:37 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:37 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:37 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:37 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:37 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:37 --> Total execution time: 0.1137
INFO - 2023-06-12 08:51:38 --> Config Class Initialized
INFO - 2023-06-12 08:51:38 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:38 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:38 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:38 --> URI Class Initialized
INFO - 2023-06-12 08:51:38 --> Router Class Initialized
INFO - 2023-06-12 08:51:38 --> Output Class Initialized
INFO - 2023-06-12 08:51:38 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:38 --> Input Class Initialized
INFO - 2023-06-12 08:51:38 --> Language Class Initialized
INFO - 2023-06-12 08:51:38 --> Loader Class Initialized
INFO - 2023-06-12 08:51:38 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:38 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:38 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:38 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:38 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:38 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:39 --> Total execution time: 0.8827
INFO - 2023-06-12 08:51:39 --> Config Class Initialized
INFO - 2023-06-12 08:51:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:39 --> URI Class Initialized
INFO - 2023-06-12 08:51:39 --> Router Class Initialized
INFO - 2023-06-12 08:51:39 --> Output Class Initialized
INFO - 2023-06-12 08:51:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:39 --> Input Class Initialized
INFO - 2023-06-12 08:51:39 --> Language Class Initialized
INFO - 2023-06-12 08:51:39 --> Loader Class Initialized
INFO - 2023-06-12 08:51:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:39 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:39 --> Total execution time: 0.7784
INFO - 2023-06-12 08:51:47 --> Config Class Initialized
INFO - 2023-06-12 08:51:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:47 --> URI Class Initialized
INFO - 2023-06-12 08:51:47 --> Router Class Initialized
INFO - 2023-06-12 08:51:47 --> Output Class Initialized
INFO - 2023-06-12 08:51:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:47 --> Input Class Initialized
INFO - 2023-06-12 08:51:47 --> Language Class Initialized
INFO - 2023-06-12 08:51:47 --> Loader Class Initialized
INFO - 2023-06-12 08:51:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:47 --> Total execution time: 0.0994
INFO - 2023-06-12 08:51:47 --> Config Class Initialized
INFO - 2023-06-12 08:51:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:47 --> URI Class Initialized
INFO - 2023-06-12 08:51:47 --> Router Class Initialized
INFO - 2023-06-12 08:51:47 --> Output Class Initialized
INFO - 2023-06-12 08:51:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:47 --> Input Class Initialized
INFO - 2023-06-12 08:51:47 --> Language Class Initialized
INFO - 2023-06-12 08:51:47 --> Loader Class Initialized
INFO - 2023-06-12 08:51:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:47 --> Total execution time: 0.0983
INFO - 2023-06-12 08:51:48 --> Config Class Initialized
INFO - 2023-06-12 08:51:48 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:48 --> URI Class Initialized
INFO - 2023-06-12 08:51:48 --> Router Class Initialized
INFO - 2023-06-12 08:51:48 --> Output Class Initialized
INFO - 2023-06-12 08:51:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:48 --> Input Class Initialized
INFO - 2023-06-12 08:51:48 --> Language Class Initialized
INFO - 2023-06-12 08:51:48 --> Loader Class Initialized
INFO - 2023-06-12 08:51:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:48 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:48 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:48 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:48 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:48 --> Total execution time: 0.6624
INFO - 2023-06-12 08:51:48 --> Config Class Initialized
INFO - 2023-06-12 08:51:48 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:48 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:48 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:48 --> URI Class Initialized
INFO - 2023-06-12 08:51:48 --> Router Class Initialized
INFO - 2023-06-12 08:51:48 --> Output Class Initialized
INFO - 2023-06-12 08:51:48 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:48 --> Input Class Initialized
INFO - 2023-06-12 08:51:48 --> Language Class Initialized
INFO - 2023-06-12 08:51:48 --> Loader Class Initialized
INFO - 2023-06-12 08:51:48 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:48 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:49 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:49 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:49 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:49 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:49 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:49 --> Total execution time: 0.5569
INFO - 2023-06-12 08:51:57 --> Config Class Initialized
INFO - 2023-06-12 08:51:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:57 --> URI Class Initialized
INFO - 2023-06-12 08:51:57 --> Router Class Initialized
INFO - 2023-06-12 08:51:57 --> Output Class Initialized
INFO - 2023-06-12 08:51:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:57 --> Input Class Initialized
INFO - 2023-06-12 08:51:57 --> Language Class Initialized
INFO - 2023-06-12 08:51:57 --> Loader Class Initialized
INFO - 2023-06-12 08:51:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:57 --> Total execution time: 0.1096
INFO - 2023-06-12 08:51:57 --> Config Class Initialized
INFO - 2023-06-12 08:51:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:57 --> URI Class Initialized
INFO - 2023-06-12 08:51:57 --> Router Class Initialized
INFO - 2023-06-12 08:51:57 --> Output Class Initialized
INFO - 2023-06-12 08:51:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:57 --> Input Class Initialized
INFO - 2023-06-12 08:51:57 --> Language Class Initialized
INFO - 2023-06-12 08:51:57 --> Loader Class Initialized
INFO - 2023-06-12 08:51:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:57 --> Total execution time: 0.1105
INFO - 2023-06-12 08:51:58 --> Config Class Initialized
INFO - 2023-06-12 08:51:58 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:58 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:58 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:58 --> URI Class Initialized
INFO - 2023-06-12 08:51:58 --> Router Class Initialized
INFO - 2023-06-12 08:51:58 --> Output Class Initialized
INFO - 2023-06-12 08:51:58 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:58 --> Input Class Initialized
INFO - 2023-06-12 08:51:58 --> Language Class Initialized
INFO - 2023-06-12 08:51:58 --> Loader Class Initialized
INFO - 2023-06-12 08:51:58 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:58 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:58 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:58 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:58 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:58 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:59 --> Total execution time: 0.7040
INFO - 2023-06-12 08:51:59 --> Config Class Initialized
INFO - 2023-06-12 08:51:59 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:51:59 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:51:59 --> Utf8 Class Initialized
INFO - 2023-06-12 08:51:59 --> URI Class Initialized
INFO - 2023-06-12 08:51:59 --> Router Class Initialized
INFO - 2023-06-12 08:51:59 --> Output Class Initialized
INFO - 2023-06-12 08:51:59 --> Security Class Initialized
DEBUG - 2023-06-12 08:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:51:59 --> Input Class Initialized
INFO - 2023-06-12 08:51:59 --> Language Class Initialized
INFO - 2023-06-12 08:51:59 --> Loader Class Initialized
INFO - 2023-06-12 08:51:59 --> Controller Class Initialized
DEBUG - 2023-06-12 08:51:59 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:51:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:59 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:51:59 --> Database Driver Class Initialized
INFO - 2023-06-12 08:51:59 --> Model "Login_model" initialized
INFO - 2023-06-12 08:51:59 --> Final output sent to browser
DEBUG - 2023-06-12 08:51:59 --> Total execution time: 0.5513
INFO - 2023-06-12 08:52:08 --> Config Class Initialized
INFO - 2023-06-12 08:52:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:52:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:52:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:52:08 --> URI Class Initialized
INFO - 2023-06-12 08:52:08 --> Router Class Initialized
INFO - 2023-06-12 08:52:08 --> Output Class Initialized
INFO - 2023-06-12 08:52:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:52:08 --> Input Class Initialized
INFO - 2023-06-12 08:52:08 --> Language Class Initialized
INFO - 2023-06-12 08:52:08 --> Loader Class Initialized
INFO - 2023-06-12 08:52:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:52:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:52:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:52:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:52:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:52:08 --> Total execution time: 0.1084
INFO - 2023-06-12 08:52:08 --> Config Class Initialized
INFO - 2023-06-12 08:52:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:52:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:52:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:52:08 --> URI Class Initialized
INFO - 2023-06-12 08:52:08 --> Router Class Initialized
INFO - 2023-06-12 08:52:08 --> Output Class Initialized
INFO - 2023-06-12 08:52:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:52:08 --> Input Class Initialized
INFO - 2023-06-12 08:52:08 --> Language Class Initialized
INFO - 2023-06-12 08:52:08 --> Loader Class Initialized
INFO - 2023-06-12 08:52:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:52:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:52:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:52:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:52:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:52:08 --> Total execution time: 0.0990
INFO - 2023-06-12 08:53:08 --> Config Class Initialized
INFO - 2023-06-12 08:53:08 --> Hooks Class Initialized
INFO - 2023-06-12 08:53:08 --> Config Class Initialized
INFO - 2023-06-12 08:53:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:53:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:53:08 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:53:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:53:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:53:08 --> URI Class Initialized
INFO - 2023-06-12 08:53:08 --> URI Class Initialized
INFO - 2023-06-12 08:53:08 --> Router Class Initialized
INFO - 2023-06-12 08:53:08 --> Router Class Initialized
INFO - 2023-06-12 08:53:08 --> Output Class Initialized
INFO - 2023-06-12 08:53:08 --> Output Class Initialized
INFO - 2023-06-12 08:53:08 --> Security Class Initialized
INFO - 2023-06-12 08:53:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:53:08 --> Input Class Initialized
INFO - 2023-06-12 08:53:08 --> Input Class Initialized
INFO - 2023-06-12 08:53:08 --> Language Class Initialized
INFO - 2023-06-12 08:53:08 --> Language Class Initialized
INFO - 2023-06-12 08:53:08 --> Loader Class Initialized
INFO - 2023-06-12 08:53:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:53:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:53:08 --> Loader Class Initialized
INFO - 2023-06-12 08:53:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:53:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:53:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:53:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:53:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:53:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:53:08 --> Total execution time: 0.1211
INFO - 2023-06-12 08:53:08 --> Config Class Initialized
INFO - 2023-06-12 08:53:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:53:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:53:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:53:08 --> URI Class Initialized
INFO - 2023-06-12 08:53:08 --> Router Class Initialized
INFO - 2023-06-12 08:53:08 --> Output Class Initialized
INFO - 2023-06-12 08:53:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:53:08 --> Input Class Initialized
INFO - 2023-06-12 08:53:08 --> Language Class Initialized
INFO - 2023-06-12 08:53:08 --> Loader Class Initialized
INFO - 2023-06-12 08:53:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:53:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:53:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:53:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:53:08 --> Total execution time: 0.1127
INFO - 2023-06-12 08:53:09 --> Final output sent to browser
DEBUG - 2023-06-12 08:53:09 --> Total execution time: 1.4754
INFO - 2023-06-12 08:53:09 --> Config Class Initialized
INFO - 2023-06-12 08:53:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:53:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:53:09 --> Utf8 Class Initialized
INFO - 2023-06-12 08:53:09 --> URI Class Initialized
INFO - 2023-06-12 08:53:09 --> Router Class Initialized
INFO - 2023-06-12 08:53:09 --> Output Class Initialized
INFO - 2023-06-12 08:53:09 --> Security Class Initialized
DEBUG - 2023-06-12 08:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:53:09 --> Input Class Initialized
INFO - 2023-06-12 08:53:09 --> Language Class Initialized
INFO - 2023-06-12 08:53:09 --> Loader Class Initialized
INFO - 2023-06-12 08:53:09 --> Controller Class Initialized
DEBUG - 2023-06-12 08:53:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:53:09 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:53:09 --> Database Driver Class Initialized
INFO - 2023-06-12 08:53:09 --> Model "Login_model" initialized
INFO - 2023-06-12 08:53:10 --> Final output sent to browser
DEBUG - 2023-06-12 08:53:10 --> Total execution time: 1.0021
INFO - 2023-06-12 08:54:08 --> Config Class Initialized
INFO - 2023-06-12 08:54:08 --> Hooks Class Initialized
INFO - 2023-06-12 08:54:08 --> Config Class Initialized
INFO - 2023-06-12 08:54:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:54:08 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:54:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:54:08 --> URI Class Initialized
INFO - 2023-06-12 08:54:08 --> URI Class Initialized
INFO - 2023-06-12 08:54:08 --> Router Class Initialized
INFO - 2023-06-12 08:54:08 --> Router Class Initialized
INFO - 2023-06-12 08:54:08 --> Output Class Initialized
INFO - 2023-06-12 08:54:08 --> Output Class Initialized
INFO - 2023-06-12 08:54:08 --> Security Class Initialized
INFO - 2023-06-12 08:54:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:54:08 --> Input Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:54:08 --> Input Class Initialized
INFO - 2023-06-12 08:54:08 --> Language Class Initialized
INFO - 2023-06-12 08:54:08 --> Language Class Initialized
INFO - 2023-06-12 08:54:08 --> Loader Class Initialized
INFO - 2023-06-12 08:54:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:54:08 --> Loader Class Initialized
INFO - 2023-06-12 08:54:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:54:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:54:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:54:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:54:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:54:08 --> Total execution time: 0.1421
INFO - 2023-06-12 08:54:08 --> Config Class Initialized
INFO - 2023-06-12 08:54:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:54:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:54:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:54:08 --> URI Class Initialized
INFO - 2023-06-12 08:54:08 --> Router Class Initialized
INFO - 2023-06-12 08:54:08 --> Output Class Initialized
INFO - 2023-06-12 08:54:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:54:08 --> Input Class Initialized
INFO - 2023-06-12 08:54:08 --> Language Class Initialized
INFO - 2023-06-12 08:54:08 --> Loader Class Initialized
INFO - 2023-06-12 08:54:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:54:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:54:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:54:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:54:08 --> Total execution time: 0.0973
INFO - 2023-06-12 08:54:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:54:08 --> Total execution time: 0.6922
INFO - 2023-06-12 08:54:09 --> Config Class Initialized
INFO - 2023-06-12 08:54:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:54:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:54:09 --> Utf8 Class Initialized
INFO - 2023-06-12 08:54:09 --> URI Class Initialized
INFO - 2023-06-12 08:54:09 --> Router Class Initialized
INFO - 2023-06-12 08:54:09 --> Output Class Initialized
INFO - 2023-06-12 08:54:09 --> Security Class Initialized
DEBUG - 2023-06-12 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:54:09 --> Input Class Initialized
INFO - 2023-06-12 08:54:09 --> Language Class Initialized
INFO - 2023-06-12 08:54:09 --> Loader Class Initialized
INFO - 2023-06-12 08:54:09 --> Controller Class Initialized
DEBUG - 2023-06-12 08:54:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:54:09 --> Database Driver Class Initialized
INFO - 2023-06-12 08:54:09 --> Model "Login_model" initialized
INFO - 2023-06-12 08:54:09 --> Final output sent to browser
DEBUG - 2023-06-12 08:54:09 --> Total execution time: 0.6150
INFO - 2023-06-12 08:55:08 --> Config Class Initialized
INFO - 2023-06-12 08:55:08 --> Hooks Class Initialized
INFO - 2023-06-12 08:55:08 --> Config Class Initialized
INFO - 2023-06-12 08:55:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:55:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:55:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:55:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:55:08 --> URI Class Initialized
INFO - 2023-06-12 08:55:08 --> URI Class Initialized
INFO - 2023-06-12 08:55:08 --> Router Class Initialized
INFO - 2023-06-12 08:55:08 --> Router Class Initialized
INFO - 2023-06-12 08:55:08 --> Output Class Initialized
INFO - 2023-06-12 08:55:08 --> Output Class Initialized
INFO - 2023-06-12 08:55:08 --> Security Class Initialized
INFO - 2023-06-12 08:55:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:55:08 --> Input Class Initialized
INFO - 2023-06-12 08:55:08 --> Input Class Initialized
INFO - 2023-06-12 08:55:08 --> Language Class Initialized
INFO - 2023-06-12 08:55:08 --> Language Class Initialized
INFO - 2023-06-12 08:55:08 --> Loader Class Initialized
INFO - 2023-06-12 08:55:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:55:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:55:08 --> Loader Class Initialized
INFO - 2023-06-12 08:55:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:55:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:55:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:55:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:55:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:55:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:55:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:55:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:55:08 --> Total execution time: 0.0964
INFO - 2023-06-12 08:55:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:55:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:55:08 --> Total execution time: 0.1031
INFO - 2023-06-12 08:56:08 --> Config Class Initialized
INFO - 2023-06-12 08:56:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:56:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:56:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:56:08 --> Config Class Initialized
INFO - 2023-06-12 08:56:08 --> Hooks Class Initialized
INFO - 2023-06-12 08:56:08 --> URI Class Initialized
INFO - 2023-06-12 08:56:08 --> Router Class Initialized
DEBUG - 2023-06-12 08:56:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:56:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:56:08 --> URI Class Initialized
INFO - 2023-06-12 08:56:08 --> Output Class Initialized
INFO - 2023-06-12 08:56:08 --> Security Class Initialized
INFO - 2023-06-12 08:56:08 --> Router Class Initialized
DEBUG - 2023-06-12 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:56:08 --> Input Class Initialized
INFO - 2023-06-12 08:56:08 --> Language Class Initialized
INFO - 2023-06-12 08:56:08 --> Output Class Initialized
INFO - 2023-06-12 08:56:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:56:08 --> Input Class Initialized
INFO - 2023-06-12 08:56:08 --> Language Class Initialized
INFO - 2023-06-12 08:56:08 --> Loader Class Initialized
INFO - 2023-06-12 08:56:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:56:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:56:08 --> Loader Class Initialized
INFO - 2023-06-12 08:56:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:56:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:56:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:56:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:56:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:56:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:56:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:56:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:56:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:56:08 --> Total execution time: 0.1030
INFO - 2023-06-12 08:56:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:56:08 --> Total execution time: 0.1049
INFO - 2023-06-12 08:57:08 --> Config Class Initialized
INFO - 2023-06-12 08:57:08 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:57:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:08 --> Config Class Initialized
INFO - 2023-06-12 08:57:08 --> URI Class Initialized
INFO - 2023-06-12 08:57:08 --> Hooks Class Initialized
INFO - 2023-06-12 08:57:08 --> Router Class Initialized
DEBUG - 2023-06-12 08:57:08 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:08 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:08 --> Output Class Initialized
INFO - 2023-06-12 08:57:08 --> URI Class Initialized
INFO - 2023-06-12 08:57:08 --> Security Class Initialized
INFO - 2023-06-12 08:57:08 --> Router Class Initialized
DEBUG - 2023-06-12 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:08 --> Input Class Initialized
INFO - 2023-06-12 08:57:08 --> Output Class Initialized
INFO - 2023-06-12 08:57:08 --> Language Class Initialized
INFO - 2023-06-12 08:57:08 --> Security Class Initialized
DEBUG - 2023-06-12 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:08 --> Input Class Initialized
INFO - 2023-06-12 08:57:08 --> Language Class Initialized
INFO - 2023-06-12 08:57:08 --> Loader Class Initialized
INFO - 2023-06-12 08:57:08 --> Loader Class Initialized
INFO - 2023-06-12 08:57:08 --> Controller Class Initialized
INFO - 2023-06-12 08:57:08 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:57:08 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:08 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:08 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:08 --> Model "Login_model" initialized
INFO - 2023-06-12 08:57:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:08 --> Total execution time: 0.0757
INFO - 2023-06-12 08:57:08 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:08 --> Total execution time: 0.0836
INFO - 2023-06-12 08:57:39 --> Config Class Initialized
INFO - 2023-06-12 08:57:39 --> Hooks Class Initialized
INFO - 2023-06-12 08:57:39 --> Config Class Initialized
INFO - 2023-06-12 08:57:39 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:57:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:39 --> URI Class Initialized
DEBUG - 2023-06-12 08:57:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:39 --> Router Class Initialized
INFO - 2023-06-12 08:57:39 --> URI Class Initialized
INFO - 2023-06-12 08:57:39 --> Output Class Initialized
INFO - 2023-06-12 08:57:39 --> Router Class Initialized
INFO - 2023-06-12 08:57:39 --> Security Class Initialized
INFO - 2023-06-12 08:57:39 --> Output Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:39 --> Input Class Initialized
INFO - 2023-06-12 08:57:39 --> Security Class Initialized
INFO - 2023-06-12 08:57:39 --> Language Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:39 --> Input Class Initialized
INFO - 2023-06-12 08:57:39 --> Language Class Initialized
INFO - 2023-06-12 08:57:39 --> Loader Class Initialized
INFO - 2023-06-12 08:57:39 --> Loader Class Initialized
INFO - 2023-06-12 08:57:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:39 --> Model "Login_model" initialized
INFO - 2023-06-12 08:57:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:39 --> Total execution time: 0.1296
INFO - 2023-06-12 08:57:39 --> Config Class Initialized
INFO - 2023-06-12 08:57:39 --> Hooks Class Initialized
INFO - 2023-06-12 08:57:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:39 --> Total execution time: 0.1405
DEBUG - 2023-06-12 08:57:39 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:39 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:39 --> URI Class Initialized
INFO - 2023-06-12 08:57:39 --> Router Class Initialized
INFO - 2023-06-12 08:57:39 --> Output Class Initialized
INFO - 2023-06-12 08:57:39 --> Security Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:39 --> Input Class Initialized
INFO - 2023-06-12 08:57:39 --> Language Class Initialized
INFO - 2023-06-12 08:57:39 --> Loader Class Initialized
INFO - 2023-06-12 08:57:39 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:39 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:39 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:39 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:39 --> Model "Login_model" initialized
INFO - 2023-06-12 08:57:39 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:39 --> Total execution time: 0.1096
INFO - 2023-06-12 08:57:47 --> Config Class Initialized
INFO - 2023-06-12 08:57:47 --> Hooks Class Initialized
INFO - 2023-06-12 08:57:47 --> Config Class Initialized
INFO - 2023-06-12 08:57:47 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:57:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:47 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:57:47 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:47 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:47 --> URI Class Initialized
INFO - 2023-06-12 08:57:47 --> URI Class Initialized
INFO - 2023-06-12 08:57:47 --> Router Class Initialized
INFO - 2023-06-12 08:57:47 --> Router Class Initialized
INFO - 2023-06-12 08:57:47 --> Output Class Initialized
INFO - 2023-06-12 08:57:47 --> Output Class Initialized
INFO - 2023-06-12 08:57:47 --> Security Class Initialized
INFO - 2023-06-12 08:57:47 --> Security Class Initialized
DEBUG - 2023-06-12 08:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:47 --> Input Class Initialized
INFO - 2023-06-12 08:57:47 --> Input Class Initialized
INFO - 2023-06-12 08:57:47 --> Language Class Initialized
INFO - 2023-06-12 08:57:47 --> Language Class Initialized
INFO - 2023-06-12 08:57:47 --> Loader Class Initialized
INFO - 2023-06-12 08:57:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:47 --> Loader Class Initialized
INFO - 2023-06-12 08:57:47 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:47 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:47 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:47 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:47 --> Model "Login_model" initialized
INFO - 2023-06-12 08:57:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:47 --> Total execution time: 0.1049
INFO - 2023-06-12 08:57:47 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:47 --> Total execution time: 0.1268
INFO - 2023-06-12 08:57:57 --> Config Class Initialized
INFO - 2023-06-12 08:57:57 --> Hooks Class Initialized
INFO - 2023-06-12 08:57:57 --> Config Class Initialized
INFO - 2023-06-12 08:57:57 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 08:57:57 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:57:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:57 --> Utf8 Class Initialized
INFO - 2023-06-12 08:57:57 --> URI Class Initialized
INFO - 2023-06-12 08:57:57 --> URI Class Initialized
INFO - 2023-06-12 08:57:57 --> Router Class Initialized
INFO - 2023-06-12 08:57:57 --> Router Class Initialized
INFO - 2023-06-12 08:57:57 --> Output Class Initialized
INFO - 2023-06-12 08:57:57 --> Output Class Initialized
INFO - 2023-06-12 08:57:57 --> Security Class Initialized
INFO - 2023-06-12 08:57:57 --> Security Class Initialized
DEBUG - 2023-06-12 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:57 --> Input Class Initialized
DEBUG - 2023-06-12 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:57:57 --> Input Class Initialized
INFO - 2023-06-12 08:57:57 --> Language Class Initialized
INFO - 2023-06-12 08:57:57 --> Language Class Initialized
INFO - 2023-06-12 08:57:57 --> Loader Class Initialized
INFO - 2023-06-12 08:57:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:57 --> Loader Class Initialized
INFO - 2023-06-12 08:57:57 --> Controller Class Initialized
DEBUG - 2023-06-12 08:57:57 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:57:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:57 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:57:57 --> Database Driver Class Initialized
INFO - 2023-06-12 08:57:57 --> Model "Login_model" initialized
INFO - 2023-06-12 08:57:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:57 --> Total execution time: 0.0810
INFO - 2023-06-12 08:57:57 --> Final output sent to browser
DEBUG - 2023-06-12 08:57:57 --> Total execution time: 0.0876
INFO - 2023-06-12 08:58:07 --> Config Class Initialized
INFO - 2023-06-12 08:58:07 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:07 --> Config Class Initialized
INFO - 2023-06-12 08:58:07 --> Hooks Class Initialized
INFO - 2023-06-12 08:58:07 --> URI Class Initialized
INFO - 2023-06-12 08:58:07 --> Router Class Initialized
DEBUG - 2023-06-12 08:58:07 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:07 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:07 --> Output Class Initialized
INFO - 2023-06-12 08:58:07 --> URI Class Initialized
INFO - 2023-06-12 08:58:07 --> Security Class Initialized
INFO - 2023-06-12 08:58:07 --> Router Class Initialized
DEBUG - 2023-06-12 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:07 --> Input Class Initialized
INFO - 2023-06-12 08:58:07 --> Output Class Initialized
INFO - 2023-06-12 08:58:07 --> Language Class Initialized
INFO - 2023-06-12 08:58:07 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:07 --> Input Class Initialized
INFO - 2023-06-12 08:58:07 --> Loader Class Initialized
INFO - 2023-06-12 08:58:07 --> Language Class Initialized
INFO - 2023-06-12 08:58:07 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:07 --> Loader Class Initialized
INFO - 2023-06-12 08:58:07 --> Controller Class Initialized
INFO - 2023-06-12 08:58:07 --> Database Driver Class Initialized
DEBUG - 2023-06-12 08:58:07 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:07 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:07 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:07 --> Model "Login_model" initialized
INFO - 2023-06-12 08:58:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:07 --> Total execution time: 0.0905
INFO - 2023-06-12 08:58:07 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:07 --> Total execution time: 0.1186
INFO - 2023-06-12 08:58:15 --> Config Class Initialized
INFO - 2023-06-12 08:58:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:15 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:15 --> URI Class Initialized
INFO - 2023-06-12 08:58:15 --> Router Class Initialized
INFO - 2023-06-12 08:58:15 --> Output Class Initialized
INFO - 2023-06-12 08:58:15 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:15 --> Input Class Initialized
INFO - 2023-06-12 08:58:15 --> Language Class Initialized
INFO - 2023-06-12 08:58:15 --> Loader Class Initialized
INFO - 2023-06-12 08:58:15 --> Controller Class Initialized
INFO - 2023-06-12 08:58:15 --> Helper loaded: form_helper
INFO - 2023-06-12 08:58:15 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:58:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:15 --> Model "Change_model" initialized
INFO - 2023-06-12 08:58:15 --> Model "Grafana_model" initialized
INFO - 2023-06-12 08:58:15 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:15 --> Total execution time: 0.1453
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
INFO - 2023-06-12 08:58:16 --> Helper loaded: form_helper
INFO - 2023-06-12 08:58:16 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0290
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
INFO - 2023-06-12 08:58:16 --> Helper loaded: form_helper
INFO - 2023-06-12 08:58:16 --> Helper loaded: url_helper
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Model "Login_model" initialized
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0802
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0731
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0544
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0735
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0738
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Config Class Initialized
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> Hooks Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
DEBUG - 2023-06-12 08:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:16 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> URI Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
INFO - 2023-06-12 08:58:16 --> Router Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Output Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:16 --> Input Class Initialized
INFO - 2023-06-12 08:58:16 --> Language Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Loader Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
INFO - 2023-06-12 08:58:16 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
DEBUG - 2023-06-12 08:58:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0752
INFO - 2023-06-12 08:58:16 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:16 --> Total execution time: 0.0948
INFO - 2023-06-12 08:58:19 --> Config Class Initialized
INFO - 2023-06-12 08:58:19 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:19 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:19 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:19 --> URI Class Initialized
INFO - 2023-06-12 08:58:19 --> Router Class Initialized
INFO - 2023-06-12 08:58:19 --> Output Class Initialized
INFO - 2023-06-12 08:58:19 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:19 --> Input Class Initialized
INFO - 2023-06-12 08:58:19 --> Language Class Initialized
INFO - 2023-06-12 08:58:19 --> Loader Class Initialized
INFO - 2023-06-12 08:58:19 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:19 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:19 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:20 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:20 --> Total execution time: 0.0696
INFO - 2023-06-12 08:58:20 --> Config Class Initialized
INFO - 2023-06-12 08:58:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:20 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:20 --> URI Class Initialized
INFO - 2023-06-12 08:58:20 --> Router Class Initialized
INFO - 2023-06-12 08:58:20 --> Output Class Initialized
INFO - 2023-06-12 08:58:20 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:20 --> Input Class Initialized
INFO - 2023-06-12 08:58:20 --> Language Class Initialized
INFO - 2023-06-12 08:58:20 --> Loader Class Initialized
INFO - 2023-06-12 08:58:20 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:20 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:20 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:20 --> Total execution time: 0.0450
INFO - 2023-06-12 08:58:29 --> Config Class Initialized
INFO - 2023-06-12 08:58:29 --> Hooks Class Initialized
INFO - 2023-06-12 08:58:29 --> Config Class Initialized
INFO - 2023-06-12 08:58:29 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:29 --> Utf8 Class Initialized
DEBUG - 2023-06-12 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:29 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:29 --> URI Class Initialized
INFO - 2023-06-12 08:58:29 --> URI Class Initialized
INFO - 2023-06-12 08:58:29 --> Router Class Initialized
INFO - 2023-06-12 08:58:29 --> Router Class Initialized
INFO - 2023-06-12 08:58:29 --> Output Class Initialized
INFO - 2023-06-12 08:58:29 --> Output Class Initialized
INFO - 2023-06-12 08:58:29 --> Security Class Initialized
INFO - 2023-06-12 08:58:29 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:29 --> Input Class Initialized
INFO - 2023-06-12 08:58:29 --> Input Class Initialized
INFO - 2023-06-12 08:58:29 --> Language Class Initialized
INFO - 2023-06-12 08:58:29 --> Language Class Initialized
INFO - 2023-06-12 08:58:29 --> Loader Class Initialized
INFO - 2023-06-12 08:58:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:29 --> Loader Class Initialized
INFO - 2023-06-12 08:58:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:29 --> Total execution time: 0.0721
INFO - 2023-06-12 08:58:29 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:29 --> Total execution time: 0.0749
INFO - 2023-06-12 08:58:29 --> Config Class Initialized
INFO - 2023-06-12 08:58:29 --> Hooks Class Initialized
INFO - 2023-06-12 08:58:29 --> Config Class Initialized
INFO - 2023-06-12 08:58:29 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:29 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:29 --> URI Class Initialized
DEBUG - 2023-06-12 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:29 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:29 --> Router Class Initialized
INFO - 2023-06-12 08:58:29 --> URI Class Initialized
INFO - 2023-06-12 08:58:29 --> Output Class Initialized
INFO - 2023-06-12 08:58:29 --> Router Class Initialized
INFO - 2023-06-12 08:58:29 --> Security Class Initialized
INFO - 2023-06-12 08:58:29 --> Output Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:29 --> Input Class Initialized
INFO - 2023-06-12 08:58:29 --> Security Class Initialized
INFO - 2023-06-12 08:58:29 --> Language Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:29 --> Input Class Initialized
INFO - 2023-06-12 08:58:29 --> Language Class Initialized
INFO - 2023-06-12 08:58:29 --> Loader Class Initialized
INFO - 2023-06-12 08:58:29 --> Loader Class Initialized
INFO - 2023-06-12 08:58:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:29 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:29 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:29 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:30 --> Total execution time: 0.1273
INFO - 2023-06-12 08:58:30 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:30 --> Total execution time: 0.1391
INFO - 2023-06-12 08:58:34 --> Config Class Initialized
INFO - 2023-06-12 08:58:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:34 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:34 --> URI Class Initialized
INFO - 2023-06-12 08:58:34 --> Router Class Initialized
INFO - 2023-06-12 08:58:34 --> Output Class Initialized
INFO - 2023-06-12 08:58:34 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:34 --> Input Class Initialized
INFO - 2023-06-12 08:58:34 --> Language Class Initialized
INFO - 2023-06-12 08:58:34 --> Loader Class Initialized
INFO - 2023-06-12 08:58:34 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:34 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:34 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:34 --> Total execution time: 0.0592
INFO - 2023-06-12 08:58:34 --> Config Class Initialized
INFO - 2023-06-12 08:58:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 08:58:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 08:58:34 --> Utf8 Class Initialized
INFO - 2023-06-12 08:58:34 --> URI Class Initialized
INFO - 2023-06-12 08:58:34 --> Router Class Initialized
INFO - 2023-06-12 08:58:34 --> Output Class Initialized
INFO - 2023-06-12 08:58:34 --> Security Class Initialized
DEBUG - 2023-06-12 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 08:58:34 --> Input Class Initialized
INFO - 2023-06-12 08:58:34 --> Language Class Initialized
INFO - 2023-06-12 08:58:34 --> Loader Class Initialized
INFO - 2023-06-12 08:58:34 --> Controller Class Initialized
DEBUG - 2023-06-12 08:58:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 08:58:34 --> Database Driver Class Initialized
INFO - 2023-06-12 08:58:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 08:58:34 --> Final output sent to browser
DEBUG - 2023-06-12 08:58:34 --> Total execution time: 0.0678
INFO - 2023-06-12 09:00:14 --> Config Class Initialized
INFO - 2023-06-12 09:00:14 --> Config Class Initialized
INFO - 2023-06-12 09:00:14 --> Hooks Class Initialized
INFO - 2023-06-12 09:00:14 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:14 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:00:14 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:14 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:14 --> URI Class Initialized
INFO - 2023-06-12 09:00:14 --> URI Class Initialized
INFO - 2023-06-12 09:00:14 --> Router Class Initialized
INFO - 2023-06-12 09:00:14 --> Router Class Initialized
INFO - 2023-06-12 09:00:14 --> Output Class Initialized
INFO - 2023-06-12 09:00:14 --> Output Class Initialized
INFO - 2023-06-12 09:00:14 --> Security Class Initialized
INFO - 2023-06-12 09:00:14 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 09:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:14 --> Input Class Initialized
INFO - 2023-06-12 09:00:14 --> Input Class Initialized
INFO - 2023-06-12 09:00:14 --> Language Class Initialized
INFO - 2023-06-12 09:00:14 --> Language Class Initialized
INFO - 2023-06-12 09:00:15 --> Loader Class Initialized
INFO - 2023-06-12 09:00:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:15 --> Loader Class Initialized
INFO - 2023-06-12 09:00:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:15 --> Total execution time: 0.0746
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Config Class Initialized
INFO - 2023-06-12 09:00:15 --> Hooks Class Initialized
INFO - 2023-06-12 09:00:15 --> Model "Login_model" initialized
DEBUG - 2023-06-12 09:00:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:15 --> URI Class Initialized
INFO - 2023-06-12 09:00:15 --> Router Class Initialized
INFO - 2023-06-12 09:00:15 --> Output Class Initialized
INFO - 2023-06-12 09:00:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:15 --> Input Class Initialized
INFO - 2023-06-12 09:00:15 --> Language Class Initialized
INFO - 2023-06-12 09:00:15 --> Loader Class Initialized
INFO - 2023-06-12 09:00:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:15 --> Total execution time: 0.1590
INFO - 2023-06-12 09:00:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:15 --> Total execution time: 0.0798
INFO - 2023-06-12 09:00:15 --> Config Class Initialized
INFO - 2023-06-12 09:00:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:15 --> URI Class Initialized
INFO - 2023-06-12 09:00:15 --> Router Class Initialized
INFO - 2023-06-12 09:00:15 --> Output Class Initialized
INFO - 2023-06-12 09:00:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:15 --> Input Class Initialized
INFO - 2023-06-12 09:00:15 --> Language Class Initialized
INFO - 2023-06-12 09:00:15 --> Loader Class Initialized
INFO - 2023-06-12 09:00:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:15 --> Model "Login_model" initialized
INFO - 2023-06-12 09:00:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:15 --> Total execution time: 0.1462
INFO - 2023-06-12 09:00:17 --> Config Class Initialized
INFO - 2023-06-12 09:00:17 --> Hooks Class Initialized
INFO - 2023-06-12 09:00:17 --> Config Class Initialized
INFO - 2023-06-12 09:00:17 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:17 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:00:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:17 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:17 --> URI Class Initialized
INFO - 2023-06-12 09:00:17 --> URI Class Initialized
INFO - 2023-06-12 09:00:17 --> Router Class Initialized
INFO - 2023-06-12 09:00:17 --> Router Class Initialized
INFO - 2023-06-12 09:00:17 --> Output Class Initialized
INFO - 2023-06-12 09:00:17 --> Output Class Initialized
INFO - 2023-06-12 09:00:17 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:17 --> Security Class Initialized
INFO - 2023-06-12 09:00:17 --> Input Class Initialized
DEBUG - 2023-06-12 09:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:17 --> Language Class Initialized
INFO - 2023-06-12 09:00:17 --> Input Class Initialized
INFO - 2023-06-12 09:00:17 --> Language Class Initialized
INFO - 2023-06-12 09:00:17 --> Loader Class Initialized
INFO - 2023-06-12 09:00:17 --> Controller Class Initialized
INFO - 2023-06-12 09:00:17 --> Loader Class Initialized
DEBUG - 2023-06-12 09:00:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:17 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:17 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:17 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:17 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:17 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:17 --> Final output sent to browser
INFO - 2023-06-12 09:00:17 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 09:00:17 --> Total execution time: 0.0653
INFO - 2023-06-12 09:00:17 --> Config Class Initialized
INFO - 2023-06-12 09:00:17 --> Hooks Class Initialized
INFO - 2023-06-12 09:00:17 --> Database Driver Class Initialized
DEBUG - 2023-06-12 09:00:17 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:17 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:18 --> URI Class Initialized
INFO - 2023-06-12 09:00:18 --> Router Class Initialized
INFO - 2023-06-12 09:00:18 --> Model "Login_model" initialized
INFO - 2023-06-12 09:00:18 --> Output Class Initialized
INFO - 2023-06-12 09:00:18 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:18 --> Input Class Initialized
INFO - 2023-06-12 09:00:18 --> Language Class Initialized
INFO - 2023-06-12 09:00:18 --> Loader Class Initialized
INFO - 2023-06-12 09:00:18 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:18 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:18 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:18 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:18 --> Total execution time: 0.1604
INFO - 2023-06-12 09:00:18 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:18 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:18 --> Total execution time: 0.0910
INFO - 2023-06-12 09:00:18 --> Config Class Initialized
INFO - 2023-06-12 09:00:18 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:18 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:18 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:18 --> URI Class Initialized
INFO - 2023-06-12 09:00:18 --> Router Class Initialized
INFO - 2023-06-12 09:00:18 --> Output Class Initialized
INFO - 2023-06-12 09:00:18 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:18 --> Input Class Initialized
INFO - 2023-06-12 09:00:18 --> Language Class Initialized
INFO - 2023-06-12 09:00:18 --> Loader Class Initialized
INFO - 2023-06-12 09:00:18 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:18 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:18 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:18 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:18 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:18 --> Model "Login_model" initialized
INFO - 2023-06-12 09:00:18 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:18 --> Total execution time: 0.1451
INFO - 2023-06-12 09:00:20 --> Config Class Initialized
INFO - 2023-06-12 09:00:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:20 --> URI Class Initialized
INFO - 2023-06-12 09:00:20 --> Router Class Initialized
INFO - 2023-06-12 09:00:20 --> Output Class Initialized
INFO - 2023-06-12 09:00:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:20 --> Input Class Initialized
INFO - 2023-06-12 09:00:20 --> Language Class Initialized
INFO - 2023-06-12 09:00:20 --> Loader Class Initialized
INFO - 2023-06-12 09:00:20 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:21 --> Total execution time: 0.0694
INFO - 2023-06-12 09:00:21 --> Config Class Initialized
INFO - 2023-06-12 09:00:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:21 --> URI Class Initialized
INFO - 2023-06-12 09:00:21 --> Router Class Initialized
INFO - 2023-06-12 09:00:21 --> Output Class Initialized
INFO - 2023-06-12 09:00:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:21 --> Input Class Initialized
INFO - 2023-06-12 09:00:21 --> Language Class Initialized
INFO - 2023-06-12 09:00:21 --> Loader Class Initialized
INFO - 2023-06-12 09:00:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:21 --> Total execution time: 0.0629
INFO - 2023-06-12 09:00:26 --> Config Class Initialized
INFO - 2023-06-12 09:00:26 --> Hooks Class Initialized
INFO - 2023-06-12 09:00:26 --> Config Class Initialized
INFO - 2023-06-12 09:00:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:26 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:00:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:26 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:26 --> URI Class Initialized
INFO - 2023-06-12 09:00:26 --> URI Class Initialized
INFO - 2023-06-12 09:00:26 --> Router Class Initialized
INFO - 2023-06-12 09:00:26 --> Router Class Initialized
INFO - 2023-06-12 09:00:26 --> Output Class Initialized
INFO - 2023-06-12 09:00:26 --> Output Class Initialized
INFO - 2023-06-12 09:00:26 --> Security Class Initialized
INFO - 2023-06-12 09:00:26 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:26 --> Input Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:26 --> Input Class Initialized
INFO - 2023-06-12 09:00:26 --> Language Class Initialized
INFO - 2023-06-12 09:00:26 --> Language Class Initialized
INFO - 2023-06-12 09:00:26 --> Loader Class Initialized
INFO - 2023-06-12 09:00:26 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:26 --> Loader Class Initialized
INFO - 2023-06-12 09:00:26 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:26 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:26 --> Total execution time: 0.0604
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Config Class Initialized
INFO - 2023-06-12 09:00:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:26 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:26 --> URI Class Initialized
INFO - 2023-06-12 09:00:26 --> Router Class Initialized
INFO - 2023-06-12 09:00:26 --> Output Class Initialized
INFO - 2023-06-12 09:00:26 --> Model "Login_model" initialized
INFO - 2023-06-12 09:00:26 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:26 --> Input Class Initialized
INFO - 2023-06-12 09:00:26 --> Language Class Initialized
INFO - 2023-06-12 09:00:26 --> Loader Class Initialized
INFO - 2023-06-12 09:00:26 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:26 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:26 --> Total execution time: 0.0624
INFO - 2023-06-12 09:00:26 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:26 --> Total execution time: 0.1529
INFO - 2023-06-12 09:00:26 --> Config Class Initialized
INFO - 2023-06-12 09:00:26 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:00:26 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:00:26 --> Utf8 Class Initialized
INFO - 2023-06-12 09:00:26 --> URI Class Initialized
INFO - 2023-06-12 09:00:26 --> Router Class Initialized
INFO - 2023-06-12 09:00:26 --> Output Class Initialized
INFO - 2023-06-12 09:00:26 --> Security Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:00:26 --> Input Class Initialized
INFO - 2023-06-12 09:00:26 --> Language Class Initialized
INFO - 2023-06-12 09:00:26 --> Loader Class Initialized
INFO - 2023-06-12 09:00:26 --> Controller Class Initialized
DEBUG - 2023-06-12 09:00:26 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:00:26 --> Database Driver Class Initialized
INFO - 2023-06-12 09:00:26 --> Model "Login_model" initialized
INFO - 2023-06-12 09:00:26 --> Final output sent to browser
DEBUG - 2023-06-12 09:00:26 --> Total execution time: 0.1631
INFO - 2023-06-12 09:01:15 --> Config Class Initialized
INFO - 2023-06-12 09:01:15 --> Hooks Class Initialized
INFO - 2023-06-12 09:01:15 --> Config Class Initialized
INFO - 2023-06-12 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:01:15 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:01:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:01:15 --> URI Class Initialized
INFO - 2023-06-12 09:01:15 --> URI Class Initialized
INFO - 2023-06-12 09:01:15 --> Router Class Initialized
INFO - 2023-06-12 09:01:15 --> Router Class Initialized
INFO - 2023-06-12 09:01:15 --> Output Class Initialized
INFO - 2023-06-12 09:01:15 --> Output Class Initialized
INFO - 2023-06-12 09:01:15 --> Security Class Initialized
INFO - 2023-06-12 09:01:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:01:15 --> Input Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:01:15 --> Input Class Initialized
INFO - 2023-06-12 09:01:15 --> Language Class Initialized
INFO - 2023-06-12 09:01:15 --> Language Class Initialized
INFO - 2023-06-12 09:01:15 --> Loader Class Initialized
INFO - 2023-06-12 09:01:15 --> Loader Class Initialized
INFO - 2023-06-12 09:01:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:01:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:01:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:01:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:01:15 --> Total execution time: 0.0692
INFO - 2023-06-12 09:01:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:01:15 --> Config Class Initialized
INFO - 2023-06-12 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:01:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:01:15 --> URI Class Initialized
INFO - 2023-06-12 09:01:15 --> Router Class Initialized
INFO - 2023-06-12 09:01:15 --> Output Class Initialized
INFO - 2023-06-12 09:01:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:01:15 --> Input Class Initialized
INFO - 2023-06-12 09:01:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:15 --> Language Class Initialized
INFO - 2023-06-12 09:01:15 --> Loader Class Initialized
INFO - 2023-06-12 09:01:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:01:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:01:16 --> Model "Login_model" initialized
INFO - 2023-06-12 09:01:16 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:01:16 --> Final output sent to browser
DEBUG - 2023-06-12 09:01:16 --> Total execution time: 0.0541
INFO - 2023-06-12 09:01:16 --> Final output sent to browser
DEBUG - 2023-06-12 09:01:16 --> Total execution time: 0.1879
INFO - 2023-06-12 09:01:16 --> Config Class Initialized
INFO - 2023-06-12 09:01:16 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:01:16 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:01:16 --> Utf8 Class Initialized
INFO - 2023-06-12 09:01:16 --> URI Class Initialized
INFO - 2023-06-12 09:01:16 --> Router Class Initialized
INFO - 2023-06-12 09:01:16 --> Output Class Initialized
INFO - 2023-06-12 09:01:16 --> Security Class Initialized
DEBUG - 2023-06-12 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:01:16 --> Input Class Initialized
INFO - 2023-06-12 09:01:16 --> Language Class Initialized
INFO - 2023-06-12 09:01:16 --> Loader Class Initialized
INFO - 2023-06-12 09:01:16 --> Controller Class Initialized
DEBUG - 2023-06-12 09:01:16 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:01:16 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:16 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:01:16 --> Database Driver Class Initialized
INFO - 2023-06-12 09:01:16 --> Model "Login_model" initialized
INFO - 2023-06-12 09:01:16 --> Final output sent to browser
DEBUG - 2023-06-12 09:01:16 --> Total execution time: 0.1398
INFO - 2023-06-12 09:02:02 --> Config Class Initialized
INFO - 2023-06-12 09:02:02 --> Hooks Class Initialized
INFO - 2023-06-12 09:02:02 --> Config Class Initialized
INFO - 2023-06-12 09:02:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:02 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:02:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:02 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:02 --> URI Class Initialized
INFO - 2023-06-12 09:02:02 --> URI Class Initialized
INFO - 2023-06-12 09:02:02 --> Router Class Initialized
INFO - 2023-06-12 09:02:02 --> Router Class Initialized
INFO - 2023-06-12 09:02:02 --> Output Class Initialized
INFO - 2023-06-12 09:02:02 --> Output Class Initialized
INFO - 2023-06-12 09:02:02 --> Security Class Initialized
INFO - 2023-06-12 09:02:02 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:02 --> Input Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:02 --> Input Class Initialized
INFO - 2023-06-12 09:02:02 --> Language Class Initialized
INFO - 2023-06-12 09:02:02 --> Language Class Initialized
INFO - 2023-06-12 09:02:02 --> Loader Class Initialized
INFO - 2023-06-12 09:02:02 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:02 --> Loader Class Initialized
INFO - 2023-06-12 09:02:02 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:02 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:02 --> Total execution time: 0.0629
INFO - 2023-06-12 09:02:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:02 --> Config Class Initialized
INFO - 2023-06-12 09:02:02 --> Hooks Class Initialized
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
DEBUG - 2023-06-12 09:02:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:02 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:02 --> URI Class Initialized
INFO - 2023-06-12 09:02:02 --> Router Class Initialized
INFO - 2023-06-12 09:02:02 --> Output Class Initialized
INFO - 2023-06-12 09:02:02 --> Security Class Initialized
INFO - 2023-06-12 09:02:02 --> Model "Login_model" initialized
DEBUG - 2023-06-12 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:02 --> Input Class Initialized
INFO - 2023-06-12 09:02:02 --> Language Class Initialized
INFO - 2023-06-12 09:02:02 --> Loader Class Initialized
INFO - 2023-06-12 09:02:02 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:02 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:02 --> Total execution time: 0.0575
INFO - 2023-06-12 09:02:02 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:02 --> Total execution time: 0.1668
INFO - 2023-06-12 09:02:02 --> Config Class Initialized
INFO - 2023-06-12 09:02:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:02 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:02 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:02 --> URI Class Initialized
INFO - 2023-06-12 09:02:02 --> Router Class Initialized
INFO - 2023-06-12 09:02:02 --> Output Class Initialized
INFO - 2023-06-12 09:02:02 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:02 --> Input Class Initialized
INFO - 2023-06-12 09:02:02 --> Language Class Initialized
INFO - 2023-06-12 09:02:02 --> Loader Class Initialized
INFO - 2023-06-12 09:02:02 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:02 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:02 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:02 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:02 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:02 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:02 --> Total execution time: 0.1469
INFO - 2023-06-12 09:02:10 --> Config Class Initialized
INFO - 2023-06-12 09:02:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:10 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:10 --> URI Class Initialized
INFO - 2023-06-12 09:02:10 --> Router Class Initialized
INFO - 2023-06-12 09:02:10 --> Output Class Initialized
INFO - 2023-06-12 09:02:10 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:10 --> Input Class Initialized
INFO - 2023-06-12 09:02:10 --> Language Class Initialized
INFO - 2023-06-12 09:02:10 --> Loader Class Initialized
INFO - 2023-06-12 09:02:10 --> Controller Class Initialized
INFO - 2023-06-12 09:02:10 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:10 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:10 --> Model "Change_model" initialized
INFO - 2023-06-12 09:02:10 --> Model "Grafana_model" initialized
INFO - 2023-06-12 09:02:10 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:10 --> Total execution time: 0.1247
INFO - 2023-06-12 09:02:10 --> Config Class Initialized
INFO - 2023-06-12 09:02:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:10 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:10 --> URI Class Initialized
INFO - 2023-06-12 09:02:10 --> Router Class Initialized
INFO - 2023-06-12 09:02:10 --> Output Class Initialized
INFO - 2023-06-12 09:02:10 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:10 --> Input Class Initialized
INFO - 2023-06-12 09:02:10 --> Language Class Initialized
INFO - 2023-06-12 09:02:10 --> Loader Class Initialized
INFO - 2023-06-12 09:02:10 --> Controller Class Initialized
INFO - 2023-06-12 09:02:10 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:10 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:10 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:10 --> Total execution time: 0.0318
INFO - 2023-06-12 09:02:10 --> Config Class Initialized
INFO - 2023-06-12 09:02:10 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:10 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:10 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:10 --> URI Class Initialized
INFO - 2023-06-12 09:02:10 --> Router Class Initialized
INFO - 2023-06-12 09:02:10 --> Output Class Initialized
INFO - 2023-06-12 09:02:10 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:10 --> Input Class Initialized
INFO - 2023-06-12 09:02:10 --> Language Class Initialized
INFO - 2023-06-12 09:02:10 --> Loader Class Initialized
INFO - 2023-06-12 09:02:10 --> Controller Class Initialized
INFO - 2023-06-12 09:02:10 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:10 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:10 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:10 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:10 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:10 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:10 --> Total execution time: 0.0702
INFO - 2023-06-12 09:02:20 --> Config Class Initialized
INFO - 2023-06-12 09:02:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:20 --> URI Class Initialized
INFO - 2023-06-12 09:02:20 --> Router Class Initialized
INFO - 2023-06-12 09:02:20 --> Output Class Initialized
INFO - 2023-06-12 09:02:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:20 --> Input Class Initialized
INFO - 2023-06-12 09:02:20 --> Language Class Initialized
INFO - 2023-06-12 09:02:20 --> Loader Class Initialized
INFO - 2023-06-12 09:02:20 --> Controller Class Initialized
INFO - 2023-06-12 09:02:20 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:20 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:20 --> Model "Change_model" initialized
INFO - 2023-06-12 09:02:20 --> Model "Grafana_model" initialized
INFO - 2023-06-12 09:02:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:20 --> Total execution time: 0.1237
INFO - 2023-06-12 09:02:20 --> Config Class Initialized
INFO - 2023-06-12 09:02:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:20 --> URI Class Initialized
INFO - 2023-06-12 09:02:20 --> Router Class Initialized
INFO - 2023-06-12 09:02:20 --> Output Class Initialized
INFO - 2023-06-12 09:02:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:20 --> Input Class Initialized
INFO - 2023-06-12 09:02:20 --> Language Class Initialized
INFO - 2023-06-12 09:02:20 --> Loader Class Initialized
INFO - 2023-06-12 09:02:20 --> Controller Class Initialized
INFO - 2023-06-12 09:02:20 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:20 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:20 --> Total execution time: 0.0286
INFO - 2023-06-12 09:02:20 --> Config Class Initialized
INFO - 2023-06-12 09:02:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:20 --> URI Class Initialized
INFO - 2023-06-12 09:02:20 --> Router Class Initialized
INFO - 2023-06-12 09:02:20 --> Output Class Initialized
INFO - 2023-06-12 09:02:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:20 --> Input Class Initialized
INFO - 2023-06-12 09:02:20 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
INFO - 2023-06-12 09:02:21 --> Helper loaded: form_helper
INFO - 2023-06-12 09:02:21 --> Helper loaded: url_helper
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.0852
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.0850
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.0540
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.0485
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.0440
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.1252
INFO - 2023-06-12 09:02:21 --> Config Class Initialized
INFO - 2023-06-12 09:02:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:21 --> URI Class Initialized
INFO - 2023-06-12 09:02:21 --> Router Class Initialized
INFO - 2023-06-12 09:02:21 --> Output Class Initialized
INFO - 2023-06-12 09:02:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:21 --> Input Class Initialized
INFO - 2023-06-12 09:02:21 --> Language Class Initialized
INFO - 2023-06-12 09:02:21 --> Loader Class Initialized
INFO - 2023-06-12 09:02:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:21 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:21 --> Total execution time: 0.1370
INFO - 2023-06-12 09:02:28 --> Config Class Initialized
INFO - 2023-06-12 09:02:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:28 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:28 --> URI Class Initialized
INFO - 2023-06-12 09:02:28 --> Router Class Initialized
INFO - 2023-06-12 09:02:28 --> Output Class Initialized
INFO - 2023-06-12 09:02:28 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:28 --> Input Class Initialized
INFO - 2023-06-12 09:02:28 --> Language Class Initialized
INFO - 2023-06-12 09:02:28 --> Loader Class Initialized
INFO - 2023-06-12 09:02:28 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:28 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:28 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:28 --> Total execution time: 0.0654
INFO - 2023-06-12 09:02:28 --> Config Class Initialized
INFO - 2023-06-12 09:02:28 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:28 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:28 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:28 --> URI Class Initialized
INFO - 2023-06-12 09:02:28 --> Router Class Initialized
INFO - 2023-06-12 09:02:28 --> Output Class Initialized
INFO - 2023-06-12 09:02:28 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:28 --> Input Class Initialized
INFO - 2023-06-12 09:02:28 --> Language Class Initialized
INFO - 2023-06-12 09:02:28 --> Loader Class Initialized
INFO - 2023-06-12 09:02:28 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:28 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:28 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:28 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:28 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:28 --> Total execution time: 0.0656
INFO - 2023-06-12 09:02:34 --> Config Class Initialized
INFO - 2023-06-12 09:02:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:34 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:34 --> URI Class Initialized
INFO - 2023-06-12 09:02:34 --> Router Class Initialized
INFO - 2023-06-12 09:02:34 --> Output Class Initialized
INFO - 2023-06-12 09:02:34 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:34 --> Input Class Initialized
INFO - 2023-06-12 09:02:34 --> Language Class Initialized
INFO - 2023-06-12 09:02:34 --> Loader Class Initialized
INFO - 2023-06-12 09:02:34 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:34 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:34 --> Total execution time: 0.0732
INFO - 2023-06-12 09:02:34 --> Config Class Initialized
INFO - 2023-06-12 09:02:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:34 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:34 --> URI Class Initialized
INFO - 2023-06-12 09:02:34 --> Router Class Initialized
INFO - 2023-06-12 09:02:34 --> Output Class Initialized
INFO - 2023-06-12 09:02:34 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:34 --> Input Class Initialized
INFO - 2023-06-12 09:02:34 --> Language Class Initialized
INFO - 2023-06-12 09:02:34 --> Loader Class Initialized
INFO - 2023-06-12 09:02:34 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:34 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:34 --> Total execution time: 0.0773
INFO - 2023-06-12 09:02:34 --> Config Class Initialized
INFO - 2023-06-12 09:02:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:34 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:34 --> URI Class Initialized
INFO - 2023-06-12 09:02:34 --> Router Class Initialized
INFO - 2023-06-12 09:02:34 --> Output Class Initialized
INFO - 2023-06-12 09:02:34 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:34 --> Input Class Initialized
INFO - 2023-06-12 09:02:34 --> Language Class Initialized
INFO - 2023-06-12 09:02:34 --> Loader Class Initialized
INFO - 2023-06-12 09:02:34 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:34 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:34 --> Total execution time: 0.0262
INFO - 2023-06-12 09:02:34 --> Config Class Initialized
INFO - 2023-06-12 09:02:34 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:02:34 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:02:34 --> Utf8 Class Initialized
INFO - 2023-06-12 09:02:34 --> URI Class Initialized
INFO - 2023-06-12 09:02:34 --> Router Class Initialized
INFO - 2023-06-12 09:02:34 --> Output Class Initialized
INFO - 2023-06-12 09:02:34 --> Security Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:02:34 --> Input Class Initialized
INFO - 2023-06-12 09:02:34 --> Language Class Initialized
INFO - 2023-06-12 09:02:34 --> Loader Class Initialized
INFO - 2023-06-12 09:02:34 --> Controller Class Initialized
DEBUG - 2023-06-12 09:02:34 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Login_model" initialized
INFO - 2023-06-12 09:02:34 --> Database Driver Class Initialized
INFO - 2023-06-12 09:02:34 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:02:34 --> Final output sent to browser
DEBUG - 2023-06-12 09:02:34 --> Total execution time: 0.0900
INFO - 2023-06-12 09:04:02 --> Config Class Initialized
INFO - 2023-06-12 09:04:02 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:03 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:03 --> URI Class Initialized
INFO - 2023-06-12 09:04:03 --> Router Class Initialized
INFO - 2023-06-12 09:04:03 --> Output Class Initialized
INFO - 2023-06-12 09:04:03 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:03 --> Input Class Initialized
INFO - 2023-06-12 09:04:03 --> Language Class Initialized
INFO - 2023-06-12 09:04:03 --> Loader Class Initialized
INFO - 2023-06-12 09:04:03 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Login_model" initialized
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:03 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:03 --> Total execution time: 0.0709
INFO - 2023-06-12 09:04:03 --> Config Class Initialized
INFO - 2023-06-12 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:03 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:03 --> URI Class Initialized
INFO - 2023-06-12 09:04:03 --> Router Class Initialized
INFO - 2023-06-12 09:04:03 --> Output Class Initialized
INFO - 2023-06-12 09:04:03 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:03 --> Input Class Initialized
INFO - 2023-06-12 09:04:03 --> Language Class Initialized
INFO - 2023-06-12 09:04:03 --> Loader Class Initialized
INFO - 2023-06-12 09:04:03 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Login_model" initialized
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:03 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:03 --> Total execution time: 0.0655
INFO - 2023-06-12 09:04:03 --> Config Class Initialized
INFO - 2023-06-12 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:03 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:03 --> URI Class Initialized
INFO - 2023-06-12 09:04:03 --> Router Class Initialized
INFO - 2023-06-12 09:04:03 --> Output Class Initialized
INFO - 2023-06-12 09:04:03 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:03 --> Input Class Initialized
INFO - 2023-06-12 09:04:03 --> Language Class Initialized
INFO - 2023-06-12 09:04:03 --> Loader Class Initialized
INFO - 2023-06-12 09:04:03 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:03 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:03 --> Total execution time: 0.0314
INFO - 2023-06-12 09:04:03 --> Config Class Initialized
INFO - 2023-06-12 09:04:03 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:03 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:03 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:03 --> URI Class Initialized
INFO - 2023-06-12 09:04:03 --> Router Class Initialized
INFO - 2023-06-12 09:04:03 --> Output Class Initialized
INFO - 2023-06-12 09:04:03 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:03 --> Input Class Initialized
INFO - 2023-06-12 09:04:03 --> Language Class Initialized
INFO - 2023-06-12 09:04:03 --> Loader Class Initialized
INFO - 2023-06-12 09:04:03 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:03 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Login_model" initialized
INFO - 2023-06-12 09:04:03 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:03 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:03 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:03 --> Total execution time: 0.0656
INFO - 2023-06-12 09:04:09 --> Config Class Initialized
INFO - 2023-06-12 09:04:09 --> Hooks Class Initialized
INFO - 2023-06-12 09:04:09 --> Config Class Initialized
INFO - 2023-06-12 09:04:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:09 --> URI Class Initialized
DEBUG - 2023-06-12 09:04:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:09 --> URI Class Initialized
INFO - 2023-06-12 09:04:09 --> Router Class Initialized
INFO - 2023-06-12 09:04:09 --> Output Class Initialized
INFO - 2023-06-12 09:04:09 --> Router Class Initialized
INFO - 2023-06-12 09:04:09 --> Security Class Initialized
INFO - 2023-06-12 09:04:09 --> Output Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:09 --> Security Class Initialized
INFO - 2023-06-12 09:04:09 --> Input Class Initialized
INFO - 2023-06-12 09:04:09 --> Language Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:09 --> Input Class Initialized
INFO - 2023-06-12 09:04:09 --> Language Class Initialized
INFO - 2023-06-12 09:04:09 --> Loader Class Initialized
INFO - 2023-06-12 09:04:09 --> Controller Class Initialized
INFO - 2023-06-12 09:04:09 --> Loader Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:09 --> Total execution time: 0.0634
INFO - 2023-06-12 09:04:09 --> Config Class Initialized
INFO - 2023-06-12 09:04:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:09 --> URI Class Initialized
INFO - 2023-06-12 09:04:09 --> Router Class Initialized
INFO - 2023-06-12 09:04:09 --> Output Class Initialized
INFO - 2023-06-12 09:04:09 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:09 --> Input Class Initialized
INFO - 2023-06-12 09:04:09 --> Language Class Initialized
INFO - 2023-06-12 09:04:09 --> Model "Login_model" initialized
INFO - 2023-06-12 09:04:09 --> Loader Class Initialized
INFO - 2023-06-12 09:04:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:09 --> Total execution time: 0.0643
INFO - 2023-06-12 09:04:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:09 --> Total execution time: 0.1433
INFO - 2023-06-12 09:04:09 --> Config Class Initialized
INFO - 2023-06-12 09:04:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:04:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:04:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:04:09 --> URI Class Initialized
INFO - 2023-06-12 09:04:09 --> Router Class Initialized
INFO - 2023-06-12 09:04:09 --> Output Class Initialized
INFO - 2023-06-12 09:04:09 --> Security Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:04:09 --> Input Class Initialized
INFO - 2023-06-12 09:04:09 --> Language Class Initialized
INFO - 2023-06-12 09:04:09 --> Loader Class Initialized
INFO - 2023-06-12 09:04:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:04:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:04:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:04:09 --> Model "Login_model" initialized
INFO - 2023-06-12 09:04:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:04:09 --> Total execution time: 0.1530
INFO - 2023-06-12 09:05:09 --> Config Class Initialized
INFO - 2023-06-12 09:05:09 --> Hooks Class Initialized
INFO - 2023-06-12 09:05:09 --> Config Class Initialized
INFO - 2023-06-12 09:05:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:09 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:09 --> URI Class Initialized
INFO - 2023-06-12 09:05:09 --> URI Class Initialized
INFO - 2023-06-12 09:05:09 --> Router Class Initialized
INFO - 2023-06-12 09:05:09 --> Router Class Initialized
INFO - 2023-06-12 09:05:09 --> Output Class Initialized
INFO - 2023-06-12 09:05:09 --> Output Class Initialized
INFO - 2023-06-12 09:05:09 --> Security Class Initialized
INFO - 2023-06-12 09:05:09 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:09 --> Input Class Initialized
INFO - 2023-06-12 09:05:09 --> Input Class Initialized
INFO - 2023-06-12 09:05:09 --> Language Class Initialized
INFO - 2023-06-12 09:05:09 --> Language Class Initialized
INFO - 2023-06-12 09:05:09 --> Loader Class Initialized
INFO - 2023-06-12 09:05:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:09 --> Loader Class Initialized
INFO - 2023-06-12 09:05:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:09 --> Total execution time: 0.0623
INFO - 2023-06-12 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:09 --> Config Class Initialized
INFO - 2023-06-12 09:05:09 --> Hooks Class Initialized
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
DEBUG - 2023-06-12 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:09 --> URI Class Initialized
INFO - 2023-06-12 09:05:09 --> Router Class Initialized
INFO - 2023-06-12 09:05:09 --> Output Class Initialized
INFO - 2023-06-12 09:05:09 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:09 --> Input Class Initialized
INFO - 2023-06-12 09:05:09 --> Model "Login_model" initialized
INFO - 2023-06-12 09:05:09 --> Language Class Initialized
INFO - 2023-06-12 09:05:09 --> Loader Class Initialized
INFO - 2023-06-12 09:05:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:09 --> Total execution time: 0.0622
INFO - 2023-06-12 09:05:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:09 --> Total execution time: 0.1503
INFO - 2023-06-12 09:05:09 --> Config Class Initialized
INFO - 2023-06-12 09:05:09 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:09 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:09 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:09 --> URI Class Initialized
INFO - 2023-06-12 09:05:09 --> Router Class Initialized
INFO - 2023-06-12 09:05:09 --> Output Class Initialized
INFO - 2023-06-12 09:05:09 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:09 --> Input Class Initialized
INFO - 2023-06-12 09:05:09 --> Language Class Initialized
INFO - 2023-06-12 09:05:09 --> Loader Class Initialized
INFO - 2023-06-12 09:05:09 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:09 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:09 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:09 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:09 --> Model "Login_model" initialized
INFO - 2023-06-12 09:05:09 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:09 --> Total execution time: 0.1664
INFO - 2023-06-12 09:05:13 --> Config Class Initialized
INFO - 2023-06-12 09:05:13 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:13 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:13 --> URI Class Initialized
INFO - 2023-06-12 09:05:13 --> Router Class Initialized
INFO - 2023-06-12 09:05:13 --> Output Class Initialized
INFO - 2023-06-12 09:05:13 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:13 --> Input Class Initialized
INFO - 2023-06-12 09:05:13 --> Language Class Initialized
INFO - 2023-06-12 09:05:13 --> Loader Class Initialized
INFO - 2023-06-12 09:05:13 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:13 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:13 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:13 --> Total execution time: 0.0606
INFO - 2023-06-12 09:05:13 --> Config Class Initialized
INFO - 2023-06-12 09:05:13 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:13 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:13 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:13 --> URI Class Initialized
INFO - 2023-06-12 09:05:13 --> Router Class Initialized
INFO - 2023-06-12 09:05:13 --> Output Class Initialized
INFO - 2023-06-12 09:05:13 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:13 --> Input Class Initialized
INFO - 2023-06-12 09:05:13 --> Language Class Initialized
INFO - 2023-06-12 09:05:13 --> Loader Class Initialized
INFO - 2023-06-12 09:05:13 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:13 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:13 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:13 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:13 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:13 --> Total execution time: 0.0637
INFO - 2023-06-12 09:05:15 --> Config Class Initialized
INFO - 2023-06-12 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:15 --> Config Class Initialized
INFO - 2023-06-12 09:05:15 --> Hooks Class Initialized
INFO - 2023-06-12 09:05:15 --> URI Class Initialized
INFO - 2023-06-12 09:05:15 --> Router Class Initialized
DEBUG - 2023-06-12 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:15 --> Output Class Initialized
INFO - 2023-06-12 09:05:15 --> URI Class Initialized
INFO - 2023-06-12 09:05:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:15 --> Input Class Initialized
INFO - 2023-06-12 09:05:15 --> Router Class Initialized
INFO - 2023-06-12 09:05:15 --> Language Class Initialized
INFO - 2023-06-12 09:05:15 --> Output Class Initialized
INFO - 2023-06-12 09:05:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:15 --> Input Class Initialized
INFO - 2023-06-12 09:05:15 --> Language Class Initialized
INFO - 2023-06-12 09:05:15 --> Loader Class Initialized
INFO - 2023-06-12 09:05:15 --> Loader Class Initialized
INFO - 2023-06-12 09:05:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:15 --> Total execution time: 0.0783
INFO - 2023-06-12 09:05:15 --> Config Class Initialized
INFO - 2023-06-12 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:15 --> URI Class Initialized
INFO - 2023-06-12 09:05:15 --> Router Class Initialized
INFO - 2023-06-12 09:05:15 --> Output Class Initialized
INFO - 2023-06-12 09:05:15 --> Model "Login_model" initialized
INFO - 2023-06-12 09:05:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:15 --> Input Class Initialized
INFO - 2023-06-12 09:05:15 --> Language Class Initialized
INFO - 2023-06-12 09:05:15 --> Loader Class Initialized
INFO - 2023-06-12 09:05:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:15 --> Total execution time: 0.0619
INFO - 2023-06-12 09:05:15 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:15 --> Total execution time: 0.1980
INFO - 2023-06-12 09:05:15 --> Config Class Initialized
INFO - 2023-06-12 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:15 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:15 --> URI Class Initialized
INFO - 2023-06-12 09:05:15 --> Router Class Initialized
INFO - 2023-06-12 09:05:15 --> Output Class Initialized
INFO - 2023-06-12 09:05:15 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:15 --> Input Class Initialized
INFO - 2023-06-12 09:05:15 --> Language Class Initialized
INFO - 2023-06-12 09:05:15 --> Loader Class Initialized
INFO - 2023-06-12 09:05:15 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:15 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:15 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:15 --> Model "Login_model" initialized
INFO - 2023-06-12 09:05:16 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:16 --> Total execution time: 0.1975
INFO - 2023-06-12 09:05:21 --> Config Class Initialized
INFO - 2023-06-12 09:05:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:21 --> URI Class Initialized
INFO - 2023-06-12 09:05:21 --> Router Class Initialized
INFO - 2023-06-12 09:05:21 --> Output Class Initialized
INFO - 2023-06-12 09:05:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:21 --> Input Class Initialized
INFO - 2023-06-12 09:05:21 --> Language Class Initialized
INFO - 2023-06-12 09:05:21 --> Loader Class Initialized
INFO - 2023-06-12 09:05:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:21 --> Total execution time: 0.0526
INFO - 2023-06-12 09:05:21 --> Config Class Initialized
INFO - 2023-06-12 09:05:21 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:05:21 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:05:21 --> Utf8 Class Initialized
INFO - 2023-06-12 09:05:21 --> URI Class Initialized
INFO - 2023-06-12 09:05:21 --> Router Class Initialized
INFO - 2023-06-12 09:05:21 --> Output Class Initialized
INFO - 2023-06-12 09:05:21 --> Security Class Initialized
DEBUG - 2023-06-12 09:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:05:21 --> Input Class Initialized
INFO - 2023-06-12 09:05:21 --> Language Class Initialized
INFO - 2023-06-12 09:05:21 --> Loader Class Initialized
INFO - 2023-06-12 09:05:21 --> Controller Class Initialized
DEBUG - 2023-06-12 09:05:21 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:05:21 --> Database Driver Class Initialized
INFO - 2023-06-12 09:05:21 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:05:21 --> Final output sent to browser
DEBUG - 2023-06-12 09:05:21 --> Total execution time: 0.0435
INFO - 2023-06-12 09:06:50 --> Config Class Initialized
INFO - 2023-06-12 09:06:50 --> Hooks Class Initialized
INFO - 2023-06-12 09:06:50 --> Config Class Initialized
INFO - 2023-06-12 09:06:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:50 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:50 --> Utf8 Class Initialized
INFO - 2023-06-12 09:06:50 --> URI Class Initialized
INFO - 2023-06-12 09:06:50 --> URI Class Initialized
INFO - 2023-06-12 09:06:50 --> Router Class Initialized
INFO - 2023-06-12 09:06:50 --> Router Class Initialized
INFO - 2023-06-12 09:06:50 --> Output Class Initialized
INFO - 2023-06-12 09:06:50 --> Output Class Initialized
INFO - 2023-06-12 09:06:50 --> Security Class Initialized
INFO - 2023-06-12 09:06:50 --> Security Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:50 --> Input Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:50 --> Input Class Initialized
INFO - 2023-06-12 09:06:50 --> Language Class Initialized
INFO - 2023-06-12 09:06:50 --> Language Class Initialized
INFO - 2023-06-12 09:06:50 --> Loader Class Initialized
INFO - 2023-06-12 09:06:50 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:50 --> Loader Class Initialized
INFO - 2023-06-12 09:06:50 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:06:50 --> Final output sent to browser
INFO - 2023-06-12 09:06:50 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 09:06:50 --> Total execution time: 0.0687
INFO - 2023-06-12 09:06:50 --> Config Class Initialized
INFO - 2023-06-12 09:06:50 --> Hooks Class Initialized
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
DEBUG - 2023-06-12 09:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:50 --> Utf8 Class Initialized
INFO - 2023-06-12 09:06:50 --> URI Class Initialized
INFO - 2023-06-12 09:06:50 --> Router Class Initialized
INFO - 2023-06-12 09:06:50 --> Output Class Initialized
INFO - 2023-06-12 09:06:50 --> Security Class Initialized
INFO - 2023-06-12 09:06:50 --> Model "Login_model" initialized
DEBUG - 2023-06-12 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:50 --> Input Class Initialized
INFO - 2023-06-12 09:06:50 --> Language Class Initialized
INFO - 2023-06-12 09:06:50 --> Loader Class Initialized
INFO - 2023-06-12 09:06:50 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:06:50 --> Final output sent to browser
DEBUG - 2023-06-12 09:06:50 --> Total execution time: 0.0593
INFO - 2023-06-12 09:06:50 --> Final output sent to browser
DEBUG - 2023-06-12 09:06:50 --> Total execution time: 0.1571
INFO - 2023-06-12 09:06:50 --> Config Class Initialized
INFO - 2023-06-12 09:06:50 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:50 --> Utf8 Class Initialized
INFO - 2023-06-12 09:06:50 --> URI Class Initialized
INFO - 2023-06-12 09:06:50 --> Router Class Initialized
INFO - 2023-06-12 09:06:50 --> Output Class Initialized
INFO - 2023-06-12 09:06:50 --> Security Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:50 --> Input Class Initialized
INFO - 2023-06-12 09:06:50 --> Language Class Initialized
INFO - 2023-06-12 09:06:50 --> Loader Class Initialized
INFO - 2023-06-12 09:06:50 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:50 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:06:50 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:50 --> Model "Login_model" initialized
INFO - 2023-06-12 09:06:50 --> Final output sent to browser
DEBUG - 2023-06-12 09:06:50 --> Total execution time: 0.1389
INFO - 2023-06-12 09:06:53 --> Config Class Initialized
INFO - 2023-06-12 09:06:53 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:06:53 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:53 --> Utf8 Class Initialized
INFO - 2023-06-12 09:06:53 --> URI Class Initialized
INFO - 2023-06-12 09:06:53 --> Router Class Initialized
INFO - 2023-06-12 09:06:53 --> Output Class Initialized
INFO - 2023-06-12 09:06:53 --> Security Class Initialized
DEBUG - 2023-06-12 09:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:53 --> Input Class Initialized
INFO - 2023-06-12 09:06:53 --> Language Class Initialized
INFO - 2023-06-12 09:06:53 --> Loader Class Initialized
INFO - 2023-06-12 09:06:53 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:53 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:53 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:06:53 --> Final output sent to browser
DEBUG - 2023-06-12 09:06:53 --> Total execution time: 0.0605
INFO - 2023-06-12 09:06:53 --> Config Class Initialized
INFO - 2023-06-12 09:06:53 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:06:53 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:06:53 --> Utf8 Class Initialized
INFO - 2023-06-12 09:06:53 --> URI Class Initialized
INFO - 2023-06-12 09:06:53 --> Router Class Initialized
INFO - 2023-06-12 09:06:53 --> Output Class Initialized
INFO - 2023-06-12 09:06:53 --> Security Class Initialized
DEBUG - 2023-06-12 09:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:06:53 --> Input Class Initialized
INFO - 2023-06-12 09:06:53 --> Language Class Initialized
INFO - 2023-06-12 09:06:53 --> Loader Class Initialized
INFO - 2023-06-12 09:06:53 --> Controller Class Initialized
DEBUG - 2023-06-12 09:06:53 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:06:53 --> Database Driver Class Initialized
INFO - 2023-06-12 09:06:53 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:06:53 --> Final output sent to browser
DEBUG - 2023-06-12 09:06:53 --> Total execution time: 0.0515
INFO - 2023-06-12 09:11:01 --> Config Class Initialized
INFO - 2023-06-12 09:11:01 --> Hooks Class Initialized
INFO - 2023-06-12 09:11:01 --> Config Class Initialized
INFO - 2023-06-12 09:11:01 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:11:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:11:01 --> Utf8 Class Initialized
INFO - 2023-06-12 09:11:01 --> URI Class Initialized
DEBUG - 2023-06-12 09:11:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:11:01 --> Utf8 Class Initialized
INFO - 2023-06-12 09:11:01 --> URI Class Initialized
INFO - 2023-06-12 09:11:01 --> Router Class Initialized
INFO - 2023-06-12 09:11:01 --> Router Class Initialized
INFO - 2023-06-12 09:11:01 --> Output Class Initialized
INFO - 2023-06-12 09:11:01 --> Security Class Initialized
INFO - 2023-06-12 09:11:01 --> Output Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:11:01 --> Security Class Initialized
INFO - 2023-06-12 09:11:01 --> Input Class Initialized
INFO - 2023-06-12 09:11:01 --> Language Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:11:01 --> Input Class Initialized
INFO - 2023-06-12 09:11:01 --> Language Class Initialized
INFO - 2023-06-12 09:11:01 --> Loader Class Initialized
INFO - 2023-06-12 09:11:01 --> Controller Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:11:01 --> Loader Class Initialized
INFO - 2023-06-12 09:11:01 --> Controller Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:11:01 --> Final output sent to browser
DEBUG - 2023-06-12 09:11:01 --> Total execution time: 0.0567
INFO - 2023-06-12 09:11:01 --> Config Class Initialized
INFO - 2023-06-12 09:11:01 --> Hooks Class Initialized
INFO - 2023-06-12 09:11:01 --> Model "Cluster_model" initialized
DEBUG - 2023-06-12 09:11:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:11:01 --> Utf8 Class Initialized
INFO - 2023-06-12 09:11:01 --> URI Class Initialized
INFO - 2023-06-12 09:11:01 --> Router Class Initialized
INFO - 2023-06-12 09:11:01 --> Output Class Initialized
INFO - 2023-06-12 09:11:01 --> Security Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:11:01 --> Input Class Initialized
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Language Class Initialized
INFO - 2023-06-12 09:11:01 --> Loader Class Initialized
INFO - 2023-06-12 09:11:01 --> Controller Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:11:01 --> Model "Login_model" initialized
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:11:01 --> Final output sent to browser
DEBUG - 2023-06-12 09:11:01 --> Total execution time: 0.0656
INFO - 2023-06-12 09:11:01 --> Final output sent to browser
DEBUG - 2023-06-12 09:11:01 --> Total execution time: 0.1321
INFO - 2023-06-12 09:11:01 --> Config Class Initialized
INFO - 2023-06-12 09:11:01 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:11:01 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:11:01 --> Utf8 Class Initialized
INFO - 2023-06-12 09:11:01 --> URI Class Initialized
INFO - 2023-06-12 09:11:01 --> Router Class Initialized
INFO - 2023-06-12 09:11:01 --> Output Class Initialized
INFO - 2023-06-12 09:11:01 --> Security Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:11:01 --> Input Class Initialized
INFO - 2023-06-12 09:11:01 --> Language Class Initialized
INFO - 2023-06-12 09:11:01 --> Loader Class Initialized
INFO - 2023-06-12 09:11:01 --> Controller Class Initialized
DEBUG - 2023-06-12 09:11:01 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:11:01 --> Database Driver Class Initialized
INFO - 2023-06-12 09:11:01 --> Model "Login_model" initialized
INFO - 2023-06-12 09:11:01 --> Final output sent to browser
DEBUG - 2023-06-12 09:11:01 --> Total execution time: 0.1297
INFO - 2023-06-12 09:13:27 --> Config Class Initialized
INFO - 2023-06-12 09:13:27 --> Hooks Class Initialized
INFO - 2023-06-12 09:13:27 --> Config Class Initialized
INFO - 2023-06-12 09:13:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:13:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:13:27 --> Utf8 Class Initialized
DEBUG - 2023-06-12 09:13:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:13:27 --> Utf8 Class Initialized
INFO - 2023-06-12 09:13:27 --> URI Class Initialized
INFO - 2023-06-12 09:13:27 --> URI Class Initialized
INFO - 2023-06-12 09:13:27 --> Router Class Initialized
INFO - 2023-06-12 09:13:27 --> Router Class Initialized
INFO - 2023-06-12 09:13:27 --> Output Class Initialized
INFO - 2023-06-12 09:13:27 --> Output Class Initialized
INFO - 2023-06-12 09:13:27 --> Security Class Initialized
INFO - 2023-06-12 09:13:27 --> Security Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:13:27 --> Input Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:13:27 --> Input Class Initialized
INFO - 2023-06-12 09:13:27 --> Language Class Initialized
INFO - 2023-06-12 09:13:27 --> Language Class Initialized
INFO - 2023-06-12 09:13:27 --> Loader Class Initialized
INFO - 2023-06-12 09:13:27 --> Controller Class Initialized
INFO - 2023-06-12 09:13:27 --> Loader Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:13:27 --> Controller Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:13:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:13:27 --> Final output sent to browser
DEBUG - 2023-06-12 09:13:27 --> Total execution time: 0.0625
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Config Class Initialized
INFO - 2023-06-12 09:13:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:13:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:13:27 --> Utf8 Class Initialized
INFO - 2023-06-12 09:13:27 --> URI Class Initialized
INFO - 2023-06-12 09:13:27 --> Router Class Initialized
INFO - 2023-06-12 09:13:27 --> Output Class Initialized
INFO - 2023-06-12 09:13:27 --> Security Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:13:27 --> Input Class Initialized
INFO - 2023-06-12 09:13:27 --> Language Class Initialized
INFO - 2023-06-12 09:13:27 --> Loader Class Initialized
INFO - 2023-06-12 09:13:27 --> Controller Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Model "Login_model" initialized
INFO - 2023-06-12 09:13:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:13:27 --> Final output sent to browser
DEBUG - 2023-06-12 09:13:27 --> Total execution time: 0.0520
INFO - 2023-06-12 09:13:27 --> Final output sent to browser
DEBUG - 2023-06-12 09:13:27 --> Total execution time: 0.1591
INFO - 2023-06-12 09:13:27 --> Config Class Initialized
INFO - 2023-06-12 09:13:27 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:13:27 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:13:27 --> Utf8 Class Initialized
INFO - 2023-06-12 09:13:27 --> URI Class Initialized
INFO - 2023-06-12 09:13:27 --> Router Class Initialized
INFO - 2023-06-12 09:13:27 --> Output Class Initialized
INFO - 2023-06-12 09:13:27 --> Security Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:13:27 --> Input Class Initialized
INFO - 2023-06-12 09:13:27 --> Language Class Initialized
INFO - 2023-06-12 09:13:27 --> Loader Class Initialized
INFO - 2023-06-12 09:13:27 --> Controller Class Initialized
DEBUG - 2023-06-12 09:13:27 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:13:27 --> Database Driver Class Initialized
INFO - 2023-06-12 09:13:27 --> Model "Login_model" initialized
INFO - 2023-06-12 09:13:27 --> Final output sent to browser
DEBUG - 2023-06-12 09:13:27 --> Total execution time: 0.1628
INFO - 2023-06-12 09:15:20 --> Config Class Initialized
INFO - 2023-06-12 09:15:20 --> Config Class Initialized
INFO - 2023-06-12 09:15:20 --> Hooks Class Initialized
INFO - 2023-06-12 09:15:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-12 09:15:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:15:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:15:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:15:20 --> URI Class Initialized
INFO - 2023-06-12 09:15:20 --> URI Class Initialized
INFO - 2023-06-12 09:15:20 --> Router Class Initialized
INFO - 2023-06-12 09:15:20 --> Router Class Initialized
INFO - 2023-06-12 09:15:20 --> Output Class Initialized
INFO - 2023-06-12 09:15:20 --> Output Class Initialized
INFO - 2023-06-12 09:15:20 --> Security Class Initialized
INFO - 2023-06-12 09:15:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-12 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:15:20 --> Input Class Initialized
INFO - 2023-06-12 09:15:20 --> Input Class Initialized
INFO - 2023-06-12 09:15:20 --> Language Class Initialized
INFO - 2023-06-12 09:15:20 --> Language Class Initialized
INFO - 2023-06-12 09:15:20 --> Loader Class Initialized
INFO - 2023-06-12 09:15:20 --> Controller Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:15:20 --> Loader Class Initialized
INFO - 2023-06-12 09:15:20 --> Controller Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:15:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:15:20 --> Total execution time: 0.0658
INFO - 2023-06-12 09:15:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Config Class Initialized
INFO - 2023-06-12 09:15:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:15:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:15:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:15:20 --> URI Class Initialized
INFO - 2023-06-12 09:15:20 --> Model "Login_model" initialized
INFO - 2023-06-12 09:15:20 --> Router Class Initialized
INFO - 2023-06-12 09:15:20 --> Output Class Initialized
INFO - 2023-06-12 09:15:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:15:20 --> Input Class Initialized
INFO - 2023-06-12 09:15:20 --> Language Class Initialized
INFO - 2023-06-12 09:15:20 --> Loader Class Initialized
INFO - 2023-06-12 09:15:20 --> Controller Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:15:20 --> Total execution time: 0.1285
INFO - 2023-06-12 09:15:20 --> Config Class Initialized
INFO - 2023-06-12 09:15:20 --> Hooks Class Initialized
DEBUG - 2023-06-12 09:15:20 --> UTF-8 Support Enabled
INFO - 2023-06-12 09:15:20 --> Utf8 Class Initialized
INFO - 2023-06-12 09:15:20 --> URI Class Initialized
INFO - 2023-06-12 09:15:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:15:20 --> Router Class Initialized
INFO - 2023-06-12 09:15:20 --> Output Class Initialized
INFO - 2023-06-12 09:15:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:15:20 --> Total execution time: 0.0753
INFO - 2023-06-12 09:15:20 --> Security Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-12 09:15:20 --> Input Class Initialized
INFO - 2023-06-12 09:15:20 --> Language Class Initialized
INFO - 2023-06-12 09:15:20 --> Loader Class Initialized
INFO - 2023-06-12 09:15:20 --> Controller Class Initialized
DEBUG - 2023-06-12 09:15:20 --> Config file loaded: D:\web\httpd\Apache24\htdocs\KunlunMonitor\application\config/myconfig.php
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Model "Cluster_model" initialized
INFO - 2023-06-12 09:15:20 --> Database Driver Class Initialized
INFO - 2023-06-12 09:15:20 --> Model "Login_model" initialized
INFO - 2023-06-12 09:15:20 --> Final output sent to browser
DEBUG - 2023-06-12 09:15:20 --> Total execution time: 0.1270
