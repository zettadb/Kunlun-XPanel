<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-01 02:08:46 --> Config Class Initialized
INFO - 2023-06-01 02:08:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:46 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:46 --> URI Class Initialized
INFO - 2023-06-01 02:08:46 --> Router Class Initialized
INFO - 2023-06-01 02:08:46 --> Output Class Initialized
INFO - 2023-06-01 02:08:46 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:47 --> Input Class Initialized
INFO - 2023-06-01 02:08:47 --> Language Class Initialized
INFO - 2023-06-01 02:08:47 --> Loader Class Initialized
INFO - 2023-06-01 02:08:47 --> Controller Class Initialized
INFO - 2023-06-01 02:08:47 --> Helper loaded: form_helper
INFO - 2023-06-01 02:08:47 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:08:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:47 --> Model "Change_model" initialized
INFO - 2023-06-01 02:08:47 --> Model "Grafana_model" initialized
INFO - 2023-06-01 02:08:47 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:47 --> Total execution time: 0.8052
INFO - 2023-06-01 02:08:47 --> Config Class Initialized
INFO - 2023-06-01 02:08:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:47 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:47 --> URI Class Initialized
INFO - 2023-06-01 02:08:47 --> Router Class Initialized
INFO - 2023-06-01 02:08:47 --> Output Class Initialized
INFO - 2023-06-01 02:08:47 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:47 --> Input Class Initialized
INFO - 2023-06-01 02:08:47 --> Language Class Initialized
INFO - 2023-06-01 02:08:47 --> Loader Class Initialized
INFO - 2023-06-01 02:08:47 --> Controller Class Initialized
INFO - 2023-06-01 02:08:47 --> Helper loaded: form_helper
INFO - 2023-06-01 02:08:47 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:08:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:47 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:47 --> Total execution time: 0.2351
INFO - 2023-06-01 02:08:47 --> Config Class Initialized
INFO - 2023-06-01 02:08:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:47 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:47 --> URI Class Initialized
INFO - 2023-06-01 02:08:47 --> Router Class Initialized
INFO - 2023-06-01 02:08:47 --> Output Class Initialized
INFO - 2023-06-01 02:08:47 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:47 --> Input Class Initialized
INFO - 2023-06-01 02:08:47 --> Language Class Initialized
INFO - 2023-06-01 02:08:47 --> Loader Class Initialized
INFO - 2023-06-01 02:08:47 --> Controller Class Initialized
INFO - 2023-06-01 02:08:47 --> Helper loaded: form_helper
INFO - 2023-06-01 02:08:47 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:08:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:48 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:48 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:48 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:48 --> Total execution time: 0.3459
INFO - 2023-06-01 02:08:48 --> Config Class Initialized
INFO - 2023-06-01 02:08:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:48 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:48 --> URI Class Initialized
INFO - 2023-06-01 02:08:48 --> Router Class Initialized
INFO - 2023-06-01 02:08:48 --> Output Class Initialized
INFO - 2023-06-01 02:08:48 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:48 --> Input Class Initialized
INFO - 2023-06-01 02:08:48 --> Language Class Initialized
INFO - 2023-06-01 02:08:48 --> Loader Class Initialized
INFO - 2023-06-01 02:08:48 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:48 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:48 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:48 --> Total execution time: 0.2669
INFO - 2023-06-01 02:08:48 --> Config Class Initialized
INFO - 2023-06-01 02:08:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:48 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:48 --> URI Class Initialized
INFO - 2023-06-01 02:08:48 --> Router Class Initialized
INFO - 2023-06-01 02:08:48 --> Output Class Initialized
INFO - 2023-06-01 02:08:48 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:48 --> Input Class Initialized
INFO - 2023-06-01 02:08:48 --> Language Class Initialized
INFO - 2023-06-01 02:08:48 --> Loader Class Initialized
INFO - 2023-06-01 02:08:48 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:48 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:48 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:48 --> Total execution time: 0.2022
INFO - 2023-06-01 02:08:49 --> Config Class Initialized
INFO - 2023-06-01 02:08:49 --> Config Class Initialized
INFO - 2023-06-01 02:08:49 --> Hooks Class Initialized
INFO - 2023-06-01 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:49 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:49 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:49 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:49 --> URI Class Initialized
INFO - 2023-06-01 02:08:49 --> URI Class Initialized
INFO - 2023-06-01 02:08:49 --> Router Class Initialized
INFO - 2023-06-01 02:08:49 --> Router Class Initialized
INFO - 2023-06-01 02:08:49 --> Output Class Initialized
INFO - 2023-06-01 02:08:49 --> Output Class Initialized
INFO - 2023-06-01 02:08:49 --> Security Class Initialized
INFO - 2023-06-01 02:08:49 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:49 --> Input Class Initialized
INFO - 2023-06-01 02:08:49 --> Input Class Initialized
INFO - 2023-06-01 02:08:49 --> Language Class Initialized
INFO - 2023-06-01 02:08:49 --> Language Class Initialized
INFO - 2023-06-01 02:08:49 --> Loader Class Initialized
INFO - 2023-06-01 02:08:49 --> Loader Class Initialized
INFO - 2023-06-01 02:08:49 --> Controller Class Initialized
INFO - 2023-06-01 02:08:49 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:08:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:49 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:49 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:49 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:49 --> Total execution time: 0.2510
INFO - 2023-06-01 02:08:49 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:49 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:49 --> Config Class Initialized
INFO - 2023-06-01 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:49 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:49 --> URI Class Initialized
INFO - 2023-06-01 02:08:49 --> Router Class Initialized
INFO - 2023-06-01 02:08:49 --> Output Class Initialized
INFO - 2023-06-01 02:08:49 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:49 --> Input Class Initialized
INFO - 2023-06-01 02:08:49 --> Language Class Initialized
INFO - 2023-06-01 02:08:49 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:49 --> Total execution time: 0.4894
INFO - 2023-06-01 02:08:49 --> Loader Class Initialized
INFO - 2023-06-01 02:08:49 --> Config Class Initialized
INFO - 2023-06-01 02:08:49 --> Controller Class Initialized
INFO - 2023-06-01 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:49 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:49 --> URI Class Initialized
INFO - 2023-06-01 02:08:49 --> Router Class Initialized
INFO - 2023-06-01 02:08:49 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:49 --> Output Class Initialized
INFO - 2023-06-01 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:49 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:49 --> Final output sent to browser
INFO - 2023-06-01 02:08:49 --> Input Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Total execution time: 0.3667
INFO - 2023-06-01 02:08:49 --> Language Class Initialized
INFO - 2023-06-01 02:08:49 --> Loader Class Initialized
INFO - 2023-06-01 02:08:49 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:49 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:50 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:50 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:50 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:50 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:50 --> Total execution time: 1.0659
INFO - 2023-06-01 02:08:58 --> Config Class Initialized
INFO - 2023-06-01 02:08:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:58 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:58 --> URI Class Initialized
INFO - 2023-06-01 02:08:58 --> Router Class Initialized
INFO - 2023-06-01 02:08:58 --> Output Class Initialized
INFO - 2023-06-01 02:08:58 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:58 --> Input Class Initialized
INFO - 2023-06-01 02:08:58 --> Language Class Initialized
INFO - 2023-06-01 02:08:58 --> Loader Class Initialized
INFO - 2023-06-01 02:08:58 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:58 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:58 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:58 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:59 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:59 --> Total execution time: 0.3140
INFO - 2023-06-01 02:08:59 --> Config Class Initialized
INFO - 2023-06-01 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:59 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:59 --> URI Class Initialized
INFO - 2023-06-01 02:08:59 --> Router Class Initialized
INFO - 2023-06-01 02:08:59 --> Output Class Initialized
INFO - 2023-06-01 02:08:59 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:59 --> Input Class Initialized
INFO - 2023-06-01 02:08:59 --> Language Class Initialized
INFO - 2023-06-01 02:08:59 --> Loader Class Initialized
INFO - 2023-06-01 02:08:59 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:59 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:59 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:59 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:08:59 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:59 --> Total execution time: 0.3087
INFO - 2023-06-01 02:08:59 --> Config Class Initialized
INFO - 2023-06-01 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:59 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:59 --> URI Class Initialized
INFO - 2023-06-01 02:08:59 --> Router Class Initialized
INFO - 2023-06-01 02:08:59 --> Output Class Initialized
INFO - 2023-06-01 02:08:59 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:59 --> Input Class Initialized
INFO - 2023-06-01 02:08:59 --> Language Class Initialized
INFO - 2023-06-01 02:08:59 --> Loader Class Initialized
INFO - 2023-06-01 02:08:59 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:59 --> Final output sent to browser
DEBUG - 2023-06-01 02:08:59 --> Total execution time: 0.1656
INFO - 2023-06-01 02:08:59 --> Config Class Initialized
INFO - 2023-06-01 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:08:59 --> Utf8 Class Initialized
INFO - 2023-06-01 02:08:59 --> URI Class Initialized
INFO - 2023-06-01 02:08:59 --> Router Class Initialized
INFO - 2023-06-01 02:08:59 --> Output Class Initialized
INFO - 2023-06-01 02:08:59 --> Security Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:08:59 --> Input Class Initialized
INFO - 2023-06-01 02:08:59 --> Language Class Initialized
INFO - 2023-06-01 02:08:59 --> Loader Class Initialized
INFO - 2023-06-01 02:08:59 --> Controller Class Initialized
DEBUG - 2023-06-01 02:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:08:59 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:59 --> Model "Login_model" initialized
INFO - 2023-06-01 02:08:59 --> Database Driver Class Initialized
INFO - 2023-06-01 02:08:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:09:00 --> Final output sent to browser
DEBUG - 2023-06-01 02:09:00 --> Total execution time: 0.4991
INFO - 2023-06-01 02:09:04 --> Config Class Initialized
INFO - 2023-06-01 02:09:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:09:04 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:09:04 --> Utf8 Class Initialized
INFO - 2023-06-01 02:09:04 --> URI Class Initialized
INFO - 2023-06-01 02:09:04 --> Router Class Initialized
INFO - 2023-06-01 02:09:04 --> Output Class Initialized
INFO - 2023-06-01 02:09:04 --> Security Class Initialized
DEBUG - 2023-06-01 02:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:09:04 --> Input Class Initialized
INFO - 2023-06-01 02:09:04 --> Language Class Initialized
INFO - 2023-06-01 02:09:04 --> Loader Class Initialized
INFO - 2023-06-01 02:09:05 --> Controller Class Initialized
DEBUG - 2023-06-01 02:09:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:09:05 --> Database Driver Class Initialized
INFO - 2023-06-01 02:09:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:09:05 --> Final output sent to browser
DEBUG - 2023-06-01 02:09:05 --> Total execution time: 0.2114
INFO - 2023-06-01 02:09:05 --> Config Class Initialized
INFO - 2023-06-01 02:09:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:09:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:09:05 --> Utf8 Class Initialized
INFO - 2023-06-01 02:09:05 --> URI Class Initialized
INFO - 2023-06-01 02:09:05 --> Router Class Initialized
INFO - 2023-06-01 02:09:05 --> Output Class Initialized
INFO - 2023-06-01 02:09:05 --> Security Class Initialized
DEBUG - 2023-06-01 02:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:09:05 --> Input Class Initialized
INFO - 2023-06-01 02:09:05 --> Language Class Initialized
INFO - 2023-06-01 02:09:05 --> Loader Class Initialized
INFO - 2023-06-01 02:09:05 --> Controller Class Initialized
DEBUG - 2023-06-01 02:09:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:09:05 --> Database Driver Class Initialized
INFO - 2023-06-01 02:09:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:09:05 --> Final output sent to browser
DEBUG - 2023-06-01 02:09:05 --> Total execution time: 0.2461
INFO - 2023-06-01 02:09:11 --> Config Class Initialized
INFO - 2023-06-01 02:09:11 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:09:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:09:11 --> Utf8 Class Initialized
INFO - 2023-06-01 02:09:11 --> URI Class Initialized
INFO - 2023-06-01 02:09:11 --> Router Class Initialized
INFO - 2023-06-01 02:09:11 --> Output Class Initialized
INFO - 2023-06-01 02:09:11 --> Security Class Initialized
DEBUG - 2023-06-01 02:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:09:11 --> Input Class Initialized
INFO - 2023-06-01 02:09:11 --> Language Class Initialized
ERROR - 2023-06-01 02:09:11 --> 404 Page Not Found: user/Cluster/CdcDelete
INFO - 2023-06-01 02:27:01 --> Config Class Initialized
INFO - 2023-06-01 02:27:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:27:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:27:01 --> Utf8 Class Initialized
INFO - 2023-06-01 02:27:01 --> URI Class Initialized
INFO - 2023-06-01 02:27:01 --> Router Class Initialized
INFO - 2023-06-01 02:27:01 --> Output Class Initialized
INFO - 2023-06-01 02:27:01 --> Security Class Initialized
DEBUG - 2023-06-01 02:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:27:01 --> Input Class Initialized
INFO - 2023-06-01 02:27:01 --> Language Class Initialized
INFO - 2023-06-01 02:27:01 --> Loader Class Initialized
INFO - 2023-06-01 02:27:01 --> Controller Class Initialized
DEBUG - 2023-06-01 02:27:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:27:01 --> Database Driver Class Initialized
INFO - 2023-06-01 02:27:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:27:01 --> Final output sent to browser
DEBUG - 2023-06-01 02:27:01 --> Total execution time: 0.3764
INFO - 2023-06-01 02:27:01 --> Config Class Initialized
INFO - 2023-06-01 02:27:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:27:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:27:01 --> Utf8 Class Initialized
INFO - 2023-06-01 02:27:01 --> URI Class Initialized
INFO - 2023-06-01 02:27:01 --> Router Class Initialized
INFO - 2023-06-01 02:27:01 --> Output Class Initialized
INFO - 2023-06-01 02:27:01 --> Security Class Initialized
DEBUG - 2023-06-01 02:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:27:01 --> Input Class Initialized
INFO - 2023-06-01 02:27:01 --> Language Class Initialized
INFO - 2023-06-01 02:27:01 --> Loader Class Initialized
INFO - 2023-06-01 02:27:01 --> Controller Class Initialized
DEBUG - 2023-06-01 02:27:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:27:01 --> Database Driver Class Initialized
INFO - 2023-06-01 02:27:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:27:01 --> Final output sent to browser
DEBUG - 2023-06-01 02:27:01 --> Total execution time: 0.4372
INFO - 2023-06-01 02:34:52 --> Config Class Initialized
INFO - 2023-06-01 02:34:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:52 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:52 --> URI Class Initialized
INFO - 2023-06-01 02:34:52 --> Router Class Initialized
INFO - 2023-06-01 02:34:52 --> Output Class Initialized
INFO - 2023-06-01 02:34:52 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:52 --> Input Class Initialized
INFO - 2023-06-01 02:34:52 --> Language Class Initialized
INFO - 2023-06-01 02:34:52 --> Loader Class Initialized
INFO - 2023-06-01 02:34:52 --> Controller Class Initialized
INFO - 2023-06-01 02:34:52 --> Helper loaded: form_helper
INFO - 2023-06-01 02:34:52 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:34:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:52 --> Model "Change_model" initialized
INFO - 2023-06-01 02:34:52 --> Model "Grafana_model" initialized
INFO - 2023-06-01 02:34:52 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:52 --> Total execution time: 0.2528
INFO - 2023-06-01 02:34:52 --> Config Class Initialized
INFO - 2023-06-01 02:34:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:52 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:52 --> URI Class Initialized
INFO - 2023-06-01 02:34:52 --> Router Class Initialized
INFO - 2023-06-01 02:34:52 --> Output Class Initialized
INFO - 2023-06-01 02:34:52 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:52 --> Input Class Initialized
INFO - 2023-06-01 02:34:52 --> Language Class Initialized
INFO - 2023-06-01 02:34:52 --> Loader Class Initialized
INFO - 2023-06-01 02:34:52 --> Controller Class Initialized
INFO - 2023-06-01 02:34:52 --> Helper loaded: form_helper
INFO - 2023-06-01 02:34:52 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:34:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:53 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:53 --> Total execution time: 0.2097
INFO - 2023-06-01 02:34:53 --> Config Class Initialized
INFO - 2023-06-01 02:34:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:53 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:53 --> URI Class Initialized
INFO - 2023-06-01 02:34:53 --> Router Class Initialized
INFO - 2023-06-01 02:34:53 --> Output Class Initialized
INFO - 2023-06-01 02:34:53 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:53 --> Input Class Initialized
INFO - 2023-06-01 02:34:53 --> Language Class Initialized
INFO - 2023-06-01 02:34:53 --> Loader Class Initialized
INFO - 2023-06-01 02:34:53 --> Controller Class Initialized
INFO - 2023-06-01 02:34:53 --> Helper loaded: form_helper
INFO - 2023-06-01 02:34:53 --> Helper loaded: url_helper
DEBUG - 2023-06-01 02:34:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:53 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:53 --> Model "Login_model" initialized
INFO - 2023-06-01 02:34:53 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:53 --> Total execution time: 0.2670
INFO - 2023-06-01 02:34:53 --> Config Class Initialized
INFO - 2023-06-01 02:34:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:53 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:53 --> URI Class Initialized
INFO - 2023-06-01 02:34:53 --> Router Class Initialized
INFO - 2023-06-01 02:34:53 --> Output Class Initialized
INFO - 2023-06-01 02:34:53 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:53 --> Input Class Initialized
INFO - 2023-06-01 02:34:53 --> Language Class Initialized
INFO - 2023-06-01 02:34:53 --> Loader Class Initialized
INFO - 2023-06-01 02:34:53 --> Controller Class Initialized
DEBUG - 2023-06-01 02:34:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:53 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:34:53 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:53 --> Total execution time: 0.2733
INFO - 2023-06-01 02:34:53 --> Config Class Initialized
INFO - 2023-06-01 02:34:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:53 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:53 --> URI Class Initialized
INFO - 2023-06-01 02:34:53 --> Router Class Initialized
INFO - 2023-06-01 02:34:53 --> Output Class Initialized
INFO - 2023-06-01 02:34:53 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:53 --> Input Class Initialized
INFO - 2023-06-01 02:34:53 --> Language Class Initialized
INFO - 2023-06-01 02:34:53 --> Loader Class Initialized
INFO - 2023-06-01 02:34:53 --> Controller Class Initialized
DEBUG - 2023-06-01 02:34:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:53 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:34:53 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:53 --> Total execution time: 0.2219
INFO - 2023-06-01 02:34:54 --> Config Class Initialized
INFO - 2023-06-01 02:34:54 --> Config Class Initialized
INFO - 2023-06-01 02:34:54 --> Hooks Class Initialized
INFO - 2023-06-01 02:34:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:54 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:34:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:54 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:54 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:54 --> URI Class Initialized
INFO - 2023-06-01 02:34:54 --> URI Class Initialized
INFO - 2023-06-01 02:34:54 --> Router Class Initialized
INFO - 2023-06-01 02:34:54 --> Router Class Initialized
INFO - 2023-06-01 02:34:54 --> Output Class Initialized
INFO - 2023-06-01 02:34:54 --> Output Class Initialized
INFO - 2023-06-01 02:34:54 --> Security Class Initialized
INFO - 2023-06-01 02:34:54 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:54 --> Input Class Initialized
INFO - 2023-06-01 02:34:54 --> Input Class Initialized
INFO - 2023-06-01 02:34:54 --> Language Class Initialized
INFO - 2023-06-01 02:34:54 --> Language Class Initialized
INFO - 2023-06-01 02:34:54 --> Loader Class Initialized
INFO - 2023-06-01 02:34:54 --> Loader Class Initialized
INFO - 2023-06-01 02:34:54 --> Controller Class Initialized
DEBUG - 2023-06-01 02:34:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:54 --> Controller Class Initialized
DEBUG - 2023-06-01 02:34:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:54 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:54 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:34:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:34:54 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:54 --> Total execution time: 0.2606
INFO - 2023-06-01 02:34:54 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:54 --> Model "Login_model" initialized
INFO - 2023-06-01 02:34:54 --> Config Class Initialized
INFO - 2023-06-01 02:34:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:34:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:34:54 --> Utf8 Class Initialized
INFO - 2023-06-01 02:34:54 --> URI Class Initialized
INFO - 2023-06-01 02:34:54 --> Router Class Initialized
INFO - 2023-06-01 02:34:54 --> Output Class Initialized
INFO - 2023-06-01 02:34:54 --> Security Class Initialized
DEBUG - 2023-06-01 02:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:34:54 --> Input Class Initialized
INFO - 2023-06-01 02:34:54 --> Language Class Initialized
INFO - 2023-06-01 02:34:54 --> Loader Class Initialized
INFO - 2023-06-01 02:34:54 --> Controller Class Initialized
DEBUG - 2023-06-01 02:34:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:34:54 --> Database Driver Class Initialized
INFO - 2023-06-01 02:34:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:34:54 --> Final output sent to browser
DEBUG - 2023-06-01 02:34:54 --> Total execution time: 0.4198
INFO - 2023-06-01 02:35:01 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:01 --> Total execution time: 7.4486
INFO - 2023-06-01 02:35:01 --> Config Class Initialized
INFO - 2023-06-01 02:35:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:01 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:01 --> URI Class Initialized
INFO - 2023-06-01 02:35:01 --> Router Class Initialized
INFO - 2023-06-01 02:35:01 --> Output Class Initialized
INFO - 2023-06-01 02:35:01 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:01 --> Input Class Initialized
INFO - 2023-06-01 02:35:01 --> Language Class Initialized
INFO - 2023-06-01 02:35:01 --> Loader Class Initialized
INFO - 2023-06-01 02:35:01 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:01 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:02 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:02 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:02 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:02 --> Total execution time: 1.1843
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:18 --> Router Class Initialized
INFO - 2023-06-01 02:35:18 --> Router Class Initialized
INFO - 2023-06-01 02:35:18 --> Router Class Initialized
INFO - 2023-06-01 02:35:18 --> Output Class Initialized
INFO - 2023-06-01 02:35:18 --> Output Class Initialized
INFO - 2023-06-01 02:35:18 --> Output Class Initialized
INFO - 2023-06-01 02:35:18 --> Security Class Initialized
INFO - 2023-06-01 02:35:18 --> Security Class Initialized
INFO - 2023-06-01 02:35:18 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:18 --> Input Class Initialized
INFO - 2023-06-01 02:35:18 --> Input Class Initialized
INFO - 2023-06-01 02:35:18 --> Input Class Initialized
INFO - 2023-06-01 02:35:18 --> Language Class Initialized
INFO - 2023-06-01 02:35:18 --> Language Class Initialized
INFO - 2023-06-01 02:35:18 --> Language Class Initialized
INFO - 2023-06-01 02:35:18 --> Loader Class Initialized
INFO - 2023-06-01 02:35:18 --> Loader Class Initialized
INFO - 2023-06-01 02:35:18 --> Loader Class Initialized
INFO - 2023-06-01 02:35:18 --> Controller Class Initialized
INFO - 2023-06-01 02:35:18 --> Controller Class Initialized
INFO - 2023-06-01 02:35:18 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:18 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:18 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:18 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:18 --> Final output sent to browser
INFO - 2023-06-01 02:35:18 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:18 --> Total execution time: 0.2941
DEBUG - 2023-06-01 02:35:18 --> Total execution time: 0.2954
INFO - 2023-06-01 02:35:18 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:18 --> Total execution time: 0.3092
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:35:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:18 --> Config Class Initialized
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:18 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:18 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
DEBUG - 2023-06-01 02:35:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
INFO - 2023-06-01 02:35:19 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.3088
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.3072
INFO - 2023-06-01 02:35:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Config Class Initialized
INFO - 2023-06-01 02:35:19 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.3546
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.4156
DEBUG - 2023-06-01 02:35:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:19 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:19 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Config Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
INFO - 2023-06-01 02:35:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
DEBUG - 2023-06-01 02:35:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:19 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:19 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.3373
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
INFO - 2023-06-01 02:35:19 --> Config Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.2955
INFO - 2023-06-01 02:35:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:19 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:19 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:19 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:19 --> Input Class Initialized
INFO - 2023-06-01 02:35:19 --> Language Class Initialized
INFO - 2023-06-01 02:35:19 --> Loader Class Initialized
INFO - 2023-06-01 02:35:19 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:19 --> Config Class Initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:19 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:19 --> Database Driver Class Initialized
DEBUG - 2023-06-01 02:35:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:19 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:19 --> URI Class Initialized
INFO - 2023-06-01 02:35:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:19 --> Router Class Initialized
INFO - 2023-06-01 02:35:19 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:19 --> Total execution time: 0.3097
INFO - 2023-06-01 02:35:19 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.3514
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.2069
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.3442
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.3586
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.4062
INFO - 2023-06-01 02:35:20 --> Config Class Initialized
INFO - 2023-06-01 02:35:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:20 --> URI Class Initialized
INFO - 2023-06-01 02:35:20 --> Router Class Initialized
INFO - 2023-06-01 02:35:20 --> Output Class Initialized
INFO - 2023-06-01 02:35:20 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:20 --> Input Class Initialized
INFO - 2023-06-01 02:35:20 --> Language Class Initialized
INFO - 2023-06-01 02:35:20 --> Loader Class Initialized
INFO - 2023-06-01 02:35:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:20 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:20 --> Total execution time: 0.6047
INFO - 2023-06-01 02:35:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:21 --> Config Class Initialized
INFO - 2023-06-01 02:35:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:21 --> URI Class Initialized
INFO - 2023-06-01 02:35:21 --> Router Class Initialized
INFO - 2023-06-01 02:35:21 --> Output Class Initialized
INFO - 2023-06-01 02:35:21 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:21 --> Input Class Initialized
INFO - 2023-06-01 02:35:21 --> Language Class Initialized
INFO - 2023-06-01 02:35:21 --> Loader Class Initialized
INFO - 2023-06-01 02:35:21 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:21 --> Total execution time: 0.4668
INFO - 2023-06-01 02:35:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:21 --> Total execution time: 0.5696
INFO - 2023-06-01 02:35:21 --> Config Class Initialized
INFO - 2023-06-01 02:35:21 --> Hooks Class Initialized
INFO - 2023-06-01 02:35:21 --> Config Class Initialized
INFO - 2023-06-01 02:35:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:21 --> URI Class Initialized
DEBUG - 2023-06-01 02:35:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:21 --> Router Class Initialized
INFO - 2023-06-01 02:35:21 --> URI Class Initialized
INFO - 2023-06-01 02:35:21 --> Output Class Initialized
INFO - 2023-06-01 02:35:21 --> Router Class Initialized
INFO - 2023-06-01 02:35:21 --> Security Class Initialized
INFO - 2023-06-01 02:35:21 --> Output Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:21 --> Input Class Initialized
INFO - 2023-06-01 02:35:21 --> Security Class Initialized
INFO - 2023-06-01 02:35:21 --> Language Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:21 --> Input Class Initialized
INFO - 2023-06-01 02:35:21 --> Language Class Initialized
INFO - 2023-06-01 02:35:21 --> Loader Class Initialized
INFO - 2023-06-01 02:35:21 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:21 --> Loader Class Initialized
INFO - 2023-06-01 02:35:21 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:22 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:22 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:22 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:22 --> Total execution time: 0.2697
INFO - 2023-06-01 02:35:22 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:22 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:22 --> Config Class Initialized
INFO - 2023-06-01 02:35:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:22 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:22 --> URI Class Initialized
INFO - 2023-06-01 02:35:22 --> Router Class Initialized
INFO - 2023-06-01 02:35:22 --> Output Class Initialized
INFO - 2023-06-01 02:35:22 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:22 --> Input Class Initialized
INFO - 2023-06-01 02:35:22 --> Language Class Initialized
INFO - 2023-06-01 02:35:22 --> Loader Class Initialized
INFO - 2023-06-01 02:35:22 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:22 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:22 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:22 --> Total execution time: 0.3059
INFO - 2023-06-01 02:35:22 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:22 --> Total execution time: 0.9636
INFO - 2023-06-01 02:35:22 --> Config Class Initialized
INFO - 2023-06-01 02:35:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:35:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:35:22 --> Utf8 Class Initialized
INFO - 2023-06-01 02:35:22 --> URI Class Initialized
INFO - 2023-06-01 02:35:22 --> Router Class Initialized
INFO - 2023-06-01 02:35:22 --> Output Class Initialized
INFO - 2023-06-01 02:35:22 --> Security Class Initialized
DEBUG - 2023-06-01 02:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:35:22 --> Input Class Initialized
INFO - 2023-06-01 02:35:22 --> Language Class Initialized
INFO - 2023-06-01 02:35:22 --> Loader Class Initialized
INFO - 2023-06-01 02:35:22 --> Controller Class Initialized
DEBUG - 2023-06-01 02:35:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:35:22 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:35:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:35:23 --> Model "Login_model" initialized
INFO - 2023-06-01 02:35:23 --> Final output sent to browser
DEBUG - 2023-06-01 02:35:23 --> Total execution time: 0.6291
INFO - 2023-06-01 02:36:10 --> Config Class Initialized
INFO - 2023-06-01 02:36:10 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:36:10 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:36:10 --> Utf8 Class Initialized
INFO - 2023-06-01 02:36:10 --> URI Class Initialized
INFO - 2023-06-01 02:36:10 --> Router Class Initialized
INFO - 2023-06-01 02:36:10 --> Output Class Initialized
INFO - 2023-06-01 02:36:10 --> Security Class Initialized
DEBUG - 2023-06-01 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:36:10 --> Input Class Initialized
INFO - 2023-06-01 02:36:10 --> Language Class Initialized
ERROR - 2023-06-01 02:36:10 --> 404 Page Not Found: user/Cluster/CdcDelete
INFO - 2023-06-01 02:39:35 --> Config Class Initialized
INFO - 2023-06-01 02:39:35 --> Config Class Initialized
INFO - 2023-06-01 02:39:35 --> Config Class Initialized
INFO - 2023-06-01 02:39:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:39:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:39:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:39:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:39:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:35 --> URI Class Initialized
INFO - 2023-06-01 02:39:35 --> URI Class Initialized
INFO - 2023-06-01 02:39:35 --> URI Class Initialized
INFO - 2023-06-01 02:39:35 --> Router Class Initialized
INFO - 2023-06-01 02:39:35 --> Router Class Initialized
INFO - 2023-06-01 02:39:35 --> Router Class Initialized
INFO - 2023-06-01 02:39:35 --> Output Class Initialized
INFO - 2023-06-01 02:39:35 --> Output Class Initialized
INFO - 2023-06-01 02:39:35 --> Output Class Initialized
INFO - 2023-06-01 02:39:35 --> Security Class Initialized
INFO - 2023-06-01 02:39:35 --> Security Class Initialized
INFO - 2023-06-01 02:39:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:39:35 --> Input Class Initialized
INFO - 2023-06-01 02:39:35 --> Input Class Initialized
INFO - 2023-06-01 02:39:35 --> Input Class Initialized
INFO - 2023-06-01 02:39:35 --> Language Class Initialized
INFO - 2023-06-01 02:39:35 --> Language Class Initialized
INFO - 2023-06-01 02:39:35 --> Language Class Initialized
INFO - 2023-06-01 02:39:35 --> Loader Class Initialized
INFO - 2023-06-01 02:39:35 --> Loader Class Initialized
INFO - 2023-06-01 02:39:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:35 --> Loader Class Initialized
INFO - 2023-06-01 02:39:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:35 --> Final output sent to browser
INFO - 2023-06-01 02:39:35 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 02:39:35 --> Total execution time: 0.2329
INFO - 2023-06-01 02:39:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:39:35 --> Total execution time: 0.2361
INFO - 2023-06-01 02:39:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:35 --> Config Class Initialized
INFO - 2023-06-01 02:39:35 --> Config Class Initialized
INFO - 2023-06-01 02:39:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:39:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:39:36 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:39:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:36 --> URI Class Initialized
INFO - 2023-06-01 02:39:36 --> URI Class Initialized
INFO - 2023-06-01 02:39:36 --> Router Class Initialized
INFO - 2023-06-01 02:39:36 --> Router Class Initialized
INFO - 2023-06-01 02:39:36 --> Output Class Initialized
INFO - 2023-06-01 02:39:36 --> Output Class Initialized
INFO - 2023-06-01 02:39:36 --> Final output sent to browser
INFO - 2023-06-01 02:39:36 --> Security Class Initialized
INFO - 2023-06-01 02:39:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Total execution time: 0.3456
DEBUG - 2023-06-01 02:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:39:36 --> Input Class Initialized
INFO - 2023-06-01 02:39:36 --> Input Class Initialized
INFO - 2023-06-01 02:39:36 --> Language Class Initialized
INFO - 2023-06-01 02:39:36 --> Language Class Initialized
INFO - 2023-06-01 02:39:36 --> Loader Class Initialized
INFO - 2023-06-01 02:39:36 --> Loader Class Initialized
INFO - 2023-06-01 02:39:36 --> Config Class Initialized
INFO - 2023-06-01 02:39:36 --> Controller Class Initialized
INFO - 2023-06-01 02:39:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:36 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:39:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:36 --> URI Class Initialized
INFO - 2023-06-01 02:39:36 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:36 --> Router Class Initialized
INFO - 2023-06-01 02:39:36 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:36 --> Output Class Initialized
INFO - 2023-06-01 02:39:36 --> Final output sent to browser
INFO - 2023-06-01 02:39:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Total execution time: 0.2396
DEBUG - 2023-06-01 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:39:36 --> Input Class Initialized
INFO - 2023-06-01 02:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:36 --> Language Class Initialized
INFO - 2023-06-01 02:39:36 --> Final output sent to browser
INFO - 2023-06-01 02:39:36 --> Loader Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Total execution time: 0.3032
INFO - 2023-06-01 02:39:36 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:36 --> Config Class Initialized
INFO - 2023-06-01 02:39:36 --> Hooks Class Initialized
INFO - 2023-06-01 02:39:36 --> Database Driver Class Initialized
DEBUG - 2023-06-01 02:39:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:36 --> URI Class Initialized
INFO - 2023-06-01 02:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:36 --> Final output sent to browser
DEBUG - 2023-06-01 02:39:36 --> Total execution time: 0.2896
INFO - 2023-06-01 02:39:36 --> Router Class Initialized
INFO - 2023-06-01 02:39:36 --> Output Class Initialized
INFO - 2023-06-01 02:39:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:39:36 --> Input Class Initialized
INFO - 2023-06-01 02:39:36 --> Language Class Initialized
INFO - 2023-06-01 02:39:36 --> Loader Class Initialized
INFO - 2023-06-01 02:39:36 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:36 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:39:36 --> Config Class Initialized
INFO - 2023-06-01 02:39:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:39:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:39:36 --> URI Class Initialized
INFO - 2023-06-01 02:39:36 --> Router Class Initialized
INFO - 2023-06-01 02:39:36 --> Output Class Initialized
INFO - 2023-06-01 02:39:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:39:37 --> Input Class Initialized
INFO - 2023-06-01 02:39:37 --> Language Class Initialized
INFO - 2023-06-01 02:39:37 --> Loader Class Initialized
INFO - 2023-06-01 02:39:37 --> Controller Class Initialized
DEBUG - 2023-06-01 02:39:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:39:37 --> Database Driver Class Initialized
INFO - 2023-06-01 02:39:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:50:16 --> Config Class Initialized
INFO - 2023-06-01 02:50:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 02:50:17 --> URI Class Initialized
INFO - 2023-06-01 02:50:17 --> Router Class Initialized
INFO - 2023-06-01 02:50:17 --> Output Class Initialized
INFO - 2023-06-01 02:50:17 --> Security Class Initialized
DEBUG - 2023-06-01 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:50:17 --> Input Class Initialized
INFO - 2023-06-01 02:50:17 --> Language Class Initialized
INFO - 2023-06-01 02:50:17 --> Loader Class Initialized
INFO - 2023-06-01 02:50:17 --> Controller Class Initialized
DEBUG - 2023-06-01 02:50:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:50:17 --> Database Driver Class Initialized
INFO - 2023-06-01 02:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:50:17 --> Final output sent to browser
DEBUG - 2023-06-01 02:50:17 --> Total execution time: 0.2413
INFO - 2023-06-01 02:50:17 --> Config Class Initialized
INFO - 2023-06-01 02:50:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:50:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:50:17 --> Utf8 Class Initialized
INFO - 2023-06-01 02:50:17 --> URI Class Initialized
INFO - 2023-06-01 02:50:17 --> Router Class Initialized
INFO - 2023-06-01 02:50:17 --> Output Class Initialized
INFO - 2023-06-01 02:50:17 --> Security Class Initialized
DEBUG - 2023-06-01 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:50:17 --> Input Class Initialized
INFO - 2023-06-01 02:50:17 --> Language Class Initialized
INFO - 2023-06-01 02:50:17 --> Loader Class Initialized
INFO - 2023-06-01 02:50:17 --> Controller Class Initialized
DEBUG - 2023-06-01 02:50:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:50:17 --> Database Driver Class Initialized
INFO - 2023-06-01 02:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:50:17 --> Final output sent to browser
DEBUG - 2023-06-01 02:50:17 --> Total execution time: 0.7486
INFO - 2023-06-01 02:50:22 --> Config Class Initialized
INFO - 2023-06-01 02:50:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:50:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:50:23 --> Utf8 Class Initialized
INFO - 2023-06-01 02:50:23 --> URI Class Initialized
INFO - 2023-06-01 02:50:23 --> Router Class Initialized
INFO - 2023-06-01 02:50:23 --> Output Class Initialized
INFO - 2023-06-01 02:50:23 --> Security Class Initialized
DEBUG - 2023-06-01 02:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:50:23 --> Input Class Initialized
INFO - 2023-06-01 02:50:23 --> Language Class Initialized
INFO - 2023-06-01 02:50:23 --> Loader Class Initialized
INFO - 2023-06-01 02:50:23 --> Controller Class Initialized
DEBUG - 2023-06-01 02:50:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:50:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:50:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:50:23 --> Final output sent to browser
DEBUG - 2023-06-01 02:50:23 --> Total execution time: 0.4285
INFO - 2023-06-01 02:50:23 --> Config Class Initialized
INFO - 2023-06-01 02:50:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:50:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:50:23 --> Utf8 Class Initialized
INFO - 2023-06-01 02:50:23 --> URI Class Initialized
INFO - 2023-06-01 02:50:23 --> Router Class Initialized
INFO - 2023-06-01 02:50:23 --> Output Class Initialized
INFO - 2023-06-01 02:50:23 --> Security Class Initialized
DEBUG - 2023-06-01 02:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:50:23 --> Input Class Initialized
INFO - 2023-06-01 02:50:23 --> Language Class Initialized
INFO - 2023-06-01 02:50:23 --> Loader Class Initialized
INFO - 2023-06-01 02:50:23 --> Controller Class Initialized
DEBUG - 2023-06-01 02:50:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:50:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:50:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:50:24 --> Final output sent to browser
DEBUG - 2023-06-01 02:50:24 --> Total execution time: 0.9662
INFO - 2023-06-01 02:51:34 --> Config Class Initialized
INFO - 2023-06-01 02:51:34 --> Config Class Initialized
INFO - 2023-06-01 02:51:34 --> Config Class Initialized
INFO - 2023-06-01 02:51:34 --> Hooks Class Initialized
INFO - 2023-06-01 02:51:34 --> Hooks Class Initialized
INFO - 2023-06-01 02:51:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:51:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:51:34 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:34 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:34 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:34 --> URI Class Initialized
INFO - 2023-06-01 02:51:34 --> URI Class Initialized
INFO - 2023-06-01 02:51:34 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.1970
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.1963
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.2115
INFO - 2023-06-01 02:51:35 --> Config Class Initialized
INFO - 2023-06-01 02:51:35 --> Config Class Initialized
INFO - 2023-06-01 02:51:35 --> Config Class Initialized
INFO - 2023-06-01 02:51:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:51:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:51:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:51:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:51:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:35 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.2074
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.2075
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:51:35 --> Total execution time: 0.2410
INFO - 2023-06-01 02:51:35 --> Config Class Initialized
INFO - 2023-06-01 02:51:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:51:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:51:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:35 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:51:35 --> Config Class Initialized
INFO - 2023-06-01 02:51:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:51:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:51:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:51:35 --> URI Class Initialized
INFO - 2023-06-01 02:51:35 --> Router Class Initialized
INFO - 2023-06-01 02:51:35 --> Output Class Initialized
INFO - 2023-06-01 02:51:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:51:35 --> Input Class Initialized
INFO - 2023-06-01 02:51:35 --> Language Class Initialized
INFO - 2023-06-01 02:51:35 --> Loader Class Initialized
INFO - 2023-06-01 02:51:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:51:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:51:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:51:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:15 --> Config Class Initialized
INFO - 2023-06-01 02:53:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:15 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:15 --> URI Class Initialized
INFO - 2023-06-01 02:53:15 --> Router Class Initialized
INFO - 2023-06-01 02:53:15 --> Output Class Initialized
INFO - 2023-06-01 02:53:15 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:15 --> Input Class Initialized
INFO - 2023-06-01 02:53:15 --> Language Class Initialized
INFO - 2023-06-01 02:53:15 --> Loader Class Initialized
INFO - 2023-06-01 02:53:15 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:15 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:16 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:16 --> Total execution time: 0.5086
INFO - 2023-06-01 02:53:16 --> Config Class Initialized
INFO - 2023-06-01 02:53:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:16 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:16 --> URI Class Initialized
INFO - 2023-06-01 02:53:16 --> Router Class Initialized
INFO - 2023-06-01 02:53:16 --> Output Class Initialized
INFO - 2023-06-01 02:53:16 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:16 --> Input Class Initialized
INFO - 2023-06-01 02:53:16 --> Language Class Initialized
INFO - 2023-06-01 02:53:16 --> Loader Class Initialized
INFO - 2023-06-01 02:53:16 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:16 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:16 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:16 --> Total execution time: 0.3120
INFO - 2023-06-01 02:53:20 --> Config Class Initialized
INFO - 2023-06-01 02:53:20 --> Config Class Initialized
INFO - 2023-06-01 02:53:20 --> Config Class Initialized
INFO - 2023-06-01 02:53:20 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:20 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:20 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:20 --> URI Class Initialized
INFO - 2023-06-01 02:53:20 --> URI Class Initialized
INFO - 2023-06-01 02:53:20 --> URI Class Initialized
INFO - 2023-06-01 02:53:20 --> Router Class Initialized
INFO - 2023-06-01 02:53:20 --> Router Class Initialized
INFO - 2023-06-01 02:53:20 --> Router Class Initialized
INFO - 2023-06-01 02:53:20 --> Output Class Initialized
INFO - 2023-06-01 02:53:20 --> Output Class Initialized
INFO - 2023-06-01 02:53:20 --> Output Class Initialized
INFO - 2023-06-01 02:53:20 --> Security Class Initialized
INFO - 2023-06-01 02:53:20 --> Security Class Initialized
INFO - 2023-06-01 02:53:20 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:20 --> Input Class Initialized
INFO - 2023-06-01 02:53:20 --> Input Class Initialized
INFO - 2023-06-01 02:53:20 --> Input Class Initialized
INFO - 2023-06-01 02:53:20 --> Language Class Initialized
INFO - 2023-06-01 02:53:20 --> Language Class Initialized
INFO - 2023-06-01 02:53:20 --> Language Class Initialized
INFO - 2023-06-01 02:53:20 --> Loader Class Initialized
INFO - 2023-06-01 02:53:20 --> Loader Class Initialized
INFO - 2023-06-01 02:53:20 --> Loader Class Initialized
INFO - 2023-06-01 02:53:20 --> Controller Class Initialized
INFO - 2023-06-01 02:53:20 --> Controller Class Initialized
INFO - 2023-06-01 02:53:20 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:20 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2040
INFO - 2023-06-01 02:53:21 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2352
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2443
INFO - 2023-06-01 02:53:21 --> Config Class Initialized
INFO - 2023-06-01 02:53:21 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:21 --> Config Class Initialized
INFO - 2023-06-01 02:53:21 --> Config Class Initialized
INFO - 2023-06-01 02:53:21 --> Config Class Initialized
INFO - 2023-06-01 02:53:21 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:21 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:21 --> Utf8 Class Initialized
DEBUG - 2023-06-01 02:53:21 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:21 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:21 --> URI Class Initialized
INFO - 2023-06-01 02:53:21 --> URI Class Initialized
INFO - 2023-06-01 02:53:21 --> URI Class Initialized
INFO - 2023-06-01 02:53:21 --> URI Class Initialized
INFO - 2023-06-01 02:53:21 --> Router Class Initialized
INFO - 2023-06-01 02:53:21 --> Router Class Initialized
INFO - 2023-06-01 02:53:21 --> Router Class Initialized
INFO - 2023-06-01 02:53:21 --> Router Class Initialized
INFO - 2023-06-01 02:53:21 --> Output Class Initialized
INFO - 2023-06-01 02:53:21 --> Output Class Initialized
INFO - 2023-06-01 02:53:21 --> Output Class Initialized
INFO - 2023-06-01 02:53:21 --> Output Class Initialized
INFO - 2023-06-01 02:53:21 --> Security Class Initialized
INFO - 2023-06-01 02:53:21 --> Security Class Initialized
INFO - 2023-06-01 02:53:21 --> Security Class Initialized
INFO - 2023-06-01 02:53:21 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:21 --> Input Class Initialized
INFO - 2023-06-01 02:53:21 --> Input Class Initialized
INFO - 2023-06-01 02:53:21 --> Input Class Initialized
INFO - 2023-06-01 02:53:21 --> Input Class Initialized
INFO - 2023-06-01 02:53:21 --> Language Class Initialized
INFO - 2023-06-01 02:53:21 --> Language Class Initialized
INFO - 2023-06-01 02:53:21 --> Language Class Initialized
INFO - 2023-06-01 02:53:21 --> Language Class Initialized
INFO - 2023-06-01 02:53:21 --> Loader Class Initialized
INFO - 2023-06-01 02:53:21 --> Loader Class Initialized
INFO - 2023-06-01 02:53:21 --> Loader Class Initialized
INFO - 2023-06-01 02:53:21 --> Loader Class Initialized
INFO - 2023-06-01 02:53:21 --> Controller Class Initialized
INFO - 2023-06-01 02:53:21 --> Controller Class Initialized
INFO - 2023-06-01 02:53:21 --> Controller Class Initialized
INFO - 2023-06-01 02:53:21 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2585
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2833
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.3240
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.3167
INFO - 2023-06-01 02:53:21 --> Config Class Initialized
INFO - 2023-06-01 02:53:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:21 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:21 --> URI Class Initialized
INFO - 2023-06-01 02:53:21 --> Router Class Initialized
INFO - 2023-06-01 02:53:21 --> Output Class Initialized
INFO - 2023-06-01 02:53:21 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:21 --> Input Class Initialized
INFO - 2023-06-01 02:53:21 --> Language Class Initialized
INFO - 2023-06-01 02:53:21 --> Loader Class Initialized
INFO - 2023-06-01 02:53:21 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:21 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:21 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:21 --> Total execution time: 0.2635
INFO - 2023-06-01 02:53:22 --> Config Class Initialized
INFO - 2023-06-01 02:53:22 --> Config Class Initialized
INFO - 2023-06-01 02:53:22 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:22 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:22 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:22 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:22 --> URI Class Initialized
INFO - 2023-06-01 02:53:22 --> URI Class Initialized
INFO - 2023-06-01 02:53:22 --> Router Class Initialized
INFO - 2023-06-01 02:53:22 --> Router Class Initialized
INFO - 2023-06-01 02:53:22 --> Output Class Initialized
INFO - 2023-06-01 02:53:22 --> Output Class Initialized
INFO - 2023-06-01 02:53:22 --> Security Class Initialized
INFO - 2023-06-01 02:53:22 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:22 --> Input Class Initialized
INFO - 2023-06-01 02:53:22 --> Input Class Initialized
INFO - 2023-06-01 02:53:22 --> Language Class Initialized
INFO - 2023-06-01 02:53:22 --> Language Class Initialized
INFO - 2023-06-01 02:53:22 --> Loader Class Initialized
INFO - 2023-06-01 02:53:22 --> Loader Class Initialized
INFO - 2023-06-01 02:53:22 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:22 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:22 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:22 --> Total execution time: 0.1459
INFO - 2023-06-01 02:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:23 --> Config Class Initialized
INFO - 2023-06-01 02:53:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:23 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:23 --> URI Class Initialized
INFO - 2023-06-01 02:53:23 --> Router Class Initialized
INFO - 2023-06-01 02:53:23 --> Output Class Initialized
INFO - 2023-06-01 02:53:23 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:23 --> Input Class Initialized
INFO - 2023-06-01 02:53:23 --> Language Class Initialized
INFO - 2023-06-01 02:53:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:23 --> Loader Class Initialized
INFO - 2023-06-01 02:53:23 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:23 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:23 --> Total execution time: 0.3553
INFO - 2023-06-01 02:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:23 --> Config Class Initialized
INFO - 2023-06-01 02:53:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:23 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:23 --> URI Class Initialized
INFO - 2023-06-01 02:53:23 --> Router Class Initialized
INFO - 2023-06-01 02:53:23 --> Output Class Initialized
INFO - 2023-06-01 02:53:23 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:23 --> Input Class Initialized
INFO - 2023-06-01 02:53:23 --> Language Class Initialized
INFO - 2023-06-01 02:53:23 --> Loader Class Initialized
INFO - 2023-06-01 02:53:23 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:23 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:23 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:23 --> Total execution time: 0.2356
INFO - 2023-06-01 02:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:23 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:23 --> Total execution time: 0.4811
INFO - 2023-06-01 02:53:25 --> Config Class Initialized
INFO - 2023-06-01 02:53:25 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:25 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:25 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:25 --> URI Class Initialized
INFO - 2023-06-01 02:53:25 --> Router Class Initialized
INFO - 2023-06-01 02:53:25 --> Output Class Initialized
INFO - 2023-06-01 02:53:25 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:25 --> Input Class Initialized
INFO - 2023-06-01 02:53:25 --> Language Class Initialized
INFO - 2023-06-01 02:53:25 --> Loader Class Initialized
INFO - 2023-06-01 02:53:25 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:26 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:26 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:26 --> Total execution time: 0.3460
INFO - 2023-06-01 02:53:26 --> Config Class Initialized
INFO - 2023-06-01 02:53:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:26 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:26 --> URI Class Initialized
INFO - 2023-06-01 02:53:26 --> Router Class Initialized
INFO - 2023-06-01 02:53:26 --> Output Class Initialized
INFO - 2023-06-01 02:53:26 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:26 --> Input Class Initialized
INFO - 2023-06-01 02:53:26 --> Language Class Initialized
INFO - 2023-06-01 02:53:26 --> Loader Class Initialized
INFO - 2023-06-01 02:53:26 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:26 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:26 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:26 --> Total execution time: 0.1968
INFO - 2023-06-01 02:53:27 --> Config Class Initialized
INFO - 2023-06-01 02:53:27 --> Config Class Initialized
INFO - 2023-06-01 02:53:27 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:27 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:27 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:27 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:27 --> URI Class Initialized
INFO - 2023-06-01 02:53:27 --> URI Class Initialized
INFO - 2023-06-01 02:53:27 --> Router Class Initialized
INFO - 2023-06-01 02:53:27 --> Router Class Initialized
INFO - 2023-06-01 02:53:27 --> Output Class Initialized
INFO - 2023-06-01 02:53:27 --> Output Class Initialized
INFO - 2023-06-01 02:53:27 --> Security Class Initialized
INFO - 2023-06-01 02:53:27 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:27 --> Input Class Initialized
INFO - 2023-06-01 02:53:27 --> Input Class Initialized
INFO - 2023-06-01 02:53:27 --> Language Class Initialized
INFO - 2023-06-01 02:53:27 --> Language Class Initialized
INFO - 2023-06-01 02:53:27 --> Loader Class Initialized
INFO - 2023-06-01 02:53:27 --> Loader Class Initialized
INFO - 2023-06-01 02:53:27 --> Controller Class Initialized
INFO - 2023-06-01 02:53:27 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:27 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:27 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:27 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:27 --> Total execution time: 0.2849
INFO - 2023-06-01 02:53:27 --> Config Class Initialized
INFO - 2023-06-01 02:53:27 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.3437
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
INFO - 2023-06-01 02:53:28 --> Config Class Initialized
INFO - 2023-06-01 02:53:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
INFO - 2023-06-01 02:53:28 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Config Class Initialized
INFO - 2023-06-01 02:53:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
INFO - 2023-06-01 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.3388
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
INFO - 2023-06-01 02:53:28 --> Config Class Initialized
INFO - 2023-06-01 02:53:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.3723
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.3011
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.2117
INFO - 2023-06-01 02:53:28 --> Config Class Initialized
INFO - 2023-06-01 02:53:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Config Class Initialized
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
DEBUG - 2023-06-01 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
INFO - 2023-06-01 02:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:28 --> URI Class Initialized
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Router Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
INFO - 2023-06-01 02:53:28 --> Output Class Initialized
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:28 --> Input Class Initialized
INFO - 2023-06-01 02:53:28 --> Language Class Initialized
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
INFO - 2023-06-01 02:53:28 --> Loader Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
INFO - 2023-06-01 02:53:28 --> Model "Login_model" initialized
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.2678
INFO - 2023-06-01 02:53:28 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:28 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:28 --> Total execution time: 0.2901
INFO - 2023-06-01 02:53:34 --> Config Class Initialized
INFO - 2023-06-01 02:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:34 --> URI Class Initialized
INFO - 2023-06-01 02:53:34 --> Router Class Initialized
INFO - 2023-06-01 02:53:34 --> Output Class Initialized
INFO - 2023-06-01 02:53:34 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:34 --> Input Class Initialized
INFO - 2023-06-01 02:53:34 --> Language Class Initialized
INFO - 2023-06-01 02:53:34 --> Loader Class Initialized
INFO - 2023-06-01 02:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:34 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:34 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:34 --> Total execution time: 0.2567
INFO - 2023-06-01 02:53:34 --> Config Class Initialized
INFO - 2023-06-01 02:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:34 --> URI Class Initialized
INFO - 2023-06-01 02:53:34 --> Router Class Initialized
INFO - 2023-06-01 02:53:34 --> Output Class Initialized
INFO - 2023-06-01 02:53:34 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:34 --> Input Class Initialized
INFO - 2023-06-01 02:53:34 --> Language Class Initialized
INFO - 2023-06-01 02:53:34 --> Loader Class Initialized
INFO - 2023-06-01 02:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:35 --> Total execution time: 0.2763
INFO - 2023-06-01 02:53:35 --> Config Class Initialized
INFO - 2023-06-01 02:53:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:35 --> Config Class Initialized
INFO - 2023-06-01 02:53:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:35 --> URI Class Initialized
DEBUG - 2023-06-01 02:53:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:35 --> Router Class Initialized
INFO - 2023-06-01 02:53:35 --> URI Class Initialized
INFO - 2023-06-01 02:53:35 --> Output Class Initialized
INFO - 2023-06-01 02:53:35 --> Security Class Initialized
INFO - 2023-06-01 02:53:35 --> Router Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:35 --> Output Class Initialized
INFO - 2023-06-01 02:53:35 --> Input Class Initialized
INFO - 2023-06-01 02:53:35 --> Language Class Initialized
INFO - 2023-06-01 02:53:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:35 --> Input Class Initialized
INFO - 2023-06-01 02:53:35 --> Language Class Initialized
INFO - 2023-06-01 02:53:35 --> Loader Class Initialized
INFO - 2023-06-01 02:53:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:35 --> Loader Class Initialized
INFO - 2023-06-01 02:53:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:35 --> Total execution time: 0.1990
INFO - 2023-06-01 02:53:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:35 --> Config Class Initialized
INFO - 2023-06-01 02:53:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:35 --> Total execution time: 0.2530
INFO - 2023-06-01 02:53:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:35 --> URI Class Initialized
INFO - 2023-06-01 02:53:35 --> Router Class Initialized
INFO - 2023-06-01 02:53:35 --> Output Class Initialized
INFO - 2023-06-01 02:53:35 --> Config Class Initialized
INFO - 2023-06-01 02:53:35 --> Security Class Initialized
INFO - 2023-06-01 02:53:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:35 --> Input Class Initialized
INFO - 2023-06-01 02:53:35 --> Language Class Initialized
DEBUG - 2023-06-01 02:53:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:35 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:35 --> URI Class Initialized
INFO - 2023-06-01 02:53:35 --> Loader Class Initialized
INFO - 2023-06-01 02:53:35 --> Controller Class Initialized
INFO - 2023-06-01 02:53:35 --> Router Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:35 --> Output Class Initialized
INFO - 2023-06-01 02:53:35 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:35 --> Input Class Initialized
INFO - 2023-06-01 02:53:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Language Class Initialized
INFO - 2023-06-01 02:53:35 --> Loader Class Initialized
INFO - 2023-06-01 02:53:35 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:35 --> Model "Login_model" initialized
INFO - 2023-06-01 02:53:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:35 --> Total execution time: 0.2629
INFO - 2023-06-01 02:53:35 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:35 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:35 --> Total execution time: 0.4864
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:40 --> Final output sent to browser
INFO - 2023-06-01 02:53:40 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:40 --> Total execution time: 0.2020
DEBUG - 2023-06-01 02:53:40 --> Total execution time: 0.2016
INFO - 2023-06-01 02:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:40 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:40 --> Total execution time: 0.2079
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
INFO - 2023-06-01 02:53:40 --> Config Class Initialized
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
DEBUG - 2023-06-01 02:53:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:40 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
INFO - 2023-06-01 02:53:40 --> URI Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
INFO - 2023-06-01 02:53:40 --> Router Class Initialized
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Output Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
INFO - 2023-06-01 02:53:40 --> Security Class Initialized
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
INFO - 2023-06-01 02:53:40 --> Input Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:40 --> Language Class Initialized
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:40 --> Loader Class Initialized
INFO - 2023-06-01 02:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:40 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:40 --> Final output sent to browser
INFO - 2023-06-01 02:53:40 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:40 --> Total execution time: 0.2287
DEBUG - 2023-06-01 02:53:40 --> Total execution time: 0.2303
INFO - 2023-06-01 02:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:41 --> Config Class Initialized
INFO - 2023-06-01 02:53:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:41 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:41 --> URI Class Initialized
INFO - 2023-06-01 02:53:41 --> Router Class Initialized
INFO - 2023-06-01 02:53:41 --> Output Class Initialized
INFO - 2023-06-01 02:53:41 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:41 --> Input Class Initialized
INFO - 2023-06-01 02:53:41 --> Language Class Initialized
INFO - 2023-06-01 02:53:41 --> Loader Class Initialized
INFO - 2023-06-01 02:53:41 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:41 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:53:41 --> Final output sent to browser
DEBUG - 2023-06-01 02:53:41 --> Total execution time: 0.5104
INFO - 2023-06-01 02:53:41 --> Config Class Initialized
INFO - 2023-06-01 02:53:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:53:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:53:41 --> Utf8 Class Initialized
INFO - 2023-06-01 02:53:41 --> URI Class Initialized
INFO - 2023-06-01 02:53:41 --> Router Class Initialized
INFO - 2023-06-01 02:53:41 --> Output Class Initialized
INFO - 2023-06-01 02:53:41 --> Security Class Initialized
DEBUG - 2023-06-01 02:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:53:41 --> Input Class Initialized
INFO - 2023-06-01 02:53:41 --> Language Class Initialized
INFO - 2023-06-01 02:53:41 --> Loader Class Initialized
INFO - 2023-06-01 02:53:41 --> Controller Class Initialized
DEBUG - 2023-06-01 02:53:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:53:41 --> Database Driver Class Initialized
INFO - 2023-06-01 02:53:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:28 --> Config Class Initialized
INFO - 2023-06-01 02:59:28 --> Config Class Initialized
INFO - 2023-06-01 02:59:28 --> Config Class Initialized
INFO - 2023-06-01 02:59:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:59:28 --> Hooks Class Initialized
INFO - 2023-06-01 02:59:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:59:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:59:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:59:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:28 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:28 --> URI Class Initialized
INFO - 2023-06-01 02:59:28 --> URI Class Initialized
INFO - 2023-06-01 02:59:28 --> URI Class Initialized
INFO - 2023-06-01 02:59:28 --> Router Class Initialized
INFO - 2023-06-01 02:59:28 --> Router Class Initialized
INFO - 2023-06-01 02:59:28 --> Router Class Initialized
INFO - 2023-06-01 02:59:28 --> Output Class Initialized
INFO - 2023-06-01 02:59:28 --> Output Class Initialized
INFO - 2023-06-01 02:59:28 --> Output Class Initialized
INFO - 2023-06-01 02:59:28 --> Security Class Initialized
INFO - 2023-06-01 02:59:28 --> Security Class Initialized
INFO - 2023-06-01 02:59:28 --> Security Class Initialized
DEBUG - 2023-06-01 02:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:28 --> Input Class Initialized
INFO - 2023-06-01 02:59:28 --> Input Class Initialized
INFO - 2023-06-01 02:59:28 --> Input Class Initialized
INFO - 2023-06-01 02:59:28 --> Language Class Initialized
INFO - 2023-06-01 02:59:28 --> Language Class Initialized
INFO - 2023-06-01 02:59:28 --> Language Class Initialized
INFO - 2023-06-01 02:59:28 --> Loader Class Initialized
INFO - 2023-06-01 02:59:28 --> Loader Class Initialized
INFO - 2023-06-01 02:59:28 --> Loader Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Model "Login_model" initialized
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.2553
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
INFO - 2023-06-01 02:59:29 --> Config Class Initialized
INFO - 2023-06-01 02:59:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.3162
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.3292
DEBUG - 2023-06-01 02:59:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:29 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:29 --> URI Class Initialized
INFO - 2023-06-01 02:59:29 --> Config Class Initialized
INFO - 2023-06-01 02:59:29 --> Config Class Initialized
INFO - 2023-06-01 02:59:29 --> Router Class Initialized
INFO - 2023-06-01 02:59:29 --> Hooks Class Initialized
INFO - 2023-06-01 02:59:29 --> Hooks Class Initialized
INFO - 2023-06-01 02:59:29 --> Output Class Initialized
DEBUG - 2023-06-01 02:59:29 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:59:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:29 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:29 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:29 --> Security Class Initialized
INFO - 2023-06-01 02:59:29 --> URI Class Initialized
INFO - 2023-06-01 02:59:29 --> URI Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:29 --> Input Class Initialized
INFO - 2023-06-01 02:59:29 --> Router Class Initialized
INFO - 2023-06-01 02:59:29 --> Router Class Initialized
INFO - 2023-06-01 02:59:29 --> Language Class Initialized
INFO - 2023-06-01 02:59:29 --> Output Class Initialized
INFO - 2023-06-01 02:59:29 --> Output Class Initialized
INFO - 2023-06-01 02:59:29 --> Security Class Initialized
INFO - 2023-06-01 02:59:29 --> Security Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:29 --> Input Class Initialized
INFO - 2023-06-01 02:59:29 --> Input Class Initialized
INFO - 2023-06-01 02:59:29 --> Loader Class Initialized
INFO - 2023-06-01 02:59:29 --> Language Class Initialized
INFO - 2023-06-01 02:59:29 --> Language Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
INFO - 2023-06-01 02:59:29 --> Loader Class Initialized
INFO - 2023-06-01 02:59:29 --> Loader Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Model "Login_model" initialized
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.2385
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.3054
INFO - 2023-06-01 02:59:29 --> Config Class Initialized
INFO - 2023-06-01 02:59:29 --> Hooks Class Initialized
INFO - 2023-06-01 02:59:29 --> Config Class Initialized
INFO - 2023-06-01 02:59:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:59:29 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 02:59:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:29 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:29 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:29 --> URI Class Initialized
INFO - 2023-06-01 02:59:29 --> URI Class Initialized
INFO - 2023-06-01 02:59:29 --> Router Class Initialized
INFO - 2023-06-01 02:59:29 --> Router Class Initialized
INFO - 2023-06-01 02:59:29 --> Output Class Initialized
INFO - 2023-06-01 02:59:29 --> Output Class Initialized
INFO - 2023-06-01 02:59:29 --> Security Class Initialized
INFO - 2023-06-01 02:59:29 --> Security Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
INFO - 2023-06-01 02:59:29 --> Input Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.3634
INFO - 2023-06-01 02:59:29 --> Input Class Initialized
INFO - 2023-06-01 02:59:29 --> Language Class Initialized
INFO - 2023-06-01 02:59:29 --> Language Class Initialized
INFO - 2023-06-01 02:59:29 --> Loader Class Initialized
INFO - 2023-06-01 02:59:29 --> Loader Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
INFO - 2023-06-01 02:59:29 --> Controller Class Initialized
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 02:59:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.2837
INFO - 2023-06-01 02:59:29 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:29 --> Total execution time: 0.2897
INFO - 2023-06-01 02:59:36 --> Config Class Initialized
INFO - 2023-06-01 02:59:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:59:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:36 --> URI Class Initialized
INFO - 2023-06-01 02:59:36 --> Router Class Initialized
INFO - 2023-06-01 02:59:36 --> Output Class Initialized
INFO - 2023-06-01 02:59:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:36 --> Input Class Initialized
INFO - 2023-06-01 02:59:36 --> Language Class Initialized
INFO - 2023-06-01 02:59:36 --> Loader Class Initialized
INFO - 2023-06-01 02:59:36 --> Controller Class Initialized
DEBUG - 2023-06-01 02:59:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:36 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:36 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:36 --> Total execution time: 0.2016
INFO - 2023-06-01 02:59:36 --> Config Class Initialized
INFO - 2023-06-01 02:59:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 02:59:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 02:59:36 --> Utf8 Class Initialized
INFO - 2023-06-01 02:59:36 --> URI Class Initialized
INFO - 2023-06-01 02:59:36 --> Router Class Initialized
INFO - 2023-06-01 02:59:36 --> Output Class Initialized
INFO - 2023-06-01 02:59:36 --> Security Class Initialized
DEBUG - 2023-06-01 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 02:59:36 --> Input Class Initialized
INFO - 2023-06-01 02:59:36 --> Language Class Initialized
INFO - 2023-06-01 02:59:36 --> Loader Class Initialized
INFO - 2023-06-01 02:59:36 --> Controller Class Initialized
DEBUG - 2023-06-01 02:59:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 02:59:36 --> Database Driver Class Initialized
INFO - 2023-06-01 02:59:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 02:59:36 --> Final output sent to browser
DEBUG - 2023-06-01 02:59:36 --> Total execution time: 0.2168
INFO - 2023-06-01 03:13:35 --> Config Class Initialized
INFO - 2023-06-01 03:13:35 --> Config Class Initialized
INFO - 2023-06-01 03:13:35 --> Hooks Class Initialized
INFO - 2023-06-01 03:13:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:13:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:35 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:35 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:35 --> URI Class Initialized
INFO - 2023-06-01 03:13:35 --> URI Class Initialized
INFO - 2023-06-01 03:13:35 --> Router Class Initialized
INFO - 2023-06-01 03:13:35 --> Router Class Initialized
INFO - 2023-06-01 03:13:35 --> Output Class Initialized
INFO - 2023-06-01 03:13:35 --> Output Class Initialized
INFO - 2023-06-01 03:13:35 --> Security Class Initialized
INFO - 2023-06-01 03:13:35 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:35 --> Input Class Initialized
INFO - 2023-06-01 03:13:35 --> Input Class Initialized
INFO - 2023-06-01 03:13:35 --> Language Class Initialized
INFO - 2023-06-01 03:13:35 --> Language Class Initialized
INFO - 2023-06-01 03:13:35 --> Loader Class Initialized
INFO - 2023-06-01 03:13:35 --> Loader Class Initialized
INFO - 2023-06-01 03:13:35 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:35 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:35 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:35 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:35 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:35 --> Total execution time: 0.2343
INFO - 2023-06-01 03:13:35 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:35 --> Model "Login_model" initialized
INFO - 2023-06-01 03:13:35 --> Config Class Initialized
INFO - 2023-06-01 03:13:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:35 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:35 --> URI Class Initialized
INFO - 2023-06-01 03:13:35 --> Router Class Initialized
INFO - 2023-06-01 03:13:35 --> Output Class Initialized
INFO - 2023-06-01 03:13:35 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:35 --> Input Class Initialized
INFO - 2023-06-01 03:13:35 --> Language Class Initialized
INFO - 2023-06-01 03:13:35 --> Loader Class Initialized
INFO - 2023-06-01 03:13:35 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:36 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:36 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:36 --> Total execution time: 0.3113
INFO - 2023-06-01 03:13:36 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:36 --> Total execution time: 0.6858
INFO - 2023-06-01 03:13:36 --> Config Class Initialized
INFO - 2023-06-01 03:13:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:36 --> URI Class Initialized
INFO - 2023-06-01 03:13:36 --> Router Class Initialized
INFO - 2023-06-01 03:13:36 --> Output Class Initialized
INFO - 2023-06-01 03:13:36 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:36 --> Input Class Initialized
INFO - 2023-06-01 03:13:36 --> Language Class Initialized
INFO - 2023-06-01 03:13:36 --> Loader Class Initialized
INFO - 2023-06-01 03:13:36 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:36 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:36 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:36 --> Model "Login_model" initialized
INFO - 2023-06-01 03:13:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:37 --> Total execution time: 0.9680
INFO - 2023-06-01 03:13:40 --> Config Class Initialized
INFO - 2023-06-01 03:13:40 --> Hooks Class Initialized
INFO - 2023-06-01 03:13:40 --> Config Class Initialized
INFO - 2023-06-01 03:13:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:40 --> Utf8 Class Initialized
DEBUG - 2023-06-01 03:13:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:40 --> URI Class Initialized
INFO - 2023-06-01 03:13:40 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:40 --> URI Class Initialized
INFO - 2023-06-01 03:13:40 --> Router Class Initialized
INFO - 2023-06-01 03:13:40 --> Router Class Initialized
INFO - 2023-06-01 03:13:40 --> Output Class Initialized
INFO - 2023-06-01 03:13:40 --> Output Class Initialized
INFO - 2023-06-01 03:13:40 --> Security Class Initialized
INFO - 2023-06-01 03:13:40 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:40 --> Input Class Initialized
DEBUG - 2023-06-01 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:40 --> Language Class Initialized
INFO - 2023-06-01 03:13:40 --> Input Class Initialized
INFO - 2023-06-01 03:13:40 --> Language Class Initialized
INFO - 2023-06-01 03:13:40 --> Loader Class Initialized
INFO - 2023-06-01 03:13:40 --> Loader Class Initialized
INFO - 2023-06-01 03:13:40 --> Controller Class Initialized
INFO - 2023-06-01 03:13:40 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:13:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:40 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:40 --> Total execution time: 0.3180
INFO - 2023-06-01 03:13:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:40 --> Config Class Initialized
INFO - 2023-06-01 03:13:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:40 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:40 --> URI Class Initialized
INFO - 2023-06-01 03:13:40 --> Router Class Initialized
INFO - 2023-06-01 03:13:40 --> Output Class Initialized
INFO - 2023-06-01 03:13:40 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:40 --> Input Class Initialized
INFO - 2023-06-01 03:13:40 --> Model "Login_model" initialized
INFO - 2023-06-01 03:13:40 --> Language Class Initialized
INFO - 2023-06-01 03:13:40 --> Loader Class Initialized
INFO - 2023-06-01 03:13:40 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:40 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:40 --> Total execution time: 0.4588
INFO - 2023-06-01 03:13:41 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:41 --> Total execution time: 1.1480
INFO - 2023-06-01 03:13:41 --> Config Class Initialized
INFO - 2023-06-01 03:13:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:41 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:41 --> URI Class Initialized
INFO - 2023-06-01 03:13:41 --> Router Class Initialized
INFO - 2023-06-01 03:13:41 --> Output Class Initialized
INFO - 2023-06-01 03:13:41 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:41 --> Input Class Initialized
INFO - 2023-06-01 03:13:41 --> Language Class Initialized
INFO - 2023-06-01 03:13:41 --> Loader Class Initialized
INFO - 2023-06-01 03:13:41 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:41 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:41 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:41 --> Model "Login_model" initialized
INFO - 2023-06-01 03:13:42 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:42 --> Total execution time: 1.0991
INFO - 2023-06-01 03:13:51 --> Config Class Initialized
INFO - 2023-06-01 03:13:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:51 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:51 --> URI Class Initialized
INFO - 2023-06-01 03:13:51 --> Router Class Initialized
INFO - 2023-06-01 03:13:51 --> Output Class Initialized
INFO - 2023-06-01 03:13:51 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:51 --> Input Class Initialized
INFO - 2023-06-01 03:13:51 --> Language Class Initialized
INFO - 2023-06-01 03:13:51 --> Loader Class Initialized
INFO - 2023-06-01 03:13:51 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:51 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:51 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:51 --> Total execution time: 0.2872
INFO - 2023-06-01 03:13:51 --> Config Class Initialized
INFO - 2023-06-01 03:13:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:51 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:51 --> URI Class Initialized
INFO - 2023-06-01 03:13:51 --> Router Class Initialized
INFO - 2023-06-01 03:13:51 --> Output Class Initialized
INFO - 2023-06-01 03:13:51 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:51 --> Input Class Initialized
INFO - 2023-06-01 03:13:51 --> Language Class Initialized
INFO - 2023-06-01 03:13:51 --> Loader Class Initialized
INFO - 2023-06-01 03:13:51 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:51 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:51 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:51 --> Total execution time: 0.2836
INFO - 2023-06-01 03:13:52 --> Config Class Initialized
INFO - 2023-06-01 03:13:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:52 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:52 --> URI Class Initialized
INFO - 2023-06-01 03:13:52 --> Router Class Initialized
INFO - 2023-06-01 03:13:52 --> Output Class Initialized
INFO - 2023-06-01 03:13:52 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:52 --> Input Class Initialized
INFO - 2023-06-01 03:13:52 --> Language Class Initialized
INFO - 2023-06-01 03:13:52 --> Loader Class Initialized
INFO - 2023-06-01 03:13:52 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:52 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:52 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:52 --> Total execution time: 0.6245
INFO - 2023-06-01 03:13:52 --> Config Class Initialized
INFO - 2023-06-01 03:13:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:13:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:13:52 --> Utf8 Class Initialized
INFO - 2023-06-01 03:13:52 --> URI Class Initialized
INFO - 2023-06-01 03:13:52 --> Router Class Initialized
INFO - 2023-06-01 03:13:52 --> Output Class Initialized
INFO - 2023-06-01 03:13:52 --> Security Class Initialized
DEBUG - 2023-06-01 03:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:13:52 --> Input Class Initialized
INFO - 2023-06-01 03:13:52 --> Language Class Initialized
INFO - 2023-06-01 03:13:53 --> Loader Class Initialized
INFO - 2023-06-01 03:13:53 --> Controller Class Initialized
DEBUG - 2023-06-01 03:13:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:13:53 --> Database Driver Class Initialized
INFO - 2023-06-01 03:13:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:13:53 --> Final output sent to browser
DEBUG - 2023-06-01 03:13:53 --> Total execution time: 0.7370
INFO - 2023-06-01 03:14:02 --> Config Class Initialized
INFO - 2023-06-01 03:14:02 --> Hooks Class Initialized
INFO - 2023-06-01 03:14:02 --> Config Class Initialized
INFO - 2023-06-01 03:14:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:02 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:02 --> URI Class Initialized
DEBUG - 2023-06-01 03:14:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:02 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:02 --> URI Class Initialized
INFO - 2023-06-01 03:14:02 --> Router Class Initialized
INFO - 2023-06-01 03:14:02 --> Output Class Initialized
INFO - 2023-06-01 03:14:02 --> Router Class Initialized
INFO - 2023-06-01 03:14:02 --> Security Class Initialized
INFO - 2023-06-01 03:14:02 --> Output Class Initialized
DEBUG - 2023-06-01 03:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:02 --> Input Class Initialized
INFO - 2023-06-01 03:14:02 --> Security Class Initialized
INFO - 2023-06-01 03:14:02 --> Language Class Initialized
DEBUG - 2023-06-01 03:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:02 --> Input Class Initialized
INFO - 2023-06-01 03:14:02 --> Language Class Initialized
INFO - 2023-06-01 03:14:02 --> Loader Class Initialized
INFO - 2023-06-01 03:14:02 --> Loader Class Initialized
INFO - 2023-06-01 03:14:02 --> Controller Class Initialized
INFO - 2023-06-01 03:14:02 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:14:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:02 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:02 --> Total execution time: 0.2892
INFO - 2023-06-01 03:14:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:02 --> Model "Login_model" initialized
INFO - 2023-06-01 03:14:02 --> Config Class Initialized
INFO - 2023-06-01 03:14:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:02 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:02 --> URI Class Initialized
INFO - 2023-06-01 03:14:02 --> Router Class Initialized
INFO - 2023-06-01 03:14:02 --> Output Class Initialized
INFO - 2023-06-01 03:14:02 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:02 --> Input Class Initialized
INFO - 2023-06-01 03:14:02 --> Language Class Initialized
INFO - 2023-06-01 03:14:02 --> Loader Class Initialized
INFO - 2023-06-01 03:14:02 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:02 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:02 --> Total execution time: 0.2655
INFO - 2023-06-01 03:14:03 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:03 --> Total execution time: 1.3021
INFO - 2023-06-01 03:14:03 --> Config Class Initialized
INFO - 2023-06-01 03:14:03 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:03 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:03 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:03 --> URI Class Initialized
INFO - 2023-06-01 03:14:03 --> Router Class Initialized
INFO - 2023-06-01 03:14:03 --> Output Class Initialized
INFO - 2023-06-01 03:14:03 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:03 --> Input Class Initialized
INFO - 2023-06-01 03:14:03 --> Language Class Initialized
INFO - 2023-06-01 03:14:03 --> Loader Class Initialized
INFO - 2023-06-01 03:14:03 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:03 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:03 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:03 --> Model "Login_model" initialized
INFO - 2023-06-01 03:14:04 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:04 --> Total execution time: 0.7495
INFO - 2023-06-01 03:14:07 --> Config Class Initialized
INFO - 2023-06-01 03:14:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:07 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:08 --> URI Class Initialized
INFO - 2023-06-01 03:14:08 --> Router Class Initialized
INFO - 2023-06-01 03:14:08 --> Output Class Initialized
INFO - 2023-06-01 03:14:08 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:08 --> Input Class Initialized
INFO - 2023-06-01 03:14:08 --> Language Class Initialized
INFO - 2023-06-01 03:14:08 --> Loader Class Initialized
INFO - 2023-06-01 03:14:08 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:08 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:08 --> Model "Login_model" initialized
INFO - 2023-06-01 03:14:08 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:08 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:08 --> Total execution time: 0.4539
INFO - 2023-06-01 03:14:08 --> Config Class Initialized
INFO - 2023-06-01 03:14:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:08 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:08 --> URI Class Initialized
INFO - 2023-06-01 03:14:08 --> Router Class Initialized
INFO - 2023-06-01 03:14:08 --> Output Class Initialized
INFO - 2023-06-01 03:14:08 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:08 --> Input Class Initialized
INFO - 2023-06-01 03:14:08 --> Language Class Initialized
INFO - 2023-06-01 03:14:08 --> Loader Class Initialized
INFO - 2023-06-01 03:14:08 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:08 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:08 --> Model "Login_model" initialized
INFO - 2023-06-01 03:14:08 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:08 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:08 --> Total execution time: 0.2952
INFO - 2023-06-01 03:14:08 --> Config Class Initialized
INFO - 2023-06-01 03:14:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:08 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:08 --> URI Class Initialized
INFO - 2023-06-01 03:14:08 --> Router Class Initialized
INFO - 2023-06-01 03:14:08 --> Output Class Initialized
INFO - 2023-06-01 03:14:08 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:08 --> Input Class Initialized
INFO - 2023-06-01 03:14:08 --> Language Class Initialized
INFO - 2023-06-01 03:14:08 --> Loader Class Initialized
INFO - 2023-06-01 03:14:08 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:08 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:08 --> Total execution time: 0.1390
INFO - 2023-06-01 03:14:08 --> Config Class Initialized
INFO - 2023-06-01 03:14:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:09 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:09 --> URI Class Initialized
INFO - 2023-06-01 03:14:09 --> Router Class Initialized
INFO - 2023-06-01 03:14:09 --> Output Class Initialized
INFO - 2023-06-01 03:14:09 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:09 --> Input Class Initialized
INFO - 2023-06-01 03:14:09 --> Language Class Initialized
INFO - 2023-06-01 03:14:09 --> Loader Class Initialized
INFO - 2023-06-01 03:14:09 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:09 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:09 --> Model "Login_model" initialized
INFO - 2023-06-01 03:14:09 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:09 --> Config Class Initialized
INFO - 2023-06-01 03:14:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:09 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:09 --> URI Class Initialized
INFO - 2023-06-01 03:14:09 --> Router Class Initialized
INFO - 2023-06-01 03:14:09 --> Output Class Initialized
INFO - 2023-06-01 03:14:09 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:09 --> Input Class Initialized
INFO - 2023-06-01 03:14:09 --> Language Class Initialized
INFO - 2023-06-01 03:14:09 --> Loader Class Initialized
INFO - 2023-06-01 03:14:09 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:09 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:10 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:10 --> Total execution time: 0.2111
INFO - 2023-06-01 03:14:10 --> Config Class Initialized
INFO - 2023-06-01 03:14:10 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:10 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:10 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:10 --> URI Class Initialized
INFO - 2023-06-01 03:14:10 --> Router Class Initialized
INFO - 2023-06-01 03:14:10 --> Output Class Initialized
INFO - 2023-06-01 03:14:10 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:10 --> Input Class Initialized
INFO - 2023-06-01 03:14:10 --> Language Class Initialized
INFO - 2023-06-01 03:14:10 --> Loader Class Initialized
INFO - 2023-06-01 03:14:10 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:10 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:11 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:11 --> Total execution time: 2.7658
INFO - 2023-06-01 03:14:11 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:11 --> Total execution time: 1.6664
INFO - 2023-06-01 03:14:56 --> Config Class Initialized
INFO - 2023-06-01 03:14:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:56 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:56 --> URI Class Initialized
INFO - 2023-06-01 03:14:56 --> Router Class Initialized
INFO - 2023-06-01 03:14:56 --> Output Class Initialized
INFO - 2023-06-01 03:14:56 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:56 --> Input Class Initialized
INFO - 2023-06-01 03:14:56 --> Language Class Initialized
INFO - 2023-06-01 03:14:56 --> Loader Class Initialized
INFO - 2023-06-01 03:14:56 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:56 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:56 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:56 --> Total execution time: 0.2798
INFO - 2023-06-01 03:14:56 --> Config Class Initialized
INFO - 2023-06-01 03:14:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:14:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:14:56 --> Utf8 Class Initialized
INFO - 2023-06-01 03:14:56 --> URI Class Initialized
INFO - 2023-06-01 03:14:56 --> Router Class Initialized
INFO - 2023-06-01 03:14:56 --> Output Class Initialized
INFO - 2023-06-01 03:14:56 --> Security Class Initialized
DEBUG - 2023-06-01 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:14:56 --> Input Class Initialized
INFO - 2023-06-01 03:14:56 --> Language Class Initialized
INFO - 2023-06-01 03:14:56 --> Loader Class Initialized
INFO - 2023-06-01 03:14:56 --> Controller Class Initialized
DEBUG - 2023-06-01 03:14:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:14:56 --> Database Driver Class Initialized
INFO - 2023-06-01 03:14:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:14:57 --> Final output sent to browser
DEBUG - 2023-06-01 03:14:57 --> Total execution time: 1.0286
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:15:58 --> Final output sent to browser
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 03:15:58 --> Total execution time: 0.2916
INFO - 2023-06-01 03:15:58 --> Final output sent to browser
INFO - 2023-06-01 03:15:58 --> Final output sent to browser
DEBUG - 2023-06-01 03:15:58 --> Total execution time: 0.2957
DEBUG - 2023-06-01 03:15:58 --> Total execution time: 0.3009
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:15:58 --> Final output sent to browser
DEBUG - 2023-06-01 03:15:58 --> Total execution time: 0.2654
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:15:58 --> Final output sent to browser
DEBUG - 2023-06-01 03:15:58 --> Total execution time: 0.3253
INFO - 2023-06-01 03:15:58 --> Config Class Initialized
INFO - 2023-06-01 03:15:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:58 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:58 --> URI Class Initialized
INFO - 2023-06-01 03:15:58 --> Router Class Initialized
INFO - 2023-06-01 03:15:58 --> Output Class Initialized
INFO - 2023-06-01 03:15:58 --> Security Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:15:58 --> Input Class Initialized
INFO - 2023-06-01 03:15:58 --> Language Class Initialized
INFO - 2023-06-01 03:15:58 --> Loader Class Initialized
INFO - 2023-06-01 03:15:58 --> Controller Class Initialized
DEBUG - 2023-06-01 03:15:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:58 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:15:59 --> Config Class Initialized
INFO - 2023-06-01 03:15:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:15:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:15:59 --> Utf8 Class Initialized
INFO - 2023-06-01 03:15:59 --> URI Class Initialized
INFO - 2023-06-01 03:15:59 --> Router Class Initialized
INFO - 2023-06-01 03:15:59 --> Output Class Initialized
INFO - 2023-06-01 03:15:59 --> Security Class Initialized
DEBUG - 2023-06-01 03:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:15:59 --> Input Class Initialized
INFO - 2023-06-01 03:15:59 --> Language Class Initialized
INFO - 2023-06-01 03:15:59 --> Loader Class Initialized
INFO - 2023-06-01 03:15:59 --> Controller Class Initialized
DEBUG - 2023-06-01 03:15:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:15:59 --> Database Driver Class Initialized
INFO - 2023-06-01 03:15:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:01 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:01 --> Total execution time: 2.9208
INFO - 2023-06-01 03:16:01 --> Config Class Initialized
INFO - 2023-06-01 03:16:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:01 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:01 --> URI Class Initialized
INFO - 2023-06-01 03:16:01 --> Router Class Initialized
INFO - 2023-06-01 03:16:01 --> Output Class Initialized
INFO - 2023-06-01 03:16:01 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:01 --> Input Class Initialized
INFO - 2023-06-01 03:16:01 --> Language Class Initialized
INFO - 2023-06-01 03:16:01 --> Loader Class Initialized
INFO - 2023-06-01 03:16:01 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:01 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:01 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:01 --> Total execution time: 0.2343
INFO - 2023-06-01 03:16:01 --> Config Class Initialized
INFO - 2023-06-01 03:16:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:01 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:01 --> URI Class Initialized
INFO - 2023-06-01 03:16:01 --> Router Class Initialized
INFO - 2023-06-01 03:16:01 --> Output Class Initialized
INFO - 2023-06-01 03:16:01 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:01 --> Input Class Initialized
INFO - 2023-06-01 03:16:01 --> Language Class Initialized
INFO - 2023-06-01 03:16:01 --> Loader Class Initialized
INFO - 2023-06-01 03:16:01 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:01 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:04 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:04 --> Total execution time: 3.2613
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:21 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:21 --> Total execution time: 0.1983
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Final output sent to browser
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Total execution time: 0.2198
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:21 --> Total execution time: 0.2624
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
INFO - 2023-06-01 03:16:21 --> Config Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
INFO - 2023-06-01 03:16:21 --> Hooks Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:16:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
INFO - 2023-06-01 03:16:21 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> URI Class Initialized
INFO - 2023-06-01 03:16:21 --> Router Class Initialized
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
INFO - 2023-06-01 03:16:21 --> Output Class Initialized
INFO - 2023-06-01 03:16:21 --> Security Class Initialized
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Input Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Language Class Initialized
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:21 --> Loader Class Initialized
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:21 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:21 --> Total execution time: 0.2549
INFO - 2023-06-01 03:16:21 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:21 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:21 --> Total execution time: 0.2674
INFO - 2023-06-01 03:16:22 --> Config Class Initialized
INFO - 2023-06-01 03:16:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:22 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:22 --> URI Class Initialized
INFO - 2023-06-01 03:16:22 --> Router Class Initialized
INFO - 2023-06-01 03:16:22 --> Output Class Initialized
INFO - 2023-06-01 03:16:22 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:22 --> Input Class Initialized
INFO - 2023-06-01 03:16:22 --> Language Class Initialized
INFO - 2023-06-01 03:16:22 --> Loader Class Initialized
INFO - 2023-06-01 03:16:22 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:22 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:22 --> Config Class Initialized
INFO - 2023-06-01 03:16:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:22 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:22 --> URI Class Initialized
INFO - 2023-06-01 03:16:22 --> Router Class Initialized
INFO - 2023-06-01 03:16:22 --> Output Class Initialized
INFO - 2023-06-01 03:16:22 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:22 --> Input Class Initialized
INFO - 2023-06-01 03:16:22 --> Language Class Initialized
INFO - 2023-06-01 03:16:22 --> Loader Class Initialized
INFO - 2023-06-01 03:16:22 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:22 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:23 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:23 --> Total execution time: 2.0667
INFO - 2023-06-01 03:16:39 --> Config Class Initialized
INFO - 2023-06-01 03:16:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:39 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:39 --> URI Class Initialized
INFO - 2023-06-01 03:16:39 --> Router Class Initialized
INFO - 2023-06-01 03:16:39 --> Output Class Initialized
INFO - 2023-06-01 03:16:39 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:39 --> Input Class Initialized
INFO - 2023-06-01 03:16:39 --> Language Class Initialized
INFO - 2023-06-01 03:16:39 --> Loader Class Initialized
INFO - 2023-06-01 03:16:39 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:39 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:39 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:39 --> Total execution time: 0.1622
INFO - 2023-06-01 03:16:39 --> Config Class Initialized
INFO - 2023-06-01 03:16:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:39 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:39 --> URI Class Initialized
INFO - 2023-06-01 03:16:39 --> Router Class Initialized
INFO - 2023-06-01 03:16:39 --> Output Class Initialized
INFO - 2023-06-01 03:16:39 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:39 --> Input Class Initialized
INFO - 2023-06-01 03:16:39 --> Language Class Initialized
INFO - 2023-06-01 03:16:39 --> Loader Class Initialized
INFO - 2023-06-01 03:16:39 --> Controller Class Initialized
DEBUG - 2023-06-01 03:16:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:16:39 --> Database Driver Class Initialized
INFO - 2023-06-01 03:16:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:16:43 --> Final output sent to browser
DEBUG - 2023-06-01 03:16:43 --> Total execution time: 3.9631
INFO - 2023-06-01 03:16:48 --> Config Class Initialized
INFO - 2023-06-01 03:16:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:16:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:16:48 --> Utf8 Class Initialized
INFO - 2023-06-01 03:16:48 --> URI Class Initialized
INFO - 2023-06-01 03:16:48 --> Router Class Initialized
INFO - 2023-06-01 03:16:48 --> Output Class Initialized
INFO - 2023-06-01 03:16:48 --> Security Class Initialized
DEBUG - 2023-06-01 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:16:48 --> Input Class Initialized
INFO - 2023-06-01 03:16:48 --> Language Class Initialized
ERROR - 2023-06-01 03:16:48 --> 404 Page Not Found: user/Cluster/CdcDelete
INFO - 2023-06-01 03:18:01 --> Config Class Initialized
INFO - 2023-06-01 03:18:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:18:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:18:01 --> Utf8 Class Initialized
INFO - 2023-06-01 03:18:01 --> URI Class Initialized
INFO - 2023-06-01 03:18:01 --> Router Class Initialized
INFO - 2023-06-01 03:18:01 --> Output Class Initialized
INFO - 2023-06-01 03:18:01 --> Security Class Initialized
DEBUG - 2023-06-01 03:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:18:01 --> Input Class Initialized
INFO - 2023-06-01 03:18:01 --> Language Class Initialized
INFO - 2023-06-01 03:18:01 --> Loader Class Initialized
INFO - 2023-06-01 03:18:01 --> Controller Class Initialized
DEBUG - 2023-06-01 03:18:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:18:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:18:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:18:02 --> Final output sent to browser
DEBUG - 2023-06-01 03:18:02 --> Total execution time: 0.6207
INFO - 2023-06-01 03:18:02 --> Config Class Initialized
INFO - 2023-06-01 03:18:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:18:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:18:02 --> Utf8 Class Initialized
INFO - 2023-06-01 03:18:02 --> URI Class Initialized
INFO - 2023-06-01 03:18:02 --> Router Class Initialized
INFO - 2023-06-01 03:18:02 --> Output Class Initialized
INFO - 2023-06-01 03:18:02 --> Security Class Initialized
DEBUG - 2023-06-01 03:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:18:02 --> Input Class Initialized
INFO - 2023-06-01 03:18:02 --> Language Class Initialized
INFO - 2023-06-01 03:18:02 --> Loader Class Initialized
INFO - 2023-06-01 03:18:02 --> Controller Class Initialized
DEBUG - 2023-06-01 03:18:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:18:02 --> Database Driver Class Initialized
INFO - 2023-06-01 03:18:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:18:02 --> Final output sent to browser
DEBUG - 2023-06-01 03:18:02 --> Total execution time: 0.5289
INFO - 2023-06-01 03:21:39 --> Config Class Initialized
INFO - 2023-06-01 03:21:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:21:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:21:39 --> Utf8 Class Initialized
INFO - 2023-06-01 03:21:39 --> URI Class Initialized
INFO - 2023-06-01 03:21:39 --> Router Class Initialized
INFO - 2023-06-01 03:21:39 --> Output Class Initialized
INFO - 2023-06-01 03:21:39 --> Security Class Initialized
DEBUG - 2023-06-01 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:21:39 --> Input Class Initialized
INFO - 2023-06-01 03:21:39 --> Language Class Initialized
INFO - 2023-06-01 03:21:39 --> Loader Class Initialized
INFO - 2023-06-01 03:21:39 --> Controller Class Initialized
DEBUG - 2023-06-01 03:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:21:39 --> Database Driver Class Initialized
INFO - 2023-06-01 03:21:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:21:39 --> Final output sent to browser
DEBUG - 2023-06-01 03:21:39 --> Total execution time: 0.3109
INFO - 2023-06-01 03:21:39 --> Config Class Initialized
INFO - 2023-06-01 03:21:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:21:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:21:39 --> Utf8 Class Initialized
INFO - 2023-06-01 03:21:39 --> URI Class Initialized
INFO - 2023-06-01 03:21:39 --> Router Class Initialized
INFO - 2023-06-01 03:21:39 --> Output Class Initialized
INFO - 2023-06-01 03:21:39 --> Security Class Initialized
DEBUG - 2023-06-01 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:21:39 --> Input Class Initialized
INFO - 2023-06-01 03:21:39 --> Language Class Initialized
INFO - 2023-06-01 03:21:39 --> Loader Class Initialized
INFO - 2023-06-01 03:21:39 --> Controller Class Initialized
DEBUG - 2023-06-01 03:21:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:21:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:21:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:21:45 --> Final output sent to browser
DEBUG - 2023-06-01 03:21:45 --> Total execution time: 6.0740
INFO - 2023-06-01 03:21:54 --> Config Class Initialized
INFO - 2023-06-01 03:21:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:21:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:21:54 --> Utf8 Class Initialized
INFO - 2023-06-01 03:21:54 --> URI Class Initialized
INFO - 2023-06-01 03:21:54 --> Router Class Initialized
INFO - 2023-06-01 03:21:54 --> Output Class Initialized
INFO - 2023-06-01 03:21:54 --> Security Class Initialized
DEBUG - 2023-06-01 03:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:21:54 --> Input Class Initialized
INFO - 2023-06-01 03:21:54 --> Language Class Initialized
INFO - 2023-06-01 03:21:54 --> Loader Class Initialized
INFO - 2023-06-01 03:21:54 --> Controller Class Initialized
DEBUG - 2023-06-01 03:21:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:21:55 --> Database Driver Class Initialized
INFO - 2023-06-01 03:21:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:21:55 --> Final output sent to browser
DEBUG - 2023-06-01 03:21:55 --> Total execution time: 0.2878
INFO - 2023-06-01 03:21:55 --> Config Class Initialized
INFO - 2023-06-01 03:21:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:21:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:21:55 --> Utf8 Class Initialized
INFO - 2023-06-01 03:21:55 --> URI Class Initialized
INFO - 2023-06-01 03:21:55 --> Router Class Initialized
INFO - 2023-06-01 03:21:55 --> Output Class Initialized
INFO - 2023-06-01 03:21:55 --> Security Class Initialized
DEBUG - 2023-06-01 03:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:21:55 --> Input Class Initialized
INFO - 2023-06-01 03:21:55 --> Language Class Initialized
INFO - 2023-06-01 03:21:55 --> Loader Class Initialized
INFO - 2023-06-01 03:21:55 --> Controller Class Initialized
DEBUG - 2023-06-01 03:21:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:21:55 --> Database Driver Class Initialized
INFO - 2023-06-01 03:21:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:22:00 --> Final output sent to browser
DEBUG - 2023-06-01 03:22:00 --> Total execution time: 5.0089
INFO - 2023-06-01 03:26:37 --> Config Class Initialized
INFO - 2023-06-01 03:26:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:26:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:26:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:26:37 --> URI Class Initialized
INFO - 2023-06-01 03:26:37 --> Router Class Initialized
INFO - 2023-06-01 03:26:38 --> Output Class Initialized
INFO - 2023-06-01 03:26:38 --> Security Class Initialized
DEBUG - 2023-06-01 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:26:38 --> Input Class Initialized
INFO - 2023-06-01 03:26:38 --> Language Class Initialized
INFO - 2023-06-01 03:26:38 --> Loader Class Initialized
INFO - 2023-06-01 03:26:38 --> Controller Class Initialized
DEBUG - 2023-06-01 03:26:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:26:38 --> Database Driver Class Initialized
INFO - 2023-06-01 03:26:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:26:38 --> Final output sent to browser
DEBUG - 2023-06-01 03:26:38 --> Total execution time: 0.3691
INFO - 2023-06-01 03:26:38 --> Config Class Initialized
INFO - 2023-06-01 03:26:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:26:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:26:38 --> Utf8 Class Initialized
INFO - 2023-06-01 03:26:38 --> URI Class Initialized
INFO - 2023-06-01 03:26:38 --> Router Class Initialized
INFO - 2023-06-01 03:26:38 --> Output Class Initialized
INFO - 2023-06-01 03:26:38 --> Security Class Initialized
DEBUG - 2023-06-01 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:26:38 --> Input Class Initialized
INFO - 2023-06-01 03:26:38 --> Language Class Initialized
INFO - 2023-06-01 03:26:38 --> Loader Class Initialized
INFO - 2023-06-01 03:26:38 --> Controller Class Initialized
DEBUG - 2023-06-01 03:26:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:26:38 --> Database Driver Class Initialized
INFO - 2023-06-01 03:26:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:26:39 --> Final output sent to browser
DEBUG - 2023-06-01 03:26:39 --> Total execution time: 0.9074
INFO - 2023-06-01 03:29:05 --> Config Class Initialized
INFO - 2023-06-01 03:29:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:05 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:05 --> URI Class Initialized
INFO - 2023-06-01 03:29:05 --> Router Class Initialized
INFO - 2023-06-01 03:29:05 --> Output Class Initialized
INFO - 2023-06-01 03:29:05 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:06 --> Input Class Initialized
INFO - 2023-06-01 03:29:06 --> Language Class Initialized
INFO - 2023-06-01 03:29:06 --> Loader Class Initialized
INFO - 2023-06-01 03:29:06 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:06 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:06 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:06 --> Total execution time: 0.4967
INFO - 2023-06-01 03:29:06 --> Config Class Initialized
INFO - 2023-06-01 03:29:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:06 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:06 --> URI Class Initialized
INFO - 2023-06-01 03:29:06 --> Router Class Initialized
INFO - 2023-06-01 03:29:06 --> Output Class Initialized
INFO - 2023-06-01 03:29:06 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:06 --> Input Class Initialized
INFO - 2023-06-01 03:29:06 --> Language Class Initialized
INFO - 2023-06-01 03:29:06 --> Loader Class Initialized
INFO - 2023-06-01 03:29:06 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:06 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:07 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:07 --> Total execution time: 0.9119
INFO - 2023-06-01 03:29:29 --> Config Class Initialized
INFO - 2023-06-01 03:29:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:29 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:29 --> URI Class Initialized
INFO - 2023-06-01 03:29:29 --> Router Class Initialized
INFO - 2023-06-01 03:29:29 --> Output Class Initialized
INFO - 2023-06-01 03:29:29 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:29 --> Input Class Initialized
INFO - 2023-06-01 03:29:29 --> Language Class Initialized
INFO - 2023-06-01 03:29:29 --> Loader Class Initialized
INFO - 2023-06-01 03:29:29 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:29 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:29 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:29 --> Total execution time: 0.1935
INFO - 2023-06-01 03:29:29 --> Config Class Initialized
INFO - 2023-06-01 03:29:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:29 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:29 --> URI Class Initialized
INFO - 2023-06-01 03:29:29 --> Router Class Initialized
INFO - 2023-06-01 03:29:29 --> Output Class Initialized
INFO - 2023-06-01 03:29:29 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:29 --> Input Class Initialized
INFO - 2023-06-01 03:29:29 --> Language Class Initialized
INFO - 2023-06-01 03:29:29 --> Loader Class Initialized
INFO - 2023-06-01 03:29:29 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:29 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:29 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:29 --> Total execution time: 0.1767
INFO - 2023-06-01 03:29:29 --> Config Class Initialized
INFO - 2023-06-01 03:29:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:29 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:29 --> URI Class Initialized
INFO - 2023-06-01 03:29:29 --> Router Class Initialized
INFO - 2023-06-01 03:29:29 --> Output Class Initialized
INFO - 2023-06-01 03:29:29 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:29 --> Input Class Initialized
INFO - 2023-06-01 03:29:29 --> Language Class Initialized
INFO - 2023-06-01 03:29:29 --> Loader Class Initialized
INFO - 2023-06-01 03:29:29 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:29 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:29 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:29 --> Total execution time: 0.1787
INFO - 2023-06-01 03:29:29 --> Config Class Initialized
INFO - 2023-06-01 03:29:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:29 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:29 --> URI Class Initialized
INFO - 2023-06-01 03:29:29 --> Router Class Initialized
INFO - 2023-06-01 03:29:30 --> Output Class Initialized
INFO - 2023-06-01 03:29:30 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:30 --> Input Class Initialized
INFO - 2023-06-01 03:29:30 --> Language Class Initialized
INFO - 2023-06-01 03:29:30 --> Loader Class Initialized
INFO - 2023-06-01 03:29:30 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:30 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:30 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:30 --> Total execution time: 0.1838
INFO - 2023-06-01 03:29:33 --> Config Class Initialized
INFO - 2023-06-01 03:29:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:33 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:33 --> URI Class Initialized
INFO - 2023-06-01 03:29:33 --> Router Class Initialized
INFO - 2023-06-01 03:29:33 --> Output Class Initialized
INFO - 2023-06-01 03:29:33 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:33 --> Input Class Initialized
INFO - 2023-06-01 03:29:33 --> Language Class Initialized
INFO - 2023-06-01 03:29:33 --> Loader Class Initialized
INFO - 2023-06-01 03:29:33 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:33 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:33 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:33 --> Total execution time: 0.1664
INFO - 2023-06-01 03:29:33 --> Config Class Initialized
INFO - 2023-06-01 03:29:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:33 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:33 --> URI Class Initialized
INFO - 2023-06-01 03:29:33 --> Router Class Initialized
INFO - 2023-06-01 03:29:33 --> Output Class Initialized
INFO - 2023-06-01 03:29:33 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:33 --> Input Class Initialized
INFO - 2023-06-01 03:29:33 --> Language Class Initialized
INFO - 2023-06-01 03:29:33 --> Loader Class Initialized
INFO - 2023-06-01 03:29:33 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:33 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:33 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:33 --> Total execution time: 0.1779
INFO - 2023-06-01 03:29:33 --> Config Class Initialized
INFO - 2023-06-01 03:29:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:33 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:33 --> URI Class Initialized
INFO - 2023-06-01 03:29:33 --> Router Class Initialized
INFO - 2023-06-01 03:29:33 --> Output Class Initialized
INFO - 2023-06-01 03:29:33 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:33 --> Input Class Initialized
INFO - 2023-06-01 03:29:33 --> Language Class Initialized
INFO - 2023-06-01 03:29:33 --> Loader Class Initialized
INFO - 2023-06-01 03:29:33 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:33 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:33 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:33 --> Total execution time: 0.1716
INFO - 2023-06-01 03:29:33 --> Config Class Initialized
INFO - 2023-06-01 03:29:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:33 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:33 --> URI Class Initialized
INFO - 2023-06-01 03:29:33 --> Router Class Initialized
INFO - 2023-06-01 03:29:33 --> Output Class Initialized
INFO - 2023-06-01 03:29:33 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:33 --> Input Class Initialized
INFO - 2023-06-01 03:29:33 --> Language Class Initialized
INFO - 2023-06-01 03:29:33 --> Loader Class Initialized
INFO - 2023-06-01 03:29:33 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:34 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:34 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:34 --> Total execution time: 0.1713
INFO - 2023-06-01 03:29:36 --> Config Class Initialized
INFO - 2023-06-01 03:29:36 --> Config Class Initialized
INFO - 2023-06-01 03:29:36 --> Config Class Initialized
INFO - 2023-06-01 03:29:36 --> Hooks Class Initialized
INFO - 2023-06-01 03:29:36 --> Hooks Class Initialized
INFO - 2023-06-01 03:29:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:29:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:36 --> URI Class Initialized
INFO - 2023-06-01 03:29:36 --> URI Class Initialized
INFO - 2023-06-01 03:29:36 --> URI Class Initialized
INFO - 2023-06-01 03:29:36 --> Router Class Initialized
INFO - 2023-06-01 03:29:36 --> Router Class Initialized
INFO - 2023-06-01 03:29:36 --> Router Class Initialized
INFO - 2023-06-01 03:29:36 --> Output Class Initialized
INFO - 2023-06-01 03:29:36 --> Output Class Initialized
INFO - 2023-06-01 03:29:36 --> Output Class Initialized
INFO - 2023-06-01 03:29:36 --> Security Class Initialized
INFO - 2023-06-01 03:29:36 --> Security Class Initialized
INFO - 2023-06-01 03:29:36 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:36 --> Input Class Initialized
INFO - 2023-06-01 03:29:36 --> Input Class Initialized
INFO - 2023-06-01 03:29:36 --> Input Class Initialized
INFO - 2023-06-01 03:29:36 --> Language Class Initialized
INFO - 2023-06-01 03:29:36 --> Language Class Initialized
INFO - 2023-06-01 03:29:36 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.1588
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.1615
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.1746
INFO - 2023-06-01 03:29:37 --> Config Class Initialized
INFO - 2023-06-01 03:29:37 --> Config Class Initialized
INFO - 2023-06-01 03:29:37 --> Hooks Class Initialized
INFO - 2023-06-01 03:29:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:37 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:37 --> URI Class Initialized
INFO - 2023-06-01 03:29:37 --> Config Class Initialized
INFO - 2023-06-01 03:29:37 --> URI Class Initialized
INFO - 2023-06-01 03:29:37 --> Hooks Class Initialized
INFO - 2023-06-01 03:29:37 --> Router Class Initialized
INFO - 2023-06-01 03:29:37 --> Router Class Initialized
INFO - 2023-06-01 03:29:37 --> Output Class Initialized
INFO - 2023-06-01 03:29:37 --> Output Class Initialized
DEBUG - 2023-06-01 03:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:37 --> Security Class Initialized
INFO - 2023-06-01 03:29:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:37 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:37 --> URI Class Initialized
INFO - 2023-06-01 03:29:37 --> Input Class Initialized
INFO - 2023-06-01 03:29:37 --> Input Class Initialized
INFO - 2023-06-01 03:29:37 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Router Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Output Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
INFO - 2023-06-01 03:29:37 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:37 --> Input Class Initialized
INFO - 2023-06-01 03:29:37 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.1736
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.1723
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Config Class Initialized
INFO - 2023-06-01 03:29:37 --> Hooks Class Initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 03:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:37 --> URI Class Initialized
INFO - 2023-06-01 03:29:37 --> Router Class Initialized
INFO - 2023-06-01 03:29:37 --> Output Class Initialized
INFO - 2023-06-01 03:29:37 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:37 --> Input Class Initialized
INFO - 2023-06-01 03:29:37 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:37 --> Total execution time: 0.3844
INFO - 2023-06-01 03:29:37 --> Config Class Initialized
INFO - 2023-06-01 03:29:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:37 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:37 --> URI Class Initialized
INFO - 2023-06-01 03:29:37 --> Router Class Initialized
INFO - 2023-06-01 03:29:37 --> Output Class Initialized
INFO - 2023-06-01 03:29:37 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:37 --> Input Class Initialized
INFO - 2023-06-01 03:29:37 --> Language Class Initialized
INFO - 2023-06-01 03:29:37 --> Loader Class Initialized
INFO - 2023-06-01 03:29:37 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:39 --> Config Class Initialized
INFO - 2023-06-01 03:29:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:39 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:39 --> URI Class Initialized
INFO - 2023-06-01 03:29:39 --> Router Class Initialized
INFO - 2023-06-01 03:29:39 --> Output Class Initialized
INFO - 2023-06-01 03:29:40 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:40 --> Input Class Initialized
INFO - 2023-06-01 03:29:40 --> Language Class Initialized
INFO - 2023-06-01 03:29:40 --> Loader Class Initialized
INFO - 2023-06-01 03:29:40 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:40 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:40 --> Total execution time: 0.1824
INFO - 2023-06-01 03:29:40 --> Config Class Initialized
INFO - 2023-06-01 03:29:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:29:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:29:40 --> Utf8 Class Initialized
INFO - 2023-06-01 03:29:40 --> URI Class Initialized
INFO - 2023-06-01 03:29:40 --> Router Class Initialized
INFO - 2023-06-01 03:29:40 --> Output Class Initialized
INFO - 2023-06-01 03:29:40 --> Security Class Initialized
DEBUG - 2023-06-01 03:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:29:40 --> Input Class Initialized
INFO - 2023-06-01 03:29:40 --> Language Class Initialized
INFO - 2023-06-01 03:29:40 --> Loader Class Initialized
INFO - 2023-06-01 03:29:40 --> Controller Class Initialized
DEBUG - 2023-06-01 03:29:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:29:40 --> Database Driver Class Initialized
INFO - 2023-06-01 03:29:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:29:40 --> Final output sent to browser
DEBUG - 2023-06-01 03:29:40 --> Total execution time: 0.2006
INFO - 2023-06-01 03:42:41 --> Config Class Initialized
INFO - 2023-06-01 03:42:41 --> Config Class Initialized
INFO - 2023-06-01 03:42:41 --> Config Class Initialized
INFO - 2023-06-01 03:42:41 --> Hooks Class Initialized
INFO - 2023-06-01 03:42:41 --> Hooks Class Initialized
INFO - 2023-06-01 03:42:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:42:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:41 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:41 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:41 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:41 --> URI Class Initialized
INFO - 2023-06-01 03:42:41 --> URI Class Initialized
INFO - 2023-06-01 03:42:41 --> URI Class Initialized
INFO - 2023-06-01 03:42:41 --> Router Class Initialized
INFO - 2023-06-01 03:42:41 --> Router Class Initialized
INFO - 2023-06-01 03:42:41 --> Router Class Initialized
INFO - 2023-06-01 03:42:41 --> Output Class Initialized
INFO - 2023-06-01 03:42:41 --> Output Class Initialized
INFO - 2023-06-01 03:42:41 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.4777
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.5210
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.5220
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:42 --> Utf8 Class Initialized
DEBUG - 2023-06-01 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:42 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:42 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:42 --> URI Class Initialized
INFO - 2023-06-01 03:42:42 --> URI Class Initialized
INFO - 2023-06-01 03:42:42 --> URI Class Initialized
INFO - 2023-06-01 03:42:42 --> Router Class Initialized
INFO - 2023-06-01 03:42:42 --> Router Class Initialized
INFO - 2023-06-01 03:42:42 --> Router Class Initialized
INFO - 2023-06-01 03:42:42 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.2083
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.2112
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:42 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:42 --> URI Class Initialized
INFO - 2023-06-01 03:42:42 --> Router Class Initialized
INFO - 2023-06-01 03:42:42 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:42 --> Language Class Initialized
INFO - 2023-06-01 03:42:42 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:42 --> Total execution time: 0.4220
INFO - 2023-06-01 03:42:42 --> Loader Class Initialized
INFO - 2023-06-01 03:42:42 --> Controller Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:42 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:42 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:42 --> URI Class Initialized
INFO - 2023-06-01 03:42:42 --> Router Class Initialized
INFO - 2023-06-01 03:42:42 --> Output Class Initialized
INFO - 2023-06-01 03:42:42 --> Config Class Initialized
INFO - 2023-06-01 03:42:42 --> Security Class Initialized
INFO - 2023-06-01 03:42:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:42 --> Input Class Initialized
INFO - 2023-06-01 03:42:43 --> Language Class Initialized
DEBUG - 2023-06-01 03:42:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:43 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:43 --> URI Class Initialized
INFO - 2023-06-01 03:42:43 --> Loader Class Initialized
INFO - 2023-06-01 03:42:43 --> Router Class Initialized
INFO - 2023-06-01 03:42:43 --> Controller Class Initialized
INFO - 2023-06-01 03:42:43 --> Output Class Initialized
DEBUG - 2023-06-01 03:42:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:43 --> Security Class Initialized
DEBUG - 2023-06-01 03:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:43 --> Input Class Initialized
INFO - 2023-06-01 03:42:43 --> Language Class Initialized
INFO - 2023-06-01 03:42:43 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:43 --> Loader Class Initialized
INFO - 2023-06-01 03:42:43 --> Controller Class Initialized
INFO - 2023-06-01 03:42:43 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 03:42:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:43 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:43 --> Total execution time: 0.2830
INFO - 2023-06-01 03:42:43 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:43 --> Config Class Initialized
INFO - 2023-06-01 03:42:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:42:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:42:43 --> Utf8 Class Initialized
INFO - 2023-06-01 03:42:43 --> URI Class Initialized
INFO - 2023-06-01 03:42:43 --> Router Class Initialized
INFO - 2023-06-01 03:42:43 --> Output Class Initialized
INFO - 2023-06-01 03:42:43 --> Security Class Initialized
DEBUG - 2023-06-01 03:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:42:43 --> Input Class Initialized
INFO - 2023-06-01 03:42:43 --> Language Class Initialized
INFO - 2023-06-01 03:42:43 --> Loader Class Initialized
INFO - 2023-06-01 03:42:43 --> Controller Class Initialized
DEBUG - 2023-06-01 03:42:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:42:43 --> Database Driver Class Initialized
INFO - 2023-06-01 03:42:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:42:43 --> Final output sent to browser
DEBUG - 2023-06-01 03:42:43 --> Total execution time: 0.2496
INFO - 2023-06-01 03:44:05 --> Config Class Initialized
INFO - 2023-06-01 03:44:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:44:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:44:05 --> Utf8 Class Initialized
INFO - 2023-06-01 03:44:05 --> URI Class Initialized
INFO - 2023-06-01 03:44:05 --> Router Class Initialized
INFO - 2023-06-01 03:44:05 --> Output Class Initialized
INFO - 2023-06-01 03:44:05 --> Security Class Initialized
DEBUG - 2023-06-01 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:44:05 --> Input Class Initialized
INFO - 2023-06-01 03:44:05 --> Language Class Initialized
INFO - 2023-06-01 03:44:05 --> Loader Class Initialized
INFO - 2023-06-01 03:44:05 --> Controller Class Initialized
DEBUG - 2023-06-01 03:44:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:44:05 --> Database Driver Class Initialized
INFO - 2023-06-01 03:44:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:44:05 --> Final output sent to browser
DEBUG - 2023-06-01 03:44:05 --> Total execution time: 0.1751
INFO - 2023-06-01 03:44:05 --> Config Class Initialized
INFO - 2023-06-01 03:44:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:44:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:44:05 --> Utf8 Class Initialized
INFO - 2023-06-01 03:44:05 --> URI Class Initialized
INFO - 2023-06-01 03:44:05 --> Router Class Initialized
INFO - 2023-06-01 03:44:05 --> Output Class Initialized
INFO - 2023-06-01 03:44:05 --> Security Class Initialized
DEBUG - 2023-06-01 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:44:05 --> Input Class Initialized
INFO - 2023-06-01 03:44:05 --> Language Class Initialized
INFO - 2023-06-01 03:44:05 --> Loader Class Initialized
INFO - 2023-06-01 03:44:05 --> Controller Class Initialized
DEBUG - 2023-06-01 03:44:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:44:05 --> Database Driver Class Initialized
INFO - 2023-06-01 03:44:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:44:06 --> Final output sent to browser
DEBUG - 2023-06-01 03:44:06 --> Total execution time: 0.1893
INFO - 2023-06-01 03:44:18 --> Config Class Initialized
INFO - 2023-06-01 03:44:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:44:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:44:18 --> Utf8 Class Initialized
INFO - 2023-06-01 03:44:18 --> URI Class Initialized
INFO - 2023-06-01 03:44:18 --> Router Class Initialized
INFO - 2023-06-01 03:44:18 --> Output Class Initialized
INFO - 2023-06-01 03:44:18 --> Security Class Initialized
DEBUG - 2023-06-01 03:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:44:18 --> Input Class Initialized
INFO - 2023-06-01 03:44:18 --> Language Class Initialized
INFO - 2023-06-01 03:44:18 --> Loader Class Initialized
INFO - 2023-06-01 03:44:18 --> Controller Class Initialized
DEBUG - 2023-06-01 03:44:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:44:18 --> Database Driver Class Initialized
INFO - 2023-06-01 03:44:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:44:18 --> Final output sent to browser
DEBUG - 2023-06-01 03:44:18 --> Total execution time: 0.5448
INFO - 2023-06-01 03:44:18 --> Config Class Initialized
INFO - 2023-06-01 03:44:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:44:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:44:18 --> Utf8 Class Initialized
INFO - 2023-06-01 03:44:18 --> URI Class Initialized
INFO - 2023-06-01 03:44:18 --> Router Class Initialized
INFO - 2023-06-01 03:44:19 --> Output Class Initialized
INFO - 2023-06-01 03:44:19 --> Security Class Initialized
DEBUG - 2023-06-01 03:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:44:19 --> Input Class Initialized
INFO - 2023-06-01 03:44:19 --> Language Class Initialized
INFO - 2023-06-01 03:44:19 --> Loader Class Initialized
INFO - 2023-06-01 03:44:19 --> Controller Class Initialized
DEBUG - 2023-06-01 03:44:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:44:19 --> Database Driver Class Initialized
INFO - 2023-06-01 03:44:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:44:19 --> Final output sent to browser
DEBUG - 2023-06-01 03:44:19 --> Total execution time: 0.2458
INFO - 2023-06-01 03:45:44 --> Config Class Initialized
INFO - 2023-06-01 03:45:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:45:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:45:44 --> Utf8 Class Initialized
INFO - 2023-06-01 03:45:44 --> URI Class Initialized
INFO - 2023-06-01 03:45:44 --> Router Class Initialized
INFO - 2023-06-01 03:45:44 --> Output Class Initialized
INFO - 2023-06-01 03:45:44 --> Security Class Initialized
DEBUG - 2023-06-01 03:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:45:44 --> Input Class Initialized
INFO - 2023-06-01 03:45:44 --> Language Class Initialized
INFO - 2023-06-01 03:45:44 --> Loader Class Initialized
INFO - 2023-06-01 03:45:44 --> Controller Class Initialized
DEBUG - 2023-06-01 03:45:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:45:44 --> Database Driver Class Initialized
INFO - 2023-06-01 03:45:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:45:44 --> Final output sent to browser
DEBUG - 2023-06-01 03:45:44 --> Total execution time: 0.2921
INFO - 2023-06-01 03:45:44 --> Config Class Initialized
INFO - 2023-06-01 03:45:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:45:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:45:44 --> Utf8 Class Initialized
INFO - 2023-06-01 03:45:44 --> URI Class Initialized
INFO - 2023-06-01 03:45:44 --> Router Class Initialized
INFO - 2023-06-01 03:45:44 --> Output Class Initialized
INFO - 2023-06-01 03:45:44 --> Security Class Initialized
DEBUG - 2023-06-01 03:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:45:44 --> Input Class Initialized
INFO - 2023-06-01 03:45:44 --> Language Class Initialized
INFO - 2023-06-01 03:45:44 --> Loader Class Initialized
INFO - 2023-06-01 03:45:44 --> Controller Class Initialized
DEBUG - 2023-06-01 03:45:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:45:44 --> Database Driver Class Initialized
INFO - 2023-06-01 03:45:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:45:44 --> Final output sent to browser
DEBUG - 2023-06-01 03:45:44 --> Total execution time: 0.2241
INFO - 2023-06-01 03:46:42 --> Config Class Initialized
INFO - 2023-06-01 03:46:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:46:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:46:42 --> Utf8 Class Initialized
INFO - 2023-06-01 03:46:42 --> URI Class Initialized
INFO - 2023-06-01 03:46:42 --> Router Class Initialized
INFO - 2023-06-01 03:46:42 --> Output Class Initialized
INFO - 2023-06-01 03:46:43 --> Security Class Initialized
DEBUG - 2023-06-01 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:46:43 --> Input Class Initialized
INFO - 2023-06-01 03:46:43 --> Language Class Initialized
INFO - 2023-06-01 03:46:43 --> Loader Class Initialized
INFO - 2023-06-01 03:46:43 --> Controller Class Initialized
DEBUG - 2023-06-01 03:46:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:46:43 --> Database Driver Class Initialized
INFO - 2023-06-01 03:46:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:46:43 --> Final output sent to browser
DEBUG - 2023-06-01 03:46:43 --> Total execution time: 0.2693
INFO - 2023-06-01 03:46:43 --> Config Class Initialized
INFO - 2023-06-01 03:46:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:46:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:46:43 --> Utf8 Class Initialized
INFO - 2023-06-01 03:46:43 --> URI Class Initialized
INFO - 2023-06-01 03:46:43 --> Router Class Initialized
INFO - 2023-06-01 03:46:43 --> Output Class Initialized
INFO - 2023-06-01 03:46:43 --> Security Class Initialized
DEBUG - 2023-06-01 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:46:43 --> Input Class Initialized
INFO - 2023-06-01 03:46:43 --> Language Class Initialized
INFO - 2023-06-01 03:46:43 --> Loader Class Initialized
INFO - 2023-06-01 03:46:43 --> Controller Class Initialized
DEBUG - 2023-06-01 03:46:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:46:43 --> Database Driver Class Initialized
INFO - 2023-06-01 03:46:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:46:43 --> Final output sent to browser
DEBUG - 2023-06-01 03:46:43 --> Total execution time: 0.1883
INFO - 2023-06-01 03:47:36 --> Config Class Initialized
INFO - 2023-06-01 03:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:47:36 --> URI Class Initialized
INFO - 2023-06-01 03:47:36 --> Router Class Initialized
INFO - 2023-06-01 03:47:36 --> Output Class Initialized
INFO - 2023-06-01 03:47:36 --> Security Class Initialized
DEBUG - 2023-06-01 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:47:36 --> Input Class Initialized
INFO - 2023-06-01 03:47:36 --> Language Class Initialized
INFO - 2023-06-01 03:47:36 --> Loader Class Initialized
INFO - 2023-06-01 03:47:36 --> Controller Class Initialized
DEBUG - 2023-06-01 03:47:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-01 03:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:47:36 --> Final output sent to browser
DEBUG - 2023-06-01 03:47:36 --> Total execution time: 0.5769
INFO - 2023-06-01 03:47:36 --> Config Class Initialized
INFO - 2023-06-01 03:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-01 03:47:36 --> URI Class Initialized
INFO - 2023-06-01 03:47:36 --> Router Class Initialized
INFO - 2023-06-01 03:47:36 --> Output Class Initialized
INFO - 2023-06-01 03:47:36 --> Security Class Initialized
DEBUG - 2023-06-01 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:47:36 --> Input Class Initialized
INFO - 2023-06-01 03:47:36 --> Language Class Initialized
INFO - 2023-06-01 03:47:37 --> Loader Class Initialized
INFO - 2023-06-01 03:47:37 --> Controller Class Initialized
DEBUG - 2023-06-01 03:47:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:47:37 --> Database Driver Class Initialized
INFO - 2023-06-01 03:47:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:47:37 --> Final output sent to browser
DEBUG - 2023-06-01 03:47:37 --> Total execution time: 0.4035
INFO - 2023-06-01 03:48:08 --> Config Class Initialized
INFO - 2023-06-01 03:48:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:48:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:48:08 --> Utf8 Class Initialized
INFO - 2023-06-01 03:48:08 --> URI Class Initialized
INFO - 2023-06-01 03:48:09 --> Router Class Initialized
INFO - 2023-06-01 03:48:09 --> Output Class Initialized
INFO - 2023-06-01 03:48:09 --> Security Class Initialized
DEBUG - 2023-06-01 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:48:09 --> Input Class Initialized
INFO - 2023-06-01 03:48:09 --> Language Class Initialized
INFO - 2023-06-01 03:48:09 --> Loader Class Initialized
INFO - 2023-06-01 03:48:09 --> Controller Class Initialized
DEBUG - 2023-06-01 03:48:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:48:09 --> Database Driver Class Initialized
INFO - 2023-06-01 03:48:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:48:09 --> Final output sent to browser
DEBUG - 2023-06-01 03:48:09 --> Total execution time: 0.3468
INFO - 2023-06-01 03:48:09 --> Config Class Initialized
INFO - 2023-06-01 03:48:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 03:48:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 03:48:09 --> Utf8 Class Initialized
INFO - 2023-06-01 03:48:09 --> URI Class Initialized
INFO - 2023-06-01 03:48:09 --> Router Class Initialized
INFO - 2023-06-01 03:48:09 --> Output Class Initialized
INFO - 2023-06-01 03:48:09 --> Security Class Initialized
DEBUG - 2023-06-01 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 03:48:09 --> Input Class Initialized
INFO - 2023-06-01 03:48:09 --> Language Class Initialized
INFO - 2023-06-01 03:48:09 --> Loader Class Initialized
INFO - 2023-06-01 03:48:09 --> Controller Class Initialized
DEBUG - 2023-06-01 03:48:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 03:48:09 --> Database Driver Class Initialized
INFO - 2023-06-01 03:48:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 03:48:09 --> Final output sent to browser
DEBUG - 2023-06-01 03:48:09 --> Total execution time: 0.4875
INFO - 2023-06-01 04:27:36 --> Config Class Initialized
INFO - 2023-06-01 04:27:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:27:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:27:36 --> Utf8 Class Initialized
INFO - 2023-06-01 04:27:36 --> URI Class Initialized
INFO - 2023-06-01 04:27:36 --> Router Class Initialized
INFO - 2023-06-01 04:27:36 --> Output Class Initialized
INFO - 2023-06-01 04:27:36 --> Security Class Initialized
DEBUG - 2023-06-01 04:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:27:37 --> Input Class Initialized
INFO - 2023-06-01 04:27:37 --> Language Class Initialized
INFO - 2023-06-01 04:27:37 --> Loader Class Initialized
INFO - 2023-06-01 04:27:37 --> Controller Class Initialized
DEBUG - 2023-06-01 04:27:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:27:37 --> Database Driver Class Initialized
INFO - 2023-06-01 04:27:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:27:37 --> Final output sent to browser
DEBUG - 2023-06-01 04:27:37 --> Total execution time: 0.6038
INFO - 2023-06-01 04:27:37 --> Config Class Initialized
INFO - 2023-06-01 04:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:27:37 --> Utf8 Class Initialized
INFO - 2023-06-01 04:27:37 --> URI Class Initialized
INFO - 2023-06-01 04:27:37 --> Router Class Initialized
INFO - 2023-06-01 04:27:37 --> Output Class Initialized
INFO - 2023-06-01 04:27:37 --> Security Class Initialized
DEBUG - 2023-06-01 04:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:27:37 --> Input Class Initialized
INFO - 2023-06-01 04:27:37 --> Language Class Initialized
INFO - 2023-06-01 04:27:37 --> Loader Class Initialized
INFO - 2023-06-01 04:27:37 --> Controller Class Initialized
DEBUG - 2023-06-01 04:27:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:27:37 --> Database Driver Class Initialized
INFO - 2023-06-01 04:27:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:27:38 --> Final output sent to browser
DEBUG - 2023-06-01 04:27:38 --> Total execution time: 0.7906
INFO - 2023-06-01 04:28:26 --> Config Class Initialized
INFO - 2023-06-01 04:28:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:28:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:28:26 --> Utf8 Class Initialized
INFO - 2023-06-01 04:28:26 --> URI Class Initialized
INFO - 2023-06-01 04:28:26 --> Router Class Initialized
INFO - 2023-06-01 04:28:26 --> Output Class Initialized
INFO - 2023-06-01 04:28:26 --> Security Class Initialized
DEBUG - 2023-06-01 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:28:26 --> Input Class Initialized
INFO - 2023-06-01 04:28:26 --> Language Class Initialized
INFO - 2023-06-01 04:28:26 --> Loader Class Initialized
INFO - 2023-06-01 04:28:26 --> Controller Class Initialized
DEBUG - 2023-06-01 04:28:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:28:26 --> Database Driver Class Initialized
INFO - 2023-06-01 04:28:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:28:26 --> Final output sent to browser
DEBUG - 2023-06-01 04:28:26 --> Total execution time: 0.2080
INFO - 2023-06-01 04:28:26 --> Config Class Initialized
INFO - 2023-06-01 04:28:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:28:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:28:26 --> Utf8 Class Initialized
INFO - 2023-06-01 04:28:26 --> URI Class Initialized
INFO - 2023-06-01 04:28:26 --> Router Class Initialized
INFO - 2023-06-01 04:28:26 --> Output Class Initialized
INFO - 2023-06-01 04:28:26 --> Security Class Initialized
DEBUG - 2023-06-01 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:28:26 --> Input Class Initialized
INFO - 2023-06-01 04:28:27 --> Language Class Initialized
INFO - 2023-06-01 04:28:27 --> Loader Class Initialized
INFO - 2023-06-01 04:28:27 --> Controller Class Initialized
DEBUG - 2023-06-01 04:28:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:28:27 --> Database Driver Class Initialized
INFO - 2023-06-01 04:28:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:28:27 --> Final output sent to browser
DEBUG - 2023-06-01 04:28:27 --> Total execution time: 0.1648
INFO - 2023-06-01 04:28:56 --> Config Class Initialized
INFO - 2023-06-01 04:28:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:28:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:28:56 --> Utf8 Class Initialized
INFO - 2023-06-01 04:28:56 --> URI Class Initialized
INFO - 2023-06-01 04:28:56 --> Router Class Initialized
INFO - 2023-06-01 04:28:56 --> Output Class Initialized
INFO - 2023-06-01 04:28:56 --> Security Class Initialized
DEBUG - 2023-06-01 04:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:28:56 --> Input Class Initialized
INFO - 2023-06-01 04:28:56 --> Language Class Initialized
INFO - 2023-06-01 04:28:56 --> Loader Class Initialized
INFO - 2023-06-01 04:28:56 --> Controller Class Initialized
DEBUG - 2023-06-01 04:28:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:28:56 --> Database Driver Class Initialized
INFO - 2023-06-01 04:28:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:28:56 --> Final output sent to browser
DEBUG - 2023-06-01 04:28:56 --> Total execution time: 0.3048
INFO - 2023-06-01 04:28:56 --> Config Class Initialized
INFO - 2023-06-01 04:28:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:28:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:28:56 --> Utf8 Class Initialized
INFO - 2023-06-01 04:28:56 --> URI Class Initialized
INFO - 2023-06-01 04:28:56 --> Router Class Initialized
INFO - 2023-06-01 04:28:56 --> Output Class Initialized
INFO - 2023-06-01 04:28:56 --> Security Class Initialized
DEBUG - 2023-06-01 04:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:28:56 --> Input Class Initialized
INFO - 2023-06-01 04:28:56 --> Language Class Initialized
INFO - 2023-06-01 04:28:56 --> Loader Class Initialized
INFO - 2023-06-01 04:28:56 --> Controller Class Initialized
DEBUG - 2023-06-01 04:28:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:28:57 --> Database Driver Class Initialized
INFO - 2023-06-01 04:28:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:28:57 --> Final output sent to browser
DEBUG - 2023-06-01 04:28:57 --> Total execution time: 0.2329
INFO - 2023-06-01 04:29:06 --> Config Class Initialized
INFO - 2023-06-01 04:29:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:29:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:29:06 --> Utf8 Class Initialized
INFO - 2023-06-01 04:29:06 --> URI Class Initialized
INFO - 2023-06-01 04:29:06 --> Router Class Initialized
INFO - 2023-06-01 04:29:06 --> Output Class Initialized
INFO - 2023-06-01 04:29:06 --> Security Class Initialized
DEBUG - 2023-06-01 04:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:29:06 --> Input Class Initialized
INFO - 2023-06-01 04:29:06 --> Language Class Initialized
INFO - 2023-06-01 04:29:06 --> Loader Class Initialized
INFO - 2023-06-01 04:29:06 --> Controller Class Initialized
DEBUG - 2023-06-01 04:29:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:29:06 --> Database Driver Class Initialized
INFO - 2023-06-01 04:29:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:29:06 --> Final output sent to browser
DEBUG - 2023-06-01 04:29:06 --> Total execution time: 0.1701
INFO - 2023-06-01 04:29:06 --> Config Class Initialized
INFO - 2023-06-01 04:29:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:29:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:29:06 --> Utf8 Class Initialized
INFO - 2023-06-01 04:29:06 --> URI Class Initialized
INFO - 2023-06-01 04:29:07 --> Router Class Initialized
INFO - 2023-06-01 04:29:07 --> Output Class Initialized
INFO - 2023-06-01 04:29:07 --> Security Class Initialized
DEBUG - 2023-06-01 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:29:07 --> Input Class Initialized
INFO - 2023-06-01 04:29:07 --> Language Class Initialized
INFO - 2023-06-01 04:29:07 --> Loader Class Initialized
INFO - 2023-06-01 04:29:07 --> Controller Class Initialized
DEBUG - 2023-06-01 04:29:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:29:07 --> Database Driver Class Initialized
INFO - 2023-06-01 04:29:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:29:07 --> Final output sent to browser
DEBUG - 2023-06-01 04:29:07 --> Total execution time: 0.1993
INFO - 2023-06-01 04:30:27 --> Config Class Initialized
INFO - 2023-06-01 04:30:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:30:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:30:27 --> Utf8 Class Initialized
INFO - 2023-06-01 04:30:27 --> URI Class Initialized
INFO - 2023-06-01 04:30:27 --> Router Class Initialized
INFO - 2023-06-01 04:30:27 --> Output Class Initialized
INFO - 2023-06-01 04:30:27 --> Security Class Initialized
DEBUG - 2023-06-01 04:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:30:27 --> Input Class Initialized
INFO - 2023-06-01 04:30:27 --> Language Class Initialized
INFO - 2023-06-01 04:30:27 --> Loader Class Initialized
INFO - 2023-06-01 04:30:27 --> Controller Class Initialized
DEBUG - 2023-06-01 04:30:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:30:27 --> Database Driver Class Initialized
INFO - 2023-06-01 04:30:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:30:27 --> Final output sent to browser
DEBUG - 2023-06-01 04:30:27 --> Total execution time: 0.3138
INFO - 2023-06-01 04:30:27 --> Config Class Initialized
INFO - 2023-06-01 04:30:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:30:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:30:27 --> Utf8 Class Initialized
INFO - 2023-06-01 04:30:27 --> URI Class Initialized
INFO - 2023-06-01 04:30:27 --> Router Class Initialized
INFO - 2023-06-01 04:30:27 --> Output Class Initialized
INFO - 2023-06-01 04:30:27 --> Security Class Initialized
DEBUG - 2023-06-01 04:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:30:27 --> Input Class Initialized
INFO - 2023-06-01 04:30:27 --> Language Class Initialized
INFO - 2023-06-01 04:30:27 --> Loader Class Initialized
INFO - 2023-06-01 04:30:27 --> Controller Class Initialized
DEBUG - 2023-06-01 04:30:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:30:27 --> Database Driver Class Initialized
INFO - 2023-06-01 04:30:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:30:27 --> Final output sent to browser
DEBUG - 2023-06-01 04:30:27 --> Total execution time: 0.2852
INFO - 2023-06-01 04:31:47 --> Config Class Initialized
INFO - 2023-06-01 04:31:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:47 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:47 --> URI Class Initialized
INFO - 2023-06-01 04:31:47 --> Router Class Initialized
INFO - 2023-06-01 04:31:48 --> Output Class Initialized
INFO - 2023-06-01 04:31:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:48 --> Input Class Initialized
INFO - 2023-06-01 04:31:48 --> Language Class Initialized
INFO - 2023-06-01 04:31:48 --> Loader Class Initialized
INFO - 2023-06-01 04:31:48 --> Controller Class Initialized
INFO - 2023-06-01 04:31:48 --> Helper loaded: form_helper
INFO - 2023-06-01 04:31:48 --> Helper loaded: url_helper
DEBUG - 2023-06-01 04:31:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:48 --> Model "Change_model" initialized
INFO - 2023-06-01 04:31:48 --> Model "Grafana_model" initialized
INFO - 2023-06-01 04:31:48 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:48 --> Total execution time: 0.3108
INFO - 2023-06-01 04:31:48 --> Config Class Initialized
INFO - 2023-06-01 04:31:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:48 --> URI Class Initialized
INFO - 2023-06-01 04:31:48 --> Router Class Initialized
INFO - 2023-06-01 04:31:48 --> Output Class Initialized
INFO - 2023-06-01 04:31:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:48 --> Input Class Initialized
INFO - 2023-06-01 04:31:48 --> Language Class Initialized
INFO - 2023-06-01 04:31:48 --> Loader Class Initialized
INFO - 2023-06-01 04:31:48 --> Controller Class Initialized
INFO - 2023-06-01 04:31:48 --> Helper loaded: form_helper
INFO - 2023-06-01 04:31:48 --> Helper loaded: url_helper
DEBUG - 2023-06-01 04:31:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:48 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:48 --> Total execution time: 0.1422
INFO - 2023-06-01 04:31:48 --> Config Class Initialized
INFO - 2023-06-01 04:31:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:48 --> URI Class Initialized
INFO - 2023-06-01 04:31:48 --> Router Class Initialized
INFO - 2023-06-01 04:31:48 --> Output Class Initialized
INFO - 2023-06-01 04:31:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:48 --> Input Class Initialized
INFO - 2023-06-01 04:31:48 --> Language Class Initialized
INFO - 2023-06-01 04:31:48 --> Loader Class Initialized
INFO - 2023-06-01 04:31:48 --> Controller Class Initialized
INFO - 2023-06-01 04:31:48 --> Helper loaded: form_helper
INFO - 2023-06-01 04:31:48 --> Helper loaded: url_helper
DEBUG - 2023-06-01 04:31:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:48 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:48 --> Model "Login_model" initialized
INFO - 2023-06-01 04:31:48 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:48 --> Total execution time: 0.2329
INFO - 2023-06-01 04:31:48 --> Config Class Initialized
INFO - 2023-06-01 04:31:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:48 --> URI Class Initialized
INFO - 2023-06-01 04:31:48 --> Router Class Initialized
INFO - 2023-06-01 04:31:48 --> Output Class Initialized
INFO - 2023-06-01 04:31:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:48 --> Input Class Initialized
INFO - 2023-06-01 04:31:48 --> Language Class Initialized
INFO - 2023-06-01 04:31:48 --> Loader Class Initialized
INFO - 2023-06-01 04:31:48 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:48 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:48 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:48 --> Total execution time: 0.1811
INFO - 2023-06-01 04:31:48 --> Config Class Initialized
INFO - 2023-06-01 04:31:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:48 --> URI Class Initialized
INFO - 2023-06-01 04:31:48 --> Router Class Initialized
INFO - 2023-06-01 04:31:48 --> Output Class Initialized
INFO - 2023-06-01 04:31:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:49 --> Input Class Initialized
INFO - 2023-06-01 04:31:49 --> Language Class Initialized
INFO - 2023-06-01 04:31:49 --> Loader Class Initialized
INFO - 2023-06-01 04:31:49 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:49 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:49 --> Total execution time: 0.1752
INFO - 2023-06-01 04:31:49 --> Config Class Initialized
INFO - 2023-06-01 04:31:49 --> Config Class Initialized
INFO - 2023-06-01 04:31:49 --> Hooks Class Initialized
INFO - 2023-06-01 04:31:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 04:31:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:49 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:49 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:49 --> URI Class Initialized
INFO - 2023-06-01 04:31:49 --> URI Class Initialized
INFO - 2023-06-01 04:31:49 --> Router Class Initialized
INFO - 2023-06-01 04:31:49 --> Router Class Initialized
INFO - 2023-06-01 04:31:49 --> Output Class Initialized
INFO - 2023-06-01 04:31:49 --> Output Class Initialized
INFO - 2023-06-01 04:31:49 --> Security Class Initialized
INFO - 2023-06-01 04:31:49 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:49 --> Input Class Initialized
INFO - 2023-06-01 04:31:49 --> Input Class Initialized
INFO - 2023-06-01 04:31:49 --> Language Class Initialized
INFO - 2023-06-01 04:31:49 --> Language Class Initialized
INFO - 2023-06-01 04:31:49 --> Loader Class Initialized
INFO - 2023-06-01 04:31:49 --> Loader Class Initialized
INFO - 2023-06-01 04:31:49 --> Controller Class Initialized
INFO - 2023-06-01 04:31:49 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 04:31:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:49 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:49 --> Total execution time: 0.1846
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:49 --> Config Class Initialized
INFO - 2023-06-01 04:31:49 --> Hooks Class Initialized
INFO - 2023-06-01 04:31:49 --> Model "Login_model" initialized
DEBUG - 2023-06-01 04:31:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:49 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:49 --> URI Class Initialized
INFO - 2023-06-01 04:31:49 --> Router Class Initialized
INFO - 2023-06-01 04:31:49 --> Output Class Initialized
INFO - 2023-06-01 04:31:49 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:49 --> Input Class Initialized
INFO - 2023-06-01 04:31:49 --> Language Class Initialized
INFO - 2023-06-01 04:31:49 --> Loader Class Initialized
INFO - 2023-06-01 04:31:49 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:49 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:49 --> Total execution time: 0.2239
INFO - 2023-06-01 04:31:49 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:49 --> Total execution time: 0.4959
INFO - 2023-06-01 04:31:49 --> Config Class Initialized
INFO - 2023-06-01 04:31:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:49 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:49 --> URI Class Initialized
INFO - 2023-06-01 04:31:49 --> Router Class Initialized
INFO - 2023-06-01 04:31:49 --> Output Class Initialized
INFO - 2023-06-01 04:31:49 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:49 --> Input Class Initialized
INFO - 2023-06-01 04:31:49 --> Language Class Initialized
INFO - 2023-06-01 04:31:49 --> Loader Class Initialized
INFO - 2023-06-01 04:31:49 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:49 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:50 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:50 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:50 --> Model "Login_model" initialized
INFO - 2023-06-01 04:31:50 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:50 --> Total execution time: 1.0604
INFO - 2023-06-01 04:31:52 --> Config Class Initialized
INFO - 2023-06-01 04:31:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:52 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:52 --> URI Class Initialized
INFO - 2023-06-01 04:31:52 --> Router Class Initialized
INFO - 2023-06-01 04:31:52 --> Output Class Initialized
INFO - 2023-06-01 04:31:52 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:52 --> Input Class Initialized
INFO - 2023-06-01 04:31:52 --> Language Class Initialized
INFO - 2023-06-01 04:31:52 --> Loader Class Initialized
INFO - 2023-06-01 04:31:52 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:53 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:53 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:53 --> Total execution time: 0.1919
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:53 --> Output Class Initialized
INFO - 2023-06-01 04:31:53 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:53 --> Input Class Initialized
INFO - 2023-06-01 04:31:53 --> Language Class Initialized
INFO - 2023-06-01 04:31:53 --> Loader Class Initialized
INFO - 2023-06-01 04:31:53 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:53 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:53 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:53 --> Total execution time: 0.1970
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:53 --> Output Class Initialized
INFO - 2023-06-01 04:31:53 --> Output Class Initialized
INFO - 2023-06-01 04:31:53 --> Security Class Initialized
INFO - 2023-06-01 04:31:53 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:53 --> Output Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:53 --> Input Class Initialized
INFO - 2023-06-01 04:31:53 --> Input Class Initialized
INFO - 2023-06-01 04:31:53 --> Language Class Initialized
INFO - 2023-06-01 04:31:53 --> Language Class Initialized
INFO - 2023-06-01 04:31:53 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:53 --> Input Class Initialized
INFO - 2023-06-01 04:31:53 --> Loader Class Initialized
INFO - 2023-06-01 04:31:53 --> Loader Class Initialized
INFO - 2023-06-01 04:31:53 --> Language Class Initialized
INFO - 2023-06-01 04:31:53 --> Controller Class Initialized
INFO - 2023-06-01 04:31:53 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 04:31:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:53 --> Loader Class Initialized
INFO - 2023-06-01 04:31:53 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:53 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:53 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:53 --> Final output sent to browser
INFO - 2023-06-01 04:31:53 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:53 --> Total execution time: 0.1708
DEBUG - 2023-06-01 04:31:53 --> Total execution time: 0.1715
INFO - 2023-06-01 04:31:53 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Config Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
INFO - 2023-06-01 04:31:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 04:31:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> URI Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:53 --> Router Class Initialized
INFO - 2023-06-01 04:31:54 --> Final output sent to browser
INFO - 2023-06-01 04:31:54 --> Output Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Total execution time: 0.2658
INFO - 2023-06-01 04:31:54 --> Output Class Initialized
INFO - 2023-06-01 04:31:54 --> Security Class Initialized
INFO - 2023-06-01 04:31:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:54 --> Input Class Initialized
INFO - 2023-06-01 04:31:54 --> Input Class Initialized
INFO - 2023-06-01 04:31:54 --> Language Class Initialized
INFO - 2023-06-01 04:31:54 --> Language Class Initialized
INFO - 2023-06-01 04:31:54 --> Loader Class Initialized
INFO - 2023-06-01 04:31:54 --> Loader Class Initialized
INFO - 2023-06-01 04:31:54 --> Controller Class Initialized
INFO - 2023-06-01 04:31:54 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 04:31:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:54 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:54 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:54 --> Final output sent to browser
INFO - 2023-06-01 04:31:54 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:54 --> Total execution time: 0.1868
DEBUG - 2023-06-01 04:31:54 --> Total execution time: 0.1858
INFO - 2023-06-01 04:31:54 --> Config Class Initialized
INFO - 2023-06-01 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:54 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:54 --> URI Class Initialized
INFO - 2023-06-01 04:31:54 --> Router Class Initialized
INFO - 2023-06-01 04:31:54 --> Output Class Initialized
INFO - 2023-06-01 04:31:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:54 --> Input Class Initialized
INFO - 2023-06-01 04:31:54 --> Language Class Initialized
INFO - 2023-06-01 04:31:54 --> Loader Class Initialized
INFO - 2023-06-01 04:31:54 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:54 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:54 --> Config Class Initialized
INFO - 2023-06-01 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:54 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:54 --> URI Class Initialized
INFO - 2023-06-01 04:31:54 --> Router Class Initialized
INFO - 2023-06-01 04:31:54 --> Output Class Initialized
INFO - 2023-06-01 04:31:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:54 --> Input Class Initialized
INFO - 2023-06-01 04:31:54 --> Language Class Initialized
INFO - 2023-06-01 04:31:54 --> Loader Class Initialized
INFO - 2023-06-01 04:31:54 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:54 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:54 --> Config Class Initialized
INFO - 2023-06-01 04:31:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:31:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:31:54 --> Utf8 Class Initialized
INFO - 2023-06-01 04:31:54 --> URI Class Initialized
INFO - 2023-06-01 04:31:54 --> Router Class Initialized
INFO - 2023-06-01 04:31:54 --> Output Class Initialized
INFO - 2023-06-01 04:31:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:31:54 --> Input Class Initialized
INFO - 2023-06-01 04:31:54 --> Language Class Initialized
INFO - 2023-06-01 04:31:55 --> Loader Class Initialized
INFO - 2023-06-01 04:31:55 --> Controller Class Initialized
DEBUG - 2023-06-01 04:31:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:31:55 --> Database Driver Class Initialized
INFO - 2023-06-01 04:31:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:31:55 --> Final output sent to browser
DEBUG - 2023-06-01 04:31:55 --> Total execution time: 0.2509
INFO - 2023-06-01 04:32:13 --> Config Class Initialized
INFO - 2023-06-01 04:32:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:13 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:13 --> URI Class Initialized
INFO - 2023-06-01 04:32:13 --> Router Class Initialized
INFO - 2023-06-01 04:32:13 --> Output Class Initialized
INFO - 2023-06-01 04:32:13 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:13 --> Input Class Initialized
INFO - 2023-06-01 04:32:13 --> Language Class Initialized
INFO - 2023-06-01 04:32:13 --> Loader Class Initialized
INFO - 2023-06-01 04:32:13 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:13 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:32:13 --> Final output sent to browser
DEBUG - 2023-06-01 04:32:13 --> Total execution time: 0.1884
INFO - 2023-06-01 04:32:13 --> Config Class Initialized
INFO - 2023-06-01 04:32:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:13 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:13 --> URI Class Initialized
INFO - 2023-06-01 04:32:13 --> Router Class Initialized
INFO - 2023-06-01 04:32:13 --> Output Class Initialized
INFO - 2023-06-01 04:32:13 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:13 --> Input Class Initialized
INFO - 2023-06-01 04:32:13 --> Language Class Initialized
INFO - 2023-06-01 04:32:13 --> Loader Class Initialized
INFO - 2023-06-01 04:32:13 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:13 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:32:13 --> Final output sent to browser
DEBUG - 2023-06-01 04:32:13 --> Total execution time: 0.3911
INFO - 2023-06-01 04:32:46 --> Config Class Initialized
INFO - 2023-06-01 04:32:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:46 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:46 --> URI Class Initialized
INFO - 2023-06-01 04:32:46 --> Router Class Initialized
INFO - 2023-06-01 04:32:46 --> Output Class Initialized
INFO - 2023-06-01 04:32:46 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:46 --> Input Class Initialized
INFO - 2023-06-01 04:32:46 --> Language Class Initialized
INFO - 2023-06-01 04:32:46 --> Loader Class Initialized
INFO - 2023-06-01 04:32:46 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:46 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:32:46 --> Final output sent to browser
DEBUG - 2023-06-01 04:32:46 --> Total execution time: 0.3799
INFO - 2023-06-01 04:32:46 --> Config Class Initialized
INFO - 2023-06-01 04:32:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:46 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:46 --> URI Class Initialized
INFO - 2023-06-01 04:32:46 --> Router Class Initialized
INFO - 2023-06-01 04:32:46 --> Output Class Initialized
INFO - 2023-06-01 04:32:46 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:46 --> Input Class Initialized
INFO - 2023-06-01 04:32:46 --> Language Class Initialized
INFO - 2023-06-01 04:32:46 --> Loader Class Initialized
INFO - 2023-06-01 04:32:46 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:46 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:32:56 --> Config Class Initialized
INFO - 2023-06-01 04:32:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:57 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:57 --> URI Class Initialized
INFO - 2023-06-01 04:32:57 --> Router Class Initialized
INFO - 2023-06-01 04:32:57 --> Output Class Initialized
INFO - 2023-06-01 04:32:57 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:57 --> Input Class Initialized
INFO - 2023-06-01 04:32:57 --> Language Class Initialized
INFO - 2023-06-01 04:32:57 --> Loader Class Initialized
INFO - 2023-06-01 04:32:57 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:57 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:32:57 --> Final output sent to browser
DEBUG - 2023-06-01 04:32:57 --> Total execution time: 0.4424
INFO - 2023-06-01 04:32:57 --> Config Class Initialized
INFO - 2023-06-01 04:32:57 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:32:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:32:57 --> Utf8 Class Initialized
INFO - 2023-06-01 04:32:57 --> URI Class Initialized
INFO - 2023-06-01 04:32:57 --> Router Class Initialized
INFO - 2023-06-01 04:32:57 --> Output Class Initialized
INFO - 2023-06-01 04:32:57 --> Security Class Initialized
DEBUG - 2023-06-01 04:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:32:57 --> Input Class Initialized
INFO - 2023-06-01 04:32:57 --> Language Class Initialized
INFO - 2023-06-01 04:32:57 --> Loader Class Initialized
INFO - 2023-06-01 04:32:57 --> Controller Class Initialized
DEBUG - 2023-06-01 04:32:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:32:57 --> Database Driver Class Initialized
INFO - 2023-06-01 04:32:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:19 --> Config Class Initialized
INFO - 2023-06-01 04:33:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:19 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:19 --> URI Class Initialized
INFO - 2023-06-01 04:33:19 --> Router Class Initialized
INFO - 2023-06-01 04:33:19 --> Output Class Initialized
INFO - 2023-06-01 04:33:19 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:19 --> Input Class Initialized
INFO - 2023-06-01 04:33:19 --> Language Class Initialized
INFO - 2023-06-01 04:33:19 --> Loader Class Initialized
INFO - 2023-06-01 04:33:19 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:19 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:19 --> Final output sent to browser
DEBUG - 2023-06-01 04:33:19 --> Total execution time: 0.2597
INFO - 2023-06-01 04:33:19 --> Config Class Initialized
INFO - 2023-06-01 04:33:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:19 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:19 --> URI Class Initialized
INFO - 2023-06-01 04:33:19 --> Router Class Initialized
INFO - 2023-06-01 04:33:19 --> Output Class Initialized
INFO - 2023-06-01 04:33:19 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:19 --> Input Class Initialized
INFO - 2023-06-01 04:33:19 --> Language Class Initialized
INFO - 2023-06-01 04:33:19 --> Loader Class Initialized
INFO - 2023-06-01 04:33:19 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:19 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:32 --> Config Class Initialized
INFO - 2023-06-01 04:33:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:32 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:32 --> URI Class Initialized
INFO - 2023-06-01 04:33:32 --> Router Class Initialized
INFO - 2023-06-01 04:33:32 --> Output Class Initialized
INFO - 2023-06-01 04:33:32 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:32 --> Input Class Initialized
INFO - 2023-06-01 04:33:32 --> Language Class Initialized
INFO - 2023-06-01 04:33:32 --> Loader Class Initialized
INFO - 2023-06-01 04:33:32 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:32 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:32 --> Final output sent to browser
DEBUG - 2023-06-01 04:33:32 --> Total execution time: 0.2673
INFO - 2023-06-01 04:33:32 --> Config Class Initialized
INFO - 2023-06-01 04:33:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:32 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:32 --> URI Class Initialized
INFO - 2023-06-01 04:33:32 --> Router Class Initialized
INFO - 2023-06-01 04:33:32 --> Output Class Initialized
INFO - 2023-06-01 04:33:32 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:32 --> Input Class Initialized
INFO - 2023-06-01 04:33:32 --> Language Class Initialized
INFO - 2023-06-01 04:33:32 --> Loader Class Initialized
INFO - 2023-06-01 04:33:32 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:32 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:32 --> Final output sent to browser
DEBUG - 2023-06-01 04:33:32 --> Total execution time: 0.2573
INFO - 2023-06-01 04:33:54 --> Config Class Initialized
INFO - 2023-06-01 04:33:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:54 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:54 --> URI Class Initialized
INFO - 2023-06-01 04:33:54 --> Router Class Initialized
INFO - 2023-06-01 04:33:54 --> Output Class Initialized
INFO - 2023-06-01 04:33:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:54 --> Input Class Initialized
INFO - 2023-06-01 04:33:54 --> Language Class Initialized
INFO - 2023-06-01 04:33:54 --> Loader Class Initialized
INFO - 2023-06-01 04:33:54 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:54 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:33:54 --> Final output sent to browser
DEBUG - 2023-06-01 04:33:54 --> Total execution time: 0.4402
INFO - 2023-06-01 04:33:54 --> Config Class Initialized
INFO - 2023-06-01 04:33:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:33:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:33:54 --> Utf8 Class Initialized
INFO - 2023-06-01 04:33:54 --> URI Class Initialized
INFO - 2023-06-01 04:33:54 --> Router Class Initialized
INFO - 2023-06-01 04:33:54 --> Output Class Initialized
INFO - 2023-06-01 04:33:54 --> Security Class Initialized
DEBUG - 2023-06-01 04:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:33:54 --> Input Class Initialized
INFO - 2023-06-01 04:33:54 --> Language Class Initialized
INFO - 2023-06-01 04:33:55 --> Loader Class Initialized
INFO - 2023-06-01 04:33:55 --> Controller Class Initialized
DEBUG - 2023-06-01 04:33:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:33:55 --> Database Driver Class Initialized
INFO - 2023-06-01 04:33:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:34:40 --> Config Class Initialized
INFO - 2023-06-01 04:34:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:34:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:34:40 --> Utf8 Class Initialized
INFO - 2023-06-01 04:34:40 --> URI Class Initialized
INFO - 2023-06-01 04:34:40 --> Router Class Initialized
INFO - 2023-06-01 04:34:40 --> Output Class Initialized
INFO - 2023-06-01 04:34:40 --> Security Class Initialized
DEBUG - 2023-06-01 04:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:34:40 --> Input Class Initialized
INFO - 2023-06-01 04:34:40 --> Language Class Initialized
INFO - 2023-06-01 04:34:40 --> Loader Class Initialized
INFO - 2023-06-01 04:34:40 --> Controller Class Initialized
DEBUG - 2023-06-01 04:34:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:34:40 --> Database Driver Class Initialized
INFO - 2023-06-01 04:34:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:34:40 --> Final output sent to browser
DEBUG - 2023-06-01 04:34:40 --> Total execution time: 0.2596
INFO - 2023-06-01 04:34:40 --> Config Class Initialized
INFO - 2023-06-01 04:34:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:34:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:34:40 --> Utf8 Class Initialized
INFO - 2023-06-01 04:34:40 --> URI Class Initialized
INFO - 2023-06-01 04:34:40 --> Router Class Initialized
INFO - 2023-06-01 04:34:41 --> Output Class Initialized
INFO - 2023-06-01 04:34:41 --> Security Class Initialized
DEBUG - 2023-06-01 04:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:34:41 --> Input Class Initialized
INFO - 2023-06-01 04:34:41 --> Language Class Initialized
INFO - 2023-06-01 04:34:41 --> Loader Class Initialized
INFO - 2023-06-01 04:34:41 --> Controller Class Initialized
DEBUG - 2023-06-01 04:34:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:34:41 --> Database Driver Class Initialized
INFO - 2023-06-01 04:34:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:34:51 --> Config Class Initialized
INFO - 2023-06-01 04:34:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:34:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:34:51 --> Utf8 Class Initialized
INFO - 2023-06-01 04:34:51 --> URI Class Initialized
INFO - 2023-06-01 04:34:51 --> Router Class Initialized
INFO - 2023-06-01 04:34:51 --> Output Class Initialized
INFO - 2023-06-01 04:34:51 --> Security Class Initialized
DEBUG - 2023-06-01 04:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:34:51 --> Input Class Initialized
INFO - 2023-06-01 04:34:51 --> Language Class Initialized
INFO - 2023-06-01 04:34:51 --> Loader Class Initialized
INFO - 2023-06-01 04:34:51 --> Controller Class Initialized
DEBUG - 2023-06-01 04:34:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:34:51 --> Database Driver Class Initialized
INFO - 2023-06-01 04:34:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:34:51 --> Final output sent to browser
DEBUG - 2023-06-01 04:34:51 --> Total execution time: 0.2601
INFO - 2023-06-01 04:34:51 --> Config Class Initialized
INFO - 2023-06-01 04:34:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:34:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:34:51 --> Utf8 Class Initialized
INFO - 2023-06-01 04:34:51 --> URI Class Initialized
INFO - 2023-06-01 04:34:51 --> Router Class Initialized
INFO - 2023-06-01 04:34:51 --> Output Class Initialized
INFO - 2023-06-01 04:34:51 --> Security Class Initialized
DEBUG - 2023-06-01 04:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:34:51 --> Input Class Initialized
INFO - 2023-06-01 04:34:51 --> Language Class Initialized
INFO - 2023-06-01 04:34:51 --> Loader Class Initialized
INFO - 2023-06-01 04:34:51 --> Controller Class Initialized
DEBUG - 2023-06-01 04:34:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:34:51 --> Database Driver Class Initialized
INFO - 2023-06-01 04:34:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:34:51 --> Final output sent to browser
DEBUG - 2023-06-01 04:34:51 --> Total execution time: 0.2194
INFO - 2023-06-01 04:35:05 --> Config Class Initialized
INFO - 2023-06-01 04:35:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:35:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:35:05 --> Utf8 Class Initialized
INFO - 2023-06-01 04:35:05 --> URI Class Initialized
INFO - 2023-06-01 04:35:05 --> Router Class Initialized
INFO - 2023-06-01 04:35:05 --> Output Class Initialized
INFO - 2023-06-01 04:35:05 --> Security Class Initialized
DEBUG - 2023-06-01 04:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:35:05 --> Input Class Initialized
INFO - 2023-06-01 04:35:05 --> Language Class Initialized
INFO - 2023-06-01 04:35:05 --> Loader Class Initialized
INFO - 2023-06-01 04:35:06 --> Controller Class Initialized
DEBUG - 2023-06-01 04:35:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:35:06 --> Database Driver Class Initialized
INFO - 2023-06-01 04:35:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:35:06 --> Final output sent to browser
DEBUG - 2023-06-01 04:35:06 --> Total execution time: 0.2690
INFO - 2023-06-01 04:35:06 --> Config Class Initialized
INFO - 2023-06-01 04:35:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:35:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:35:06 --> Utf8 Class Initialized
INFO - 2023-06-01 04:35:06 --> URI Class Initialized
INFO - 2023-06-01 04:35:06 --> Router Class Initialized
INFO - 2023-06-01 04:35:06 --> Output Class Initialized
INFO - 2023-06-01 04:35:06 --> Security Class Initialized
DEBUG - 2023-06-01 04:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:35:06 --> Input Class Initialized
INFO - 2023-06-01 04:35:06 --> Language Class Initialized
INFO - 2023-06-01 04:35:06 --> Loader Class Initialized
INFO - 2023-06-01 04:35:06 --> Controller Class Initialized
DEBUG - 2023-06-01 04:35:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:35:06 --> Database Driver Class Initialized
INFO - 2023-06-01 04:35:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:35:28 --> Config Class Initialized
INFO - 2023-06-01 04:35:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:35:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:35:28 --> Utf8 Class Initialized
INFO - 2023-06-01 04:35:28 --> URI Class Initialized
INFO - 2023-06-01 04:35:28 --> Router Class Initialized
INFO - 2023-06-01 04:35:28 --> Output Class Initialized
INFO - 2023-06-01 04:35:28 --> Security Class Initialized
DEBUG - 2023-06-01 04:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:35:28 --> Input Class Initialized
INFO - 2023-06-01 04:35:28 --> Language Class Initialized
INFO - 2023-06-01 04:35:28 --> Loader Class Initialized
INFO - 2023-06-01 04:35:28 --> Controller Class Initialized
DEBUG - 2023-06-01 04:35:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:35:28 --> Database Driver Class Initialized
INFO - 2023-06-01 04:35:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:35:28 --> Final output sent to browser
DEBUG - 2023-06-01 04:35:28 --> Total execution time: 0.2427
INFO - 2023-06-01 04:35:28 --> Config Class Initialized
INFO - 2023-06-01 04:35:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:35:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:35:28 --> Utf8 Class Initialized
INFO - 2023-06-01 04:35:28 --> URI Class Initialized
INFO - 2023-06-01 04:35:28 --> Router Class Initialized
INFO - 2023-06-01 04:35:28 --> Output Class Initialized
INFO - 2023-06-01 04:35:28 --> Security Class Initialized
DEBUG - 2023-06-01 04:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:35:28 --> Input Class Initialized
INFO - 2023-06-01 04:35:28 --> Language Class Initialized
INFO - 2023-06-01 04:35:28 --> Loader Class Initialized
INFO - 2023-06-01 04:35:29 --> Controller Class Initialized
DEBUG - 2023-06-01 04:35:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:35:29 --> Database Driver Class Initialized
INFO - 2023-06-01 04:35:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:39:35 --> Config Class Initialized
INFO - 2023-06-01 04:39:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:39:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:39:35 --> Utf8 Class Initialized
INFO - 2023-06-01 04:39:35 --> URI Class Initialized
INFO - 2023-06-01 04:39:35 --> Router Class Initialized
INFO - 2023-06-01 04:39:35 --> Output Class Initialized
INFO - 2023-06-01 04:39:35 --> Security Class Initialized
DEBUG - 2023-06-01 04:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:39:35 --> Input Class Initialized
INFO - 2023-06-01 04:39:36 --> Language Class Initialized
INFO - 2023-06-01 04:39:36 --> Loader Class Initialized
INFO - 2023-06-01 04:39:36 --> Controller Class Initialized
DEBUG - 2023-06-01 04:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:39:36 --> Database Driver Class Initialized
INFO - 2023-06-01 04:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:39:36 --> Final output sent to browser
DEBUG - 2023-06-01 04:39:36 --> Total execution time: 0.3513
INFO - 2023-06-01 04:39:36 --> Config Class Initialized
INFO - 2023-06-01 04:39:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:39:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:39:36 --> Utf8 Class Initialized
INFO - 2023-06-01 04:39:36 --> URI Class Initialized
INFO - 2023-06-01 04:39:36 --> Router Class Initialized
INFO - 2023-06-01 04:39:36 --> Output Class Initialized
INFO - 2023-06-01 04:39:36 --> Security Class Initialized
DEBUG - 2023-06-01 04:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:39:36 --> Input Class Initialized
INFO - 2023-06-01 04:39:36 --> Language Class Initialized
INFO - 2023-06-01 04:39:36 --> Loader Class Initialized
INFO - 2023-06-01 04:39:36 --> Controller Class Initialized
DEBUG - 2023-06-01 04:39:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:39:36 --> Database Driver Class Initialized
INFO - 2023-06-01 04:39:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:39:47 --> Config Class Initialized
INFO - 2023-06-01 04:39:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:39:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:39:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:39:48 --> URI Class Initialized
INFO - 2023-06-01 04:39:48 --> Router Class Initialized
INFO - 2023-06-01 04:39:48 --> Output Class Initialized
INFO - 2023-06-01 04:39:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:39:48 --> Input Class Initialized
INFO - 2023-06-01 04:39:48 --> Language Class Initialized
INFO - 2023-06-01 04:39:48 --> Loader Class Initialized
INFO - 2023-06-01 04:39:48 --> Controller Class Initialized
DEBUG - 2023-06-01 04:39:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:39:48 --> Database Driver Class Initialized
INFO - 2023-06-01 04:39:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 04:39:48 --> Final output sent to browser
DEBUG - 2023-06-01 04:39:48 --> Total execution time: 0.7112
INFO - 2023-06-01 04:39:48 --> Config Class Initialized
INFO - 2023-06-01 04:39:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 04:39:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 04:39:48 --> Utf8 Class Initialized
INFO - 2023-06-01 04:39:48 --> URI Class Initialized
INFO - 2023-06-01 04:39:48 --> Router Class Initialized
INFO - 2023-06-01 04:39:48 --> Output Class Initialized
INFO - 2023-06-01 04:39:48 --> Security Class Initialized
DEBUG - 2023-06-01 04:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 04:39:48 --> Input Class Initialized
INFO - 2023-06-01 04:39:48 --> Language Class Initialized
INFO - 2023-06-01 04:39:48 --> Loader Class Initialized
INFO - 2023-06-01 04:39:48 --> Controller Class Initialized
DEBUG - 2023-06-01 04:39:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 04:39:48 --> Database Driver Class Initialized
INFO - 2023-06-01 04:39:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:32:48 --> Config Class Initialized
INFO - 2023-06-01 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-01 05:32:48 --> URI Class Initialized
INFO - 2023-06-01 05:32:48 --> Router Class Initialized
INFO - 2023-06-01 05:32:48 --> Output Class Initialized
INFO - 2023-06-01 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-01 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:32:48 --> Input Class Initialized
INFO - 2023-06-01 05:32:48 --> Language Class Initialized
INFO - 2023-06-01 05:32:48 --> Loader Class Initialized
INFO - 2023-06-01 05:32:48 --> Controller Class Initialized
DEBUG - 2023-06-01 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-01 05:32:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:32:48 --> Final output sent to browser
DEBUG - 2023-06-01 05:32:48 --> Total execution time: 0.2372
INFO - 2023-06-01 05:32:48 --> Config Class Initialized
INFO - 2023-06-01 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-01 05:32:48 --> URI Class Initialized
INFO - 2023-06-01 05:32:48 --> Router Class Initialized
INFO - 2023-06-01 05:32:48 --> Output Class Initialized
INFO - 2023-06-01 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-01 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:32:48 --> Input Class Initialized
INFO - 2023-06-01 05:32:48 --> Language Class Initialized
INFO - 2023-06-01 05:32:49 --> Loader Class Initialized
INFO - 2023-06-01 05:32:49 --> Controller Class Initialized
DEBUG - 2023-06-01 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-01 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:42:00 --> Config Class Initialized
INFO - 2023-06-01 05:42:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:42:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:42:00 --> Utf8 Class Initialized
INFO - 2023-06-01 05:42:00 --> URI Class Initialized
INFO - 2023-06-01 05:42:00 --> Router Class Initialized
INFO - 2023-06-01 05:42:00 --> Output Class Initialized
INFO - 2023-06-01 05:42:00 --> Security Class Initialized
DEBUG - 2023-06-01 05:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:42:00 --> Input Class Initialized
INFO - 2023-06-01 05:42:00 --> Language Class Initialized
INFO - 2023-06-01 05:42:00 --> Loader Class Initialized
INFO - 2023-06-01 05:42:00 --> Controller Class Initialized
DEBUG - 2023-06-01 05:42:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:42:00 --> Database Driver Class Initialized
INFO - 2023-06-01 05:42:00 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:42:00 --> Final output sent to browser
DEBUG - 2023-06-01 05:42:00 --> Total execution time: 0.2802
INFO - 2023-06-01 05:42:00 --> Config Class Initialized
INFO - 2023-06-01 05:42:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:42:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:42:00 --> Utf8 Class Initialized
INFO - 2023-06-01 05:42:00 --> URI Class Initialized
INFO - 2023-06-01 05:42:00 --> Router Class Initialized
INFO - 2023-06-01 05:42:00 --> Output Class Initialized
INFO - 2023-06-01 05:42:00 --> Security Class Initialized
DEBUG - 2023-06-01 05:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:42:00 --> Input Class Initialized
INFO - 2023-06-01 05:42:00 --> Language Class Initialized
INFO - 2023-06-01 05:42:00 --> Loader Class Initialized
INFO - 2023-06-01 05:42:00 --> Controller Class Initialized
DEBUG - 2023-06-01 05:42:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:42:00 --> Database Driver Class Initialized
INFO - 2023-06-01 05:42:00 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:43:52 --> Config Class Initialized
INFO - 2023-06-01 05:43:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:43:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:43:52 --> Utf8 Class Initialized
INFO - 2023-06-01 05:43:52 --> URI Class Initialized
INFO - 2023-06-01 05:43:52 --> Router Class Initialized
INFO - 2023-06-01 05:43:52 --> Output Class Initialized
INFO - 2023-06-01 05:43:52 --> Security Class Initialized
DEBUG - 2023-06-01 05:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:43:52 --> Input Class Initialized
INFO - 2023-06-01 05:43:52 --> Language Class Initialized
INFO - 2023-06-01 05:43:52 --> Loader Class Initialized
INFO - 2023-06-01 05:43:52 --> Controller Class Initialized
DEBUG - 2023-06-01 05:43:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:43:52 --> Database Driver Class Initialized
INFO - 2023-06-01 05:43:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:43:52 --> Final output sent to browser
DEBUG - 2023-06-01 05:43:52 --> Total execution time: 0.2264
INFO - 2023-06-01 05:43:52 --> Config Class Initialized
INFO - 2023-06-01 05:43:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:43:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:43:52 --> Utf8 Class Initialized
INFO - 2023-06-01 05:43:52 --> URI Class Initialized
INFO - 2023-06-01 05:43:52 --> Router Class Initialized
INFO - 2023-06-01 05:43:52 --> Output Class Initialized
INFO - 2023-06-01 05:43:52 --> Security Class Initialized
DEBUG - 2023-06-01 05:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:43:52 --> Input Class Initialized
INFO - 2023-06-01 05:43:52 --> Language Class Initialized
INFO - 2023-06-01 05:43:52 --> Loader Class Initialized
INFO - 2023-06-01 05:43:52 --> Controller Class Initialized
DEBUG - 2023-06-01 05:43:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:43:52 --> Database Driver Class Initialized
INFO - 2023-06-01 05:43:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:46:46 --> Config Class Initialized
INFO - 2023-06-01 05:46:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:46:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:46:46 --> Utf8 Class Initialized
INFO - 2023-06-01 05:46:46 --> URI Class Initialized
INFO - 2023-06-01 05:46:46 --> Router Class Initialized
INFO - 2023-06-01 05:46:46 --> Output Class Initialized
INFO - 2023-06-01 05:46:46 --> Security Class Initialized
DEBUG - 2023-06-01 05:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:46:46 --> Input Class Initialized
INFO - 2023-06-01 05:46:46 --> Language Class Initialized
ERROR - 2023-06-01 05:46:46 --> Severity: error --> Exception: syntax error, unexpected 'unset' (T_UNSET) /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php 4483
INFO - 2023-06-01 05:47:13 --> Config Class Initialized
INFO - 2023-06-01 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:47:13 --> Utf8 Class Initialized
INFO - 2023-06-01 05:47:13 --> URI Class Initialized
INFO - 2023-06-01 05:47:13 --> Router Class Initialized
INFO - 2023-06-01 05:47:13 --> Output Class Initialized
INFO - 2023-06-01 05:47:13 --> Security Class Initialized
DEBUG - 2023-06-01 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:47:13 --> Input Class Initialized
INFO - 2023-06-01 05:47:13 --> Language Class Initialized
INFO - 2023-06-01 05:47:13 --> Loader Class Initialized
INFO - 2023-06-01 05:47:13 --> Controller Class Initialized
DEBUG - 2023-06-01 05:47:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:47:13 --> Database Driver Class Initialized
INFO - 2023-06-01 05:47:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:47:13 --> Final output sent to browser
DEBUG - 2023-06-01 05:47:13 --> Total execution time: 0.2780
INFO - 2023-06-01 05:47:13 --> Config Class Initialized
INFO - 2023-06-01 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:47:13 --> Utf8 Class Initialized
INFO - 2023-06-01 05:47:13 --> URI Class Initialized
INFO - 2023-06-01 05:47:13 --> Router Class Initialized
INFO - 2023-06-01 05:47:14 --> Output Class Initialized
INFO - 2023-06-01 05:47:14 --> Security Class Initialized
DEBUG - 2023-06-01 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:47:14 --> Input Class Initialized
INFO - 2023-06-01 05:47:14 --> Language Class Initialized
INFO - 2023-06-01 05:47:14 --> Loader Class Initialized
INFO - 2023-06-01 05:47:14 --> Controller Class Initialized
DEBUG - 2023-06-01 05:47:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:47:14 --> Database Driver Class Initialized
INFO - 2023-06-01 05:47:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:47:37 --> Config Class Initialized
INFO - 2023-06-01 05:47:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:47:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:47:37 --> Utf8 Class Initialized
INFO - 2023-06-01 05:47:37 --> URI Class Initialized
INFO - 2023-06-01 05:47:37 --> Router Class Initialized
INFO - 2023-06-01 05:47:37 --> Output Class Initialized
INFO - 2023-06-01 05:47:37 --> Security Class Initialized
DEBUG - 2023-06-01 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:47:37 --> Input Class Initialized
INFO - 2023-06-01 05:47:37 --> Language Class Initialized
INFO - 2023-06-01 05:47:37 --> Loader Class Initialized
INFO - 2023-06-01 05:47:37 --> Controller Class Initialized
DEBUG - 2023-06-01 05:47:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:47:37 --> Database Driver Class Initialized
INFO - 2023-06-01 05:47:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:47:37 --> Final output sent to browser
DEBUG - 2023-06-01 05:47:37 --> Total execution time: 0.2601
INFO - 2023-06-01 05:47:37 --> Config Class Initialized
INFO - 2023-06-01 05:47:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:47:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:47:37 --> Utf8 Class Initialized
INFO - 2023-06-01 05:47:37 --> URI Class Initialized
INFO - 2023-06-01 05:47:37 --> Router Class Initialized
INFO - 2023-06-01 05:47:37 --> Output Class Initialized
INFO - 2023-06-01 05:47:37 --> Security Class Initialized
DEBUG - 2023-06-01 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:47:37 --> Input Class Initialized
INFO - 2023-06-01 05:47:37 --> Language Class Initialized
INFO - 2023-06-01 05:47:38 --> Loader Class Initialized
INFO - 2023-06-01 05:47:38 --> Controller Class Initialized
DEBUG - 2023-06-01 05:47:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:47:38 --> Database Driver Class Initialized
INFO - 2023-06-01 05:47:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:48:56 --> Config Class Initialized
INFO - 2023-06-01 05:48:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:48:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:48:56 --> Utf8 Class Initialized
INFO - 2023-06-01 05:48:56 --> URI Class Initialized
INFO - 2023-06-01 05:48:56 --> Router Class Initialized
INFO - 2023-06-01 05:48:56 --> Output Class Initialized
INFO - 2023-06-01 05:48:56 --> Security Class Initialized
DEBUG - 2023-06-01 05:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:48:56 --> Input Class Initialized
INFO - 2023-06-01 05:48:56 --> Language Class Initialized
INFO - 2023-06-01 05:48:56 --> Loader Class Initialized
INFO - 2023-06-01 05:48:56 --> Controller Class Initialized
DEBUG - 2023-06-01 05:48:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:48:56 --> Database Driver Class Initialized
INFO - 2023-06-01 05:48:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:48:56 --> Final output sent to browser
DEBUG - 2023-06-01 05:48:56 --> Total execution time: 0.1822
INFO - 2023-06-01 05:48:56 --> Config Class Initialized
INFO - 2023-06-01 05:48:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:48:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:48:56 --> Utf8 Class Initialized
INFO - 2023-06-01 05:48:56 --> URI Class Initialized
INFO - 2023-06-01 05:48:56 --> Router Class Initialized
INFO - 2023-06-01 05:48:56 --> Output Class Initialized
INFO - 2023-06-01 05:48:56 --> Security Class Initialized
DEBUG - 2023-06-01 05:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:48:56 --> Input Class Initialized
INFO - 2023-06-01 05:48:56 --> Language Class Initialized
INFO - 2023-06-01 05:48:56 --> Loader Class Initialized
INFO - 2023-06-01 05:48:56 --> Controller Class Initialized
DEBUG - 2023-06-01 05:48:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:48:56 --> Database Driver Class Initialized
INFO - 2023-06-01 05:48:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:54:55 --> Config Class Initialized
INFO - 2023-06-01 05:54:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:54:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:54:55 --> Utf8 Class Initialized
INFO - 2023-06-01 05:54:55 --> URI Class Initialized
INFO - 2023-06-01 05:54:55 --> Router Class Initialized
INFO - 2023-06-01 05:54:55 --> Output Class Initialized
INFO - 2023-06-01 05:54:55 --> Security Class Initialized
DEBUG - 2023-06-01 05:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:54:55 --> Input Class Initialized
INFO - 2023-06-01 05:54:55 --> Language Class Initialized
INFO - 2023-06-01 05:54:55 --> Loader Class Initialized
INFO - 2023-06-01 05:54:55 --> Controller Class Initialized
DEBUG - 2023-06-01 05:54:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:54:55 --> Database Driver Class Initialized
INFO - 2023-06-01 05:54:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:54:55 --> Final output sent to browser
DEBUG - 2023-06-01 05:54:55 --> Total execution time: 0.2135
INFO - 2023-06-01 05:54:56 --> Config Class Initialized
INFO - 2023-06-01 05:54:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:54:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:54:56 --> Utf8 Class Initialized
INFO - 2023-06-01 05:54:56 --> URI Class Initialized
INFO - 2023-06-01 05:54:56 --> Router Class Initialized
INFO - 2023-06-01 05:54:56 --> Output Class Initialized
INFO - 2023-06-01 05:54:56 --> Security Class Initialized
DEBUG - 2023-06-01 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:54:56 --> Input Class Initialized
INFO - 2023-06-01 05:54:56 --> Language Class Initialized
INFO - 2023-06-01 05:54:56 --> Loader Class Initialized
INFO - 2023-06-01 05:54:56 --> Controller Class Initialized
DEBUG - 2023-06-01 05:54:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:54:56 --> Database Driver Class Initialized
INFO - 2023-06-01 05:54:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:55:37 --> Config Class Initialized
INFO - 2023-06-01 05:55:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:55:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:55:37 --> Utf8 Class Initialized
INFO - 2023-06-01 05:55:37 --> URI Class Initialized
INFO - 2023-06-01 05:55:37 --> Router Class Initialized
INFO - 2023-06-01 05:55:37 --> Output Class Initialized
INFO - 2023-06-01 05:55:37 --> Security Class Initialized
DEBUG - 2023-06-01 05:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:55:37 --> Input Class Initialized
INFO - 2023-06-01 05:55:37 --> Language Class Initialized
INFO - 2023-06-01 05:55:37 --> Loader Class Initialized
INFO - 2023-06-01 05:55:37 --> Controller Class Initialized
DEBUG - 2023-06-01 05:55:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:55:37 --> Database Driver Class Initialized
INFO - 2023-06-01 05:55:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:55:37 --> Final output sent to browser
DEBUG - 2023-06-01 05:55:37 --> Total execution time: 0.2987
INFO - 2023-06-01 05:55:37 --> Config Class Initialized
INFO - 2023-06-01 05:55:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:55:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:55:37 --> Utf8 Class Initialized
INFO - 2023-06-01 05:55:37 --> URI Class Initialized
INFO - 2023-06-01 05:55:37 --> Router Class Initialized
INFO - 2023-06-01 05:55:37 --> Output Class Initialized
INFO - 2023-06-01 05:55:37 --> Security Class Initialized
DEBUG - 2023-06-01 05:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:55:37 --> Input Class Initialized
INFO - 2023-06-01 05:55:37 --> Language Class Initialized
INFO - 2023-06-01 05:55:37 --> Loader Class Initialized
INFO - 2023-06-01 05:55:37 --> Controller Class Initialized
DEBUG - 2023-06-01 05:55:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:55:37 --> Database Driver Class Initialized
INFO - 2023-06-01 05:55:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:56:11 --> Config Class Initialized
INFO - 2023-06-01 05:56:11 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:56:12 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:56:12 --> Utf8 Class Initialized
INFO - 2023-06-01 05:56:12 --> URI Class Initialized
INFO - 2023-06-01 05:56:12 --> Router Class Initialized
INFO - 2023-06-01 05:56:12 --> Output Class Initialized
INFO - 2023-06-01 05:56:12 --> Security Class Initialized
DEBUG - 2023-06-01 05:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:56:12 --> Input Class Initialized
INFO - 2023-06-01 05:56:12 --> Language Class Initialized
INFO - 2023-06-01 05:56:12 --> Loader Class Initialized
INFO - 2023-06-01 05:56:12 --> Controller Class Initialized
DEBUG - 2023-06-01 05:56:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:56:12 --> Database Driver Class Initialized
INFO - 2023-06-01 05:56:12 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:56:12 --> Final output sent to browser
DEBUG - 2023-06-01 05:56:12 --> Total execution time: 0.2879
INFO - 2023-06-01 05:56:12 --> Config Class Initialized
INFO - 2023-06-01 05:56:12 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:56:12 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:56:12 --> Utf8 Class Initialized
INFO - 2023-06-01 05:56:12 --> URI Class Initialized
INFO - 2023-06-01 05:56:12 --> Router Class Initialized
INFO - 2023-06-01 05:56:12 --> Output Class Initialized
INFO - 2023-06-01 05:56:12 --> Security Class Initialized
DEBUG - 2023-06-01 05:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:56:12 --> Input Class Initialized
INFO - 2023-06-01 05:56:12 --> Language Class Initialized
INFO - 2023-06-01 05:56:12 --> Loader Class Initialized
INFO - 2023-06-01 05:56:12 --> Controller Class Initialized
DEBUG - 2023-06-01 05:56:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:56:12 --> Database Driver Class Initialized
INFO - 2023-06-01 05:56:12 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:57:23 --> Config Class Initialized
INFO - 2023-06-01 05:57:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:57:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:57:23 --> Utf8 Class Initialized
INFO - 2023-06-01 05:57:23 --> URI Class Initialized
INFO - 2023-06-01 05:57:23 --> Router Class Initialized
INFO - 2023-06-01 05:57:23 --> Output Class Initialized
INFO - 2023-06-01 05:57:23 --> Security Class Initialized
DEBUG - 2023-06-01 05:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:57:23 --> Input Class Initialized
INFO - 2023-06-01 05:57:23 --> Language Class Initialized
INFO - 2023-06-01 05:57:23 --> Loader Class Initialized
INFO - 2023-06-01 05:57:23 --> Controller Class Initialized
DEBUG - 2023-06-01 05:57:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:57:23 --> Database Driver Class Initialized
INFO - 2023-06-01 05:57:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:57:23 --> Final output sent to browser
DEBUG - 2023-06-01 05:57:23 --> Total execution time: 0.3294
INFO - 2023-06-01 05:57:23 --> Config Class Initialized
INFO - 2023-06-01 05:57:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:57:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:57:23 --> Utf8 Class Initialized
INFO - 2023-06-01 05:57:23 --> URI Class Initialized
INFO - 2023-06-01 05:57:23 --> Router Class Initialized
INFO - 2023-06-01 05:57:23 --> Output Class Initialized
INFO - 2023-06-01 05:57:23 --> Security Class Initialized
DEBUG - 2023-06-01 05:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:57:23 --> Input Class Initialized
INFO - 2023-06-01 05:57:23 --> Language Class Initialized
INFO - 2023-06-01 05:57:23 --> Loader Class Initialized
INFO - 2023-06-01 05:57:23 --> Controller Class Initialized
DEBUG - 2023-06-01 05:57:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:57:23 --> Database Driver Class Initialized
INFO - 2023-06-01 05:57:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:58:04 --> Config Class Initialized
INFO - 2023-06-01 05:58:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:58:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:58:05 --> Utf8 Class Initialized
INFO - 2023-06-01 05:58:05 --> URI Class Initialized
INFO - 2023-06-01 05:58:05 --> Router Class Initialized
INFO - 2023-06-01 05:58:05 --> Output Class Initialized
INFO - 2023-06-01 05:58:05 --> Security Class Initialized
DEBUG - 2023-06-01 05:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:58:05 --> Input Class Initialized
INFO - 2023-06-01 05:58:05 --> Language Class Initialized
INFO - 2023-06-01 05:58:05 --> Loader Class Initialized
INFO - 2023-06-01 05:58:05 --> Controller Class Initialized
DEBUG - 2023-06-01 05:58:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:58:05 --> Database Driver Class Initialized
INFO - 2023-06-01 05:58:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:58:05 --> Final output sent to browser
DEBUG - 2023-06-01 05:58:05 --> Total execution time: 0.6293
INFO - 2023-06-01 05:58:05 --> Config Class Initialized
INFO - 2023-06-01 05:58:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:58:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:58:05 --> Utf8 Class Initialized
INFO - 2023-06-01 05:58:05 --> URI Class Initialized
INFO - 2023-06-01 05:58:05 --> Router Class Initialized
INFO - 2023-06-01 05:58:05 --> Output Class Initialized
INFO - 2023-06-01 05:58:05 --> Security Class Initialized
DEBUG - 2023-06-01 05:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:58:05 --> Input Class Initialized
INFO - 2023-06-01 05:58:05 --> Language Class Initialized
INFO - 2023-06-01 05:58:05 --> Loader Class Initialized
INFO - 2023-06-01 05:58:05 --> Controller Class Initialized
DEBUG - 2023-06-01 05:58:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:58:05 --> Database Driver Class Initialized
INFO - 2023-06-01 05:58:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:58:58 --> Config Class Initialized
INFO - 2023-06-01 05:58:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:58:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:58:58 --> Utf8 Class Initialized
INFO - 2023-06-01 05:58:58 --> URI Class Initialized
INFO - 2023-06-01 05:58:58 --> Router Class Initialized
INFO - 2023-06-01 05:58:58 --> Output Class Initialized
INFO - 2023-06-01 05:58:58 --> Security Class Initialized
DEBUG - 2023-06-01 05:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:58:58 --> Input Class Initialized
INFO - 2023-06-01 05:58:58 --> Language Class Initialized
INFO - 2023-06-01 05:58:58 --> Loader Class Initialized
INFO - 2023-06-01 05:58:58 --> Controller Class Initialized
DEBUG - 2023-06-01 05:58:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:58:58 --> Database Driver Class Initialized
INFO - 2023-06-01 05:58:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:58:58 --> Final output sent to browser
DEBUG - 2023-06-01 05:58:58 --> Total execution time: 0.2430
INFO - 2023-06-01 05:58:58 --> Config Class Initialized
INFO - 2023-06-01 05:58:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:58:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:58:59 --> Utf8 Class Initialized
INFO - 2023-06-01 05:58:59 --> URI Class Initialized
INFO - 2023-06-01 05:58:59 --> Router Class Initialized
INFO - 2023-06-01 05:58:59 --> Output Class Initialized
INFO - 2023-06-01 05:58:59 --> Security Class Initialized
DEBUG - 2023-06-01 05:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:58:59 --> Input Class Initialized
INFO - 2023-06-01 05:58:59 --> Language Class Initialized
INFO - 2023-06-01 05:58:59 --> Loader Class Initialized
INFO - 2023-06-01 05:58:59 --> Controller Class Initialized
DEBUG - 2023-06-01 05:58:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:58:59 --> Database Driver Class Initialized
INFO - 2023-06-01 05:58:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:58:59 --> Final output sent to browser
DEBUG - 2023-06-01 05:58:59 --> Total execution time: 0.2673
INFO - 2023-06-01 05:59:08 --> Config Class Initialized
INFO - 2023-06-01 05:59:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:08 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:08 --> URI Class Initialized
INFO - 2023-06-01 05:59:08 --> Router Class Initialized
INFO - 2023-06-01 05:59:08 --> Output Class Initialized
INFO - 2023-06-01 05:59:08 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:08 --> Input Class Initialized
INFO - 2023-06-01 05:59:08 --> Language Class Initialized
INFO - 2023-06-01 05:59:08 --> Loader Class Initialized
INFO - 2023-06-01 05:59:08 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:08 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:08 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:08 --> Total execution time: 0.1892
INFO - 2023-06-01 05:59:08 --> Config Class Initialized
INFO - 2023-06-01 05:59:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:08 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:08 --> URI Class Initialized
INFO - 2023-06-01 05:59:08 --> Router Class Initialized
INFO - 2023-06-01 05:59:08 --> Output Class Initialized
INFO - 2023-06-01 05:59:08 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:08 --> Input Class Initialized
INFO - 2023-06-01 05:59:08 --> Language Class Initialized
INFO - 2023-06-01 05:59:08 --> Loader Class Initialized
INFO - 2023-06-01 05:59:08 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:08 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:08 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:08 --> Total execution time: 0.2857
INFO - 2023-06-01 05:59:45 --> Config Class Initialized
INFO - 2023-06-01 05:59:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:45 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:45 --> URI Class Initialized
INFO - 2023-06-01 05:59:45 --> Router Class Initialized
INFO - 2023-06-01 05:59:45 --> Output Class Initialized
INFO - 2023-06-01 05:59:45 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:45 --> Input Class Initialized
INFO - 2023-06-01 05:59:45 --> Language Class Initialized
INFO - 2023-06-01 05:59:45 --> Loader Class Initialized
INFO - 2023-06-01 05:59:45 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:45 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:46 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:46 --> Total execution time: 0.5175
INFO - 2023-06-01 05:59:46 --> Config Class Initialized
INFO - 2023-06-01 05:59:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:46 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:46 --> URI Class Initialized
INFO - 2023-06-01 05:59:46 --> Router Class Initialized
INFO - 2023-06-01 05:59:46 --> Output Class Initialized
INFO - 2023-06-01 05:59:46 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:46 --> Input Class Initialized
INFO - 2023-06-01 05:59:46 --> Language Class Initialized
INFO - 2023-06-01 05:59:46 --> Loader Class Initialized
INFO - 2023-06-01 05:59:46 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:46 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:46 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:46 --> Total execution time: 0.3473
INFO - 2023-06-01 05:59:56 --> Config Class Initialized
INFO - 2023-06-01 05:59:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:56 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:56 --> URI Class Initialized
INFO - 2023-06-01 05:59:56 --> Router Class Initialized
INFO - 2023-06-01 05:59:56 --> Output Class Initialized
INFO - 2023-06-01 05:59:56 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:56 --> Input Class Initialized
INFO - 2023-06-01 05:59:56 --> Language Class Initialized
INFO - 2023-06-01 05:59:56 --> Loader Class Initialized
INFO - 2023-06-01 05:59:56 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:56 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:56 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:56 --> Total execution time: 0.4024
INFO - 2023-06-01 05:59:56 --> Config Class Initialized
INFO - 2023-06-01 05:59:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 05:59:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 05:59:56 --> Utf8 Class Initialized
INFO - 2023-06-01 05:59:56 --> URI Class Initialized
INFO - 2023-06-01 05:59:56 --> Router Class Initialized
INFO - 2023-06-01 05:59:56 --> Output Class Initialized
INFO - 2023-06-01 05:59:56 --> Security Class Initialized
DEBUG - 2023-06-01 05:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 05:59:56 --> Input Class Initialized
INFO - 2023-06-01 05:59:56 --> Language Class Initialized
INFO - 2023-06-01 05:59:56 --> Loader Class Initialized
INFO - 2023-06-01 05:59:56 --> Controller Class Initialized
DEBUG - 2023-06-01 05:59:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 05:59:56 --> Database Driver Class Initialized
INFO - 2023-06-01 05:59:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 05:59:56 --> Final output sent to browser
DEBUG - 2023-06-01 05:59:56 --> Total execution time: 0.2468
INFO - 2023-06-01 06:00:34 --> Config Class Initialized
INFO - 2023-06-01 06:00:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:34 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:34 --> URI Class Initialized
INFO - 2023-06-01 06:00:34 --> Router Class Initialized
INFO - 2023-06-01 06:00:34 --> Output Class Initialized
INFO - 2023-06-01 06:00:34 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:34 --> Input Class Initialized
INFO - 2023-06-01 06:00:34 --> Language Class Initialized
INFO - 2023-06-01 06:00:34 --> Loader Class Initialized
INFO - 2023-06-01 06:00:34 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:34 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:34 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:34 --> Total execution time: 0.5637
INFO - 2023-06-01 06:00:34 --> Config Class Initialized
INFO - 2023-06-01 06:00:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:34 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:34 --> URI Class Initialized
INFO - 2023-06-01 06:00:34 --> Router Class Initialized
INFO - 2023-06-01 06:00:34 --> Output Class Initialized
INFO - 2023-06-01 06:00:34 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:34 --> Input Class Initialized
INFO - 2023-06-01 06:00:34 --> Language Class Initialized
INFO - 2023-06-01 06:00:34 --> Loader Class Initialized
INFO - 2023-06-01 06:00:34 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:34 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:34 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:34 --> Total execution time: 0.2506
INFO - 2023-06-01 06:00:35 --> Config Class Initialized
INFO - 2023-06-01 06:00:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:35 --> URI Class Initialized
INFO - 2023-06-01 06:00:35 --> Router Class Initialized
INFO - 2023-06-01 06:00:35 --> Output Class Initialized
INFO - 2023-06-01 06:00:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:35 --> Input Class Initialized
INFO - 2023-06-01 06:00:35 --> Language Class Initialized
INFO - 2023-06-01 06:00:35 --> Loader Class Initialized
INFO - 2023-06-01 06:00:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:35 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:35 --> Total execution time: 0.2553
INFO - 2023-06-01 06:00:35 --> Config Class Initialized
INFO - 2023-06-01 06:00:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:35 --> URI Class Initialized
INFO - 2023-06-01 06:00:35 --> Router Class Initialized
INFO - 2023-06-01 06:00:35 --> Output Class Initialized
INFO - 2023-06-01 06:00:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:35 --> Input Class Initialized
INFO - 2023-06-01 06:00:35 --> Language Class Initialized
INFO - 2023-06-01 06:00:35 --> Loader Class Initialized
INFO - 2023-06-01 06:00:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:35 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:35 --> Total execution time: 0.2357
INFO - 2023-06-01 06:00:39 --> Config Class Initialized
INFO - 2023-06-01 06:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:39 --> URI Class Initialized
INFO - 2023-06-01 06:00:39 --> Router Class Initialized
INFO - 2023-06-01 06:00:39 --> Output Class Initialized
INFO - 2023-06-01 06:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:39 --> Input Class Initialized
INFO - 2023-06-01 06:00:39 --> Language Class Initialized
INFO - 2023-06-01 06:00:39 --> Loader Class Initialized
INFO - 2023-06-01 06:00:39 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:39 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:39 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:39 --> Total execution time: 0.1982
INFO - 2023-06-01 06:00:39 --> Config Class Initialized
INFO - 2023-06-01 06:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:39 --> URI Class Initialized
INFO - 2023-06-01 06:00:39 --> Router Class Initialized
INFO - 2023-06-01 06:00:39 --> Output Class Initialized
INFO - 2023-06-01 06:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:39 --> Input Class Initialized
INFO - 2023-06-01 06:00:39 --> Language Class Initialized
INFO - 2023-06-01 06:00:39 --> Loader Class Initialized
INFO - 2023-06-01 06:00:39 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:39 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:39 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:39 --> Total execution time: 0.1971
INFO - 2023-06-01 06:00:39 --> Config Class Initialized
INFO - 2023-06-01 06:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:39 --> URI Class Initialized
INFO - 2023-06-01 06:00:39 --> Router Class Initialized
INFO - 2023-06-01 06:00:39 --> Output Class Initialized
INFO - 2023-06-01 06:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:39 --> Input Class Initialized
INFO - 2023-06-01 06:00:39 --> Language Class Initialized
INFO - 2023-06-01 06:00:39 --> Loader Class Initialized
INFO - 2023-06-01 06:00:39 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:39 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:39 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:39 --> Total execution time: 0.1983
INFO - 2023-06-01 06:00:39 --> Config Class Initialized
INFO - 2023-06-01 06:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:39 --> URI Class Initialized
INFO - 2023-06-01 06:00:39 --> Router Class Initialized
INFO - 2023-06-01 06:00:39 --> Output Class Initialized
INFO - 2023-06-01 06:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:39 --> Input Class Initialized
INFO - 2023-06-01 06:00:39 --> Language Class Initialized
INFO - 2023-06-01 06:00:40 --> Loader Class Initialized
INFO - 2023-06-01 06:00:40 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:40 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:40 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:40 --> Total execution time: 0.2120
INFO - 2023-06-01 06:00:42 --> Config Class Initialized
INFO - 2023-06-01 06:00:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:42 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:43 --> URI Class Initialized
INFO - 2023-06-01 06:00:43 --> Router Class Initialized
INFO - 2023-06-01 06:00:43 --> Output Class Initialized
INFO - 2023-06-01 06:00:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:43 --> Input Class Initialized
INFO - 2023-06-01 06:00:43 --> Language Class Initialized
INFO - 2023-06-01 06:00:43 --> Loader Class Initialized
INFO - 2023-06-01 06:00:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:43 --> Total execution time: 0.4031
INFO - 2023-06-01 06:00:43 --> Config Class Initialized
INFO - 2023-06-01 06:00:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:43 --> URI Class Initialized
INFO - 2023-06-01 06:00:43 --> Router Class Initialized
INFO - 2023-06-01 06:00:43 --> Output Class Initialized
INFO - 2023-06-01 06:00:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:43 --> Input Class Initialized
INFO - 2023-06-01 06:00:43 --> Language Class Initialized
INFO - 2023-06-01 06:00:43 --> Loader Class Initialized
INFO - 2023-06-01 06:00:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:43 --> Total execution time: 0.1978
INFO - 2023-06-01 06:00:43 --> Config Class Initialized
INFO - 2023-06-01 06:00:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:43 --> URI Class Initialized
INFO - 2023-06-01 06:00:43 --> Router Class Initialized
INFO - 2023-06-01 06:00:43 --> Output Class Initialized
INFO - 2023-06-01 06:00:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:43 --> Input Class Initialized
INFO - 2023-06-01 06:00:43 --> Language Class Initialized
INFO - 2023-06-01 06:00:43 --> Loader Class Initialized
INFO - 2023-06-01 06:00:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:43 --> Total execution time: 0.2974
INFO - 2023-06-01 06:00:44 --> Config Class Initialized
INFO - 2023-06-01 06:00:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:44 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:44 --> URI Class Initialized
INFO - 2023-06-01 06:00:44 --> Router Class Initialized
INFO - 2023-06-01 06:00:44 --> Output Class Initialized
INFO - 2023-06-01 06:00:44 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:44 --> Input Class Initialized
INFO - 2023-06-01 06:00:44 --> Language Class Initialized
INFO - 2023-06-01 06:00:44 --> Loader Class Initialized
INFO - 2023-06-01 06:00:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:44 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:44 --> Total execution time: 0.3214
INFO - 2023-06-01 06:00:46 --> Config Class Initialized
INFO - 2023-06-01 06:00:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:46 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:46 --> URI Class Initialized
INFO - 2023-06-01 06:00:46 --> Router Class Initialized
INFO - 2023-06-01 06:00:46 --> Output Class Initialized
INFO - 2023-06-01 06:00:46 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:46 --> Input Class Initialized
INFO - 2023-06-01 06:00:46 --> Language Class Initialized
INFO - 2023-06-01 06:00:46 --> Loader Class Initialized
INFO - 2023-06-01 06:00:46 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:46 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:47 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:47 --> Total execution time: 0.2978
INFO - 2023-06-01 06:00:47 --> Config Class Initialized
INFO - 2023-06-01 06:00:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:47 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:47 --> URI Class Initialized
INFO - 2023-06-01 06:00:47 --> Router Class Initialized
INFO - 2023-06-01 06:00:47 --> Output Class Initialized
INFO - 2023-06-01 06:00:47 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:47 --> Input Class Initialized
INFO - 2023-06-01 06:00:47 --> Language Class Initialized
INFO - 2023-06-01 06:00:47 --> Loader Class Initialized
INFO - 2023-06-01 06:00:47 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:47 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:47 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:47 --> Total execution time: 0.2968
INFO - 2023-06-01 06:00:47 --> Config Class Initialized
INFO - 2023-06-01 06:00:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:47 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:47 --> URI Class Initialized
INFO - 2023-06-01 06:00:47 --> Router Class Initialized
INFO - 2023-06-01 06:00:47 --> Output Class Initialized
INFO - 2023-06-01 06:00:47 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:47 --> Input Class Initialized
INFO - 2023-06-01 06:00:47 --> Language Class Initialized
INFO - 2023-06-01 06:00:47 --> Loader Class Initialized
INFO - 2023-06-01 06:00:47 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:47 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:47 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:47 --> Total execution time: 0.2885
INFO - 2023-06-01 06:00:47 --> Config Class Initialized
INFO - 2023-06-01 06:00:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:00:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:00:47 --> Utf8 Class Initialized
INFO - 2023-06-01 06:00:47 --> URI Class Initialized
INFO - 2023-06-01 06:00:47 --> Router Class Initialized
INFO - 2023-06-01 06:00:47 --> Output Class Initialized
INFO - 2023-06-01 06:00:47 --> Security Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:00:47 --> Input Class Initialized
INFO - 2023-06-01 06:00:47 --> Language Class Initialized
INFO - 2023-06-01 06:00:47 --> Loader Class Initialized
INFO - 2023-06-01 06:00:47 --> Controller Class Initialized
DEBUG - 2023-06-01 06:00:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:00:47 --> Database Driver Class Initialized
INFO - 2023-06-01 06:00:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:00:48 --> Final output sent to browser
DEBUG - 2023-06-01 06:00:48 --> Total execution time: 0.3509
INFO - 2023-06-01 06:02:32 --> Config Class Initialized
INFO - 2023-06-01 06:02:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:32 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:32 --> URI Class Initialized
INFO - 2023-06-01 06:02:32 --> Router Class Initialized
INFO - 2023-06-01 06:02:32 --> Output Class Initialized
INFO - 2023-06-01 06:02:32 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:32 --> Input Class Initialized
INFO - 2023-06-01 06:02:32 --> Language Class Initialized
INFO - 2023-06-01 06:02:32 --> Loader Class Initialized
INFO - 2023-06-01 06:02:32 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:32 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:32 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:32 --> Total execution time: 0.2168
INFO - 2023-06-01 06:02:32 --> Config Class Initialized
INFO - 2023-06-01 06:02:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:33 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:33 --> URI Class Initialized
INFO - 2023-06-01 06:02:33 --> Router Class Initialized
INFO - 2023-06-01 06:02:33 --> Output Class Initialized
INFO - 2023-06-01 06:02:33 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:33 --> Input Class Initialized
INFO - 2023-06-01 06:02:33 --> Language Class Initialized
INFO - 2023-06-01 06:02:33 --> Loader Class Initialized
INFO - 2023-06-01 06:02:33 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:33 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:33 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:33 --> Total execution time: 0.2045
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
INFO - 2023-06-01 06:02:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:41 --> Final output sent to browser
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Total execution time: 0.1780
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:41 --> Total execution time: 0.2466
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
INFO - 2023-06-01 06:02:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:41 --> Total execution time: 0.2630
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
INFO - 2023-06-01 06:02:41 --> Config Class Initialized
INFO - 2023-06-01 06:02:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
DEBUG - 2023-06-01 06:02:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
INFO - 2023-06-01 06:02:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:41 --> URI Class Initialized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
INFO - 2023-06-01 06:02:41 --> Router Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> Output Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
INFO - 2023-06-01 06:02:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:41 --> Input Class Initialized
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
INFO - 2023-06-01 06:02:41 --> Language Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
INFO - 2023-06-01 06:02:41 --> Loader Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:42 --> Final output sent to browser
INFO - 2023-06-01 06:02:42 --> Final output sent to browser
INFO - 2023-06-01 06:02:42 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:42 --> Total execution time: 0.5614
DEBUG - 2023-06-01 06:02:42 --> Total execution time: 0.4751
DEBUG - 2023-06-01 06:02:42 --> Total execution time: 0.5050
INFO - 2023-06-01 06:02:42 --> Config Class Initialized
INFO - 2023-06-01 06:02:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:42 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:42 --> URI Class Initialized
INFO - 2023-06-01 06:02:42 --> Router Class Initialized
INFO - 2023-06-01 06:02:42 --> Output Class Initialized
INFO - 2023-06-01 06:02:42 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:42 --> Input Class Initialized
INFO - 2023-06-01 06:02:42 --> Language Class Initialized
INFO - 2023-06-01 06:02:42 --> Loader Class Initialized
INFO - 2023-06-01 06:02:42 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:42 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:42 --> Config Class Initialized
INFO - 2023-06-01 06:02:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:42 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:42 --> URI Class Initialized
INFO - 2023-06-01 06:02:42 --> Router Class Initialized
INFO - 2023-06-01 06:02:42 --> Output Class Initialized
INFO - 2023-06-01 06:02:42 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:42 --> Input Class Initialized
INFO - 2023-06-01 06:02:42 --> Language Class Initialized
INFO - 2023-06-01 06:02:42 --> Loader Class Initialized
INFO - 2023-06-01 06:02:42 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:42 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:43 --> Config Class Initialized
INFO - 2023-06-01 06:02:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:43 --> URI Class Initialized
INFO - 2023-06-01 06:02:43 --> Router Class Initialized
INFO - 2023-06-01 06:02:43 --> Output Class Initialized
INFO - 2023-06-01 06:02:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:44 --> Input Class Initialized
INFO - 2023-06-01 06:02:44 --> Language Class Initialized
INFO - 2023-06-01 06:02:44 --> Loader Class Initialized
INFO - 2023-06-01 06:02:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:44 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:44 --> Total execution time: 0.2067
INFO - 2023-06-01 06:02:44 --> Config Class Initialized
INFO - 2023-06-01 06:02:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:44 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:44 --> URI Class Initialized
INFO - 2023-06-01 06:02:44 --> Router Class Initialized
INFO - 2023-06-01 06:02:44 --> Output Class Initialized
INFO - 2023-06-01 06:02:44 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:44 --> Input Class Initialized
INFO - 2023-06-01 06:02:44 --> Language Class Initialized
INFO - 2023-06-01 06:02:44 --> Loader Class Initialized
INFO - 2023-06-01 06:02:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:44 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:44 --> Total execution time: 0.1972
INFO - 2023-06-01 06:02:53 --> Config Class Initialized
INFO - 2023-06-01 06:02:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:53 --> URI Class Initialized
INFO - 2023-06-01 06:02:53 --> Router Class Initialized
INFO - 2023-06-01 06:02:53 --> Output Class Initialized
INFO - 2023-06-01 06:02:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:53 --> Input Class Initialized
INFO - 2023-06-01 06:02:53 --> Language Class Initialized
INFO - 2023-06-01 06:02:53 --> Loader Class Initialized
INFO - 2023-06-01 06:02:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:53 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:53 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:53 --> Total execution time: 0.2422
INFO - 2023-06-01 06:02:53 --> Config Class Initialized
INFO - 2023-06-01 06:02:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:02:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:02:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:02:53 --> URI Class Initialized
INFO - 2023-06-01 06:02:53 --> Router Class Initialized
INFO - 2023-06-01 06:02:53 --> Output Class Initialized
INFO - 2023-06-01 06:02:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:02:53 --> Input Class Initialized
INFO - 2023-06-01 06:02:53 --> Language Class Initialized
INFO - 2023-06-01 06:02:53 --> Loader Class Initialized
INFO - 2023-06-01 06:02:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:02:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:02:53 --> Database Driver Class Initialized
INFO - 2023-06-01 06:02:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:02:53 --> Final output sent to browser
DEBUG - 2023-06-01 06:02:53 --> Total execution time: 0.2434
INFO - 2023-06-01 06:03:53 --> Config Class Initialized
INFO - 2023-06-01 06:03:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:03:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:03:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:03:53 --> URI Class Initialized
INFO - 2023-06-01 06:03:53 --> Router Class Initialized
INFO - 2023-06-01 06:03:53 --> Output Class Initialized
INFO - 2023-06-01 06:03:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:03:53 --> Input Class Initialized
INFO - 2023-06-01 06:03:53 --> Language Class Initialized
INFO - 2023-06-01 06:03:53 --> Loader Class Initialized
INFO - 2023-06-01 06:03:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:03:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:03:53 --> Database Driver Class Initialized
INFO - 2023-06-01 06:03:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:03:53 --> Final output sent to browser
DEBUG - 2023-06-01 06:03:53 --> Total execution time: 0.1686
INFO - 2023-06-01 06:03:53 --> Config Class Initialized
INFO - 2023-06-01 06:03:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:03:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:03:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:03:53 --> URI Class Initialized
INFO - 2023-06-01 06:03:53 --> Router Class Initialized
INFO - 2023-06-01 06:03:53 --> Output Class Initialized
INFO - 2023-06-01 06:03:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:03:53 --> Input Class Initialized
INFO - 2023-06-01 06:03:53 --> Language Class Initialized
INFO - 2023-06-01 06:03:53 --> Loader Class Initialized
INFO - 2023-06-01 06:03:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:03:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:03:53 --> Database Driver Class Initialized
INFO - 2023-06-01 06:03:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:03:53 --> Final output sent to browser
DEBUG - 2023-06-01 06:03:53 --> Total execution time: 0.2787
INFO - 2023-06-01 06:04:22 --> Config Class Initialized
INFO - 2023-06-01 06:04:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:04:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:04:22 --> Utf8 Class Initialized
INFO - 2023-06-01 06:04:22 --> URI Class Initialized
INFO - 2023-06-01 06:04:22 --> Router Class Initialized
INFO - 2023-06-01 06:04:22 --> Output Class Initialized
INFO - 2023-06-01 06:04:22 --> Security Class Initialized
DEBUG - 2023-06-01 06:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:04:22 --> Input Class Initialized
INFO - 2023-06-01 06:04:22 --> Language Class Initialized
INFO - 2023-06-01 06:04:22 --> Loader Class Initialized
INFO - 2023-06-01 06:04:22 --> Controller Class Initialized
DEBUG - 2023-06-01 06:04:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:04:22 --> Database Driver Class Initialized
INFO - 2023-06-01 06:04:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:04:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:04:23 --> Total execution time: 0.5825
INFO - 2023-06-01 06:04:23 --> Config Class Initialized
INFO - 2023-06-01 06:04:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:04:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:04:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:04:23 --> URI Class Initialized
INFO - 2023-06-01 06:04:23 --> Router Class Initialized
INFO - 2023-06-01 06:04:23 --> Output Class Initialized
INFO - 2023-06-01 06:04:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:04:23 --> Input Class Initialized
INFO - 2023-06-01 06:04:23 --> Language Class Initialized
INFO - 2023-06-01 06:04:23 --> Loader Class Initialized
INFO - 2023-06-01 06:04:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:04:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:04:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:04:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:04:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:04:23 --> Total execution time: 0.2321
INFO - 2023-06-01 06:05:23 --> Config Class Initialized
INFO - 2023-06-01 06:05:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:05:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:05:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:05:23 --> URI Class Initialized
INFO - 2023-06-01 06:05:23 --> Router Class Initialized
INFO - 2023-06-01 06:05:23 --> Output Class Initialized
INFO - 2023-06-01 06:05:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:05:23 --> Input Class Initialized
INFO - 2023-06-01 06:05:23 --> Language Class Initialized
INFO - 2023-06-01 06:05:23 --> Loader Class Initialized
INFO - 2023-06-01 06:05:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:05:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:05:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:05:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:05:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:05:23 --> Total execution time: 0.4211
INFO - 2023-06-01 06:05:23 --> Config Class Initialized
INFO - 2023-06-01 06:05:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:05:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:05:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:05:23 --> URI Class Initialized
INFO - 2023-06-01 06:05:23 --> Router Class Initialized
INFO - 2023-06-01 06:05:23 --> Output Class Initialized
INFO - 2023-06-01 06:05:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:05:23 --> Input Class Initialized
INFO - 2023-06-01 06:05:23 --> Language Class Initialized
INFO - 2023-06-01 06:05:23 --> Loader Class Initialized
INFO - 2023-06-01 06:05:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:05:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:05:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:05:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:05:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:05:23 --> Total execution time: 0.2291
INFO - 2023-06-01 06:05:23 --> Config Class Initialized
INFO - 2023-06-01 06:05:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:05:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:05:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:05:24 --> URI Class Initialized
INFO - 2023-06-01 06:05:24 --> Router Class Initialized
INFO - 2023-06-01 06:05:24 --> Output Class Initialized
INFO - 2023-06-01 06:05:24 --> Security Class Initialized
DEBUG - 2023-06-01 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:05:24 --> Input Class Initialized
INFO - 2023-06-01 06:05:24 --> Language Class Initialized
INFO - 2023-06-01 06:05:24 --> Loader Class Initialized
INFO - 2023-06-01 06:05:24 --> Controller Class Initialized
DEBUG - 2023-06-01 06:05:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:05:24 --> Database Driver Class Initialized
INFO - 2023-06-01 06:05:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:05:24 --> Final output sent to browser
DEBUG - 2023-06-01 06:05:24 --> Total execution time: 0.3045
INFO - 2023-06-01 06:05:24 --> Config Class Initialized
INFO - 2023-06-01 06:05:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:05:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:05:24 --> Utf8 Class Initialized
INFO - 2023-06-01 06:05:24 --> URI Class Initialized
INFO - 2023-06-01 06:05:24 --> Router Class Initialized
INFO - 2023-06-01 06:05:24 --> Output Class Initialized
INFO - 2023-06-01 06:05:24 --> Security Class Initialized
DEBUG - 2023-06-01 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:05:24 --> Input Class Initialized
INFO - 2023-06-01 06:05:24 --> Language Class Initialized
INFO - 2023-06-01 06:05:24 --> Loader Class Initialized
INFO - 2023-06-01 06:05:24 --> Controller Class Initialized
DEBUG - 2023-06-01 06:05:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:05:24 --> Database Driver Class Initialized
INFO - 2023-06-01 06:05:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:05:24 --> Final output sent to browser
DEBUG - 2023-06-01 06:05:24 --> Total execution time: 0.2200
INFO - 2023-06-01 06:06:02 --> Config Class Initialized
INFO - 2023-06-01 06:06:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:02 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:02 --> URI Class Initialized
INFO - 2023-06-01 06:06:02 --> Router Class Initialized
INFO - 2023-06-01 06:06:02 --> Output Class Initialized
INFO - 2023-06-01 06:06:02 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:02 --> Input Class Initialized
INFO - 2023-06-01 06:06:02 --> Language Class Initialized
INFO - 2023-06-01 06:06:02 --> Loader Class Initialized
INFO - 2023-06-01 06:06:02 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:02 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:02 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:02 --> Total execution time: 0.3205
INFO - 2023-06-01 06:06:02 --> Config Class Initialized
INFO - 2023-06-01 06:06:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:02 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:02 --> URI Class Initialized
INFO - 2023-06-01 06:06:02 --> Router Class Initialized
INFO - 2023-06-01 06:06:02 --> Output Class Initialized
INFO - 2023-06-01 06:06:02 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:02 --> Input Class Initialized
INFO - 2023-06-01 06:06:02 --> Language Class Initialized
INFO - 2023-06-01 06:06:02 --> Loader Class Initialized
INFO - 2023-06-01 06:06:02 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:03 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:03 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:03 --> Total execution time: 0.2480
INFO - 2023-06-01 06:06:29 --> Config Class Initialized
INFO - 2023-06-01 06:06:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:29 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:29 --> URI Class Initialized
INFO - 2023-06-01 06:06:29 --> Router Class Initialized
INFO - 2023-06-01 06:06:29 --> Output Class Initialized
INFO - 2023-06-01 06:06:29 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:29 --> Input Class Initialized
INFO - 2023-06-01 06:06:29 --> Language Class Initialized
INFO - 2023-06-01 06:06:29 --> Loader Class Initialized
INFO - 2023-06-01 06:06:29 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:29 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:29 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:29 --> Total execution time: 0.4152
INFO - 2023-06-01 06:06:29 --> Config Class Initialized
INFO - 2023-06-01 06:06:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:29 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:29 --> URI Class Initialized
INFO - 2023-06-01 06:06:29 --> Router Class Initialized
INFO - 2023-06-01 06:06:29 --> Output Class Initialized
INFO - 2023-06-01 06:06:29 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:29 --> Input Class Initialized
INFO - 2023-06-01 06:06:29 --> Language Class Initialized
INFO - 2023-06-01 06:06:29 --> Loader Class Initialized
INFO - 2023-06-01 06:06:29 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:30 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:30 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:30 --> Total execution time: 0.3612
INFO - 2023-06-01 06:06:35 --> Config Class Initialized
INFO - 2023-06-01 06:06:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:35 --> URI Class Initialized
INFO - 2023-06-01 06:06:35 --> Router Class Initialized
INFO - 2023-06-01 06:06:35 --> Output Class Initialized
INFO - 2023-06-01 06:06:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:35 --> Input Class Initialized
INFO - 2023-06-01 06:06:35 --> Language Class Initialized
INFO - 2023-06-01 06:06:35 --> Loader Class Initialized
INFO - 2023-06-01 06:06:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:35 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:35 --> Total execution time: 0.2010
INFO - 2023-06-01 06:06:35 --> Config Class Initialized
INFO - 2023-06-01 06:06:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:35 --> URI Class Initialized
INFO - 2023-06-01 06:06:35 --> Router Class Initialized
INFO - 2023-06-01 06:06:35 --> Output Class Initialized
INFO - 2023-06-01 06:06:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:35 --> Input Class Initialized
INFO - 2023-06-01 06:06:35 --> Language Class Initialized
INFO - 2023-06-01 06:06:35 --> Loader Class Initialized
INFO - 2023-06-01 06:06:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:35 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:35 --> Total execution time: 0.2062
INFO - 2023-06-01 06:06:35 --> Config Class Initialized
INFO - 2023-06-01 06:06:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:36 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:36 --> URI Class Initialized
INFO - 2023-06-01 06:06:36 --> Router Class Initialized
INFO - 2023-06-01 06:06:36 --> Output Class Initialized
INFO - 2023-06-01 06:06:36 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:36 --> Input Class Initialized
INFO - 2023-06-01 06:06:36 --> Language Class Initialized
INFO - 2023-06-01 06:06:36 --> Loader Class Initialized
INFO - 2023-06-01 06:06:36 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:36 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:36 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:36 --> Total execution time: 0.2041
INFO - 2023-06-01 06:06:36 --> Config Class Initialized
INFO - 2023-06-01 06:06:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:36 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:36 --> URI Class Initialized
INFO - 2023-06-01 06:06:36 --> Router Class Initialized
INFO - 2023-06-01 06:06:36 --> Output Class Initialized
INFO - 2023-06-01 06:06:36 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:36 --> Input Class Initialized
INFO - 2023-06-01 06:06:36 --> Language Class Initialized
INFO - 2023-06-01 06:06:36 --> Loader Class Initialized
INFO - 2023-06-01 06:06:36 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:36 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:36 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:36 --> Total execution time: 0.2163
INFO - 2023-06-01 06:06:38 --> Config Class Initialized
INFO - 2023-06-01 06:06:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:38 --> URI Class Initialized
INFO - 2023-06-01 06:06:38 --> Router Class Initialized
INFO - 2023-06-01 06:06:38 --> Output Class Initialized
INFO - 2023-06-01 06:06:38 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:38 --> Input Class Initialized
INFO - 2023-06-01 06:06:38 --> Language Class Initialized
INFO - 2023-06-01 06:06:38 --> Loader Class Initialized
INFO - 2023-06-01 06:06:38 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:38 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:38 --> Total execution time: 0.1731
INFO - 2023-06-01 06:06:38 --> Config Class Initialized
INFO - 2023-06-01 06:06:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:38 --> URI Class Initialized
INFO - 2023-06-01 06:06:38 --> Router Class Initialized
INFO - 2023-06-01 06:06:38 --> Output Class Initialized
INFO - 2023-06-01 06:06:38 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:38 --> Input Class Initialized
INFO - 2023-06-01 06:06:38 --> Language Class Initialized
INFO - 2023-06-01 06:06:38 --> Loader Class Initialized
INFO - 2023-06-01 06:06:38 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:38 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:38 --> Total execution time: 0.2369
INFO - 2023-06-01 06:06:38 --> Config Class Initialized
INFO - 2023-06-01 06:06:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:38 --> URI Class Initialized
INFO - 2023-06-01 06:06:38 --> Router Class Initialized
INFO - 2023-06-01 06:06:38 --> Output Class Initialized
INFO - 2023-06-01 06:06:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:39 --> Input Class Initialized
INFO - 2023-06-01 06:06:39 --> Language Class Initialized
INFO - 2023-06-01 06:06:39 --> Loader Class Initialized
INFO - 2023-06-01 06:06:39 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:39 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:39 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:39 --> Total execution time: 0.2305
INFO - 2023-06-01 06:06:39 --> Config Class Initialized
INFO - 2023-06-01 06:06:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:39 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:39 --> URI Class Initialized
INFO - 2023-06-01 06:06:39 --> Router Class Initialized
INFO - 2023-06-01 06:06:39 --> Output Class Initialized
INFO - 2023-06-01 06:06:39 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:39 --> Input Class Initialized
INFO - 2023-06-01 06:06:39 --> Language Class Initialized
INFO - 2023-06-01 06:06:39 --> Loader Class Initialized
INFO - 2023-06-01 06:06:39 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:39 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:39 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:39 --> Total execution time: 0.4103
INFO - 2023-06-01 06:06:41 --> Config Class Initialized
INFO - 2023-06-01 06:06:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:41 --> URI Class Initialized
INFO - 2023-06-01 06:06:41 --> Router Class Initialized
INFO - 2023-06-01 06:06:41 --> Output Class Initialized
INFO - 2023-06-01 06:06:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:41 --> Input Class Initialized
INFO - 2023-06-01 06:06:41 --> Language Class Initialized
INFO - 2023-06-01 06:06:41 --> Loader Class Initialized
INFO - 2023-06-01 06:06:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:41 --> Total execution time: 0.1977
INFO - 2023-06-01 06:06:41 --> Config Class Initialized
INFO - 2023-06-01 06:06:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:41 --> URI Class Initialized
INFO - 2023-06-01 06:06:41 --> Router Class Initialized
INFO - 2023-06-01 06:06:41 --> Output Class Initialized
INFO - 2023-06-01 06:06:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:41 --> Input Class Initialized
INFO - 2023-06-01 06:06:42 --> Language Class Initialized
INFO - 2023-06-01 06:06:42 --> Loader Class Initialized
INFO - 2023-06-01 06:06:42 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:42 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:42 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:42 --> Total execution time: 0.2156
INFO - 2023-06-01 06:06:42 --> Config Class Initialized
INFO - 2023-06-01 06:06:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:42 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:42 --> URI Class Initialized
INFO - 2023-06-01 06:06:42 --> Router Class Initialized
INFO - 2023-06-01 06:06:42 --> Output Class Initialized
INFO - 2023-06-01 06:06:42 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:42 --> Input Class Initialized
INFO - 2023-06-01 06:06:42 --> Language Class Initialized
INFO - 2023-06-01 06:06:42 --> Loader Class Initialized
INFO - 2023-06-01 06:06:42 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:42 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:42 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:42 --> Total execution time: 0.2030
INFO - 2023-06-01 06:06:42 --> Config Class Initialized
INFO - 2023-06-01 06:06:42 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:06:42 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:06:42 --> Utf8 Class Initialized
INFO - 2023-06-01 06:06:42 --> URI Class Initialized
INFO - 2023-06-01 06:06:42 --> Router Class Initialized
INFO - 2023-06-01 06:06:42 --> Output Class Initialized
INFO - 2023-06-01 06:06:42 --> Security Class Initialized
DEBUG - 2023-06-01 06:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:06:42 --> Input Class Initialized
INFO - 2023-06-01 06:06:42 --> Language Class Initialized
INFO - 2023-06-01 06:06:42 --> Loader Class Initialized
INFO - 2023-06-01 06:06:42 --> Controller Class Initialized
DEBUG - 2023-06-01 06:06:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:06:42 --> Database Driver Class Initialized
INFO - 2023-06-01 06:06:42 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:06:42 --> Final output sent to browser
DEBUG - 2023-06-01 06:06:42 --> Total execution time: 0.2453
INFO - 2023-06-01 06:27:43 --> Config Class Initialized
INFO - 2023-06-01 06:27:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:27:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:27:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:27:43 --> URI Class Initialized
INFO - 2023-06-01 06:27:43 --> Router Class Initialized
INFO - 2023-06-01 06:27:43 --> Output Class Initialized
INFO - 2023-06-01 06:27:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:27:43 --> Input Class Initialized
INFO - 2023-06-01 06:27:43 --> Language Class Initialized
INFO - 2023-06-01 06:27:43 --> Loader Class Initialized
INFO - 2023-06-01 06:27:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:27:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:27:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:27:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:27:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:27:43 --> Total execution time: 0.3433
INFO - 2023-06-01 06:27:43 --> Config Class Initialized
INFO - 2023-06-01 06:27:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:27:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:27:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:27:43 --> URI Class Initialized
INFO - 2023-06-01 06:27:43 --> Router Class Initialized
INFO - 2023-06-01 06:27:43 --> Output Class Initialized
INFO - 2023-06-01 06:27:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:27:43 --> Input Class Initialized
INFO - 2023-06-01 06:27:43 --> Language Class Initialized
INFO - 2023-06-01 06:27:43 --> Loader Class Initialized
INFO - 2023-06-01 06:27:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:27:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:27:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:27:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:27:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:27:43 --> Total execution time: 0.4979
INFO - 2023-06-01 06:30:04 --> Config Class Initialized
INFO - 2023-06-01 06:30:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:30:04 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:30:04 --> Utf8 Class Initialized
INFO - 2023-06-01 06:30:04 --> URI Class Initialized
INFO - 2023-06-01 06:30:04 --> Router Class Initialized
INFO - 2023-06-01 06:30:04 --> Output Class Initialized
INFO - 2023-06-01 06:30:04 --> Security Class Initialized
DEBUG - 2023-06-01 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:30:04 --> Input Class Initialized
INFO - 2023-06-01 06:30:05 --> Language Class Initialized
INFO - 2023-06-01 06:30:05 --> Loader Class Initialized
INFO - 2023-06-01 06:30:05 --> Controller Class Initialized
DEBUG - 2023-06-01 06:30:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:30:05 --> Database Driver Class Initialized
INFO - 2023-06-01 06:30:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:30:05 --> Final output sent to browser
DEBUG - 2023-06-01 06:30:05 --> Total execution time: 0.1997
INFO - 2023-06-01 06:30:05 --> Config Class Initialized
INFO - 2023-06-01 06:30:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:30:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:30:05 --> Utf8 Class Initialized
INFO - 2023-06-01 06:30:05 --> URI Class Initialized
INFO - 2023-06-01 06:30:05 --> Router Class Initialized
INFO - 2023-06-01 06:30:05 --> Output Class Initialized
INFO - 2023-06-01 06:30:05 --> Security Class Initialized
DEBUG - 2023-06-01 06:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:30:05 --> Input Class Initialized
INFO - 2023-06-01 06:30:05 --> Language Class Initialized
INFO - 2023-06-01 06:30:05 --> Loader Class Initialized
INFO - 2023-06-01 06:30:05 --> Controller Class Initialized
DEBUG - 2023-06-01 06:30:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:30:05 --> Database Driver Class Initialized
INFO - 2023-06-01 06:30:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:30:05 --> Final output sent to browser
DEBUG - 2023-06-01 06:30:05 --> Total execution time: 0.3091
INFO - 2023-06-01 06:30:55 --> Config Class Initialized
INFO - 2023-06-01 06:30:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:30:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:30:55 --> Utf8 Class Initialized
INFO - 2023-06-01 06:30:55 --> URI Class Initialized
INFO - 2023-06-01 06:30:55 --> Router Class Initialized
INFO - 2023-06-01 06:30:55 --> Output Class Initialized
INFO - 2023-06-01 06:30:55 --> Security Class Initialized
DEBUG - 2023-06-01 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:30:55 --> Input Class Initialized
INFO - 2023-06-01 06:30:55 --> Language Class Initialized
INFO - 2023-06-01 06:30:55 --> Loader Class Initialized
INFO - 2023-06-01 06:30:55 --> Controller Class Initialized
DEBUG - 2023-06-01 06:30:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:30:55 --> Database Driver Class Initialized
INFO - 2023-06-01 06:30:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:30:55 --> Final output sent to browser
DEBUG - 2023-06-01 06:30:55 --> Total execution time: 0.3739
INFO - 2023-06-01 06:30:55 --> Config Class Initialized
INFO - 2023-06-01 06:30:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:30:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:30:55 --> Utf8 Class Initialized
INFO - 2023-06-01 06:30:55 --> URI Class Initialized
INFO - 2023-06-01 06:30:55 --> Router Class Initialized
INFO - 2023-06-01 06:30:55 --> Output Class Initialized
INFO - 2023-06-01 06:30:55 --> Security Class Initialized
DEBUG - 2023-06-01 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:30:55 --> Input Class Initialized
INFO - 2023-06-01 06:30:55 --> Language Class Initialized
INFO - 2023-06-01 06:30:55 --> Loader Class Initialized
INFO - 2023-06-01 06:30:55 --> Controller Class Initialized
DEBUG - 2023-06-01 06:30:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:30:55 --> Database Driver Class Initialized
INFO - 2023-06-01 06:30:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:30:55 --> Final output sent to browser
DEBUG - 2023-06-01 06:30:55 --> Total execution time: 0.3664
INFO - 2023-06-01 06:31:31 --> Config Class Initialized
INFO - 2023-06-01 06:31:31 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:31:31 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:31:31 --> Utf8 Class Initialized
INFO - 2023-06-01 06:31:31 --> URI Class Initialized
INFO - 2023-06-01 06:31:31 --> Router Class Initialized
INFO - 2023-06-01 06:31:31 --> Output Class Initialized
INFO - 2023-06-01 06:31:31 --> Security Class Initialized
DEBUG - 2023-06-01 06:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:31:31 --> Input Class Initialized
INFO - 2023-06-01 06:31:31 --> Language Class Initialized
INFO - 2023-06-01 06:31:31 --> Loader Class Initialized
INFO - 2023-06-01 06:31:31 --> Controller Class Initialized
DEBUG - 2023-06-01 06:31:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:31:31 --> Database Driver Class Initialized
INFO - 2023-06-01 06:31:31 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:31:31 --> Final output sent to browser
DEBUG - 2023-06-01 06:31:31 --> Total execution time: 0.3250
INFO - 2023-06-01 06:31:31 --> Config Class Initialized
INFO - 2023-06-01 06:31:31 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:31:31 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:31:31 --> Utf8 Class Initialized
INFO - 2023-06-01 06:31:31 --> URI Class Initialized
INFO - 2023-06-01 06:31:31 --> Router Class Initialized
INFO - 2023-06-01 06:31:31 --> Output Class Initialized
INFO - 2023-06-01 06:31:31 --> Security Class Initialized
DEBUG - 2023-06-01 06:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:31:31 --> Input Class Initialized
INFO - 2023-06-01 06:31:31 --> Language Class Initialized
INFO - 2023-06-01 06:31:31 --> Loader Class Initialized
INFO - 2023-06-01 06:31:31 --> Controller Class Initialized
DEBUG - 2023-06-01 06:31:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:31:31 --> Database Driver Class Initialized
INFO - 2023-06-01 06:31:31 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:31:31 --> Final output sent to browser
DEBUG - 2023-06-01 06:31:31 --> Total execution time: 0.2941
INFO - 2023-06-01 06:31:45 --> Config Class Initialized
INFO - 2023-06-01 06:31:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:31:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:31:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:31:45 --> URI Class Initialized
INFO - 2023-06-01 06:31:45 --> Router Class Initialized
INFO - 2023-06-01 06:31:45 --> Output Class Initialized
INFO - 2023-06-01 06:31:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:31:45 --> Input Class Initialized
INFO - 2023-06-01 06:31:45 --> Language Class Initialized
INFO - 2023-06-01 06:31:45 --> Loader Class Initialized
INFO - 2023-06-01 06:31:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:31:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:31:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:31:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:31:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:31:45 --> Total execution time: 0.2069
INFO - 2023-06-01 06:31:45 --> Config Class Initialized
INFO - 2023-06-01 06:31:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:31:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:31:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:31:45 --> URI Class Initialized
INFO - 2023-06-01 06:31:45 --> Router Class Initialized
INFO - 2023-06-01 06:31:45 --> Output Class Initialized
INFO - 2023-06-01 06:31:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:31:45 --> Input Class Initialized
INFO - 2023-06-01 06:31:45 --> Language Class Initialized
INFO - 2023-06-01 06:31:45 --> Loader Class Initialized
INFO - 2023-06-01 06:31:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:31:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:31:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:31:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:31:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:31:45 --> Total execution time: 0.1791
INFO - 2023-06-01 06:32:31 --> Config Class Initialized
INFO - 2023-06-01 06:32:31 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:31 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:31 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:31 --> URI Class Initialized
INFO - 2023-06-01 06:32:31 --> Router Class Initialized
INFO - 2023-06-01 06:32:31 --> Output Class Initialized
INFO - 2023-06-01 06:32:31 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:31 --> Input Class Initialized
INFO - 2023-06-01 06:32:31 --> Language Class Initialized
INFO - 2023-06-01 06:32:31 --> Loader Class Initialized
INFO - 2023-06-01 06:32:31 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:31 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:31 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:31 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:31 --> Total execution time: 0.2330
INFO - 2023-06-01 06:32:32 --> Config Class Initialized
INFO - 2023-06-01 06:32:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:32 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:32 --> URI Class Initialized
INFO - 2023-06-01 06:32:32 --> Router Class Initialized
INFO - 2023-06-01 06:32:32 --> Output Class Initialized
INFO - 2023-06-01 06:32:32 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:32 --> Input Class Initialized
INFO - 2023-06-01 06:32:32 --> Language Class Initialized
INFO - 2023-06-01 06:32:32 --> Loader Class Initialized
INFO - 2023-06-01 06:32:32 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:32 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:32 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:32 --> Total execution time: 0.3347
INFO - 2023-06-01 06:32:53 --> Config Class Initialized
INFO - 2023-06-01 06:32:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:53 --> URI Class Initialized
INFO - 2023-06-01 06:32:53 --> Router Class Initialized
INFO - 2023-06-01 06:32:53 --> Output Class Initialized
INFO - 2023-06-01 06:32:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:53 --> Input Class Initialized
INFO - 2023-06-01 06:32:53 --> Language Class Initialized
INFO - 2023-06-01 06:32:53 --> Loader Class Initialized
INFO - 2023-06-01 06:32:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:53 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:53 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:53 --> Total execution time: 0.2124
INFO - 2023-06-01 06:32:53 --> Config Class Initialized
INFO - 2023-06-01 06:32:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:53 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:53 --> URI Class Initialized
INFO - 2023-06-01 06:32:53 --> Router Class Initialized
INFO - 2023-06-01 06:32:53 --> Output Class Initialized
INFO - 2023-06-01 06:32:53 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:53 --> Input Class Initialized
INFO - 2023-06-01 06:32:53 --> Language Class Initialized
INFO - 2023-06-01 06:32:53 --> Loader Class Initialized
INFO - 2023-06-01 06:32:53 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:54 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:56 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:56 --> Total execution time: 2.3291
INFO - 2023-06-01 06:32:56 --> Config Class Initialized
INFO - 2023-06-01 06:32:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:56 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:56 --> URI Class Initialized
INFO - 2023-06-01 06:32:56 --> Router Class Initialized
INFO - 2023-06-01 06:32:56 --> Output Class Initialized
INFO - 2023-06-01 06:32:56 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:56 --> Input Class Initialized
INFO - 2023-06-01 06:32:56 --> Language Class Initialized
INFO - 2023-06-01 06:32:56 --> Loader Class Initialized
INFO - 2023-06-01 06:32:56 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:56 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:56 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:56 --> Total execution time: 0.1711
INFO - 2023-06-01 06:32:56 --> Config Class Initialized
INFO - 2023-06-01 06:32:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:32:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:32:56 --> Utf8 Class Initialized
INFO - 2023-06-01 06:32:56 --> URI Class Initialized
INFO - 2023-06-01 06:32:56 --> Router Class Initialized
INFO - 2023-06-01 06:32:56 --> Output Class Initialized
INFO - 2023-06-01 06:32:56 --> Security Class Initialized
DEBUG - 2023-06-01 06:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:32:56 --> Input Class Initialized
INFO - 2023-06-01 06:32:56 --> Language Class Initialized
INFO - 2023-06-01 06:32:56 --> Loader Class Initialized
INFO - 2023-06-01 06:32:56 --> Controller Class Initialized
DEBUG - 2023-06-01 06:32:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:32:56 --> Database Driver Class Initialized
INFO - 2023-06-01 06:32:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:32:56 --> Final output sent to browser
DEBUG - 2023-06-01 06:32:56 --> Total execution time: 0.4066
INFO - 2023-06-01 06:34:02 --> Config Class Initialized
INFO - 2023-06-01 06:34:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:02 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:02 --> URI Class Initialized
INFO - 2023-06-01 06:34:02 --> Router Class Initialized
INFO - 2023-06-01 06:34:02 --> Output Class Initialized
INFO - 2023-06-01 06:34:02 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:02 --> Input Class Initialized
INFO - 2023-06-01 06:34:02 --> Language Class Initialized
INFO - 2023-06-01 06:34:02 --> Loader Class Initialized
INFO - 2023-06-01 06:34:02 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:02 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:03 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:03 --> Total execution time: 0.3470
INFO - 2023-06-01 06:34:03 --> Config Class Initialized
INFO - 2023-06-01 06:34:03 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:03 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:03 --> URI Class Initialized
INFO - 2023-06-01 06:34:03 --> Router Class Initialized
INFO - 2023-06-01 06:34:03 --> Output Class Initialized
INFO - 2023-06-01 06:34:03 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:03 --> Input Class Initialized
INFO - 2023-06-01 06:34:03 --> Language Class Initialized
INFO - 2023-06-01 06:34:03 --> Loader Class Initialized
INFO - 2023-06-01 06:34:03 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:03 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:03 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:03 --> Total execution time: 0.4770
INFO - 2023-06-01 06:34:20 --> Config Class Initialized
INFO - 2023-06-01 06:34:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:20 --> URI Class Initialized
INFO - 2023-06-01 06:34:20 --> Router Class Initialized
INFO - 2023-06-01 06:34:20 --> Output Class Initialized
INFO - 2023-06-01 06:34:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:20 --> Input Class Initialized
INFO - 2023-06-01 06:34:20 --> Language Class Initialized
INFO - 2023-06-01 06:34:20 --> Loader Class Initialized
INFO - 2023-06-01 06:34:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:20 --> Total execution time: 0.1692
INFO - 2023-06-01 06:34:20 --> Config Class Initialized
INFO - 2023-06-01 06:34:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:20 --> URI Class Initialized
INFO - 2023-06-01 06:34:20 --> Router Class Initialized
INFO - 2023-06-01 06:34:20 --> Output Class Initialized
INFO - 2023-06-01 06:34:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:20 --> Input Class Initialized
INFO - 2023-06-01 06:34:20 --> Language Class Initialized
INFO - 2023-06-01 06:34:20 --> Loader Class Initialized
INFO - 2023-06-01 06:34:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:20 --> Total execution time: 0.1836
INFO - 2023-06-01 06:34:20 --> Config Class Initialized
INFO - 2023-06-01 06:34:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:20 --> URI Class Initialized
INFO - 2023-06-01 06:34:20 --> Router Class Initialized
INFO - 2023-06-01 06:34:20 --> Output Class Initialized
INFO - 2023-06-01 06:34:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:20 --> Input Class Initialized
INFO - 2023-06-01 06:34:20 --> Language Class Initialized
INFO - 2023-06-01 06:34:20 --> Loader Class Initialized
INFO - 2023-06-01 06:34:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:20 --> Total execution time: 0.1619
INFO - 2023-06-01 06:34:20 --> Config Class Initialized
INFO - 2023-06-01 06:34:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:34:21 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:34:21 --> Utf8 Class Initialized
INFO - 2023-06-01 06:34:21 --> URI Class Initialized
INFO - 2023-06-01 06:34:21 --> Router Class Initialized
INFO - 2023-06-01 06:34:21 --> Output Class Initialized
INFO - 2023-06-01 06:34:21 --> Security Class Initialized
DEBUG - 2023-06-01 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:34:21 --> Input Class Initialized
INFO - 2023-06-01 06:34:21 --> Language Class Initialized
INFO - 2023-06-01 06:34:21 --> Loader Class Initialized
INFO - 2023-06-01 06:34:21 --> Controller Class Initialized
DEBUG - 2023-06-01 06:34:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:34:21 --> Database Driver Class Initialized
INFO - 2023-06-01 06:34:21 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:34:21 --> Final output sent to browser
DEBUG - 2023-06-01 06:34:21 --> Total execution time: 0.1855
INFO - 2023-06-01 06:35:58 --> Config Class Initialized
INFO - 2023-06-01 06:35:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:35:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:35:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:35:58 --> URI Class Initialized
INFO - 2023-06-01 06:35:58 --> Router Class Initialized
INFO - 2023-06-01 06:35:58 --> Output Class Initialized
INFO - 2023-06-01 06:35:58 --> Security Class Initialized
DEBUG - 2023-06-01 06:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:35:58 --> Input Class Initialized
INFO - 2023-06-01 06:35:58 --> Language Class Initialized
INFO - 2023-06-01 06:35:58 --> Loader Class Initialized
INFO - 2023-06-01 06:35:58 --> Controller Class Initialized
DEBUG - 2023-06-01 06:35:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:35:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:35:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:35:58 --> Final output sent to browser
DEBUG - 2023-06-01 06:35:58 --> Total execution time: 0.3855
INFO - 2023-06-01 06:35:58 --> Config Class Initialized
INFO - 2023-06-01 06:35:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:35:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:35:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:35:58 --> URI Class Initialized
INFO - 2023-06-01 06:35:58 --> Router Class Initialized
INFO - 2023-06-01 06:35:58 --> Output Class Initialized
INFO - 2023-06-01 06:35:59 --> Security Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:35:59 --> Input Class Initialized
INFO - 2023-06-01 06:35:59 --> Language Class Initialized
INFO - 2023-06-01 06:35:59 --> Loader Class Initialized
INFO - 2023-06-01 06:35:59 --> Controller Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:35:59 --> Database Driver Class Initialized
INFO - 2023-06-01 06:35:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:35:59 --> Final output sent to browser
DEBUG - 2023-06-01 06:35:59 --> Total execution time: 0.2930
INFO - 2023-06-01 06:35:59 --> Config Class Initialized
INFO - 2023-06-01 06:35:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:35:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:35:59 --> Utf8 Class Initialized
INFO - 2023-06-01 06:35:59 --> URI Class Initialized
INFO - 2023-06-01 06:35:59 --> Router Class Initialized
INFO - 2023-06-01 06:35:59 --> Output Class Initialized
INFO - 2023-06-01 06:35:59 --> Security Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:35:59 --> Input Class Initialized
INFO - 2023-06-01 06:35:59 --> Language Class Initialized
INFO - 2023-06-01 06:35:59 --> Loader Class Initialized
INFO - 2023-06-01 06:35:59 --> Controller Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:35:59 --> Database Driver Class Initialized
INFO - 2023-06-01 06:35:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:35:59 --> Final output sent to browser
DEBUG - 2023-06-01 06:35:59 --> Total execution time: 0.2472
INFO - 2023-06-01 06:35:59 --> Config Class Initialized
INFO - 2023-06-01 06:35:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:35:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:35:59 --> Utf8 Class Initialized
INFO - 2023-06-01 06:35:59 --> URI Class Initialized
INFO - 2023-06-01 06:35:59 --> Router Class Initialized
INFO - 2023-06-01 06:35:59 --> Output Class Initialized
INFO - 2023-06-01 06:35:59 --> Security Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:35:59 --> Input Class Initialized
INFO - 2023-06-01 06:35:59 --> Language Class Initialized
INFO - 2023-06-01 06:35:59 --> Loader Class Initialized
INFO - 2023-06-01 06:35:59 --> Controller Class Initialized
DEBUG - 2023-06-01 06:35:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:35:59 --> Database Driver Class Initialized
INFO - 2023-06-01 06:35:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:36:00 --> Final output sent to browser
DEBUG - 2023-06-01 06:36:00 --> Total execution time: 0.5225
INFO - 2023-06-01 06:38:50 --> Config Class Initialized
INFO - 2023-06-01 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:38:50 --> Utf8 Class Initialized
INFO - 2023-06-01 06:38:50 --> URI Class Initialized
INFO - 2023-06-01 06:38:50 --> Router Class Initialized
INFO - 2023-06-01 06:38:50 --> Output Class Initialized
INFO - 2023-06-01 06:38:50 --> Security Class Initialized
DEBUG - 2023-06-01 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:38:50 --> Input Class Initialized
INFO - 2023-06-01 06:38:50 --> Language Class Initialized
INFO - 2023-06-01 06:38:50 --> Loader Class Initialized
INFO - 2023-06-01 06:38:50 --> Controller Class Initialized
DEBUG - 2023-06-01 06:38:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:38:50 --> Database Driver Class Initialized
INFO - 2023-06-01 06:38:50 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:38:50 --> Final output sent to browser
DEBUG - 2023-06-01 06:38:50 --> Total execution time: 0.4202
INFO - 2023-06-01 06:38:50 --> Config Class Initialized
INFO - 2023-06-01 06:38:50 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:38:50 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:38:50 --> Utf8 Class Initialized
INFO - 2023-06-01 06:38:50 --> URI Class Initialized
INFO - 2023-06-01 06:38:50 --> Router Class Initialized
INFO - 2023-06-01 06:38:50 --> Output Class Initialized
INFO - 2023-06-01 06:38:50 --> Security Class Initialized
DEBUG - 2023-06-01 06:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:38:50 --> Input Class Initialized
INFO - 2023-06-01 06:38:50 --> Language Class Initialized
INFO - 2023-06-01 06:38:50 --> Loader Class Initialized
INFO - 2023-06-01 06:38:50 --> Controller Class Initialized
DEBUG - 2023-06-01 06:38:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:38:50 --> Database Driver Class Initialized
INFO - 2023-06-01 06:38:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:38:51 --> Final output sent to browser
DEBUG - 2023-06-01 06:38:51 --> Total execution time: 0.2707
INFO - 2023-06-01 06:39:32 --> Config Class Initialized
INFO - 2023-06-01 06:39:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:32 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:32 --> URI Class Initialized
INFO - 2023-06-01 06:39:32 --> Router Class Initialized
INFO - 2023-06-01 06:39:32 --> Output Class Initialized
INFO - 2023-06-01 06:39:32 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:32 --> Input Class Initialized
INFO - 2023-06-01 06:39:32 --> Language Class Initialized
INFO - 2023-06-01 06:39:32 --> Loader Class Initialized
INFO - 2023-06-01 06:39:32 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:32 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:32 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:32 --> Total execution time: 0.3058
INFO - 2023-06-01 06:39:33 --> Config Class Initialized
INFO - 2023-06-01 06:39:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:33 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:33 --> URI Class Initialized
INFO - 2023-06-01 06:39:33 --> Router Class Initialized
INFO - 2023-06-01 06:39:33 --> Output Class Initialized
INFO - 2023-06-01 06:39:33 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:33 --> Input Class Initialized
INFO - 2023-06-01 06:39:33 --> Language Class Initialized
INFO - 2023-06-01 06:39:33 --> Loader Class Initialized
INFO - 2023-06-01 06:39:33 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:33 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:33 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:33 --> Total execution time: 0.2499
INFO - 2023-06-01 06:39:37 --> Config Class Initialized
INFO - 2023-06-01 06:39:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:37 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:37 --> URI Class Initialized
INFO - 2023-06-01 06:39:37 --> Router Class Initialized
INFO - 2023-06-01 06:39:37 --> Output Class Initialized
INFO - 2023-06-01 06:39:37 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:37 --> Input Class Initialized
INFO - 2023-06-01 06:39:37 --> Language Class Initialized
INFO - 2023-06-01 06:39:37 --> Loader Class Initialized
INFO - 2023-06-01 06:39:37 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:37 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:38 --> Total execution time: 0.1654
INFO - 2023-06-01 06:39:38 --> Config Class Initialized
INFO - 2023-06-01 06:39:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:38 --> URI Class Initialized
INFO - 2023-06-01 06:39:38 --> Router Class Initialized
INFO - 2023-06-01 06:39:38 --> Output Class Initialized
INFO - 2023-06-01 06:39:38 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:38 --> Input Class Initialized
INFO - 2023-06-01 06:39:38 --> Language Class Initialized
INFO - 2023-06-01 06:39:38 --> Loader Class Initialized
INFO - 2023-06-01 06:39:38 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:38 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:38 --> Total execution time: 0.1844
INFO - 2023-06-01 06:39:38 --> Config Class Initialized
INFO - 2023-06-01 06:39:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:38 --> URI Class Initialized
INFO - 2023-06-01 06:39:38 --> Router Class Initialized
INFO - 2023-06-01 06:39:38 --> Output Class Initialized
INFO - 2023-06-01 06:39:38 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:38 --> Input Class Initialized
INFO - 2023-06-01 06:39:38 --> Language Class Initialized
INFO - 2023-06-01 06:39:38 --> Loader Class Initialized
INFO - 2023-06-01 06:39:38 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:38 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:38 --> Total execution time: 0.1779
INFO - 2023-06-01 06:39:38 --> Config Class Initialized
INFO - 2023-06-01 06:39:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:38 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:38 --> URI Class Initialized
INFO - 2023-06-01 06:39:38 --> Router Class Initialized
INFO - 2023-06-01 06:39:38 --> Output Class Initialized
INFO - 2023-06-01 06:39:38 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:38 --> Input Class Initialized
INFO - 2023-06-01 06:39:38 --> Language Class Initialized
INFO - 2023-06-01 06:39:38 --> Loader Class Initialized
INFO - 2023-06-01 06:39:38 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:38 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:38 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:38 --> Total execution time: 0.2101
INFO - 2023-06-01 06:39:40 --> Config Class Initialized
INFO - 2023-06-01 06:39:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:40 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:40 --> URI Class Initialized
INFO - 2023-06-01 06:39:40 --> Router Class Initialized
INFO - 2023-06-01 06:39:40 --> Output Class Initialized
INFO - 2023-06-01 06:39:40 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:40 --> Input Class Initialized
INFO - 2023-06-01 06:39:40 --> Language Class Initialized
INFO - 2023-06-01 06:39:40 --> Loader Class Initialized
INFO - 2023-06-01 06:39:40 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:40 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:41 --> Total execution time: 0.1763
INFO - 2023-06-01 06:39:41 --> Config Class Initialized
INFO - 2023-06-01 06:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:41 --> URI Class Initialized
INFO - 2023-06-01 06:39:41 --> Router Class Initialized
INFO - 2023-06-01 06:39:41 --> Output Class Initialized
INFO - 2023-06-01 06:39:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:41 --> Input Class Initialized
INFO - 2023-06-01 06:39:41 --> Language Class Initialized
INFO - 2023-06-01 06:39:41 --> Loader Class Initialized
INFO - 2023-06-01 06:39:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:41 --> Total execution time: 0.2064
INFO - 2023-06-01 06:39:41 --> Config Class Initialized
INFO - 2023-06-01 06:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:41 --> URI Class Initialized
INFO - 2023-06-01 06:39:41 --> Router Class Initialized
INFO - 2023-06-01 06:39:41 --> Output Class Initialized
INFO - 2023-06-01 06:39:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:41 --> Input Class Initialized
INFO - 2023-06-01 06:39:41 --> Language Class Initialized
INFO - 2023-06-01 06:39:41 --> Loader Class Initialized
INFO - 2023-06-01 06:39:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:41 --> Total execution time: 0.1705
INFO - 2023-06-01 06:39:41 --> Config Class Initialized
INFO - 2023-06-01 06:39:41 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:41 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:41 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:41 --> URI Class Initialized
INFO - 2023-06-01 06:39:41 --> Router Class Initialized
INFO - 2023-06-01 06:39:41 --> Output Class Initialized
INFO - 2023-06-01 06:39:41 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:41 --> Input Class Initialized
INFO - 2023-06-01 06:39:41 --> Language Class Initialized
INFO - 2023-06-01 06:39:41 --> Loader Class Initialized
INFO - 2023-06-01 06:39:41 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:41 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:41 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:41 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:41 --> Total execution time: 0.1975
INFO - 2023-06-01 06:39:43 --> Config Class Initialized
INFO - 2023-06-01 06:39:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:43 --> URI Class Initialized
INFO - 2023-06-01 06:39:43 --> Router Class Initialized
INFO - 2023-06-01 06:39:43 --> Output Class Initialized
INFO - 2023-06-01 06:39:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:43 --> Input Class Initialized
INFO - 2023-06-01 06:39:43 --> Language Class Initialized
INFO - 2023-06-01 06:39:43 --> Loader Class Initialized
INFO - 2023-06-01 06:39:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:43 --> Total execution time: 0.1948
INFO - 2023-06-01 06:39:43 --> Config Class Initialized
INFO - 2023-06-01 06:39:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:43 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:43 --> URI Class Initialized
INFO - 2023-06-01 06:39:43 --> Router Class Initialized
INFO - 2023-06-01 06:39:43 --> Output Class Initialized
INFO - 2023-06-01 06:39:43 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:43 --> Input Class Initialized
INFO - 2023-06-01 06:39:43 --> Language Class Initialized
INFO - 2023-06-01 06:39:43 --> Loader Class Initialized
INFO - 2023-06-01 06:39:43 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:43 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:43 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:43 --> Total execution time: 0.1666
INFO - 2023-06-01 06:39:44 --> Config Class Initialized
INFO - 2023-06-01 06:39:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:44 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:44 --> URI Class Initialized
INFO - 2023-06-01 06:39:44 --> Router Class Initialized
INFO - 2023-06-01 06:39:44 --> Output Class Initialized
INFO - 2023-06-01 06:39:44 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:44 --> Input Class Initialized
INFO - 2023-06-01 06:39:44 --> Language Class Initialized
INFO - 2023-06-01 06:39:44 --> Loader Class Initialized
INFO - 2023-06-01 06:39:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:44 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:44 --> Total execution time: 0.1936
INFO - 2023-06-01 06:39:44 --> Config Class Initialized
INFO - 2023-06-01 06:39:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:39:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:39:44 --> Utf8 Class Initialized
INFO - 2023-06-01 06:39:44 --> URI Class Initialized
INFO - 2023-06-01 06:39:44 --> Router Class Initialized
INFO - 2023-06-01 06:39:44 --> Output Class Initialized
INFO - 2023-06-01 06:39:44 --> Security Class Initialized
DEBUG - 2023-06-01 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:39:44 --> Input Class Initialized
INFO - 2023-06-01 06:39:44 --> Language Class Initialized
INFO - 2023-06-01 06:39:44 --> Loader Class Initialized
INFO - 2023-06-01 06:39:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:39:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:39:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:39:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:39:44 --> Final output sent to browser
DEBUG - 2023-06-01 06:39:44 --> Total execution time: 0.1863
INFO - 2023-06-01 06:40:24 --> Config Class Initialized
INFO - 2023-06-01 06:40:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:24 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:24 --> URI Class Initialized
INFO - 2023-06-01 06:40:24 --> Router Class Initialized
INFO - 2023-06-01 06:40:24 --> Output Class Initialized
INFO - 2023-06-01 06:40:24 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:24 --> Input Class Initialized
INFO - 2023-06-01 06:40:24 --> Language Class Initialized
INFO - 2023-06-01 06:40:24 --> Loader Class Initialized
INFO - 2023-06-01 06:40:24 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:24 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:24 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:24 --> Total execution time: 0.2310
INFO - 2023-06-01 06:40:24 --> Config Class Initialized
INFO - 2023-06-01 06:40:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:24 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:24 --> URI Class Initialized
INFO - 2023-06-01 06:40:24 --> Router Class Initialized
INFO - 2023-06-01 06:40:24 --> Output Class Initialized
INFO - 2023-06-01 06:40:24 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:24 --> Input Class Initialized
INFO - 2023-06-01 06:40:24 --> Language Class Initialized
INFO - 2023-06-01 06:40:24 --> Loader Class Initialized
INFO - 2023-06-01 06:40:24 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:24 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:24 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:24 --> Total execution time: 0.4316
INFO - 2023-06-01 06:40:44 --> Config Class Initialized
INFO - 2023-06-01 06:40:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:44 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:44 --> URI Class Initialized
INFO - 2023-06-01 06:40:44 --> Router Class Initialized
INFO - 2023-06-01 06:40:44 --> Output Class Initialized
INFO - 2023-06-01 06:40:44 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:44 --> Input Class Initialized
INFO - 2023-06-01 06:40:44 --> Language Class Initialized
INFO - 2023-06-01 06:40:44 --> Loader Class Initialized
INFO - 2023-06-01 06:40:44 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:44 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:45 --> Total execution time: 0.1635
INFO - 2023-06-01 06:40:45 --> Config Class Initialized
INFO - 2023-06-01 06:40:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:45 --> URI Class Initialized
INFO - 2023-06-01 06:40:45 --> Router Class Initialized
INFO - 2023-06-01 06:40:45 --> Output Class Initialized
INFO - 2023-06-01 06:40:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:45 --> Input Class Initialized
INFO - 2023-06-01 06:40:45 --> Language Class Initialized
INFO - 2023-06-01 06:40:45 --> Loader Class Initialized
INFO - 2023-06-01 06:40:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:45 --> Total execution time: 0.2109
INFO - 2023-06-01 06:40:45 --> Config Class Initialized
INFO - 2023-06-01 06:40:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:45 --> URI Class Initialized
INFO - 2023-06-01 06:40:45 --> Router Class Initialized
INFO - 2023-06-01 06:40:45 --> Output Class Initialized
INFO - 2023-06-01 06:40:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:45 --> Input Class Initialized
INFO - 2023-06-01 06:40:45 --> Language Class Initialized
INFO - 2023-06-01 06:40:45 --> Loader Class Initialized
INFO - 2023-06-01 06:40:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:45 --> Total execution time: 0.1698
INFO - 2023-06-01 06:40:45 --> Config Class Initialized
INFO - 2023-06-01 06:40:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:40:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:40:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:40:45 --> URI Class Initialized
INFO - 2023-06-01 06:40:45 --> Router Class Initialized
INFO - 2023-06-01 06:40:45 --> Output Class Initialized
INFO - 2023-06-01 06:40:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:40:45 --> Input Class Initialized
INFO - 2023-06-01 06:40:45 --> Language Class Initialized
INFO - 2023-06-01 06:40:45 --> Loader Class Initialized
INFO - 2023-06-01 06:40:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:40:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:40:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:40:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:40:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:40:45 --> Total execution time: 0.1884
INFO - 2023-06-01 06:41:05 --> Config Class Initialized
INFO - 2023-06-01 06:41:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:05 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:05 --> URI Class Initialized
INFO - 2023-06-01 06:41:05 --> Router Class Initialized
INFO - 2023-06-01 06:41:05 --> Output Class Initialized
INFO - 2023-06-01 06:41:05 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:05 --> Input Class Initialized
INFO - 2023-06-01 06:41:05 --> Language Class Initialized
INFO - 2023-06-01 06:41:05 --> Loader Class Initialized
INFO - 2023-06-01 06:41:05 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:05 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:05 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:05 --> Total execution time: 0.2125
INFO - 2023-06-01 06:41:05 --> Config Class Initialized
INFO - 2023-06-01 06:41:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:05 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:05 --> URI Class Initialized
INFO - 2023-06-01 06:41:05 --> Router Class Initialized
INFO - 2023-06-01 06:41:05 --> Output Class Initialized
INFO - 2023-06-01 06:41:05 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:05 --> Input Class Initialized
INFO - 2023-06-01 06:41:05 --> Language Class Initialized
INFO - 2023-06-01 06:41:06 --> Loader Class Initialized
INFO - 2023-06-01 06:41:06 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:06 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:06 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:06 --> Total execution time: 0.1904
INFO - 2023-06-01 06:41:06 --> Config Class Initialized
INFO - 2023-06-01 06:41:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:06 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:06 --> URI Class Initialized
INFO - 2023-06-01 06:41:06 --> Router Class Initialized
INFO - 2023-06-01 06:41:06 --> Output Class Initialized
INFO - 2023-06-01 06:41:06 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:06 --> Input Class Initialized
INFO - 2023-06-01 06:41:06 --> Language Class Initialized
INFO - 2023-06-01 06:41:06 --> Loader Class Initialized
INFO - 2023-06-01 06:41:06 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:06 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:06 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:06 --> Total execution time: 0.2408
INFO - 2023-06-01 06:41:06 --> Config Class Initialized
INFO - 2023-06-01 06:41:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:06 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:06 --> URI Class Initialized
INFO - 2023-06-01 06:41:06 --> Router Class Initialized
INFO - 2023-06-01 06:41:06 --> Output Class Initialized
INFO - 2023-06-01 06:41:06 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:06 --> Input Class Initialized
INFO - 2023-06-01 06:41:06 --> Language Class Initialized
INFO - 2023-06-01 06:41:06 --> Loader Class Initialized
INFO - 2023-06-01 06:41:06 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:06 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:06 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:06 --> Total execution time: 0.2141
INFO - 2023-06-01 06:41:16 --> Config Class Initialized
INFO - 2023-06-01 06:41:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:16 --> URI Class Initialized
INFO - 2023-06-01 06:41:16 --> Router Class Initialized
INFO - 2023-06-01 06:41:16 --> Output Class Initialized
INFO - 2023-06-01 06:41:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:16 --> Input Class Initialized
INFO - 2023-06-01 06:41:17 --> Language Class Initialized
INFO - 2023-06-01 06:41:17 --> Loader Class Initialized
INFO - 2023-06-01 06:41:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:17 --> Total execution time: 0.1773
INFO - 2023-06-01 06:41:17 --> Config Class Initialized
INFO - 2023-06-01 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:17 --> URI Class Initialized
INFO - 2023-06-01 06:41:17 --> Router Class Initialized
INFO - 2023-06-01 06:41:17 --> Output Class Initialized
INFO - 2023-06-01 06:41:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:17 --> Input Class Initialized
INFO - 2023-06-01 06:41:17 --> Language Class Initialized
INFO - 2023-06-01 06:41:17 --> Loader Class Initialized
INFO - 2023-06-01 06:41:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:17 --> Total execution time: 0.1780
INFO - 2023-06-01 06:41:17 --> Config Class Initialized
INFO - 2023-06-01 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:17 --> URI Class Initialized
INFO - 2023-06-01 06:41:17 --> Router Class Initialized
INFO - 2023-06-01 06:41:17 --> Output Class Initialized
INFO - 2023-06-01 06:41:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:17 --> Input Class Initialized
INFO - 2023-06-01 06:41:17 --> Language Class Initialized
INFO - 2023-06-01 06:41:17 --> Loader Class Initialized
INFO - 2023-06-01 06:41:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:17 --> Total execution time: 0.2002
INFO - 2023-06-01 06:41:17 --> Config Class Initialized
INFO - 2023-06-01 06:41:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:17 --> URI Class Initialized
INFO - 2023-06-01 06:41:17 --> Router Class Initialized
INFO - 2023-06-01 06:41:17 --> Output Class Initialized
INFO - 2023-06-01 06:41:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:17 --> Input Class Initialized
INFO - 2023-06-01 06:41:17 --> Language Class Initialized
INFO - 2023-06-01 06:41:17 --> Loader Class Initialized
INFO - 2023-06-01 06:41:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:17 --> Total execution time: 0.2031
INFO - 2023-06-01 06:41:57 --> Config Class Initialized
INFO - 2023-06-01 06:41:57 --> Config Class Initialized
INFO - 2023-06-01 06:41:57 --> Config Class Initialized
INFO - 2023-06-01 06:41:57 --> Hooks Class Initialized
INFO - 2023-06-01 06:41:57 --> Hooks Class Initialized
INFO - 2023-06-01 06:41:57 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:57 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:41:57 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:41:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:57 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:57 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:57 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:57 --> URI Class Initialized
INFO - 2023-06-01 06:41:57 --> URI Class Initialized
INFO - 2023-06-01 06:41:57 --> URI Class Initialized
INFO - 2023-06-01 06:41:57 --> Router Class Initialized
INFO - 2023-06-01 06:41:57 --> Router Class Initialized
INFO - 2023-06-01 06:41:57 --> Router Class Initialized
INFO - 2023-06-01 06:41:57 --> Output Class Initialized
INFO - 2023-06-01 06:41:57 --> Output Class Initialized
INFO - 2023-06-01 06:41:57 --> Output Class Initialized
INFO - 2023-06-01 06:41:57 --> Security Class Initialized
INFO - 2023-06-01 06:41:57 --> Security Class Initialized
INFO - 2023-06-01 06:41:57 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:57 --> Input Class Initialized
INFO - 2023-06-01 06:41:57 --> Input Class Initialized
INFO - 2023-06-01 06:41:57 --> Input Class Initialized
INFO - 2023-06-01 06:41:57 --> Language Class Initialized
INFO - 2023-06-01 06:41:57 --> Language Class Initialized
INFO - 2023-06-01 06:41:57 --> Language Class Initialized
INFO - 2023-06-01 06:41:57 --> Loader Class Initialized
INFO - 2023-06-01 06:41:57 --> Loader Class Initialized
INFO - 2023-06-01 06:41:57 --> Controller Class Initialized
INFO - 2023-06-01 06:41:57 --> Controller Class Initialized
INFO - 2023-06-01 06:41:57 --> Loader Class Initialized
DEBUG - 2023-06-01 06:41:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 06:41:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:57 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:57 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:57 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.1693
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.1700
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.1965
INFO - 2023-06-01 06:41:58 --> Config Class Initialized
INFO - 2023-06-01 06:41:58 --> Config Class Initialized
INFO - 2023-06-01 06:41:58 --> Hooks Class Initialized
INFO - 2023-06-01 06:41:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:41:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:58 --> URI Class Initialized
INFO - 2023-06-01 06:41:58 --> URI Class Initialized
INFO - 2023-06-01 06:41:58 --> Config Class Initialized
INFO - 2023-06-01 06:41:58 --> Router Class Initialized
INFO - 2023-06-01 06:41:58 --> Hooks Class Initialized
INFO - 2023-06-01 06:41:58 --> Router Class Initialized
INFO - 2023-06-01 06:41:58 --> Output Class Initialized
INFO - 2023-06-01 06:41:58 --> Output Class Initialized
INFO - 2023-06-01 06:41:58 --> Security Class Initialized
INFO - 2023-06-01 06:41:58 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:58 --> Input Class Initialized
INFO - 2023-06-01 06:41:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:58 --> Input Class Initialized
INFO - 2023-06-01 06:41:58 --> Language Class Initialized
INFO - 2023-06-01 06:41:58 --> URI Class Initialized
INFO - 2023-06-01 06:41:58 --> Language Class Initialized
INFO - 2023-06-01 06:41:58 --> Loader Class Initialized
INFO - 2023-06-01 06:41:58 --> Router Class Initialized
INFO - 2023-06-01 06:41:58 --> Loader Class Initialized
INFO - 2023-06-01 06:41:58 --> Controller Class Initialized
INFO - 2023-06-01 06:41:58 --> Controller Class Initialized
INFO - 2023-06-01 06:41:58 --> Output Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 06:41:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:58 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:58 --> Input Class Initialized
INFO - 2023-06-01 06:41:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Language Class Initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.2082
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.2086
INFO - 2023-06-01 06:41:58 --> Loader Class Initialized
INFO - 2023-06-01 06:41:58 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Config Class Initialized
INFO - 2023-06-01 06:41:58 --> Hooks Class Initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 06:41:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:58 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:58 --> Final output sent to browser
DEBUG - 2023-06-01 06:41:58 --> Total execution time: 0.3098
INFO - 2023-06-01 06:41:58 --> URI Class Initialized
INFO - 2023-06-01 06:41:58 --> Router Class Initialized
INFO - 2023-06-01 06:41:58 --> Output Class Initialized
INFO - 2023-06-01 06:41:58 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:58 --> Input Class Initialized
INFO - 2023-06-01 06:41:58 --> Language Class Initialized
INFO - 2023-06-01 06:41:58 --> Loader Class Initialized
INFO - 2023-06-01 06:41:58 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:58 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:41:58 --> Config Class Initialized
INFO - 2023-06-01 06:41:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:41:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:41:59 --> Utf8 Class Initialized
INFO - 2023-06-01 06:41:59 --> URI Class Initialized
INFO - 2023-06-01 06:41:59 --> Router Class Initialized
INFO - 2023-06-01 06:41:59 --> Output Class Initialized
INFO - 2023-06-01 06:41:59 --> Security Class Initialized
DEBUG - 2023-06-01 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:41:59 --> Input Class Initialized
INFO - 2023-06-01 06:41:59 --> Language Class Initialized
INFO - 2023-06-01 06:41:59 --> Loader Class Initialized
INFO - 2023-06-01 06:41:59 --> Controller Class Initialized
DEBUG - 2023-06-01 06:41:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:41:59 --> Database Driver Class Initialized
INFO - 2023-06-01 06:41:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:16 --> Loader Class Initialized
INFO - 2023-06-01 06:42:16 --> Loader Class Initialized
INFO - 2023-06-01 06:42:16 --> Controller Class Initialized
INFO - 2023-06-01 06:42:16 --> Controller Class Initialized
INFO - 2023-06-01 06:42:16 --> Loader Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 06:42:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:16 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:16 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:16 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:16 --> Final output sent to browser
INFO - 2023-06-01 06:42:16 --> Final output sent to browser
INFO - 2023-06-01 06:42:16 --> Database Driver Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Total execution time: 0.2786
DEBUG - 2023-06-01 06:42:16 --> Total execution time: 0.2797
INFO - 2023-06-01 06:42:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:16 --> Final output sent to browser
DEBUG - 2023-06-01 06:42:16 --> Total execution time: 0.3080
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> Config Class Initialized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> Hooks Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
DEBUG - 2023-06-01 06:42:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
INFO - 2023-06-01 06:42:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:16 --> URI Class Initialized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:16 --> Router Class Initialized
INFO - 2023-06-01 06:42:16 --> Loader Class Initialized
INFO - 2023-06-01 06:42:16 --> Loader Class Initialized
INFO - 2023-06-01 06:42:16 --> Output Class Initialized
INFO - 2023-06-01 06:42:16 --> Controller Class Initialized
INFO - 2023-06-01 06:42:16 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 06:42:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:16 --> Input Class Initialized
INFO - 2023-06-01 06:42:16 --> Language Class Initialized
INFO - 2023-06-01 06:42:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:17 --> Loader Class Initialized
INFO - 2023-06-01 06:42:17 --> Final output sent to browser
INFO - 2023-06-01 06:42:17 --> Final output sent to browser
INFO - 2023-06-01 06:42:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:17 --> Total execution time: 0.2698
DEBUG - 2023-06-01 06:42:17 --> Total execution time: 0.2686
DEBUG - 2023-06-01 06:42:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:17 --> Config Class Initialized
INFO - 2023-06-01 06:42:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:17 --> URI Class Initialized
INFO - 2023-06-01 06:42:17 --> Router Class Initialized
INFO - 2023-06-01 06:42:17 --> Output Class Initialized
INFO - 2023-06-01 06:42:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:17 --> Input Class Initialized
INFO - 2023-06-01 06:42:17 --> Language Class Initialized
INFO - 2023-06-01 06:42:17 --> Loader Class Initialized
INFO - 2023-06-01 06:42:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:42:17 --> Total execution time: 0.5287
INFO - 2023-06-01 06:42:17 --> Config Class Initialized
INFO - 2023-06-01 06:42:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:17 --> URI Class Initialized
INFO - 2023-06-01 06:42:17 --> Router Class Initialized
INFO - 2023-06-01 06:42:17 --> Output Class Initialized
INFO - 2023-06-01 06:42:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:17 --> Input Class Initialized
INFO - 2023-06-01 06:42:17 --> Language Class Initialized
INFO - 2023-06-01 06:42:17 --> Loader Class Initialized
INFO - 2023-06-01 06:42:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:26 --> Config Class Initialized
INFO - 2023-06-01 06:42:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:26 --> URI Class Initialized
INFO - 2023-06-01 06:42:26 --> Router Class Initialized
INFO - 2023-06-01 06:42:26 --> Output Class Initialized
INFO - 2023-06-01 06:42:26 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:26 --> Input Class Initialized
INFO - 2023-06-01 06:42:26 --> Language Class Initialized
INFO - 2023-06-01 06:42:26 --> Loader Class Initialized
INFO - 2023-06-01 06:42:26 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:26 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:26 --> Final output sent to browser
DEBUG - 2023-06-01 06:42:26 --> Total execution time: 0.1691
INFO - 2023-06-01 06:42:26 --> Config Class Initialized
INFO - 2023-06-01 06:42:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:42:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:42:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:42:26 --> URI Class Initialized
INFO - 2023-06-01 06:42:26 --> Router Class Initialized
INFO - 2023-06-01 06:42:26 --> Output Class Initialized
INFO - 2023-06-01 06:42:26 --> Security Class Initialized
DEBUG - 2023-06-01 06:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:42:26 --> Input Class Initialized
INFO - 2023-06-01 06:42:26 --> Language Class Initialized
INFO - 2023-06-01 06:42:26 --> Loader Class Initialized
INFO - 2023-06-01 06:42:26 --> Controller Class Initialized
DEBUG - 2023-06-01 06:42:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:42:26 --> Database Driver Class Initialized
INFO - 2023-06-01 06:42:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:42:26 --> Final output sent to browser
DEBUG - 2023-06-01 06:42:26 --> Total execution time: 0.2306
INFO - 2023-06-01 06:56:13 --> Config Class Initialized
INFO - 2023-06-01 06:56:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:56:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:56:13 --> Utf8 Class Initialized
INFO - 2023-06-01 06:56:13 --> URI Class Initialized
INFO - 2023-06-01 06:56:13 --> Router Class Initialized
INFO - 2023-06-01 06:56:13 --> Output Class Initialized
INFO - 2023-06-01 06:56:13 --> Security Class Initialized
DEBUG - 2023-06-01 06:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:56:13 --> Input Class Initialized
INFO - 2023-06-01 06:56:13 --> Language Class Initialized
INFO - 2023-06-01 06:56:13 --> Loader Class Initialized
INFO - 2023-06-01 06:56:13 --> Controller Class Initialized
DEBUG - 2023-06-01 06:56:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:56:13 --> Database Driver Class Initialized
INFO - 2023-06-01 06:56:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:56:13 --> Final output sent to browser
DEBUG - 2023-06-01 06:56:13 --> Total execution time: 0.2923
INFO - 2023-06-01 06:56:13 --> Config Class Initialized
INFO - 2023-06-01 06:56:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:56:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:56:13 --> Utf8 Class Initialized
INFO - 2023-06-01 06:56:13 --> URI Class Initialized
INFO - 2023-06-01 06:56:13 --> Router Class Initialized
INFO - 2023-06-01 06:56:14 --> Output Class Initialized
INFO - 2023-06-01 06:56:14 --> Security Class Initialized
DEBUG - 2023-06-01 06:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:56:14 --> Input Class Initialized
INFO - 2023-06-01 06:56:14 --> Language Class Initialized
INFO - 2023-06-01 06:56:14 --> Loader Class Initialized
INFO - 2023-06-01 06:56:14 --> Controller Class Initialized
DEBUG - 2023-06-01 06:56:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:56:14 --> Database Driver Class Initialized
INFO - 2023-06-01 06:56:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:56:14 --> Final output sent to browser
DEBUG - 2023-06-01 06:56:14 --> Total execution time: 0.2455
INFO - 2023-06-01 06:57:04 --> Config Class Initialized
INFO - 2023-06-01 06:57:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:04 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:04 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:04 --> URI Class Initialized
INFO - 2023-06-01 06:57:04 --> Router Class Initialized
INFO - 2023-06-01 06:57:04 --> Output Class Initialized
INFO - 2023-06-01 06:57:04 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:04 --> Input Class Initialized
INFO - 2023-06-01 06:57:04 --> Language Class Initialized
INFO - 2023-06-01 06:57:04 --> Loader Class Initialized
INFO - 2023-06-01 06:57:04 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:04 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:04 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:04 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:04 --> Total execution time: 0.3488
INFO - 2023-06-01 06:57:04 --> Config Class Initialized
INFO - 2023-06-01 06:57:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:04 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:04 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:04 --> URI Class Initialized
INFO - 2023-06-01 06:57:04 --> Router Class Initialized
INFO - 2023-06-01 06:57:04 --> Output Class Initialized
INFO - 2023-06-01 06:57:04 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:04 --> Input Class Initialized
INFO - 2023-06-01 06:57:04 --> Language Class Initialized
INFO - 2023-06-01 06:57:04 --> Loader Class Initialized
INFO - 2023-06-01 06:57:04 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:04 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:04 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:04 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:04 --> Total execution time: 0.1984
INFO - 2023-06-01 06:57:17 --> Config Class Initialized
INFO - 2023-06-01 06:57:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:17 --> URI Class Initialized
INFO - 2023-06-01 06:57:17 --> Router Class Initialized
INFO - 2023-06-01 06:57:17 --> Output Class Initialized
INFO - 2023-06-01 06:57:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:17 --> Input Class Initialized
INFO - 2023-06-01 06:57:17 --> Language Class Initialized
INFO - 2023-06-01 06:57:17 --> Loader Class Initialized
INFO - 2023-06-01 06:57:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:17 --> Total execution time: 0.1758
INFO - 2023-06-01 06:57:17 --> Config Class Initialized
INFO - 2023-06-01 06:57:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:17 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:17 --> URI Class Initialized
INFO - 2023-06-01 06:57:17 --> Router Class Initialized
INFO - 2023-06-01 06:57:17 --> Output Class Initialized
INFO - 2023-06-01 06:57:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:17 --> Input Class Initialized
INFO - 2023-06-01 06:57:17 --> Language Class Initialized
INFO - 2023-06-01 06:57:17 --> Loader Class Initialized
INFO - 2023-06-01 06:57:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:17 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 06:57:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.0.125' at line 1 - Invalid query: select * from cluster_cdc_server where `host_addr`=192.168.0.125
INFO - 2023-06-01 06:57:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:17 --> Total execution time: 0.5004
INFO - 2023-06-01 06:57:18 --> Config Class Initialized
INFO - 2023-06-01 06:57:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:18 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:18 --> URI Class Initialized
INFO - 2023-06-01 06:57:18 --> Router Class Initialized
INFO - 2023-06-01 06:57:18 --> Output Class Initialized
INFO - 2023-06-01 06:57:18 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:18 --> Input Class Initialized
INFO - 2023-06-01 06:57:18 --> Language Class Initialized
INFO - 2023-06-01 06:57:18 --> Loader Class Initialized
INFO - 2023-06-01 06:57:18 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:18 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:18 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:18 --> Total execution time: 0.1711
INFO - 2023-06-01 06:57:18 --> Config Class Initialized
INFO - 2023-06-01 06:57:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:18 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:18 --> URI Class Initialized
INFO - 2023-06-01 06:57:18 --> Router Class Initialized
INFO - 2023-06-01 06:57:18 --> Output Class Initialized
INFO - 2023-06-01 06:57:18 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:18 --> Input Class Initialized
INFO - 2023-06-01 06:57:18 --> Language Class Initialized
INFO - 2023-06-01 06:57:18 --> Loader Class Initialized
INFO - 2023-06-01 06:57:18 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:18 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:18 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:18 --> Total execution time: 0.4107
INFO - 2023-06-01 06:57:35 --> Config Class Initialized
INFO - 2023-06-01 06:57:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:35 --> URI Class Initialized
INFO - 2023-06-01 06:57:35 --> Router Class Initialized
INFO - 2023-06-01 06:57:35 --> Output Class Initialized
INFO - 2023-06-01 06:57:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:35 --> Input Class Initialized
INFO - 2023-06-01 06:57:35 --> Language Class Initialized
INFO - 2023-06-01 06:57:35 --> Loader Class Initialized
INFO - 2023-06-01 06:57:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:35 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:35 --> Total execution time: 0.1709
INFO - 2023-06-01 06:57:35 --> Config Class Initialized
INFO - 2023-06-01 06:57:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:35 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:35 --> URI Class Initialized
INFO - 2023-06-01 06:57:35 --> Router Class Initialized
INFO - 2023-06-01 06:57:35 --> Output Class Initialized
INFO - 2023-06-01 06:57:35 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:35 --> Input Class Initialized
INFO - 2023-06-01 06:57:35 --> Language Class Initialized
INFO - 2023-06-01 06:57:35 --> Loader Class Initialized
INFO - 2023-06-01 06:57:35 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:35 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:36 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 06:57:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.0.125' at line 1 - Invalid query: select * from cluster_cdc_server where `host_addr`=192.168.0.125
INFO - 2023-06-01 06:57:36 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:36 --> Total execution time: 0.4297
INFO - 2023-06-01 06:57:36 --> Config Class Initialized
INFO - 2023-06-01 06:57:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:36 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:36 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:36 --> URI Class Initialized
INFO - 2023-06-01 06:57:36 --> Router Class Initialized
INFO - 2023-06-01 06:57:36 --> Output Class Initialized
INFO - 2023-06-01 06:57:36 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:36 --> Input Class Initialized
INFO - 2023-06-01 06:57:36 --> Language Class Initialized
INFO - 2023-06-01 06:57:36 --> Loader Class Initialized
INFO - 2023-06-01 06:57:36 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:36 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:36 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:36 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:36 --> Total execution time: 0.7120
INFO - 2023-06-01 06:57:36 --> Config Class Initialized
INFO - 2023-06-01 06:57:36 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:57:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:57:37 --> Utf8 Class Initialized
INFO - 2023-06-01 06:57:37 --> URI Class Initialized
INFO - 2023-06-01 06:57:37 --> Router Class Initialized
INFO - 2023-06-01 06:57:37 --> Output Class Initialized
INFO - 2023-06-01 06:57:37 --> Security Class Initialized
DEBUG - 2023-06-01 06:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:57:37 --> Input Class Initialized
INFO - 2023-06-01 06:57:37 --> Language Class Initialized
INFO - 2023-06-01 06:57:37 --> Loader Class Initialized
INFO - 2023-06-01 06:57:37 --> Controller Class Initialized
DEBUG - 2023-06-01 06:57:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:57:37 --> Database Driver Class Initialized
INFO - 2023-06-01 06:57:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:57:37 --> Final output sent to browser
DEBUG - 2023-06-01 06:57:37 --> Total execution time: 0.8692
INFO - 2023-06-01 06:58:44 --> Config Class Initialized
INFO - 2023-06-01 06:58:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:45 --> URI Class Initialized
INFO - 2023-06-01 06:58:45 --> Router Class Initialized
INFO - 2023-06-01 06:58:45 --> Output Class Initialized
INFO - 2023-06-01 06:58:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:45 --> Input Class Initialized
INFO - 2023-06-01 06:58:45 --> Language Class Initialized
INFO - 2023-06-01 06:58:45 --> Loader Class Initialized
INFO - 2023-06-01 06:58:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:45 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:45 --> Total execution time: 0.2130
INFO - 2023-06-01 06:58:45 --> Config Class Initialized
INFO - 2023-06-01 06:58:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:45 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:45 --> URI Class Initialized
INFO - 2023-06-01 06:58:45 --> Router Class Initialized
INFO - 2023-06-01 06:58:45 --> Output Class Initialized
INFO - 2023-06-01 06:58:45 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:45 --> Input Class Initialized
INFO - 2023-06-01 06:58:45 --> Language Class Initialized
INFO - 2023-06-01 06:58:45 --> Loader Class Initialized
INFO - 2023-06-01 06:58:45 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:45 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:46 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:46 --> Total execution time: 1.2474
INFO - 2023-06-01 06:58:46 --> Config Class Initialized
INFO - 2023-06-01 06:58:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:46 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:46 --> URI Class Initialized
INFO - 2023-06-01 06:58:46 --> Router Class Initialized
INFO - 2023-06-01 06:58:46 --> Output Class Initialized
INFO - 2023-06-01 06:58:46 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:46 --> Input Class Initialized
INFO - 2023-06-01 06:58:46 --> Language Class Initialized
INFO - 2023-06-01 06:58:46 --> Loader Class Initialized
INFO - 2023-06-01 06:58:46 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:46 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:46 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:46 --> Total execution time: 0.3905
INFO - 2023-06-01 06:58:46 --> Config Class Initialized
INFO - 2023-06-01 06:58:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:46 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:46 --> URI Class Initialized
INFO - 2023-06-01 06:58:46 --> Router Class Initialized
INFO - 2023-06-01 06:58:46 --> Output Class Initialized
INFO - 2023-06-01 06:58:46 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:46 --> Input Class Initialized
INFO - 2023-06-01 06:58:47 --> Language Class Initialized
INFO - 2023-06-01 06:58:47 --> Loader Class Initialized
INFO - 2023-06-01 06:58:47 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:47 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:47 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:47 --> Total execution time: 0.2113
INFO - 2023-06-01 06:58:54 --> Config Class Initialized
INFO - 2023-06-01 06:58:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:54 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:54 --> URI Class Initialized
INFO - 2023-06-01 06:58:54 --> Router Class Initialized
INFO - 2023-06-01 06:58:54 --> Output Class Initialized
INFO - 2023-06-01 06:58:54 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:54 --> Input Class Initialized
INFO - 2023-06-01 06:58:54 --> Language Class Initialized
INFO - 2023-06-01 06:58:54 --> Loader Class Initialized
INFO - 2023-06-01 06:58:54 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:54 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:54 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:54 --> Total execution time: 0.1660
INFO - 2023-06-01 06:58:54 --> Config Class Initialized
INFO - 2023-06-01 06:58:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:54 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:54 --> URI Class Initialized
INFO - 2023-06-01 06:58:54 --> Router Class Initialized
INFO - 2023-06-01 06:58:54 --> Output Class Initialized
INFO - 2023-06-01 06:58:54 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:54 --> Input Class Initialized
INFO - 2023-06-01 06:58:54 --> Language Class Initialized
INFO - 2023-06-01 06:58:54 --> Loader Class Initialized
INFO - 2023-06-01 06:58:54 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:54 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:55 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:55 --> Total execution time: 0.4491
INFO - 2023-06-01 06:58:55 --> Config Class Initialized
INFO - 2023-06-01 06:58:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:55 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:55 --> URI Class Initialized
INFO - 2023-06-01 06:58:55 --> Router Class Initialized
INFO - 2023-06-01 06:58:55 --> Output Class Initialized
INFO - 2023-06-01 06:58:55 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:55 --> Input Class Initialized
INFO - 2023-06-01 06:58:55 --> Language Class Initialized
INFO - 2023-06-01 06:58:55 --> Loader Class Initialized
INFO - 2023-06-01 06:58:55 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:55 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:55 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:55 --> Total execution time: 0.1834
INFO - 2023-06-01 06:58:55 --> Config Class Initialized
INFO - 2023-06-01 06:58:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:58:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:58:55 --> Utf8 Class Initialized
INFO - 2023-06-01 06:58:55 --> URI Class Initialized
INFO - 2023-06-01 06:58:55 --> Router Class Initialized
INFO - 2023-06-01 06:58:55 --> Output Class Initialized
INFO - 2023-06-01 06:58:55 --> Security Class Initialized
DEBUG - 2023-06-01 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:58:55 --> Input Class Initialized
INFO - 2023-06-01 06:58:55 --> Language Class Initialized
INFO - 2023-06-01 06:58:55 --> Loader Class Initialized
INFO - 2023-06-01 06:58:55 --> Controller Class Initialized
DEBUG - 2023-06-01 06:58:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:58:55 --> Database Driver Class Initialized
INFO - 2023-06-01 06:58:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:58:55 --> Final output sent to browser
DEBUG - 2023-06-01 06:58:55 --> Total execution time: 0.2623
INFO - 2023-06-01 06:59:06 --> Config Class Initialized
INFO - 2023-06-01 06:59:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:06 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:06 --> URI Class Initialized
INFO - 2023-06-01 06:59:06 --> Router Class Initialized
INFO - 2023-06-01 06:59:06 --> Output Class Initialized
INFO - 2023-06-01 06:59:06 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:06 --> Input Class Initialized
INFO - 2023-06-01 06:59:06 --> Language Class Initialized
INFO - 2023-06-01 06:59:06 --> Loader Class Initialized
INFO - 2023-06-01 06:59:06 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:06 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:07 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:07 --> Total execution time: 0.3911
INFO - 2023-06-01 06:59:07 --> Config Class Initialized
INFO - 2023-06-01 06:59:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:07 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:07 --> URI Class Initialized
INFO - 2023-06-01 06:59:07 --> Router Class Initialized
INFO - 2023-06-01 06:59:07 --> Output Class Initialized
INFO - 2023-06-01 06:59:07 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:07 --> Input Class Initialized
INFO - 2023-06-01 06:59:07 --> Language Class Initialized
INFO - 2023-06-01 06:59:07 --> Loader Class Initialized
INFO - 2023-06-01 06:59:07 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:07 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:07 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:07 --> Total execution time: 0.1942
INFO - 2023-06-01 06:59:07 --> Config Class Initialized
INFO - 2023-06-01 06:59:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:07 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:07 --> URI Class Initialized
INFO - 2023-06-01 06:59:07 --> Router Class Initialized
INFO - 2023-06-01 06:59:07 --> Output Class Initialized
INFO - 2023-06-01 06:59:07 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:07 --> Input Class Initialized
INFO - 2023-06-01 06:59:07 --> Language Class Initialized
INFO - 2023-06-01 06:59:07 --> Loader Class Initialized
INFO - 2023-06-01 06:59:07 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:07 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:07 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:07 --> Total execution time: 0.1630
INFO - 2023-06-01 06:59:07 --> Config Class Initialized
INFO - 2023-06-01 06:59:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:07 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:07 --> URI Class Initialized
INFO - 2023-06-01 06:59:07 --> Router Class Initialized
INFO - 2023-06-01 06:59:07 --> Output Class Initialized
INFO - 2023-06-01 06:59:07 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:07 --> Input Class Initialized
INFO - 2023-06-01 06:59:07 --> Language Class Initialized
INFO - 2023-06-01 06:59:07 --> Loader Class Initialized
INFO - 2023-06-01 06:59:07 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:07 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:07 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:07 --> Total execution time: 0.2048
INFO - 2023-06-01 06:59:09 --> Config Class Initialized
INFO - 2023-06-01 06:59:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:09 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:09 --> URI Class Initialized
INFO - 2023-06-01 06:59:09 --> Router Class Initialized
INFO - 2023-06-01 06:59:09 --> Output Class Initialized
INFO - 2023-06-01 06:59:09 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:09 --> Input Class Initialized
INFO - 2023-06-01 06:59:09 --> Language Class Initialized
INFO - 2023-06-01 06:59:09 --> Loader Class Initialized
INFO - 2023-06-01 06:59:09 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:10 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:10 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:10 --> Total execution time: 0.1988
INFO - 2023-06-01 06:59:10 --> Config Class Initialized
INFO - 2023-06-01 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:10 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:10 --> URI Class Initialized
INFO - 2023-06-01 06:59:10 --> Router Class Initialized
INFO - 2023-06-01 06:59:10 --> Output Class Initialized
INFO - 2023-06-01 06:59:10 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:10 --> Input Class Initialized
INFO - 2023-06-01 06:59:10 --> Language Class Initialized
INFO - 2023-06-01 06:59:10 --> Loader Class Initialized
INFO - 2023-06-01 06:59:10 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:10 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:10 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:10 --> Total execution time: 0.4579
INFO - 2023-06-01 06:59:10 --> Config Class Initialized
INFO - 2023-06-01 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:10 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:10 --> URI Class Initialized
INFO - 2023-06-01 06:59:10 --> Router Class Initialized
INFO - 2023-06-01 06:59:10 --> Output Class Initialized
INFO - 2023-06-01 06:59:10 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:10 --> Input Class Initialized
INFO - 2023-06-01 06:59:10 --> Language Class Initialized
INFO - 2023-06-01 06:59:10 --> Loader Class Initialized
INFO - 2023-06-01 06:59:10 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:10 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:10 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:10 --> Total execution time: 0.1792
INFO - 2023-06-01 06:59:10 --> Config Class Initialized
INFO - 2023-06-01 06:59:10 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:10 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:10 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:10 --> URI Class Initialized
INFO - 2023-06-01 06:59:10 --> Router Class Initialized
INFO - 2023-06-01 06:59:10 --> Output Class Initialized
INFO - 2023-06-01 06:59:10 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:10 --> Input Class Initialized
INFO - 2023-06-01 06:59:10 --> Language Class Initialized
INFO - 2023-06-01 06:59:10 --> Loader Class Initialized
INFO - 2023-06-01 06:59:10 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:10 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:11 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:11 --> Total execution time: 0.2501
INFO - 2023-06-01 06:59:12 --> Config Class Initialized
INFO - 2023-06-01 06:59:12 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:12 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:12 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:12 --> URI Class Initialized
INFO - 2023-06-01 06:59:12 --> Router Class Initialized
INFO - 2023-06-01 06:59:12 --> Output Class Initialized
INFO - 2023-06-01 06:59:12 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:12 --> Input Class Initialized
INFO - 2023-06-01 06:59:12 --> Language Class Initialized
INFO - 2023-06-01 06:59:13 --> Loader Class Initialized
INFO - 2023-06-01 06:59:13 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:13 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:13 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:13 --> Total execution time: 0.1675
INFO - 2023-06-01 06:59:13 --> Config Class Initialized
INFO - 2023-06-01 06:59:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:13 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:13 --> URI Class Initialized
INFO - 2023-06-01 06:59:13 --> Router Class Initialized
INFO - 2023-06-01 06:59:13 --> Output Class Initialized
INFO - 2023-06-01 06:59:13 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:13 --> Input Class Initialized
INFO - 2023-06-01 06:59:13 --> Language Class Initialized
INFO - 2023-06-01 06:59:13 --> Loader Class Initialized
INFO - 2023-06-01 06:59:13 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:13 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:13 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:13 --> Total execution time: 0.1951
INFO - 2023-06-01 06:59:13 --> Config Class Initialized
INFO - 2023-06-01 06:59:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:13 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:13 --> URI Class Initialized
INFO - 2023-06-01 06:59:13 --> Router Class Initialized
INFO - 2023-06-01 06:59:13 --> Output Class Initialized
INFO - 2023-06-01 06:59:13 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:13 --> Input Class Initialized
INFO - 2023-06-01 06:59:13 --> Language Class Initialized
INFO - 2023-06-01 06:59:13 --> Loader Class Initialized
INFO - 2023-06-01 06:59:13 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:13 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:13 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:13 --> Total execution time: 0.2085
INFO - 2023-06-01 06:59:13 --> Config Class Initialized
INFO - 2023-06-01 06:59:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:13 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:13 --> URI Class Initialized
INFO - 2023-06-01 06:59:13 --> Router Class Initialized
INFO - 2023-06-01 06:59:13 --> Output Class Initialized
INFO - 2023-06-01 06:59:13 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:13 --> Input Class Initialized
INFO - 2023-06-01 06:59:13 --> Language Class Initialized
INFO - 2023-06-01 06:59:13 --> Loader Class Initialized
INFO - 2023-06-01 06:59:13 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:13 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:13 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:13 --> Total execution time: 0.2527
INFO - 2023-06-01 06:59:16 --> Config Class Initialized
INFO - 2023-06-01 06:59:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:16 --> URI Class Initialized
INFO - 2023-06-01 06:59:16 --> Router Class Initialized
INFO - 2023-06-01 06:59:16 --> Output Class Initialized
INFO - 2023-06-01 06:59:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:16 --> Input Class Initialized
INFO - 2023-06-01 06:59:16 --> Language Class Initialized
INFO - 2023-06-01 06:59:16 --> Loader Class Initialized
INFO - 2023-06-01 06:59:16 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:16 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:16 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:16 --> Total execution time: 0.1888
INFO - 2023-06-01 06:59:16 --> Config Class Initialized
INFO - 2023-06-01 06:59:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:16 --> URI Class Initialized
INFO - 2023-06-01 06:59:16 --> Router Class Initialized
INFO - 2023-06-01 06:59:16 --> Output Class Initialized
INFO - 2023-06-01 06:59:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:16 --> Input Class Initialized
INFO - 2023-06-01 06:59:16 --> Language Class Initialized
INFO - 2023-06-01 06:59:16 --> Loader Class Initialized
INFO - 2023-06-01 06:59:16 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:16 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:16 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:16 --> Total execution time: 0.2107
INFO - 2023-06-01 06:59:16 --> Config Class Initialized
INFO - 2023-06-01 06:59:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:16 --> URI Class Initialized
INFO - 2023-06-01 06:59:16 --> Router Class Initialized
INFO - 2023-06-01 06:59:16 --> Output Class Initialized
INFO - 2023-06-01 06:59:16 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:16 --> Input Class Initialized
INFO - 2023-06-01 06:59:16 --> Language Class Initialized
INFO - 2023-06-01 06:59:16 --> Loader Class Initialized
INFO - 2023-06-01 06:59:16 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:16 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:16 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:16 --> Total execution time: 0.1978
INFO - 2023-06-01 06:59:16 --> Config Class Initialized
INFO - 2023-06-01 06:59:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:16 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:16 --> URI Class Initialized
INFO - 2023-06-01 06:59:16 --> Router Class Initialized
INFO - 2023-06-01 06:59:16 --> Output Class Initialized
INFO - 2023-06-01 06:59:17 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:17 --> Input Class Initialized
INFO - 2023-06-01 06:59:17 --> Language Class Initialized
INFO - 2023-06-01 06:59:17 --> Loader Class Initialized
INFO - 2023-06-01 06:59:17 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:17 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:17 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:17 --> Total execution time: 0.1980
INFO - 2023-06-01 06:59:19 --> Config Class Initialized
INFO - 2023-06-01 06:59:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:19 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:19 --> URI Class Initialized
INFO - 2023-06-01 06:59:20 --> Router Class Initialized
INFO - 2023-06-01 06:59:20 --> Output Class Initialized
INFO - 2023-06-01 06:59:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:20 --> Input Class Initialized
INFO - 2023-06-01 06:59:20 --> Language Class Initialized
INFO - 2023-06-01 06:59:20 --> Loader Class Initialized
INFO - 2023-06-01 06:59:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:20 --> Total execution time: 0.1847
INFO - 2023-06-01 06:59:20 --> Config Class Initialized
INFO - 2023-06-01 06:59:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:20 --> URI Class Initialized
INFO - 2023-06-01 06:59:20 --> Router Class Initialized
INFO - 2023-06-01 06:59:20 --> Output Class Initialized
INFO - 2023-06-01 06:59:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:20 --> Input Class Initialized
INFO - 2023-06-01 06:59:20 --> Language Class Initialized
INFO - 2023-06-01 06:59:20 --> Loader Class Initialized
INFO - 2023-06-01 06:59:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:20 --> Total execution time: 0.1897
INFO - 2023-06-01 06:59:20 --> Config Class Initialized
INFO - 2023-06-01 06:59:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:20 --> URI Class Initialized
INFO - 2023-06-01 06:59:20 --> Router Class Initialized
INFO - 2023-06-01 06:59:20 --> Output Class Initialized
INFO - 2023-06-01 06:59:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:20 --> Input Class Initialized
INFO - 2023-06-01 06:59:20 --> Language Class Initialized
INFO - 2023-06-01 06:59:20 --> Loader Class Initialized
INFO - 2023-06-01 06:59:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:20 --> Total execution time: 0.1936
INFO - 2023-06-01 06:59:20 --> Config Class Initialized
INFO - 2023-06-01 06:59:20 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:20 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:20 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:20 --> URI Class Initialized
INFO - 2023-06-01 06:59:20 --> Router Class Initialized
INFO - 2023-06-01 06:59:20 --> Output Class Initialized
INFO - 2023-06-01 06:59:20 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:20 --> Input Class Initialized
INFO - 2023-06-01 06:59:20 --> Language Class Initialized
INFO - 2023-06-01 06:59:20 --> Loader Class Initialized
INFO - 2023-06-01 06:59:20 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:20 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:20 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:20 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:20 --> Total execution time: 0.2346
INFO - 2023-06-01 06:59:22 --> Config Class Initialized
INFO - 2023-06-01 06:59:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:22 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:22 --> URI Class Initialized
INFO - 2023-06-01 06:59:22 --> Router Class Initialized
INFO - 2023-06-01 06:59:22 --> Output Class Initialized
INFO - 2023-06-01 06:59:22 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:22 --> Input Class Initialized
INFO - 2023-06-01 06:59:22 --> Language Class Initialized
INFO - 2023-06-01 06:59:22 --> Loader Class Initialized
INFO - 2023-06-01 06:59:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:23 --> Total execution time: 0.1815
INFO - 2023-06-01 06:59:23 --> Config Class Initialized
INFO - 2023-06-01 06:59:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:23 --> URI Class Initialized
INFO - 2023-06-01 06:59:23 --> Router Class Initialized
INFO - 2023-06-01 06:59:23 --> Output Class Initialized
INFO - 2023-06-01 06:59:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:23 --> Input Class Initialized
INFO - 2023-06-01 06:59:23 --> Language Class Initialized
INFO - 2023-06-01 06:59:23 --> Loader Class Initialized
INFO - 2023-06-01 06:59:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:23 --> Total execution time: 0.1948
INFO - 2023-06-01 06:59:23 --> Config Class Initialized
INFO - 2023-06-01 06:59:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:23 --> URI Class Initialized
INFO - 2023-06-01 06:59:23 --> Router Class Initialized
INFO - 2023-06-01 06:59:23 --> Output Class Initialized
INFO - 2023-06-01 06:59:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:23 --> Input Class Initialized
INFO - 2023-06-01 06:59:23 --> Language Class Initialized
INFO - 2023-06-01 06:59:23 --> Loader Class Initialized
INFO - 2023-06-01 06:59:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:23 --> Total execution time: 0.2204
INFO - 2023-06-01 06:59:23 --> Config Class Initialized
INFO - 2023-06-01 06:59:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:23 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:23 --> URI Class Initialized
INFO - 2023-06-01 06:59:23 --> Router Class Initialized
INFO - 2023-06-01 06:59:23 --> Output Class Initialized
INFO - 2023-06-01 06:59:23 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:23 --> Input Class Initialized
INFO - 2023-06-01 06:59:23 --> Language Class Initialized
INFO - 2023-06-01 06:59:23 --> Loader Class Initialized
INFO - 2023-06-01 06:59:23 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:23 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:23 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:23 --> Total execution time: 0.2242
INFO - 2023-06-01 06:59:26 --> Config Class Initialized
INFO - 2023-06-01 06:59:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:26 --> URI Class Initialized
INFO - 2023-06-01 06:59:26 --> Router Class Initialized
INFO - 2023-06-01 06:59:26 --> Output Class Initialized
INFO - 2023-06-01 06:59:26 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:26 --> Input Class Initialized
INFO - 2023-06-01 06:59:26 --> Language Class Initialized
INFO - 2023-06-01 06:59:26 --> Loader Class Initialized
INFO - 2023-06-01 06:59:26 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:26 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:26 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:26 --> Total execution time: 0.1722
INFO - 2023-06-01 06:59:26 --> Config Class Initialized
INFO - 2023-06-01 06:59:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:26 --> URI Class Initialized
INFO - 2023-06-01 06:59:26 --> Router Class Initialized
INFO - 2023-06-01 06:59:26 --> Output Class Initialized
INFO - 2023-06-01 06:59:26 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:26 --> Input Class Initialized
INFO - 2023-06-01 06:59:26 --> Language Class Initialized
INFO - 2023-06-01 06:59:26 --> Loader Class Initialized
INFO - 2023-06-01 06:59:26 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:26 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:26 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:26 --> Total execution time: 0.1738
INFO - 2023-06-01 06:59:26 --> Config Class Initialized
INFO - 2023-06-01 06:59:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:26 --> URI Class Initialized
INFO - 2023-06-01 06:59:26 --> Router Class Initialized
INFO - 2023-06-01 06:59:26 --> Output Class Initialized
INFO - 2023-06-01 06:59:26 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:26 --> Input Class Initialized
INFO - 2023-06-01 06:59:26 --> Language Class Initialized
INFO - 2023-06-01 06:59:26 --> Loader Class Initialized
INFO - 2023-06-01 06:59:26 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:26 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:26 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:26 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:26 --> Total execution time: 0.1838
INFO - 2023-06-01 06:59:26 --> Config Class Initialized
INFO - 2023-06-01 06:59:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 06:59:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 06:59:26 --> Utf8 Class Initialized
INFO - 2023-06-01 06:59:26 --> URI Class Initialized
INFO - 2023-06-01 06:59:27 --> Router Class Initialized
INFO - 2023-06-01 06:59:27 --> Output Class Initialized
INFO - 2023-06-01 06:59:27 --> Security Class Initialized
DEBUG - 2023-06-01 06:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 06:59:27 --> Input Class Initialized
INFO - 2023-06-01 06:59:27 --> Language Class Initialized
INFO - 2023-06-01 06:59:27 --> Loader Class Initialized
INFO - 2023-06-01 06:59:27 --> Controller Class Initialized
DEBUG - 2023-06-01 06:59:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 06:59:27 --> Database Driver Class Initialized
INFO - 2023-06-01 06:59:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 06:59:27 --> Final output sent to browser
DEBUG - 2023-06-01 06:59:27 --> Total execution time: 0.2134
INFO - 2023-06-01 07:00:00 --> Config Class Initialized
INFO - 2023-06-01 07:00:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:00 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:00 --> URI Class Initialized
INFO - 2023-06-01 07:00:00 --> Router Class Initialized
INFO - 2023-06-01 07:00:00 --> Output Class Initialized
INFO - 2023-06-01 07:00:00 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:00 --> Input Class Initialized
INFO - 2023-06-01 07:00:00 --> Language Class Initialized
INFO - 2023-06-01 07:00:00 --> Loader Class Initialized
INFO - 2023-06-01 07:00:00 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:00 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:00 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:00 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:00 --> Total execution time: 0.1719
INFO - 2023-06-01 07:00:00 --> Config Class Initialized
INFO - 2023-06-01 07:00:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:00 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:00 --> URI Class Initialized
INFO - 2023-06-01 07:00:00 --> Router Class Initialized
INFO - 2023-06-01 07:00:00 --> Output Class Initialized
INFO - 2023-06-01 07:00:00 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:00 --> Input Class Initialized
INFO - 2023-06-01 07:00:00 --> Language Class Initialized
INFO - 2023-06-01 07:00:00 --> Loader Class Initialized
INFO - 2023-06-01 07:00:00 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:00 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:00 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:00 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:00 --> Total execution time: 0.2406
INFO - 2023-06-01 07:00:00 --> Config Class Initialized
INFO - 2023-06-01 07:00:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:00 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:00 --> URI Class Initialized
INFO - 2023-06-01 07:00:00 --> Router Class Initialized
INFO - 2023-06-01 07:00:00 --> Output Class Initialized
INFO - 2023-06-01 07:00:00 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:00 --> Input Class Initialized
INFO - 2023-06-01 07:00:00 --> Language Class Initialized
INFO - 2023-06-01 07:00:00 --> Loader Class Initialized
INFO - 2023-06-01 07:00:00 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:01 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:01 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:01 --> Total execution time: 0.1885
INFO - 2023-06-01 07:00:01 --> Config Class Initialized
INFO - 2023-06-01 07:00:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:01 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:01 --> URI Class Initialized
INFO - 2023-06-01 07:00:01 --> Router Class Initialized
INFO - 2023-06-01 07:00:01 --> Output Class Initialized
INFO - 2023-06-01 07:00:01 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:01 --> Input Class Initialized
INFO - 2023-06-01 07:00:01 --> Language Class Initialized
INFO - 2023-06-01 07:00:01 --> Loader Class Initialized
INFO - 2023-06-01 07:00:01 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:01 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:01 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:01 --> Total execution time: 0.2106
INFO - 2023-06-01 07:00:39 --> Config Class Initialized
INFO - 2023-06-01 07:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:39 --> URI Class Initialized
INFO - 2023-06-01 07:00:39 --> Router Class Initialized
INFO - 2023-06-01 07:00:39 --> Output Class Initialized
INFO - 2023-06-01 07:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:39 --> Input Class Initialized
INFO - 2023-06-01 07:00:39 --> Language Class Initialized
INFO - 2023-06-01 07:00:39 --> Loader Class Initialized
INFO - 2023-06-01 07:00:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:39 --> Total execution time: 0.1534
INFO - 2023-06-01 07:00:39 --> Config Class Initialized
INFO - 2023-06-01 07:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:39 --> URI Class Initialized
INFO - 2023-06-01 07:00:39 --> Router Class Initialized
INFO - 2023-06-01 07:00:39 --> Output Class Initialized
INFO - 2023-06-01 07:00:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:39 --> Input Class Initialized
INFO - 2023-06-01 07:00:39 --> Language Class Initialized
INFO - 2023-06-01 07:00:39 --> Loader Class Initialized
INFO - 2023-06-01 07:00:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:39 --> Total execution time: 0.1708
INFO - 2023-06-01 07:00:39 --> Config Class Initialized
INFO - 2023-06-01 07:00:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:39 --> URI Class Initialized
INFO - 2023-06-01 07:00:39 --> Router Class Initialized
INFO - 2023-06-01 07:00:40 --> Output Class Initialized
INFO - 2023-06-01 07:00:40 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:40 --> Input Class Initialized
INFO - 2023-06-01 07:00:40 --> Language Class Initialized
INFO - 2023-06-01 07:00:40 --> Loader Class Initialized
INFO - 2023-06-01 07:00:40 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:40 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:40 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:40 --> Total execution time: 0.2007
INFO - 2023-06-01 07:00:40 --> Config Class Initialized
INFO - 2023-06-01 07:00:40 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:40 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:40 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:40 --> URI Class Initialized
INFO - 2023-06-01 07:00:40 --> Router Class Initialized
INFO - 2023-06-01 07:00:40 --> Output Class Initialized
INFO - 2023-06-01 07:00:40 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:40 --> Input Class Initialized
INFO - 2023-06-01 07:00:40 --> Language Class Initialized
INFO - 2023-06-01 07:00:40 --> Loader Class Initialized
INFO - 2023-06-01 07:00:40 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:40 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:40 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:40 --> Total execution time: 0.2006
INFO - 2023-06-01 07:00:52 --> Config Class Initialized
INFO - 2023-06-01 07:00:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:52 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:52 --> URI Class Initialized
INFO - 2023-06-01 07:00:52 --> Router Class Initialized
INFO - 2023-06-01 07:00:52 --> Output Class Initialized
INFO - 2023-06-01 07:00:52 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:52 --> Input Class Initialized
INFO - 2023-06-01 07:00:52 --> Language Class Initialized
INFO - 2023-06-01 07:00:52 --> Loader Class Initialized
INFO - 2023-06-01 07:00:52 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:52 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:52 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:52 --> Total execution time: 0.1820
INFO - 2023-06-01 07:00:52 --> Config Class Initialized
INFO - 2023-06-01 07:00:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:52 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:52 --> URI Class Initialized
INFO - 2023-06-01 07:00:52 --> Router Class Initialized
INFO - 2023-06-01 07:00:52 --> Output Class Initialized
INFO - 2023-06-01 07:00:52 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:52 --> Input Class Initialized
INFO - 2023-06-01 07:00:52 --> Language Class Initialized
INFO - 2023-06-01 07:00:52 --> Loader Class Initialized
INFO - 2023-06-01 07:00:52 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:52 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:52 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:52 --> Total execution time: 0.3174
INFO - 2023-06-01 07:00:52 --> Config Class Initialized
INFO - 2023-06-01 07:00:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:52 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:52 --> URI Class Initialized
INFO - 2023-06-01 07:00:52 --> Router Class Initialized
INFO - 2023-06-01 07:00:52 --> Output Class Initialized
INFO - 2023-06-01 07:00:53 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:53 --> Input Class Initialized
INFO - 2023-06-01 07:00:53 --> Language Class Initialized
INFO - 2023-06-01 07:00:53 --> Loader Class Initialized
INFO - 2023-06-01 07:00:53 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:53 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:53 --> Total execution time: 0.2260
INFO - 2023-06-01 07:00:53 --> Config Class Initialized
INFO - 2023-06-01 07:00:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:53 --> URI Class Initialized
INFO - 2023-06-01 07:00:53 --> Router Class Initialized
INFO - 2023-06-01 07:00:53 --> Output Class Initialized
INFO - 2023-06-01 07:00:53 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:53 --> Input Class Initialized
INFO - 2023-06-01 07:00:53 --> Language Class Initialized
INFO - 2023-06-01 07:00:53 --> Loader Class Initialized
INFO - 2023-06-01 07:00:53 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:53 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:53 --> Total execution time: 0.2604
INFO - 2023-06-01 07:00:55 --> Config Class Initialized
INFO - 2023-06-01 07:00:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:55 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:55 --> URI Class Initialized
INFO - 2023-06-01 07:00:55 --> Router Class Initialized
INFO - 2023-06-01 07:00:55 --> Output Class Initialized
INFO - 2023-06-01 07:00:55 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:55 --> Input Class Initialized
INFO - 2023-06-01 07:00:55 --> Language Class Initialized
INFO - 2023-06-01 07:00:55 --> Loader Class Initialized
INFO - 2023-06-01 07:00:55 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:55 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:55 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:55 --> Total execution time: 0.1661
INFO - 2023-06-01 07:00:55 --> Config Class Initialized
INFO - 2023-06-01 07:00:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:55 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:55 --> URI Class Initialized
INFO - 2023-06-01 07:00:55 --> Router Class Initialized
INFO - 2023-06-01 07:00:55 --> Output Class Initialized
INFO - 2023-06-01 07:00:55 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:55 --> Input Class Initialized
INFO - 2023-06-01 07:00:55 --> Language Class Initialized
INFO - 2023-06-01 07:00:55 --> Loader Class Initialized
INFO - 2023-06-01 07:00:55 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:55 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:55 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:55 --> Total execution time: 0.1929
INFO - 2023-06-01 07:00:55 --> Config Class Initialized
INFO - 2023-06-01 07:00:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:55 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:55 --> URI Class Initialized
INFO - 2023-06-01 07:00:55 --> Router Class Initialized
INFO - 2023-06-01 07:00:55 --> Output Class Initialized
INFO - 2023-06-01 07:00:55 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:55 --> Input Class Initialized
INFO - 2023-06-01 07:00:55 --> Language Class Initialized
INFO - 2023-06-01 07:00:55 --> Loader Class Initialized
INFO - 2023-06-01 07:00:55 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:55 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:55 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:55 --> Total execution time: 0.1889
INFO - 2023-06-01 07:00:55 --> Config Class Initialized
INFO - 2023-06-01 07:00:55 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:55 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:56 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:56 --> URI Class Initialized
INFO - 2023-06-01 07:00:56 --> Router Class Initialized
INFO - 2023-06-01 07:00:56 --> Output Class Initialized
INFO - 2023-06-01 07:00:56 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:56 --> Input Class Initialized
INFO - 2023-06-01 07:00:56 --> Language Class Initialized
INFO - 2023-06-01 07:00:56 --> Loader Class Initialized
INFO - 2023-06-01 07:00:56 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:56 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:56 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:56 --> Total execution time: 0.2447
INFO - 2023-06-01 07:00:59 --> Config Class Initialized
INFO - 2023-06-01 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:59 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:59 --> URI Class Initialized
INFO - 2023-06-01 07:00:59 --> Router Class Initialized
INFO - 2023-06-01 07:00:59 --> Output Class Initialized
INFO - 2023-06-01 07:00:59 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:59 --> Input Class Initialized
INFO - 2023-06-01 07:00:59 --> Language Class Initialized
INFO - 2023-06-01 07:00:59 --> Loader Class Initialized
INFO - 2023-06-01 07:00:59 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:59 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:59 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:59 --> Total execution time: 0.1707
INFO - 2023-06-01 07:00:59 --> Config Class Initialized
INFO - 2023-06-01 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:59 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:59 --> URI Class Initialized
INFO - 2023-06-01 07:00:59 --> Router Class Initialized
INFO - 2023-06-01 07:00:59 --> Output Class Initialized
INFO - 2023-06-01 07:00:59 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:59 --> Input Class Initialized
INFO - 2023-06-01 07:00:59 --> Language Class Initialized
INFO - 2023-06-01 07:00:59 --> Loader Class Initialized
INFO - 2023-06-01 07:00:59 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:59 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:59 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:59 --> Total execution time: 0.1926
INFO - 2023-06-01 07:00:59 --> Config Class Initialized
INFO - 2023-06-01 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:59 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:59 --> URI Class Initialized
INFO - 2023-06-01 07:00:59 --> Router Class Initialized
INFO - 2023-06-01 07:00:59 --> Output Class Initialized
INFO - 2023-06-01 07:00:59 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:59 --> Input Class Initialized
INFO - 2023-06-01 07:00:59 --> Language Class Initialized
INFO - 2023-06-01 07:00:59 --> Loader Class Initialized
INFO - 2023-06-01 07:00:59 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:59 --> Database Driver Class Initialized
INFO - 2023-06-01 07:00:59 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:00:59 --> Final output sent to browser
DEBUG - 2023-06-01 07:00:59 --> Total execution time: 0.1903
INFO - 2023-06-01 07:00:59 --> Config Class Initialized
INFO - 2023-06-01 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:00:59 --> Utf8 Class Initialized
INFO - 2023-06-01 07:00:59 --> URI Class Initialized
INFO - 2023-06-01 07:00:59 --> Router Class Initialized
INFO - 2023-06-01 07:00:59 --> Output Class Initialized
INFO - 2023-06-01 07:00:59 --> Security Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:00:59 --> Input Class Initialized
INFO - 2023-06-01 07:00:59 --> Language Class Initialized
INFO - 2023-06-01 07:00:59 --> Loader Class Initialized
INFO - 2023-06-01 07:00:59 --> Controller Class Initialized
DEBUG - 2023-06-01 07:00:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:00:59 --> Database Driver Class Initialized
INFO - 2023-06-01 07:01:00 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:01:00 --> Final output sent to browser
DEBUG - 2023-06-01 07:01:00 --> Total execution time: 0.4104
INFO - 2023-06-01 07:01:07 --> Config Class Initialized
INFO - 2023-06-01 07:01:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:01:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:01:07 --> Utf8 Class Initialized
INFO - 2023-06-01 07:01:07 --> URI Class Initialized
INFO - 2023-06-01 07:01:07 --> Router Class Initialized
INFO - 2023-06-01 07:01:07 --> Output Class Initialized
INFO - 2023-06-01 07:01:07 --> Security Class Initialized
DEBUG - 2023-06-01 07:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:01:07 --> Input Class Initialized
INFO - 2023-06-01 07:01:07 --> Language Class Initialized
INFO - 2023-06-01 07:01:07 --> Loader Class Initialized
INFO - 2023-06-01 07:01:07 --> Controller Class Initialized
DEBUG - 2023-06-01 07:01:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:01:07 --> Database Driver Class Initialized
INFO - 2023-06-01 07:01:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:01:07 --> Final output sent to browser
DEBUG - 2023-06-01 07:01:07 --> Total execution time: 0.1937
INFO - 2023-06-01 07:01:07 --> Config Class Initialized
INFO - 2023-06-01 07:01:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:01:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:01:07 --> Utf8 Class Initialized
INFO - 2023-06-01 07:01:07 --> URI Class Initialized
INFO - 2023-06-01 07:01:08 --> Router Class Initialized
INFO - 2023-06-01 07:01:08 --> Output Class Initialized
INFO - 2023-06-01 07:01:08 --> Security Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:01:08 --> Input Class Initialized
INFO - 2023-06-01 07:01:08 --> Language Class Initialized
INFO - 2023-06-01 07:01:08 --> Loader Class Initialized
INFO - 2023-06-01 07:01:08 --> Controller Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:01:08 --> Database Driver Class Initialized
INFO - 2023-06-01 07:01:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:01:08 --> Final output sent to browser
DEBUG - 2023-06-01 07:01:08 --> Total execution time: 0.2358
INFO - 2023-06-01 07:01:08 --> Config Class Initialized
INFO - 2023-06-01 07:01:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:01:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:01:08 --> Utf8 Class Initialized
INFO - 2023-06-01 07:01:08 --> URI Class Initialized
INFO - 2023-06-01 07:01:08 --> Router Class Initialized
INFO - 2023-06-01 07:01:08 --> Output Class Initialized
INFO - 2023-06-01 07:01:08 --> Security Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:01:08 --> Input Class Initialized
INFO - 2023-06-01 07:01:08 --> Language Class Initialized
INFO - 2023-06-01 07:01:08 --> Loader Class Initialized
INFO - 2023-06-01 07:01:08 --> Controller Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:01:08 --> Database Driver Class Initialized
INFO - 2023-06-01 07:01:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:01:08 --> Final output sent to browser
DEBUG - 2023-06-01 07:01:08 --> Total execution time: 0.1957
INFO - 2023-06-01 07:01:08 --> Config Class Initialized
INFO - 2023-06-01 07:01:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:01:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:01:08 --> Utf8 Class Initialized
INFO - 2023-06-01 07:01:08 --> URI Class Initialized
INFO - 2023-06-01 07:01:08 --> Router Class Initialized
INFO - 2023-06-01 07:01:08 --> Output Class Initialized
INFO - 2023-06-01 07:01:08 --> Security Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:01:08 --> Input Class Initialized
INFO - 2023-06-01 07:01:08 --> Language Class Initialized
INFO - 2023-06-01 07:01:08 --> Loader Class Initialized
INFO - 2023-06-01 07:01:08 --> Controller Class Initialized
DEBUG - 2023-06-01 07:01:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:01:08 --> Database Driver Class Initialized
INFO - 2023-06-01 07:01:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:01:08 --> Final output sent to browser
DEBUG - 2023-06-01 07:01:08 --> Total execution time: 0.2190
INFO - 2023-06-01 07:19:01 --> Config Class Initialized
INFO - 2023-06-01 07:19:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:01 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:01 --> URI Class Initialized
INFO - 2023-06-01 07:19:01 --> Router Class Initialized
INFO - 2023-06-01 07:19:01 --> Output Class Initialized
INFO - 2023-06-01 07:19:01 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:01 --> Input Class Initialized
INFO - 2023-06-01 07:19:01 --> Language Class Initialized
INFO - 2023-06-01 07:19:01 --> Loader Class Initialized
INFO - 2023-06-01 07:19:01 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:02 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:02 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:02 --> Total execution time: 0.4036
INFO - 2023-06-01 07:19:02 --> Config Class Initialized
INFO - 2023-06-01 07:19:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:02 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:02 --> URI Class Initialized
INFO - 2023-06-01 07:19:02 --> Router Class Initialized
INFO - 2023-06-01 07:19:02 --> Output Class Initialized
INFO - 2023-06-01 07:19:02 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:02 --> Input Class Initialized
INFO - 2023-06-01 07:19:02 --> Language Class Initialized
INFO - 2023-06-01 07:19:02 --> Loader Class Initialized
INFO - 2023-06-01 07:19:02 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:02 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:02 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:02 --> Total execution time: 0.4994
INFO - 2023-06-01 07:19:14 --> Config Class Initialized
INFO - 2023-06-01 07:19:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:14 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:14 --> URI Class Initialized
INFO - 2023-06-01 07:19:14 --> Router Class Initialized
INFO - 2023-06-01 07:19:14 --> Output Class Initialized
INFO - 2023-06-01 07:19:14 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:14 --> Input Class Initialized
INFO - 2023-06-01 07:19:14 --> Language Class Initialized
INFO - 2023-06-01 07:19:14 --> Loader Class Initialized
INFO - 2023-06-01 07:19:14 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:14 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:14 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:14 --> Total execution time: 0.4073
INFO - 2023-06-01 07:19:14 --> Config Class Initialized
INFO - 2023-06-01 07:19:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:14 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:14 --> URI Class Initialized
INFO - 2023-06-01 07:19:14 --> Router Class Initialized
INFO - 2023-06-01 07:19:14 --> Output Class Initialized
INFO - 2023-06-01 07:19:14 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:14 --> Input Class Initialized
INFO - 2023-06-01 07:19:14 --> Language Class Initialized
INFO - 2023-06-01 07:19:14 --> Loader Class Initialized
INFO - 2023-06-01 07:19:14 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:14 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:14 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:14 --> Total execution time: 0.1859
INFO - 2023-06-01 07:19:15 --> Config Class Initialized
INFO - 2023-06-01 07:19:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:15 --> URI Class Initialized
INFO - 2023-06-01 07:19:15 --> Router Class Initialized
INFO - 2023-06-01 07:19:15 --> Output Class Initialized
INFO - 2023-06-01 07:19:15 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:15 --> Input Class Initialized
INFO - 2023-06-01 07:19:15 --> Language Class Initialized
INFO - 2023-06-01 07:19:15 --> Loader Class Initialized
INFO - 2023-06-01 07:19:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:15 --> Total execution time: 0.3357
INFO - 2023-06-01 07:19:15 --> Config Class Initialized
INFO - 2023-06-01 07:19:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:15 --> URI Class Initialized
INFO - 2023-06-01 07:19:15 --> Router Class Initialized
INFO - 2023-06-01 07:19:15 --> Output Class Initialized
INFO - 2023-06-01 07:19:15 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:15 --> Input Class Initialized
INFO - 2023-06-01 07:19:15 --> Language Class Initialized
INFO - 2023-06-01 07:19:15 --> Loader Class Initialized
INFO - 2023-06-01 07:19:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:15 --> Total execution time: 0.4766
INFO - 2023-06-01 07:19:33 --> Config Class Initialized
INFO - 2023-06-01 07:19:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:33 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:33 --> URI Class Initialized
INFO - 2023-06-01 07:19:33 --> Router Class Initialized
INFO - 2023-06-01 07:19:33 --> Output Class Initialized
INFO - 2023-06-01 07:19:33 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:33 --> Input Class Initialized
INFO - 2023-06-01 07:19:33 --> Language Class Initialized
INFO - 2023-06-01 07:19:33 --> Loader Class Initialized
INFO - 2023-06-01 07:19:33 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:33 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:33 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:33 --> Total execution time: 0.1790
INFO - 2023-06-01 07:19:33 --> Config Class Initialized
INFO - 2023-06-01 07:19:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:33 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:33 --> URI Class Initialized
INFO - 2023-06-01 07:19:33 --> Router Class Initialized
INFO - 2023-06-01 07:19:33 --> Output Class Initialized
INFO - 2023-06-01 07:19:33 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:33 --> Input Class Initialized
INFO - 2023-06-01 07:19:33 --> Language Class Initialized
INFO - 2023-06-01 07:19:33 --> Loader Class Initialized
INFO - 2023-06-01 07:19:33 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:33 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:33 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:33 --> Total execution time: 0.1719
INFO - 2023-06-01 07:19:33 --> Config Class Initialized
INFO - 2023-06-01 07:19:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:33 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:33 --> URI Class Initialized
INFO - 2023-06-01 07:19:33 --> Router Class Initialized
INFO - 2023-06-01 07:19:33 --> Output Class Initialized
INFO - 2023-06-01 07:19:33 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:33 --> Input Class Initialized
INFO - 2023-06-01 07:19:33 --> Language Class Initialized
INFO - 2023-06-01 07:19:33 --> Loader Class Initialized
INFO - 2023-06-01 07:19:33 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:33 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:33 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:33 --> Total execution time: 0.2203
INFO - 2023-06-01 07:19:33 --> Config Class Initialized
INFO - 2023-06-01 07:19:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:33 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:33 --> URI Class Initialized
INFO - 2023-06-01 07:19:33 --> Router Class Initialized
INFO - 2023-06-01 07:19:33 --> Output Class Initialized
INFO - 2023-06-01 07:19:33 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:33 --> Input Class Initialized
INFO - 2023-06-01 07:19:33 --> Language Class Initialized
INFO - 2023-06-01 07:19:33 --> Loader Class Initialized
INFO - 2023-06-01 07:19:33 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:34 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:34 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:34 --> Total execution time: 0.2712
INFO - 2023-06-01 07:19:38 --> Config Class Initialized
INFO - 2023-06-01 07:19:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:38 --> URI Class Initialized
INFO - 2023-06-01 07:19:38 --> Router Class Initialized
INFO - 2023-06-01 07:19:38 --> Output Class Initialized
INFO - 2023-06-01 07:19:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:38 --> Input Class Initialized
INFO - 2023-06-01 07:19:38 --> Language Class Initialized
INFO - 2023-06-01 07:19:38 --> Loader Class Initialized
INFO - 2023-06-01 07:19:38 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:38 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:38 --> Total execution time: 0.1680
INFO - 2023-06-01 07:19:38 --> Config Class Initialized
INFO - 2023-06-01 07:19:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:38 --> URI Class Initialized
INFO - 2023-06-01 07:19:38 --> Router Class Initialized
INFO - 2023-06-01 07:19:38 --> Output Class Initialized
INFO - 2023-06-01 07:19:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:38 --> Input Class Initialized
INFO - 2023-06-01 07:19:38 --> Language Class Initialized
INFO - 2023-06-01 07:19:38 --> Loader Class Initialized
INFO - 2023-06-01 07:19:38 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:38 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:38 --> Total execution time: 0.1886
INFO - 2023-06-01 07:19:38 --> Config Class Initialized
INFO - 2023-06-01 07:19:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:38 --> URI Class Initialized
INFO - 2023-06-01 07:19:38 --> Router Class Initialized
INFO - 2023-06-01 07:19:38 --> Output Class Initialized
INFO - 2023-06-01 07:19:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:38 --> Input Class Initialized
INFO - 2023-06-01 07:19:38 --> Language Class Initialized
INFO - 2023-06-01 07:19:38 --> Loader Class Initialized
INFO - 2023-06-01 07:19:38 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:38 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:38 --> Total execution time: 0.2003
INFO - 2023-06-01 07:19:38 --> Config Class Initialized
INFO - 2023-06-01 07:19:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:38 --> URI Class Initialized
INFO - 2023-06-01 07:19:38 --> Router Class Initialized
INFO - 2023-06-01 07:19:38 --> Output Class Initialized
INFO - 2023-06-01 07:19:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:38 --> Input Class Initialized
INFO - 2023-06-01 07:19:38 --> Language Class Initialized
INFO - 2023-06-01 07:19:38 --> Loader Class Initialized
INFO - 2023-06-01 07:19:38 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:39 --> Total execution time: 0.1954
INFO - 2023-06-01 07:19:47 --> Config Class Initialized
INFO - 2023-06-01 07:19:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:47 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:47 --> URI Class Initialized
INFO - 2023-06-01 07:19:47 --> Router Class Initialized
INFO - 2023-06-01 07:19:47 --> Output Class Initialized
INFO - 2023-06-01 07:19:47 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:47 --> Input Class Initialized
INFO - 2023-06-01 07:19:47 --> Language Class Initialized
INFO - 2023-06-01 07:19:47 --> Loader Class Initialized
INFO - 2023-06-01 07:19:47 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:47 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:48 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:48 --> Total execution time: 0.3861
INFO - 2023-06-01 07:19:48 --> Config Class Initialized
INFO - 2023-06-01 07:19:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:48 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:48 --> URI Class Initialized
INFO - 2023-06-01 07:19:48 --> Router Class Initialized
INFO - 2023-06-01 07:19:48 --> Output Class Initialized
INFO - 2023-06-01 07:19:48 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:48 --> Input Class Initialized
INFO - 2023-06-01 07:19:48 --> Language Class Initialized
INFO - 2023-06-01 07:19:48 --> Loader Class Initialized
INFO - 2023-06-01 07:19:48 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:48 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:48 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:48 --> Total execution time: 0.1691
INFO - 2023-06-01 07:19:48 --> Config Class Initialized
INFO - 2023-06-01 07:19:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:48 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:48 --> URI Class Initialized
INFO - 2023-06-01 07:19:48 --> Router Class Initialized
INFO - 2023-06-01 07:19:48 --> Output Class Initialized
INFO - 2023-06-01 07:19:48 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:48 --> Input Class Initialized
INFO - 2023-06-01 07:19:48 --> Language Class Initialized
INFO - 2023-06-01 07:19:48 --> Loader Class Initialized
INFO - 2023-06-01 07:19:48 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:48 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:48 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:48 --> Total execution time: 0.1746
INFO - 2023-06-01 07:19:48 --> Config Class Initialized
INFO - 2023-06-01 07:19:48 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:19:48 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:19:48 --> Utf8 Class Initialized
INFO - 2023-06-01 07:19:48 --> URI Class Initialized
INFO - 2023-06-01 07:19:48 --> Router Class Initialized
INFO - 2023-06-01 07:19:48 --> Output Class Initialized
INFO - 2023-06-01 07:19:48 --> Security Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:19:48 --> Input Class Initialized
INFO - 2023-06-01 07:19:48 --> Language Class Initialized
INFO - 2023-06-01 07:19:48 --> Loader Class Initialized
INFO - 2023-06-01 07:19:48 --> Controller Class Initialized
DEBUG - 2023-06-01 07:19:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:19:48 --> Database Driver Class Initialized
INFO - 2023-06-01 07:19:48 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:19:48 --> Final output sent to browser
DEBUG - 2023-06-01 07:19:48 --> Total execution time: 0.2410
INFO - 2023-06-01 07:20:00 --> Config Class Initialized
INFO - 2023-06-01 07:20:00 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:00 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:00 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:00 --> URI Class Initialized
INFO - 2023-06-01 07:20:01 --> Router Class Initialized
INFO - 2023-06-01 07:20:01 --> Output Class Initialized
INFO - 2023-06-01 07:20:01 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:01 --> Input Class Initialized
INFO - 2023-06-01 07:20:01 --> Language Class Initialized
INFO - 2023-06-01 07:20:01 --> Loader Class Initialized
INFO - 2023-06-01 07:20:01 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:01 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:01 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:01 --> Total execution time: 0.3733
INFO - 2023-06-01 07:20:01 --> Config Class Initialized
INFO - 2023-06-01 07:20:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:01 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:01 --> URI Class Initialized
INFO - 2023-06-01 07:20:01 --> Router Class Initialized
INFO - 2023-06-01 07:20:01 --> Output Class Initialized
INFO - 2023-06-01 07:20:01 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:01 --> Input Class Initialized
INFO - 2023-06-01 07:20:01 --> Language Class Initialized
INFO - 2023-06-01 07:20:01 --> Loader Class Initialized
INFO - 2023-06-01 07:20:01 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:01 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:01 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:01 --> Total execution time: 0.1847
INFO - 2023-06-01 07:20:01 --> Config Class Initialized
INFO - 2023-06-01 07:20:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:01 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:01 --> URI Class Initialized
INFO - 2023-06-01 07:20:01 --> Router Class Initialized
INFO - 2023-06-01 07:20:01 --> Output Class Initialized
INFO - 2023-06-01 07:20:01 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:01 --> Input Class Initialized
INFO - 2023-06-01 07:20:01 --> Language Class Initialized
INFO - 2023-06-01 07:20:01 --> Loader Class Initialized
INFO - 2023-06-01 07:20:01 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:01 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:01 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:01 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:02 --> Total execution time: 0.4200
INFO - 2023-06-01 07:20:02 --> Config Class Initialized
INFO - 2023-06-01 07:20:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:02 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:02 --> URI Class Initialized
INFO - 2023-06-01 07:20:02 --> Router Class Initialized
INFO - 2023-06-01 07:20:02 --> Output Class Initialized
INFO - 2023-06-01 07:20:02 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:02 --> Input Class Initialized
INFO - 2023-06-01 07:20:02 --> Language Class Initialized
INFO - 2023-06-01 07:20:02 --> Loader Class Initialized
INFO - 2023-06-01 07:20:02 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:02 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:02 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:02 --> Total execution time: 0.2009
INFO - 2023-06-01 07:20:14 --> Config Class Initialized
INFO - 2023-06-01 07:20:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:14 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:14 --> URI Class Initialized
INFO - 2023-06-01 07:20:14 --> Router Class Initialized
INFO - 2023-06-01 07:20:14 --> Output Class Initialized
INFO - 2023-06-01 07:20:14 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:14 --> Input Class Initialized
INFO - 2023-06-01 07:20:14 --> Language Class Initialized
INFO - 2023-06-01 07:20:14 --> Loader Class Initialized
INFO - 2023-06-01 07:20:14 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:14 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:14 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:14 --> Total execution time: 0.1569
INFO - 2023-06-01 07:20:14 --> Config Class Initialized
INFO - 2023-06-01 07:20:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:14 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:14 --> URI Class Initialized
INFO - 2023-06-01 07:20:14 --> Router Class Initialized
INFO - 2023-06-01 07:20:14 --> Output Class Initialized
INFO - 2023-06-01 07:20:14 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:14 --> Input Class Initialized
INFO - 2023-06-01 07:20:14 --> Language Class Initialized
INFO - 2023-06-01 07:20:14 --> Loader Class Initialized
INFO - 2023-06-01 07:20:14 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:14 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:14 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:14 --> Total execution time: 0.1686
INFO - 2023-06-01 07:20:14 --> Config Class Initialized
INFO - 2023-06-01 07:20:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:14 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:14 --> URI Class Initialized
INFO - 2023-06-01 07:20:14 --> Router Class Initialized
INFO - 2023-06-01 07:20:14 --> Output Class Initialized
INFO - 2023-06-01 07:20:14 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:14 --> Input Class Initialized
INFO - 2023-06-01 07:20:14 --> Language Class Initialized
INFO - 2023-06-01 07:20:14 --> Loader Class Initialized
INFO - 2023-06-01 07:20:14 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:14 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:15 --> Total execution time: 0.1941
INFO - 2023-06-01 07:20:15 --> Config Class Initialized
INFO - 2023-06-01 07:20:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:15 --> URI Class Initialized
INFO - 2023-06-01 07:20:15 --> Router Class Initialized
INFO - 2023-06-01 07:20:15 --> Output Class Initialized
INFO - 2023-06-01 07:20:15 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:15 --> Input Class Initialized
INFO - 2023-06-01 07:20:15 --> Language Class Initialized
INFO - 2023-06-01 07:20:15 --> Loader Class Initialized
INFO - 2023-06-01 07:20:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:15 --> Total execution time: 0.4156
INFO - 2023-06-01 07:20:27 --> Config Class Initialized
INFO - 2023-06-01 07:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:27 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:27 --> URI Class Initialized
INFO - 2023-06-01 07:20:27 --> Router Class Initialized
INFO - 2023-06-01 07:20:27 --> Output Class Initialized
INFO - 2023-06-01 07:20:27 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:27 --> Input Class Initialized
INFO - 2023-06-01 07:20:27 --> Language Class Initialized
INFO - 2023-06-01 07:20:27 --> Loader Class Initialized
INFO - 2023-06-01 07:20:27 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:27 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:27 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:27 --> Total execution time: 0.1825
INFO - 2023-06-01 07:20:27 --> Config Class Initialized
INFO - 2023-06-01 07:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:27 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:27 --> URI Class Initialized
INFO - 2023-06-01 07:20:27 --> Router Class Initialized
INFO - 2023-06-01 07:20:27 --> Output Class Initialized
INFO - 2023-06-01 07:20:27 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:27 --> Input Class Initialized
INFO - 2023-06-01 07:20:27 --> Language Class Initialized
INFO - 2023-06-01 07:20:27 --> Loader Class Initialized
INFO - 2023-06-01 07:20:27 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:27 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:27 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:27 --> Total execution time: 0.1787
INFO - 2023-06-01 07:20:27 --> Config Class Initialized
INFO - 2023-06-01 07:20:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:27 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:27 --> URI Class Initialized
INFO - 2023-06-01 07:20:27 --> Router Class Initialized
INFO - 2023-06-01 07:20:27 --> Output Class Initialized
INFO - 2023-06-01 07:20:27 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:27 --> Input Class Initialized
INFO - 2023-06-01 07:20:27 --> Language Class Initialized
INFO - 2023-06-01 07:20:28 --> Loader Class Initialized
INFO - 2023-06-01 07:20:28 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:28 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:28 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:28 --> Total execution time: 0.1951
INFO - 2023-06-01 07:20:28 --> Config Class Initialized
INFO - 2023-06-01 07:20:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:28 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:28 --> URI Class Initialized
INFO - 2023-06-01 07:20:28 --> Router Class Initialized
INFO - 2023-06-01 07:20:28 --> Output Class Initialized
INFO - 2023-06-01 07:20:28 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:28 --> Input Class Initialized
INFO - 2023-06-01 07:20:28 --> Language Class Initialized
INFO - 2023-06-01 07:20:28 --> Loader Class Initialized
INFO - 2023-06-01 07:20:28 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:28 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:28 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:28 --> Total execution time: 0.2317
INFO - 2023-06-01 07:20:38 --> Config Class Initialized
INFO - 2023-06-01 07:20:38 --> Config Class Initialized
INFO - 2023-06-01 07:20:38 --> Config Class Initialized
INFO - 2023-06-01 07:20:38 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:38 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:38 --> URI Class Initialized
INFO - 2023-06-01 07:20:38 --> URI Class Initialized
INFO - 2023-06-01 07:20:38 --> URI Class Initialized
INFO - 2023-06-01 07:20:38 --> Router Class Initialized
INFO - 2023-06-01 07:20:38 --> Router Class Initialized
INFO - 2023-06-01 07:20:38 --> Router Class Initialized
INFO - 2023-06-01 07:20:38 --> Output Class Initialized
INFO - 2023-06-01 07:20:38 --> Output Class Initialized
INFO - 2023-06-01 07:20:38 --> Output Class Initialized
INFO - 2023-06-01 07:20:38 --> Security Class Initialized
INFO - 2023-06-01 07:20:38 --> Security Class Initialized
INFO - 2023-06-01 07:20:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:38 --> Input Class Initialized
INFO - 2023-06-01 07:20:38 --> Input Class Initialized
INFO - 2023-06-01 07:20:38 --> Input Class Initialized
INFO - 2023-06-01 07:20:38 --> Language Class Initialized
INFO - 2023-06-01 07:20:38 --> Language Class Initialized
INFO - 2023-06-01 07:20:38 --> Language Class Initialized
INFO - 2023-06-01 07:20:38 --> Loader Class Initialized
INFO - 2023-06-01 07:20:38 --> Loader Class Initialized
INFO - 2023-06-01 07:20:38 --> Controller Class Initialized
INFO - 2023-06-01 07:20:38 --> Controller Class Initialized
INFO - 2023-06-01 07:20:38 --> Loader Class Initialized
DEBUG - 2023-06-01 07:20:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:38 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:38 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:38 --> Final output sent to browser
INFO - 2023-06-01 07:20:38 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:38 --> Total execution time: 0.1794
DEBUG - 2023-06-01 07:20:38 --> Total execution time: 0.1802
INFO - 2023-06-01 07:20:38 --> Config Class Initialized
INFO - 2023-06-01 07:20:38 --> Config Class Initialized
INFO - 2023-06-01 07:20:38 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:38 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:38 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:39 --> Total execution time: 0.2374
DEBUG - 2023-06-01 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:39 --> URI Class Initialized
INFO - 2023-06-01 07:20:39 --> URI Class Initialized
INFO - 2023-06-01 07:20:39 --> Router Class Initialized
INFO - 2023-06-01 07:20:39 --> Router Class Initialized
INFO - 2023-06-01 07:20:39 --> Output Class Initialized
INFO - 2023-06-01 07:20:39 --> Output Class Initialized
INFO - 2023-06-01 07:20:39 --> Security Class Initialized
INFO - 2023-06-01 07:20:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:39 --> Input Class Initialized
INFO - 2023-06-01 07:20:39 --> Input Class Initialized
INFO - 2023-06-01 07:20:39 --> Language Class Initialized
INFO - 2023-06-01 07:20:39 --> Language Class Initialized
INFO - 2023-06-01 07:20:39 --> Config Class Initialized
INFO - 2023-06-01 07:20:39 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:39 --> Loader Class Initialized
INFO - 2023-06-01 07:20:39 --> Loader Class Initialized
INFO - 2023-06-01 07:20:39 --> Controller Class Initialized
INFO - 2023-06-01 07:20:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:39 --> URI Class Initialized
INFO - 2023-06-01 07:20:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:39 --> Router Class Initialized
INFO - 2023-06-01 07:20:39 --> Output Class Initialized
INFO - 2023-06-01 07:20:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:39 --> Input Class Initialized
INFO - 2023-06-01 07:20:39 --> Language Class Initialized
INFO - 2023-06-01 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:39 --> Total execution time: 0.2474
INFO - 2023-06-01 07:20:39 --> Loader Class Initialized
INFO - 2023-06-01 07:20:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:39 --> Total execution time: 0.2591
INFO - 2023-06-01 07:20:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:39 --> Config Class Initialized
INFO - 2023-06-01 07:20:39 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:39 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:39 --> Total execution time: 0.2763
INFO - 2023-06-01 07:20:39 --> URI Class Initialized
INFO - 2023-06-01 07:20:39 --> Router Class Initialized
INFO - 2023-06-01 07:20:39 --> Output Class Initialized
INFO - 2023-06-01 07:20:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:39 --> Input Class Initialized
INFO - 2023-06-01 07:20:39 --> Language Class Initialized
INFO - 2023-06-01 07:20:39 --> Loader Class Initialized
INFO - 2023-06-01 07:20:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:39 --> Config Class Initialized
INFO - 2023-06-01 07:20:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:39 --> URI Class Initialized
INFO - 2023-06-01 07:20:39 --> Router Class Initialized
INFO - 2023-06-01 07:20:39 --> Output Class Initialized
INFO - 2023-06-01 07:20:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:39 --> Input Class Initialized
INFO - 2023-06-01 07:20:39 --> Language Class Initialized
INFO - 2023-06-01 07:20:39 --> Loader Class Initialized
INFO - 2023-06-01 07:20:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.2601
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.2602
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.2966
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Router Class Initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
INFO - 2023-06-01 07:20:44 --> Output Class Initialized
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
INFO - 2023-06-01 07:20:44 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:44 --> Input Class Initialized
INFO - 2023-06-01 07:20:44 --> Language Class Initialized
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Loader Class Initialized
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.2544
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.2557
INFO - 2023-06-01 07:20:44 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:44 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:44 --> Config Class Initialized
INFO - 2023-06-01 07:20:44 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:44 --> Hooks Class Initialized
INFO - 2023-06-01 07:20:44 --> Final output sent to browser
DEBUG - 2023-06-01 07:20:44 --> Total execution time: 0.3013
DEBUG - 2023-06-01 07:20:44 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:44 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:44 --> URI Class Initialized
INFO - 2023-06-01 07:20:45 --> Router Class Initialized
INFO - 2023-06-01 07:20:45 --> Output Class Initialized
INFO - 2023-06-01 07:20:45 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:45 --> Input Class Initialized
INFO - 2023-06-01 07:20:45 --> Language Class Initialized
INFO - 2023-06-01 07:20:45 --> Loader Class Initialized
INFO - 2023-06-01 07:20:45 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:45 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:20:45 --> Config Class Initialized
INFO - 2023-06-01 07:20:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:20:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:20:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:20:45 --> URI Class Initialized
INFO - 2023-06-01 07:20:45 --> Router Class Initialized
INFO - 2023-06-01 07:20:45 --> Output Class Initialized
INFO - 2023-06-01 07:20:45 --> Security Class Initialized
DEBUG - 2023-06-01 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:20:45 --> Input Class Initialized
INFO - 2023-06-01 07:20:45 --> Language Class Initialized
INFO - 2023-06-01 07:20:45 --> Loader Class Initialized
INFO - 2023-06-01 07:20:45 --> Controller Class Initialized
DEBUG - 2023-06-01 07:20:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:20:45 --> Database Driver Class Initialized
INFO - 2023-06-01 07:20:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:15 --> Final output sent to browser
INFO - 2023-06-01 07:22:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:22:15 --> Total execution time: 0.3688
DEBUG - 2023-06-01 07:22:15 --> Total execution time: 0.3676
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:22:15 --> Final output sent to browser
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Total execution time: 0.4920
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:15 --> Router Class Initialized
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:15 --> Output Class Initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:15 --> Security Class Initialized
INFO - 2023-06-01 07:22:15 --> Final output sent to browser
INFO - 2023-06-01 07:22:15 --> Final output sent to browser
DEBUG - 2023-06-01 07:22:15 --> Total execution time: 0.3132
DEBUG - 2023-06-01 07:22:15 --> Total execution time: 0.3148
DEBUG - 2023-06-01 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:22:15 --> Input Class Initialized
INFO - 2023-06-01 07:22:15 --> Language Class Initialized
INFO - 2023-06-01 07:22:15 --> Loader Class Initialized
INFO - 2023-06-01 07:22:15 --> Controller Class Initialized
DEBUG - 2023-06-01 07:22:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:15 --> Config Class Initialized
INFO - 2023-06-01 07:22:15 --> Hooks Class Initialized
INFO - 2023-06-01 07:22:15 --> Database Driver Class Initialized
DEBUG - 2023-06-01 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:22:15 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:15 --> URI Class Initialized
INFO - 2023-06-01 07:22:16 --> Router Class Initialized
INFO - 2023-06-01 07:22:16 --> Final output sent to browser
DEBUG - 2023-06-01 07:22:16 --> Total execution time: 0.3972
INFO - 2023-06-01 07:22:16 --> Output Class Initialized
INFO - 2023-06-01 07:22:16 --> Security Class Initialized
DEBUG - 2023-06-01 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:22:16 --> Input Class Initialized
INFO - 2023-06-01 07:22:16 --> Language Class Initialized
INFO - 2023-06-01 07:22:16 --> Loader Class Initialized
INFO - 2023-06-01 07:22:16 --> Controller Class Initialized
DEBUG - 2023-06-01 07:22:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:16 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:22:16 --> Config Class Initialized
INFO - 2023-06-01 07:22:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:22:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:22:16 --> Utf8 Class Initialized
INFO - 2023-06-01 07:22:16 --> URI Class Initialized
INFO - 2023-06-01 07:22:16 --> Router Class Initialized
INFO - 2023-06-01 07:22:16 --> Output Class Initialized
INFO - 2023-06-01 07:22:16 --> Security Class Initialized
DEBUG - 2023-06-01 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:22:16 --> Input Class Initialized
INFO - 2023-06-01 07:22:16 --> Language Class Initialized
INFO - 2023-06-01 07:22:16 --> Loader Class Initialized
INFO - 2023-06-01 07:22:16 --> Controller Class Initialized
DEBUG - 2023-06-01 07:22:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:22:16 --> Database Driver Class Initialized
INFO - 2023-06-01 07:22:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:50 --> Config Class Initialized
INFO - 2023-06-01 07:38:50 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:50 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:50 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:50 --> URI Class Initialized
INFO - 2023-06-01 07:38:50 --> Router Class Initialized
INFO - 2023-06-01 07:38:50 --> Output Class Initialized
INFO - 2023-06-01 07:38:50 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:50 --> Input Class Initialized
INFO - 2023-06-01 07:38:50 --> Language Class Initialized
INFO - 2023-06-01 07:38:50 --> Loader Class Initialized
INFO - 2023-06-01 07:38:50 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:50 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:50 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:50 --> Final output sent to browser
DEBUG - 2023-06-01 07:38:51 --> Total execution time: 0.2594
INFO - 2023-06-01 07:38:51 --> Config Class Initialized
INFO - 2023-06-01 07:38:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:51 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:51 --> URI Class Initialized
INFO - 2023-06-01 07:38:51 --> Router Class Initialized
INFO - 2023-06-01 07:38:51 --> Output Class Initialized
INFO - 2023-06-01 07:38:51 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:51 --> Input Class Initialized
INFO - 2023-06-01 07:38:51 --> Language Class Initialized
INFO - 2023-06-01 07:38:51 --> Loader Class Initialized
INFO - 2023-06-01 07:38:51 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:51 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:51 --> Final output sent to browser
DEBUG - 2023-06-01 07:38:51 --> Total execution time: 0.3741
INFO - 2023-06-01 07:38:53 --> Config Class Initialized
INFO - 2023-06-01 07:38:53 --> Config Class Initialized
INFO - 2023-06-01 07:38:53 --> Config Class Initialized
INFO - 2023-06-01 07:38:53 --> Hooks Class Initialized
INFO - 2023-06-01 07:38:53 --> Hooks Class Initialized
INFO - 2023-06-01 07:38:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:38:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:53 --> URI Class Initialized
INFO - 2023-06-01 07:38:53 --> URI Class Initialized
INFO - 2023-06-01 07:38:53 --> URI Class Initialized
INFO - 2023-06-01 07:38:53 --> Router Class Initialized
INFO - 2023-06-01 07:38:53 --> Router Class Initialized
INFO - 2023-06-01 07:38:53 --> Router Class Initialized
INFO - 2023-06-01 07:38:53 --> Output Class Initialized
INFO - 2023-06-01 07:38:53 --> Output Class Initialized
INFO - 2023-06-01 07:38:53 --> Output Class Initialized
INFO - 2023-06-01 07:38:53 --> Security Class Initialized
INFO - 2023-06-01 07:38:53 --> Security Class Initialized
INFO - 2023-06-01 07:38:53 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:53 --> Input Class Initialized
INFO - 2023-06-01 07:38:53 --> Input Class Initialized
INFO - 2023-06-01 07:38:53 --> Input Class Initialized
INFO - 2023-06-01 07:38:53 --> Language Class Initialized
INFO - 2023-06-01 07:38:53 --> Language Class Initialized
INFO - 2023-06-01 07:38:53 --> Language Class Initialized
INFO - 2023-06-01 07:38:53 --> Loader Class Initialized
INFO - 2023-06-01 07:38:53 --> Loader Class Initialized
INFO - 2023-06-01 07:38:53 --> Controller Class Initialized
INFO - 2023-06-01 07:38:53 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:53 --> Loader Class Initialized
INFO - 2023-06-01 07:38:53 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:53 --> Final output sent to browser
INFO - 2023-06-01 07:38:53 --> Final output sent to browser
DEBUG - 2023-06-01 07:38:53 --> Total execution time: 0.1897
DEBUG - 2023-06-01 07:38:53 --> Total execution time: 0.1891
INFO - 2023-06-01 07:38:53 --> Final output sent to browser
DEBUG - 2023-06-01 07:38:53 --> Total execution time: 0.2134
INFO - 2023-06-01 07:38:53 --> Config Class Initialized
INFO - 2023-06-01 07:38:53 --> Config Class Initialized
INFO - 2023-06-01 07:38:53 --> Hooks Class Initialized
INFO - 2023-06-01 07:38:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:38:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:53 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:53 --> URI Class Initialized
INFO - 2023-06-01 07:38:53 --> URI Class Initialized
INFO - 2023-06-01 07:38:53 --> Router Class Initialized
INFO - 2023-06-01 07:38:53 --> Router Class Initialized
INFO - 2023-06-01 07:38:53 --> Output Class Initialized
INFO - 2023-06-01 07:38:53 --> Output Class Initialized
INFO - 2023-06-01 07:38:53 --> Security Class Initialized
INFO - 2023-06-01 07:38:53 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:53 --> Input Class Initialized
INFO - 2023-06-01 07:38:53 --> Input Class Initialized
INFO - 2023-06-01 07:38:53 --> Language Class Initialized
INFO - 2023-06-01 07:38:53 --> Language Class Initialized
INFO - 2023-06-01 07:38:53 --> Loader Class Initialized
INFO - 2023-06-01 07:38:53 --> Loader Class Initialized
INFO - 2023-06-01 07:38:53 --> Controller Class Initialized
INFO - 2023-06-01 07:38:53 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:53 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:54 --> Final output sent to browser
INFO - 2023-06-01 07:38:54 --> Final output sent to browser
DEBUG - 2023-06-01 07:38:54 --> Total execution time: 0.1818
DEBUG - 2023-06-01 07:38:54 --> Total execution time: 0.1813
INFO - 2023-06-01 07:38:54 --> Config Class Initialized
INFO - 2023-06-01 07:38:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:54 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:54 --> URI Class Initialized
INFO - 2023-06-01 07:38:54 --> Router Class Initialized
INFO - 2023-06-01 07:38:54 --> Output Class Initialized
INFO - 2023-06-01 07:38:54 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:54 --> Input Class Initialized
INFO - 2023-06-01 07:38:54 --> Language Class Initialized
INFO - 2023-06-01 07:38:54 --> Loader Class Initialized
INFO - 2023-06-01 07:38:54 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:54 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:54 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:38:54 --> Config Class Initialized
INFO - 2023-06-01 07:38:54 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:38:54 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:38:54 --> Utf8 Class Initialized
INFO - 2023-06-01 07:38:54 --> URI Class Initialized
INFO - 2023-06-01 07:38:54 --> Router Class Initialized
INFO - 2023-06-01 07:38:55 --> Output Class Initialized
INFO - 2023-06-01 07:38:55 --> Security Class Initialized
DEBUG - 2023-06-01 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:38:55 --> Input Class Initialized
INFO - 2023-06-01 07:38:55 --> Language Class Initialized
INFO - 2023-06-01 07:38:55 --> Loader Class Initialized
INFO - 2023-06-01 07:38:55 --> Controller Class Initialized
DEBUG - 2023-06-01 07:38:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:38:55 --> Database Driver Class Initialized
INFO - 2023-06-01 07:38:55 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:39:04 --> Config Class Initialized
INFO - 2023-06-01 07:39:04 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:39:04 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:39:04 --> Utf8 Class Initialized
INFO - 2023-06-01 07:39:04 --> URI Class Initialized
INFO - 2023-06-01 07:39:04 --> Router Class Initialized
INFO - 2023-06-01 07:39:04 --> Output Class Initialized
INFO - 2023-06-01 07:39:04 --> Security Class Initialized
DEBUG - 2023-06-01 07:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:39:04 --> Input Class Initialized
INFO - 2023-06-01 07:39:04 --> Language Class Initialized
INFO - 2023-06-01 07:39:04 --> Loader Class Initialized
INFO - 2023-06-01 07:39:04 --> Controller Class Initialized
DEBUG - 2023-06-01 07:39:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:39:04 --> Database Driver Class Initialized
INFO - 2023-06-01 07:39:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:39:05 --> Config Class Initialized
INFO - 2023-06-01 07:39:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:39:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:39:05 --> Utf8 Class Initialized
INFO - 2023-06-01 07:39:05 --> URI Class Initialized
INFO - 2023-06-01 07:39:05 --> Router Class Initialized
INFO - 2023-06-01 07:39:05 --> Output Class Initialized
INFO - 2023-06-01 07:39:05 --> Security Class Initialized
DEBUG - 2023-06-01 07:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:39:05 --> Input Class Initialized
INFO - 2023-06-01 07:39:05 --> Language Class Initialized
INFO - 2023-06-01 07:39:05 --> Loader Class Initialized
INFO - 2023-06-01 07:39:05 --> Controller Class Initialized
DEBUG - 2023-06-01 07:39:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:39:05 --> Database Driver Class Initialized
INFO - 2023-06-01 07:39:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:38 --> Config Class Initialized
INFO - 2023-06-01 07:42:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:42:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:38 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:38 --> URI Class Initialized
INFO - 2023-06-01 07:42:38 --> Router Class Initialized
INFO - 2023-06-01 07:42:38 --> Output Class Initialized
INFO - 2023-06-01 07:42:38 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:38 --> Input Class Initialized
INFO - 2023-06-01 07:42:38 --> Language Class Initialized
INFO - 2023-06-01 07:42:39 --> Loader Class Initialized
INFO - 2023-06-01 07:42:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:39 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:39 --> Total execution time: 0.8799
INFO - 2023-06-01 07:42:39 --> Config Class Initialized
INFO - 2023-06-01 07:42:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:42:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:39 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:39 --> URI Class Initialized
INFO - 2023-06-01 07:42:39 --> Router Class Initialized
INFO - 2023-06-01 07:42:39 --> Output Class Initialized
INFO - 2023-06-01 07:42:39 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:39 --> Input Class Initialized
INFO - 2023-06-01 07:42:39 --> Language Class Initialized
INFO - 2023-06-01 07:42:39 --> Loader Class Initialized
INFO - 2023-06-01 07:42:39 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:39 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:40 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:40 --> Total execution time: 0.2397
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
INFO - 2023-06-01 07:42:45 --> Loader Class Initialized
INFO - 2023-06-01 07:42:45 --> Loader Class Initialized
INFO - 2023-06-01 07:42:45 --> Controller Class Initialized
INFO - 2023-06-01 07:42:45 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:45 --> Loader Class Initialized
INFO - 2023-06-01 07:42:45 --> Controller Class Initialized
INFO - 2023-06-01 07:42:45 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:45 --> Database Driver Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:45 --> Final output sent to browser
INFO - 2023-06-01 07:42:45 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:45 --> Total execution time: 0.1791
DEBUG - 2023-06-01 07:42:45 --> Total execution time: 0.1795
INFO - 2023-06-01 07:42:45 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:45 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:45 --> Total execution time: 0.2343
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Config Class Initialized
INFO - 2023-06-01 07:42:45 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
DEBUG - 2023-06-01 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:45 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:45 --> Loader Class Initialized
INFO - 2023-06-01 07:42:45 --> URI Class Initialized
INFO - 2023-06-01 07:42:45 --> Loader Class Initialized
INFO - 2023-06-01 07:42:45 --> Controller Class Initialized
INFO - 2023-06-01 07:42:45 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:45 --> Router Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:45 --> Output Class Initialized
INFO - 2023-06-01 07:42:45 --> Security Class Initialized
INFO - 2023-06-01 07:42:45 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:45 --> Database Driver Class Initialized
DEBUG - 2023-06-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:45 --> Input Class Initialized
INFO - 2023-06-01 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:45 --> Language Class Initialized
INFO - 2023-06-01 07:42:45 --> Final output sent to browser
INFO - 2023-06-01 07:42:45 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:45 --> Total execution time: 0.2011
DEBUG - 2023-06-01 07:42:45 --> Total execution time: 0.2005
INFO - 2023-06-01 07:42:46 --> Loader Class Initialized
INFO - 2023-06-01 07:42:46 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:46 --> Config Class Initialized
INFO - 2023-06-01 07:42:46 --> Hooks Class Initialized
INFO - 2023-06-01 07:42:46 --> Database Driver Class Initialized
DEBUG - 2023-06-01 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:46 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:46 --> URI Class Initialized
INFO - 2023-06-01 07:42:46 --> Router Class Initialized
INFO - 2023-06-01 07:42:46 --> Final output sent to browser
DEBUG - 2023-06-01 07:42:46 --> Total execution time: 0.2876
INFO - 2023-06-01 07:42:46 --> Output Class Initialized
INFO - 2023-06-01 07:42:46 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:46 --> Input Class Initialized
INFO - 2023-06-01 07:42:46 --> Language Class Initialized
INFO - 2023-06-01 07:42:46 --> Loader Class Initialized
INFO - 2023-06-01 07:42:46 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:46 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:42:46 --> Config Class Initialized
INFO - 2023-06-01 07:42:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:42:46 --> Utf8 Class Initialized
INFO - 2023-06-01 07:42:46 --> URI Class Initialized
INFO - 2023-06-01 07:42:46 --> Router Class Initialized
INFO - 2023-06-01 07:42:46 --> Output Class Initialized
INFO - 2023-06-01 07:42:46 --> Security Class Initialized
DEBUG - 2023-06-01 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:42:46 --> Input Class Initialized
INFO - 2023-06-01 07:42:46 --> Language Class Initialized
INFO - 2023-06-01 07:42:46 --> Loader Class Initialized
INFO - 2023-06-01 07:42:46 --> Controller Class Initialized
DEBUG - 2023-06-01 07:42:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:42:46 --> Database Driver Class Initialized
INFO - 2023-06-01 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:09 --> Config Class Initialized
INFO - 2023-06-01 07:59:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:09 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:09 --> URI Class Initialized
INFO - 2023-06-01 07:59:09 --> Router Class Initialized
INFO - 2023-06-01 07:59:09 --> Output Class Initialized
INFO - 2023-06-01 07:59:09 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:09 --> Input Class Initialized
INFO - 2023-06-01 07:59:09 --> Language Class Initialized
INFO - 2023-06-01 07:59:09 --> Loader Class Initialized
INFO - 2023-06-01 07:59:09 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:09 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:09 --> Final output sent to browser
DEBUG - 2023-06-01 07:59:09 --> Total execution time: 0.2288
INFO - 2023-06-01 07:59:09 --> Config Class Initialized
INFO - 2023-06-01 07:59:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:09 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:09 --> URI Class Initialized
INFO - 2023-06-01 07:59:09 --> Router Class Initialized
INFO - 2023-06-01 07:59:09 --> Output Class Initialized
INFO - 2023-06-01 07:59:09 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:09 --> Input Class Initialized
INFO - 2023-06-01 07:59:09 --> Language Class Initialized
INFO - 2023-06-01 07:59:09 --> Loader Class Initialized
INFO - 2023-06-01 07:59:09 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:10 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:10 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:10 --> Final output sent to browser
DEBUG - 2023-06-01 07:59:10 --> Total execution time: 0.4752
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Final output sent to browser
DEBUG - 2023-06-01 07:59:11 --> Total execution time: 0.2447
INFO - 2023-06-01 07:59:11 --> Final output sent to browser
INFO - 2023-06-01 07:59:11 --> Final output sent to browser
DEBUG - 2023-06-01 07:59:11 --> Total execution time: 0.2560
DEBUG - 2023-06-01 07:59:11 --> Total execution time: 0.2552
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Final output sent to browser
INFO - 2023-06-01 07:59:11 --> Final output sent to browser
DEBUG - 2023-06-01 07:59:11 --> Total execution time: 0.1912
DEBUG - 2023-06-01 07:59:11 --> Total execution time: 0.2001
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:11 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:11 --> Input Class Initialized
INFO - 2023-06-01 07:59:11 --> Language Class Initialized
INFO - 2023-06-01 07:59:11 --> Loader Class Initialized
INFO - 2023-06-01 07:59:11 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:11 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:11 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:11 --> Config Class Initialized
INFO - 2023-06-01 07:59:11 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:11 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:11 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:11 --> URI Class Initialized
INFO - 2023-06-01 07:59:11 --> Router Class Initialized
INFO - 2023-06-01 07:59:11 --> Output Class Initialized
INFO - 2023-06-01 07:59:12 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:12 --> Input Class Initialized
INFO - 2023-06-01 07:59:12 --> Language Class Initialized
INFO - 2023-06-01 07:59:12 --> Loader Class Initialized
INFO - 2023-06-01 07:59:12 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:12 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:12 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:34 --> Config Class Initialized
INFO - 2023-06-01 07:59:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:34 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:34 --> URI Class Initialized
INFO - 2023-06-01 07:59:34 --> Router Class Initialized
INFO - 2023-06-01 07:59:34 --> Output Class Initialized
INFO - 2023-06-01 07:59:34 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:34 --> Input Class Initialized
INFO - 2023-06-01 07:59:34 --> Language Class Initialized
INFO - 2023-06-01 07:59:34 --> Loader Class Initialized
INFO - 2023-06-01 07:59:34 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:34 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 07:59:35 --> Config Class Initialized
INFO - 2023-06-01 07:59:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 07:59:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 07:59:35 --> Utf8 Class Initialized
INFO - 2023-06-01 07:59:35 --> URI Class Initialized
INFO - 2023-06-01 07:59:35 --> Router Class Initialized
INFO - 2023-06-01 07:59:35 --> Output Class Initialized
INFO - 2023-06-01 07:59:35 --> Security Class Initialized
DEBUG - 2023-06-01 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 07:59:35 --> Input Class Initialized
INFO - 2023-06-01 07:59:35 --> Language Class Initialized
INFO - 2023-06-01 07:59:35 --> Loader Class Initialized
INFO - 2023-06-01 07:59:35 --> Controller Class Initialized
DEBUG - 2023-06-01 07:59:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 07:59:35 --> Database Driver Class Initialized
INFO - 2023-06-01 07:59:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:56 --> Config Class Initialized
INFO - 2023-06-01 08:37:56 --> Config Class Initialized
INFO - 2023-06-01 08:37:56 --> Config Class Initialized
INFO - 2023-06-01 08:37:56 --> Hooks Class Initialized
INFO - 2023-06-01 08:37:56 --> Hooks Class Initialized
INFO - 2023-06-01 08:37:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:37:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:37:56 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:56 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:56 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:56 --> URI Class Initialized
INFO - 2023-06-01 08:37:56 --> URI Class Initialized
INFO - 2023-06-01 08:37:56 --> URI Class Initialized
INFO - 2023-06-01 08:37:56 --> Router Class Initialized
INFO - 2023-06-01 08:37:56 --> Router Class Initialized
INFO - 2023-06-01 08:37:56 --> Router Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.5809
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
INFO - 2023-06-01 08:37:57 --> Config Class Initialized
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.6276
INFO - 2023-06-01 08:37:57 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.6286
DEBUG - 2023-06-01 08:37:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:37:57 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:57 --> Config Class Initialized
INFO - 2023-06-01 08:37:57 --> URI Class Initialized
INFO - 2023-06-01 08:37:57 --> Config Class Initialized
INFO - 2023-06-01 08:37:57 --> Hooks Class Initialized
INFO - 2023-06-01 08:37:57 --> Hooks Class Initialized
INFO - 2023-06-01 08:37:57 --> Router Class Initialized
DEBUG - 2023-06-01 08:37:57 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:37:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:37:57 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:57 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:57 --> URI Class Initialized
INFO - 2023-06-01 08:37:57 --> URI Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Router Class Initialized
INFO - 2023-06-01 08:37:57 --> Router Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
INFO - 2023-06-01 08:37:57 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.1801
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.1809
INFO - 2023-06-01 08:37:57 --> Final output sent to browser
DEBUG - 2023-06-01 08:37:57 --> Total execution time: 0.2598
INFO - 2023-06-01 08:37:57 --> Config Class Initialized
INFO - 2023-06-01 08:37:57 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:37:57 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:37:57 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:57 --> URI Class Initialized
INFO - 2023-06-01 08:37:57 --> Router Class Initialized
INFO - 2023-06-01 08:37:57 --> Output Class Initialized
INFO - 2023-06-01 08:37:57 --> Security Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:57 --> Input Class Initialized
INFO - 2023-06-01 08:37:57 --> Language Class Initialized
INFO - 2023-06-01 08:37:57 --> Loader Class Initialized
INFO - 2023-06-01 08:37:57 --> Controller Class Initialized
DEBUG - 2023-06-01 08:37:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:37:57 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:37:58 --> Config Class Initialized
INFO - 2023-06-01 08:37:58 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:37:58 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:37:58 --> Utf8 Class Initialized
INFO - 2023-06-01 08:37:58 --> URI Class Initialized
INFO - 2023-06-01 08:37:58 --> Router Class Initialized
INFO - 2023-06-01 08:37:58 --> Output Class Initialized
INFO - 2023-06-01 08:37:58 --> Security Class Initialized
DEBUG - 2023-06-01 08:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:37:58 --> Input Class Initialized
INFO - 2023-06-01 08:37:58 --> Language Class Initialized
INFO - 2023-06-01 08:37:58 --> Loader Class Initialized
INFO - 2023-06-01 08:37:58 --> Controller Class Initialized
DEBUG - 2023-06-01 08:37:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:37:58 --> Database Driver Class Initialized
INFO - 2023-06-01 08:37:58 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:23 --> Config Class Initialized
INFO - 2023-06-01 08:41:23 --> Config Class Initialized
INFO - 2023-06-01 08:41:23 --> Config Class Initialized
INFO - 2023-06-01 08:41:23 --> Hooks Class Initialized
INFO - 2023-06-01 08:41:23 --> Hooks Class Initialized
INFO - 2023-06-01 08:41:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:41:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:41:23 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:23 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:23 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:23 --> URI Class Initialized
INFO - 2023-06-01 08:41:23 --> URI Class Initialized
INFO - 2023-06-01 08:41:23 --> URI Class Initialized
INFO - 2023-06-01 08:41:23 --> Router Class Initialized
INFO - 2023-06-01 08:41:23 --> Router Class Initialized
INFO - 2023-06-01 08:41:23 --> Router Class Initialized
INFO - 2023-06-01 08:41:23 --> Output Class Initialized
INFO - 2023-06-01 08:41:23 --> Output Class Initialized
INFO - 2023-06-01 08:41:23 --> Output Class Initialized
INFO - 2023-06-01 08:41:23 --> Security Class Initialized
INFO - 2023-06-01 08:41:23 --> Security Class Initialized
INFO - 2023-06-01 08:41:23 --> Security Class Initialized
DEBUG - 2023-06-01 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:41:23 --> Input Class Initialized
INFO - 2023-06-01 08:41:23 --> Input Class Initialized
INFO - 2023-06-01 08:41:23 --> Input Class Initialized
INFO - 2023-06-01 08:41:23 --> Language Class Initialized
INFO - 2023-06-01 08:41:23 --> Language Class Initialized
INFO - 2023-06-01 08:41:23 --> Language Class Initialized
INFO - 2023-06-01 08:41:23 --> Loader Class Initialized
INFO - 2023-06-01 08:41:23 --> Loader Class Initialized
INFO - 2023-06-01 08:41:23 --> Controller Class Initialized
INFO - 2023-06-01 08:41:23 --> Controller Class Initialized
DEBUG - 2023-06-01 08:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:41:23 --> Loader Class Initialized
INFO - 2023-06-01 08:41:23 --> Controller Class Initialized
INFO - 2023-06-01 08:41:23 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:23 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.3496
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.3510
INFO - 2023-06-01 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:24 --> Config Class Initialized
INFO - 2023-06-01 08:41:24 --> Config Class Initialized
INFO - 2023-06-01 08:41:24 --> Hooks Class Initialized
INFO - 2023-06-01 08:41:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:41:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:24 --> URI Class Initialized
INFO - 2023-06-01 08:41:24 --> URI Class Initialized
INFO - 2023-06-01 08:41:24 --> Router Class Initialized
INFO - 2023-06-01 08:41:24 --> Router Class Initialized
INFO - 2023-06-01 08:41:24 --> Output Class Initialized
INFO - 2023-06-01 08:41:24 --> Output Class Initialized
INFO - 2023-06-01 08:41:24 --> Security Class Initialized
INFO - 2023-06-01 08:41:24 --> Security Class Initialized
DEBUG - 2023-06-01 08:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:41:24 --> Input Class Initialized
INFO - 2023-06-01 08:41:24 --> Input Class Initialized
INFO - 2023-06-01 08:41:24 --> Language Class Initialized
INFO - 2023-06-01 08:41:24 --> Language Class Initialized
INFO - 2023-06-01 08:41:24 --> Loader Class Initialized
INFO - 2023-06-01 08:41:24 --> Loader Class Initialized
INFO - 2023-06-01 08:41:24 --> Controller Class Initialized
INFO - 2023-06-01 08:41:24 --> Controller Class Initialized
DEBUG - 2023-06-01 08:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.6471
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.2542
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.2550
INFO - 2023-06-01 08:41:24 --> Config Class Initialized
INFO - 2023-06-01 08:41:24 --> Hooks Class Initialized
INFO - 2023-06-01 08:41:24 --> Config Class Initialized
INFO - 2023-06-01 08:41:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:24 --> URI Class Initialized
DEBUG - 2023-06-01 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:24 --> URI Class Initialized
INFO - 2023-06-01 08:41:24 --> Router Class Initialized
INFO - 2023-06-01 08:41:24 --> Output Class Initialized
INFO - 2023-06-01 08:41:24 --> Router Class Initialized
INFO - 2023-06-01 08:41:24 --> Security Class Initialized
INFO - 2023-06-01 08:41:24 --> Output Class Initialized
DEBUG - 2023-06-01 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:41:24 --> Security Class Initialized
INFO - 2023-06-01 08:41:24 --> Input Class Initialized
DEBUG - 2023-06-01 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:41:24 --> Language Class Initialized
INFO - 2023-06-01 08:41:24 --> Input Class Initialized
INFO - 2023-06-01 08:41:24 --> Language Class Initialized
INFO - 2023-06-01 08:41:24 --> Loader Class Initialized
INFO - 2023-06-01 08:41:24 --> Loader Class Initialized
INFO - 2023-06-01 08:41:24 --> Controller Class Initialized
INFO - 2023-06-01 08:41:24 --> Controller Class Initialized
DEBUG - 2023-06-01 08:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:24 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:41:24 --> Final output sent to browser
DEBUG - 2023-06-01 08:41:24 --> Total execution time: 0.4670
INFO - 2023-06-01 08:41:24 --> Config Class Initialized
INFO - 2023-06-01 08:41:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:41:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:41:24 --> Utf8 Class Initialized
INFO - 2023-06-01 08:41:25 --> URI Class Initialized
INFO - 2023-06-01 08:41:25 --> Router Class Initialized
INFO - 2023-06-01 08:41:25 --> Output Class Initialized
INFO - 2023-06-01 08:41:25 --> Security Class Initialized
DEBUG - 2023-06-01 08:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:41:25 --> Input Class Initialized
INFO - 2023-06-01 08:41:25 --> Language Class Initialized
INFO - 2023-06-01 08:41:25 --> Loader Class Initialized
INFO - 2023-06-01 08:41:25 --> Controller Class Initialized
DEBUG - 2023-06-01 08:41:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:41:25 --> Database Driver Class Initialized
INFO - 2023-06-01 08:41:25 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:01 --> Config Class Initialized
INFO - 2023-06-01 08:43:01 --> Config Class Initialized
INFO - 2023-06-01 08:43:01 --> Config Class Initialized
INFO - 2023-06-01 08:43:01 --> Hooks Class Initialized
INFO - 2023-06-01 08:43:01 --> Hooks Class Initialized
INFO - 2023-06-01 08:43:01 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:43:01 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:43:01 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:01 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:01 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:01 --> URI Class Initialized
INFO - 2023-06-01 08:43:01 --> URI Class Initialized
INFO - 2023-06-01 08:43:01 --> URI Class Initialized
INFO - 2023-06-01 08:43:01 --> Router Class Initialized
INFO - 2023-06-01 08:43:01 --> Router Class Initialized
INFO - 2023-06-01 08:43:01 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.2557
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.2549
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.2532
INFO - 2023-06-01 08:43:02 --> Config Class Initialized
INFO - 2023-06-01 08:43:02 --> Config Class Initialized
INFO - 2023-06-01 08:43:02 --> Config Class Initialized
INFO - 2023-06-01 08:43:02 --> Hooks Class Initialized
INFO - 2023-06-01 08:43:02 --> Hooks Class Initialized
INFO - 2023-06-01 08:43:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:43:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:43:02 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:02 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:02 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:02 --> URI Class Initialized
INFO - 2023-06-01 08:43:02 --> URI Class Initialized
INFO - 2023-06-01 08:43:02 --> URI Class Initialized
INFO - 2023-06-01 08:43:02 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.2073
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.2072
INFO - 2023-06-01 08:43:02 --> Config Class Initialized
INFO - 2023-06-01 08:43:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:43:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:43:02 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:02 --> URI Class Initialized
INFO - 2023-06-01 08:43:02 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:43:02 --> Final output sent to browser
DEBUG - 2023-06-01 08:43:02 --> Total execution time: 0.4625
INFO - 2023-06-01 08:43:02 --> Config Class Initialized
INFO - 2023-06-01 08:43:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:43:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:43:02 --> Utf8 Class Initialized
INFO - 2023-06-01 08:43:02 --> URI Class Initialized
INFO - 2023-06-01 08:43:02 --> Router Class Initialized
INFO - 2023-06-01 08:43:02 --> Output Class Initialized
INFO - 2023-06-01 08:43:02 --> Security Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:43:02 --> Input Class Initialized
INFO - 2023-06-01 08:43:02 --> Language Class Initialized
INFO - 2023-06-01 08:43:02 --> Loader Class Initialized
INFO - 2023-06-01 08:43:02 --> Controller Class Initialized
DEBUG - 2023-06-01 08:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:43:02 --> Database Driver Class Initialized
INFO - 2023-06-01 08:43:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.5606
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.6160
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.6154
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:44:46 --> Loader Class Initialized
INFO - 2023-06-01 08:44:46 --> Controller Class Initialized
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.1676
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.1676
INFO - 2023-06-01 08:44:46 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:46 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:46 --> Config Class Initialized
INFO - 2023-06-01 08:44:46 --> Hooks Class Initialized
INFO - 2023-06-01 08:44:46 --> Final output sent to browser
DEBUG - 2023-06-01 08:44:46 --> Total execution time: 0.2897
DEBUG - 2023-06-01 08:44:46 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:44:46 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:46 --> URI Class Initialized
INFO - 2023-06-01 08:44:46 --> Router Class Initialized
INFO - 2023-06-01 08:44:46 --> Output Class Initialized
INFO - 2023-06-01 08:44:46 --> Security Class Initialized
DEBUG - 2023-06-01 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:44:46 --> Input Class Initialized
INFO - 2023-06-01 08:44:46 --> Language Class Initialized
INFO - 2023-06-01 08:44:47 --> Loader Class Initialized
INFO - 2023-06-01 08:44:47 --> Controller Class Initialized
DEBUG - 2023-06-01 08:44:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:44:47 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:44:47 --> Config Class Initialized
INFO - 2023-06-01 08:44:47 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:44:47 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:44:47 --> Utf8 Class Initialized
INFO - 2023-06-01 08:44:47 --> URI Class Initialized
INFO - 2023-06-01 08:44:47 --> Router Class Initialized
INFO - 2023-06-01 08:44:47 --> Output Class Initialized
INFO - 2023-06-01 08:44:47 --> Security Class Initialized
DEBUG - 2023-06-01 08:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:44:47 --> Input Class Initialized
INFO - 2023-06-01 08:44:47 --> Language Class Initialized
INFO - 2023-06-01 08:44:47 --> Loader Class Initialized
INFO - 2023-06-01 08:44:47 --> Controller Class Initialized
DEBUG - 2023-06-01 08:44:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:44:47 --> Database Driver Class Initialized
INFO - 2023-06-01 08:44:47 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.3000
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.2982
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.3887
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.2983
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.2988
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:18 --> Config Class Initialized
INFO - 2023-06-01 08:45:18 --> Hooks Class Initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 08:45:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:45:18 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:18 --> Final output sent to browser
INFO - 2023-06-01 08:45:18 --> URI Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Total execution time: 0.3207
INFO - 2023-06-01 08:45:18 --> Router Class Initialized
INFO - 2023-06-01 08:45:18 --> Output Class Initialized
INFO - 2023-06-01 08:45:18 --> Security Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:18 --> Input Class Initialized
INFO - 2023-06-01 08:45:18 --> Language Class Initialized
INFO - 2023-06-01 08:45:18 --> Loader Class Initialized
INFO - 2023-06-01 08:45:18 --> Controller Class Initialized
DEBUG - 2023-06-01 08:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:18 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:45:19 --> Config Class Initialized
INFO - 2023-06-01 08:45:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:45:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:45:19 --> Utf8 Class Initialized
INFO - 2023-06-01 08:45:19 --> URI Class Initialized
INFO - 2023-06-01 08:45:19 --> Router Class Initialized
INFO - 2023-06-01 08:45:19 --> Output Class Initialized
INFO - 2023-06-01 08:45:19 --> Security Class Initialized
DEBUG - 2023-06-01 08:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:45:19 --> Input Class Initialized
INFO - 2023-06-01 08:45:19 --> Language Class Initialized
INFO - 2023-06-01 08:45:19 --> Loader Class Initialized
INFO - 2023-06-01 08:45:19 --> Controller Class Initialized
DEBUG - 2023-06-01 08:45:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:45:19 --> Database Driver Class Initialized
INFO - 2023-06-01 08:45:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.2676
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.2842
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.3372
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.2867
INFO - 2023-06-01 08:46:32 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.2773
INFO - 2023-06-01 08:46:32 --> Config Class Initialized
INFO - 2023-06-01 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:32 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:32 --> URI Class Initialized
INFO - 2023-06-01 08:46:32 --> Final output sent to browser
DEBUG - 2023-06-01 08:46:32 --> Total execution time: 0.4087
INFO - 2023-06-01 08:46:32 --> Router Class Initialized
INFO - 2023-06-01 08:46:32 --> Output Class Initialized
INFO - 2023-06-01 08:46:32 --> Security Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:32 --> Input Class Initialized
INFO - 2023-06-01 08:46:32 --> Language Class Initialized
INFO - 2023-06-01 08:46:32 --> Loader Class Initialized
INFO - 2023-06-01 08:46:32 --> Controller Class Initialized
DEBUG - 2023-06-01 08:46:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:33 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:46:33 --> Config Class Initialized
INFO - 2023-06-01 08:46:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:46:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:46:33 --> Utf8 Class Initialized
INFO - 2023-06-01 08:46:33 --> URI Class Initialized
INFO - 2023-06-01 08:46:33 --> Router Class Initialized
INFO - 2023-06-01 08:46:33 --> Output Class Initialized
INFO - 2023-06-01 08:46:33 --> Security Class Initialized
DEBUG - 2023-06-01 08:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:46:33 --> Input Class Initialized
INFO - 2023-06-01 08:46:33 --> Language Class Initialized
INFO - 2023-06-01 08:46:33 --> Loader Class Initialized
INFO - 2023-06-01 08:46:33 --> Controller Class Initialized
DEBUG - 2023-06-01 08:46:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:46:33 --> Database Driver Class Initialized
INFO - 2023-06-01 08:46:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.2756
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.2755
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.3322
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.2005
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.2019
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
INFO - 2023-06-01 08:50:16 --> Final output sent to browser
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 08:50:16 --> Total execution time: 0.2923
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:16 --> Language Class Initialized
INFO - 2023-06-01 08:50:16 --> Loader Class Initialized
INFO - 2023-06-01 08:50:16 --> Controller Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:16 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 08:50:16 --> Config Class Initialized
INFO - 2023-06-01 08:50:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 08:50:16 --> Utf8 Class Initialized
INFO - 2023-06-01 08:50:16 --> URI Class Initialized
INFO - 2023-06-01 08:50:16 --> Router Class Initialized
INFO - 2023-06-01 08:50:16 --> Output Class Initialized
INFO - 2023-06-01 08:50:16 --> Security Class Initialized
DEBUG - 2023-06-01 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 08:50:16 --> Input Class Initialized
INFO - 2023-06-01 08:50:17 --> Language Class Initialized
INFO - 2023-06-01 08:50:17 --> Loader Class Initialized
INFO - 2023-06-01 08:50:17 --> Controller Class Initialized
DEBUG - 2023-06-01 08:50:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 08:50:17 --> Database Driver Class Initialized
INFO - 2023-06-01 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Final output sent to browser
DEBUG - 2023-06-01 10:09:30 --> Total execution time: 0.6489
INFO - 2023-06-01 10:09:30 --> Final output sent to browser
INFO - 2023-06-01 10:09:30 --> Final output sent to browser
DEBUG - 2023-06-01 10:09:30 --> Total execution time: 0.6925
DEBUG - 2023-06-01 10:09:30 --> Total execution time: 0.6930
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:09:30 --> Output Class Initialized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Security Class Initialized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
INFO - 2023-06-01 10:09:30 --> Input Class Initialized
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
INFO - 2023-06-01 10:09:30 --> Language Class Initialized
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Loader Class Initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:30 --> Final output sent to browser
INFO - 2023-06-01 10:09:30 --> Final output sent to browser
INFO - 2023-06-01 10:09:30 --> Controller Class Initialized
DEBUG - 2023-06-01 10:09:30 --> Total execution time: 0.2034
DEBUG - 2023-06-01 10:09:30 --> Total execution time: 0.2026
DEBUG - 2023-06-01 10:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:09:30 --> Config Class Initialized
INFO - 2023-06-01 10:09:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:09:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:30 --> URI Class Initialized
INFO - 2023-06-01 10:09:30 --> Router Class Initialized
INFO - 2023-06-01 10:09:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:31 --> Output Class Initialized
INFO - 2023-06-01 10:09:31 --> Security Class Initialized
INFO - 2023-06-01 10:09:31 --> Final output sent to browser
DEBUG - 2023-06-01 10:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:09:31 --> Input Class Initialized
DEBUG - 2023-06-01 10:09:31 --> Total execution time: 0.3873
INFO - 2023-06-01 10:09:31 --> Language Class Initialized
INFO - 2023-06-01 10:09:31 --> Loader Class Initialized
INFO - 2023-06-01 10:09:31 --> Controller Class Initialized
DEBUG - 2023-06-01 10:09:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:09:31 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:31 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:09:31 --> Config Class Initialized
INFO - 2023-06-01 10:09:31 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:09:31 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:09:31 --> Utf8 Class Initialized
INFO - 2023-06-01 10:09:31 --> URI Class Initialized
INFO - 2023-06-01 10:09:31 --> Router Class Initialized
INFO - 2023-06-01 10:09:31 --> Output Class Initialized
INFO - 2023-06-01 10:09:31 --> Security Class Initialized
DEBUG - 2023-06-01 10:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:09:31 --> Input Class Initialized
INFO - 2023-06-01 10:09:31 --> Language Class Initialized
INFO - 2023-06-01 10:09:31 --> Loader Class Initialized
INFO - 2023-06-01 10:09:31 --> Controller Class Initialized
DEBUG - 2023-06-01 10:09:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:09:31 --> Database Driver Class Initialized
INFO - 2023-06-01 10:09:31 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:26 --> Config Class Initialized
INFO - 2023-06-01 10:11:26 --> Config Class Initialized
INFO - 2023-06-01 10:11:26 --> Config Class Initialized
INFO - 2023-06-01 10:11:26 --> Hooks Class Initialized
INFO - 2023-06-01 10:11:26 --> Hooks Class Initialized
INFO - 2023-06-01 10:11:26 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:11:26 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:11:26 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:26 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:26 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:26 --> URI Class Initialized
INFO - 2023-06-01 10:11:26 --> URI Class Initialized
INFO - 2023-06-01 10:11:26 --> URI Class Initialized
INFO - 2023-06-01 10:11:26 --> Router Class Initialized
INFO - 2023-06-01 10:11:26 --> Router Class Initialized
INFO - 2023-06-01 10:11:26 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.2933
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.3116
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.3135
INFO - 2023-06-01 10:11:27 --> Config Class Initialized
INFO - 2023-06-01 10:11:27 --> Config Class Initialized
INFO - 2023-06-01 10:11:27 --> Config Class Initialized
INFO - 2023-06-01 10:11:27 --> Hooks Class Initialized
INFO - 2023-06-01 10:11:27 --> Hooks Class Initialized
INFO - 2023-06-01 10:11:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:11:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:11:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:27 --> URI Class Initialized
INFO - 2023-06-01 10:11:27 --> URI Class Initialized
INFO - 2023-06-01 10:11:27 --> URI Class Initialized
INFO - 2023-06-01 10:11:27 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.2219
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.2214
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:11:27 --> Total execution time: 0.2891
INFO - 2023-06-01 10:11:27 --> Config Class Initialized
INFO - 2023-06-01 10:11:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:11:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:11:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:27 --> URI Class Initialized
INFO - 2023-06-01 10:11:27 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:11:27 --> Config Class Initialized
INFO - 2023-06-01 10:11:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:11:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:11:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:11:27 --> URI Class Initialized
INFO - 2023-06-01 10:11:27 --> Router Class Initialized
INFO - 2023-06-01 10:11:27 --> Output Class Initialized
INFO - 2023-06-01 10:11:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:11:27 --> Input Class Initialized
INFO - 2023-06-01 10:11:27 --> Language Class Initialized
INFO - 2023-06-01 10:11:27 --> Loader Class Initialized
INFO - 2023-06-01 10:11:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:11:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:11:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:11:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Final output sent to browser
INFO - 2023-06-01 10:12:17 --> Final output sent to browser
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Total execution time: 0.3092
DEBUG - 2023-06-01 10:12:17 --> Total execution time: 0.3094
INFO - 2023-06-01 10:12:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Final output sent to browser
DEBUG - 2023-06-01 10:12:17 --> Total execution time: 0.3332
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:12:17 --> Input Class Initialized
INFO - 2023-06-01 10:12:17 --> Language Class Initialized
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:17 --> Loader Class Initialized
INFO - 2023-06-01 10:12:17 --> Final output sent to browser
INFO - 2023-06-01 10:12:17 --> Final output sent to browser
DEBUG - 2023-06-01 10:12:17 --> Total execution time: 0.2343
DEBUG - 2023-06-01 10:12:17 --> Total execution time: 0.2355
INFO - 2023-06-01 10:12:17 --> Controller Class Initialized
DEBUG - 2023-06-01 10:12:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:17 --> Config Class Initialized
INFO - 2023-06-01 10:12:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:12:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:12:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:17 --> URI Class Initialized
INFO - 2023-06-01 10:12:17 --> Router Class Initialized
INFO - 2023-06-01 10:12:17 --> Output Class Initialized
INFO - 2023-06-01 10:12:17 --> Security Class Initialized
DEBUG - 2023-06-01 10:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:12:18 --> Input Class Initialized
INFO - 2023-06-01 10:12:18 --> Language Class Initialized
INFO - 2023-06-01 10:12:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:18 --> Final output sent to browser
DEBUG - 2023-06-01 10:12:18 --> Total execution time: 0.4551
INFO - 2023-06-01 10:12:18 --> Loader Class Initialized
INFO - 2023-06-01 10:12:18 --> Controller Class Initialized
DEBUG - 2023-06-01 10:12:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:18 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:12:18 --> Config Class Initialized
INFO - 2023-06-01 10:12:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:12:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:12:18 --> Utf8 Class Initialized
INFO - 2023-06-01 10:12:18 --> URI Class Initialized
INFO - 2023-06-01 10:12:18 --> Router Class Initialized
INFO - 2023-06-01 10:12:18 --> Output Class Initialized
INFO - 2023-06-01 10:12:18 --> Security Class Initialized
DEBUG - 2023-06-01 10:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:12:18 --> Input Class Initialized
INFO - 2023-06-01 10:12:18 --> Language Class Initialized
INFO - 2023-06-01 10:12:18 --> Loader Class Initialized
INFO - 2023-06-01 10:12:18 --> Controller Class Initialized
DEBUG - 2023-06-01 10:12:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:12:18 --> Database Driver Class Initialized
INFO - 2023-06-01 10:12:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:13 --> Config Class Initialized
INFO - 2023-06-01 10:17:13 --> Config Class Initialized
INFO - 2023-06-01 10:17:13 --> Config Class Initialized
INFO - 2023-06-01 10:17:13 --> Hooks Class Initialized
INFO - 2023-06-01 10:17:13 --> Hooks Class Initialized
INFO - 2023-06-01 10:17:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:17:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:13 --> URI Class Initialized
INFO - 2023-06-01 10:17:13 --> URI Class Initialized
INFO - 2023-06-01 10:17:13 --> URI Class Initialized
INFO - 2023-06-01 10:17:13 --> Router Class Initialized
INFO - 2023-06-01 10:17:13 --> Router Class Initialized
INFO - 2023-06-01 10:17:13 --> Router Class Initialized
INFO - 2023-06-01 10:17:13 --> Output Class Initialized
INFO - 2023-06-01 10:17:13 --> Output Class Initialized
INFO - 2023-06-01 10:17:13 --> Output Class Initialized
INFO - 2023-06-01 10:17:13 --> Security Class Initialized
INFO - 2023-06-01 10:17:13 --> Security Class Initialized
INFO - 2023-06-01 10:17:13 --> Security Class Initialized
DEBUG - 2023-06-01 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:13 --> Input Class Initialized
INFO - 2023-06-01 10:17:13 --> Input Class Initialized
INFO - 2023-06-01 10:17:13 --> Input Class Initialized
INFO - 2023-06-01 10:17:13 --> Language Class Initialized
INFO - 2023-06-01 10:17:13 --> Language Class Initialized
INFO - 2023-06-01 10:17:13 --> Language Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.2738
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.2730
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Config Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Config Class Initialized
INFO - 2023-06-01 10:17:14 --> Hooks Class Initialized
INFO - 2023-06-01 10:17:14 --> Hooks Class Initialized
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.3346
DEBUG - 2023-06-01 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:17:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:14 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:14 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:14 --> URI Class Initialized
INFO - 2023-06-01 10:17:14 --> URI Class Initialized
INFO - 2023-06-01 10:17:14 --> Router Class Initialized
INFO - 2023-06-01 10:17:14 --> Router Class Initialized
INFO - 2023-06-01 10:17:14 --> Output Class Initialized
INFO - 2023-06-01 10:17:14 --> Output Class Initialized
INFO - 2023-06-01 10:17:14 --> Config Class Initialized
INFO - 2023-06-01 10:17:14 --> Security Class Initialized
INFO - 2023-06-01 10:17:14 --> Security Class Initialized
INFO - 2023-06-01 10:17:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:14 --> Input Class Initialized
INFO - 2023-06-01 10:17:14 --> Input Class Initialized
INFO - 2023-06-01 10:17:14 --> Language Class Initialized
INFO - 2023-06-01 10:17:14 --> Language Class Initialized
DEBUG - 2023-06-01 10:17:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:14 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> URI Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Router Class Initialized
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Output Class Initialized
INFO - 2023-06-01 10:17:14 --> Security Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.2266
INFO - 2023-06-01 10:17:14 --> Input Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.2278
INFO - 2023-06-01 10:17:14 --> Language Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
INFO - 2023-06-01 10:17:14 --> Config Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:14 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> URI Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Router Class Initialized
INFO - 2023-06-01 10:17:14 --> Final output sent to browser
INFO - 2023-06-01 10:17:14 --> Output Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Total execution time: 0.3025
INFO - 2023-06-01 10:17:14 --> Security Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:14 --> Input Class Initialized
INFO - 2023-06-01 10:17:14 --> Language Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:14 --> Config Class Initialized
INFO - 2023-06-01 10:17:14 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:14 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:14 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:14 --> URI Class Initialized
INFO - 2023-06-01 10:17:14 --> Router Class Initialized
INFO - 2023-06-01 10:17:14 --> Output Class Initialized
INFO - 2023-06-01 10:17:14 --> Security Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:14 --> Input Class Initialized
INFO - 2023-06-01 10:17:14 --> Language Class Initialized
INFO - 2023-06-01 10:17:14 --> Loader Class Initialized
INFO - 2023-06-01 10:17:14 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:14 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:14 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:56 --> Config Class Initialized
INFO - 2023-06-01 10:17:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:56 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:56 --> URI Class Initialized
INFO - 2023-06-01 10:17:56 --> Router Class Initialized
INFO - 2023-06-01 10:17:56 --> Output Class Initialized
INFO - 2023-06-01 10:17:56 --> Security Class Initialized
DEBUG - 2023-06-01 10:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:56 --> Input Class Initialized
INFO - 2023-06-01 10:17:56 --> Language Class Initialized
INFO - 2023-06-01 10:17:56 --> Loader Class Initialized
INFO - 2023-06-01 10:17:56 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:56 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:17:56 --> Config Class Initialized
INFO - 2023-06-01 10:17:56 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:17:56 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:17:56 --> Utf8 Class Initialized
INFO - 2023-06-01 10:17:56 --> URI Class Initialized
INFO - 2023-06-01 10:17:56 --> Router Class Initialized
INFO - 2023-06-01 10:17:56 --> Output Class Initialized
INFO - 2023-06-01 10:17:56 --> Security Class Initialized
DEBUG - 2023-06-01 10:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:17:56 --> Input Class Initialized
INFO - 2023-06-01 10:17:56 --> Language Class Initialized
INFO - 2023-06-01 10:17:56 --> Loader Class Initialized
INFO - 2023-06-01 10:17:56 --> Controller Class Initialized
DEBUG - 2023-06-01 10:17:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:17:56 --> Database Driver Class Initialized
INFO - 2023-06-01 10:17:56 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.2731
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.2726
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.3400
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.2559
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.2742
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:28 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:28 --> Config Class Initialized
INFO - 2023-06-01 10:24:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:24:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:24:28 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:28 --> URI Class Initialized
INFO - 2023-06-01 10:24:28 --> Final output sent to browser
DEBUG - 2023-06-01 10:24:28 --> Total execution time: 0.3354
INFO - 2023-06-01 10:24:28 --> Router Class Initialized
INFO - 2023-06-01 10:24:28 --> Output Class Initialized
INFO - 2023-06-01 10:24:28 --> Security Class Initialized
DEBUG - 2023-06-01 10:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:24:28 --> Input Class Initialized
INFO - 2023-06-01 10:24:28 --> Language Class Initialized
INFO - 2023-06-01 10:24:28 --> Loader Class Initialized
INFO - 2023-06-01 10:24:28 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:24:29 --> Config Class Initialized
INFO - 2023-06-01 10:24:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:24:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:24:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:24:29 --> URI Class Initialized
INFO - 2023-06-01 10:24:29 --> Router Class Initialized
INFO - 2023-06-01 10:24:29 --> Output Class Initialized
INFO - 2023-06-01 10:24:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:24:29 --> Input Class Initialized
INFO - 2023-06-01 10:24:29 --> Language Class Initialized
INFO - 2023-06-01 10:24:29 --> Loader Class Initialized
INFO - 2023-06-01 10:24:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:24:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:24:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:24:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:50:35 --> Config Class Initialized
INFO - 2023-06-01 10:50:35 --> Config Class Initialized
INFO - 2023-06-01 10:50:35 --> Hooks Class Initialized
INFO - 2023-06-01 10:50:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:50:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:50:35 --> Utf8 Class Initialized
INFO - 2023-06-01 10:50:35 --> Utf8 Class Initialized
INFO - 2023-06-01 10:50:35 --> URI Class Initialized
INFO - 2023-06-01 10:50:35 --> URI Class Initialized
INFO - 2023-06-01 10:50:35 --> Router Class Initialized
INFO - 2023-06-01 10:50:35 --> Router Class Initialized
INFO - 2023-06-01 10:50:35 --> Output Class Initialized
INFO - 2023-06-01 10:50:35 --> Output Class Initialized
INFO - 2023-06-01 10:50:35 --> Security Class Initialized
INFO - 2023-06-01 10:50:35 --> Security Class Initialized
DEBUG - 2023-06-01 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:50:35 --> Input Class Initialized
INFO - 2023-06-01 10:50:35 --> Input Class Initialized
INFO - 2023-06-01 10:50:35 --> Language Class Initialized
INFO - 2023-06-01 10:50:35 --> Language Class Initialized
INFO - 2023-06-01 10:50:35 --> Loader Class Initialized
INFO - 2023-06-01 10:50:35 --> Loader Class Initialized
INFO - 2023-06-01 10:50:35 --> Controller Class Initialized
DEBUG - 2023-06-01 10:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:50:35 --> Controller Class Initialized
DEBUG - 2023-06-01 10:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:50:35 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:35 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:50:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:50:35 --> Final output sent to browser
DEBUG - 2023-06-01 10:50:35 --> Total execution time: 0.2729
INFO - 2023-06-01 10:50:35 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:35 --> Config Class Initialized
INFO - 2023-06-01 10:50:35 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:50:35 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:50:35 --> Utf8 Class Initialized
INFO - 2023-06-01 10:50:35 --> URI Class Initialized
INFO - 2023-06-01 10:50:35 --> Router Class Initialized
INFO - 2023-06-01 10:50:35 --> Output Class Initialized
INFO - 2023-06-01 10:50:35 --> Security Class Initialized
DEBUG - 2023-06-01 10:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:50:35 --> Input Class Initialized
INFO - 2023-06-01 10:50:35 --> Language Class Initialized
INFO - 2023-06-01 10:50:35 --> Loader Class Initialized
INFO - 2023-06-01 10:50:35 --> Controller Class Initialized
DEBUG - 2023-06-01 10:50:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:50:35 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:35 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:50:35 --> Model "Login_model" initialized
INFO - 2023-06-01 10:50:36 --> Final output sent to browser
DEBUG - 2023-06-01 10:50:36 --> Total execution time: 0.3021
INFO - 2023-06-01 10:50:37 --> Final output sent to browser
DEBUG - 2023-06-01 10:50:37 --> Total execution time: 1.7383
INFO - 2023-06-01 10:50:37 --> Config Class Initialized
INFO - 2023-06-01 10:50:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:50:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:50:37 --> Utf8 Class Initialized
INFO - 2023-06-01 10:50:37 --> URI Class Initialized
INFO - 2023-06-01 10:50:37 --> Router Class Initialized
INFO - 2023-06-01 10:50:37 --> Output Class Initialized
INFO - 2023-06-01 10:50:37 --> Security Class Initialized
DEBUG - 2023-06-01 10:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:50:37 --> Input Class Initialized
INFO - 2023-06-01 10:50:37 --> Language Class Initialized
INFO - 2023-06-01 10:50:37 --> Loader Class Initialized
INFO - 2023-06-01 10:50:37 --> Controller Class Initialized
DEBUG - 2023-06-01 10:50:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:50:37 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:50:37 --> Database Driver Class Initialized
INFO - 2023-06-01 10:50:37 --> Model "Login_model" initialized
INFO - 2023-06-01 10:50:37 --> Final output sent to browser
DEBUG - 2023-06-01 10:50:37 --> Total execution time: 0.6203
INFO - 2023-06-01 10:53:05 --> Config Class Initialized
INFO - 2023-06-01 10:53:05 --> Config Class Initialized
INFO - 2023-06-01 10:53:05 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:05 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:05 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:05 --> URI Class Initialized
INFO - 2023-06-01 10:53:05 --> URI Class Initialized
INFO - 2023-06-01 10:53:05 --> Router Class Initialized
INFO - 2023-06-01 10:53:05 --> Router Class Initialized
INFO - 2023-06-01 10:53:05 --> Output Class Initialized
INFO - 2023-06-01 10:53:05 --> Output Class Initialized
INFO - 2023-06-01 10:53:05 --> Security Class Initialized
INFO - 2023-06-01 10:53:05 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:05 --> Input Class Initialized
INFO - 2023-06-01 10:53:05 --> Input Class Initialized
INFO - 2023-06-01 10:53:05 --> Language Class Initialized
INFO - 2023-06-01 10:53:05 --> Language Class Initialized
INFO - 2023-06-01 10:53:05 --> Loader Class Initialized
INFO - 2023-06-01 10:53:05 --> Loader Class Initialized
INFO - 2023-06-01 10:53:05 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:05 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:05 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:05 --> Total execution time: 0.3315
INFO - 2023-06-01 10:53:05 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:05 --> Config Class Initialized
INFO - 2023-06-01 10:53:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:05 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:05 --> URI Class Initialized
INFO - 2023-06-01 10:53:05 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:05 --> Router Class Initialized
INFO - 2023-06-01 10:53:05 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:05 --> Total execution time: 0.6478
INFO - 2023-06-01 10:53:05 --> Output Class Initialized
INFO - 2023-06-01 10:53:05 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:05 --> Input Class Initialized
INFO - 2023-06-01 10:53:05 --> Language Class Initialized
INFO - 2023-06-01 10:53:05 --> Config Class Initialized
INFO - 2023-06-01 10:53:05 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:05 --> Loader Class Initialized
DEBUG - 2023-06-01 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:05 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:05 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:05 --> URI Class Initialized
INFO - 2023-06-01 10:53:05 --> Router Class Initialized
INFO - 2023-06-01 10:53:05 --> Output Class Initialized
INFO - 2023-06-01 10:53:06 --> Security Class Initialized
INFO - 2023-06-01 10:53:06 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:06 --> Input Class Initialized
INFO - 2023-06-01 10:53:06 --> Language Class Initialized
INFO - 2023-06-01 10:53:06 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:06 --> Loader Class Initialized
INFO - 2023-06-01 10:53:06 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:06 --> Controller Class Initialized
INFO - 2023-06-01 10:53:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:06 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:53:06 --> Total execution time: 0.6120
INFO - 2023-06-01 10:53:06 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:06 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:06 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:06 --> Total execution time: 0.4230
INFO - 2023-06-01 10:53:08 --> Config Class Initialized
INFO - 2023-06-01 10:53:08 --> Config Class Initialized
INFO - 2023-06-01 10:53:08 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:08 --> URI Class Initialized
INFO - 2023-06-01 10:53:08 --> URI Class Initialized
INFO - 2023-06-01 10:53:08 --> Router Class Initialized
INFO - 2023-06-01 10:53:08 --> Router Class Initialized
INFO - 2023-06-01 10:53:08 --> Output Class Initialized
INFO - 2023-06-01 10:53:08 --> Output Class Initialized
INFO - 2023-06-01 10:53:08 --> Security Class Initialized
INFO - 2023-06-01 10:53:08 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:08 --> Input Class Initialized
INFO - 2023-06-01 10:53:08 --> Input Class Initialized
INFO - 2023-06-01 10:53:08 --> Language Class Initialized
INFO - 2023-06-01 10:53:08 --> Language Class Initialized
INFO - 2023-06-01 10:53:08 --> Loader Class Initialized
INFO - 2023-06-01 10:53:08 --> Loader Class Initialized
INFO - 2023-06-01 10:53:08 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:08 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:08 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:08 --> Total execution time: 0.2094
INFO - 2023-06-01 10:53:09 --> Config Class Initialized
INFO - 2023-06-01 10:53:09 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:09 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:53:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:09 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:09 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:09 --> URI Class Initialized
INFO - 2023-06-01 10:53:09 --> Router Class Initialized
INFO - 2023-06-01 10:53:09 --> Output Class Initialized
INFO - 2023-06-01 10:53:09 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:09 --> Input Class Initialized
INFO - 2023-06-01 10:53:09 --> Language Class Initialized
INFO - 2023-06-01 10:53:09 --> Loader Class Initialized
INFO - 2023-06-01 10:53:09 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:09 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:09 --> Total execution time: 0.4807
INFO - 2023-06-01 10:53:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:09 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:09 --> Total execution time: 0.2650
INFO - 2023-06-01 10:53:09 --> Config Class Initialized
INFO - 2023-06-01 10:53:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:09 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:09 --> URI Class Initialized
INFO - 2023-06-01 10:53:09 --> Router Class Initialized
INFO - 2023-06-01 10:53:09 --> Output Class Initialized
INFO - 2023-06-01 10:53:09 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:09 --> Input Class Initialized
INFO - 2023-06-01 10:53:09 --> Language Class Initialized
INFO - 2023-06-01 10:53:09 --> Loader Class Initialized
INFO - 2023-06-01 10:53:09 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:09 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:09 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:09 --> Total execution time: 0.6016
INFO - 2023-06-01 10:53:15 --> Config Class Initialized
INFO - 2023-06-01 10:53:15 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:15 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:15 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:15 --> URI Class Initialized
INFO - 2023-06-01 10:53:15 --> Router Class Initialized
INFO - 2023-06-01 10:53:15 --> Output Class Initialized
INFO - 2023-06-01 10:53:15 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:15 --> Input Class Initialized
INFO - 2023-06-01 10:53:15 --> Language Class Initialized
INFO - 2023-06-01 10:53:15 --> Loader Class Initialized
INFO - 2023-06-01 10:53:15 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:15 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:15 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:15 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:15 --> Total execution time: 0.1898
INFO - 2023-06-01 10:53:16 --> Config Class Initialized
INFO - 2023-06-01 10:53:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:16 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:16 --> URI Class Initialized
INFO - 2023-06-01 10:53:16 --> Router Class Initialized
INFO - 2023-06-01 10:53:16 --> Output Class Initialized
INFO - 2023-06-01 10:53:16 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:16 --> Input Class Initialized
INFO - 2023-06-01 10:53:16 --> Language Class Initialized
INFO - 2023-06-01 10:53:16 --> Loader Class Initialized
INFO - 2023-06-01 10:53:16 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:16 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:16 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:16 --> Total execution time: 0.1791
INFO - 2023-06-01 10:53:23 --> Config Class Initialized
INFO - 2023-06-01 10:53:23 --> Config Class Initialized
INFO - 2023-06-01 10:53:23 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:23 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:23 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:23 --> URI Class Initialized
INFO - 2023-06-01 10:53:23 --> URI Class Initialized
INFO - 2023-06-01 10:53:23 --> Router Class Initialized
INFO - 2023-06-01 10:53:23 --> Router Class Initialized
INFO - 2023-06-01 10:53:23 --> Output Class Initialized
INFO - 2023-06-01 10:53:23 --> Output Class Initialized
INFO - 2023-06-01 10:53:23 --> Security Class Initialized
INFO - 2023-06-01 10:53:23 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:23 --> Input Class Initialized
INFO - 2023-06-01 10:53:23 --> Input Class Initialized
INFO - 2023-06-01 10:53:23 --> Language Class Initialized
INFO - 2023-06-01 10:53:23 --> Language Class Initialized
INFO - 2023-06-01 10:53:23 --> Loader Class Initialized
INFO - 2023-06-01 10:53:23 --> Loader Class Initialized
INFO - 2023-06-01 10:53:23 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:23 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:23 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:23 --> Total execution time: 0.1875
INFO - 2023-06-01 10:53:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:23 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:23 --> Config Class Initialized
INFO - 2023-06-01 10:53:23 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:23 --> Model "Login_model" initialized
DEBUG - 2023-06-01 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:23 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:24 --> URI Class Initialized
INFO - 2023-06-01 10:53:24 --> Router Class Initialized
INFO - 2023-06-01 10:53:24 --> Output Class Initialized
INFO - 2023-06-01 10:53:24 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:24 --> Input Class Initialized
INFO - 2023-06-01 10:53:24 --> Language Class Initialized
INFO - 2023-06-01 10:53:24 --> Loader Class Initialized
INFO - 2023-06-01 10:53:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:24 --> Total execution time: 0.2139
INFO - 2023-06-01 10:53:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:24 --> Total execution time: 0.4438
INFO - 2023-06-01 10:53:24 --> Config Class Initialized
INFO - 2023-06-01 10:53:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:24 --> URI Class Initialized
INFO - 2023-06-01 10:53:24 --> Router Class Initialized
INFO - 2023-06-01 10:53:24 --> Output Class Initialized
INFO - 2023-06-01 10:53:24 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:24 --> Input Class Initialized
INFO - 2023-06-01 10:53:24 --> Language Class Initialized
INFO - 2023-06-01 10:53:24 --> Loader Class Initialized
INFO - 2023-06-01 10:53:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:24 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:24 --> Total execution time: 0.6367
INFO - 2023-06-01 10:53:28 --> Config Class Initialized
INFO - 2023-06-01 10:53:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:28 --> URI Class Initialized
INFO - 2023-06-01 10:53:29 --> Router Class Initialized
INFO - 2023-06-01 10:53:29 --> Output Class Initialized
INFO - 2023-06-01 10:53:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:29 --> Input Class Initialized
INFO - 2023-06-01 10:53:29 --> Language Class Initialized
INFO - 2023-06-01 10:53:29 --> Loader Class Initialized
INFO - 2023-06-01 10:53:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:29 --> Total execution time: 0.1945
INFO - 2023-06-01 10:53:29 --> Config Class Initialized
INFO - 2023-06-01 10:53:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:29 --> URI Class Initialized
INFO - 2023-06-01 10:53:29 --> Router Class Initialized
INFO - 2023-06-01 10:53:29 --> Output Class Initialized
INFO - 2023-06-01 10:53:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:29 --> Input Class Initialized
INFO - 2023-06-01 10:53:29 --> Language Class Initialized
INFO - 2023-06-01 10:53:29 --> Loader Class Initialized
INFO - 2023-06-01 10:53:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:29 --> Total execution time: 0.2124
INFO - 2023-06-01 10:53:30 --> Config Class Initialized
INFO - 2023-06-01 10:53:30 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:30 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:30 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:30 --> URI Class Initialized
INFO - 2023-06-01 10:53:30 --> Router Class Initialized
INFO - 2023-06-01 10:53:30 --> Output Class Initialized
INFO - 2023-06-01 10:53:30 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:30 --> Input Class Initialized
INFO - 2023-06-01 10:53:30 --> Language Class Initialized
INFO - 2023-06-01 10:53:30 --> Loader Class Initialized
INFO - 2023-06-01 10:53:30 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:30 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:30 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:30 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:30 --> Total execution time: 0.1829
INFO - 2023-06-01 10:53:32 --> Config Class Initialized
INFO - 2023-06-01 10:53:32 --> Config Class Initialized
INFO - 2023-06-01 10:53:32 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:32 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:32 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:32 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:32 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:32 --> URI Class Initialized
INFO - 2023-06-01 10:53:32 --> URI Class Initialized
INFO - 2023-06-01 10:53:32 --> Router Class Initialized
INFO - 2023-06-01 10:53:32 --> Router Class Initialized
INFO - 2023-06-01 10:53:32 --> Output Class Initialized
INFO - 2023-06-01 10:53:32 --> Output Class Initialized
INFO - 2023-06-01 10:53:32 --> Security Class Initialized
INFO - 2023-06-01 10:53:32 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:32 --> Input Class Initialized
INFO - 2023-06-01 10:53:32 --> Input Class Initialized
INFO - 2023-06-01 10:53:32 --> Language Class Initialized
INFO - 2023-06-01 10:53:32 --> Language Class Initialized
INFO - 2023-06-01 10:53:32 --> Loader Class Initialized
INFO - 2023-06-01 10:53:32 --> Loader Class Initialized
INFO - 2023-06-01 10:53:32 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:33 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:33 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:33 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:33 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:33 --> Total execution time: 0.1754
INFO - 2023-06-01 10:53:33 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:33 --> Config Class Initialized
INFO - 2023-06-01 10:53:33 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:33 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:33 --> URI Class Initialized
INFO - 2023-06-01 10:53:33 --> Router Class Initialized
INFO - 2023-06-01 10:53:33 --> Output Class Initialized
INFO - 2023-06-01 10:53:33 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:33 --> Input Class Initialized
INFO - 2023-06-01 10:53:33 --> Language Class Initialized
INFO - 2023-06-01 10:53:33 --> Loader Class Initialized
INFO - 2023-06-01 10:53:33 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:33 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:33 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:33 --> Total execution time: 0.2089
INFO - 2023-06-01 10:53:33 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:33 --> Total execution time: 0.6582
INFO - 2023-06-01 10:53:33 --> Config Class Initialized
INFO - 2023-06-01 10:53:33 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:33 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:33 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:33 --> URI Class Initialized
INFO - 2023-06-01 10:53:33 --> Router Class Initialized
INFO - 2023-06-01 10:53:33 --> Output Class Initialized
INFO - 2023-06-01 10:53:33 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:33 --> Input Class Initialized
INFO - 2023-06-01 10:53:33 --> Language Class Initialized
INFO - 2023-06-01 10:53:33 --> Loader Class Initialized
INFO - 2023-06-01 10:53:33 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:33 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:33 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:34 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:34 --> Config Class Initialized
INFO - 2023-06-01 10:53:34 --> Config Class Initialized
INFO - 2023-06-01 10:53:34 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:34 --> URI Class Initialized
INFO - 2023-06-01 10:53:34 --> URI Class Initialized
INFO - 2023-06-01 10:53:34 --> Router Class Initialized
INFO - 2023-06-01 10:53:34 --> Router Class Initialized
INFO - 2023-06-01 10:53:34 --> Output Class Initialized
INFO - 2023-06-01 10:53:34 --> Output Class Initialized
INFO - 2023-06-01 10:53:34 --> Security Class Initialized
INFO - 2023-06-01 10:53:34 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:34 --> Input Class Initialized
INFO - 2023-06-01 10:53:34 --> Input Class Initialized
INFO - 2023-06-01 10:53:34 --> Language Class Initialized
INFO - 2023-06-01 10:53:34 --> Language Class Initialized
INFO - 2023-06-01 10:53:34 --> Loader Class Initialized
INFO - 2023-06-01 10:53:34 --> Loader Class Initialized
INFO - 2023-06-01 10:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:34 --> Final output sent to browser
INFO - 2023-06-01 10:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Total execution time: 0.1503
DEBUG - 2023-06-01 10:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:34 --> Config Class Initialized
INFO - 2023-06-01 10:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:34 --> URI Class Initialized
INFO - 2023-06-01 10:53:34 --> Router Class Initialized
INFO - 2023-06-01 10:53:34 --> Output Class Initialized
INFO - 2023-06-01 10:53:34 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:34 --> Input Class Initialized
INFO - 2023-06-01 10:53:34 --> Language Class Initialized
INFO - 2023-06-01 10:53:34 --> Loader Class Initialized
INFO - 2023-06-01 10:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:34 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:34 --> Final output sent to browser
INFO - 2023-06-01 10:53:34 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:34 --> Total execution time: 0.4366
DEBUG - 2023-06-01 10:53:34 --> Total execution time: 1.0871
INFO - 2023-06-01 10:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:34 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:34 --> Total execution time: 0.2893
INFO - 2023-06-01 10:53:34 --> Config Class Initialized
INFO - 2023-06-01 10:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:34 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:34 --> URI Class Initialized
INFO - 2023-06-01 10:53:34 --> Router Class Initialized
INFO - 2023-06-01 10:53:34 --> Output Class Initialized
INFO - 2023-06-01 10:53:34 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:34 --> Input Class Initialized
INFO - 2023-06-01 10:53:34 --> Language Class Initialized
INFO - 2023-06-01 10:53:34 --> Loader Class Initialized
INFO - 2023-06-01 10:53:34 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:34 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:34 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:34 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:34 --> Total execution time: 0.2689
INFO - 2023-06-01 10:53:37 --> Config Class Initialized
INFO - 2023-06-01 10:53:37 --> Config Class Initialized
INFO - 2023-06-01 10:53:37 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:37 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:37 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:37 --> URI Class Initialized
INFO - 2023-06-01 10:53:37 --> URI Class Initialized
INFO - 2023-06-01 10:53:37 --> Router Class Initialized
INFO - 2023-06-01 10:53:37 --> Router Class Initialized
INFO - 2023-06-01 10:53:37 --> Output Class Initialized
INFO - 2023-06-01 10:53:37 --> Output Class Initialized
INFO - 2023-06-01 10:53:37 --> Security Class Initialized
INFO - 2023-06-01 10:53:37 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:37 --> Input Class Initialized
INFO - 2023-06-01 10:53:37 --> Input Class Initialized
INFO - 2023-06-01 10:53:37 --> Language Class Initialized
INFO - 2023-06-01 10:53:37 --> Language Class Initialized
INFO - 2023-06-01 10:53:37 --> Loader Class Initialized
INFO - 2023-06-01 10:53:37 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:37 --> Loader Class Initialized
INFO - 2023-06-01 10:53:37 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:37 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:37 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:37 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:37 --> Total execution time: 0.2160
INFO - 2023-06-01 10:53:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:38 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:38 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:38 --> Total execution time: 0.7704
INFO - 2023-06-01 10:53:38 --> Config Class Initialized
INFO - 2023-06-01 10:53:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:38 --> URI Class Initialized
INFO - 2023-06-01 10:53:38 --> Router Class Initialized
INFO - 2023-06-01 10:53:38 --> Output Class Initialized
INFO - 2023-06-01 10:53:38 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:38 --> Input Class Initialized
INFO - 2023-06-01 10:53:38 --> Language Class Initialized
INFO - 2023-06-01 10:53:38 --> Loader Class Initialized
INFO - 2023-06-01 10:53:38 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:39 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:39 --> Total execution time: 0.4091
INFO - 2023-06-01 10:53:39 --> Config Class Initialized
INFO - 2023-06-01 10:53:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:39 --> URI Class Initialized
INFO - 2023-06-01 10:53:39 --> Router Class Initialized
INFO - 2023-06-01 10:53:39 --> Output Class Initialized
INFO - 2023-06-01 10:53:39 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:39 --> Input Class Initialized
INFO - 2023-06-01 10:53:39 --> Language Class Initialized
INFO - 2023-06-01 10:53:39 --> Loader Class Initialized
INFO - 2023-06-01 10:53:39 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:39 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:39 --> Total execution time: 0.3016
INFO - 2023-06-01 10:53:39 --> Config Class Initialized
INFO - 2023-06-01 10:53:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:39 --> URI Class Initialized
INFO - 2023-06-01 10:53:39 --> Router Class Initialized
INFO - 2023-06-01 10:53:39 --> Output Class Initialized
INFO - 2023-06-01 10:53:39 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:39 --> Input Class Initialized
INFO - 2023-06-01 10:53:39 --> Language Class Initialized
INFO - 2023-06-01 10:53:39 --> Loader Class Initialized
INFO - 2023-06-01 10:53:39 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:39 --> Total execution time: 0.1722
INFO - 2023-06-01 10:53:39 --> Config Class Initialized
INFO - 2023-06-01 10:53:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:39 --> URI Class Initialized
INFO - 2023-06-01 10:53:39 --> Router Class Initialized
INFO - 2023-06-01 10:53:39 --> Output Class Initialized
INFO - 2023-06-01 10:53:39 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:39 --> Input Class Initialized
INFO - 2023-06-01 10:53:39 --> Language Class Initialized
INFO - 2023-06-01 10:53:39 --> Loader Class Initialized
INFO - 2023-06-01 10:53:39 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:40 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:40 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:40 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:40 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:40 --> Total execution time: 0.2861
INFO - 2023-06-01 10:53:49 --> Config Class Initialized
INFO - 2023-06-01 10:53:49 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:49 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:49 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:49 --> URI Class Initialized
INFO - 2023-06-01 10:53:49 --> Router Class Initialized
INFO - 2023-06-01 10:53:49 --> Output Class Initialized
INFO - 2023-06-01 10:53:49 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:49 --> Input Class Initialized
INFO - 2023-06-01 10:53:49 --> Language Class Initialized
INFO - 2023-06-01 10:53:49 --> Loader Class Initialized
INFO - 2023-06-01 10:53:49 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:49 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:49 --> Total execution time: 0.1414
INFO - 2023-06-01 10:53:50 --> Config Class Initialized
INFO - 2023-06-01 10:53:50 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:50 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:50 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:50 --> URI Class Initialized
INFO - 2023-06-01 10:53:50 --> Router Class Initialized
INFO - 2023-06-01 10:53:50 --> Output Class Initialized
INFO - 2023-06-01 10:53:50 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:50 --> Input Class Initialized
INFO - 2023-06-01 10:53:50 --> Language Class Initialized
INFO - 2023-06-01 10:53:50 --> Loader Class Initialized
INFO - 2023-06-01 10:53:50 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:50 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:50 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:50 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:50 --> Total execution time: 0.4208
INFO - 2023-06-01 10:53:51 --> Config Class Initialized
INFO - 2023-06-01 10:53:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:51 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:51 --> URI Class Initialized
INFO - 2023-06-01 10:53:51 --> Router Class Initialized
INFO - 2023-06-01 10:53:51 --> Output Class Initialized
INFO - 2023-06-01 10:53:51 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:51 --> Input Class Initialized
INFO - 2023-06-01 10:53:51 --> Language Class Initialized
INFO - 2023-06-01 10:53:51 --> Loader Class Initialized
INFO - 2023-06-01 10:53:51 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:51 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:51 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:51 --> Total execution time: 0.1699
INFO - 2023-06-01 10:53:51 --> Config Class Initialized
INFO - 2023-06-01 10:53:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:51 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:51 --> URI Class Initialized
INFO - 2023-06-01 10:53:51 --> Router Class Initialized
INFO - 2023-06-01 10:53:51 --> Output Class Initialized
INFO - 2023-06-01 10:53:51 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:51 --> Input Class Initialized
INFO - 2023-06-01 10:53:51 --> Language Class Initialized
INFO - 2023-06-01 10:53:51 --> Loader Class Initialized
INFO - 2023-06-01 10:53:51 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:51 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:51 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:51 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:51 --> Total execution time: 0.1885
INFO - 2023-06-01 10:53:51 --> Config Class Initialized
INFO - 2023-06-01 10:53:51 --> Config Class Initialized
INFO - 2023-06-01 10:53:51 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:51 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:53:51 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:51 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:51 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:51 --> URI Class Initialized
INFO - 2023-06-01 10:53:51 --> URI Class Initialized
INFO - 2023-06-01 10:53:51 --> Router Class Initialized
INFO - 2023-06-01 10:53:51 --> Router Class Initialized
INFO - 2023-06-01 10:53:51 --> Output Class Initialized
INFO - 2023-06-01 10:53:51 --> Output Class Initialized
INFO - 2023-06-01 10:53:51 --> Security Class Initialized
INFO - 2023-06-01 10:53:51 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:51 --> Input Class Initialized
INFO - 2023-06-01 10:53:51 --> Input Class Initialized
INFO - 2023-06-01 10:53:51 --> Language Class Initialized
INFO - 2023-06-01 10:53:51 --> Language Class Initialized
INFO - 2023-06-01 10:53:51 --> Loader Class Initialized
INFO - 2023-06-01 10:53:51 --> Loader Class Initialized
INFO - 2023-06-01 10:53:51 --> Controller Class Initialized
INFO - 2023-06-01 10:53:51 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:53:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:51 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.1169
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:52 --> Config Class Initialized
INFO - 2023-06-01 10:53:52 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:52 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:52 --> URI Class Initialized
INFO - 2023-06-01 10:53:52 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.2283
INFO - 2023-06-01 10:53:52 --> Router Class Initialized
INFO - 2023-06-01 10:53:52 --> Output Class Initialized
INFO - 2023-06-01 10:53:52 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:52 --> Input Class Initialized
INFO - 2023-06-01 10:53:52 --> Config Class Initialized
INFO - 2023-06-01 10:53:52 --> Hooks Class Initialized
INFO - 2023-06-01 10:53:52 --> Language Class Initialized
DEBUG - 2023-06-01 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:52 --> Loader Class Initialized
INFO - 2023-06-01 10:53:52 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:52 --> URI Class Initialized
INFO - 2023-06-01 10:53:52 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:52 --> Router Class Initialized
INFO - 2023-06-01 10:53:52 --> Output Class Initialized
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:52 --> Input Class Initialized
INFO - 2023-06-01 10:53:52 --> Language Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:52 --> Loader Class Initialized
INFO - 2023-06-01 10:53:52 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:52 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.2667
INFO - 2023-06-01 10:53:52 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.4000
INFO - 2023-06-01 10:53:52 --> Config Class Initialized
INFO - 2023-06-01 10:53:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:52 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:52 --> URI Class Initialized
INFO - 2023-06-01 10:53:52 --> Router Class Initialized
INFO - 2023-06-01 10:53:52 --> Output Class Initialized
INFO - 2023-06-01 10:53:52 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:52 --> Input Class Initialized
INFO - 2023-06-01 10:53:52 --> Language Class Initialized
INFO - 2023-06-01 10:53:52 --> Loader Class Initialized
INFO - 2023-06-01 10:53:52 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:52 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.1550
INFO - 2023-06-01 10:53:52 --> Config Class Initialized
INFO - 2023-06-01 10:53:52 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:53:52 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:53:52 --> Utf8 Class Initialized
INFO - 2023-06-01 10:53:52 --> URI Class Initialized
INFO - 2023-06-01 10:53:52 --> Router Class Initialized
INFO - 2023-06-01 10:53:52 --> Output Class Initialized
INFO - 2023-06-01 10:53:52 --> Security Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:53:52 --> Input Class Initialized
INFO - 2023-06-01 10:53:52 --> Language Class Initialized
INFO - 2023-06-01 10:53:52 --> Loader Class Initialized
INFO - 2023-06-01 10:53:52 --> Controller Class Initialized
DEBUG - 2023-06-01 10:53:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Login_model" initialized
INFO - 2023-06-01 10:53:52 --> Database Driver Class Initialized
INFO - 2023-06-01 10:53:52 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:53:52 --> Final output sent to browser
DEBUG - 2023-06-01 10:53:52 --> Total execution time: 0.3111
INFO - 2023-06-01 10:54:22 --> Config Class Initialized
INFO - 2023-06-01 10:54:22 --> Config Class Initialized
INFO - 2023-06-01 10:54:22 --> Hooks Class Initialized
INFO - 2023-06-01 10:54:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:22 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:54:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:22 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:22 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:22 --> URI Class Initialized
INFO - 2023-06-01 10:54:22 --> URI Class Initialized
INFO - 2023-06-01 10:54:22 --> Router Class Initialized
INFO - 2023-06-01 10:54:22 --> Router Class Initialized
INFO - 2023-06-01 10:54:22 --> Output Class Initialized
INFO - 2023-06-01 10:54:22 --> Output Class Initialized
INFO - 2023-06-01 10:54:22 --> Security Class Initialized
INFO - 2023-06-01 10:54:22 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:22 --> Input Class Initialized
INFO - 2023-06-01 10:54:22 --> Input Class Initialized
INFO - 2023-06-01 10:54:22 --> Language Class Initialized
INFO - 2023-06-01 10:54:22 --> Language Class Initialized
INFO - 2023-06-01 10:54:22 --> Loader Class Initialized
INFO - 2023-06-01 10:54:22 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:22 --> Loader Class Initialized
INFO - 2023-06-01 10:54:22 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:22 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:22 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:22 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:22 --> Total execution time: 0.1729
INFO - 2023-06-01 10:54:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:22 --> Config Class Initialized
INFO - 2023-06-01 10:54:22 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:22 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:22 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:22 --> URI Class Initialized
INFO - 2023-06-01 10:54:22 --> Router Class Initialized
INFO - 2023-06-01 10:54:22 --> Output Class Initialized
INFO - 2023-06-01 10:54:22 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:22 --> Input Class Initialized
INFO - 2023-06-01 10:54:22 --> Language Class Initialized
INFO - 2023-06-01 10:54:22 --> Loader Class Initialized
INFO - 2023-06-01 10:54:22 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:22 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:22 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:22 --> Model "Login_model" initialized
INFO - 2023-06-01 10:54:22 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:22 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:22 --> Total execution time: 0.2409
INFO - 2023-06-01 10:54:23 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:23 --> Total execution time: 1.2826
INFO - 2023-06-01 10:54:23 --> Config Class Initialized
INFO - 2023-06-01 10:54:23 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:23 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:23 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:23 --> URI Class Initialized
INFO - 2023-06-01 10:54:23 --> Router Class Initialized
INFO - 2023-06-01 10:54:23 --> Output Class Initialized
INFO - 2023-06-01 10:54:23 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:23 --> Input Class Initialized
INFO - 2023-06-01 10:54:23 --> Language Class Initialized
INFO - 2023-06-01 10:54:23 --> Loader Class Initialized
INFO - 2023-06-01 10:54:23 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:23 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:23 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:23 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:23 --> Model "Login_model" initialized
INFO - 2023-06-01 10:54:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:24 --> Total execution time: 0.9895
INFO - 2023-06-01 10:54:27 --> Config Class Initialized
INFO - 2023-06-01 10:54:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:27 --> URI Class Initialized
INFO - 2023-06-01 10:54:27 --> Router Class Initialized
INFO - 2023-06-01 10:54:27 --> Output Class Initialized
INFO - 2023-06-01 10:54:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:27 --> Input Class Initialized
INFO - 2023-06-01 10:54:27 --> Language Class Initialized
INFO - 2023-06-01 10:54:27 --> Loader Class Initialized
INFO - 2023-06-01 10:54:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:27 --> Total execution time: 0.1704
INFO - 2023-06-01 10:54:27 --> Config Class Initialized
INFO - 2023-06-01 10:54:27 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:27 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:27 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:27 --> URI Class Initialized
INFO - 2023-06-01 10:54:27 --> Router Class Initialized
INFO - 2023-06-01 10:54:27 --> Output Class Initialized
INFO - 2023-06-01 10:54:27 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:27 --> Input Class Initialized
INFO - 2023-06-01 10:54:27 --> Language Class Initialized
INFO - 2023-06-01 10:54:27 --> Loader Class Initialized
INFO - 2023-06-01 10:54:27 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:27 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:27 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:27 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:28 --> Total execution time: 0.1832
INFO - 2023-06-01 10:54:29 --> Config Class Initialized
INFO - 2023-06-01 10:54:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:29 --> URI Class Initialized
INFO - 2023-06-01 10:54:29 --> Router Class Initialized
INFO - 2023-06-01 10:54:29 --> Output Class Initialized
INFO - 2023-06-01 10:54:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:29 --> Input Class Initialized
INFO - 2023-06-01 10:54:29 --> Language Class Initialized
INFO - 2023-06-01 10:54:29 --> Loader Class Initialized
INFO - 2023-06-01 10:54:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:29 --> Total execution time: 0.1685
INFO - 2023-06-01 10:54:37 --> Config Class Initialized
INFO - 2023-06-01 10:54:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:37 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:37 --> URI Class Initialized
INFO - 2023-06-01 10:54:37 --> Router Class Initialized
INFO - 2023-06-01 10:54:37 --> Output Class Initialized
INFO - 2023-06-01 10:54:37 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:37 --> Input Class Initialized
INFO - 2023-06-01 10:54:37 --> Language Class Initialized
INFO - 2023-06-01 10:54:37 --> Loader Class Initialized
INFO - 2023-06-01 10:54:37 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:37 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:37 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:37 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:37 --> Total execution time: 0.2024
INFO - 2023-06-01 10:54:37 --> Config Class Initialized
INFO - 2023-06-01 10:54:37 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:37 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:37 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:37 --> URI Class Initialized
INFO - 2023-06-01 10:54:37 --> Router Class Initialized
INFO - 2023-06-01 10:54:37 --> Output Class Initialized
INFO - 2023-06-01 10:54:37 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:37 --> Input Class Initialized
INFO - 2023-06-01 10:54:37 --> Language Class Initialized
INFO - 2023-06-01 10:54:37 --> Loader Class Initialized
INFO - 2023-06-01 10:54:37 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:38 --> Model "Login_model" initialized
INFO - 2023-06-01 10:54:38 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:38 --> Total execution time: 0.2206
INFO - 2023-06-01 10:54:38 --> Config Class Initialized
INFO - 2023-06-01 10:54:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:38 --> URI Class Initialized
INFO - 2023-06-01 10:54:38 --> Router Class Initialized
INFO - 2023-06-01 10:54:38 --> Output Class Initialized
INFO - 2023-06-01 10:54:38 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:38 --> Input Class Initialized
INFO - 2023-06-01 10:54:38 --> Language Class Initialized
INFO - 2023-06-01 10:54:38 --> Loader Class Initialized
INFO - 2023-06-01 10:54:38 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:38 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:38 --> Total execution time: 0.1904
INFO - 2023-06-01 10:54:38 --> Config Class Initialized
INFO - 2023-06-01 10:54:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:38 --> URI Class Initialized
INFO - 2023-06-01 10:54:38 --> Router Class Initialized
INFO - 2023-06-01 10:54:38 --> Output Class Initialized
INFO - 2023-06-01 10:54:38 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:38 --> Input Class Initialized
INFO - 2023-06-01 10:54:38 --> Language Class Initialized
INFO - 2023-06-01 10:54:38 --> Loader Class Initialized
INFO - 2023-06-01 10:54:38 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:38 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:38 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:38 --> Total execution time: 0.2134
INFO - 2023-06-01 10:54:43 --> Config Class Initialized
INFO - 2023-06-01 10:54:43 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:43 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:43 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:43 --> URI Class Initialized
INFO - 2023-06-01 10:54:43 --> Router Class Initialized
INFO - 2023-06-01 10:54:43 --> Output Class Initialized
INFO - 2023-06-01 10:54:43 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:43 --> Input Class Initialized
INFO - 2023-06-01 10:54:43 --> Language Class Initialized
INFO - 2023-06-01 10:54:43 --> Loader Class Initialized
INFO - 2023-06-01 10:54:43 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:43 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:43 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:43 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:43 --> Total execution time: 0.1796
INFO - 2023-06-01 10:54:53 --> Config Class Initialized
INFO - 2023-06-01 10:54:53 --> Config Class Initialized
INFO - 2023-06-01 10:54:53 --> Hooks Class Initialized
INFO - 2023-06-01 10:54:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:53 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:54:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:53 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:53 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:53 --> URI Class Initialized
INFO - 2023-06-01 10:54:53 --> URI Class Initialized
INFO - 2023-06-01 10:54:53 --> Router Class Initialized
INFO - 2023-06-01 10:54:53 --> Router Class Initialized
INFO - 2023-06-01 10:54:53 --> Output Class Initialized
INFO - 2023-06-01 10:54:53 --> Output Class Initialized
INFO - 2023-06-01 10:54:53 --> Security Class Initialized
INFO - 2023-06-01 10:54:53 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:53 --> Input Class Initialized
INFO - 2023-06-01 10:54:53 --> Input Class Initialized
INFO - 2023-06-01 10:54:53 --> Language Class Initialized
INFO - 2023-06-01 10:54:53 --> Language Class Initialized
INFO - 2023-06-01 10:54:53 --> Loader Class Initialized
INFO - 2023-06-01 10:54:53 --> Controller Class Initialized
INFO - 2023-06-01 10:54:53 --> Loader Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:53 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:53 --> Total execution time: 0.1554
INFO - 2023-06-01 10:54:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:53 --> Config Class Initialized
INFO - 2023-06-01 10:54:53 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:54:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:53 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> URI Class Initialized
INFO - 2023-06-01 10:54:53 --> Router Class Initialized
INFO - 2023-06-01 10:54:53 --> Model "Login_model" initialized
INFO - 2023-06-01 10:54:53 --> Output Class Initialized
INFO - 2023-06-01 10:54:53 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:53 --> Input Class Initialized
INFO - 2023-06-01 10:54:53 --> Language Class Initialized
INFO - 2023-06-01 10:54:53 --> Loader Class Initialized
INFO - 2023-06-01 10:54:53 --> Final output sent to browser
INFO - 2023-06-01 10:54:53 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Total execution time: 0.3367
DEBUG - 2023-06-01 10:54:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> Config Class Initialized
INFO - 2023-06-01 10:54:53 --> Hooks Class Initialized
INFO - 2023-06-01 10:54:53 --> Model "Cluster_model" initialized
DEBUG - 2023-06-01 10:54:53 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:54:53 --> Utf8 Class Initialized
INFO - 2023-06-01 10:54:53 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:53 --> Total execution time: 0.2400
INFO - 2023-06-01 10:54:53 --> URI Class Initialized
INFO - 2023-06-01 10:54:53 --> Router Class Initialized
INFO - 2023-06-01 10:54:53 --> Output Class Initialized
INFO - 2023-06-01 10:54:53 --> Security Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:54:53 --> Input Class Initialized
INFO - 2023-06-01 10:54:53 --> Language Class Initialized
INFO - 2023-06-01 10:54:53 --> Loader Class Initialized
INFO - 2023-06-01 10:54:53 --> Controller Class Initialized
DEBUG - 2023-06-01 10:54:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:54:53 --> Database Driver Class Initialized
INFO - 2023-06-01 10:54:53 --> Model "Login_model" initialized
INFO - 2023-06-01 10:54:54 --> Final output sent to browser
DEBUG - 2023-06-01 10:54:54 --> Total execution time: 0.5807
INFO - 2023-06-01 10:56:07 --> Config Class Initialized
INFO - 2023-06-01 10:56:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:07 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:07 --> URI Class Initialized
INFO - 2023-06-01 10:56:07 --> Router Class Initialized
INFO - 2023-06-01 10:56:07 --> Output Class Initialized
INFO - 2023-06-01 10:56:07 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:07 --> Input Class Initialized
INFO - 2023-06-01 10:56:07 --> Language Class Initialized
INFO - 2023-06-01 10:56:07 --> Loader Class Initialized
INFO - 2023-06-01 10:56:07 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:07 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:07 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:07 --> Total execution time: 0.3936
INFO - 2023-06-01 10:56:07 --> Config Class Initialized
INFO - 2023-06-01 10:56:07 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:07 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:07 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:07 --> URI Class Initialized
INFO - 2023-06-01 10:56:07 --> Router Class Initialized
INFO - 2023-06-01 10:56:07 --> Output Class Initialized
INFO - 2023-06-01 10:56:07 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:07 --> Input Class Initialized
INFO - 2023-06-01 10:56:07 --> Language Class Initialized
INFO - 2023-06-01 10:56:07 --> Loader Class Initialized
INFO - 2023-06-01 10:56:07 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:07 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:07 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:08 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:08 --> Total execution time: 0.2054
INFO - 2023-06-01 10:56:09 --> Config Class Initialized
INFO - 2023-06-01 10:56:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:09 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:09 --> URI Class Initialized
INFO - 2023-06-01 10:56:09 --> Router Class Initialized
INFO - 2023-06-01 10:56:09 --> Output Class Initialized
INFO - 2023-06-01 10:56:09 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:09 --> Input Class Initialized
INFO - 2023-06-01 10:56:09 --> Language Class Initialized
INFO - 2023-06-01 10:56:09 --> Loader Class Initialized
INFO - 2023-06-01 10:56:09 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:09 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:09 --> Total execution time: 0.1973
INFO - 2023-06-01 10:56:18 --> Config Class Initialized
INFO - 2023-06-01 10:56:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:18 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:18 --> URI Class Initialized
INFO - 2023-06-01 10:56:18 --> Router Class Initialized
INFO - 2023-06-01 10:56:18 --> Output Class Initialized
INFO - 2023-06-01 10:56:18 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:18 --> Input Class Initialized
INFO - 2023-06-01 10:56:18 --> Language Class Initialized
INFO - 2023-06-01 10:56:18 --> Loader Class Initialized
INFO - 2023-06-01 10:56:18 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:18 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:18 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:18 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:18 --> Total execution time: 0.1805
INFO - 2023-06-01 10:56:18 --> Config Class Initialized
INFO - 2023-06-01 10:56:18 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:18 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:18 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:18 --> URI Class Initialized
INFO - 2023-06-01 10:56:18 --> Router Class Initialized
INFO - 2023-06-01 10:56:19 --> Output Class Initialized
INFO - 2023-06-01 10:56:19 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:19 --> Input Class Initialized
INFO - 2023-06-01 10:56:19 --> Language Class Initialized
INFO - 2023-06-01 10:56:19 --> Loader Class Initialized
INFO - 2023-06-01 10:56:19 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:19 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:19 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:19 --> Model "Login_model" initialized
INFO - 2023-06-01 10:56:19 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:19 --> Total execution time: 0.2489
INFO - 2023-06-01 10:56:19 --> Config Class Initialized
INFO - 2023-06-01 10:56:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:19 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:19 --> URI Class Initialized
INFO - 2023-06-01 10:56:19 --> Router Class Initialized
INFO - 2023-06-01 10:56:19 --> Output Class Initialized
INFO - 2023-06-01 10:56:19 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:19 --> Input Class Initialized
INFO - 2023-06-01 10:56:19 --> Language Class Initialized
INFO - 2023-06-01 10:56:19 --> Loader Class Initialized
INFO - 2023-06-01 10:56:19 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:19 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:19 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:19 --> Total execution time: 0.1866
INFO - 2023-06-01 10:56:19 --> Config Class Initialized
INFO - 2023-06-01 10:56:19 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:19 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:19 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:19 --> URI Class Initialized
INFO - 2023-06-01 10:56:19 --> Router Class Initialized
INFO - 2023-06-01 10:56:19 --> Output Class Initialized
INFO - 2023-06-01 10:56:19 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:19 --> Input Class Initialized
INFO - 2023-06-01 10:56:19 --> Language Class Initialized
INFO - 2023-06-01 10:56:19 --> Loader Class Initialized
INFO - 2023-06-01 10:56:19 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:19 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:19 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:19 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:19 --> Total execution time: 0.2147
INFO - 2023-06-01 10:56:24 --> Config Class Initialized
INFO - 2023-06-01 10:56:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:24 --> URI Class Initialized
INFO - 2023-06-01 10:56:24 --> Router Class Initialized
INFO - 2023-06-01 10:56:24 --> Output Class Initialized
INFO - 2023-06-01 10:56:24 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:24 --> Input Class Initialized
INFO - 2023-06-01 10:56:24 --> Language Class Initialized
INFO - 2023-06-01 10:56:24 --> Loader Class Initialized
INFO - 2023-06-01 10:56:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:24 --> Total execution time: 0.1669
INFO - 2023-06-01 10:56:28 --> Config Class Initialized
INFO - 2023-06-01 10:56:28 --> Config Class Initialized
INFO - 2023-06-01 10:56:28 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:28 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:56:28 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:28 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:28 --> URI Class Initialized
INFO - 2023-06-01 10:56:28 --> URI Class Initialized
INFO - 2023-06-01 10:56:28 --> Router Class Initialized
INFO - 2023-06-01 10:56:28 --> Router Class Initialized
INFO - 2023-06-01 10:56:28 --> Output Class Initialized
INFO - 2023-06-01 10:56:28 --> Output Class Initialized
INFO - 2023-06-01 10:56:28 --> Security Class Initialized
INFO - 2023-06-01 10:56:28 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:29 --> Input Class Initialized
INFO - 2023-06-01 10:56:29 --> Input Class Initialized
INFO - 2023-06-01 10:56:29 --> Language Class Initialized
INFO - 2023-06-01 10:56:29 --> Language Class Initialized
INFO - 2023-06-01 10:56:29 --> Loader Class Initialized
INFO - 2023-06-01 10:56:29 --> Loader Class Initialized
INFO - 2023-06-01 10:56:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:29 --> Total execution time: 0.1492
INFO - 2023-06-01 10:56:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:29 --> Total execution time: 0.1752
INFO - 2023-06-01 10:56:29 --> Config Class Initialized
INFO - 2023-06-01 10:56:29 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:29 --> Config Class Initialized
DEBUG - 2023-06-01 10:56:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:29 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:29 --> URI Class Initialized
INFO - 2023-06-01 10:56:29 --> Router Class Initialized
DEBUG - 2023-06-01 10:56:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:29 --> URI Class Initialized
INFO - 2023-06-01 10:56:29 --> Output Class Initialized
INFO - 2023-06-01 10:56:29 --> Security Class Initialized
INFO - 2023-06-01 10:56:29 --> Router Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:29 --> Input Class Initialized
INFO - 2023-06-01 10:56:29 --> Output Class Initialized
INFO - 2023-06-01 10:56:29 --> Language Class Initialized
INFO - 2023-06-01 10:56:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:29 --> Input Class Initialized
INFO - 2023-06-01 10:56:29 --> Loader Class Initialized
INFO - 2023-06-01 10:56:29 --> Language Class Initialized
INFO - 2023-06-01 10:56:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:29 --> Loader Class Initialized
INFO - 2023-06-01 10:56:29 --> Controller Class Initialized
INFO - 2023-06-01 10:56:29 --> Database Driver Class Initialized
DEBUG - 2023-06-01 10:56:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:29 --> Total execution time: 0.2076
INFO - 2023-06-01 10:56:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:29 --> Total execution time: 0.2337
INFO - 2023-06-01 10:56:38 --> Config Class Initialized
INFO - 2023-06-01 10:56:38 --> Config Class Initialized
INFO - 2023-06-01 10:56:38 --> Config Class Initialized
INFO - 2023-06-01 10:56:38 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:38 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:38 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:38 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:56:38 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:56:38 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:38 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:38 --> URI Class Initialized
INFO - 2023-06-01 10:56:38 --> URI Class Initialized
INFO - 2023-06-01 10:56:38 --> URI Class Initialized
INFO - 2023-06-01 10:56:38 --> Router Class Initialized
INFO - 2023-06-01 10:56:38 --> Router Class Initialized
INFO - 2023-06-01 10:56:38 --> Router Class Initialized
INFO - 2023-06-01 10:56:38 --> Output Class Initialized
INFO - 2023-06-01 10:56:38 --> Output Class Initialized
INFO - 2023-06-01 10:56:38 --> Output Class Initialized
INFO - 2023-06-01 10:56:38 --> Security Class Initialized
INFO - 2023-06-01 10:56:38 --> Security Class Initialized
INFO - 2023-06-01 10:56:38 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:38 --> Input Class Initialized
INFO - 2023-06-01 10:56:38 --> Input Class Initialized
INFO - 2023-06-01 10:56:38 --> Input Class Initialized
INFO - 2023-06-01 10:56:38 --> Language Class Initialized
INFO - 2023-06-01 10:56:38 --> Language Class Initialized
INFO - 2023-06-01 10:56:38 --> Language Class Initialized
INFO - 2023-06-01 10:56:38 --> Loader Class Initialized
INFO - 2023-06-01 10:56:38 --> Loader Class Initialized
INFO - 2023-06-01 10:56:38 --> Controller Class Initialized
INFO - 2023-06-01 10:56:38 --> Controller Class Initialized
INFO - 2023-06-01 10:56:38 --> Loader Class Initialized
DEBUG - 2023-06-01 10:56:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:56:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:38 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:38 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.1721
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.1721
INFO - 2023-06-01 10:56:39 --> Config Class Initialized
INFO - 2023-06-01 10:56:39 --> Config Class Initialized
INFO - 2023-06-01 10:56:39 --> Hooks Class Initialized
INFO - 2023-06-01 10:56:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:56:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:39 --> URI Class Initialized
INFO - 2023-06-01 10:56:39 --> URI Class Initialized
INFO - 2023-06-01 10:56:39 --> Router Class Initialized
INFO - 2023-06-01 10:56:39 --> Router Class Initialized
INFO - 2023-06-01 10:56:39 --> Output Class Initialized
INFO - 2023-06-01 10:56:39 --> Output Class Initialized
INFO - 2023-06-01 10:56:39 --> Security Class Initialized
INFO - 2023-06-01 10:56:39 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:39 --> Input Class Initialized
INFO - 2023-06-01 10:56:39 --> Input Class Initialized
INFO - 2023-06-01 10:56:39 --> Language Class Initialized
INFO - 2023-06-01 10:56:39 --> Language Class Initialized
INFO - 2023-06-01 10:56:39 --> Loader Class Initialized
INFO - 2023-06-01 10:56:39 --> Loader Class Initialized
INFO - 2023-06-01 10:56:39 --> Controller Class Initialized
INFO - 2023-06-01 10:56:39 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:56:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.3525
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.1744
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.1749
INFO - 2023-06-01 10:56:39 --> Config Class Initialized
INFO - 2023-06-01 10:56:39 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:56:39 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:56:39 --> Utf8 Class Initialized
INFO - 2023-06-01 10:56:39 --> URI Class Initialized
INFO - 2023-06-01 10:56:39 --> Router Class Initialized
INFO - 2023-06-01 10:56:39 --> Output Class Initialized
INFO - 2023-06-01 10:56:39 --> Security Class Initialized
DEBUG - 2023-06-01 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:56:39 --> Input Class Initialized
INFO - 2023-06-01 10:56:39 --> Language Class Initialized
INFO - 2023-06-01 10:56:39 --> Loader Class Initialized
INFO - 2023-06-01 10:56:39 --> Controller Class Initialized
DEBUG - 2023-06-01 10:56:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:56:39 --> Database Driver Class Initialized
INFO - 2023-06-01 10:56:39 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:56:39 --> Final output sent to browser
DEBUG - 2023-06-01 10:56:39 --> Total execution time: 0.2547
INFO - 2023-06-01 10:57:02 --> Config Class Initialized
INFO - 2023-06-01 10:57:02 --> Config Class Initialized
INFO - 2023-06-01 10:57:02 --> Hooks Class Initialized
INFO - 2023-06-01 10:57:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:57:02 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:57:02 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:57:02 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:02 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:02 --> URI Class Initialized
INFO - 2023-06-01 10:57:02 --> URI Class Initialized
INFO - 2023-06-01 10:57:02 --> Router Class Initialized
INFO - 2023-06-01 10:57:02 --> Router Class Initialized
INFO - 2023-06-01 10:57:02 --> Output Class Initialized
INFO - 2023-06-01 10:57:02 --> Output Class Initialized
INFO - 2023-06-01 10:57:02 --> Security Class Initialized
INFO - 2023-06-01 10:57:02 --> Security Class Initialized
DEBUG - 2023-06-01 10:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:57:02 --> Input Class Initialized
INFO - 2023-06-01 10:57:02 --> Input Class Initialized
INFO - 2023-06-01 10:57:02 --> Language Class Initialized
INFO - 2023-06-01 10:57:02 --> Language Class Initialized
INFO - 2023-06-01 10:57:02 --> Loader Class Initialized
INFO - 2023-06-01 10:57:02 --> Loader Class Initialized
INFO - 2023-06-01 10:57:02 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:02 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:02 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:02 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:02 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:02 --> Total execution time: 0.2777
INFO - 2023-06-01 10:57:02 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:02 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:02 --> Total execution time: 0.3224
INFO - 2023-06-01 10:57:02 --> Config Class Initialized
INFO - 2023-06-01 10:57:02 --> Hooks Class Initialized
INFO - 2023-06-01 10:57:03 --> Config Class Initialized
DEBUG - 2023-06-01 10:57:03 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:57:03 --> Hooks Class Initialized
INFO - 2023-06-01 10:57:03 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:03 --> URI Class Initialized
DEBUG - 2023-06-01 10:57:03 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:57:03 --> Router Class Initialized
INFO - 2023-06-01 10:57:03 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:03 --> URI Class Initialized
INFO - 2023-06-01 10:57:03 --> Output Class Initialized
INFO - 2023-06-01 10:57:03 --> Security Class Initialized
INFO - 2023-06-01 10:57:03 --> Router Class Initialized
DEBUG - 2023-06-01 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:57:03 --> Input Class Initialized
INFO - 2023-06-01 10:57:03 --> Output Class Initialized
INFO - 2023-06-01 10:57:03 --> Security Class Initialized
INFO - 2023-06-01 10:57:03 --> Language Class Initialized
DEBUG - 2023-06-01 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:57:03 --> Input Class Initialized
INFO - 2023-06-01 10:57:03 --> Language Class Initialized
INFO - 2023-06-01 10:57:03 --> Loader Class Initialized
INFO - 2023-06-01 10:57:03 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:03 --> Loader Class Initialized
INFO - 2023-06-01 10:57:03 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:03 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:03 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:03 --> Total execution time: 0.2459
INFO - 2023-06-01 10:57:03 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:03 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:03 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:03 --> Total execution time: 0.2659
INFO - 2023-06-01 10:57:12 --> Config Class Initialized
INFO - 2023-06-01 10:57:12 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:57:12 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:57:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:13 --> URI Class Initialized
INFO - 2023-06-01 10:57:13 --> Router Class Initialized
INFO - 2023-06-01 10:57:13 --> Output Class Initialized
INFO - 2023-06-01 10:57:13 --> Security Class Initialized
DEBUG - 2023-06-01 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:57:13 --> Input Class Initialized
INFO - 2023-06-01 10:57:13 --> Language Class Initialized
INFO - 2023-06-01 10:57:13 --> Loader Class Initialized
INFO - 2023-06-01 10:57:13 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:13 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:13 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:13 --> Total execution time: 0.2009
INFO - 2023-06-01 10:57:13 --> Config Class Initialized
INFO - 2023-06-01 10:57:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:57:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:57:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:57:13 --> URI Class Initialized
INFO - 2023-06-01 10:57:13 --> Router Class Initialized
INFO - 2023-06-01 10:57:13 --> Output Class Initialized
INFO - 2023-06-01 10:57:13 --> Security Class Initialized
DEBUG - 2023-06-01 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:57:13 --> Input Class Initialized
INFO - 2023-06-01 10:57:13 --> Language Class Initialized
INFO - 2023-06-01 10:57:13 --> Loader Class Initialized
INFO - 2023-06-01 10:57:13 --> Controller Class Initialized
DEBUG - 2023-06-01 10:57:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:57:13 --> Database Driver Class Initialized
INFO - 2023-06-01 10:57:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:57:13 --> Final output sent to browser
DEBUG - 2023-06-01 10:57:13 --> Total execution time: 0.2167
INFO - 2023-06-01 10:58:08 --> Config Class Initialized
INFO - 2023-06-01 10:58:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:08 --> URI Class Initialized
INFO - 2023-06-01 10:58:08 --> Router Class Initialized
INFO - 2023-06-01 10:58:08 --> Output Class Initialized
INFO - 2023-06-01 10:58:08 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:08 --> Input Class Initialized
INFO - 2023-06-01 10:58:08 --> Language Class Initialized
INFO - 2023-06-01 10:58:08 --> Loader Class Initialized
INFO - 2023-06-01 10:58:08 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:08 --> Model "Login_model" initialized
INFO - 2023-06-01 10:58:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:08 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:08 --> Total execution time: 0.2788
INFO - 2023-06-01 10:58:08 --> Config Class Initialized
INFO - 2023-06-01 10:58:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:08 --> URI Class Initialized
INFO - 2023-06-01 10:58:08 --> Router Class Initialized
INFO - 2023-06-01 10:58:08 --> Output Class Initialized
INFO - 2023-06-01 10:58:08 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:08 --> Input Class Initialized
INFO - 2023-06-01 10:58:08 --> Language Class Initialized
INFO - 2023-06-01 10:58:08 --> Loader Class Initialized
INFO - 2023-06-01 10:58:08 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:08 --> Model "Login_model" initialized
INFO - 2023-06-01 10:58:08 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:08 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:08 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:08 --> Total execution time: 0.2933
INFO - 2023-06-01 10:58:08 --> Config Class Initialized
INFO - 2023-06-01 10:58:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:08 --> URI Class Initialized
INFO - 2023-06-01 10:58:08 --> Router Class Initialized
INFO - 2023-06-01 10:58:08 --> Output Class Initialized
INFO - 2023-06-01 10:58:08 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:08 --> Input Class Initialized
INFO - 2023-06-01 10:58:08 --> Language Class Initialized
INFO - 2023-06-01 10:58:08 --> Loader Class Initialized
INFO - 2023-06-01 10:58:08 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:08 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:08 --> Total execution time: 0.1754
INFO - 2023-06-01 10:58:08 --> Config Class Initialized
INFO - 2023-06-01 10:58:08 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:08 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:08 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:08 --> URI Class Initialized
INFO - 2023-06-01 10:58:08 --> Router Class Initialized
INFO - 2023-06-01 10:58:08 --> Output Class Initialized
INFO - 2023-06-01 10:58:08 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:08 --> Input Class Initialized
INFO - 2023-06-01 10:58:08 --> Language Class Initialized
INFO - 2023-06-01 10:58:09 --> Loader Class Initialized
INFO - 2023-06-01 10:58:09 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:09 --> Model "Login_model" initialized
INFO - 2023-06-01 10:58:09 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:09 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:09 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:09 --> Total execution time: 0.3067
INFO - 2023-06-01 10:58:13 --> Config Class Initialized
INFO - 2023-06-01 10:58:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:13 --> URI Class Initialized
INFO - 2023-06-01 10:58:13 --> Router Class Initialized
INFO - 2023-06-01 10:58:13 --> Output Class Initialized
INFO - 2023-06-01 10:58:13 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:13 --> Input Class Initialized
INFO - 2023-06-01 10:58:13 --> Language Class Initialized
INFO - 2023-06-01 10:58:13 --> Loader Class Initialized
INFO - 2023-06-01 10:58:13 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:13 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:13 --> Total execution time: 0.1289
INFO - 2023-06-01 10:58:13 --> Config Class Initialized
INFO - 2023-06-01 10:58:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:13 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:13 --> URI Class Initialized
INFO - 2023-06-01 10:58:13 --> Router Class Initialized
INFO - 2023-06-01 10:58:13 --> Output Class Initialized
INFO - 2023-06-01 10:58:13 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:13 --> Input Class Initialized
INFO - 2023-06-01 10:58:13 --> Language Class Initialized
INFO - 2023-06-01 10:58:13 --> Loader Class Initialized
INFO - 2023-06-01 10:58:13 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:13 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:13 --> Model "Login_model" initialized
INFO - 2023-06-01 10:58:13 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:13 --> Total execution time: 0.3660
INFO - 2023-06-01 10:58:16 --> Config Class Initialized
INFO - 2023-06-01 10:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:16 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:16 --> URI Class Initialized
INFO - 2023-06-01 10:58:16 --> Router Class Initialized
INFO - 2023-06-01 10:58:16 --> Output Class Initialized
INFO - 2023-06-01 10:58:16 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:16 --> Input Class Initialized
INFO - 2023-06-01 10:58:16 --> Language Class Initialized
INFO - 2023-06-01 10:58:16 --> Loader Class Initialized
INFO - 2023-06-01 10:58:16 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:16 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:16 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:16 --> Total execution time: 0.1777
INFO - 2023-06-01 10:58:16 --> Config Class Initialized
INFO - 2023-06-01 10:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:16 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:16 --> URI Class Initialized
INFO - 2023-06-01 10:58:16 --> Router Class Initialized
INFO - 2023-06-01 10:58:16 --> Output Class Initialized
INFO - 2023-06-01 10:58:16 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:16 --> Input Class Initialized
INFO - 2023-06-01 10:58:16 --> Language Class Initialized
INFO - 2023-06-01 10:58:16 --> Loader Class Initialized
INFO - 2023-06-01 10:58:16 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:16 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:16 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:16 --> Total execution time: 0.1925
INFO - 2023-06-01 10:58:16 --> Config Class Initialized
INFO - 2023-06-01 10:58:16 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:16 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:16 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:16 --> URI Class Initialized
INFO - 2023-06-01 10:58:16 --> Router Class Initialized
INFO - 2023-06-01 10:58:16 --> Output Class Initialized
INFO - 2023-06-01 10:58:16 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:16 --> Input Class Initialized
INFO - 2023-06-01 10:58:16 --> Language Class Initialized
INFO - 2023-06-01 10:58:16 --> Loader Class Initialized
INFO - 2023-06-01 10:58:16 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:16 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:16 --> Total execution time: 0.1435
INFO - 2023-06-01 10:58:17 --> Config Class Initialized
INFO - 2023-06-01 10:58:17 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:17 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:17 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:17 --> URI Class Initialized
INFO - 2023-06-01 10:58:17 --> Router Class Initialized
INFO - 2023-06-01 10:58:17 --> Output Class Initialized
INFO - 2023-06-01 10:58:17 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:17 --> Input Class Initialized
INFO - 2023-06-01 10:58:17 --> Language Class Initialized
INFO - 2023-06-01 10:58:17 --> Loader Class Initialized
INFO - 2023-06-01 10:58:17 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:17 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:17 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:17 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:17 --> Total execution time: 0.1957
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.1941
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.1934
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.2015
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
INFO - 2023-06-01 10:58:24 --> Config Class Initialized
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:24 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
DEBUG - 2023-06-01 10:58:24 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:24 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> URI Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
INFO - 2023-06-01 10:58:24 --> Router Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Output Class Initialized
INFO - 2023-06-01 10:58:24 --> Security Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
INFO - 2023-06-01 10:58:24 --> Input Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:24 --> Language Class Initialized
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Loader Class Initialized
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
INFO - 2023-06-01 10:58:24 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.1918
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.1926
DEBUG - 2023-06-01 10:58:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:24 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:24 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:24 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:24 --> Total execution time: 0.2646
INFO - 2023-06-01 10:58:29 --> Config Class Initialized
INFO - 2023-06-01 10:58:29 --> Hooks Class Initialized
DEBUG - 2023-06-01 10:58:29 --> UTF-8 Support Enabled
INFO - 2023-06-01 10:58:29 --> Utf8 Class Initialized
INFO - 2023-06-01 10:58:29 --> URI Class Initialized
INFO - 2023-06-01 10:58:29 --> Router Class Initialized
INFO - 2023-06-01 10:58:29 --> Output Class Initialized
INFO - 2023-06-01 10:58:29 --> Security Class Initialized
DEBUG - 2023-06-01 10:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 10:58:29 --> Input Class Initialized
INFO - 2023-06-01 10:58:29 --> Language Class Initialized
INFO - 2023-06-01 10:58:29 --> Loader Class Initialized
INFO - 2023-06-01 10:58:29 --> Controller Class Initialized
DEBUG - 2023-06-01 10:58:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 10:58:29 --> Database Driver Class Initialized
INFO - 2023-06-01 10:58:29 --> Model "Cluster_model" initialized
INFO - 2023-06-01 10:58:29 --> Final output sent to browser
DEBUG - 2023-06-01 10:58:29 --> Total execution time: 0.2761
INFO - 2023-06-01 12:46:02 --> Config Class Initialized
INFO - 2023-06-01 12:46:02 --> Hooks Class Initialized
DEBUG - 2023-06-01 12:46:03 --> UTF-8 Support Enabled
INFO - 2023-06-01 12:46:03 --> Utf8 Class Initialized
INFO - 2023-06-01 12:46:03 --> URI Class Initialized
INFO - 2023-06-01 12:46:03 --> Router Class Initialized
INFO - 2023-06-01 12:46:03 --> Output Class Initialized
INFO - 2023-06-01 12:46:03 --> Security Class Initialized
DEBUG - 2023-06-01 12:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 12:46:03 --> Input Class Initialized
INFO - 2023-06-01 12:46:03 --> Language Class Initialized
INFO - 2023-06-01 12:46:03 --> Loader Class Initialized
INFO - 2023-06-01 12:46:03 --> Controller Class Initialized
DEBUG - 2023-06-01 12:46:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 12:46:03 --> Database Driver Class Initialized
ERROR - 2023-06-01 12:46:13 --> Unable to connect to the database
INFO - 2023-06-01 12:46:13 --> Model "Cluster_model" initialized
INFO - 2023-06-01 12:46:13 --> Final output sent to browser
DEBUG - 2023-06-01 12:46:13 --> Total execution time: 10.5336
INFO - 2023-06-01 12:46:13 --> Config Class Initialized
INFO - 2023-06-01 12:46:13 --> Hooks Class Initialized
DEBUG - 2023-06-01 12:46:13 --> UTF-8 Support Enabled
INFO - 2023-06-01 12:46:13 --> Utf8 Class Initialized
INFO - 2023-06-01 12:46:13 --> URI Class Initialized
INFO - 2023-06-01 12:46:13 --> Router Class Initialized
INFO - 2023-06-01 12:46:13 --> Output Class Initialized
INFO - 2023-06-01 12:46:13 --> Security Class Initialized
DEBUG - 2023-06-01 12:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 12:46:13 --> Input Class Initialized
INFO - 2023-06-01 12:46:13 --> Language Class Initialized
INFO - 2023-06-01 12:46:13 --> Loader Class Initialized
INFO - 2023-06-01 12:46:14 --> Controller Class Initialized
DEBUG - 2023-06-01 12:46:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 12:46:14 --> Database Driver Class Initialized
ERROR - 2023-06-01 12:46:24 --> Unable to connect to the database
INFO - 2023-06-01 12:46:24 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 12:46:34 --> Unable to connect to the database
ERROR - 2023-06-01 12:46:34 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_cdc_server` (`id` INT NOT NULL,`host_addr` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`port` VARCHAR (8) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`master` INT DEFAULT NULL,`create_time` INT DEFAULT NULL,`status` INT DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 12:46:44 --> Unable to connect to the database
ERROR - 2023-06-01 12:46:44 --> Query error: Connection timed out - Invalid query: select * from cluster_cdc_server
INFO - 2023-06-01 12:46:44 --> Final output sent to browser
DEBUG - 2023-06-01 12:46:44 --> Total execution time: 30.6564
INFO - 2023-06-01 14:13:05 --> Config Class Initialized
INFO - 2023-06-01 14:13:05 --> Config Class Initialized
INFO - 2023-06-01 14:13:05 --> Config Class Initialized
INFO - 2023-06-01 14:13:05 --> Hooks Class Initialized
INFO - 2023-06-01 14:13:05 --> Hooks Class Initialized
INFO - 2023-06-01 14:13:05 --> Hooks Class Initialized
DEBUG - 2023-06-01 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2023-06-01 14:13:05 --> UTF-8 Support Enabled
INFO - 2023-06-01 14:13:05 --> Utf8 Class Initialized
INFO - 2023-06-01 14:13:05 --> Utf8 Class Initialized
INFO - 2023-06-01 14:13:05 --> Utf8 Class Initialized
INFO - 2023-06-01 14:13:05 --> URI Class Initialized
INFO - 2023-06-01 14:13:05 --> URI Class Initialized
INFO - 2023-06-01 14:13:05 --> URI Class Initialized
INFO - 2023-06-01 14:13:05 --> Router Class Initialized
INFO - 2023-06-01 14:13:05 --> Router Class Initialized
INFO - 2023-06-01 14:13:05 --> Router Class Initialized
INFO - 2023-06-01 14:13:05 --> Output Class Initialized
INFO - 2023-06-01 14:13:05 --> Output Class Initialized
INFO - 2023-06-01 14:13:05 --> Output Class Initialized
INFO - 2023-06-01 14:13:05 --> Security Class Initialized
INFO - 2023-06-01 14:13:05 --> Security Class Initialized
INFO - 2023-06-01 14:13:05 --> Security Class Initialized
DEBUG - 2023-06-01 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-01 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 14:13:05 --> Input Class Initialized
INFO - 2023-06-01 14:13:05 --> Input Class Initialized
INFO - 2023-06-01 14:13:05 --> Input Class Initialized
INFO - 2023-06-01 14:13:05 --> Language Class Initialized
INFO - 2023-06-01 14:13:05 --> Language Class Initialized
INFO - 2023-06-01 14:13:05 --> Language Class Initialized
INFO - 2023-06-01 14:13:05 --> Loader Class Initialized
INFO - 2023-06-01 14:13:05 --> Loader Class Initialized
INFO - 2023-06-01 14:13:05 --> Controller Class Initialized
INFO - 2023-06-01 14:13:05 --> Controller Class Initialized
DEBUG - 2023-06-01 14:13:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-01 14:13:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 14:13:05 --> Loader Class Initialized
INFO - 2023-06-01 14:13:06 --> Controller Class Initialized
DEBUG - 2023-06-01 14:13:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 14:13:06 --> Database Driver Class Initialized
INFO - 2023-06-01 14:13:06 --> Database Driver Class Initialized
INFO - 2023-06-01 14:13:06 --> Database Driver Class Initialized
INFO - 2023-06-01 14:13:06 --> Config Class Initialized
INFO - 2023-06-01 14:13:06 --> Hooks Class Initialized
DEBUG - 2023-06-01 14:13:06 --> UTF-8 Support Enabled
INFO - 2023-06-01 14:13:06 --> Utf8 Class Initialized
INFO - 2023-06-01 14:13:06 --> URI Class Initialized
INFO - 2023-06-01 14:13:06 --> Router Class Initialized
INFO - 2023-06-01 14:13:06 --> Output Class Initialized
INFO - 2023-06-01 14:13:06 --> Security Class Initialized
DEBUG - 2023-06-01 14:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 14:13:06 --> Input Class Initialized
INFO - 2023-06-01 14:13:06 --> Language Class Initialized
INFO - 2023-06-01 14:13:06 --> Loader Class Initialized
INFO - 2023-06-01 14:13:06 --> Controller Class Initialized
DEBUG - 2023-06-01 14:13:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 14:13:06 --> Database Driver Class Initialized
INFO - 2023-06-01 14:13:09 --> Config Class Initialized
INFO - 2023-06-01 14:13:09 --> Hooks Class Initialized
DEBUG - 2023-06-01 14:13:09 --> UTF-8 Support Enabled
INFO - 2023-06-01 14:13:09 --> Utf8 Class Initialized
INFO - 2023-06-01 14:13:09 --> URI Class Initialized
INFO - 2023-06-01 14:13:09 --> Router Class Initialized
INFO - 2023-06-01 14:13:09 --> Output Class Initialized
INFO - 2023-06-01 14:13:09 --> Security Class Initialized
DEBUG - 2023-06-01 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-01 14:13:09 --> Input Class Initialized
INFO - 2023-06-01 14:13:09 --> Language Class Initialized
INFO - 2023-06-01 14:13:09 --> Loader Class Initialized
INFO - 2023-06-01 14:13:09 --> Controller Class Initialized
DEBUG - 2023-06-01 14:13:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-01 14:13:09 --> Database Driver Class Initialized
ERROR - 2023-06-01 14:13:16 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:16 --> Unable to connect to the database
INFO - 2023-06-01 14:13:16 --> Model "Cluster_model" initialized
INFO - 2023-06-01 14:13:16 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 14:13:16 --> Unable to connect to the database
INFO - 2023-06-01 14:13:16 --> Database Driver Class Initialized
ERROR - 2023-06-01 14:13:16 --> Unable to connect to the database
INFO - 2023-06-01 14:13:16 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 14:13:19 --> Unable to connect to the database
INFO - 2023-06-01 14:13:19 --> Model "Cluster_model" initialized
ERROR - 2023-06-01 14:13:26 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:26 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:26 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL COMMENT '告警类型',
  `label` varchar(255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `accept_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',
  `create_at` int DEFAULT NULL,
  `push_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `threshold` tinyint DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:26 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL COMMENT '告警类型',
  `label` varchar(255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `accept_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',
  `create_at` int DEFAULT NULL,
  `push_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `threshold` tinyint DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:26 --> Unable to connect to the database
INFO - 2023-06-01 14:13:26 --> Model "Login_model" initialized
ERROR - 2023-06-01 14:13:26 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:26 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL COMMENT '告警类型',
  `label` varchar(255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `accept_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',
  `create_at` int DEFAULT NULL,
  `push_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `threshold` tinyint DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:29 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:29 --> Query error: Connection timed out - Invalid query: select id, hostaddr,rack_id,total_cpu_cores,comp_datadir,datadir,logdir,wal_log_dir,total_mem,machine_type,port_range,used_port,node_stats,installing_port from server_nodes where  machine_type is not null order by id desc limit 10 offset 0
ERROR - 2023-06-01 14:13:36 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:36 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:36 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_message_config` (`id` INT NOT NULL AUTO_INCREMENT,`message` text COLLATE utf8mb4_0900_as_cs,`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`type` VARCHAR (64) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:36 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_message_config` (`id` INT NOT NULL AUTO_INCREMENT,`message` text COLLATE utf8mb4_0900_as_cs,`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`type` VARCHAR (64) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:36 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:36 --> Query error: Connection timed out - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time from kunlun_user  where id is not null  order by id desc limit 10 offset 0
ERROR - 2023-06-01 14:13:36 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:36 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_message_config` (`id` INT NOT NULL AUTO_INCREMENT,`message` text COLLATE utf8mb4_0900_as_cs,`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`type` VARCHAR (64) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:40 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:40 --> Query error: Connection timed out - Invalid query: select count(id) as count from server_nodes where  machine_type is not null
INFO - 2023-06-01 14:13:40 --> Final output sent to browser
DEBUG - 2023-06-01 14:13:40 --> Total execution time: 30.5587
ERROR - 2023-06-01 14:13:46 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:46 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:46 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_push_log` (`id` INT NOT NULL AUTO_INCREMENT,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`push_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`content` text COLLATE utf8mb4_0900_as_cs,`content_res` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`create_at` INT DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:46 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_push_log` (`id` INT NOT NULL AUTO_INCREMENT,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`push_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`content` text COLLATE utf8mb4_0900_as_cs,`content_res` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`create_at` INT DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:46 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:46 --> Query error: Connection timed out - Invalid query: select count(id) as count from kunlun_user 
INFO - 2023-06-01 14:13:46 --> Final output sent to browser
DEBUG - 2023-06-01 14:13:46 --> Total execution time: 40.4351
ERROR - 2023-06-01 14:13:46 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:46 --> Query error: Connection timed out - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_push_log` (`id` INT NOT NULL AUTO_INCREMENT,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`push_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`content` text COLLATE utf8mb4_0900_as_cs,`content_res` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL,`create_at` INT DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-06-01 14:13:56 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:56 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:56 --> Query error: Connection timed out - Invalid query: select * from cluster_alarm_user order by id asc 
ERROR - 2023-06-01 14:13:56 --> Query error: Connection timed out - Invalid query: select TABLE_NAME from information_schema.TABLES where TABLE_NAME = 'cluster_alarm_info';
INFO - 2023-06-01 14:13:56 --> Final output sent to browser
INFO - 2023-06-01 14:13:56 --> Final output sent to browser
DEBUG - 2023-06-01 14:13:56 --> Total execution time: 50.3577
DEBUG - 2023-06-01 14:13:56 --> Total execution time: 50.3569
ERROR - 2023-06-01 14:13:56 --> Unable to connect to the database
ERROR - 2023-06-01 14:13:56 --> Query error: Connection timed out - Invalid query: select * from cluster_alarm_message_config 
INFO - 2023-06-01 14:13:56 --> Final output sent to browser
DEBUG - 2023-06-01 14:13:56 --> Total execution time: 50.5388
