<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-24 09:18:10 --> Config Class Initialized
INFO - 2023-03-24 09:18:10 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:10 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:10 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:10 --> URI Class Initialized
INFO - 2023-03-24 09:18:10 --> Router Class Initialized
INFO - 2023-03-24 09:18:10 --> Output Class Initialized
INFO - 2023-03-24 09:18:10 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:10 --> Input Class Initialized
INFO - 2023-03-24 09:18:10 --> Language Class Initialized
INFO - 2023-03-24 09:18:10 --> Loader Class Initialized
INFO - 2023-03-24 09:18:10 --> Controller Class Initialized
INFO - 2023-03-24 09:18:10 --> Helper loaded: form_helper
INFO - 2023-03-24 09:18:10 --> Helper loaded: url_helper
DEBUG - 2023-03-24 09:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:10 --> Model "Change_model" initialized
INFO - 2023-03-24 09:18:10 --> Model "Grafana_model" initialized
INFO - 2023-03-24 09:18:10 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:10 --> Total execution time: 0.0380
INFO - 2023-03-24 09:18:10 --> Config Class Initialized
INFO - 2023-03-24 09:18:10 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:10 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:10 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:10 --> URI Class Initialized
INFO - 2023-03-24 09:18:10 --> Router Class Initialized
INFO - 2023-03-24 09:18:10 --> Output Class Initialized
INFO - 2023-03-24 09:18:10 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:10 --> Input Class Initialized
INFO - 2023-03-24 09:18:10 --> Language Class Initialized
INFO - 2023-03-24 09:18:10 --> Loader Class Initialized
INFO - 2023-03-24 09:18:10 --> Controller Class Initialized
INFO - 2023-03-24 09:18:10 --> Helper loaded: form_helper
INFO - 2023-03-24 09:18:10 --> Helper loaded: url_helper
DEBUG - 2023-03-24 09:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:10 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:10 --> Total execution time: 0.0030
INFO - 2023-03-24 09:18:10 --> Config Class Initialized
INFO - 2023-03-24 09:18:10 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:10 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:10 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:10 --> URI Class Initialized
INFO - 2023-03-24 09:18:10 --> Router Class Initialized
INFO - 2023-03-24 09:18:10 --> Output Class Initialized
INFO - 2023-03-24 09:18:10 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:10 --> Input Class Initialized
INFO - 2023-03-24 09:18:10 --> Language Class Initialized
INFO - 2023-03-24 09:18:10 --> Loader Class Initialized
INFO - 2023-03-24 09:18:10 --> Controller Class Initialized
INFO - 2023-03-24 09:18:10 --> Helper loaded: form_helper
INFO - 2023-03-24 09:18:10 --> Helper loaded: url_helper
DEBUG - 2023-03-24 09:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:10 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:10 --> Model "Login_model" initialized
INFO - 2023-03-24 09:18:11 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:11 --> Total execution time: 0.0705
INFO - 2023-03-24 09:18:11 --> Config Class Initialized
INFO - 2023-03-24 09:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:11 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:11 --> URI Class Initialized
INFO - 2023-03-24 09:18:11 --> Router Class Initialized
INFO - 2023-03-24 09:18:11 --> Output Class Initialized
INFO - 2023-03-24 09:18:11 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:11 --> Input Class Initialized
INFO - 2023-03-24 09:18:11 --> Language Class Initialized
INFO - 2023-03-24 09:18:11 --> Loader Class Initialized
INFO - 2023-03-24 09:18:11 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:11 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:11 --> Total execution time: 0.0131
INFO - 2023-03-24 09:18:11 --> Config Class Initialized
INFO - 2023-03-24 09:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:11 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:11 --> URI Class Initialized
INFO - 2023-03-24 09:18:11 --> Router Class Initialized
INFO - 2023-03-24 09:18:11 --> Output Class Initialized
INFO - 2023-03-24 09:18:11 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:11 --> Input Class Initialized
INFO - 2023-03-24 09:18:11 --> Language Class Initialized
INFO - 2023-03-24 09:18:11 --> Loader Class Initialized
INFO - 2023-03-24 09:18:11 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:11 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:11 --> Total execution time: 0.0227
INFO - 2023-03-24 09:18:11 --> Config Class Initialized
INFO - 2023-03-24 09:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:11 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:11 --> URI Class Initialized
INFO - 2023-03-24 09:18:11 --> Router Class Initialized
INFO - 2023-03-24 09:18:11 --> Output Class Initialized
INFO - 2023-03-24 09:18:11 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:11 --> Input Class Initialized
INFO - 2023-03-24 09:18:11 --> Language Class Initialized
INFO - 2023-03-24 09:18:11 --> Loader Class Initialized
INFO - 2023-03-24 09:18:11 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Login_model" initialized
INFO - 2023-03-24 09:18:11 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:11 --> Total execution time: 0.0425
INFO - 2023-03-24 09:18:11 --> Config Class Initialized
INFO - 2023-03-24 09:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:11 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:11 --> URI Class Initialized
INFO - 2023-03-24 09:18:11 --> Router Class Initialized
INFO - 2023-03-24 09:18:11 --> Output Class Initialized
INFO - 2023-03-24 09:18:11 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:11 --> Input Class Initialized
INFO - 2023-03-24 09:18:11 --> Language Class Initialized
INFO - 2023-03-24 09:18:11 --> Loader Class Initialized
INFO - 2023-03-24 09:18:11 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:11 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:11 --> Model "Login_model" initialized
INFO - 2023-03-24 09:18:11 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:11 --> Total execution time: 0.0831
INFO - 2023-03-24 09:18:14 --> Config Class Initialized
INFO - 2023-03-24 09:18:14 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:14 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:14 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:14 --> URI Class Initialized
INFO - 2023-03-24 09:18:14 --> Router Class Initialized
INFO - 2023-03-24 09:18:14 --> Output Class Initialized
INFO - 2023-03-24 09:18:14 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:14 --> Input Class Initialized
INFO - 2023-03-24 09:18:14 --> Language Class Initialized
INFO - 2023-03-24 09:18:14 --> Loader Class Initialized
INFO - 2023-03-24 09:18:14 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:14 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:14 --> Total execution time: 0.0443
INFO - 2023-03-24 09:18:14 --> Config Class Initialized
INFO - 2023-03-24 09:18:14 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:14 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:14 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:14 --> URI Class Initialized
INFO - 2023-03-24 09:18:14 --> Router Class Initialized
INFO - 2023-03-24 09:18:14 --> Output Class Initialized
INFO - 2023-03-24 09:18:14 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:14 --> Input Class Initialized
INFO - 2023-03-24 09:18:14 --> Language Class Initialized
INFO - 2023-03-24 09:18:14 --> Loader Class Initialized
INFO - 2023-03-24 09:18:14 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:14 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:14 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:14 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:14 --> Total execution time: 0.0564
INFO - 2023-03-24 09:18:18 --> Config Class Initialized
INFO - 2023-03-24 09:18:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:18 --> URI Class Initialized
INFO - 2023-03-24 09:18:18 --> Router Class Initialized
INFO - 2023-03-24 09:18:18 --> Output Class Initialized
INFO - 2023-03-24 09:18:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:18 --> Input Class Initialized
INFO - 2023-03-24 09:18:18 --> Language Class Initialized
INFO - 2023-03-24 09:18:18 --> Loader Class Initialized
INFO - 2023-03-24 09:18:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:18 --> Total execution time: 0.0206
INFO - 2023-03-24 09:18:18 --> Config Class Initialized
INFO - 2023-03-24 09:18:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:18:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:18:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:18:18 --> URI Class Initialized
INFO - 2023-03-24 09:18:18 --> Router Class Initialized
INFO - 2023-03-24 09:18:18 --> Output Class Initialized
INFO - 2023-03-24 09:18:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:18:18 --> Input Class Initialized
INFO - 2023-03-24 09:18:18 --> Language Class Initialized
INFO - 2023-03-24 09:18:18 --> Loader Class Initialized
INFO - 2023-03-24 09:18:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:18:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:18:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:18:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:18:18 --> Total execution time: 0.0686
INFO - 2023-03-24 09:19:18 --> Config Class Initialized
INFO - 2023-03-24 09:19:18 --> Config Class Initialized
INFO - 2023-03-24 09:19:18 --> Hooks Class Initialized
INFO - 2023-03-24 09:19:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:19:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:19:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:19:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:19:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:19:18 --> URI Class Initialized
INFO - 2023-03-24 09:19:18 --> URI Class Initialized
INFO - 2023-03-24 09:19:18 --> Router Class Initialized
INFO - 2023-03-24 09:19:18 --> Router Class Initialized
INFO - 2023-03-24 09:19:18 --> Output Class Initialized
INFO - 2023-03-24 09:19:18 --> Output Class Initialized
INFO - 2023-03-24 09:19:18 --> Security Class Initialized
INFO - 2023-03-24 09:19:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:19:18 --> Input Class Initialized
INFO - 2023-03-24 09:19:18 --> Input Class Initialized
INFO - 2023-03-24 09:19:18 --> Language Class Initialized
INFO - 2023-03-24 09:19:18 --> Language Class Initialized
INFO - 2023-03-24 09:19:18 --> Loader Class Initialized
INFO - 2023-03-24 09:19:18 --> Loader Class Initialized
INFO - 2023-03-24 09:19:18 --> Controller Class Initialized
INFO - 2023-03-24 09:19:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:19:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:18 --> Model "Login_model" initialized
INFO - 2023-03-24 09:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:19:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:19:18 --> Total execution time: 0.0628
INFO - 2023-03-24 09:19:18 --> Config Class Initialized
INFO - 2023-03-24 09:19:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:19:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:19:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:19:18 --> URI Class Initialized
INFO - 2023-03-24 09:19:18 --> Router Class Initialized
INFO - 2023-03-24 09:19:18 --> Output Class Initialized
INFO - 2023-03-24 09:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:19:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:19:18 --> Input Class Initialized
INFO - 2023-03-24 09:19:18 --> Language Class Initialized
INFO - 2023-03-24 09:19:18 --> Loader Class Initialized
INFO - 2023-03-24 09:19:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:19:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:19:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:19:18 --> Total execution time: 0.0165
INFO - 2023-03-24 09:19:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:19:19 --> Total execution time: 0.2266
INFO - 2023-03-24 09:19:19 --> Config Class Initialized
INFO - 2023-03-24 09:19:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:19:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:19:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:19:19 --> URI Class Initialized
INFO - 2023-03-24 09:19:19 --> Router Class Initialized
INFO - 2023-03-24 09:19:19 --> Output Class Initialized
INFO - 2023-03-24 09:19:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:19:19 --> Input Class Initialized
INFO - 2023-03-24 09:19:19 --> Language Class Initialized
INFO - 2023-03-24 09:19:19 --> Loader Class Initialized
INFO - 2023-03-24 09:19:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:19:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:19:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:19:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:19:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:19:19 --> Total execution time: 0.2110
INFO - 2023-03-24 09:20:18 --> Config Class Initialized
INFO - 2023-03-24 09:20:18 --> Config Class Initialized
INFO - 2023-03-24 09:20:18 --> Hooks Class Initialized
INFO - 2023-03-24 09:20:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:20:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:18 --> Utf8 Class Initialized
DEBUG - 2023-03-24 09:20:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:18 --> URI Class Initialized
INFO - 2023-03-24 09:20:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:20:18 --> Router Class Initialized
INFO - 2023-03-24 09:20:18 --> URI Class Initialized
INFO - 2023-03-24 09:20:18 --> Output Class Initialized
INFO - 2023-03-24 09:20:18 --> Router Class Initialized
INFO - 2023-03-24 09:20:18 --> Security Class Initialized
INFO - 2023-03-24 09:20:18 --> Output Class Initialized
DEBUG - 2023-03-24 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:18 --> Security Class Initialized
INFO - 2023-03-24 09:20:18 --> Input Class Initialized
DEBUG - 2023-03-24 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:18 --> Language Class Initialized
INFO - 2023-03-24 09:20:18 --> Input Class Initialized
INFO - 2023-03-24 09:20:18 --> Language Class Initialized
INFO - 2023-03-24 09:20:18 --> Loader Class Initialized
INFO - 2023-03-24 09:20:18 --> Loader Class Initialized
INFO - 2023-03-24 09:20:18 --> Controller Class Initialized
INFO - 2023-03-24 09:20:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:20:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:18 --> Model "Login_model" initialized
INFO - 2023-03-24 09:20:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:18 --> Total execution time: 0.0262
INFO - 2023-03-24 09:20:18 --> Config Class Initialized
INFO - 2023-03-24 09:20:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:20:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:20:18 --> URI Class Initialized
INFO - 2023-03-24 09:20:18 --> Router Class Initialized
INFO - 2023-03-24 09:20:18 --> Output Class Initialized
INFO - 2023-03-24 09:20:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:18 --> Input Class Initialized
INFO - 2023-03-24 09:20:18 --> Language Class Initialized
INFO - 2023-03-24 09:20:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:18 --> Loader Class Initialized
INFO - 2023-03-24 09:20:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:20:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:20:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:18 --> Total execution time: 0.0277
INFO - 2023-03-24 09:20:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:19 --> Total execution time: 0.1955
INFO - 2023-03-24 09:20:19 --> Config Class Initialized
INFO - 2023-03-24 09:20:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:20:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:20:19 --> URI Class Initialized
INFO - 2023-03-24 09:20:19 --> Router Class Initialized
INFO - 2023-03-24 09:20:19 --> Output Class Initialized
INFO - 2023-03-24 09:20:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:19 --> Input Class Initialized
INFO - 2023-03-24 09:20:19 --> Language Class Initialized
INFO - 2023-03-24 09:20:19 --> Loader Class Initialized
INFO - 2023-03-24 09:20:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:20:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:20:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:20:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:19 --> Total execution time: 0.1750
INFO - 2023-03-24 09:20:53 --> Config Class Initialized
INFO - 2023-03-24 09:20:53 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:20:53 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:53 --> Utf8 Class Initialized
INFO - 2023-03-24 09:20:53 --> URI Class Initialized
INFO - 2023-03-24 09:20:53 --> Router Class Initialized
INFO - 2023-03-24 09:20:53 --> Output Class Initialized
INFO - 2023-03-24 09:20:53 --> Security Class Initialized
DEBUG - 2023-03-24 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:53 --> Input Class Initialized
INFO - 2023-03-24 09:20:53 --> Language Class Initialized
INFO - 2023-03-24 09:20:53 --> Loader Class Initialized
INFO - 2023-03-24 09:20:53 --> Controller Class Initialized
DEBUG - 2023-03-24 09:20:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:20:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:53 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:53 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:53 --> Total execution time: 0.0954
INFO - 2023-03-24 09:20:53 --> Config Class Initialized
INFO - 2023-03-24 09:20:53 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:20:53 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:20:53 --> Utf8 Class Initialized
INFO - 2023-03-24 09:20:53 --> URI Class Initialized
INFO - 2023-03-24 09:20:53 --> Router Class Initialized
INFO - 2023-03-24 09:20:53 --> Output Class Initialized
INFO - 2023-03-24 09:20:53 --> Security Class Initialized
DEBUG - 2023-03-24 09:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:20:53 --> Input Class Initialized
INFO - 2023-03-24 09:20:53 --> Language Class Initialized
INFO - 2023-03-24 09:20:53 --> Loader Class Initialized
INFO - 2023-03-24 09:20:53 --> Controller Class Initialized
DEBUG - 2023-03-24 09:20:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:20:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:20:54 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:20:54 --> Final output sent to browser
DEBUG - 2023-03-24 09:20:54 --> Total execution time: 0.0139
INFO - 2023-03-24 09:21:53 --> Config Class Initialized
INFO - 2023-03-24 09:21:53 --> Config Class Initialized
INFO - 2023-03-24 09:21:53 --> Hooks Class Initialized
INFO - 2023-03-24 09:21:53 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:21:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:21:53 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:21:53 --> Utf8 Class Initialized
INFO - 2023-03-24 09:21:53 --> Utf8 Class Initialized
INFO - 2023-03-24 09:21:53 --> URI Class Initialized
INFO - 2023-03-24 09:21:53 --> URI Class Initialized
INFO - 2023-03-24 09:21:53 --> Router Class Initialized
INFO - 2023-03-24 09:21:53 --> Router Class Initialized
INFO - 2023-03-24 09:21:53 --> Output Class Initialized
INFO - 2023-03-24 09:21:53 --> Output Class Initialized
INFO - 2023-03-24 09:21:53 --> Security Class Initialized
INFO - 2023-03-24 09:21:53 --> Security Class Initialized
DEBUG - 2023-03-24 09:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:21:53 --> Input Class Initialized
INFO - 2023-03-24 09:21:53 --> Input Class Initialized
INFO - 2023-03-24 09:21:53 --> Language Class Initialized
INFO - 2023-03-24 09:21:53 --> Language Class Initialized
INFO - 2023-03-24 09:21:53 --> Loader Class Initialized
INFO - 2023-03-24 09:21:53 --> Loader Class Initialized
INFO - 2023-03-24 09:21:53 --> Controller Class Initialized
INFO - 2023-03-24 09:21:53 --> Controller Class Initialized
DEBUG - 2023-03-24 09:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:21:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:53 --> Model "Login_model" initialized
INFO - 2023-03-24 09:21:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:53 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:21:53 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:21:53 --> Final output sent to browser
DEBUG - 2023-03-24 09:21:53 --> Total execution time: 0.0996
INFO - 2023-03-24 09:21:53 --> Config Class Initialized
INFO - 2023-03-24 09:21:53 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:21:53 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:21:53 --> Utf8 Class Initialized
INFO - 2023-03-24 09:21:53 --> URI Class Initialized
INFO - 2023-03-24 09:21:53 --> Router Class Initialized
INFO - 2023-03-24 09:21:53 --> Output Class Initialized
INFO - 2023-03-24 09:21:53 --> Security Class Initialized
DEBUG - 2023-03-24 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:21:53 --> Input Class Initialized
INFO - 2023-03-24 09:21:53 --> Language Class Initialized
INFO - 2023-03-24 09:21:53 --> Loader Class Initialized
INFO - 2023-03-24 09:21:53 --> Controller Class Initialized
DEBUG - 2023-03-24 09:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:21:53 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:53 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:21:53 --> Final output sent to browser
DEBUG - 2023-03-24 09:21:53 --> Total execution time: 0.0146
INFO - 2023-03-24 09:21:54 --> Final output sent to browser
DEBUG - 2023-03-24 09:21:54 --> Total execution time: 0.2406
INFO - 2023-03-24 09:21:54 --> Config Class Initialized
INFO - 2023-03-24 09:21:54 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:21:54 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:21:54 --> Utf8 Class Initialized
INFO - 2023-03-24 09:21:54 --> URI Class Initialized
INFO - 2023-03-24 09:21:54 --> Router Class Initialized
INFO - 2023-03-24 09:21:54 --> Output Class Initialized
INFO - 2023-03-24 09:21:54 --> Security Class Initialized
DEBUG - 2023-03-24 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:21:54 --> Input Class Initialized
INFO - 2023-03-24 09:21:54 --> Language Class Initialized
INFO - 2023-03-24 09:21:54 --> Loader Class Initialized
INFO - 2023-03-24 09:21:54 --> Controller Class Initialized
DEBUG - 2023-03-24 09:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:21:54 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:54 --> Model "Login_model" initialized
INFO - 2023-03-24 09:21:54 --> Database Driver Class Initialized
INFO - 2023-03-24 09:21:54 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:21:54 --> Final output sent to browser
DEBUG - 2023-03-24 09:21:54 --> Total execution time: 0.1779
INFO - 2023-03-24 09:22:17 --> Config Class Initialized
INFO - 2023-03-24 09:22:17 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:22:17 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:22:17 --> Utf8 Class Initialized
INFO - 2023-03-24 09:22:17 --> URI Class Initialized
INFO - 2023-03-24 09:22:17 --> Router Class Initialized
INFO - 2023-03-24 09:22:17 --> Output Class Initialized
INFO - 2023-03-24 09:22:17 --> Security Class Initialized
DEBUG - 2023-03-24 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:22:17 --> Input Class Initialized
INFO - 2023-03-24 09:22:17 --> Language Class Initialized
INFO - 2023-03-24 09:22:17 --> Loader Class Initialized
INFO - 2023-03-24 09:22:17 --> Controller Class Initialized
DEBUG - 2023-03-24 09:22:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:22:17 --> Database Driver Class Initialized
INFO - 2023-03-24 09:22:17 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:22:17 --> Final output sent to browser
DEBUG - 2023-03-24 09:22:17 --> Total execution time: 0.0164
INFO - 2023-03-24 09:22:17 --> Config Class Initialized
INFO - 2023-03-24 09:22:17 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:22:17 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:22:17 --> Utf8 Class Initialized
INFO - 2023-03-24 09:22:17 --> URI Class Initialized
INFO - 2023-03-24 09:22:17 --> Router Class Initialized
INFO - 2023-03-24 09:22:17 --> Output Class Initialized
INFO - 2023-03-24 09:22:17 --> Security Class Initialized
DEBUG - 2023-03-24 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:22:17 --> Input Class Initialized
INFO - 2023-03-24 09:22:17 --> Language Class Initialized
INFO - 2023-03-24 09:22:17 --> Loader Class Initialized
INFO - 2023-03-24 09:22:17 --> Controller Class Initialized
DEBUG - 2023-03-24 09:22:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:22:17 --> Database Driver Class Initialized
INFO - 2023-03-24 09:22:17 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:22:17 --> Final output sent to browser
DEBUG - 2023-03-24 09:22:17 --> Total execution time: 0.0126
INFO - 2023-03-24 09:23:12 --> Config Class Initialized
INFO - 2023-03-24 09:23:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:12 --> URI Class Initialized
INFO - 2023-03-24 09:23:12 --> Router Class Initialized
INFO - 2023-03-24 09:23:12 --> Output Class Initialized
INFO - 2023-03-24 09:23:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:12 --> Input Class Initialized
INFO - 2023-03-24 09:23:12 --> Language Class Initialized
INFO - 2023-03-24 09:23:12 --> Loader Class Initialized
INFO - 2023-03-24 09:23:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:12 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:12 --> Total execution time: 0.0513
INFO - 2023-03-24 09:23:12 --> Config Class Initialized
INFO - 2023-03-24 09:23:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:12 --> URI Class Initialized
INFO - 2023-03-24 09:23:12 --> Router Class Initialized
INFO - 2023-03-24 09:23:12 --> Output Class Initialized
INFO - 2023-03-24 09:23:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:12 --> Input Class Initialized
INFO - 2023-03-24 09:23:12 --> Language Class Initialized
INFO - 2023-03-24 09:23:12 --> Loader Class Initialized
INFO - 2023-03-24 09:23:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:12 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:12 --> Total execution time: 0.0458
INFO - 2023-03-24 09:23:17 --> Config Class Initialized
INFO - 2023-03-24 09:23:17 --> Config Class Initialized
INFO - 2023-03-24 09:23:17 --> Hooks Class Initialized
INFO - 2023-03-24 09:23:17 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:17 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:23:17 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:17 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:17 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:17 --> URI Class Initialized
INFO - 2023-03-24 09:23:17 --> URI Class Initialized
INFO - 2023-03-24 09:23:17 --> Router Class Initialized
INFO - 2023-03-24 09:23:17 --> Router Class Initialized
INFO - 2023-03-24 09:23:17 --> Output Class Initialized
INFO - 2023-03-24 09:23:17 --> Output Class Initialized
INFO - 2023-03-24 09:23:17 --> Security Class Initialized
INFO - 2023-03-24 09:23:17 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:17 --> Input Class Initialized
INFO - 2023-03-24 09:23:17 --> Input Class Initialized
INFO - 2023-03-24 09:23:17 --> Language Class Initialized
INFO - 2023-03-24 09:23:17 --> Language Class Initialized
INFO - 2023-03-24 09:23:17 --> Loader Class Initialized
INFO - 2023-03-24 09:23:17 --> Loader Class Initialized
INFO - 2023-03-24 09:23:17 --> Controller Class Initialized
INFO - 2023-03-24 09:23:17 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:23:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:17 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:17 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:17 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:17 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:17 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:17 --> Total execution time: 0.0257
INFO - 2023-03-24 09:23:17 --> Config Class Initialized
INFO - 2023-03-24 09:23:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:18 --> URI Class Initialized
INFO - 2023-03-24 09:23:18 --> Router Class Initialized
INFO - 2023-03-24 09:23:18 --> Output Class Initialized
INFO - 2023-03-24 09:23:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:18 --> Input Class Initialized
INFO - 2023-03-24 09:23:18 --> Language Class Initialized
INFO - 2023-03-24 09:23:18 --> Loader Class Initialized
INFO - 2023-03-24 09:23:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:18 --> Total execution time: 0.0514
INFO - 2023-03-24 09:23:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:18 --> Total execution time: 0.2025
INFO - 2023-03-24 09:23:18 --> Config Class Initialized
INFO - 2023-03-24 09:23:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:18 --> URI Class Initialized
INFO - 2023-03-24 09:23:18 --> Router Class Initialized
INFO - 2023-03-24 09:23:18 --> Output Class Initialized
INFO - 2023-03-24 09:23:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:18 --> Input Class Initialized
INFO - 2023-03-24 09:23:18 --> Language Class Initialized
INFO - 2023-03-24 09:23:18 --> Loader Class Initialized
INFO - 2023-03-24 09:23:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:18 --> Total execution time: 0.0178
INFO - 2023-03-24 09:23:18 --> Config Class Initialized
INFO - 2023-03-24 09:23:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:18 --> URI Class Initialized
INFO - 2023-03-24 09:23:18 --> Router Class Initialized
INFO - 2023-03-24 09:23:18 --> Output Class Initialized
INFO - 2023-03-24 09:23:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:18 --> Input Class Initialized
INFO - 2023-03-24 09:23:18 --> Language Class Initialized
INFO - 2023-03-24 09:23:18 --> Loader Class Initialized
INFO - 2023-03-24 09:23:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:18 --> Total execution time: 0.0179
INFO - 2023-03-24 09:23:20 --> Config Class Initialized
INFO - 2023-03-24 09:23:20 --> Config Class Initialized
INFO - 2023-03-24 09:23:20 --> Hooks Class Initialized
INFO - 2023-03-24 09:23:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:23:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:20 --> URI Class Initialized
INFO - 2023-03-24 09:23:20 --> URI Class Initialized
INFO - 2023-03-24 09:23:20 --> Router Class Initialized
INFO - 2023-03-24 09:23:20 --> Router Class Initialized
INFO - 2023-03-24 09:23:20 --> Output Class Initialized
INFO - 2023-03-24 09:23:20 --> Output Class Initialized
INFO - 2023-03-24 09:23:20 --> Security Class Initialized
INFO - 2023-03-24 09:23:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:20 --> Input Class Initialized
INFO - 2023-03-24 09:23:20 --> Input Class Initialized
INFO - 2023-03-24 09:23:20 --> Language Class Initialized
INFO - 2023-03-24 09:23:20 --> Language Class Initialized
INFO - 2023-03-24 09:23:20 --> Loader Class Initialized
INFO - 2023-03-24 09:23:20 --> Loader Class Initialized
INFO - 2023-03-24 09:23:20 --> Controller Class Initialized
INFO - 2023-03-24 09:23:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:20 --> Total execution time: 0.0176
INFO - 2023-03-24 09:23:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:20 --> Total execution time: 0.0242
INFO - 2023-03-24 09:23:20 --> Config Class Initialized
INFO - 2023-03-24 09:23:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:20 --> URI Class Initialized
INFO - 2023-03-24 09:23:20 --> Router Class Initialized
INFO - 2023-03-24 09:23:20 --> Output Class Initialized
INFO - 2023-03-24 09:23:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:20 --> Input Class Initialized
INFO - 2023-03-24 09:23:20 --> Language Class Initialized
INFO - 2023-03-24 09:23:20 --> Loader Class Initialized
INFO - 2023-03-24 09:23:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:20 --> Total execution time: 0.0149
INFO - 2023-03-24 09:23:21 --> Config Class Initialized
INFO - 2023-03-24 09:23:21 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:21 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:21 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:21 --> URI Class Initialized
INFO - 2023-03-24 09:23:21 --> Router Class Initialized
INFO - 2023-03-24 09:23:21 --> Output Class Initialized
INFO - 2023-03-24 09:23:21 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:21 --> Input Class Initialized
INFO - 2023-03-24 09:23:21 --> Language Class Initialized
INFO - 2023-03-24 09:23:21 --> Loader Class Initialized
INFO - 2023-03-24 09:23:21 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:21 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:21 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:21 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:21 --> Total execution time: 0.0444
INFO - 2023-03-24 09:23:21 --> Config Class Initialized
INFO - 2023-03-24 09:23:21 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:21 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:21 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:21 --> URI Class Initialized
INFO - 2023-03-24 09:23:21 --> Router Class Initialized
INFO - 2023-03-24 09:23:21 --> Output Class Initialized
INFO - 2023-03-24 09:23:21 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:21 --> Input Class Initialized
INFO - 2023-03-24 09:23:21 --> Language Class Initialized
INFO - 2023-03-24 09:23:21 --> Loader Class Initialized
INFO - 2023-03-24 09:23:21 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:21 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:21 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:21 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:21 --> Total execution time: 0.0249
INFO - 2023-03-24 09:23:24 --> Config Class Initialized
INFO - 2023-03-24 09:23:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:24 --> URI Class Initialized
INFO - 2023-03-24 09:23:24 --> Router Class Initialized
INFO - 2023-03-24 09:23:24 --> Output Class Initialized
INFO - 2023-03-24 09:23:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:24 --> Input Class Initialized
INFO - 2023-03-24 09:23:24 --> Language Class Initialized
INFO - 2023-03-24 09:23:24 --> Loader Class Initialized
INFO - 2023-03-24 09:23:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:24 --> Total execution time: 0.0213
INFO - 2023-03-24 09:23:24 --> Config Class Initialized
INFO - 2023-03-24 09:23:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:24 --> URI Class Initialized
INFO - 2023-03-24 09:23:24 --> Router Class Initialized
INFO - 2023-03-24 09:23:24 --> Output Class Initialized
INFO - 2023-03-24 09:23:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:24 --> Input Class Initialized
INFO - 2023-03-24 09:23:24 --> Language Class Initialized
INFO - 2023-03-24 09:23:24 --> Loader Class Initialized
INFO - 2023-03-24 09:23:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:24 --> Total execution time: 0.0182
INFO - 2023-03-24 09:23:28 --> Config Class Initialized
INFO - 2023-03-24 09:23:28 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:28 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:28 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:28 --> URI Class Initialized
INFO - 2023-03-24 09:23:28 --> Router Class Initialized
INFO - 2023-03-24 09:23:28 --> Output Class Initialized
INFO - 2023-03-24 09:23:28 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:28 --> Input Class Initialized
INFO - 2023-03-24 09:23:28 --> Language Class Initialized
INFO - 2023-03-24 09:23:28 --> Loader Class Initialized
INFO - 2023-03-24 09:23:28 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:28 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:28 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:28 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:28 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:28 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:28 --> Total execution time: 0.0505
INFO - 2023-03-24 09:23:28 --> Config Class Initialized
INFO - 2023-03-24 09:23:28 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:28 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:28 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:28 --> URI Class Initialized
INFO - 2023-03-24 09:23:28 --> Router Class Initialized
INFO - 2023-03-24 09:23:28 --> Output Class Initialized
INFO - 2023-03-24 09:23:28 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:28 --> Input Class Initialized
INFO - 2023-03-24 09:23:28 --> Language Class Initialized
INFO - 2023-03-24 09:23:28 --> Loader Class Initialized
INFO - 2023-03-24 09:23:28 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:28 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:28 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:28 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:28 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:28 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:28 --> Total execution time: 0.0456
INFO - 2023-03-24 09:23:30 --> Config Class Initialized
INFO - 2023-03-24 09:23:30 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:30 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:30 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:30 --> URI Class Initialized
INFO - 2023-03-24 09:23:30 --> Router Class Initialized
INFO - 2023-03-24 09:23:30 --> Output Class Initialized
INFO - 2023-03-24 09:23:30 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:30 --> Input Class Initialized
INFO - 2023-03-24 09:23:30 --> Language Class Initialized
INFO - 2023-03-24 09:23:30 --> Loader Class Initialized
INFO - 2023-03-24 09:23:30 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:30 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:30 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:30 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:30 --> Total execution time: 0.0223
INFO - 2023-03-24 09:23:30 --> Config Class Initialized
INFO - 2023-03-24 09:23:30 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:30 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:30 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:30 --> URI Class Initialized
INFO - 2023-03-24 09:23:30 --> Router Class Initialized
INFO - 2023-03-24 09:23:30 --> Output Class Initialized
INFO - 2023-03-24 09:23:30 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:30 --> Input Class Initialized
INFO - 2023-03-24 09:23:30 --> Language Class Initialized
INFO - 2023-03-24 09:23:30 --> Loader Class Initialized
INFO - 2023-03-24 09:23:30 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:30 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:30 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:30 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:30 --> Total execution time: 0.0536
INFO - 2023-03-24 09:23:31 --> Config Class Initialized
INFO - 2023-03-24 09:23:31 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:31 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:31 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:31 --> URI Class Initialized
INFO - 2023-03-24 09:23:31 --> Router Class Initialized
INFO - 2023-03-24 09:23:31 --> Output Class Initialized
INFO - 2023-03-24 09:23:31 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:31 --> Input Class Initialized
INFO - 2023-03-24 09:23:31 --> Language Class Initialized
INFO - 2023-03-24 09:23:31 --> Loader Class Initialized
INFO - 2023-03-24 09:23:31 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:31 --> Total execution time: 0.0038
INFO - 2023-03-24 09:23:31 --> Config Class Initialized
INFO - 2023-03-24 09:23:31 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:31 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:31 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:31 --> URI Class Initialized
INFO - 2023-03-24 09:23:31 --> Router Class Initialized
INFO - 2023-03-24 09:23:31 --> Output Class Initialized
INFO - 2023-03-24 09:23:31 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:31 --> Input Class Initialized
INFO - 2023-03-24 09:23:31 --> Language Class Initialized
INFO - 2023-03-24 09:23:31 --> Loader Class Initialized
INFO - 2023-03-24 09:23:31 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:31 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:31 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:31 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:31 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:31 --> Total execution time: 0.0201
INFO - 2023-03-24 09:23:31 --> Config Class Initialized
INFO - 2023-03-24 09:23:31 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:31 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:31 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:31 --> URI Class Initialized
INFO - 2023-03-24 09:23:31 --> Router Class Initialized
INFO - 2023-03-24 09:23:31 --> Output Class Initialized
INFO - 2023-03-24 09:23:31 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:31 --> Input Class Initialized
INFO - 2023-03-24 09:23:31 --> Language Class Initialized
INFO - 2023-03-24 09:23:31 --> Loader Class Initialized
INFO - 2023-03-24 09:23:31 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:31 --> Total execution time: 0.0431
INFO - 2023-03-24 09:23:31 --> Config Class Initialized
INFO - 2023-03-24 09:23:31 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:31 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:31 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:31 --> URI Class Initialized
INFO - 2023-03-24 09:23:31 --> Router Class Initialized
INFO - 2023-03-24 09:23:31 --> Output Class Initialized
INFO - 2023-03-24 09:23:31 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:31 --> Input Class Initialized
INFO - 2023-03-24 09:23:31 --> Language Class Initialized
INFO - 2023-03-24 09:23:31 --> Loader Class Initialized
INFO - 2023-03-24 09:23:31 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:31 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:31 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:31 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:31 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:31 --> Total execution time: 0.0235
INFO - 2023-03-24 09:23:46 --> Config Class Initialized
INFO - 2023-03-24 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:46 --> URI Class Initialized
INFO - 2023-03-24 09:23:46 --> Router Class Initialized
INFO - 2023-03-24 09:23:46 --> Output Class Initialized
INFO - 2023-03-24 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:46 --> Input Class Initialized
INFO - 2023-03-24 09:23:46 --> Language Class Initialized
INFO - 2023-03-24 09:23:46 --> Loader Class Initialized
INFO - 2023-03-24 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:46 --> Total execution time: 0.0354
INFO - 2023-03-24 09:23:46 --> Config Class Initialized
INFO - 2023-03-24 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:46 --> URI Class Initialized
INFO - 2023-03-24 09:23:46 --> Router Class Initialized
INFO - 2023-03-24 09:23:46 --> Output Class Initialized
INFO - 2023-03-24 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:46 --> Input Class Initialized
INFO - 2023-03-24 09:23:46 --> Language Class Initialized
INFO - 2023-03-24 09:23:46 --> Loader Class Initialized
INFO - 2023-03-24 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:46 --> Total execution time: 0.0812
INFO - 2023-03-24 09:23:49 --> Config Class Initialized
INFO - 2023-03-24 09:23:49 --> Config Class Initialized
INFO - 2023-03-24 09:23:49 --> Hooks Class Initialized
INFO - 2023-03-24 09:23:49 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:23:49 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:49 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:49 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:49 --> URI Class Initialized
INFO - 2023-03-24 09:23:49 --> URI Class Initialized
INFO - 2023-03-24 09:23:49 --> Router Class Initialized
INFO - 2023-03-24 09:23:49 --> Router Class Initialized
INFO - 2023-03-24 09:23:49 --> Output Class Initialized
INFO - 2023-03-24 09:23:49 --> Output Class Initialized
INFO - 2023-03-24 09:23:49 --> Security Class Initialized
INFO - 2023-03-24 09:23:49 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:49 --> Input Class Initialized
INFO - 2023-03-24 09:23:49 --> Input Class Initialized
INFO - 2023-03-24 09:23:49 --> Language Class Initialized
INFO - 2023-03-24 09:23:49 --> Language Class Initialized
INFO - 2023-03-24 09:23:49 --> Loader Class Initialized
INFO - 2023-03-24 09:23:49 --> Loader Class Initialized
INFO - 2023-03-24 09:23:49 --> Controller Class Initialized
INFO - 2023-03-24 09:23:49 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:23:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:49 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:49 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:49 --> Total execution time: 0.0052
INFO - 2023-03-24 09:23:49 --> Config Class Initialized
INFO - 2023-03-24 09:23:49 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:49 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:49 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:49 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:49 --> URI Class Initialized
INFO - 2023-03-24 09:23:49 --> Router Class Initialized
INFO - 2023-03-24 09:23:49 --> Output Class Initialized
INFO - 2023-03-24 09:23:49 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:49 --> Input Class Initialized
INFO - 2023-03-24 09:23:49 --> Language Class Initialized
INFO - 2023-03-24 09:23:49 --> Loader Class Initialized
INFO - 2023-03-24 09:23:49 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:49 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:49 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:49 --> Total execution time: 0.0516
INFO - 2023-03-24 09:23:49 --> Config Class Initialized
INFO - 2023-03-24 09:23:49 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:49 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:49 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:49 --> URI Class Initialized
INFO - 2023-03-24 09:23:49 --> Router Class Initialized
INFO - 2023-03-24 09:23:49 --> Output Class Initialized
INFO - 2023-03-24 09:23:49 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:49 --> Input Class Initialized
INFO - 2023-03-24 09:23:49 --> Language Class Initialized
INFO - 2023-03-24 09:23:49 --> Loader Class Initialized
INFO - 2023-03-24 09:23:49 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:49 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:49 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:49 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:49 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:49 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:49 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:49 --> Total execution time: 0.0155
INFO - 2023-03-24 09:23:49 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:49 --> Total execution time: 0.0641
INFO - 2023-03-24 09:23:55 --> Config Class Initialized
INFO - 2023-03-24 09:23:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:55 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:55 --> URI Class Initialized
INFO - 2023-03-24 09:23:55 --> Router Class Initialized
INFO - 2023-03-24 09:23:55 --> Output Class Initialized
INFO - 2023-03-24 09:23:55 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:55 --> Input Class Initialized
INFO - 2023-03-24 09:23:55 --> Language Class Initialized
INFO - 2023-03-24 09:23:55 --> Loader Class Initialized
INFO - 2023-03-24 09:23:55 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:55 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:55 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:55 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:55 --> Total execution time: 0.0308
INFO - 2023-03-24 09:23:55 --> Config Class Initialized
INFO - 2023-03-24 09:23:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:55 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:55 --> URI Class Initialized
INFO - 2023-03-24 09:23:55 --> Router Class Initialized
INFO - 2023-03-24 09:23:55 --> Output Class Initialized
INFO - 2023-03-24 09:23:55 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:55 --> Input Class Initialized
INFO - 2023-03-24 09:23:55 --> Language Class Initialized
INFO - 2023-03-24 09:23:55 --> Loader Class Initialized
INFO - 2023-03-24 09:23:55 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:55 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:55 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:55 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:55 --> Total execution time: 0.0285
INFO - 2023-03-24 09:23:58 --> Config Class Initialized
INFO - 2023-03-24 09:23:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:58 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:58 --> URI Class Initialized
INFO - 2023-03-24 09:23:58 --> Router Class Initialized
INFO - 2023-03-24 09:23:58 --> Output Class Initialized
INFO - 2023-03-24 09:23:58 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:58 --> Input Class Initialized
INFO - 2023-03-24 09:23:58 --> Language Class Initialized
INFO - 2023-03-24 09:23:58 --> Loader Class Initialized
INFO - 2023-03-24 09:23:58 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:58 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:58 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:58 --> Total execution time: 0.0725
INFO - 2023-03-24 09:23:58 --> Config Class Initialized
INFO - 2023-03-24 09:23:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:23:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:23:58 --> Utf8 Class Initialized
INFO - 2023-03-24 09:23:58 --> URI Class Initialized
INFO - 2023-03-24 09:23:58 --> Router Class Initialized
INFO - 2023-03-24 09:23:58 --> Output Class Initialized
INFO - 2023-03-24 09:23:58 --> Security Class Initialized
DEBUG - 2023-03-24 09:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:23:58 --> Input Class Initialized
INFO - 2023-03-24 09:23:58 --> Language Class Initialized
INFO - 2023-03-24 09:23:58 --> Loader Class Initialized
INFO - 2023-03-24 09:23:58 --> Controller Class Initialized
DEBUG - 2023-03-24 09:23:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:23:58 --> Database Driver Class Initialized
INFO - 2023-03-24 09:23:58 --> Model "Login_model" initialized
INFO - 2023-03-24 09:23:58 --> Final output sent to browser
DEBUG - 2023-03-24 09:23:58 --> Total execution time: 0.0420
INFO - 2023-03-24 09:24:01 --> Config Class Initialized
INFO - 2023-03-24 09:24:01 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:24:01 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:01 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:01 --> URI Class Initialized
INFO - 2023-03-24 09:24:01 --> Router Class Initialized
INFO - 2023-03-24 09:24:01 --> Output Class Initialized
INFO - 2023-03-24 09:24:01 --> Security Class Initialized
DEBUG - 2023-03-24 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:01 --> Input Class Initialized
INFO - 2023-03-24 09:24:01 --> Language Class Initialized
INFO - 2023-03-24 09:24:01 --> Loader Class Initialized
INFO - 2023-03-24 09:24:01 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:01 --> Database Driver Class Initialized
INFO - 2023-03-24 09:24:01 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:24:01 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:01 --> Total execution time: 0.0151
INFO - 2023-03-24 09:24:01 --> Config Class Initialized
INFO - 2023-03-24 09:24:01 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:24:01 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:01 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:01 --> URI Class Initialized
INFO - 2023-03-24 09:24:01 --> Router Class Initialized
INFO - 2023-03-24 09:24:01 --> Output Class Initialized
INFO - 2023-03-24 09:24:01 --> Security Class Initialized
DEBUG - 2023-03-24 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:01 --> Input Class Initialized
INFO - 2023-03-24 09:24:01 --> Language Class Initialized
INFO - 2023-03-24 09:24:01 --> Loader Class Initialized
INFO - 2023-03-24 09:24:01 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:01 --> Database Driver Class Initialized
INFO - 2023-03-24 09:24:01 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:24:01 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:01 --> Total execution time: 0.0097
INFO - 2023-03-24 09:24:06 --> Config Class Initialized
INFO - 2023-03-24 09:24:06 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:24:06 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:06 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:06 --> URI Class Initialized
INFO - 2023-03-24 09:24:06 --> Router Class Initialized
INFO - 2023-03-24 09:24:06 --> Output Class Initialized
INFO - 2023-03-24 09:24:06 --> Security Class Initialized
DEBUG - 2023-03-24 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:06 --> Input Class Initialized
INFO - 2023-03-24 09:24:06 --> Language Class Initialized
INFO - 2023-03-24 09:24:06 --> Loader Class Initialized
INFO - 2023-03-24 09:24:06 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:06 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:06 --> Total execution time: 0.0050
INFO - 2023-03-24 09:24:06 --> Config Class Initialized
INFO - 2023-03-24 09:24:06 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:24:06 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:06 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:06 --> URI Class Initialized
INFO - 2023-03-24 09:24:06 --> Router Class Initialized
INFO - 2023-03-24 09:24:06 --> Output Class Initialized
INFO - 2023-03-24 09:24:06 --> Security Class Initialized
DEBUG - 2023-03-24 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:06 --> Input Class Initialized
INFO - 2023-03-24 09:24:06 --> Language Class Initialized
INFO - 2023-03-24 09:24:06 --> Loader Class Initialized
INFO - 2023-03-24 09:24:06 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:06 --> Database Driver Class Initialized
INFO - 2023-03-24 09:24:06 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:24:06 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:06 --> Total execution time: 0.0096
INFO - 2023-03-24 09:24:08 --> Config Class Initialized
INFO - 2023-03-24 09:24:08 --> Config Class Initialized
INFO - 2023-03-24 09:24:08 --> Hooks Class Initialized
INFO - 2023-03-24 09:24:08 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:08 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:08 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:08 --> URI Class Initialized
INFO - 2023-03-24 09:24:08 --> URI Class Initialized
INFO - 2023-03-24 09:24:08 --> Router Class Initialized
INFO - 2023-03-24 09:24:08 --> Router Class Initialized
INFO - 2023-03-24 09:24:08 --> Output Class Initialized
INFO - 2023-03-24 09:24:08 --> Output Class Initialized
INFO - 2023-03-24 09:24:08 --> Security Class Initialized
INFO - 2023-03-24 09:24:08 --> Security Class Initialized
DEBUG - 2023-03-24 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:08 --> Input Class Initialized
INFO - 2023-03-24 09:24:08 --> Input Class Initialized
INFO - 2023-03-24 09:24:08 --> Language Class Initialized
INFO - 2023-03-24 09:24:08 --> Language Class Initialized
INFO - 2023-03-24 09:24:08 --> Loader Class Initialized
INFO - 2023-03-24 09:24:08 --> Loader Class Initialized
INFO - 2023-03-24 09:24:08 --> Controller Class Initialized
INFO - 2023-03-24 09:24:08 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:08 --> Final output sent to browser
INFO - 2023-03-24 09:24:08 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:08 --> Total execution time: 0.0038
DEBUG - 2023-03-24 09:24:08 --> Total execution time: 0.0039
INFO - 2023-03-24 09:24:08 --> Config Class Initialized
INFO - 2023-03-24 09:24:08 --> Hooks Class Initialized
INFO - 2023-03-24 09:24:08 --> Config Class Initialized
DEBUG - 2023-03-24 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:08 --> Hooks Class Initialized
INFO - 2023-03-24 09:24:08 --> Utf8 Class Initialized
INFO - 2023-03-24 09:24:08 --> URI Class Initialized
INFO - 2023-03-24 09:24:08 --> Router Class Initialized
INFO - 2023-03-24 09:24:08 --> Output Class Initialized
DEBUG - 2023-03-24 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:24:08 --> Security Class Initialized
INFO - 2023-03-24 09:24:08 --> Utf8 Class Initialized
DEBUG - 2023-03-24 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:24:08 --> URI Class Initialized
INFO - 2023-03-24 09:24:08 --> Input Class Initialized
INFO - 2023-03-24 09:24:08 --> Language Class Initialized
INFO - 2023-03-24 09:24:08 --> Router Class Initialized
INFO - 2023-03-24 09:24:08 --> Output Class Initialized
INFO - 2023-03-24 09:24:08 --> Loader Class Initialized
INFO - 2023-03-24 09:24:08 --> Security Class Initialized
INFO - 2023-03-24 09:24:08 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:08 --> Input Class Initialized
INFO - 2023-03-24 09:24:08 --> Database Driver Class Initialized
INFO - 2023-03-24 09:24:08 --> Language Class Initialized
INFO - 2023-03-24 09:24:08 --> Loader Class Initialized
INFO - 2023-03-24 09:24:08 --> Controller Class Initialized
DEBUG - 2023-03-24 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:24:08 --> Database Driver Class Initialized
INFO - 2023-03-24 09:24:08 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:24:08 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:24:08 --> Final output sent to browser
INFO - 2023-03-24 09:24:08 --> Final output sent to browser
DEBUG - 2023-03-24 09:24:08 --> Total execution time: 0.0190
DEBUG - 2023-03-24 09:24:08 --> Total execution time: 0.0191
INFO - 2023-03-24 09:25:21 --> Config Class Initialized
INFO - 2023-03-24 09:25:21 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:21 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:21 --> URI Class Initialized
INFO - 2023-03-24 09:25:21 --> Router Class Initialized
INFO - 2023-03-24 09:25:21 --> Output Class Initialized
INFO - 2023-03-24 09:25:21 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:21 --> Input Class Initialized
INFO - 2023-03-24 09:25:21 --> Language Class Initialized
INFO - 2023-03-24 09:25:21 --> Loader Class Initialized
INFO - 2023-03-24 09:25:21 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:21 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:21 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:21 --> Total execution time: 0.0122
INFO - 2023-03-24 09:25:21 --> Config Class Initialized
INFO - 2023-03-24 09:25:21 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:21 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:21 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:21 --> URI Class Initialized
INFO - 2023-03-24 09:25:21 --> Router Class Initialized
INFO - 2023-03-24 09:25:21 --> Output Class Initialized
INFO - 2023-03-24 09:25:21 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:21 --> Input Class Initialized
INFO - 2023-03-24 09:25:21 --> Language Class Initialized
INFO - 2023-03-24 09:25:21 --> Loader Class Initialized
INFO - 2023-03-24 09:25:21 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:21 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:21 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:21 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:21 --> Total execution time: 0.0093
INFO - 2023-03-24 09:25:23 --> Config Class Initialized
INFO - 2023-03-24 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:23 --> URI Class Initialized
INFO - 2023-03-24 09:25:23 --> Router Class Initialized
INFO - 2023-03-24 09:25:23 --> Output Class Initialized
INFO - 2023-03-24 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:23 --> Input Class Initialized
INFO - 2023-03-24 09:25:23 --> Language Class Initialized
INFO - 2023-03-24 09:25:23 --> Loader Class Initialized
INFO - 2023-03-24 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:23 --> Total execution time: 0.0129
INFO - 2023-03-24 09:25:23 --> Config Class Initialized
INFO - 2023-03-24 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:23 --> URI Class Initialized
INFO - 2023-03-24 09:25:23 --> Router Class Initialized
INFO - 2023-03-24 09:25:23 --> Output Class Initialized
INFO - 2023-03-24 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:23 --> Input Class Initialized
INFO - 2023-03-24 09:25:23 --> Language Class Initialized
INFO - 2023-03-24 09:25:23 --> Loader Class Initialized
INFO - 2023-03-24 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:23 --> Total execution time: 0.0113
INFO - 2023-03-24 09:25:23 --> Config Class Initialized
INFO - 2023-03-24 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:23 --> URI Class Initialized
INFO - 2023-03-24 09:25:23 --> Router Class Initialized
INFO - 2023-03-24 09:25:23 --> Output Class Initialized
INFO - 2023-03-24 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:23 --> Input Class Initialized
INFO - 2023-03-24 09:25:23 --> Language Class Initialized
INFO - 2023-03-24 09:25:23 --> Loader Class Initialized
INFO - 2023-03-24 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:23 --> Total execution time: 0.0162
INFO - 2023-03-24 09:25:23 --> Config Class Initialized
INFO - 2023-03-24 09:25:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:23 --> URI Class Initialized
INFO - 2023-03-24 09:25:23 --> Router Class Initialized
INFO - 2023-03-24 09:25:23 --> Output Class Initialized
INFO - 2023-03-24 09:25:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:23 --> Input Class Initialized
INFO - 2023-03-24 09:25:23 --> Language Class Initialized
INFO - 2023-03-24 09:25:23 --> Loader Class Initialized
INFO - 2023-03-24 09:25:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:23 --> Total execution time: 0.0120
INFO - 2023-03-24 09:25:24 --> Config Class Initialized
INFO - 2023-03-24 09:25:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:24 --> URI Class Initialized
INFO - 2023-03-24 09:25:24 --> Router Class Initialized
INFO - 2023-03-24 09:25:24 --> Output Class Initialized
INFO - 2023-03-24 09:25:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:24 --> Input Class Initialized
INFO - 2023-03-24 09:25:24 --> Language Class Initialized
INFO - 2023-03-24 09:25:24 --> Loader Class Initialized
INFO - 2023-03-24 09:25:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:24 --> Total execution time: 0.0222
INFO - 2023-03-24 09:25:24 --> Config Class Initialized
INFO - 2023-03-24 09:25:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:24 --> URI Class Initialized
INFO - 2023-03-24 09:25:24 --> Router Class Initialized
INFO - 2023-03-24 09:25:24 --> Output Class Initialized
INFO - 2023-03-24 09:25:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:24 --> Input Class Initialized
INFO - 2023-03-24 09:25:24 --> Language Class Initialized
INFO - 2023-03-24 09:25:24 --> Loader Class Initialized
INFO - 2023-03-24 09:25:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:24 --> Total execution time: 0.0198
INFO - 2023-03-24 09:25:26 --> Config Class Initialized
INFO - 2023-03-24 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:26 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:26 --> URI Class Initialized
INFO - 2023-03-24 09:25:26 --> Router Class Initialized
INFO - 2023-03-24 09:25:26 --> Output Class Initialized
INFO - 2023-03-24 09:25:26 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:26 --> Input Class Initialized
INFO - 2023-03-24 09:25:26 --> Language Class Initialized
INFO - 2023-03-24 09:25:26 --> Loader Class Initialized
INFO - 2023-03-24 09:25:26 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:26 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:26 --> Total execution time: 0.0059
INFO - 2023-03-24 09:25:26 --> Config Class Initialized
INFO - 2023-03-24 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:25:26 --> Utf8 Class Initialized
INFO - 2023-03-24 09:25:26 --> URI Class Initialized
INFO - 2023-03-24 09:25:26 --> Router Class Initialized
INFO - 2023-03-24 09:25:26 --> Output Class Initialized
INFO - 2023-03-24 09:25:26 --> Security Class Initialized
DEBUG - 2023-03-24 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:25:26 --> Input Class Initialized
INFO - 2023-03-24 09:25:26 --> Language Class Initialized
INFO - 2023-03-24 09:25:26 --> Loader Class Initialized
INFO - 2023-03-24 09:25:26 --> Controller Class Initialized
DEBUG - 2023-03-24 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:25:26 --> Database Driver Class Initialized
INFO - 2023-03-24 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:25:26 --> Final output sent to browser
DEBUG - 2023-03-24 09:25:26 --> Total execution time: 0.0532
INFO - 2023-03-24 09:26:13 --> Config Class Initialized
INFO - 2023-03-24 09:26:13 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:26:13 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:26:13 --> Utf8 Class Initialized
INFO - 2023-03-24 09:26:13 --> URI Class Initialized
INFO - 2023-03-24 09:26:13 --> Router Class Initialized
INFO - 2023-03-24 09:26:13 --> Output Class Initialized
INFO - 2023-03-24 09:26:13 --> Security Class Initialized
DEBUG - 2023-03-24 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:26:13 --> Input Class Initialized
INFO - 2023-03-24 09:26:13 --> Language Class Initialized
INFO - 2023-03-24 09:26:13 --> Loader Class Initialized
INFO - 2023-03-24 09:26:13 --> Controller Class Initialized
DEBUG - 2023-03-24 09:26:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:26:13 --> Database Driver Class Initialized
INFO - 2023-03-24 09:26:13 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:26:13 --> Final output sent to browser
DEBUG - 2023-03-24 09:26:13 --> Total execution time: 0.0221
INFO - 2023-03-24 09:26:13 --> Config Class Initialized
INFO - 2023-03-24 09:26:13 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:26:13 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:26:13 --> Utf8 Class Initialized
INFO - 2023-03-24 09:26:13 --> URI Class Initialized
INFO - 2023-03-24 09:26:13 --> Router Class Initialized
INFO - 2023-03-24 09:26:13 --> Output Class Initialized
INFO - 2023-03-24 09:26:13 --> Security Class Initialized
DEBUG - 2023-03-24 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:26:13 --> Input Class Initialized
INFO - 2023-03-24 09:26:13 --> Language Class Initialized
INFO - 2023-03-24 09:26:13 --> Loader Class Initialized
INFO - 2023-03-24 09:26:13 --> Controller Class Initialized
DEBUG - 2023-03-24 09:26:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:26:13 --> Database Driver Class Initialized
INFO - 2023-03-24 09:26:13 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:26:13 --> Final output sent to browser
DEBUG - 2023-03-24 09:26:13 --> Total execution time: 0.0209
INFO - 2023-03-24 09:26:16 --> Config Class Initialized
INFO - 2023-03-24 09:26:16 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:26:16 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:26:16 --> Utf8 Class Initialized
INFO - 2023-03-24 09:26:16 --> URI Class Initialized
INFO - 2023-03-24 09:26:16 --> Router Class Initialized
INFO - 2023-03-24 09:26:16 --> Output Class Initialized
INFO - 2023-03-24 09:26:16 --> Security Class Initialized
DEBUG - 2023-03-24 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:26:16 --> Input Class Initialized
INFO - 2023-03-24 09:26:16 --> Language Class Initialized
INFO - 2023-03-24 09:26:16 --> Loader Class Initialized
INFO - 2023-03-24 09:26:16 --> Controller Class Initialized
DEBUG - 2023-03-24 09:26:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:26:16 --> Final output sent to browser
DEBUG - 2023-03-24 09:26:16 --> Total execution time: 0.0024
INFO - 2023-03-24 09:26:16 --> Config Class Initialized
INFO - 2023-03-24 09:26:16 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:26:16 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:26:16 --> Utf8 Class Initialized
INFO - 2023-03-24 09:26:16 --> URI Class Initialized
INFO - 2023-03-24 09:26:16 --> Router Class Initialized
INFO - 2023-03-24 09:26:16 --> Output Class Initialized
INFO - 2023-03-24 09:26:16 --> Security Class Initialized
DEBUG - 2023-03-24 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:26:16 --> Input Class Initialized
INFO - 2023-03-24 09:26:16 --> Language Class Initialized
INFO - 2023-03-24 09:26:16 --> Loader Class Initialized
INFO - 2023-03-24 09:26:16 --> Controller Class Initialized
DEBUG - 2023-03-24 09:26:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:26:16 --> Database Driver Class Initialized
INFO - 2023-03-24 09:26:16 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:26:16 --> Final output sent to browser
DEBUG - 2023-03-24 09:26:16 --> Total execution time: 0.0160
INFO - 2023-03-24 09:29:16 --> Config Class Initialized
INFO - 2023-03-24 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:16 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:16 --> URI Class Initialized
INFO - 2023-03-24 09:29:16 --> Router Class Initialized
INFO - 2023-03-24 09:29:16 --> Output Class Initialized
INFO - 2023-03-24 09:29:16 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:16 --> Input Class Initialized
INFO - 2023-03-24 09:29:16 --> Language Class Initialized
INFO - 2023-03-24 09:29:16 --> Loader Class Initialized
INFO - 2023-03-24 09:29:16 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:16 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:16 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:16 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:16 --> Total execution time: 0.0191
INFO - 2023-03-24 09:29:16 --> Config Class Initialized
INFO - 2023-03-24 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:16 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:16 --> URI Class Initialized
INFO - 2023-03-24 09:29:16 --> Router Class Initialized
INFO - 2023-03-24 09:29:16 --> Output Class Initialized
INFO - 2023-03-24 09:29:16 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:16 --> Input Class Initialized
INFO - 2023-03-24 09:29:16 --> Language Class Initialized
INFO - 2023-03-24 09:29:16 --> Loader Class Initialized
INFO - 2023-03-24 09:29:16 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:16 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:16 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:16 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:16 --> Total execution time: 0.0189
INFO - 2023-03-24 09:29:20 --> Config Class Initialized
INFO - 2023-03-24 09:29:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:20 --> URI Class Initialized
INFO - 2023-03-24 09:29:20 --> Router Class Initialized
INFO - 2023-03-24 09:29:20 --> Output Class Initialized
INFO - 2023-03-24 09:29:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:20 --> Input Class Initialized
INFO - 2023-03-24 09:29:20 --> Language Class Initialized
INFO - 2023-03-24 09:29:20 --> Loader Class Initialized
INFO - 2023-03-24 09:29:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:20 --> Total execution time: 0.0197
INFO - 2023-03-24 09:29:20 --> Config Class Initialized
INFO - 2023-03-24 09:29:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:20 --> URI Class Initialized
INFO - 2023-03-24 09:29:20 --> Router Class Initialized
INFO - 2023-03-24 09:29:20 --> Output Class Initialized
INFO - 2023-03-24 09:29:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:20 --> Input Class Initialized
INFO - 2023-03-24 09:29:20 --> Language Class Initialized
INFO - 2023-03-24 09:29:20 --> Loader Class Initialized
INFO - 2023-03-24 09:29:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:20 --> Total execution time: 0.0150
INFO - 2023-03-24 09:29:23 --> Config Class Initialized
INFO - 2023-03-24 09:29:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:23 --> URI Class Initialized
INFO - 2023-03-24 09:29:23 --> Router Class Initialized
INFO - 2023-03-24 09:29:23 --> Output Class Initialized
INFO - 2023-03-24 09:29:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:23 --> Input Class Initialized
INFO - 2023-03-24 09:29:23 --> Language Class Initialized
INFO - 2023-03-24 09:29:23 --> Loader Class Initialized
INFO - 2023-03-24 09:29:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:23 --> Total execution time: 0.0221
INFO - 2023-03-24 09:29:23 --> Config Class Initialized
INFO - 2023-03-24 09:29:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:23 --> URI Class Initialized
INFO - 2023-03-24 09:29:23 --> Router Class Initialized
INFO - 2023-03-24 09:29:23 --> Output Class Initialized
INFO - 2023-03-24 09:29:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:23 --> Input Class Initialized
INFO - 2023-03-24 09:29:23 --> Language Class Initialized
INFO - 2023-03-24 09:29:23 --> Loader Class Initialized
INFO - 2023-03-24 09:29:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:23 --> Total execution time: 0.0242
INFO - 2023-03-24 09:29:28 --> Config Class Initialized
INFO - 2023-03-24 09:29:28 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:28 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:28 --> URI Class Initialized
INFO - 2023-03-24 09:29:28 --> Router Class Initialized
INFO - 2023-03-24 09:29:28 --> Output Class Initialized
INFO - 2023-03-24 09:29:28 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:28 --> Input Class Initialized
INFO - 2023-03-24 09:29:28 --> Language Class Initialized
INFO - 2023-03-24 09:29:28 --> Loader Class Initialized
INFO - 2023-03-24 09:29:28 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:28 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:28 --> Total execution time: 0.0089
INFO - 2023-03-24 09:29:28 --> Config Class Initialized
INFO - 2023-03-24 09:29:28 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:28 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:28 --> URI Class Initialized
INFO - 2023-03-24 09:29:28 --> Router Class Initialized
INFO - 2023-03-24 09:29:28 --> Output Class Initialized
INFO - 2023-03-24 09:29:28 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:28 --> Input Class Initialized
INFO - 2023-03-24 09:29:28 --> Language Class Initialized
INFO - 2023-03-24 09:29:28 --> Loader Class Initialized
INFO - 2023-03-24 09:29:28 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:28 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:28 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:28 --> Model "Mysql_model" initialized
INFO - 2023-03-24 09:29:28 --> Model "Grafana_model" initialized
INFO - 2023-03-24 09:29:28 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:28 --> Total execution time: 0.0216
INFO - 2023-03-24 09:29:35 --> Config Class Initialized
INFO - 2023-03-24 09:29:35 --> Config Class Initialized
INFO - 2023-03-24 09:29:35 --> Hooks Class Initialized
INFO - 2023-03-24 09:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:35 --> URI Class Initialized
INFO - 2023-03-24 09:29:35 --> URI Class Initialized
INFO - 2023-03-24 09:29:35 --> Router Class Initialized
INFO - 2023-03-24 09:29:35 --> Router Class Initialized
INFO - 2023-03-24 09:29:35 --> Output Class Initialized
INFO - 2023-03-24 09:29:35 --> Output Class Initialized
INFO - 2023-03-24 09:29:35 --> Security Class Initialized
INFO - 2023-03-24 09:29:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:35 --> Input Class Initialized
INFO - 2023-03-24 09:29:35 --> Input Class Initialized
INFO - 2023-03-24 09:29:35 --> Language Class Initialized
INFO - 2023-03-24 09:29:35 --> Language Class Initialized
INFO - 2023-03-24 09:29:35 --> Loader Class Initialized
INFO - 2023-03-24 09:29:35 --> Loader Class Initialized
INFO - 2023-03-24 09:29:35 --> Controller Class Initialized
INFO - 2023-03-24 09:29:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:35 --> Final output sent to browser
INFO - 2023-03-24 09:29:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:35 --> Total execution time: 0.0045
DEBUG - 2023-03-24 09:29:35 --> Total execution time: 0.0046
INFO - 2023-03-24 09:29:35 --> Config Class Initialized
INFO - 2023-03-24 09:29:35 --> Config Class Initialized
INFO - 2023-03-24 09:29:35 --> Hooks Class Initialized
INFO - 2023-03-24 09:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:35 --> URI Class Initialized
INFO - 2023-03-24 09:29:35 --> URI Class Initialized
INFO - 2023-03-24 09:29:35 --> Router Class Initialized
INFO - 2023-03-24 09:29:35 --> Router Class Initialized
INFO - 2023-03-24 09:29:35 --> Output Class Initialized
INFO - 2023-03-24 09:29:35 --> Output Class Initialized
INFO - 2023-03-24 09:29:35 --> Security Class Initialized
INFO - 2023-03-24 09:29:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:35 --> Input Class Initialized
INFO - 2023-03-24 09:29:35 --> Input Class Initialized
INFO - 2023-03-24 09:29:35 --> Language Class Initialized
INFO - 2023-03-24 09:29:35 --> Language Class Initialized
INFO - 2023-03-24 09:29:35 --> Loader Class Initialized
INFO - 2023-03-24 09:29:35 --> Loader Class Initialized
INFO - 2023-03-24 09:29:35 --> Controller Class Initialized
INFO - 2023-03-24 09:29:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:35 --> Final output sent to browser
INFO - 2023-03-24 09:29:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:35 --> Total execution time: 0.0127
DEBUG - 2023-03-24 09:29:35 --> Total execution time: 0.0127
INFO - 2023-03-24 09:29:43 --> Config Class Initialized
INFO - 2023-03-24 09:29:43 --> Config Class Initialized
INFO - 2023-03-24 09:29:43 --> Hooks Class Initialized
INFO - 2023-03-24 09:29:43 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:29:43 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:43 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:43 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:43 --> URI Class Initialized
INFO - 2023-03-24 09:29:43 --> URI Class Initialized
INFO - 2023-03-24 09:29:43 --> Router Class Initialized
INFO - 2023-03-24 09:29:43 --> Router Class Initialized
INFO - 2023-03-24 09:29:43 --> Output Class Initialized
INFO - 2023-03-24 09:29:43 --> Output Class Initialized
INFO - 2023-03-24 09:29:43 --> Security Class Initialized
INFO - 2023-03-24 09:29:43 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:43 --> Input Class Initialized
INFO - 2023-03-24 09:29:43 --> Input Class Initialized
INFO - 2023-03-24 09:29:43 --> Language Class Initialized
INFO - 2023-03-24 09:29:43 --> Language Class Initialized
INFO - 2023-03-24 09:29:43 --> Loader Class Initialized
INFO - 2023-03-24 09:29:43 --> Loader Class Initialized
INFO - 2023-03-24 09:29:43 --> Controller Class Initialized
INFO - 2023-03-24 09:29:43 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:43 --> Final output sent to browser
INFO - 2023-03-24 09:29:43 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:43 --> Total execution time: 0.0058
DEBUG - 2023-03-24 09:29:43 --> Total execution time: 0.0058
INFO - 2023-03-24 09:29:43 --> Config Class Initialized
INFO - 2023-03-24 09:29:43 --> Config Class Initialized
INFO - 2023-03-24 09:29:43 --> Hooks Class Initialized
INFO - 2023-03-24 09:29:43 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:29:43 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:29:43 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:43 --> Utf8 Class Initialized
INFO - 2023-03-24 09:29:43 --> URI Class Initialized
INFO - 2023-03-24 09:29:43 --> URI Class Initialized
INFO - 2023-03-24 09:29:43 --> Router Class Initialized
INFO - 2023-03-24 09:29:43 --> Router Class Initialized
INFO - 2023-03-24 09:29:43 --> Output Class Initialized
INFO - 2023-03-24 09:29:43 --> Output Class Initialized
INFO - 2023-03-24 09:29:43 --> Security Class Initialized
INFO - 2023-03-24 09:29:43 --> Security Class Initialized
DEBUG - 2023-03-24 09:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:29:43 --> Input Class Initialized
INFO - 2023-03-24 09:29:43 --> Input Class Initialized
INFO - 2023-03-24 09:29:43 --> Language Class Initialized
INFO - 2023-03-24 09:29:43 --> Language Class Initialized
INFO - 2023-03-24 09:29:43 --> Loader Class Initialized
INFO - 2023-03-24 09:29:43 --> Loader Class Initialized
INFO - 2023-03-24 09:29:43 --> Controller Class Initialized
INFO - 2023-03-24 09:29:43 --> Controller Class Initialized
DEBUG - 2023-03-24 09:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:29:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:29:43 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:43 --> Database Driver Class Initialized
INFO - 2023-03-24 09:29:43 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:43 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:29:43 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:43 --> Total execution time: 0.0108
INFO - 2023-03-24 09:29:43 --> Final output sent to browser
DEBUG - 2023-03-24 09:29:43 --> Total execution time: 0.0124
INFO - 2023-03-24 09:30:19 --> Config Class Initialized
INFO - 2023-03-24 09:30:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:30:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:30:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:30:19 --> URI Class Initialized
INFO - 2023-03-24 09:30:19 --> Router Class Initialized
INFO - 2023-03-24 09:30:19 --> Output Class Initialized
INFO - 2023-03-24 09:30:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:30:19 --> Input Class Initialized
INFO - 2023-03-24 09:30:19 --> Language Class Initialized
INFO - 2023-03-24 09:30:19 --> Loader Class Initialized
INFO - 2023-03-24 09:30:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:30:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:30:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:30:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:30:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:30:19 --> Total execution time: 0.0175
INFO - 2023-03-24 09:30:19 --> Config Class Initialized
INFO - 2023-03-24 09:30:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:30:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:30:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:30:19 --> URI Class Initialized
INFO - 2023-03-24 09:30:19 --> Router Class Initialized
INFO - 2023-03-24 09:30:19 --> Output Class Initialized
INFO - 2023-03-24 09:30:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:30:19 --> Input Class Initialized
INFO - 2023-03-24 09:30:19 --> Language Class Initialized
INFO - 2023-03-24 09:30:19 --> Loader Class Initialized
INFO - 2023-03-24 09:30:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:30:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:30:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:30:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:30:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:30:19 --> Total execution time: 0.0168
INFO - 2023-03-24 09:31:19 --> Config Class Initialized
INFO - 2023-03-24 09:31:19 --> Config Class Initialized
INFO - 2023-03-24 09:31:19 --> Hooks Class Initialized
INFO - 2023-03-24 09:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:31:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:19 --> URI Class Initialized
INFO - 2023-03-24 09:31:19 --> URI Class Initialized
INFO - 2023-03-24 09:31:19 --> Router Class Initialized
INFO - 2023-03-24 09:31:19 --> Router Class Initialized
INFO - 2023-03-24 09:31:19 --> Output Class Initialized
INFO - 2023-03-24 09:31:19 --> Output Class Initialized
INFO - 2023-03-24 09:31:19 --> Security Class Initialized
INFO - 2023-03-24 09:31:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:31:19 --> Input Class Initialized
INFO - 2023-03-24 09:31:19 --> Input Class Initialized
INFO - 2023-03-24 09:31:19 --> Language Class Initialized
INFO - 2023-03-24 09:31:19 --> Language Class Initialized
INFO - 2023-03-24 09:31:19 --> Loader Class Initialized
INFO - 2023-03-24 09:31:19 --> Loader Class Initialized
INFO - 2023-03-24 09:31:19 --> Controller Class Initialized
INFO - 2023-03-24 09:31:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:31:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:19 --> Total execution time: 0.0213
INFO - 2023-03-24 09:31:19 --> Config Class Initialized
INFO - 2023-03-24 09:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:31:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:19 --> URI Class Initialized
INFO - 2023-03-24 09:31:19 --> Router Class Initialized
INFO - 2023-03-24 09:31:19 --> Output Class Initialized
INFO - 2023-03-24 09:31:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:31:19 --> Input Class Initialized
INFO - 2023-03-24 09:31:19 --> Language Class Initialized
INFO - 2023-03-24 09:31:19 --> Loader Class Initialized
INFO - 2023-03-24 09:31:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:19 --> Total execution time: 0.0148
INFO - 2023-03-24 09:31:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:19 --> Total execution time: 0.1826
INFO - 2023-03-24 09:31:19 --> Config Class Initialized
INFO - 2023-03-24 09:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:31:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:19 --> URI Class Initialized
INFO - 2023-03-24 09:31:19 --> Router Class Initialized
INFO - 2023-03-24 09:31:19 --> Output Class Initialized
INFO - 2023-03-24 09:31:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:31:19 --> Input Class Initialized
INFO - 2023-03-24 09:31:19 --> Language Class Initialized
INFO - 2023-03-24 09:31:19 --> Loader Class Initialized
INFO - 2023-03-24 09:31:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:31:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:19 --> Total execution time: 0.1596
INFO - 2023-03-24 09:31:30 --> Config Class Initialized
INFO - 2023-03-24 09:31:30 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:31:30 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:31:30 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:30 --> URI Class Initialized
INFO - 2023-03-24 09:31:30 --> Router Class Initialized
INFO - 2023-03-24 09:31:30 --> Output Class Initialized
INFO - 2023-03-24 09:31:30 --> Security Class Initialized
DEBUG - 2023-03-24 09:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:31:30 --> Input Class Initialized
INFO - 2023-03-24 09:31:30 --> Language Class Initialized
INFO - 2023-03-24 09:31:30 --> Loader Class Initialized
INFO - 2023-03-24 09:31:30 --> Controller Class Initialized
DEBUG - 2023-03-24 09:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:31:30 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:30 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:31 --> Total execution time: 0.0352
INFO - 2023-03-24 09:31:31 --> Config Class Initialized
INFO - 2023-03-24 09:31:31 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:31:31 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:31:31 --> Utf8 Class Initialized
INFO - 2023-03-24 09:31:31 --> URI Class Initialized
INFO - 2023-03-24 09:31:31 --> Router Class Initialized
INFO - 2023-03-24 09:31:31 --> Output Class Initialized
INFO - 2023-03-24 09:31:31 --> Security Class Initialized
DEBUG - 2023-03-24 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:31:31 --> Input Class Initialized
INFO - 2023-03-24 09:31:31 --> Language Class Initialized
INFO - 2023-03-24 09:31:31 --> Loader Class Initialized
INFO - 2023-03-24 09:31:31 --> Controller Class Initialized
DEBUG - 2023-03-24 09:31:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:31:31 --> Database Driver Class Initialized
INFO - 2023-03-24 09:31:31 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:31:31 --> Final output sent to browser
DEBUG - 2023-03-24 09:31:31 --> Total execution time: 0.0572
INFO - 2023-03-24 09:32:12 --> Config Class Initialized
INFO - 2023-03-24 09:32:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:32:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:32:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:32:12 --> URI Class Initialized
INFO - 2023-03-24 09:32:12 --> Router Class Initialized
INFO - 2023-03-24 09:32:12 --> Output Class Initialized
INFO - 2023-03-24 09:32:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:32:12 --> Input Class Initialized
INFO - 2023-03-24 09:32:12 --> Language Class Initialized
INFO - 2023-03-24 09:32:12 --> Loader Class Initialized
INFO - 2023-03-24 09:32:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:32:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:32:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:32:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:32:12 --> Total execution time: 0.1025
INFO - 2023-03-24 09:32:12 --> Config Class Initialized
INFO - 2023-03-24 09:32:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:32:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:32:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:32:12 --> URI Class Initialized
INFO - 2023-03-24 09:32:12 --> Router Class Initialized
INFO - 2023-03-24 09:32:12 --> Output Class Initialized
INFO - 2023-03-24 09:32:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:32:12 --> Input Class Initialized
INFO - 2023-03-24 09:32:12 --> Language Class Initialized
INFO - 2023-03-24 09:32:12 --> Loader Class Initialized
INFO - 2023-03-24 09:32:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:32:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:32:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:32:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:32:12 --> Total execution time: 0.0132
INFO - 2023-03-24 09:33:12 --> Config Class Initialized
INFO - 2023-03-24 09:33:12 --> Hooks Class Initialized
INFO - 2023-03-24 09:33:12 --> Config Class Initialized
DEBUG - 2023-03-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:12 --> Hooks Class Initialized
INFO - 2023-03-24 09:33:12 --> Utf8 Class Initialized
DEBUG - 2023-03-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:12 --> URI Class Initialized
INFO - 2023-03-24 09:33:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:33:12 --> Router Class Initialized
INFO - 2023-03-24 09:33:12 --> URI Class Initialized
INFO - 2023-03-24 09:33:12 --> Output Class Initialized
INFO - 2023-03-24 09:33:12 --> Router Class Initialized
INFO - 2023-03-24 09:33:12 --> Security Class Initialized
INFO - 2023-03-24 09:33:12 --> Output Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:12 --> Security Class Initialized
INFO - 2023-03-24 09:33:12 --> Input Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:12 --> Language Class Initialized
INFO - 2023-03-24 09:33:12 --> Input Class Initialized
INFO - 2023-03-24 09:33:12 --> Language Class Initialized
INFO - 2023-03-24 09:33:12 --> Loader Class Initialized
INFO - 2023-03-24 09:33:12 --> Loader Class Initialized
INFO - 2023-03-24 09:33:12 --> Controller Class Initialized
INFO - 2023-03-24 09:33:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:33:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:33:12 --> Model "Login_model" initialized
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:12 --> Total execution time: 0.0211
INFO - 2023-03-24 09:33:12 --> Config Class Initialized
INFO - 2023-03-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:33:12 --> URI Class Initialized
INFO - 2023-03-24 09:33:12 --> Router Class Initialized
INFO - 2023-03-24 09:33:12 --> Output Class Initialized
INFO - 2023-03-24 09:33:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:12 --> Input Class Initialized
INFO - 2023-03-24 09:33:12 --> Language Class Initialized
INFO - 2023-03-24 09:33:12 --> Loader Class Initialized
INFO - 2023-03-24 09:33:12 --> Controller Class Initialized
INFO - 2023-03-24 09:33:12 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 09:33:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:33:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:12 --> Total execution time: 0.0153
INFO - 2023-03-24 09:33:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:12 --> Total execution time: 0.1611
INFO - 2023-03-24 09:33:12 --> Config Class Initialized
INFO - 2023-03-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:33:12 --> URI Class Initialized
INFO - 2023-03-24 09:33:12 --> Router Class Initialized
INFO - 2023-03-24 09:33:12 --> Output Class Initialized
INFO - 2023-03-24 09:33:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:12 --> Input Class Initialized
INFO - 2023-03-24 09:33:12 --> Language Class Initialized
INFO - 2023-03-24 09:33:12 --> Loader Class Initialized
INFO - 2023-03-24 09:33:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:33:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Model "Login_model" initialized
INFO - 2023-03-24 09:33:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:33:13 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:13 --> Total execution time: 0.1928
INFO - 2023-03-24 09:33:48 --> Config Class Initialized
INFO - 2023-03-24 09:33:48 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:48 --> Utf8 Class Initialized
INFO - 2023-03-24 09:33:48 --> URI Class Initialized
INFO - 2023-03-24 09:33:48 --> Router Class Initialized
INFO - 2023-03-24 09:33:48 --> Output Class Initialized
INFO - 2023-03-24 09:33:48 --> Security Class Initialized
DEBUG - 2023-03-24 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:48 --> Input Class Initialized
INFO - 2023-03-24 09:33:48 --> Language Class Initialized
INFO - 2023-03-24 09:33:48 --> Loader Class Initialized
INFO - 2023-03-24 09:33:48 --> Controller Class Initialized
DEBUG - 2023-03-24 09:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:33:48 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:33:48 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:48 --> Total execution time: 0.0237
INFO - 2023-03-24 09:33:48 --> Config Class Initialized
INFO - 2023-03-24 09:33:48 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:33:48 --> Utf8 Class Initialized
INFO - 2023-03-24 09:33:48 --> URI Class Initialized
INFO - 2023-03-24 09:33:48 --> Router Class Initialized
INFO - 2023-03-24 09:33:48 --> Output Class Initialized
INFO - 2023-03-24 09:33:48 --> Security Class Initialized
DEBUG - 2023-03-24 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:33:48 --> Input Class Initialized
INFO - 2023-03-24 09:33:48 --> Language Class Initialized
INFO - 2023-03-24 09:33:48 --> Loader Class Initialized
INFO - 2023-03-24 09:33:48 --> Controller Class Initialized
DEBUG - 2023-03-24 09:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:33:48 --> Database Driver Class Initialized
INFO - 2023-03-24 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:33:48 --> Final output sent to browser
DEBUG - 2023-03-24 09:33:48 --> Total execution time: 0.0168
INFO - 2023-03-24 09:34:23 --> Config Class Initialized
INFO - 2023-03-24 09:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:34:23 --> URI Class Initialized
INFO - 2023-03-24 09:34:23 --> Router Class Initialized
INFO - 2023-03-24 09:34:23 --> Output Class Initialized
INFO - 2023-03-24 09:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:34:23 --> Input Class Initialized
INFO - 2023-03-24 09:34:23 --> Language Class Initialized
INFO - 2023-03-24 09:34:23 --> Loader Class Initialized
INFO - 2023-03-24 09:34:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:34:23 --> Total execution time: 0.0205
INFO - 2023-03-24 09:34:23 --> Config Class Initialized
INFO - 2023-03-24 09:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:34:23 --> URI Class Initialized
INFO - 2023-03-24 09:34:23 --> Router Class Initialized
INFO - 2023-03-24 09:34:23 --> Output Class Initialized
INFO - 2023-03-24 09:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:34:23 --> Input Class Initialized
INFO - 2023-03-24 09:34:23 --> Language Class Initialized
INFO - 2023-03-24 09:34:23 --> Loader Class Initialized
INFO - 2023-03-24 09:34:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:34:23 --> Total execution time: 0.0151
INFO - 2023-03-24 09:35:23 --> Config Class Initialized
INFO - 2023-03-24 09:35:23 --> Config Class Initialized
INFO - 2023-03-24 09:35:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:35:23 --> URI Class Initialized
INFO - 2023-03-24 09:35:23 --> URI Class Initialized
INFO - 2023-03-24 09:35:23 --> Router Class Initialized
INFO - 2023-03-24 09:35:23 --> Router Class Initialized
INFO - 2023-03-24 09:35:23 --> Output Class Initialized
INFO - 2023-03-24 09:35:23 --> Output Class Initialized
INFO - 2023-03-24 09:35:23 --> Security Class Initialized
INFO - 2023-03-24 09:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:35:23 --> Input Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:35:23 --> Language Class Initialized
INFO - 2023-03-24 09:35:23 --> Input Class Initialized
INFO - 2023-03-24 09:35:23 --> Language Class Initialized
INFO - 2023-03-24 09:35:23 --> Loader Class Initialized
INFO - 2023-03-24 09:35:23 --> Loader Class Initialized
INFO - 2023-03-24 09:35:23 --> Controller Class Initialized
INFO - 2023-03-24 09:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:35:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:35:23 --> Total execution time: 0.0209
INFO - 2023-03-24 09:35:23 --> Config Class Initialized
INFO - 2023-03-24 09:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:35:23 --> URI Class Initialized
INFO - 2023-03-24 09:35:23 --> Router Class Initialized
INFO - 2023-03-24 09:35:23 --> Output Class Initialized
INFO - 2023-03-24 09:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:35:23 --> Input Class Initialized
INFO - 2023-03-24 09:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:35:23 --> Language Class Initialized
INFO - 2023-03-24 09:35:23 --> Loader Class Initialized
INFO - 2023-03-24 09:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:35:23 --> Total execution time: 0.0139
INFO - 2023-03-24 09:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:35:23 --> Total execution time: 0.1622
INFO - 2023-03-24 09:35:23 --> Config Class Initialized
INFO - 2023-03-24 09:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:35:23 --> URI Class Initialized
INFO - 2023-03-24 09:35:23 --> Router Class Initialized
INFO - 2023-03-24 09:35:23 --> Output Class Initialized
INFO - 2023-03-24 09:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:35:23 --> Input Class Initialized
INFO - 2023-03-24 09:35:23 --> Language Class Initialized
INFO - 2023-03-24 09:35:23 --> Loader Class Initialized
INFO - 2023-03-24 09:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:35:23 --> Total execution time: 0.1559
INFO - 2023-03-24 09:36:23 --> Config Class Initialized
INFO - 2023-03-24 09:36:23 --> Config Class Initialized
INFO - 2023-03-24 09:36:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:36:23 --> URI Class Initialized
INFO - 2023-03-24 09:36:23 --> URI Class Initialized
INFO - 2023-03-24 09:36:23 --> Router Class Initialized
INFO - 2023-03-24 09:36:23 --> Router Class Initialized
INFO - 2023-03-24 09:36:23 --> Output Class Initialized
INFO - 2023-03-24 09:36:23 --> Output Class Initialized
INFO - 2023-03-24 09:36:23 --> Security Class Initialized
INFO - 2023-03-24 09:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:36:23 --> Input Class Initialized
INFO - 2023-03-24 09:36:23 --> Input Class Initialized
INFO - 2023-03-24 09:36:23 --> Language Class Initialized
INFO - 2023-03-24 09:36:23 --> Language Class Initialized
INFO - 2023-03-24 09:36:23 --> Loader Class Initialized
INFO - 2023-03-24 09:36:23 --> Loader Class Initialized
INFO - 2023-03-24 09:36:23 --> Controller Class Initialized
INFO - 2023-03-24 09:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:36:23 --> Total execution time: 0.0236
INFO - 2023-03-24 09:36:23 --> Config Class Initialized
INFO - 2023-03-24 09:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:36:23 --> URI Class Initialized
INFO - 2023-03-24 09:36:23 --> Router Class Initialized
INFO - 2023-03-24 09:36:23 --> Output Class Initialized
INFO - 2023-03-24 09:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:36:23 --> Input Class Initialized
INFO - 2023-03-24 09:36:23 --> Language Class Initialized
INFO - 2023-03-24 09:36:23 --> Loader Class Initialized
INFO - 2023-03-24 09:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:36:23 --> Total execution time: 0.0563
INFO - 2023-03-24 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:36:23 --> Total execution time: 0.2160
INFO - 2023-03-24 09:36:23 --> Config Class Initialized
INFO - 2023-03-24 09:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:36:23 --> URI Class Initialized
INFO - 2023-03-24 09:36:23 --> Router Class Initialized
INFO - 2023-03-24 09:36:23 --> Output Class Initialized
INFO - 2023-03-24 09:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:36:23 --> Input Class Initialized
INFO - 2023-03-24 09:36:23 --> Language Class Initialized
INFO - 2023-03-24 09:36:23 --> Loader Class Initialized
INFO - 2023-03-24 09:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:36:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:36:24 --> Total execution time: 0.1599
INFO - 2023-03-24 09:37:23 --> Config Class Initialized
INFO - 2023-03-24 09:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:37:23 --> URI Class Initialized
INFO - 2023-03-24 09:37:23 --> Router Class Initialized
INFO - 2023-03-24 09:37:23 --> Output Class Initialized
INFO - 2023-03-24 09:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:37:23 --> Input Class Initialized
INFO - 2023-03-24 09:37:23 --> Language Class Initialized
INFO - 2023-03-24 09:37:23 --> Loader Class Initialized
INFO - 2023-03-24 09:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:37:23 --> Config Class Initialized
INFO - 2023-03-24 09:37:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 09:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:37:23 --> URI Class Initialized
INFO - 2023-03-24 09:37:23 --> Router Class Initialized
INFO - 2023-03-24 09:37:23 --> Output Class Initialized
INFO - 2023-03-24 09:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:37:23 --> Input Class Initialized
INFO - 2023-03-24 09:37:23 --> Language Class Initialized
INFO - 2023-03-24 09:37:23 --> Loader Class Initialized
INFO - 2023-03-24 09:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:37:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:37:23 --> Total execution time: 0.0172
INFO - 2023-03-24 09:37:23 --> Config Class Initialized
INFO - 2023-03-24 09:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:37:23 --> URI Class Initialized
INFO - 2023-03-24 09:37:23 --> Router Class Initialized
INFO - 2023-03-24 09:37:23 --> Output Class Initialized
INFO - 2023-03-24 09:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:37:23 --> Input Class Initialized
INFO - 2023-03-24 09:37:23 --> Language Class Initialized
INFO - 2023-03-24 09:37:23 --> Loader Class Initialized
INFO - 2023-03-24 09:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:37:23 --> Total execution time: 0.0144
INFO - 2023-03-24 09:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:37:23 --> Total execution time: 0.1639
INFO - 2023-03-24 09:37:23 --> Config Class Initialized
INFO - 2023-03-24 09:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:37:23 --> URI Class Initialized
INFO - 2023-03-24 09:37:23 --> Router Class Initialized
INFO - 2023-03-24 09:37:23 --> Output Class Initialized
INFO - 2023-03-24 09:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:37:23 --> Input Class Initialized
INFO - 2023-03-24 09:37:23 --> Language Class Initialized
INFO - 2023-03-24 09:37:23 --> Loader Class Initialized
INFO - 2023-03-24 09:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:37:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:37:23 --> Total execution time: 0.1561
INFO - 2023-03-24 09:38:23 --> Config Class Initialized
INFO - 2023-03-24 09:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:38:23 --> URI Class Initialized
INFO - 2023-03-24 09:38:23 --> Router Class Initialized
INFO - 2023-03-24 09:38:23 --> Output Class Initialized
INFO - 2023-03-24 09:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:38:23 --> Input Class Initialized
INFO - 2023-03-24 09:38:23 --> Language Class Initialized
INFO - 2023-03-24 09:38:23 --> Loader Class Initialized
INFO - 2023-03-24 09:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:38:23 --> Config Class Initialized
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:38:23 --> URI Class Initialized
INFO - 2023-03-24 09:38:23 --> Router Class Initialized
INFO - 2023-03-24 09:38:23 --> Output Class Initialized
INFO - 2023-03-24 09:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:38:23 --> Input Class Initialized
INFO - 2023-03-24 09:38:23 --> Language Class Initialized
INFO - 2023-03-24 09:38:23 --> Loader Class Initialized
INFO - 2023-03-24 09:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:38:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:38:23 --> Total execution time: 0.0188
INFO - 2023-03-24 09:38:23 --> Config Class Initialized
INFO - 2023-03-24 09:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:38:23 --> URI Class Initialized
INFO - 2023-03-24 09:38:23 --> Router Class Initialized
INFO - 2023-03-24 09:38:23 --> Output Class Initialized
INFO - 2023-03-24 09:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:38:23 --> Input Class Initialized
INFO - 2023-03-24 09:38:23 --> Language Class Initialized
INFO - 2023-03-24 09:38:23 --> Loader Class Initialized
INFO - 2023-03-24 09:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:38:23 --> Total execution time: 0.0151
INFO - 2023-03-24 09:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:38:23 --> Total execution time: 0.1906
INFO - 2023-03-24 09:38:23 --> Config Class Initialized
INFO - 2023-03-24 09:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:38:23 --> URI Class Initialized
INFO - 2023-03-24 09:38:23 --> Router Class Initialized
INFO - 2023-03-24 09:38:23 --> Output Class Initialized
INFO - 2023-03-24 09:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:38:23 --> Input Class Initialized
INFO - 2023-03-24 09:38:23 --> Language Class Initialized
INFO - 2023-03-24 09:38:23 --> Loader Class Initialized
INFO - 2023-03-24 09:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:38:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:38:24 --> Total execution time: 0.1856
INFO - 2023-03-24 09:39:23 --> Config Class Initialized
INFO - 2023-03-24 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:39:23 --> URI Class Initialized
INFO - 2023-03-24 09:39:23 --> Router Class Initialized
INFO - 2023-03-24 09:39:23 --> Output Class Initialized
INFO - 2023-03-24 09:39:23 --> Security Class Initialized
INFO - 2023-03-24 09:39:23 --> Config Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:39:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:39:23 --> Input Class Initialized
DEBUG - 2023-03-24 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:39:23 --> Language Class Initialized
INFO - 2023-03-24 09:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:39:23 --> Loader Class Initialized
INFO - 2023-03-24 09:39:23 --> URI Class Initialized
INFO - 2023-03-24 09:39:23 --> Controller Class Initialized
INFO - 2023-03-24 09:39:23 --> Router Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:39:23 --> Output Class Initialized
INFO - 2023-03-24 09:39:23 --> Security Class Initialized
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:39:23 --> Input Class Initialized
INFO - 2023-03-24 09:39:23 --> Language Class Initialized
INFO - 2023-03-24 09:39:23 --> Loader Class Initialized
INFO - 2023-03-24 09:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:39:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:39:23 --> Total execution time: 0.0281
INFO - 2023-03-24 09:39:23 --> Config Class Initialized
INFO - 2023-03-24 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:39:23 --> URI Class Initialized
INFO - 2023-03-24 09:39:23 --> Router Class Initialized
INFO - 2023-03-24 09:39:23 --> Output Class Initialized
INFO - 2023-03-24 09:39:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:39:23 --> Input Class Initialized
INFO - 2023-03-24 09:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:39:23 --> Language Class Initialized
INFO - 2023-03-24 09:39:23 --> Loader Class Initialized
INFO - 2023-03-24 09:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:39:23 --> Total execution time: 0.0155
INFO - 2023-03-24 09:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:39:23 --> Total execution time: 0.1845
INFO - 2023-03-24 09:39:23 --> Config Class Initialized
INFO - 2023-03-24 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:39:23 --> URI Class Initialized
INFO - 2023-03-24 09:39:23 --> Router Class Initialized
INFO - 2023-03-24 09:39:23 --> Output Class Initialized
INFO - 2023-03-24 09:39:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:39:23 --> Input Class Initialized
INFO - 2023-03-24 09:39:23 --> Language Class Initialized
INFO - 2023-03-24 09:39:23 --> Loader Class Initialized
INFO - 2023-03-24 09:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:39:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:39:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:39:24 --> Total execution time: 0.1824
INFO - 2023-03-24 09:40:23 --> Config Class Initialized
INFO - 2023-03-24 09:40:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:40:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:40:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:40:23 --> URI Class Initialized
INFO - 2023-03-24 09:40:23 --> Router Class Initialized
INFO - 2023-03-24 09:40:23 --> Output Class Initialized
INFO - 2023-03-24 09:40:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:40:23 --> Input Class Initialized
INFO - 2023-03-24 09:40:23 --> Language Class Initialized
INFO - 2023-03-24 09:40:23 --> Config Class Initialized
INFO - 2023-03-24 09:40:23 --> Loader Class Initialized
INFO - 2023-03-24 09:40:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:40:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:40:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:40:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:40:23 --> URI Class Initialized
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Router Class Initialized
INFO - 2023-03-24 09:40:23 --> Output Class Initialized
INFO - 2023-03-24 09:40:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:40:23 --> Input Class Initialized
INFO - 2023-03-24 09:40:23 --> Language Class Initialized
INFO - 2023-03-24 09:40:23 --> Loader Class Initialized
INFO - 2023-03-24 09:40:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:40:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:40:23 --> Total execution time: 0.0325
INFO - 2023-03-24 09:40:23 --> Config Class Initialized
INFO - 2023-03-24 09:40:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:40:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:40:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:40:23 --> URI Class Initialized
INFO - 2023-03-24 09:40:23 --> Router Class Initialized
INFO - 2023-03-24 09:40:23 --> Output Class Initialized
INFO - 2023-03-24 09:40:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:40:23 --> Input Class Initialized
INFO - 2023-03-24 09:40:23 --> Language Class Initialized
INFO - 2023-03-24 09:40:23 --> Loader Class Initialized
INFO - 2023-03-24 09:40:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:40:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:40:23 --> Total execution time: 0.0192
INFO - 2023-03-24 09:40:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:40:23 --> Total execution time: 0.1977
INFO - 2023-03-24 09:40:23 --> Config Class Initialized
INFO - 2023-03-24 09:40:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:40:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:40:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:40:23 --> URI Class Initialized
INFO - 2023-03-24 09:40:23 --> Router Class Initialized
INFO - 2023-03-24 09:40:23 --> Output Class Initialized
INFO - 2023-03-24 09:40:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:40:23 --> Input Class Initialized
INFO - 2023-03-24 09:40:23 --> Language Class Initialized
INFO - 2023-03-24 09:40:23 --> Loader Class Initialized
INFO - 2023-03-24 09:40:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:40:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:40:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:40:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:40:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:40:24 --> Total execution time: 0.2143
INFO - 2023-03-24 09:41:23 --> Config Class Initialized
INFO - 2023-03-24 09:41:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:41:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:41:23 --> Config Class Initialized
INFO - 2023-03-24 09:41:23 --> URI Class Initialized
INFO - 2023-03-24 09:41:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:41:23 --> Router Class Initialized
DEBUG - 2023-03-24 09:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:41:23 --> Output Class Initialized
INFO - 2023-03-24 09:41:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:41:23 --> Security Class Initialized
INFO - 2023-03-24 09:41:23 --> URI Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:41:23 --> Router Class Initialized
INFO - 2023-03-24 09:41:23 --> Input Class Initialized
INFO - 2023-03-24 09:41:23 --> Output Class Initialized
INFO - 2023-03-24 09:41:23 --> Language Class Initialized
INFO - 2023-03-24 09:41:23 --> Security Class Initialized
INFO - 2023-03-24 09:41:23 --> Loader Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:41:23 --> Input Class Initialized
INFO - 2023-03-24 09:41:23 --> Controller Class Initialized
INFO - 2023-03-24 09:41:23 --> Language Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:41:23 --> Loader Class Initialized
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:41:23 --> Total execution time: 0.0184
INFO - 2023-03-24 09:41:23 --> Config Class Initialized
INFO - 2023-03-24 09:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:41:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:41:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:41:23 --> URI Class Initialized
INFO - 2023-03-24 09:41:23 --> Router Class Initialized
INFO - 2023-03-24 09:41:23 --> Output Class Initialized
INFO - 2023-03-24 09:41:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:41:23 --> Input Class Initialized
INFO - 2023-03-24 09:41:23 --> Language Class Initialized
INFO - 2023-03-24 09:41:23 --> Loader Class Initialized
INFO - 2023-03-24 09:41:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:41:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:41:23 --> Total execution time: 0.0567
INFO - 2023-03-24 09:41:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:41:23 --> Total execution time: 0.2119
INFO - 2023-03-24 09:41:23 --> Config Class Initialized
INFO - 2023-03-24 09:41:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:41:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:41:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:41:23 --> URI Class Initialized
INFO - 2023-03-24 09:41:23 --> Router Class Initialized
INFO - 2023-03-24 09:41:23 --> Output Class Initialized
INFO - 2023-03-24 09:41:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:41:23 --> Input Class Initialized
INFO - 2023-03-24 09:41:23 --> Language Class Initialized
INFO - 2023-03-24 09:41:23 --> Loader Class Initialized
INFO - 2023-03-24 09:41:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:41:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:41:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:41:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:41:24 --> Total execution time: 0.1671
INFO - 2023-03-24 09:42:23 --> Config Class Initialized
INFO - 2023-03-24 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:42:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:42:23 --> Config Class Initialized
INFO - 2023-03-24 09:42:23 --> URI Class Initialized
INFO - 2023-03-24 09:42:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:42:23 --> Router Class Initialized
DEBUG - 2023-03-24 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:42:23 --> Output Class Initialized
INFO - 2023-03-24 09:42:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:42:23 --> Security Class Initialized
INFO - 2023-03-24 09:42:23 --> URI Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:42:23 --> Router Class Initialized
INFO - 2023-03-24 09:42:23 --> Input Class Initialized
INFO - 2023-03-24 09:42:23 --> Output Class Initialized
INFO - 2023-03-24 09:42:23 --> Language Class Initialized
INFO - 2023-03-24 09:42:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:42:23 --> Loader Class Initialized
INFO - 2023-03-24 09:42:23 --> Input Class Initialized
INFO - 2023-03-24 09:42:23 --> Controller Class Initialized
INFO - 2023-03-24 09:42:23 --> Language Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:42:23 --> Loader Class Initialized
INFO - 2023-03-24 09:42:23 --> Controller Class Initialized
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:42:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:42:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:42:23 --> Total execution time: 0.0189
INFO - 2023-03-24 09:42:23 --> Config Class Initialized
INFO - 2023-03-24 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:42:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:42:23 --> URI Class Initialized
INFO - 2023-03-24 09:42:23 --> Router Class Initialized
INFO - 2023-03-24 09:42:23 --> Output Class Initialized
INFO - 2023-03-24 09:42:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:42:23 --> Input Class Initialized
INFO - 2023-03-24 09:42:23 --> Language Class Initialized
INFO - 2023-03-24 09:42:23 --> Loader Class Initialized
INFO - 2023-03-24 09:42:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:42:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:42:23 --> Total execution time: 0.0549
INFO - 2023-03-24 09:42:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:42:23 --> Total execution time: 0.2007
INFO - 2023-03-24 09:42:23 --> Config Class Initialized
INFO - 2023-03-24 09:42:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:42:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:42:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:42:23 --> URI Class Initialized
INFO - 2023-03-24 09:42:23 --> Router Class Initialized
INFO - 2023-03-24 09:42:23 --> Output Class Initialized
INFO - 2023-03-24 09:42:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:42:23 --> Input Class Initialized
INFO - 2023-03-24 09:42:23 --> Language Class Initialized
INFO - 2023-03-24 09:42:23 --> Loader Class Initialized
INFO - 2023-03-24 09:42:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:42:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:42:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:42:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:42:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:42:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:42:24 --> Total execution time: 0.1596
INFO - 2023-03-24 09:43:23 --> Config Class Initialized
INFO - 2023-03-24 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:43:23 --> URI Class Initialized
INFO - 2023-03-24 09:43:23 --> Router Class Initialized
INFO - 2023-03-24 09:43:23 --> Output Class Initialized
INFO - 2023-03-24 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:43:23 --> Input Class Initialized
INFO - 2023-03-24 09:43:23 --> Language Class Initialized
INFO - 2023-03-24 09:43:23 --> Loader Class Initialized
INFO - 2023-03-24 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Config Class Initialized
INFO - 2023-03-24 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:43:23 --> URI Class Initialized
INFO - 2023-03-24 09:43:23 --> Router Class Initialized
INFO - 2023-03-24 09:43:23 --> Output Class Initialized
INFO - 2023-03-24 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:43:23 --> Input Class Initialized
INFO - 2023-03-24 09:43:23 --> Language Class Initialized
INFO - 2023-03-24 09:43:23 --> Loader Class Initialized
INFO - 2023-03-24 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:43:23 --> Total execution time: 0.0219
INFO - 2023-03-24 09:43:23 --> Config Class Initialized
INFO - 2023-03-24 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:43:23 --> URI Class Initialized
INFO - 2023-03-24 09:43:23 --> Router Class Initialized
INFO - 2023-03-24 09:43:23 --> Output Class Initialized
INFO - 2023-03-24 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:43:23 --> Input Class Initialized
INFO - 2023-03-24 09:43:23 --> Language Class Initialized
INFO - 2023-03-24 09:43:23 --> Loader Class Initialized
INFO - 2023-03-24 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:43:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:43:23 --> Total execution time: 0.0552
INFO - 2023-03-24 09:43:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:43:23 --> Total execution time: 0.2014
INFO - 2023-03-24 09:43:23 --> Config Class Initialized
INFO - 2023-03-24 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:43:23 --> URI Class Initialized
INFO - 2023-03-24 09:43:23 --> Router Class Initialized
INFO - 2023-03-24 09:43:23 --> Output Class Initialized
INFO - 2023-03-24 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:43:23 --> Input Class Initialized
INFO - 2023-03-24 09:43:23 --> Language Class Initialized
INFO - 2023-03-24 09:43:23 --> Loader Class Initialized
INFO - 2023-03-24 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:43:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:43:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:43:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:43:24 --> Total execution time: 0.2046
INFO - 2023-03-24 09:44:23 --> Config Class Initialized
INFO - 2023-03-24 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:44:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:44:23 --> URI Class Initialized
INFO - 2023-03-24 09:44:23 --> Router Class Initialized
INFO - 2023-03-24 09:44:23 --> Output Class Initialized
INFO - 2023-03-24 09:44:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:44:23 --> Input Class Initialized
INFO - 2023-03-24 09:44:23 --> Language Class Initialized
INFO - 2023-03-24 09:44:23 --> Loader Class Initialized
INFO - 2023-03-24 09:44:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:44:23 --> Config Class Initialized
INFO - 2023-03-24 09:44:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:44:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:44:23 --> URI Class Initialized
INFO - 2023-03-24 09:44:23 --> Router Class Initialized
INFO - 2023-03-24 09:44:23 --> Output Class Initialized
INFO - 2023-03-24 09:44:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:44:23 --> Input Class Initialized
INFO - 2023-03-24 09:44:23 --> Language Class Initialized
INFO - 2023-03-24 09:44:23 --> Loader Class Initialized
INFO - 2023-03-24 09:44:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:44:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:44:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:44:23 --> Total execution time: 0.0204
INFO - 2023-03-24 09:44:23 --> Config Class Initialized
INFO - 2023-03-24 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:44:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:44:23 --> URI Class Initialized
INFO - 2023-03-24 09:44:23 --> Router Class Initialized
INFO - 2023-03-24 09:44:23 --> Output Class Initialized
INFO - 2023-03-24 09:44:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:44:23 --> Input Class Initialized
INFO - 2023-03-24 09:44:23 --> Language Class Initialized
INFO - 2023-03-24 09:44:23 --> Loader Class Initialized
INFO - 2023-03-24 09:44:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:44:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:44:23 --> Total execution time: 0.0147
INFO - 2023-03-24 09:44:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:44:23 --> Total execution time: 0.1761
INFO - 2023-03-24 09:44:23 --> Config Class Initialized
INFO - 2023-03-24 09:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:44:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:44:23 --> URI Class Initialized
INFO - 2023-03-24 09:44:23 --> Router Class Initialized
INFO - 2023-03-24 09:44:23 --> Output Class Initialized
INFO - 2023-03-24 09:44:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:44:23 --> Input Class Initialized
INFO - 2023-03-24 09:44:23 --> Language Class Initialized
INFO - 2023-03-24 09:44:23 --> Loader Class Initialized
INFO - 2023-03-24 09:44:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:44:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:44:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:44:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:44:24 --> Total execution time: 0.2558
INFO - 2023-03-24 09:45:23 --> Config Class Initialized
INFO - 2023-03-24 09:45:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:45:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:45:23 --> URI Class Initialized
INFO - 2023-03-24 09:45:23 --> Router Class Initialized
INFO - 2023-03-24 09:45:23 --> Output Class Initialized
INFO - 2023-03-24 09:45:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:45:23 --> Config Class Initialized
INFO - 2023-03-24 09:45:23 --> Input Class Initialized
INFO - 2023-03-24 09:45:23 --> Hooks Class Initialized
INFO - 2023-03-24 09:45:23 --> Language Class Initialized
DEBUG - 2023-03-24 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:45:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:45:23 --> Loader Class Initialized
INFO - 2023-03-24 09:45:23 --> URI Class Initialized
INFO - 2023-03-24 09:45:23 --> Controller Class Initialized
INFO - 2023-03-24 09:45:23 --> Router Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:45:23 --> Output Class Initialized
INFO - 2023-03-24 09:45:23 --> Security Class Initialized
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:45:23 --> Input Class Initialized
INFO - 2023-03-24 09:45:23 --> Language Class Initialized
INFO - 2023-03-24 09:45:23 --> Loader Class Initialized
INFO - 2023-03-24 09:45:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:45:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:45:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:45:23 --> Total execution time: 0.0201
INFO - 2023-03-24 09:45:23 --> Config Class Initialized
INFO - 2023-03-24 09:45:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:45:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:45:23 --> URI Class Initialized
INFO - 2023-03-24 09:45:23 --> Router Class Initialized
INFO - 2023-03-24 09:45:23 --> Output Class Initialized
INFO - 2023-03-24 09:45:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:45:23 --> Input Class Initialized
INFO - 2023-03-24 09:45:23 --> Language Class Initialized
INFO - 2023-03-24 09:45:23 --> Loader Class Initialized
INFO - 2023-03-24 09:45:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:45:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:45:23 --> Total execution time: 0.0141
INFO - 2023-03-24 09:45:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:45:23 --> Total execution time: 0.1677
INFO - 2023-03-24 09:45:23 --> Config Class Initialized
INFO - 2023-03-24 09:45:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:45:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:45:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:45:23 --> URI Class Initialized
INFO - 2023-03-24 09:45:23 --> Router Class Initialized
INFO - 2023-03-24 09:45:23 --> Output Class Initialized
INFO - 2023-03-24 09:45:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:45:23 --> Input Class Initialized
INFO - 2023-03-24 09:45:23 --> Language Class Initialized
INFO - 2023-03-24 09:45:23 --> Loader Class Initialized
INFO - 2023-03-24 09:45:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:45:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:45:23 --> Model "Login_model" initialized
INFO - 2023-03-24 09:45:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:45:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:45:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:45:24 --> Total execution time: 0.2026
INFO - 2023-03-24 09:46:23 --> Config Class Initialized
INFO - 2023-03-24 09:46:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:46:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:46:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:46:23 --> URI Class Initialized
INFO - 2023-03-24 09:46:23 --> Router Class Initialized
INFO - 2023-03-24 09:46:23 --> Output Class Initialized
INFO - 2023-03-24 09:46:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:46:23 --> Input Class Initialized
INFO - 2023-03-24 09:46:23 --> Language Class Initialized
INFO - 2023-03-24 09:46:23 --> Loader Class Initialized
INFO - 2023-03-24 09:46:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:46:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:46:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:46:23 --> Total execution time: 0.0178
INFO - 2023-03-24 09:46:23 --> Config Class Initialized
INFO - 2023-03-24 09:46:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:46:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:46:23 --> Utf8 Class Initialized
INFO - 2023-03-24 09:46:23 --> URI Class Initialized
INFO - 2023-03-24 09:46:23 --> Router Class Initialized
INFO - 2023-03-24 09:46:23 --> Output Class Initialized
INFO - 2023-03-24 09:46:23 --> Security Class Initialized
DEBUG - 2023-03-24 09:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:46:23 --> Input Class Initialized
INFO - 2023-03-24 09:46:23 --> Language Class Initialized
INFO - 2023-03-24 09:46:23 --> Loader Class Initialized
INFO - 2023-03-24 09:46:23 --> Controller Class Initialized
DEBUG - 2023-03-24 09:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:46:23 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:46:23 --> Final output sent to browser
DEBUG - 2023-03-24 09:46:23 --> Total execution time: 0.0136
INFO - 2023-03-24 09:46:24 --> Config Class Initialized
INFO - 2023-03-24 09:46:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:46:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:46:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:46:24 --> URI Class Initialized
INFO - 2023-03-24 09:46:24 --> Router Class Initialized
INFO - 2023-03-24 09:46:24 --> Output Class Initialized
INFO - 2023-03-24 09:46:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:46:24 --> Input Class Initialized
INFO - 2023-03-24 09:46:24 --> Language Class Initialized
INFO - 2023-03-24 09:46:24 --> Loader Class Initialized
INFO - 2023-03-24 09:46:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:46:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:24 --> Model "Login_model" initialized
INFO - 2023-03-24 09:46:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:46:24 --> Final output sent to browser
DEBUG - 2023-03-24 09:46:24 --> Total execution time: 0.1731
INFO - 2023-03-24 09:46:24 --> Config Class Initialized
INFO - 2023-03-24 09:46:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:46:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:46:24 --> Utf8 Class Initialized
INFO - 2023-03-24 09:46:24 --> URI Class Initialized
INFO - 2023-03-24 09:46:24 --> Router Class Initialized
INFO - 2023-03-24 09:46:24 --> Output Class Initialized
INFO - 2023-03-24 09:46:24 --> Security Class Initialized
DEBUG - 2023-03-24 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:46:24 --> Input Class Initialized
INFO - 2023-03-24 09:46:24 --> Language Class Initialized
INFO - 2023-03-24 09:46:24 --> Loader Class Initialized
INFO - 2023-03-24 09:46:24 --> Controller Class Initialized
DEBUG - 2023-03-24 09:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:46:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:24 --> Model "Login_model" initialized
INFO - 2023-03-24 09:46:24 --> Database Driver Class Initialized
INFO - 2023-03-24 09:46:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:46:25 --> Final output sent to browser
DEBUG - 2023-03-24 09:46:25 --> Total execution time: 0.1594
INFO - 2023-03-24 09:47:00 --> Config Class Initialized
INFO - 2023-03-24 09:47:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:47:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:47:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:47:00 --> URI Class Initialized
INFO - 2023-03-24 09:47:00 --> Router Class Initialized
INFO - 2023-03-24 09:47:00 --> Output Class Initialized
INFO - 2023-03-24 09:47:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:47:00 --> Input Class Initialized
INFO - 2023-03-24 09:47:00 --> Language Class Initialized
INFO - 2023-03-24 09:47:00 --> Loader Class Initialized
INFO - 2023-03-24 09:47:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:47:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:47:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:47:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:47:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:47:00 --> Total execution time: 0.0959
INFO - 2023-03-24 09:47:00 --> Config Class Initialized
INFO - 2023-03-24 09:47:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:47:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:47:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:47:00 --> URI Class Initialized
INFO - 2023-03-24 09:47:00 --> Router Class Initialized
INFO - 2023-03-24 09:47:00 --> Output Class Initialized
INFO - 2023-03-24 09:47:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:47:00 --> Input Class Initialized
INFO - 2023-03-24 09:47:00 --> Language Class Initialized
INFO - 2023-03-24 09:47:00 --> Loader Class Initialized
INFO - 2023-03-24 09:47:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:47:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:47:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:47:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:47:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:47:00 --> Total execution time: 0.0583
INFO - 2023-03-24 09:48:00 --> Config Class Initialized
INFO - 2023-03-24 09:48:00 --> Config Class Initialized
INFO - 2023-03-24 09:48:00 --> Hooks Class Initialized
INFO - 2023-03-24 09:48:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:48:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:48:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:48:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:48:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:48:00 --> URI Class Initialized
INFO - 2023-03-24 09:48:00 --> URI Class Initialized
INFO - 2023-03-24 09:48:00 --> Router Class Initialized
INFO - 2023-03-24 09:48:00 --> Router Class Initialized
INFO - 2023-03-24 09:48:00 --> Output Class Initialized
INFO - 2023-03-24 09:48:00 --> Output Class Initialized
INFO - 2023-03-24 09:48:00 --> Security Class Initialized
INFO - 2023-03-24 09:48:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:48:00 --> Input Class Initialized
INFO - 2023-03-24 09:48:00 --> Input Class Initialized
INFO - 2023-03-24 09:48:00 --> Language Class Initialized
INFO - 2023-03-24 09:48:00 --> Language Class Initialized
INFO - 2023-03-24 09:48:00 --> Loader Class Initialized
INFO - 2023-03-24 09:48:00 --> Loader Class Initialized
INFO - 2023-03-24 09:48:00 --> Controller Class Initialized
INFO - 2023-03-24 09:48:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:48:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:48:00 --> Total execution time: 0.0581
INFO - 2023-03-24 09:48:00 --> Config Class Initialized
INFO - 2023-03-24 09:48:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:48:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:48:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:48:00 --> URI Class Initialized
INFO - 2023-03-24 09:48:00 --> Router Class Initialized
INFO - 2023-03-24 09:48:00 --> Output Class Initialized
INFO - 2023-03-24 09:48:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:48:00 --> Input Class Initialized
INFO - 2023-03-24 09:48:00 --> Language Class Initialized
INFO - 2023-03-24 09:48:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:48:00 --> Loader Class Initialized
INFO - 2023-03-24 09:48:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:48:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:48:00 --> Total execution time: 0.0150
INFO - 2023-03-24 09:48:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:48:00 --> Total execution time: 0.2323
INFO - 2023-03-24 09:48:00 --> Config Class Initialized
INFO - 2023-03-24 09:48:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:48:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:48:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:48:00 --> URI Class Initialized
INFO - 2023-03-24 09:48:00 --> Router Class Initialized
INFO - 2023-03-24 09:48:00 --> Output Class Initialized
INFO - 2023-03-24 09:48:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:48:00 --> Input Class Initialized
INFO - 2023-03-24 09:48:00 --> Language Class Initialized
INFO - 2023-03-24 09:48:00 --> Loader Class Initialized
INFO - 2023-03-24 09:48:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:48:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:48:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:48:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:48:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:48:00 --> Total execution time: 0.1708
INFO - 2023-03-24 09:49:00 --> Config Class Initialized
INFO - 2023-03-24 09:49:00 --> Config Class Initialized
INFO - 2023-03-24 09:49:00 --> Hooks Class Initialized
INFO - 2023-03-24 09:49:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:49:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:49:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:49:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:49:00 --> URI Class Initialized
INFO - 2023-03-24 09:49:00 --> URI Class Initialized
INFO - 2023-03-24 09:49:00 --> Router Class Initialized
INFO - 2023-03-24 09:49:00 --> Router Class Initialized
INFO - 2023-03-24 09:49:00 --> Output Class Initialized
INFO - 2023-03-24 09:49:00 --> Output Class Initialized
INFO - 2023-03-24 09:49:00 --> Security Class Initialized
INFO - 2023-03-24 09:49:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:49:00 --> Input Class Initialized
INFO - 2023-03-24 09:49:00 --> Input Class Initialized
INFO - 2023-03-24 09:49:00 --> Language Class Initialized
INFO - 2023-03-24 09:49:00 --> Language Class Initialized
INFO - 2023-03-24 09:49:00 --> Loader Class Initialized
INFO - 2023-03-24 09:49:00 --> Loader Class Initialized
INFO - 2023-03-24 09:49:00 --> Controller Class Initialized
INFO - 2023-03-24 09:49:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:49:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:49:00 --> Total execution time: 0.0211
INFO - 2023-03-24 09:49:00 --> Config Class Initialized
INFO - 2023-03-24 09:49:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:49:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:49:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:49:00 --> URI Class Initialized
INFO - 2023-03-24 09:49:00 --> Router Class Initialized
INFO - 2023-03-24 09:49:00 --> Output Class Initialized
INFO - 2023-03-24 09:49:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:49:00 --> Input Class Initialized
INFO - 2023-03-24 09:49:00 --> Language Class Initialized
INFO - 2023-03-24 09:49:00 --> Loader Class Initialized
INFO - 2023-03-24 09:49:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:49:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:49:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:49:00 --> Total execution time: 0.0155
INFO - 2023-03-24 09:49:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:49:00 --> Total execution time: 0.1759
INFO - 2023-03-24 09:49:00 --> Config Class Initialized
INFO - 2023-03-24 09:49:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:49:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:49:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:49:00 --> URI Class Initialized
INFO - 2023-03-24 09:49:00 --> Router Class Initialized
INFO - 2023-03-24 09:49:00 --> Output Class Initialized
INFO - 2023-03-24 09:49:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:49:00 --> Input Class Initialized
INFO - 2023-03-24 09:49:00 --> Language Class Initialized
INFO - 2023-03-24 09:49:00 --> Loader Class Initialized
INFO - 2023-03-24 09:49:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:49:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:49:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:49:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:49:00 --> Total execution time: 0.1784
INFO - 2023-03-24 09:50:00 --> Config Class Initialized
INFO - 2023-03-24 09:50:00 --> Config Class Initialized
INFO - 2023-03-24 09:50:00 --> Hooks Class Initialized
INFO - 2023-03-24 09:50:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:50:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:50:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:50:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:50:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:50:00 --> URI Class Initialized
INFO - 2023-03-24 09:50:00 --> URI Class Initialized
INFO - 2023-03-24 09:50:00 --> Router Class Initialized
INFO - 2023-03-24 09:50:00 --> Router Class Initialized
INFO - 2023-03-24 09:50:00 --> Output Class Initialized
INFO - 2023-03-24 09:50:00 --> Output Class Initialized
INFO - 2023-03-24 09:50:00 --> Security Class Initialized
INFO - 2023-03-24 09:50:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:50:00 --> Input Class Initialized
INFO - 2023-03-24 09:50:00 --> Input Class Initialized
INFO - 2023-03-24 09:50:00 --> Language Class Initialized
INFO - 2023-03-24 09:50:00 --> Language Class Initialized
INFO - 2023-03-24 09:50:00 --> Loader Class Initialized
INFO - 2023-03-24 09:50:00 --> Loader Class Initialized
INFO - 2023-03-24 09:50:00 --> Controller Class Initialized
INFO - 2023-03-24 09:50:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:50:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:50:00 --> Total execution time: 0.0240
INFO - 2023-03-24 09:50:00 --> Config Class Initialized
INFO - 2023-03-24 09:50:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:50:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:50:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:50:00 --> URI Class Initialized
INFO - 2023-03-24 09:50:00 --> Router Class Initialized
INFO - 2023-03-24 09:50:00 --> Output Class Initialized
INFO - 2023-03-24 09:50:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:50:00 --> Input Class Initialized
INFO - 2023-03-24 09:50:00 --> Language Class Initialized
INFO - 2023-03-24 09:50:00 --> Loader Class Initialized
INFO - 2023-03-24 09:50:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:50:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:50:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:50:00 --> Total execution time: 0.0167
INFO - 2023-03-24 09:50:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:50:00 --> Total execution time: 0.2096
INFO - 2023-03-24 09:50:00 --> Config Class Initialized
INFO - 2023-03-24 09:50:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:50:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:50:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:50:00 --> URI Class Initialized
INFO - 2023-03-24 09:50:00 --> Router Class Initialized
INFO - 2023-03-24 09:50:00 --> Output Class Initialized
INFO - 2023-03-24 09:50:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:50:00 --> Input Class Initialized
INFO - 2023-03-24 09:50:00 --> Language Class Initialized
INFO - 2023-03-24 09:50:00 --> Loader Class Initialized
INFO - 2023-03-24 09:50:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:50:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:50:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:50:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:50:00 --> Total execution time: 0.1892
INFO - 2023-03-24 09:51:00 --> Config Class Initialized
INFO - 2023-03-24 09:51:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:00 --> URI Class Initialized
INFO - 2023-03-24 09:51:00 --> Router Class Initialized
INFO - 2023-03-24 09:51:00 --> Output Class Initialized
INFO - 2023-03-24 09:51:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:00 --> Config Class Initialized
INFO - 2023-03-24 09:51:00 --> Input Class Initialized
INFO - 2023-03-24 09:51:00 --> Hooks Class Initialized
INFO - 2023-03-24 09:51:00 --> Language Class Initialized
DEBUG - 2023-03-24 09:51:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:00 --> Loader Class Initialized
INFO - 2023-03-24 09:51:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:00 --> Controller Class Initialized
INFO - 2023-03-24 09:51:00 --> URI Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:00 --> Router Class Initialized
INFO - 2023-03-24 09:51:00 --> Output Class Initialized
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:00 --> Input Class Initialized
INFO - 2023-03-24 09:51:00 --> Language Class Initialized
INFO - 2023-03-24 09:51:00 --> Loader Class Initialized
INFO - 2023-03-24 09:51:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:51:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:00 --> Total execution time: 0.0232
INFO - 2023-03-24 09:51:00 --> Config Class Initialized
INFO - 2023-03-24 09:51:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:00 --> URI Class Initialized
INFO - 2023-03-24 09:51:00 --> Router Class Initialized
INFO - 2023-03-24 09:51:00 --> Output Class Initialized
INFO - 2023-03-24 09:51:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:00 --> Input Class Initialized
INFO - 2023-03-24 09:51:00 --> Language Class Initialized
INFO - 2023-03-24 09:51:00 --> Loader Class Initialized
INFO - 2023-03-24 09:51:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:00 --> Total execution time: 0.0172
INFO - 2023-03-24 09:51:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:00 --> Total execution time: 0.1727
INFO - 2023-03-24 09:51:00 --> Config Class Initialized
INFO - 2023-03-24 09:51:00 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:00 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:00 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:00 --> URI Class Initialized
INFO - 2023-03-24 09:51:00 --> Router Class Initialized
INFO - 2023-03-24 09:51:00 --> Output Class Initialized
INFO - 2023-03-24 09:51:00 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:00 --> Input Class Initialized
INFO - 2023-03-24 09:51:00 --> Language Class Initialized
INFO - 2023-03-24 09:51:00 --> Loader Class Initialized
INFO - 2023-03-24 09:51:00 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Model "Login_model" initialized
INFO - 2023-03-24 09:51:00 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:00 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:00 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:00 --> Total execution time: 0.1580
INFO - 2023-03-24 09:51:12 --> Config Class Initialized
INFO - 2023-03-24 09:51:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:12 --> URI Class Initialized
INFO - 2023-03-24 09:51:12 --> Router Class Initialized
INFO - 2023-03-24 09:51:12 --> Output Class Initialized
INFO - 2023-03-24 09:51:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:12 --> Input Class Initialized
INFO - 2023-03-24 09:51:12 --> Language Class Initialized
INFO - 2023-03-24 09:51:12 --> Loader Class Initialized
INFO - 2023-03-24 09:51:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:12 --> Total execution time: 0.0589
INFO - 2023-03-24 09:51:12 --> Config Class Initialized
INFO - 2023-03-24 09:51:12 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:12 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:12 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:12 --> URI Class Initialized
INFO - 2023-03-24 09:51:12 --> Router Class Initialized
INFO - 2023-03-24 09:51:12 --> Output Class Initialized
INFO - 2023-03-24 09:51:12 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:12 --> Input Class Initialized
INFO - 2023-03-24 09:51:12 --> Language Class Initialized
INFO - 2023-03-24 09:51:12 --> Loader Class Initialized
INFO - 2023-03-24 09:51:12 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:12 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:12 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:12 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:12 --> Total execution time: 0.0154
INFO - 2023-03-24 09:51:35 --> Config Class Initialized
INFO - 2023-03-24 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:35 --> URI Class Initialized
INFO - 2023-03-24 09:51:35 --> Router Class Initialized
INFO - 2023-03-24 09:51:35 --> Output Class Initialized
INFO - 2023-03-24 09:51:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:35 --> Input Class Initialized
INFO - 2023-03-24 09:51:35 --> Language Class Initialized
INFO - 2023-03-24 09:51:35 --> Loader Class Initialized
INFO - 2023-03-24 09:51:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:35 --> Total execution time: 0.0176
INFO - 2023-03-24 09:51:35 --> Config Class Initialized
INFO - 2023-03-24 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:51:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:51:35 --> URI Class Initialized
INFO - 2023-03-24 09:51:35 --> Router Class Initialized
INFO - 2023-03-24 09:51:35 --> Output Class Initialized
INFO - 2023-03-24 09:51:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:51:35 --> Input Class Initialized
INFO - 2023-03-24 09:51:35 --> Language Class Initialized
INFO - 2023-03-24 09:51:35 --> Loader Class Initialized
INFO - 2023-03-24 09:51:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:51:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:51:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:51:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:51:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:51:35 --> Total execution time: 0.0140
INFO - 2023-03-24 09:52:35 --> Config Class Initialized
INFO - 2023-03-24 09:52:35 --> Config Class Initialized
INFO - 2023-03-24 09:52:35 --> Hooks Class Initialized
INFO - 2023-03-24 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:52:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:52:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:52:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:52:35 --> URI Class Initialized
INFO - 2023-03-24 09:52:35 --> URI Class Initialized
INFO - 2023-03-24 09:52:35 --> Router Class Initialized
INFO - 2023-03-24 09:52:35 --> Router Class Initialized
INFO - 2023-03-24 09:52:35 --> Output Class Initialized
INFO - 2023-03-24 09:52:35 --> Output Class Initialized
INFO - 2023-03-24 09:52:35 --> Security Class Initialized
INFO - 2023-03-24 09:52:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:52:35 --> Input Class Initialized
INFO - 2023-03-24 09:52:35 --> Input Class Initialized
INFO - 2023-03-24 09:52:35 --> Language Class Initialized
INFO - 2023-03-24 09:52:35 --> Language Class Initialized
INFO - 2023-03-24 09:52:35 --> Loader Class Initialized
INFO - 2023-03-24 09:52:35 --> Loader Class Initialized
INFO - 2023-03-24 09:52:35 --> Controller Class Initialized
INFO - 2023-03-24 09:52:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Model "Login_model" initialized
INFO - 2023-03-24 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:52:35 --> Total execution time: 0.0205
INFO - 2023-03-24 09:52:35 --> Config Class Initialized
INFO - 2023-03-24 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:52:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:52:35 --> URI Class Initialized
INFO - 2023-03-24 09:52:35 --> Router Class Initialized
INFO - 2023-03-24 09:52:35 --> Output Class Initialized
INFO - 2023-03-24 09:52:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:52:35 --> Input Class Initialized
INFO - 2023-03-24 09:52:35 --> Language Class Initialized
INFO - 2023-03-24 09:52:35 --> Loader Class Initialized
INFO - 2023-03-24 09:52:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:52:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:52:35 --> Total execution time: 0.1019
INFO - 2023-03-24 09:52:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:52:35 --> Total execution time: 0.2254
INFO - 2023-03-24 09:52:35 --> Config Class Initialized
INFO - 2023-03-24 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:52:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:52:35 --> URI Class Initialized
INFO - 2023-03-24 09:52:35 --> Router Class Initialized
INFO - 2023-03-24 09:52:35 --> Output Class Initialized
INFO - 2023-03-24 09:52:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:52:35 --> Input Class Initialized
INFO - 2023-03-24 09:52:35 --> Language Class Initialized
INFO - 2023-03-24 09:52:35 --> Loader Class Initialized
INFO - 2023-03-24 09:52:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:52:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Model "Login_model" initialized
INFO - 2023-03-24 09:52:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:52:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:52:36 --> Final output sent to browser
DEBUG - 2023-03-24 09:52:36 --> Total execution time: 0.2260
INFO - 2023-03-24 09:53:35 --> Config Class Initialized
INFO - 2023-03-24 09:53:35 --> Config Class Initialized
INFO - 2023-03-24 09:53:35 --> Hooks Class Initialized
INFO - 2023-03-24 09:53:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:53:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:53:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:53:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:53:35 --> URI Class Initialized
INFO - 2023-03-24 09:53:35 --> URI Class Initialized
INFO - 2023-03-24 09:53:35 --> Router Class Initialized
INFO - 2023-03-24 09:53:35 --> Router Class Initialized
INFO - 2023-03-24 09:53:35 --> Output Class Initialized
INFO - 2023-03-24 09:53:35 --> Output Class Initialized
INFO - 2023-03-24 09:53:35 --> Security Class Initialized
INFO - 2023-03-24 09:53:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:53:35 --> Input Class Initialized
INFO - 2023-03-24 09:53:35 --> Input Class Initialized
INFO - 2023-03-24 09:53:35 --> Language Class Initialized
INFO - 2023-03-24 09:53:35 --> Language Class Initialized
INFO - 2023-03-24 09:53:35 --> Loader Class Initialized
INFO - 2023-03-24 09:53:35 --> Loader Class Initialized
INFO - 2023-03-24 09:53:35 --> Controller Class Initialized
INFO - 2023-03-24 09:53:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:53:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Model "Login_model" initialized
INFO - 2023-03-24 09:53:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:53:35 --> Total execution time: 0.0225
INFO - 2023-03-24 09:53:35 --> Config Class Initialized
INFO - 2023-03-24 09:53:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:53:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:53:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:53:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:53:35 --> URI Class Initialized
INFO - 2023-03-24 09:53:35 --> Router Class Initialized
INFO - 2023-03-24 09:53:35 --> Output Class Initialized
INFO - 2023-03-24 09:53:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:53:35 --> Input Class Initialized
INFO - 2023-03-24 09:53:35 --> Language Class Initialized
INFO - 2023-03-24 09:53:35 --> Loader Class Initialized
INFO - 2023-03-24 09:53:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:53:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:53:35 --> Total execution time: 0.0140
INFO - 2023-03-24 09:53:35 --> Final output sent to browser
DEBUG - 2023-03-24 09:53:35 --> Total execution time: 0.1965
INFO - 2023-03-24 09:53:35 --> Config Class Initialized
INFO - 2023-03-24 09:53:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:53:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:53:35 --> Utf8 Class Initialized
INFO - 2023-03-24 09:53:35 --> URI Class Initialized
INFO - 2023-03-24 09:53:35 --> Router Class Initialized
INFO - 2023-03-24 09:53:35 --> Output Class Initialized
INFO - 2023-03-24 09:53:35 --> Security Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:53:35 --> Input Class Initialized
INFO - 2023-03-24 09:53:35 --> Language Class Initialized
INFO - 2023-03-24 09:53:35 --> Loader Class Initialized
INFO - 2023-03-24 09:53:35 --> Controller Class Initialized
DEBUG - 2023-03-24 09:53:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Model "Login_model" initialized
INFO - 2023-03-24 09:53:35 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:53:36 --> Final output sent to browser
DEBUG - 2023-03-24 09:53:36 --> Total execution time: 0.3506
INFO - 2023-03-24 09:53:37 --> Config Class Initialized
INFO - 2023-03-24 09:53:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:53:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:53:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:53:37 --> URI Class Initialized
INFO - 2023-03-24 09:53:37 --> Router Class Initialized
INFO - 2023-03-24 09:53:37 --> Output Class Initialized
INFO - 2023-03-24 09:53:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:53:37 --> Input Class Initialized
INFO - 2023-03-24 09:53:37 --> Language Class Initialized
INFO - 2023-03-24 09:53:37 --> Loader Class Initialized
INFO - 2023-03-24 09:53:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:53:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:53:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:53:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:53:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:53:37 --> Total execution time: 0.0215
INFO - 2023-03-24 09:54:37 --> Config Class Initialized
INFO - 2023-03-24 09:54:37 --> Config Class Initialized
INFO - 2023-03-24 09:54:37 --> Hooks Class Initialized
INFO - 2023-03-24 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:37 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:37 --> URI Class Initialized
INFO - 2023-03-24 09:54:37 --> URI Class Initialized
INFO - 2023-03-24 09:54:37 --> Router Class Initialized
INFO - 2023-03-24 09:54:37 --> Router Class Initialized
INFO - 2023-03-24 09:54:37 --> Output Class Initialized
INFO - 2023-03-24 09:54:37 --> Output Class Initialized
INFO - 2023-03-24 09:54:37 --> Security Class Initialized
INFO - 2023-03-24 09:54:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:37 --> Input Class Initialized
INFO - 2023-03-24 09:54:37 --> Input Class Initialized
INFO - 2023-03-24 09:54:37 --> Language Class Initialized
INFO - 2023-03-24 09:54:37 --> Language Class Initialized
INFO - 2023-03-24 09:54:37 --> Loader Class Initialized
INFO - 2023-03-24 09:54:37 --> Loader Class Initialized
INFO - 2023-03-24 09:54:37 --> Controller Class Initialized
INFO - 2023-03-24 09:54:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Model "Login_model" initialized
INFO - 2023-03-24 09:54:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:37 --> Total execution time: 0.0239
INFO - 2023-03-24 09:54:37 --> Config Class Initialized
INFO - 2023-03-24 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:37 --> URI Class Initialized
INFO - 2023-03-24 09:54:37 --> Router Class Initialized
INFO - 2023-03-24 09:54:37 --> Output Class Initialized
INFO - 2023-03-24 09:54:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:37 --> Input Class Initialized
INFO - 2023-03-24 09:54:37 --> Language Class Initialized
INFO - 2023-03-24 09:54:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:37 --> Loader Class Initialized
INFO - 2023-03-24 09:54:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:37 --> Total execution time: 0.0145
INFO - 2023-03-24 09:54:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:37 --> Total execution time: 0.1729
INFO - 2023-03-24 09:54:37 --> Config Class Initialized
INFO - 2023-03-24 09:54:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:37 --> URI Class Initialized
INFO - 2023-03-24 09:54:37 --> Router Class Initialized
INFO - 2023-03-24 09:54:37 --> Output Class Initialized
INFO - 2023-03-24 09:54:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:37 --> Input Class Initialized
INFO - 2023-03-24 09:54:37 --> Language Class Initialized
INFO - 2023-03-24 09:54:37 --> Loader Class Initialized
INFO - 2023-03-24 09:54:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Model "Login_model" initialized
INFO - 2023-03-24 09:54:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:37 --> Total execution time: 0.2135
INFO - 2023-03-24 09:54:47 --> Config Class Initialized
INFO - 2023-03-24 09:54:47 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:47 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:47 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:47 --> URI Class Initialized
INFO - 2023-03-24 09:54:47 --> Router Class Initialized
INFO - 2023-03-24 09:54:47 --> Output Class Initialized
INFO - 2023-03-24 09:54:47 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:47 --> Input Class Initialized
INFO - 2023-03-24 09:54:47 --> Language Class Initialized
INFO - 2023-03-24 09:54:47 --> Loader Class Initialized
INFO - 2023-03-24 09:54:47 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:47 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:47 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:47 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:47 --> Model "Login_model" initialized
INFO - 2023-03-24 09:54:47 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:47 --> Total execution time: 0.1246
INFO - 2023-03-24 09:54:47 --> Config Class Initialized
INFO - 2023-03-24 09:54:47 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:47 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:47 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:47 --> URI Class Initialized
INFO - 2023-03-24 09:54:47 --> Router Class Initialized
INFO - 2023-03-24 09:54:47 --> Output Class Initialized
INFO - 2023-03-24 09:54:47 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:47 --> Input Class Initialized
INFO - 2023-03-24 09:54:47 --> Language Class Initialized
INFO - 2023-03-24 09:54:47 --> Loader Class Initialized
INFO - 2023-03-24 09:54:47 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:47 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:47 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:47 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:47 --> Model "Login_model" initialized
INFO - 2023-03-24 09:54:47 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:47 --> Total execution time: 0.0827
INFO - 2023-03-24 09:54:50 --> Config Class Initialized
INFO - 2023-03-24 09:54:50 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:50 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:50 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:50 --> URI Class Initialized
INFO - 2023-03-24 09:54:50 --> Router Class Initialized
INFO - 2023-03-24 09:54:50 --> Output Class Initialized
INFO - 2023-03-24 09:54:50 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:50 --> Input Class Initialized
INFO - 2023-03-24 09:54:50 --> Language Class Initialized
INFO - 2023-03-24 09:54:50 --> Loader Class Initialized
INFO - 2023-03-24 09:54:50 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:50 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:50 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:50 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:50 --> Total execution time: 0.0167
INFO - 2023-03-24 09:54:50 --> Config Class Initialized
INFO - 2023-03-24 09:54:50 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:54:50 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:54:50 --> Utf8 Class Initialized
INFO - 2023-03-24 09:54:50 --> URI Class Initialized
INFO - 2023-03-24 09:54:50 --> Router Class Initialized
INFO - 2023-03-24 09:54:50 --> Output Class Initialized
INFO - 2023-03-24 09:54:50 --> Security Class Initialized
DEBUG - 2023-03-24 09:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:54:50 --> Input Class Initialized
INFO - 2023-03-24 09:54:50 --> Language Class Initialized
INFO - 2023-03-24 09:54:50 --> Loader Class Initialized
INFO - 2023-03-24 09:54:50 --> Controller Class Initialized
DEBUG - 2023-03-24 09:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:54:50 --> Database Driver Class Initialized
INFO - 2023-03-24 09:54:50 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:54:50 --> Final output sent to browser
DEBUG - 2023-03-24 09:54:50 --> Total execution time: 0.0599
INFO - 2023-03-24 09:55:14 --> Config Class Initialized
INFO - 2023-03-24 09:55:14 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:55:14 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:55:14 --> Utf8 Class Initialized
INFO - 2023-03-24 09:55:14 --> URI Class Initialized
INFO - 2023-03-24 09:55:14 --> Router Class Initialized
INFO - 2023-03-24 09:55:14 --> Output Class Initialized
INFO - 2023-03-24 09:55:14 --> Security Class Initialized
DEBUG - 2023-03-24 09:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:55:14 --> Input Class Initialized
INFO - 2023-03-24 09:55:14 --> Language Class Initialized
INFO - 2023-03-24 09:55:14 --> Loader Class Initialized
INFO - 2023-03-24 09:55:14 --> Controller Class Initialized
DEBUG - 2023-03-24 09:55:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:55:14 --> Database Driver Class Initialized
INFO - 2023-03-24 09:55:14 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:55:14 --> Final output sent to browser
DEBUG - 2023-03-24 09:55:14 --> Total execution time: 0.0197
INFO - 2023-03-24 09:55:14 --> Config Class Initialized
INFO - 2023-03-24 09:55:14 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:55:14 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:55:14 --> Utf8 Class Initialized
INFO - 2023-03-24 09:55:14 --> URI Class Initialized
INFO - 2023-03-24 09:55:14 --> Router Class Initialized
INFO - 2023-03-24 09:55:14 --> Output Class Initialized
INFO - 2023-03-24 09:55:14 --> Security Class Initialized
DEBUG - 2023-03-24 09:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:55:14 --> Input Class Initialized
INFO - 2023-03-24 09:55:14 --> Language Class Initialized
INFO - 2023-03-24 09:55:14 --> Loader Class Initialized
INFO - 2023-03-24 09:55:14 --> Controller Class Initialized
DEBUG - 2023-03-24 09:55:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:55:14 --> Database Driver Class Initialized
INFO - 2023-03-24 09:55:14 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:55:14 --> Final output sent to browser
DEBUG - 2023-03-24 09:55:14 --> Total execution time: 0.0139
INFO - 2023-03-24 09:55:18 --> Config Class Initialized
INFO - 2023-03-24 09:55:18 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:55:18 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:55:18 --> Utf8 Class Initialized
INFO - 2023-03-24 09:55:18 --> URI Class Initialized
INFO - 2023-03-24 09:55:18 --> Router Class Initialized
INFO - 2023-03-24 09:55:18 --> Output Class Initialized
INFO - 2023-03-24 09:55:18 --> Security Class Initialized
DEBUG - 2023-03-24 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:55:18 --> Input Class Initialized
INFO - 2023-03-24 09:55:18 --> Language Class Initialized
INFO - 2023-03-24 09:55:18 --> Loader Class Initialized
INFO - 2023-03-24 09:55:18 --> Controller Class Initialized
DEBUG - 2023-03-24 09:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:55:18 --> Database Driver Class Initialized
INFO - 2023-03-24 09:55:18 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:55:18 --> Final output sent to browser
DEBUG - 2023-03-24 09:55:18 --> Total execution time: 0.0164
INFO - 2023-03-24 09:56:19 --> Config Class Initialized
INFO - 2023-03-24 09:56:19 --> Config Class Initialized
INFO - 2023-03-24 09:56:19 --> Hooks Class Initialized
INFO - 2023-03-24 09:56:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:56:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 09:56:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:56:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:56:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:56:19 --> URI Class Initialized
INFO - 2023-03-24 09:56:19 --> URI Class Initialized
INFO - 2023-03-24 09:56:19 --> Router Class Initialized
INFO - 2023-03-24 09:56:19 --> Router Class Initialized
INFO - 2023-03-24 09:56:19 --> Output Class Initialized
INFO - 2023-03-24 09:56:19 --> Output Class Initialized
INFO - 2023-03-24 09:56:19 --> Security Class Initialized
INFO - 2023-03-24 09:56:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 09:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:56:19 --> Input Class Initialized
INFO - 2023-03-24 09:56:19 --> Input Class Initialized
INFO - 2023-03-24 09:56:19 --> Language Class Initialized
INFO - 2023-03-24 09:56:19 --> Language Class Initialized
INFO - 2023-03-24 09:56:19 --> Loader Class Initialized
INFO - 2023-03-24 09:56:19 --> Loader Class Initialized
INFO - 2023-03-24 09:56:19 --> Controller Class Initialized
INFO - 2023-03-24 09:56:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 09:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:56:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:56:19 --> Total execution time: 0.0168
INFO - 2023-03-24 09:56:19 --> Config Class Initialized
INFO - 2023-03-24 09:56:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:56:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:56:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:56:19 --> URI Class Initialized
INFO - 2023-03-24 09:56:19 --> Router Class Initialized
INFO - 2023-03-24 09:56:19 --> Output Class Initialized
INFO - 2023-03-24 09:56:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:56:19 --> Input Class Initialized
INFO - 2023-03-24 09:56:19 --> Language Class Initialized
INFO - 2023-03-24 09:56:19 --> Loader Class Initialized
INFO - 2023-03-24 09:56:19 --> Controller Class Initialized
INFO - 2023-03-24 09:56:19 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 09:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:56:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:56:19 --> Total execution time: 0.0158
INFO - 2023-03-24 09:56:19 --> Final output sent to browser
DEBUG - 2023-03-24 09:56:19 --> Total execution time: 0.1771
INFO - 2023-03-24 09:56:19 --> Config Class Initialized
INFO - 2023-03-24 09:56:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:56:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:56:19 --> Utf8 Class Initialized
INFO - 2023-03-24 09:56:19 --> URI Class Initialized
INFO - 2023-03-24 09:56:19 --> Router Class Initialized
INFO - 2023-03-24 09:56:19 --> Output Class Initialized
INFO - 2023-03-24 09:56:19 --> Security Class Initialized
DEBUG - 2023-03-24 09:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:56:19 --> Input Class Initialized
INFO - 2023-03-24 09:56:19 --> Language Class Initialized
INFO - 2023-03-24 09:56:19 --> Loader Class Initialized
INFO - 2023-03-24 09:56:19 --> Controller Class Initialized
DEBUG - 2023-03-24 09:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Model "Login_model" initialized
INFO - 2023-03-24 09:56:19 --> Database Driver Class Initialized
INFO - 2023-03-24 09:56:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:56:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:56:20 --> Total execution time: 0.1673
INFO - 2023-03-24 09:57:20 --> Config Class Initialized
INFO - 2023-03-24 09:57:20 --> Config Class Initialized
INFO - 2023-03-24 09:57:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:57:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:20 --> Hooks Class Initialized
INFO - 2023-03-24 09:57:20 --> Utf8 Class Initialized
DEBUG - 2023-03-24 09:57:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:20 --> URI Class Initialized
INFO - 2023-03-24 09:57:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:57:20 --> Router Class Initialized
INFO - 2023-03-24 09:57:20 --> URI Class Initialized
INFO - 2023-03-24 09:57:20 --> Output Class Initialized
INFO - 2023-03-24 09:57:20 --> Router Class Initialized
INFO - 2023-03-24 09:57:20 --> Security Class Initialized
INFO - 2023-03-24 09:57:20 --> Output Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:20 --> Security Class Initialized
INFO - 2023-03-24 09:57:20 --> Input Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:20 --> Language Class Initialized
INFO - 2023-03-24 09:57:20 --> Input Class Initialized
INFO - 2023-03-24 09:57:20 --> Language Class Initialized
INFO - 2023-03-24 09:57:20 --> Loader Class Initialized
INFO - 2023-03-24 09:57:20 --> Controller Class Initialized
INFO - 2023-03-24 09:57:20 --> Loader Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Model "Login_model" initialized
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:20 --> Total execution time: 0.1218
INFO - 2023-03-24 09:57:20 --> Config Class Initialized
INFO - 2023-03-24 09:57:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:57:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:57:20 --> URI Class Initialized
INFO - 2023-03-24 09:57:20 --> Router Class Initialized
INFO - 2023-03-24 09:57:20 --> Output Class Initialized
INFO - 2023-03-24 09:57:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:20 --> Input Class Initialized
INFO - 2023-03-24 09:57:20 --> Language Class Initialized
INFO - 2023-03-24 09:57:20 --> Loader Class Initialized
INFO - 2023-03-24 09:57:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:20 --> Total execution time: 0.0196
INFO - 2023-03-24 09:57:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:20 --> Total execution time: 0.1871
INFO - 2023-03-24 09:57:20 --> Config Class Initialized
INFO - 2023-03-24 09:57:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:57:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:20 --> Utf8 Class Initialized
INFO - 2023-03-24 09:57:20 --> URI Class Initialized
INFO - 2023-03-24 09:57:20 --> Router Class Initialized
INFO - 2023-03-24 09:57:20 --> Output Class Initialized
INFO - 2023-03-24 09:57:20 --> Security Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:20 --> Input Class Initialized
INFO - 2023-03-24 09:57:20 --> Language Class Initialized
INFO - 2023-03-24 09:57:20 --> Loader Class Initialized
INFO - 2023-03-24 09:57:20 --> Controller Class Initialized
DEBUG - 2023-03-24 09:57:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Model "Login_model" initialized
INFO - 2023-03-24 09:57:20 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:20 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:20 --> Total execution time: 0.1675
INFO - 2023-03-24 09:57:55 --> Config Class Initialized
INFO - 2023-03-24 09:57:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:57:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:55 --> Utf8 Class Initialized
INFO - 2023-03-24 09:57:55 --> URI Class Initialized
INFO - 2023-03-24 09:57:55 --> Router Class Initialized
INFO - 2023-03-24 09:57:55 --> Output Class Initialized
INFO - 2023-03-24 09:57:55 --> Security Class Initialized
DEBUG - 2023-03-24 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:55 --> Input Class Initialized
INFO - 2023-03-24 09:57:55 --> Language Class Initialized
INFO - 2023-03-24 09:57:55 --> Loader Class Initialized
INFO - 2023-03-24 09:57:55 --> Controller Class Initialized
DEBUG - 2023-03-24 09:57:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:55 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:55 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:55 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:55 --> Total execution time: 0.1039
INFO - 2023-03-24 09:57:55 --> Config Class Initialized
INFO - 2023-03-24 09:57:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:57:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:57:55 --> Utf8 Class Initialized
INFO - 2023-03-24 09:57:55 --> URI Class Initialized
INFO - 2023-03-24 09:57:55 --> Router Class Initialized
INFO - 2023-03-24 09:57:55 --> Output Class Initialized
INFO - 2023-03-24 09:57:55 --> Security Class Initialized
DEBUG - 2023-03-24 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:57:55 --> Input Class Initialized
INFO - 2023-03-24 09:57:55 --> Language Class Initialized
INFO - 2023-03-24 09:57:55 --> Loader Class Initialized
INFO - 2023-03-24 09:57:55 --> Controller Class Initialized
DEBUG - 2023-03-24 09:57:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:57:55 --> Database Driver Class Initialized
INFO - 2023-03-24 09:57:55 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:57:55 --> Final output sent to browser
DEBUG - 2023-03-24 09:57:55 --> Total execution time: 0.0192
INFO - 2023-03-24 09:58:37 --> Config Class Initialized
INFO - 2023-03-24 09:58:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:58:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:58:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:58:37 --> URI Class Initialized
INFO - 2023-03-24 09:58:37 --> Router Class Initialized
INFO - 2023-03-24 09:58:37 --> Output Class Initialized
INFO - 2023-03-24 09:58:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:58:37 --> Input Class Initialized
INFO - 2023-03-24 09:58:37 --> Language Class Initialized
INFO - 2023-03-24 09:58:37 --> Loader Class Initialized
INFO - 2023-03-24 09:58:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:58:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:58:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:58:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:58:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:58:37 --> Total execution time: 0.0178
INFO - 2023-03-24 09:58:37 --> Config Class Initialized
INFO - 2023-03-24 09:58:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:58:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:58:37 --> Utf8 Class Initialized
INFO - 2023-03-24 09:58:37 --> URI Class Initialized
INFO - 2023-03-24 09:58:37 --> Router Class Initialized
INFO - 2023-03-24 09:58:37 --> Output Class Initialized
INFO - 2023-03-24 09:58:37 --> Security Class Initialized
DEBUG - 2023-03-24 09:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:58:37 --> Input Class Initialized
INFO - 2023-03-24 09:58:37 --> Language Class Initialized
INFO - 2023-03-24 09:58:37 --> Loader Class Initialized
INFO - 2023-03-24 09:58:37 --> Controller Class Initialized
DEBUG - 2023-03-24 09:58:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:58:37 --> Database Driver Class Initialized
INFO - 2023-03-24 09:58:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:58:37 --> Final output sent to browser
DEBUG - 2023-03-24 09:58:37 --> Total execution time: 0.0572
INFO - 2023-03-24 09:59:22 --> Config Class Initialized
INFO - 2023-03-24 09:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:59:22 --> Utf8 Class Initialized
INFO - 2023-03-24 09:59:22 --> URI Class Initialized
INFO - 2023-03-24 09:59:22 --> Router Class Initialized
INFO - 2023-03-24 09:59:22 --> Output Class Initialized
INFO - 2023-03-24 09:59:22 --> Security Class Initialized
DEBUG - 2023-03-24 09:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:59:22 --> Input Class Initialized
INFO - 2023-03-24 09:59:22 --> Language Class Initialized
INFO - 2023-03-24 09:59:22 --> Loader Class Initialized
INFO - 2023-03-24 09:59:22 --> Controller Class Initialized
DEBUG - 2023-03-24 09:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:59:22 --> Final output sent to browser
DEBUG - 2023-03-24 09:59:22 --> Total execution time: 0.0462
INFO - 2023-03-24 09:59:22 --> Config Class Initialized
INFO - 2023-03-24 09:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:59:22 --> Utf8 Class Initialized
INFO - 2023-03-24 09:59:22 --> URI Class Initialized
INFO - 2023-03-24 09:59:22 --> Router Class Initialized
INFO - 2023-03-24 09:59:22 --> Output Class Initialized
INFO - 2023-03-24 09:59:22 --> Security Class Initialized
DEBUG - 2023-03-24 09:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:59:22 --> Input Class Initialized
INFO - 2023-03-24 09:59:22 --> Language Class Initialized
INFO - 2023-03-24 09:59:22 --> Loader Class Initialized
INFO - 2023-03-24 09:59:22 --> Controller Class Initialized
DEBUG - 2023-03-24 09:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:59:22 --> Database Driver Class Initialized
INFO - 2023-03-24 09:59:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:59:22 --> Final output sent to browser
DEBUG - 2023-03-24 09:59:22 --> Total execution time: 0.0540
INFO - 2023-03-24 09:59:25 --> Config Class Initialized
INFO - 2023-03-24 09:59:25 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:59:25 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:59:25 --> Utf8 Class Initialized
INFO - 2023-03-24 09:59:25 --> URI Class Initialized
INFO - 2023-03-24 09:59:25 --> Router Class Initialized
INFO - 2023-03-24 09:59:25 --> Output Class Initialized
INFO - 2023-03-24 09:59:25 --> Security Class Initialized
DEBUG - 2023-03-24 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:59:25 --> Input Class Initialized
INFO - 2023-03-24 09:59:25 --> Language Class Initialized
INFO - 2023-03-24 09:59:25 --> Loader Class Initialized
INFO - 2023-03-24 09:59:25 --> Controller Class Initialized
DEBUG - 2023-03-24 09:59:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:59:25 --> Database Driver Class Initialized
INFO - 2023-03-24 09:59:25 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:59:25 --> Final output sent to browser
DEBUG - 2023-03-24 09:59:25 --> Total execution time: 0.0192
INFO - 2023-03-24 09:59:25 --> Config Class Initialized
INFO - 2023-03-24 09:59:25 --> Hooks Class Initialized
DEBUG - 2023-03-24 09:59:25 --> UTF-8 Support Enabled
INFO - 2023-03-24 09:59:25 --> Utf8 Class Initialized
INFO - 2023-03-24 09:59:25 --> URI Class Initialized
INFO - 2023-03-24 09:59:25 --> Router Class Initialized
INFO - 2023-03-24 09:59:25 --> Output Class Initialized
INFO - 2023-03-24 09:59:25 --> Security Class Initialized
DEBUG - 2023-03-24 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 09:59:25 --> Input Class Initialized
INFO - 2023-03-24 09:59:25 --> Language Class Initialized
INFO - 2023-03-24 09:59:25 --> Loader Class Initialized
INFO - 2023-03-24 09:59:25 --> Controller Class Initialized
DEBUG - 2023-03-24 09:59:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 09:59:25 --> Database Driver Class Initialized
INFO - 2023-03-24 09:59:25 --> Model "Cluster_model" initialized
INFO - 2023-03-24 09:59:25 --> Final output sent to browser
DEBUG - 2023-03-24 09:59:25 --> Total execution time: 0.0569
INFO - 2023-03-24 10:03:28 --> Config Class Initialized
INFO - 2023-03-24 10:03:29 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:29 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:29 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:29 --> URI Class Initialized
INFO - 2023-03-24 10:03:29 --> Router Class Initialized
INFO - 2023-03-24 10:03:29 --> Output Class Initialized
INFO - 2023-03-24 10:03:29 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:29 --> Input Class Initialized
INFO - 2023-03-24 10:03:29 --> Language Class Initialized
INFO - 2023-03-24 10:03:29 --> Loader Class Initialized
INFO - 2023-03-24 10:03:29 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:29 --> Database Driver Class Initialized
INFO - 2023-03-24 10:03:29 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:03:29 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:29 --> Total execution time: 0.0611
INFO - 2023-03-24 10:03:29 --> Config Class Initialized
INFO - 2023-03-24 10:03:29 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:29 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:29 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:29 --> URI Class Initialized
INFO - 2023-03-24 10:03:29 --> Router Class Initialized
INFO - 2023-03-24 10:03:29 --> Output Class Initialized
INFO - 2023-03-24 10:03:29 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:29 --> Input Class Initialized
INFO - 2023-03-24 10:03:29 --> Language Class Initialized
INFO - 2023-03-24 10:03:29 --> Loader Class Initialized
INFO - 2023-03-24 10:03:29 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:29 --> Database Driver Class Initialized
INFO - 2023-03-24 10:03:29 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:03:29 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:29 --> Total execution time: 0.1394
INFO - 2023-03-24 10:03:32 --> Config Class Initialized
INFO - 2023-03-24 10:03:32 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:32 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:32 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:32 --> URI Class Initialized
INFO - 2023-03-24 10:03:32 --> Router Class Initialized
INFO - 2023-03-24 10:03:32 --> Output Class Initialized
INFO - 2023-03-24 10:03:32 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:32 --> Input Class Initialized
INFO - 2023-03-24 10:03:32 --> Language Class Initialized
INFO - 2023-03-24 10:03:32 --> Loader Class Initialized
INFO - 2023-03-24 10:03:32 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:32 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:32 --> Total execution time: 0.0464
INFO - 2023-03-24 10:03:32 --> Config Class Initialized
INFO - 2023-03-24 10:03:32 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:32 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:32 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:32 --> URI Class Initialized
INFO - 2023-03-24 10:03:32 --> Router Class Initialized
INFO - 2023-03-24 10:03:32 --> Output Class Initialized
INFO - 2023-03-24 10:03:32 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:32 --> Input Class Initialized
INFO - 2023-03-24 10:03:32 --> Language Class Initialized
INFO - 2023-03-24 10:03:32 --> Loader Class Initialized
INFO - 2023-03-24 10:03:32 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:32 --> Database Driver Class Initialized
INFO - 2023-03-24 10:03:32 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:03:32 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:32 --> Total execution time: 0.0142
INFO - 2023-03-24 10:03:34 --> Config Class Initialized
INFO - 2023-03-24 10:03:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:34 --> URI Class Initialized
INFO - 2023-03-24 10:03:34 --> Router Class Initialized
INFO - 2023-03-24 10:03:34 --> Output Class Initialized
INFO - 2023-03-24 10:03:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:34 --> Input Class Initialized
INFO - 2023-03-24 10:03:34 --> Language Class Initialized
INFO - 2023-03-24 10:03:34 --> Loader Class Initialized
INFO - 2023-03-24 10:03:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:03:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:03:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:34 --> Total execution time: 0.0646
INFO - 2023-03-24 10:03:35 --> Config Class Initialized
INFO - 2023-03-24 10:03:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:03:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:03:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:03:35 --> URI Class Initialized
INFO - 2023-03-24 10:03:35 --> Router Class Initialized
INFO - 2023-03-24 10:03:35 --> Output Class Initialized
INFO - 2023-03-24 10:03:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:03:35 --> Input Class Initialized
INFO - 2023-03-24 10:03:35 --> Language Class Initialized
INFO - 2023-03-24 10:03:35 --> Loader Class Initialized
INFO - 2023-03-24 10:03:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:03:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:03:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:03:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:03:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:03:35 --> Total execution time: 0.0169
INFO - 2023-03-24 10:04:34 --> Config Class Initialized
INFO - 2023-03-24 10:04:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:04:34 --> Config Class Initialized
INFO - 2023-03-24 10:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:04:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:04:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:04:34 --> URI Class Initialized
INFO - 2023-03-24 10:04:34 --> URI Class Initialized
INFO - 2023-03-24 10:04:34 --> Router Class Initialized
INFO - 2023-03-24 10:04:34 --> Router Class Initialized
INFO - 2023-03-24 10:04:34 --> Output Class Initialized
INFO - 2023-03-24 10:04:34 --> Output Class Initialized
INFO - 2023-03-24 10:04:34 --> Security Class Initialized
INFO - 2023-03-24 10:04:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:04:34 --> Input Class Initialized
INFO - 2023-03-24 10:04:34 --> Input Class Initialized
INFO - 2023-03-24 10:04:34 --> Language Class Initialized
INFO - 2023-03-24 10:04:34 --> Language Class Initialized
INFO - 2023-03-24 10:04:34 --> Loader Class Initialized
INFO - 2023-03-24 10:04:34 --> Loader Class Initialized
INFO - 2023-03-24 10:04:34 --> Controller Class Initialized
INFO - 2023-03-24 10:04:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:04:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:04:34 --> Model "Login_model" initialized
INFO - 2023-03-24 10:04:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:04:34 --> Total execution time: 0.0217
INFO - 2023-03-24 10:04:34 --> Config Class Initialized
INFO - 2023-03-24 10:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:04:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:04:34 --> URI Class Initialized
INFO - 2023-03-24 10:04:34 --> Router Class Initialized
INFO - 2023-03-24 10:04:34 --> Output Class Initialized
INFO - 2023-03-24 10:04:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:04:34 --> Input Class Initialized
INFO - 2023-03-24 10:04:34 --> Language Class Initialized
INFO - 2023-03-24 10:04:34 --> Loader Class Initialized
INFO - 2023-03-24 10:04:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:04:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:04:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:04:34 --> Total execution time: 0.0148
INFO - 2023-03-24 10:04:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:04:35 --> Total execution time: 0.1870
INFO - 2023-03-24 10:04:35 --> Config Class Initialized
INFO - 2023-03-24 10:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:04:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:04:35 --> URI Class Initialized
INFO - 2023-03-24 10:04:35 --> Router Class Initialized
INFO - 2023-03-24 10:04:35 --> Output Class Initialized
INFO - 2023-03-24 10:04:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:04:35 --> Input Class Initialized
INFO - 2023-03-24 10:04:35 --> Language Class Initialized
INFO - 2023-03-24 10:04:35 --> Loader Class Initialized
INFO - 2023-03-24 10:04:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:04:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:35 --> Model "Login_model" initialized
INFO - 2023-03-24 10:04:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:04:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:04:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:04:35 --> Total execution time: 0.1708
INFO - 2023-03-24 10:05:34 --> Config Class Initialized
INFO - 2023-03-24 10:05:34 --> Config Class Initialized
INFO - 2023-03-24 10:05:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:05:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:05:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:05:34 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:05:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:05:34 --> URI Class Initialized
INFO - 2023-03-24 10:05:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:05:34 --> Router Class Initialized
INFO - 2023-03-24 10:05:34 --> URI Class Initialized
INFO - 2023-03-24 10:05:34 --> Output Class Initialized
INFO - 2023-03-24 10:05:34 --> Router Class Initialized
INFO - 2023-03-24 10:05:34 --> Security Class Initialized
INFO - 2023-03-24 10:05:34 --> Output Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:05:34 --> Security Class Initialized
INFO - 2023-03-24 10:05:34 --> Input Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:05:34 --> Language Class Initialized
INFO - 2023-03-24 10:05:34 --> Input Class Initialized
INFO - 2023-03-24 10:05:34 --> Language Class Initialized
INFO - 2023-03-24 10:05:34 --> Loader Class Initialized
INFO - 2023-03-24 10:05:34 --> Controller Class Initialized
INFO - 2023-03-24 10:05:34 --> Loader Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:05:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:05:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:34 --> Model "Login_model" initialized
INFO - 2023-03-24 10:05:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:05:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:05:34 --> Total execution time: 0.0309
INFO - 2023-03-24 10:05:34 --> Config Class Initialized
INFO - 2023-03-24 10:05:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:05:34 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 10:05:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:05:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:05:34 --> URI Class Initialized
INFO - 2023-03-24 10:05:34 --> Router Class Initialized
INFO - 2023-03-24 10:05:34 --> Output Class Initialized
INFO - 2023-03-24 10:05:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:05:34 --> Input Class Initialized
INFO - 2023-03-24 10:05:34 --> Language Class Initialized
INFO - 2023-03-24 10:05:34 --> Loader Class Initialized
INFO - 2023-03-24 10:05:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:05:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:05:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:05:34 --> Total execution time: 0.0189
INFO - 2023-03-24 10:05:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:05:35 --> Total execution time: 0.1865
INFO - 2023-03-24 10:05:35 --> Config Class Initialized
INFO - 2023-03-24 10:05:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:05:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:05:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:05:35 --> URI Class Initialized
INFO - 2023-03-24 10:05:35 --> Router Class Initialized
INFO - 2023-03-24 10:05:35 --> Output Class Initialized
INFO - 2023-03-24 10:05:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:05:35 --> Input Class Initialized
INFO - 2023-03-24 10:05:35 --> Language Class Initialized
INFO - 2023-03-24 10:05:35 --> Loader Class Initialized
INFO - 2023-03-24 10:05:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:05:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:05:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:35 --> Model "Login_model" initialized
INFO - 2023-03-24 10:05:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:05:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:05:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:05:35 --> Total execution time: 0.2416
INFO - 2023-03-24 10:06:34 --> Config Class Initialized
INFO - 2023-03-24 10:06:34 --> Config Class Initialized
INFO - 2023-03-24 10:06:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:06:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:06:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:06:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:06:34 --> URI Class Initialized
INFO - 2023-03-24 10:06:34 --> URI Class Initialized
INFO - 2023-03-24 10:06:34 --> Router Class Initialized
INFO - 2023-03-24 10:06:34 --> Router Class Initialized
INFO - 2023-03-24 10:06:34 --> Output Class Initialized
INFO - 2023-03-24 10:06:34 --> Output Class Initialized
INFO - 2023-03-24 10:06:34 --> Security Class Initialized
INFO - 2023-03-24 10:06:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:06:34 --> Input Class Initialized
INFO - 2023-03-24 10:06:34 --> Input Class Initialized
INFO - 2023-03-24 10:06:34 --> Language Class Initialized
INFO - 2023-03-24 10:06:34 --> Language Class Initialized
INFO - 2023-03-24 10:06:34 --> Loader Class Initialized
INFO - 2023-03-24 10:06:34 --> Loader Class Initialized
INFO - 2023-03-24 10:06:34 --> Controller Class Initialized
INFO - 2023-03-24 10:06:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:06:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:34 --> Model "Login_model" initialized
INFO - 2023-03-24 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:06:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:06:34 --> Total execution time: 0.0230
INFO - 2023-03-24 10:06:34 --> Config Class Initialized
INFO - 2023-03-24 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:06:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:06:34 --> URI Class Initialized
INFO - 2023-03-24 10:06:34 --> Router Class Initialized
INFO - 2023-03-24 10:06:34 --> Output Class Initialized
INFO - 2023-03-24 10:06:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:06:34 --> Input Class Initialized
INFO - 2023-03-24 10:06:34 --> Language Class Initialized
INFO - 2023-03-24 10:06:34 --> Loader Class Initialized
INFO - 2023-03-24 10:06:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:06:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:06:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:06:34 --> Total execution time: 0.0552
INFO - 2023-03-24 10:06:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:06:35 --> Total execution time: 0.2102
INFO - 2023-03-24 10:06:35 --> Config Class Initialized
INFO - 2023-03-24 10:06:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:06:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:06:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:06:35 --> URI Class Initialized
INFO - 2023-03-24 10:06:35 --> Router Class Initialized
INFO - 2023-03-24 10:06:35 --> Output Class Initialized
INFO - 2023-03-24 10:06:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:06:35 --> Input Class Initialized
INFO - 2023-03-24 10:06:35 --> Language Class Initialized
INFO - 2023-03-24 10:06:35 --> Loader Class Initialized
INFO - 2023-03-24 10:06:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:06:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:06:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:35 --> Model "Login_model" initialized
INFO - 2023-03-24 10:06:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:06:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:06:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:06:35 --> Total execution time: 0.1578
INFO - 2023-03-24 10:07:34 --> Config Class Initialized
INFO - 2023-03-24 10:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:07:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:07:34 --> URI Class Initialized
INFO - 2023-03-24 10:07:34 --> Router Class Initialized
INFO - 2023-03-24 10:07:34 --> Config Class Initialized
INFO - 2023-03-24 10:07:34 --> Output Class Initialized
INFO - 2023-03-24 10:07:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:07:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:07:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:07:34 --> Input Class Initialized
INFO - 2023-03-24 10:07:34 --> URI Class Initialized
INFO - 2023-03-24 10:07:34 --> Language Class Initialized
INFO - 2023-03-24 10:07:34 --> Router Class Initialized
INFO - 2023-03-24 10:07:34 --> Output Class Initialized
INFO - 2023-03-24 10:07:34 --> Loader Class Initialized
INFO - 2023-03-24 10:07:34 --> Security Class Initialized
INFO - 2023-03-24 10:07:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:07:34 --> Input Class Initialized
INFO - 2023-03-24 10:07:34 --> Language Class Initialized
INFO - 2023-03-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:34 --> Loader Class Initialized
INFO - 2023-03-24 10:07:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:34 --> Model "Login_model" initialized
INFO - 2023-03-24 10:07:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:07:34 --> Total execution time: 0.0231
INFO - 2023-03-24 10:07:34 --> Config Class Initialized
INFO - 2023-03-24 10:07:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:07:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:07:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:07:34 --> URI Class Initialized
INFO - 2023-03-24 10:07:34 --> Router Class Initialized
INFO - 2023-03-24 10:07:34 --> Output Class Initialized
INFO - 2023-03-24 10:07:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:07:34 --> Input Class Initialized
INFO - 2023-03-24 10:07:34 --> Language Class Initialized
INFO - 2023-03-24 10:07:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:07:34 --> Loader Class Initialized
INFO - 2023-03-24 10:07:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:07:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:07:34 --> Total execution time: 0.0171
INFO - 2023-03-24 10:07:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:07:35 --> Total execution time: 0.1791
INFO - 2023-03-24 10:07:35 --> Config Class Initialized
INFO - 2023-03-24 10:07:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:07:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:07:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:07:35 --> URI Class Initialized
INFO - 2023-03-24 10:07:35 --> Router Class Initialized
INFO - 2023-03-24 10:07:35 --> Output Class Initialized
INFO - 2023-03-24 10:07:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:07:35 --> Input Class Initialized
INFO - 2023-03-24 10:07:35 --> Language Class Initialized
INFO - 2023-03-24 10:07:35 --> Loader Class Initialized
INFO - 2023-03-24 10:07:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:07:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:07:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:35 --> Model "Login_model" initialized
INFO - 2023-03-24 10:07:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:07:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:07:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:07:35 --> Total execution time: 0.1830
INFO - 2023-03-24 10:08:34 --> Config Class Initialized
INFO - 2023-03-24 10:08:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:08:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:34 --> URI Class Initialized
INFO - 2023-03-24 10:08:34 --> Router Class Initialized
INFO - 2023-03-24 10:08:34 --> Output Class Initialized
INFO - 2023-03-24 10:08:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:34 --> Input Class Initialized
INFO - 2023-03-24 10:08:34 --> Language Class Initialized
INFO - 2023-03-24 10:08:34 --> Loader Class Initialized
INFO - 2023-03-24 10:08:34 --> Controller Class Initialized
INFO - 2023-03-24 10:08:34 --> Config Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:34 --> Hooks Class Initialized
INFO - 2023-03-24 10:08:34 --> Database Driver Class Initialized
DEBUG - 2023-03-24 10:08:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:34 --> URI Class Initialized
INFO - 2023-03-24 10:08:34 --> Router Class Initialized
INFO - 2023-03-24 10:08:34 --> Output Class Initialized
INFO - 2023-03-24 10:08:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:34 --> Input Class Initialized
INFO - 2023-03-24 10:08:34 --> Language Class Initialized
INFO - 2023-03-24 10:08:34 --> Loader Class Initialized
INFO - 2023-03-24 10:08:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:34 --> Model "Login_model" initialized
INFO - 2023-03-24 10:08:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:34 --> Total execution time: 0.0199
INFO - 2023-03-24 10:08:34 --> Config Class Initialized
INFO - 2023-03-24 10:08:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:08:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:34 --> URI Class Initialized
INFO - 2023-03-24 10:08:34 --> Router Class Initialized
INFO - 2023-03-24 10:08:34 --> Output Class Initialized
INFO - 2023-03-24 10:08:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:34 --> Input Class Initialized
INFO - 2023-03-24 10:08:34 --> Language Class Initialized
INFO - 2023-03-24 10:08:34 --> Loader Class Initialized
INFO - 2023-03-24 10:08:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:34 --> Total execution time: 0.0633
INFO - 2023-03-24 10:08:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:35 --> Total execution time: 0.2390
INFO - 2023-03-24 10:08:35 --> Config Class Initialized
INFO - 2023-03-24 10:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:35 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:35 --> URI Class Initialized
INFO - 2023-03-24 10:08:35 --> Router Class Initialized
INFO - 2023-03-24 10:08:35 --> Output Class Initialized
INFO - 2023-03-24 10:08:35 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:35 --> Input Class Initialized
INFO - 2023-03-24 10:08:35 --> Language Class Initialized
INFO - 2023-03-24 10:08:35 --> Loader Class Initialized
INFO - 2023-03-24 10:08:35 --> Controller Class Initialized
DEBUG - 2023-03-24 10:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:35 --> Model "Login_model" initialized
INFO - 2023-03-24 10:08:35 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:35 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:35 --> Total execution time: 0.1668
INFO - 2023-03-24 10:08:51 --> Config Class Initialized
INFO - 2023-03-24 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:51 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:51 --> URI Class Initialized
INFO - 2023-03-24 10:08:51 --> Router Class Initialized
INFO - 2023-03-24 10:08:51 --> Output Class Initialized
INFO - 2023-03-24 10:08:51 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:51 --> Input Class Initialized
INFO - 2023-03-24 10:08:51 --> Language Class Initialized
INFO - 2023-03-24 10:08:51 --> Loader Class Initialized
INFO - 2023-03-24 10:08:51 --> Controller Class Initialized
DEBUG - 2023-03-24 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:51 --> Total execution time: 0.0220
INFO - 2023-03-24 10:08:51 --> Config Class Initialized
INFO - 2023-03-24 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:08:51 --> Utf8 Class Initialized
INFO - 2023-03-24 10:08:51 --> URI Class Initialized
INFO - 2023-03-24 10:08:51 --> Router Class Initialized
INFO - 2023-03-24 10:08:51 --> Output Class Initialized
INFO - 2023-03-24 10:08:51 --> Security Class Initialized
DEBUG - 2023-03-24 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:08:51 --> Input Class Initialized
INFO - 2023-03-24 10:08:51 --> Language Class Initialized
INFO - 2023-03-24 10:08:51 --> Loader Class Initialized
INFO - 2023-03-24 10:08:51 --> Controller Class Initialized
DEBUG - 2023-03-24 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:08:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:08:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:08:51 --> Total execution time: 0.0570
INFO - 2023-03-24 10:09:51 --> Config Class Initialized
INFO - 2023-03-24 10:09:51 --> Hooks Class Initialized
INFO - 2023-03-24 10:09:51 --> Config Class Initialized
DEBUG - 2023-03-24 10:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:51 --> Hooks Class Initialized
INFO - 2023-03-24 10:09:51 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:51 --> URI Class Initialized
INFO - 2023-03-24 10:09:51 --> Utf8 Class Initialized
INFO - 2023-03-24 10:09:51 --> URI Class Initialized
INFO - 2023-03-24 10:09:51 --> Router Class Initialized
INFO - 2023-03-24 10:09:51 --> Router Class Initialized
INFO - 2023-03-24 10:09:51 --> Output Class Initialized
INFO - 2023-03-24 10:09:51 --> Output Class Initialized
INFO - 2023-03-24 10:09:51 --> Security Class Initialized
INFO - 2023-03-24 10:09:51 --> Security Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:09:51 --> Input Class Initialized
INFO - 2023-03-24 10:09:51 --> Input Class Initialized
INFO - 2023-03-24 10:09:51 --> Language Class Initialized
INFO - 2023-03-24 10:09:51 --> Language Class Initialized
INFO - 2023-03-24 10:09:51 --> Loader Class Initialized
INFO - 2023-03-24 10:09:51 --> Loader Class Initialized
INFO - 2023-03-24 10:09:51 --> Controller Class Initialized
INFO - 2023-03-24 10:09:51 --> Controller Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Model "Login_model" initialized
INFO - 2023-03-24 10:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:51 --> Total execution time: 0.0240
INFO - 2023-03-24 10:09:51 --> Config Class Initialized
INFO - 2023-03-24 10:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:51 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:51 --> Utf8 Class Initialized
INFO - 2023-03-24 10:09:51 --> URI Class Initialized
INFO - 2023-03-24 10:09:51 --> Router Class Initialized
INFO - 2023-03-24 10:09:51 --> Output Class Initialized
INFO - 2023-03-24 10:09:51 --> Security Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:09:51 --> Input Class Initialized
INFO - 2023-03-24 10:09:51 --> Language Class Initialized
INFO - 2023-03-24 10:09:51 --> Loader Class Initialized
INFO - 2023-03-24 10:09:51 --> Controller Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:51 --> Total execution time: 0.0579
INFO - 2023-03-24 10:09:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:51 --> Total execution time: 0.2696
INFO - 2023-03-24 10:09:51 --> Config Class Initialized
INFO - 2023-03-24 10:09:51 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:09:51 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:51 --> Utf8 Class Initialized
INFO - 2023-03-24 10:09:51 --> URI Class Initialized
INFO - 2023-03-24 10:09:51 --> Router Class Initialized
INFO - 2023-03-24 10:09:51 --> Output Class Initialized
INFO - 2023-03-24 10:09:51 --> Security Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:09:51 --> Input Class Initialized
INFO - 2023-03-24 10:09:51 --> Language Class Initialized
INFO - 2023-03-24 10:09:51 --> Loader Class Initialized
INFO - 2023-03-24 10:09:51 --> Controller Class Initialized
DEBUG - 2023-03-24 10:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Model "Login_model" initialized
INFO - 2023-03-24 10:09:51 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:51 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:51 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:51 --> Total execution time: 0.1830
INFO - 2023-03-24 10:09:58 --> Config Class Initialized
INFO - 2023-03-24 10:09:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:09:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:09:58 --> URI Class Initialized
INFO - 2023-03-24 10:09:58 --> Router Class Initialized
INFO - 2023-03-24 10:09:58 --> Output Class Initialized
INFO - 2023-03-24 10:09:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:09:58 --> Input Class Initialized
INFO - 2023-03-24 10:09:58 --> Language Class Initialized
INFO - 2023-03-24 10:09:58 --> Loader Class Initialized
INFO - 2023-03-24 10:09:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:09:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:09:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:58 --> Total execution time: 0.0176
INFO - 2023-03-24 10:09:58 --> Config Class Initialized
INFO - 2023-03-24 10:09:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:09:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:09:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:09:58 --> URI Class Initialized
INFO - 2023-03-24 10:09:58 --> Router Class Initialized
INFO - 2023-03-24 10:09:58 --> Output Class Initialized
INFO - 2023-03-24 10:09:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:09:58 --> Input Class Initialized
INFO - 2023-03-24 10:09:58 --> Language Class Initialized
INFO - 2023-03-24 10:09:58 --> Loader Class Initialized
INFO - 2023-03-24 10:09:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:09:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:09:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:09:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:09:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:09:58 --> Total execution time: 0.0130
INFO - 2023-03-24 10:10:58 --> Config Class Initialized
INFO - 2023-03-24 10:10:58 --> Config Class Initialized
INFO - 2023-03-24 10:10:58 --> Hooks Class Initialized
INFO - 2023-03-24 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:10:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:10:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:10:58 --> URI Class Initialized
INFO - 2023-03-24 10:10:58 --> URI Class Initialized
INFO - 2023-03-24 10:10:58 --> Router Class Initialized
INFO - 2023-03-24 10:10:58 --> Router Class Initialized
INFO - 2023-03-24 10:10:58 --> Output Class Initialized
INFO - 2023-03-24 10:10:58 --> Output Class Initialized
INFO - 2023-03-24 10:10:58 --> Security Class Initialized
INFO - 2023-03-24 10:10:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:10:58 --> Input Class Initialized
INFO - 2023-03-24 10:10:58 --> Input Class Initialized
INFO - 2023-03-24 10:10:58 --> Language Class Initialized
INFO - 2023-03-24 10:10:58 --> Language Class Initialized
INFO - 2023-03-24 10:10:58 --> Loader Class Initialized
INFO - 2023-03-24 10:10:58 --> Loader Class Initialized
INFO - 2023-03-24 10:10:58 --> Controller Class Initialized
INFO - 2023-03-24 10:10:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:10:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:10:58 --> Total execution time: 0.0226
INFO - 2023-03-24 10:10:58 --> Config Class Initialized
INFO - 2023-03-24 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:10:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:10:58 --> URI Class Initialized
INFO - 2023-03-24 10:10:58 --> Router Class Initialized
INFO - 2023-03-24 10:10:58 --> Output Class Initialized
INFO - 2023-03-24 10:10:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:10:58 --> Input Class Initialized
INFO - 2023-03-24 10:10:58 --> Language Class Initialized
INFO - 2023-03-24 10:10:58 --> Loader Class Initialized
INFO - 2023-03-24 10:10:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:10:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:10:58 --> Total execution time: 0.0156
INFO - 2023-03-24 10:10:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:10:58 --> Total execution time: 0.1932
INFO - 2023-03-24 10:10:58 --> Config Class Initialized
INFO - 2023-03-24 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:10:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:10:58 --> URI Class Initialized
INFO - 2023-03-24 10:10:58 --> Router Class Initialized
INFO - 2023-03-24 10:10:58 --> Output Class Initialized
INFO - 2023-03-24 10:10:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:10:58 --> Input Class Initialized
INFO - 2023-03-24 10:10:58 --> Language Class Initialized
INFO - 2023-03-24 10:10:58 --> Loader Class Initialized
INFO - 2023-03-24 10:10:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:10:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:10:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:10:58 --> Total execution time: 0.2124
INFO - 2023-03-24 10:11:58 --> Config Class Initialized
INFO - 2023-03-24 10:11:58 --> Config Class Initialized
INFO - 2023-03-24 10:11:58 --> Hooks Class Initialized
INFO - 2023-03-24 10:11:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:11:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:11:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:11:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:11:58 --> URI Class Initialized
INFO - 2023-03-24 10:11:58 --> URI Class Initialized
INFO - 2023-03-24 10:11:58 --> Router Class Initialized
INFO - 2023-03-24 10:11:58 --> Router Class Initialized
INFO - 2023-03-24 10:11:58 --> Output Class Initialized
INFO - 2023-03-24 10:11:58 --> Output Class Initialized
INFO - 2023-03-24 10:11:58 --> Security Class Initialized
INFO - 2023-03-24 10:11:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:11:58 --> Input Class Initialized
INFO - 2023-03-24 10:11:58 --> Input Class Initialized
INFO - 2023-03-24 10:11:58 --> Language Class Initialized
INFO - 2023-03-24 10:11:58 --> Language Class Initialized
INFO - 2023-03-24 10:11:58 --> Loader Class Initialized
INFO - 2023-03-24 10:11:58 --> Loader Class Initialized
INFO - 2023-03-24 10:11:58 --> Controller Class Initialized
INFO - 2023-03-24 10:11:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:11:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:11:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:11:58 --> Total execution time: 0.0280
INFO - 2023-03-24 10:11:58 --> Config Class Initialized
INFO - 2023-03-24 10:11:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:11:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:11:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:11:58 --> URI Class Initialized
INFO - 2023-03-24 10:11:58 --> Router Class Initialized
INFO - 2023-03-24 10:11:58 --> Output Class Initialized
INFO - 2023-03-24 10:11:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:11:58 --> Input Class Initialized
INFO - 2023-03-24 10:11:58 --> Language Class Initialized
INFO - 2023-03-24 10:11:58 --> Loader Class Initialized
INFO - 2023-03-24 10:11:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:11:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:11:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:11:58 --> Total execution time: 0.0169
INFO - 2023-03-24 10:11:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:11:58 --> Total execution time: 0.2243
INFO - 2023-03-24 10:11:58 --> Config Class Initialized
INFO - 2023-03-24 10:11:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:11:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:11:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:11:58 --> URI Class Initialized
INFO - 2023-03-24 10:11:58 --> Router Class Initialized
INFO - 2023-03-24 10:11:58 --> Output Class Initialized
INFO - 2023-03-24 10:11:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:11:58 --> Input Class Initialized
INFO - 2023-03-24 10:11:58 --> Language Class Initialized
INFO - 2023-03-24 10:11:58 --> Loader Class Initialized
INFO - 2023-03-24 10:11:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:11:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:11:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:11:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:11:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:11:58 --> Total execution time: 0.2244
INFO - 2023-03-24 10:12:58 --> Config Class Initialized
INFO - 2023-03-24 10:12:58 --> Config Class Initialized
INFO - 2023-03-24 10:12:58 --> Hooks Class Initialized
INFO - 2023-03-24 10:12:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:12:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:12:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:12:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:12:58 --> URI Class Initialized
INFO - 2023-03-24 10:12:58 --> URI Class Initialized
INFO - 2023-03-24 10:12:58 --> Router Class Initialized
INFO - 2023-03-24 10:12:58 --> Router Class Initialized
INFO - 2023-03-24 10:12:58 --> Output Class Initialized
INFO - 2023-03-24 10:12:58 --> Output Class Initialized
INFO - 2023-03-24 10:12:58 --> Security Class Initialized
INFO - 2023-03-24 10:12:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:12:58 --> Input Class Initialized
INFO - 2023-03-24 10:12:58 --> Input Class Initialized
INFO - 2023-03-24 10:12:58 --> Language Class Initialized
INFO - 2023-03-24 10:12:58 --> Language Class Initialized
INFO - 2023-03-24 10:12:58 --> Loader Class Initialized
INFO - 2023-03-24 10:12:58 --> Loader Class Initialized
INFO - 2023-03-24 10:12:58 --> Controller Class Initialized
INFO - 2023-03-24 10:12:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:12:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:12:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:12:58 --> Total execution time: 0.0210
INFO - 2023-03-24 10:12:58 --> Config Class Initialized
INFO - 2023-03-24 10:12:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:12:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:12:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:12:58 --> URI Class Initialized
INFO - 2023-03-24 10:12:58 --> Router Class Initialized
INFO - 2023-03-24 10:12:58 --> Output Class Initialized
INFO - 2023-03-24 10:12:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:12:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:12:58 --> Input Class Initialized
INFO - 2023-03-24 10:12:58 --> Language Class Initialized
INFO - 2023-03-24 10:12:58 --> Loader Class Initialized
INFO - 2023-03-24 10:12:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:12:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:12:58 --> Total execution time: 0.0152
INFO - 2023-03-24 10:12:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:12:58 --> Total execution time: 0.1734
INFO - 2023-03-24 10:12:58 --> Config Class Initialized
INFO - 2023-03-24 10:12:58 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:12:58 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:12:58 --> Utf8 Class Initialized
INFO - 2023-03-24 10:12:58 --> URI Class Initialized
INFO - 2023-03-24 10:12:58 --> Router Class Initialized
INFO - 2023-03-24 10:12:58 --> Output Class Initialized
INFO - 2023-03-24 10:12:58 --> Security Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:12:58 --> Input Class Initialized
INFO - 2023-03-24 10:12:58 --> Language Class Initialized
INFO - 2023-03-24 10:12:58 --> Loader Class Initialized
INFO - 2023-03-24 10:12:58 --> Controller Class Initialized
DEBUG - 2023-03-24 10:12:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Model "Login_model" initialized
INFO - 2023-03-24 10:12:58 --> Database Driver Class Initialized
INFO - 2023-03-24 10:12:58 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:12:58 --> Final output sent to browser
DEBUG - 2023-03-24 10:12:58 --> Total execution time: 0.1780
INFO - 2023-03-24 10:13:43 --> Config Class Initialized
INFO - 2023-03-24 10:13:43 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:13:43 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:13:43 --> Utf8 Class Initialized
INFO - 2023-03-24 10:13:43 --> URI Class Initialized
INFO - 2023-03-24 10:13:43 --> Router Class Initialized
INFO - 2023-03-24 10:13:43 --> Output Class Initialized
INFO - 2023-03-24 10:13:43 --> Security Class Initialized
DEBUG - 2023-03-24 10:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:13:43 --> Input Class Initialized
INFO - 2023-03-24 10:13:43 --> Language Class Initialized
INFO - 2023-03-24 10:13:43 --> Loader Class Initialized
INFO - 2023-03-24 10:13:43 --> Controller Class Initialized
DEBUG - 2023-03-24 10:13:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:13:43 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:43 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:43 --> Model "Login_model" initialized
INFO - 2023-03-24 10:13:43 --> Final output sent to browser
DEBUG - 2023-03-24 10:13:43 --> Total execution time: 0.0218
INFO - 2023-03-24 10:13:43 --> Config Class Initialized
INFO - 2023-03-24 10:13:43 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:13:43 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:13:43 --> Utf8 Class Initialized
INFO - 2023-03-24 10:13:43 --> URI Class Initialized
INFO - 2023-03-24 10:13:43 --> Router Class Initialized
INFO - 2023-03-24 10:13:43 --> Output Class Initialized
INFO - 2023-03-24 10:13:43 --> Security Class Initialized
DEBUG - 2023-03-24 10:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:13:43 --> Input Class Initialized
INFO - 2023-03-24 10:13:43 --> Language Class Initialized
INFO - 2023-03-24 10:13:43 --> Loader Class Initialized
INFO - 2023-03-24 10:13:43 --> Controller Class Initialized
DEBUG - 2023-03-24 10:13:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:13:43 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:43 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:43 --> Model "Login_model" initialized
INFO - 2023-03-24 10:13:43 --> Final output sent to browser
DEBUG - 2023-03-24 10:13:43 --> Total execution time: 0.0626
INFO - 2023-03-24 10:13:55 --> Config Class Initialized
INFO - 2023-03-24 10:13:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:13:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:13:55 --> Utf8 Class Initialized
INFO - 2023-03-24 10:13:55 --> URI Class Initialized
INFO - 2023-03-24 10:13:55 --> Router Class Initialized
INFO - 2023-03-24 10:13:55 --> Output Class Initialized
INFO - 2023-03-24 10:13:55 --> Security Class Initialized
DEBUG - 2023-03-24 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:13:55 --> Input Class Initialized
INFO - 2023-03-24 10:13:55 --> Language Class Initialized
INFO - 2023-03-24 10:13:55 --> Loader Class Initialized
INFO - 2023-03-24 10:13:55 --> Controller Class Initialized
DEBUG - 2023-03-24 10:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:13:55 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:55 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:55 --> Model "Login_model" initialized
INFO - 2023-03-24 10:13:55 --> Final output sent to browser
DEBUG - 2023-03-24 10:13:55 --> Total execution time: 0.0238
INFO - 2023-03-24 10:13:55 --> Config Class Initialized
INFO - 2023-03-24 10:13:55 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:13:55 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:13:55 --> Utf8 Class Initialized
INFO - 2023-03-24 10:13:55 --> URI Class Initialized
INFO - 2023-03-24 10:13:55 --> Router Class Initialized
INFO - 2023-03-24 10:13:55 --> Output Class Initialized
INFO - 2023-03-24 10:13:55 --> Security Class Initialized
DEBUG - 2023-03-24 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:13:55 --> Input Class Initialized
INFO - 2023-03-24 10:13:55 --> Language Class Initialized
INFO - 2023-03-24 10:13:55 --> Loader Class Initialized
INFO - 2023-03-24 10:13:55 --> Controller Class Initialized
DEBUG - 2023-03-24 10:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:13:55 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:55 --> Database Driver Class Initialized
INFO - 2023-03-24 10:13:55 --> Model "Login_model" initialized
INFO - 2023-03-24 10:13:55 --> Final output sent to browser
DEBUG - 2023-03-24 10:13:55 --> Total execution time: 0.0221
INFO - 2023-03-24 10:24:22 --> Config Class Initialized
INFO - 2023-03-24 10:24:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:24:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:24:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:24:22 --> URI Class Initialized
INFO - 2023-03-24 10:24:22 --> Router Class Initialized
INFO - 2023-03-24 10:24:22 --> Output Class Initialized
INFO - 2023-03-24 10:24:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:24:22 --> Input Class Initialized
INFO - 2023-03-24 10:24:22 --> Language Class Initialized
INFO - 2023-03-24 10:24:22 --> Loader Class Initialized
INFO - 2023-03-24 10:24:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:24:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:24:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:24:22 --> Total execution time: 0.0044
INFO - 2023-03-24 10:24:22 --> Config Class Initialized
INFO - 2023-03-24 10:24:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:24:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:24:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:24:22 --> URI Class Initialized
INFO - 2023-03-24 10:24:22 --> Router Class Initialized
INFO - 2023-03-24 10:24:22 --> Output Class Initialized
INFO - 2023-03-24 10:24:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:24:22 --> Input Class Initialized
INFO - 2023-03-24 10:24:22 --> Language Class Initialized
INFO - 2023-03-24 10:24:22 --> Loader Class Initialized
INFO - 2023-03-24 10:24:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:24:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:24:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:24:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:24:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:24:22 --> Total execution time: 0.0572
INFO - 2023-03-24 10:24:24 --> Config Class Initialized
INFO - 2023-03-24 10:24:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:24:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:24:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:24:24 --> URI Class Initialized
INFO - 2023-03-24 10:24:24 --> Router Class Initialized
INFO - 2023-03-24 10:24:24 --> Output Class Initialized
INFO - 2023-03-24 10:24:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:24:24 --> Input Class Initialized
INFO - 2023-03-24 10:24:24 --> Language Class Initialized
INFO - 2023-03-24 10:24:24 --> Loader Class Initialized
INFO - 2023-03-24 10:24:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:24:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:24:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:24:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:24:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:24:24 --> Total execution time: 0.3204
INFO - 2023-03-24 10:24:24 --> Config Class Initialized
INFO - 2023-03-24 10:24:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:24:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:24:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:24:24 --> URI Class Initialized
INFO - 2023-03-24 10:24:24 --> Router Class Initialized
INFO - 2023-03-24 10:24:24 --> Output Class Initialized
INFO - 2023-03-24 10:24:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:24:24 --> Input Class Initialized
INFO - 2023-03-24 10:24:24 --> Language Class Initialized
INFO - 2023-03-24 10:24:24 --> Loader Class Initialized
INFO - 2023-03-24 10:24:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:24:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:24:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:24:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:24:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:24:24 --> Total execution time: 0.0547
INFO - 2023-03-24 10:25:24 --> Config Class Initialized
INFO - 2023-03-24 10:25:24 --> Hooks Class Initialized
INFO - 2023-03-24 10:25:24 --> Config Class Initialized
DEBUG - 2023-03-24 10:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:25:24 --> Hooks Class Initialized
INFO - 2023-03-24 10:25:24 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:25:24 --> URI Class Initialized
INFO - 2023-03-24 10:25:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:25:24 --> Router Class Initialized
INFO - 2023-03-24 10:25:24 --> URI Class Initialized
INFO - 2023-03-24 10:25:24 --> Output Class Initialized
INFO - 2023-03-24 10:25:24 --> Router Class Initialized
INFO - 2023-03-24 10:25:24 --> Security Class Initialized
INFO - 2023-03-24 10:25:24 --> Output Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:25:24 --> Security Class Initialized
INFO - 2023-03-24 10:25:24 --> Input Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:25:24 --> Language Class Initialized
INFO - 2023-03-24 10:25:24 --> Input Class Initialized
INFO - 2023-03-24 10:25:24 --> Language Class Initialized
INFO - 2023-03-24 10:25:24 --> Loader Class Initialized
INFO - 2023-03-24 10:25:24 --> Loader Class Initialized
INFO - 2023-03-24 10:25:24 --> Controller Class Initialized
INFO - 2023-03-24 10:25:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:25:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:25:24 --> Total execution time: 0.0192
INFO - 2023-03-24 10:25:24 --> Config Class Initialized
INFO - 2023-03-24 10:25:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:25:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:25:24 --> URI Class Initialized
INFO - 2023-03-24 10:25:24 --> Router Class Initialized
INFO - 2023-03-24 10:25:24 --> Output Class Initialized
INFO - 2023-03-24 10:25:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:25:24 --> Input Class Initialized
INFO - 2023-03-24 10:25:24 --> Language Class Initialized
INFO - 2023-03-24 10:25:24 --> Loader Class Initialized
INFO - 2023-03-24 10:25:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:25:24 --> Total execution time: 0.0146
INFO - 2023-03-24 10:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:25:24 --> Total execution time: 0.1919
INFO - 2023-03-24 10:25:24 --> Config Class Initialized
INFO - 2023-03-24 10:25:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:25:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:25:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:25:24 --> URI Class Initialized
INFO - 2023-03-24 10:25:24 --> Router Class Initialized
INFO - 2023-03-24 10:25:24 --> Output Class Initialized
INFO - 2023-03-24 10:25:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:25:24 --> Input Class Initialized
INFO - 2023-03-24 10:25:24 --> Language Class Initialized
INFO - 2023-03-24 10:25:24 --> Loader Class Initialized
INFO - 2023-03-24 10:25:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:25:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:25:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:25:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:25:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:25:24 --> Total execution time: 0.2250
INFO - 2023-03-24 10:26:24 --> Config Class Initialized
INFO - 2023-03-24 10:26:24 --> Config Class Initialized
INFO - 2023-03-24 10:26:24 --> Hooks Class Initialized
INFO - 2023-03-24 10:26:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:26:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:26:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:26:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:26:24 --> URI Class Initialized
INFO - 2023-03-24 10:26:24 --> URI Class Initialized
INFO - 2023-03-24 10:26:24 --> Router Class Initialized
INFO - 2023-03-24 10:26:24 --> Router Class Initialized
INFO - 2023-03-24 10:26:24 --> Output Class Initialized
INFO - 2023-03-24 10:26:24 --> Output Class Initialized
INFO - 2023-03-24 10:26:24 --> Security Class Initialized
INFO - 2023-03-24 10:26:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:26:24 --> Input Class Initialized
INFO - 2023-03-24 10:26:24 --> Language Class Initialized
INFO - 2023-03-24 10:26:24 --> Input Class Initialized
INFO - 2023-03-24 10:26:24 --> Language Class Initialized
INFO - 2023-03-24 10:26:24 --> Loader Class Initialized
INFO - 2023-03-24 10:26:24 --> Loader Class Initialized
INFO - 2023-03-24 10:26:24 --> Controller Class Initialized
INFO - 2023-03-24 10:26:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:26:24 --> Total execution time: 0.0457
INFO - 2023-03-24 10:26:24 --> Config Class Initialized
INFO - 2023-03-24 10:26:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:26:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:26:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:26:24 --> URI Class Initialized
INFO - 2023-03-24 10:26:24 --> Router Class Initialized
INFO - 2023-03-24 10:26:24 --> Output Class Initialized
INFO - 2023-03-24 10:26:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:26:24 --> Input Class Initialized
INFO - 2023-03-24 10:26:24 --> Language Class Initialized
INFO - 2023-03-24 10:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:26:24 --> Loader Class Initialized
INFO - 2023-03-24 10:26:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:26:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:26:24 --> Total execution time: 0.0222
INFO - 2023-03-24 10:26:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:26:24 --> Total execution time: 0.2454
INFO - 2023-03-24 10:26:24 --> Config Class Initialized
INFO - 2023-03-24 10:26:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:26:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:26:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:26:24 --> URI Class Initialized
INFO - 2023-03-24 10:26:24 --> Router Class Initialized
INFO - 2023-03-24 10:26:24 --> Output Class Initialized
INFO - 2023-03-24 10:26:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:26:24 --> Input Class Initialized
INFO - 2023-03-24 10:26:24 --> Language Class Initialized
INFO - 2023-03-24 10:26:24 --> Loader Class Initialized
INFO - 2023-03-24 10:26:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:26:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:26:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:26:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:26:24 --> Total execution time: 0.2121
INFO - 2023-03-24 10:27:24 --> Config Class Initialized
INFO - 2023-03-24 10:27:24 --> Config Class Initialized
INFO - 2023-03-24 10:27:24 --> Hooks Class Initialized
INFO - 2023-03-24 10:27:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:27:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:27:24 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:27:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:27:24 --> URI Class Initialized
INFO - 2023-03-24 10:27:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:27:24 --> Router Class Initialized
INFO - 2023-03-24 10:27:24 --> URI Class Initialized
INFO - 2023-03-24 10:27:24 --> Output Class Initialized
INFO - 2023-03-24 10:27:24 --> Router Class Initialized
INFO - 2023-03-24 10:27:24 --> Security Class Initialized
INFO - 2023-03-24 10:27:24 --> Output Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:27:24 --> Security Class Initialized
INFO - 2023-03-24 10:27:24 --> Input Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:27:24 --> Language Class Initialized
INFO - 2023-03-24 10:27:24 --> Input Class Initialized
INFO - 2023-03-24 10:27:24 --> Language Class Initialized
INFO - 2023-03-24 10:27:24 --> Loader Class Initialized
INFO - 2023-03-24 10:27:24 --> Loader Class Initialized
INFO - 2023-03-24 10:27:24 --> Controller Class Initialized
INFO - 2023-03-24 10:27:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:27:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:27:24 --> Total execution time: 0.0192
INFO - 2023-03-24 10:27:24 --> Config Class Initialized
INFO - 2023-03-24 10:27:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:27:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:27:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:27:24 --> URI Class Initialized
INFO - 2023-03-24 10:27:24 --> Router Class Initialized
INFO - 2023-03-24 10:27:24 --> Output Class Initialized
INFO - 2023-03-24 10:27:24 --> Security Class Initialized
INFO - 2023-03-24 10:27:24 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:27:24 --> Input Class Initialized
INFO - 2023-03-24 10:27:24 --> Language Class Initialized
INFO - 2023-03-24 10:27:24 --> Loader Class Initialized
INFO - 2023-03-24 10:27:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:27:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:27:24 --> Total execution time: 0.0178
INFO - 2023-03-24 10:27:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:27:24 --> Total execution time: 0.1762
INFO - 2023-03-24 10:27:24 --> Config Class Initialized
INFO - 2023-03-24 10:27:24 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:27:24 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:27:24 --> Utf8 Class Initialized
INFO - 2023-03-24 10:27:24 --> URI Class Initialized
INFO - 2023-03-24 10:27:24 --> Router Class Initialized
INFO - 2023-03-24 10:27:24 --> Output Class Initialized
INFO - 2023-03-24 10:27:24 --> Security Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:27:24 --> Input Class Initialized
INFO - 2023-03-24 10:27:24 --> Language Class Initialized
INFO - 2023-03-24 10:27:24 --> Loader Class Initialized
INFO - 2023-03-24 10:27:24 --> Controller Class Initialized
DEBUG - 2023-03-24 10:27:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Model "Login_model" initialized
INFO - 2023-03-24 10:27:24 --> Database Driver Class Initialized
INFO - 2023-03-24 10:27:24 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:27:24 --> Final output sent to browser
DEBUG - 2023-03-24 10:27:24 --> Total execution time: 0.1654
INFO - 2023-03-24 10:28:03 --> Config Class Initialized
INFO - 2023-03-24 10:28:03 --> Config Class Initialized
INFO - 2023-03-24 10:28:03 --> Hooks Class Initialized
INFO - 2023-03-24 10:28:03 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:03 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:03 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:03 --> URI Class Initialized
INFO - 2023-03-24 10:28:03 --> Router Class Initialized
DEBUG - 2023-03-24 10:28:03 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:03 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:03 --> URI Class Initialized
INFO - 2023-03-24 10:28:03 --> Router Class Initialized
INFO - 2023-03-24 10:28:03 --> Output Class Initialized
INFO - 2023-03-24 10:28:03 --> Output Class Initialized
INFO - 2023-03-24 10:28:03 --> Security Class Initialized
INFO - 2023-03-24 10:28:03 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:03 --> Input Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:03 --> Language Class Initialized
INFO - 2023-03-24 10:28:03 --> Input Class Initialized
INFO - 2023-03-24 10:28:03 --> Language Class Initialized
INFO - 2023-03-24 10:28:03 --> Loader Class Initialized
INFO - 2023-03-24 10:28:03 --> Loader Class Initialized
INFO - 2023-03-24 10:28:03 --> Controller Class Initialized
INFO - 2023-03-24 10:28:03 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:03 --> Total execution time: 0.0219
INFO - 2023-03-24 10:28:03 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:03 --> Config Class Initialized
INFO - 2023-03-24 10:28:03 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:03 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:03 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:03 --> URI Class Initialized
INFO - 2023-03-24 10:28:03 --> Router Class Initialized
INFO - 2023-03-24 10:28:03 --> Output Class Initialized
INFO - 2023-03-24 10:28:03 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:03 --> Input Class Initialized
INFO - 2023-03-24 10:28:03 --> Language Class Initialized
INFO - 2023-03-24 10:28:03 --> Loader Class Initialized
INFO - 2023-03-24 10:28:03 --> Controller Class Initialized
INFO - 2023-03-24 10:28:03 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:28:03 --> Total execution time: 0.0271
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Config Class Initialized
INFO - 2023-03-24 10:28:03 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:03 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:03 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:03 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:03 --> URI Class Initialized
INFO - 2023-03-24 10:28:03 --> Router Class Initialized
INFO - 2023-03-24 10:28:03 --> Output Class Initialized
INFO - 2023-03-24 10:28:03 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:03 --> Input Class Initialized
INFO - 2023-03-24 10:28:03 --> Language Class Initialized
INFO - 2023-03-24 10:28:03 --> Loader Class Initialized
INFO - 2023-03-24 10:28:03 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:03 --> Total execution time: 0.0494
INFO - 2023-03-24 10:28:03 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:03 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:03 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:03 --> Total execution time: 0.0975
INFO - 2023-03-24 10:28:09 --> Config Class Initialized
INFO - 2023-03-24 10:28:09 --> Config Class Initialized
INFO - 2023-03-24 10:28:09 --> Hooks Class Initialized
INFO - 2023-03-24 10:28:09 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:09 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:09 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:28:09 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:09 --> URI Class Initialized
INFO - 2023-03-24 10:28:09 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:09 --> Router Class Initialized
INFO - 2023-03-24 10:28:09 --> URI Class Initialized
INFO - 2023-03-24 10:28:09 --> Output Class Initialized
INFO - 2023-03-24 10:28:09 --> Router Class Initialized
INFO - 2023-03-24 10:28:09 --> Security Class Initialized
INFO - 2023-03-24 10:28:09 --> Output Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:09 --> Security Class Initialized
INFO - 2023-03-24 10:28:09 --> Input Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:09 --> Language Class Initialized
INFO - 2023-03-24 10:28:09 --> Input Class Initialized
INFO - 2023-03-24 10:28:09 --> Loader Class Initialized
INFO - 2023-03-24 10:28:09 --> Language Class Initialized
INFO - 2023-03-24 10:28:09 --> Controller Class Initialized
INFO - 2023-03-24 10:28:09 --> Loader Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:09 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:09 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:09 --> Total execution time: 0.2823
INFO - 2023-03-24 10:28:09 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:09 --> Config Class Initialized
INFO - 2023-03-24 10:28:09 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:09 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:09 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:09 --> URI Class Initialized
INFO - 2023-03-24 10:28:09 --> Router Class Initialized
INFO - 2023-03-24 10:28:09 --> Output Class Initialized
INFO - 2023-03-24 10:28:09 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:09 --> Input Class Initialized
INFO - 2023-03-24 10:28:09 --> Language Class Initialized
INFO - 2023-03-24 10:28:09 --> Final output sent to browser
INFO - 2023-03-24 10:28:09 --> Loader Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Total execution time: 0.2878
INFO - 2023-03-24 10:28:09 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Config Class Initialized
INFO - 2023-03-24 10:28:09 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:09 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:09 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:09 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:09 --> URI Class Initialized
INFO - 2023-03-24 10:28:09 --> Router Class Initialized
INFO - 2023-03-24 10:28:09 --> Output Class Initialized
INFO - 2023-03-24 10:28:09 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:09 --> Input Class Initialized
INFO - 2023-03-24 10:28:09 --> Language Class Initialized
INFO - 2023-03-24 10:28:09 --> Loader Class Initialized
INFO - 2023-03-24 10:28:09 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:09 --> Total execution time: 0.0496
INFO - 2023-03-24 10:28:09 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:09 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:09 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:09 --> Total execution time: 0.1023
INFO - 2023-03-24 10:28:22 --> Config Class Initialized
INFO - 2023-03-24 10:28:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:28:22 --> Config Class Initialized
INFO - 2023-03-24 10:28:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:22 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:28:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:22 --> URI Class Initialized
INFO - 2023-03-24 10:28:22 --> URI Class Initialized
INFO - 2023-03-24 10:28:22 --> Router Class Initialized
INFO - 2023-03-24 10:28:22 --> Router Class Initialized
INFO - 2023-03-24 10:28:22 --> Output Class Initialized
INFO - 2023-03-24 10:28:22 --> Output Class Initialized
INFO - 2023-03-24 10:28:22 --> Security Class Initialized
INFO - 2023-03-24 10:28:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:22 --> Input Class Initialized
INFO - 2023-03-24 10:28:22 --> Input Class Initialized
INFO - 2023-03-24 10:28:22 --> Language Class Initialized
INFO - 2023-03-24 10:28:22 --> Language Class Initialized
INFO - 2023-03-24 10:28:22 --> Loader Class Initialized
INFO - 2023-03-24 10:28:22 --> Loader Class Initialized
INFO - 2023-03-24 10:28:22 --> Controller Class Initialized
INFO - 2023-03-24 10:28:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:28:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:22 --> Total execution time: 0.0282
INFO - 2023-03-24 10:28:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:22 --> Config Class Initialized
INFO - 2023-03-24 10:28:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:28:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:28:22 --> Total execution time: 0.0321
INFO - 2023-03-24 10:28:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:22 --> URI Class Initialized
INFO - 2023-03-24 10:28:22 --> Router Class Initialized
INFO - 2023-03-24 10:28:22 --> Output Class Initialized
INFO - 2023-03-24 10:28:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:22 --> Input Class Initialized
INFO - 2023-03-24 10:28:22 --> Language Class Initialized
INFO - 2023-03-24 10:28:22 --> Loader Class Initialized
INFO - 2023-03-24 10:28:22 --> Config Class Initialized
INFO - 2023-03-24 10:28:22 --> Controller Class Initialized
INFO - 2023-03-24 10:28:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:28:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:28:22 --> URI Class Initialized
INFO - 2023-03-24 10:28:22 --> Router Class Initialized
INFO - 2023-03-24 10:28:22 --> Output Class Initialized
INFO - 2023-03-24 10:28:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:28:22 --> Input Class Initialized
INFO - 2023-03-24 10:28:22 --> Language Class Initialized
INFO - 2023-03-24 10:28:22 --> Loader Class Initialized
INFO - 2023-03-24 10:28:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:28:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:28:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:28:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:22 --> Total execution time: 0.0229
INFO - 2023-03-24 10:28:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:28:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:28:23 --> Total execution time: 0.0689
INFO - 2023-03-24 10:29:22 --> Config Class Initialized
INFO - 2023-03-24 10:29:22 --> Config Class Initialized
INFO - 2023-03-24 10:29:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:29:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:29:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:29:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:29:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:29:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:29:22 --> URI Class Initialized
INFO - 2023-03-24 10:29:22 --> URI Class Initialized
INFO - 2023-03-24 10:29:22 --> Router Class Initialized
INFO - 2023-03-24 10:29:22 --> Router Class Initialized
INFO - 2023-03-24 10:29:22 --> Output Class Initialized
INFO - 2023-03-24 10:29:22 --> Output Class Initialized
INFO - 2023-03-24 10:29:22 --> Security Class Initialized
INFO - 2023-03-24 10:29:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:29:22 --> Input Class Initialized
INFO - 2023-03-24 10:29:22 --> Input Class Initialized
INFO - 2023-03-24 10:29:22 --> Language Class Initialized
INFO - 2023-03-24 10:29:22 --> Language Class Initialized
INFO - 2023-03-24 10:29:22 --> Loader Class Initialized
INFO - 2023-03-24 10:29:22 --> Loader Class Initialized
INFO - 2023-03-24 10:29:22 --> Controller Class Initialized
INFO - 2023-03-24 10:29:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:29:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:29:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:29:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:29:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:29:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:29:22 --> Total execution time: 0.0246
INFO - 2023-03-24 10:29:22 --> Config Class Initialized
INFO - 2023-03-24 10:29:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:29:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:29:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:29:22 --> URI Class Initialized
INFO - 2023-03-24 10:29:22 --> Router Class Initialized
INFO - 2023-03-24 10:29:22 --> Output Class Initialized
INFO - 2023-03-24 10:29:22 --> Security Class Initialized
INFO - 2023-03-24 10:29:22 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:29:22 --> Input Class Initialized
INFO - 2023-03-24 10:29:22 --> Language Class Initialized
INFO - 2023-03-24 10:29:22 --> Loader Class Initialized
INFO - 2023-03-24 10:29:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:29:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:29:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:29:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:29:22 --> Total execution time: 0.0147
INFO - 2023-03-24 10:29:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:29:23 --> Total execution time: 0.1844
INFO - 2023-03-24 10:29:23 --> Config Class Initialized
INFO - 2023-03-24 10:29:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:29:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:29:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:29:23 --> URI Class Initialized
INFO - 2023-03-24 10:29:23 --> Router Class Initialized
INFO - 2023-03-24 10:29:23 --> Output Class Initialized
INFO - 2023-03-24 10:29:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:29:23 --> Input Class Initialized
INFO - 2023-03-24 10:29:23 --> Language Class Initialized
INFO - 2023-03-24 10:29:23 --> Loader Class Initialized
INFO - 2023-03-24 10:29:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:29:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:29:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:29:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:29:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:29:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:29:23 --> Total execution time: 0.1685
INFO - 2023-03-24 10:30:22 --> Config Class Initialized
INFO - 2023-03-24 10:30:22 --> Config Class Initialized
INFO - 2023-03-24 10:30:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:30:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:30:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:30:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:30:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:30:22 --> URI Class Initialized
INFO - 2023-03-24 10:30:22 --> URI Class Initialized
INFO - 2023-03-24 10:30:22 --> Router Class Initialized
INFO - 2023-03-24 10:30:22 --> Router Class Initialized
INFO - 2023-03-24 10:30:22 --> Output Class Initialized
INFO - 2023-03-24 10:30:22 --> Output Class Initialized
INFO - 2023-03-24 10:30:22 --> Security Class Initialized
INFO - 2023-03-24 10:30:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:30:22 --> Input Class Initialized
INFO - 2023-03-24 10:30:22 --> Input Class Initialized
INFO - 2023-03-24 10:30:22 --> Language Class Initialized
INFO - 2023-03-24 10:30:22 --> Language Class Initialized
INFO - 2023-03-24 10:30:22 --> Loader Class Initialized
INFO - 2023-03-24 10:30:22 --> Loader Class Initialized
INFO - 2023-03-24 10:30:22 --> Controller Class Initialized
INFO - 2023-03-24 10:30:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:30:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:30:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:30:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:30:22 --> Total execution time: 0.0185
INFO - 2023-03-24 10:30:22 --> Config Class Initialized
INFO - 2023-03-24 10:30:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:30:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:30:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:30:22 --> URI Class Initialized
INFO - 2023-03-24 10:30:22 --> Router Class Initialized
INFO - 2023-03-24 10:30:22 --> Output Class Initialized
INFO - 2023-03-24 10:30:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:30:22 --> Input Class Initialized
INFO - 2023-03-24 10:30:22 --> Language Class Initialized
INFO - 2023-03-24 10:30:22 --> Loader Class Initialized
INFO - 2023-03-24 10:30:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:30:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:30:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:30:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:30:22 --> Total execution time: 0.0150
INFO - 2023-03-24 10:30:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:30:23 --> Total execution time: 0.1760
INFO - 2023-03-24 10:30:23 --> Config Class Initialized
INFO - 2023-03-24 10:30:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:30:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:30:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:30:23 --> URI Class Initialized
INFO - 2023-03-24 10:30:23 --> Router Class Initialized
INFO - 2023-03-24 10:30:23 --> Output Class Initialized
INFO - 2023-03-24 10:30:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:30:23 --> Input Class Initialized
INFO - 2023-03-24 10:30:23 --> Language Class Initialized
INFO - 2023-03-24 10:30:23 --> Loader Class Initialized
INFO - 2023-03-24 10:30:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:30:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:30:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:30:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:30:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:30:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:30:23 --> Total execution time: 0.1597
INFO - 2023-03-24 10:31:22 --> Config Class Initialized
INFO - 2023-03-24 10:31:22 --> Config Class Initialized
INFO - 2023-03-24 10:31:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:31:22 --> URI Class Initialized
INFO - 2023-03-24 10:31:22 --> URI Class Initialized
INFO - 2023-03-24 10:31:22 --> Router Class Initialized
INFO - 2023-03-24 10:31:22 --> Router Class Initialized
INFO - 2023-03-24 10:31:22 --> Output Class Initialized
INFO - 2023-03-24 10:31:22 --> Output Class Initialized
INFO - 2023-03-24 10:31:22 --> Security Class Initialized
INFO - 2023-03-24 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:31:22 --> Input Class Initialized
INFO - 2023-03-24 10:31:22 --> Input Class Initialized
INFO - 2023-03-24 10:31:22 --> Language Class Initialized
INFO - 2023-03-24 10:31:22 --> Language Class Initialized
INFO - 2023-03-24 10:31:22 --> Loader Class Initialized
INFO - 2023-03-24 10:31:22 --> Loader Class Initialized
INFO - 2023-03-24 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:31:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:31:22 --> Total execution time: 0.0216
INFO - 2023-03-24 10:31:22 --> Config Class Initialized
INFO - 2023-03-24 10:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:31:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:31:22 --> URI Class Initialized
INFO - 2023-03-24 10:31:22 --> Router Class Initialized
INFO - 2023-03-24 10:31:22 --> Output Class Initialized
INFO - 2023-03-24 10:31:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:31:22 --> Input Class Initialized
INFO - 2023-03-24 10:31:22 --> Language Class Initialized
INFO - 2023-03-24 10:31:22 --> Loader Class Initialized
INFO - 2023-03-24 10:31:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:31:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:31:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:31:22 --> Total execution time: 0.0143
INFO - 2023-03-24 10:31:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:31:23 --> Total execution time: 0.1697
INFO - 2023-03-24 10:31:23 --> Config Class Initialized
INFO - 2023-03-24 10:31:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:31:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:31:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:31:23 --> URI Class Initialized
INFO - 2023-03-24 10:31:23 --> Router Class Initialized
INFO - 2023-03-24 10:31:23 --> Output Class Initialized
INFO - 2023-03-24 10:31:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:31:23 --> Input Class Initialized
INFO - 2023-03-24 10:31:23 --> Language Class Initialized
INFO - 2023-03-24 10:31:23 --> Loader Class Initialized
INFO - 2023-03-24 10:31:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:31:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:31:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:31:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:31:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:31:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:31:23 --> Total execution time: 0.1855
INFO - 2023-03-24 10:32:22 --> Config Class Initialized
INFO - 2023-03-24 10:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:32:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:32:22 --> URI Class Initialized
INFO - 2023-03-24 10:32:22 --> Router Class Initialized
INFO - 2023-03-24 10:32:22 --> Output Class Initialized
INFO - 2023-03-24 10:32:22 --> Security Class Initialized
INFO - 2023-03-24 10:32:22 --> Config Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:32:22 --> Hooks Class Initialized
INFO - 2023-03-24 10:32:22 --> Input Class Initialized
DEBUG - 2023-03-24 10:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:32:22 --> Language Class Initialized
INFO - 2023-03-24 10:32:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:32:22 --> Loader Class Initialized
INFO - 2023-03-24 10:32:22 --> URI Class Initialized
INFO - 2023-03-24 10:32:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:32:22 --> Router Class Initialized
INFO - 2023-03-24 10:32:22 --> Output Class Initialized
INFO - 2023-03-24 10:32:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:32:22 --> Input Class Initialized
INFO - 2023-03-24 10:32:22 --> Language Class Initialized
INFO - 2023-03-24 10:32:22 --> Loader Class Initialized
INFO - 2023-03-24 10:32:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:32:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:32:22 --> Model "Login_model" initialized
INFO - 2023-03-24 10:32:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:32:22 --> Total execution time: 0.0211
INFO - 2023-03-24 10:32:22 --> Config Class Initialized
INFO - 2023-03-24 10:32:22 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:32:22 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:32:22 --> Utf8 Class Initialized
INFO - 2023-03-24 10:32:22 --> URI Class Initialized
INFO - 2023-03-24 10:32:22 --> Router Class Initialized
INFO - 2023-03-24 10:32:22 --> Output Class Initialized
INFO - 2023-03-24 10:32:22 --> Security Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:32:22 --> Input Class Initialized
INFO - 2023-03-24 10:32:22 --> Language Class Initialized
INFO - 2023-03-24 10:32:22 --> Loader Class Initialized
INFO - 2023-03-24 10:32:22 --> Controller Class Initialized
DEBUG - 2023-03-24 10:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:32:22 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:22 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:32:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:32:22 --> Total execution time: 0.0153
INFO - 2023-03-24 10:32:22 --> Final output sent to browser
DEBUG - 2023-03-24 10:32:22 --> Total execution time: 0.1579
INFO - 2023-03-24 10:32:23 --> Config Class Initialized
INFO - 2023-03-24 10:32:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:32:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:32:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:32:23 --> URI Class Initialized
INFO - 2023-03-24 10:32:23 --> Router Class Initialized
INFO - 2023-03-24 10:32:23 --> Output Class Initialized
INFO - 2023-03-24 10:32:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:32:23 --> Input Class Initialized
INFO - 2023-03-24 10:32:23 --> Language Class Initialized
INFO - 2023-03-24 10:32:23 --> Loader Class Initialized
INFO - 2023-03-24 10:32:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:32:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:32:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:32:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:32:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:32:23 --> Total execution time: 0.1506
INFO - 2023-03-24 10:33:23 --> Config Class Initialized
INFO - 2023-03-24 10:33:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:33:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:33:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:33:23 --> Config Class Initialized
INFO - 2023-03-24 10:33:23 --> URI Class Initialized
INFO - 2023-03-24 10:33:23 --> Hooks Class Initialized
INFO - 2023-03-24 10:33:23 --> Router Class Initialized
DEBUG - 2023-03-24 10:33:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:33:23 --> Output Class Initialized
INFO - 2023-03-24 10:33:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:33:23 --> Security Class Initialized
INFO - 2023-03-24 10:33:23 --> URI Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:33:23 --> Input Class Initialized
INFO - 2023-03-24 10:33:23 --> Router Class Initialized
INFO - 2023-03-24 10:33:23 --> Language Class Initialized
INFO - 2023-03-24 10:33:23 --> Output Class Initialized
INFO - 2023-03-24 10:33:23 --> Security Class Initialized
INFO - 2023-03-24 10:33:23 --> Loader Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:33:23 --> Input Class Initialized
INFO - 2023-03-24 10:33:23 --> Controller Class Initialized
INFO - 2023-03-24 10:33:23 --> Language Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:33:23 --> Loader Class Initialized
INFO - 2023-03-24 10:33:23 --> Controller Class Initialized
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:33:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:33:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:33:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:33:23 --> Total execution time: 0.0182
INFO - 2023-03-24 10:33:23 --> Config Class Initialized
INFO - 2023-03-24 10:33:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:33:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:33:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:33:23 --> URI Class Initialized
INFO - 2023-03-24 10:33:23 --> Router Class Initialized
INFO - 2023-03-24 10:33:23 --> Output Class Initialized
INFO - 2023-03-24 10:33:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:33:23 --> Input Class Initialized
INFO - 2023-03-24 10:33:23 --> Language Class Initialized
INFO - 2023-03-24 10:33:23 --> Loader Class Initialized
INFO - 2023-03-24 10:33:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:33:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:33:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:33:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:33:23 --> Total execution time: 0.0141
INFO - 2023-03-24 10:33:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:33:23 --> Total execution time: 0.1631
INFO - 2023-03-24 10:33:23 --> Config Class Initialized
INFO - 2023-03-24 10:33:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:33:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:33:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:33:23 --> URI Class Initialized
INFO - 2023-03-24 10:33:23 --> Router Class Initialized
INFO - 2023-03-24 10:33:23 --> Output Class Initialized
INFO - 2023-03-24 10:33:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:33:23 --> Input Class Initialized
INFO - 2023-03-24 10:33:23 --> Language Class Initialized
INFO - 2023-03-24 10:33:23 --> Loader Class Initialized
INFO - 2023-03-24 10:33:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:33:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:33:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:33:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:33:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:33:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:33:23 --> Total execution time: 0.1752
INFO - 2023-03-24 10:34:23 --> Config Class Initialized
INFO - 2023-03-24 10:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:34:23 --> URI Class Initialized
INFO - 2023-03-24 10:34:23 --> Router Class Initialized
INFO - 2023-03-24 10:34:23 --> Output Class Initialized
INFO - 2023-03-24 10:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:34:23 --> Input Class Initialized
INFO - 2023-03-24 10:34:23 --> Language Class Initialized
INFO - 2023-03-24 10:34:23 --> Loader Class Initialized
INFO - 2023-03-24 10:34:23 --> Config Class Initialized
INFO - 2023-03-24 10:34:23 --> Controller Class Initialized
INFO - 2023-03-24 10:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> URI Class Initialized
INFO - 2023-03-24 10:34:23 --> Router Class Initialized
INFO - 2023-03-24 10:34:23 --> Output Class Initialized
INFO - 2023-03-24 10:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:34:23 --> Input Class Initialized
INFO - 2023-03-24 10:34:23 --> Language Class Initialized
INFO - 2023-03-24 10:34:23 --> Loader Class Initialized
INFO - 2023-03-24 10:34:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:34:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:34:23 --> Total execution time: 0.0201
INFO - 2023-03-24 10:34:23 --> Config Class Initialized
INFO - 2023-03-24 10:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:34:23 --> URI Class Initialized
INFO - 2023-03-24 10:34:23 --> Router Class Initialized
INFO - 2023-03-24 10:34:23 --> Output Class Initialized
INFO - 2023-03-24 10:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:34:23 --> Input Class Initialized
INFO - 2023-03-24 10:34:23 --> Language Class Initialized
INFO - 2023-03-24 10:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:34:23 --> Loader Class Initialized
INFO - 2023-03-24 10:34:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:34:23 --> Total execution time: 0.0167
INFO - 2023-03-24 10:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:34:23 --> Total execution time: 0.1938
INFO - 2023-03-24 10:34:23 --> Config Class Initialized
INFO - 2023-03-24 10:34:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:34:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:34:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:34:23 --> URI Class Initialized
INFO - 2023-03-24 10:34:23 --> Router Class Initialized
INFO - 2023-03-24 10:34:23 --> Output Class Initialized
INFO - 2023-03-24 10:34:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:34:23 --> Input Class Initialized
INFO - 2023-03-24 10:34:23 --> Language Class Initialized
INFO - 2023-03-24 10:34:23 --> Loader Class Initialized
INFO - 2023-03-24 10:34:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:34:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:34:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:34:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:34:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:34:23 --> Total execution time: 0.1858
INFO - 2023-03-24 10:35:23 --> Config Class Initialized
INFO - 2023-03-24 10:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:35:23 --> URI Class Initialized
INFO - 2023-03-24 10:35:23 --> Router Class Initialized
INFO - 2023-03-24 10:35:23 --> Output Class Initialized
INFO - 2023-03-24 10:35:23 --> Config Class Initialized
INFO - 2023-03-24 10:35:23 --> Security Class Initialized
INFO - 2023-03-24 10:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:35:23 --> Input Class Initialized
INFO - 2023-03-24 10:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:35:23 --> Language Class Initialized
INFO - 2023-03-24 10:35:23 --> URI Class Initialized
INFO - 2023-03-24 10:35:23 --> Loader Class Initialized
INFO - 2023-03-24 10:35:23 --> Router Class Initialized
INFO - 2023-03-24 10:35:23 --> Controller Class Initialized
INFO - 2023-03-24 10:35:23 --> Output Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Input Class Initialized
INFO - 2023-03-24 10:35:23 --> Language Class Initialized
INFO - 2023-03-24 10:35:23 --> Loader Class Initialized
INFO - 2023-03-24 10:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:35:23 --> Total execution time: 0.0341
INFO - 2023-03-24 10:35:23 --> Config Class Initialized
INFO - 2023-03-24 10:35:23 --> Hooks Class Initialized
INFO - 2023-03-24 10:35:23 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 10:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:35:23 --> URI Class Initialized
INFO - 2023-03-24 10:35:23 --> Router Class Initialized
INFO - 2023-03-24 10:35:23 --> Output Class Initialized
INFO - 2023-03-24 10:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:35:23 --> Input Class Initialized
INFO - 2023-03-24 10:35:23 --> Language Class Initialized
INFO - 2023-03-24 10:35:23 --> Loader Class Initialized
INFO - 2023-03-24 10:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:35:23 --> Total execution time: 0.0213
INFO - 2023-03-24 10:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:35:23 --> Total execution time: 0.1786
INFO - 2023-03-24 10:35:23 --> Config Class Initialized
INFO - 2023-03-24 10:35:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:35:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:35:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:35:23 --> URI Class Initialized
INFO - 2023-03-24 10:35:23 --> Router Class Initialized
INFO - 2023-03-24 10:35:23 --> Output Class Initialized
INFO - 2023-03-24 10:35:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:35:23 --> Input Class Initialized
INFO - 2023-03-24 10:35:23 --> Language Class Initialized
INFO - 2023-03-24 10:35:23 --> Loader Class Initialized
INFO - 2023-03-24 10:35:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:35:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:35:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:35:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:35:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:35:23 --> Total execution time: 0.1682
INFO - 2023-03-24 10:36:23 --> Config Class Initialized
INFO - 2023-03-24 10:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:36:23 --> URI Class Initialized
INFO - 2023-03-24 10:36:23 --> Router Class Initialized
INFO - 2023-03-24 10:36:23 --> Output Class Initialized
INFO - 2023-03-24 10:36:23 --> Security Class Initialized
INFO - 2023-03-24 10:36:23 --> Config Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:36:23 --> Hooks Class Initialized
INFO - 2023-03-24 10:36:23 --> Input Class Initialized
DEBUG - 2023-03-24 10:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:36:23 --> Language Class Initialized
INFO - 2023-03-24 10:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:36:23 --> URI Class Initialized
INFO - 2023-03-24 10:36:23 --> Loader Class Initialized
INFO - 2023-03-24 10:36:23 --> Router Class Initialized
INFO - 2023-03-24 10:36:23 --> Controller Class Initialized
INFO - 2023-03-24 10:36:23 --> Output Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Input Class Initialized
INFO - 2023-03-24 10:36:23 --> Language Class Initialized
INFO - 2023-03-24 10:36:23 --> Loader Class Initialized
INFO - 2023-03-24 10:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:36:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Final output sent to browser
INFO - 2023-03-24 10:36:23 --> Model "Cluster_model" initialized
DEBUG - 2023-03-24 10:36:23 --> Total execution time: 0.0214
INFO - 2023-03-24 10:36:23 --> Config Class Initialized
INFO - 2023-03-24 10:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:36:23 --> URI Class Initialized
INFO - 2023-03-24 10:36:23 --> Router Class Initialized
INFO - 2023-03-24 10:36:23 --> Output Class Initialized
INFO - 2023-03-24 10:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:36:23 --> Input Class Initialized
INFO - 2023-03-24 10:36:23 --> Language Class Initialized
INFO - 2023-03-24 10:36:23 --> Loader Class Initialized
INFO - 2023-03-24 10:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:36:23 --> Total execution time: 0.0151
INFO - 2023-03-24 10:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:36:23 --> Total execution time: 0.2047
INFO - 2023-03-24 10:36:23 --> Config Class Initialized
INFO - 2023-03-24 10:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:36:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:36:23 --> URI Class Initialized
INFO - 2023-03-24 10:36:23 --> Router Class Initialized
INFO - 2023-03-24 10:36:23 --> Output Class Initialized
INFO - 2023-03-24 10:36:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:36:23 --> Input Class Initialized
INFO - 2023-03-24 10:36:23 --> Language Class Initialized
INFO - 2023-03-24 10:36:23 --> Loader Class Initialized
INFO - 2023-03-24 10:36:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:36:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:36:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:36:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:36:23 --> Total execution time: 0.1622
INFO - 2023-03-24 10:37:23 --> Config Class Initialized
INFO - 2023-03-24 10:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:37:23 --> URI Class Initialized
INFO - 2023-03-24 10:37:23 --> Router Class Initialized
INFO - 2023-03-24 10:37:23 --> Output Class Initialized
INFO - 2023-03-24 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:37:23 --> Config Class Initialized
INFO - 2023-03-24 10:37:23 --> Input Class Initialized
INFO - 2023-03-24 10:37:23 --> Hooks Class Initialized
INFO - 2023-03-24 10:37:23 --> Language Class Initialized
DEBUG - 2023-03-24 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:37:23 --> Loader Class Initialized
INFO - 2023-03-24 10:37:23 --> URI Class Initialized
INFO - 2023-03-24 10:37:23 --> Controller Class Initialized
INFO - 2023-03-24 10:37:23 --> Router Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:37:23 --> Output Class Initialized
INFO - 2023-03-24 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Input Class Initialized
INFO - 2023-03-24 10:37:23 --> Language Class Initialized
INFO - 2023-03-24 10:37:23 --> Loader Class Initialized
INFO - 2023-03-24 10:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:37:23 --> Total execution time: 0.0259
INFO - 2023-03-24 10:37:23 --> Config Class Initialized
INFO - 2023-03-24 10:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:37:23 --> URI Class Initialized
INFO - 2023-03-24 10:37:23 --> Router Class Initialized
INFO - 2023-03-24 10:37:23 --> Output Class Initialized
INFO - 2023-03-24 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:37:23 --> Input Class Initialized
INFO - 2023-03-24 10:37:23 --> Language Class Initialized
INFO - 2023-03-24 10:37:23 --> Loader Class Initialized
INFO - 2023-03-24 10:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:37:23 --> Total execution time: 0.0601
INFO - 2023-03-24 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:37:23 --> Total execution time: 0.2210
INFO - 2023-03-24 10:37:23 --> Config Class Initialized
INFO - 2023-03-24 10:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:37:23 --> URI Class Initialized
INFO - 2023-03-24 10:37:23 --> Router Class Initialized
INFO - 2023-03-24 10:37:23 --> Output Class Initialized
INFO - 2023-03-24 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:37:23 --> Input Class Initialized
INFO - 2023-03-24 10:37:23 --> Language Class Initialized
INFO - 2023-03-24 10:37:23 --> Loader Class Initialized
INFO - 2023-03-24 10:37:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:37:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:37:23 --> Total execution time: 0.3405
INFO - 2023-03-24 10:38:23 --> Config Class Initialized
INFO - 2023-03-24 10:38:23 --> Config Class Initialized
INFO - 2023-03-24 10:38:23 --> Hooks Class Initialized
INFO - 2023-03-24 10:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:38:23 --> URI Class Initialized
INFO - 2023-03-24 10:38:23 --> URI Class Initialized
INFO - 2023-03-24 10:38:23 --> Router Class Initialized
INFO - 2023-03-24 10:38:23 --> Router Class Initialized
INFO - 2023-03-24 10:38:23 --> Output Class Initialized
INFO - 2023-03-24 10:38:23 --> Output Class Initialized
INFO - 2023-03-24 10:38:23 --> Security Class Initialized
INFO - 2023-03-24 10:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:38:23 --> Input Class Initialized
INFO - 2023-03-24 10:38:23 --> Input Class Initialized
INFO - 2023-03-24 10:38:23 --> Language Class Initialized
INFO - 2023-03-24 10:38:23 --> Language Class Initialized
INFO - 2023-03-24 10:38:23 --> Loader Class Initialized
INFO - 2023-03-24 10:38:23 --> Loader Class Initialized
INFO - 2023-03-24 10:38:23 --> Controller Class Initialized
INFO - 2023-03-24 10:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:38:23 --> Total execution time: 0.0340
INFO - 2023-03-24 10:38:23 --> Config Class Initialized
INFO - 2023-03-24 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:38:23 --> URI Class Initialized
INFO - 2023-03-24 10:38:23 --> Router Class Initialized
INFO - 2023-03-24 10:38:23 --> Output Class Initialized
INFO - 2023-03-24 10:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:38:23 --> Input Class Initialized
INFO - 2023-03-24 10:38:23 --> Language Class Initialized
INFO - 2023-03-24 10:38:23 --> Loader Class Initialized
INFO - 2023-03-24 10:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:38:23 --> Total execution time: 0.0581
INFO - 2023-03-24 10:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:38:23 --> Total execution time: 0.2424
INFO - 2023-03-24 10:38:23 --> Config Class Initialized
INFO - 2023-03-24 10:38:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:38:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:38:23 --> URI Class Initialized
INFO - 2023-03-24 10:38:23 --> Router Class Initialized
INFO - 2023-03-24 10:38:23 --> Output Class Initialized
INFO - 2023-03-24 10:38:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:38:23 --> Input Class Initialized
INFO - 2023-03-24 10:38:23 --> Language Class Initialized
INFO - 2023-03-24 10:38:23 --> Loader Class Initialized
INFO - 2023-03-24 10:38:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:38:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:38:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:38:23 --> Total execution time: 0.2684
INFO - 2023-03-24 10:39:23 --> Config Class Initialized
INFO - 2023-03-24 10:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:39:23 --> URI Class Initialized
INFO - 2023-03-24 10:39:23 --> Router Class Initialized
INFO - 2023-03-24 10:39:23 --> Output Class Initialized
INFO - 2023-03-24 10:39:23 --> Config Class Initialized
INFO - 2023-03-24 10:39:23 --> Security Class Initialized
INFO - 2023-03-24 10:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:39:23 --> Input Class Initialized
INFO - 2023-03-24 10:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:39:23 --> Language Class Initialized
INFO - 2023-03-24 10:39:23 --> URI Class Initialized
INFO - 2023-03-24 10:39:23 --> Loader Class Initialized
INFO - 2023-03-24 10:39:23 --> Router Class Initialized
INFO - 2023-03-24 10:39:23 --> Controller Class Initialized
INFO - 2023-03-24 10:39:23 --> Output Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:39:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Input Class Initialized
INFO - 2023-03-24 10:39:23 --> Language Class Initialized
INFO - 2023-03-24 10:39:23 --> Loader Class Initialized
INFO - 2023-03-24 10:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:39:23 --> Total execution time: 0.0220
INFO - 2023-03-24 10:39:23 --> Config Class Initialized
INFO - 2023-03-24 10:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:39:23 --> URI Class Initialized
INFO - 2023-03-24 10:39:23 --> Router Class Initialized
INFO - 2023-03-24 10:39:23 --> Output Class Initialized
INFO - 2023-03-24 10:39:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:39:23 --> Input Class Initialized
INFO - 2023-03-24 10:39:23 --> Language Class Initialized
INFO - 2023-03-24 10:39:23 --> Loader Class Initialized
INFO - 2023-03-24 10:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:39:23 --> Total execution time: 0.0557
INFO - 2023-03-24 10:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:39:23 --> Total execution time: 0.2542
INFO - 2023-03-24 10:39:23 --> Config Class Initialized
INFO - 2023-03-24 10:39:23 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:39:23 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:39:23 --> Utf8 Class Initialized
INFO - 2023-03-24 10:39:23 --> URI Class Initialized
INFO - 2023-03-24 10:39:23 --> Router Class Initialized
INFO - 2023-03-24 10:39:23 --> Output Class Initialized
INFO - 2023-03-24 10:39:23 --> Security Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:39:23 --> Input Class Initialized
INFO - 2023-03-24 10:39:23 --> Language Class Initialized
INFO - 2023-03-24 10:39:23 --> Loader Class Initialized
INFO - 2023-03-24 10:39:23 --> Controller Class Initialized
DEBUG - 2023-03-24 10:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Model "Login_model" initialized
INFO - 2023-03-24 10:39:23 --> Database Driver Class Initialized
INFO - 2023-03-24 10:39:23 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:39:23 --> Final output sent to browser
DEBUG - 2023-03-24 10:39:23 --> Total execution time: 0.1782
INFO - 2023-03-24 10:40:19 --> Config Class Initialized
INFO - 2023-03-24 10:40:19 --> Config Class Initialized
INFO - 2023-03-24 10:40:19 --> Hooks Class Initialized
INFO - 2023-03-24 10:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:40:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:40:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:40:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:40:19 --> URI Class Initialized
INFO - 2023-03-24 10:40:19 --> URI Class Initialized
INFO - 2023-03-24 10:40:19 --> Router Class Initialized
INFO - 2023-03-24 10:40:19 --> Router Class Initialized
INFO - 2023-03-24 10:40:19 --> Output Class Initialized
INFO - 2023-03-24 10:40:19 --> Output Class Initialized
INFO - 2023-03-24 10:40:19 --> Security Class Initialized
INFO - 2023-03-24 10:40:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:40:19 --> Input Class Initialized
INFO - 2023-03-24 10:40:19 --> Input Class Initialized
INFO - 2023-03-24 10:40:19 --> Language Class Initialized
INFO - 2023-03-24 10:40:19 --> Language Class Initialized
INFO - 2023-03-24 10:40:19 --> Loader Class Initialized
INFO - 2023-03-24 10:40:19 --> Loader Class Initialized
INFO - 2023-03-24 10:40:19 --> Controller Class Initialized
INFO - 2023-03-24 10:40:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:40:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:40:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:40:19 --> Total execution time: 0.0592
INFO - 2023-03-24 10:40:19 --> Model "Login_model" initialized
INFO - 2023-03-24 10:40:19 --> Config Class Initialized
INFO - 2023-03-24 10:40:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:40:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:40:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:40:19 --> URI Class Initialized
INFO - 2023-03-24 10:40:19 --> Router Class Initialized
INFO - 2023-03-24 10:40:19 --> Output Class Initialized
INFO - 2023-03-24 10:40:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:40:19 --> Input Class Initialized
INFO - 2023-03-24 10:40:19 --> Language Class Initialized
INFO - 2023-03-24 10:40:19 --> Loader Class Initialized
INFO - 2023-03-24 10:40:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:40:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:40:19 --> Total execution time: 0.0637
INFO - 2023-03-24 10:40:19 --> Config Class Initialized
INFO - 2023-03-24 10:40:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:40:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:40:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:40:20 --> Utf8 Class Initialized
INFO - 2023-03-24 10:40:20 --> URI Class Initialized
INFO - 2023-03-24 10:40:20 --> Router Class Initialized
INFO - 2023-03-24 10:40:20 --> Output Class Initialized
INFO - 2023-03-24 10:40:20 --> Security Class Initialized
DEBUG - 2023-03-24 10:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:40:20 --> Input Class Initialized
INFO - 2023-03-24 10:40:20 --> Language Class Initialized
INFO - 2023-03-24 10:40:20 --> Loader Class Initialized
INFO - 2023-03-24 10:40:20 --> Controller Class Initialized
DEBUG - 2023-03-24 10:40:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:40:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:40:20 --> Total execution time: 0.0494
INFO - 2023-03-24 10:40:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:40:20 --> Model "Login_model" initialized
INFO - 2023-03-24 10:40:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:40:20 --> Total execution time: 0.1021
INFO - 2023-03-24 10:41:19 --> Config Class Initialized
INFO - 2023-03-24 10:41:19 --> Config Class Initialized
INFO - 2023-03-24 10:41:19 --> Hooks Class Initialized
INFO - 2023-03-24 10:41:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:41:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:41:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:41:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:41:19 --> URI Class Initialized
INFO - 2023-03-24 10:41:19 --> URI Class Initialized
INFO - 2023-03-24 10:41:19 --> Router Class Initialized
INFO - 2023-03-24 10:41:19 --> Router Class Initialized
INFO - 2023-03-24 10:41:19 --> Output Class Initialized
INFO - 2023-03-24 10:41:19 --> Output Class Initialized
INFO - 2023-03-24 10:41:19 --> Security Class Initialized
INFO - 2023-03-24 10:41:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:41:19 --> Input Class Initialized
INFO - 2023-03-24 10:41:19 --> Input Class Initialized
INFO - 2023-03-24 10:41:19 --> Language Class Initialized
INFO - 2023-03-24 10:41:19 --> Language Class Initialized
INFO - 2023-03-24 10:41:19 --> Loader Class Initialized
INFO - 2023-03-24 10:41:19 --> Loader Class Initialized
INFO - 2023-03-24 10:41:19 --> Controller Class Initialized
INFO - 2023-03-24 10:41:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:41:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:41:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:41:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:41:19 --> Model "Login_model" initialized
INFO - 2023-03-24 10:41:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:41:19 --> Total execution time: 0.0203
INFO - 2023-03-24 10:41:19 --> Config Class Initialized
INFO - 2023-03-24 10:41:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:41:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:41:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:41:19 --> URI Class Initialized
INFO - 2023-03-24 10:41:19 --> Router Class Initialized
INFO - 2023-03-24 10:41:19 --> Output Class Initialized
INFO - 2023-03-24 10:41:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:41:19 --> Input Class Initialized
INFO - 2023-03-24 10:41:19 --> Language Class Initialized
INFO - 2023-03-24 10:41:19 --> Loader Class Initialized
INFO - 2023-03-24 10:41:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:41:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:41:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:41:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:41:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:41:19 --> Total execution time: 0.0167
INFO - 2023-03-24 10:41:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:41:20 --> Total execution time: 0.1844
INFO - 2023-03-24 10:41:20 --> Config Class Initialized
INFO - 2023-03-24 10:41:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:41:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:41:20 --> Utf8 Class Initialized
INFO - 2023-03-24 10:41:20 --> URI Class Initialized
INFO - 2023-03-24 10:41:20 --> Router Class Initialized
INFO - 2023-03-24 10:41:20 --> Output Class Initialized
INFO - 2023-03-24 10:41:20 --> Security Class Initialized
DEBUG - 2023-03-24 10:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:41:20 --> Input Class Initialized
INFO - 2023-03-24 10:41:20 --> Language Class Initialized
INFO - 2023-03-24 10:41:20 --> Loader Class Initialized
INFO - 2023-03-24 10:41:20 --> Controller Class Initialized
DEBUG - 2023-03-24 10:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:41:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:20 --> Model "Login_model" initialized
INFO - 2023-03-24 10:41:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:41:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:41:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:41:20 --> Total execution time: 0.2394
INFO - 2023-03-24 10:42:19 --> Config Class Initialized
INFO - 2023-03-24 10:42:19 --> Config Class Initialized
INFO - 2023-03-24 10:42:19 --> Hooks Class Initialized
INFO - 2023-03-24 10:42:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:42:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:42:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:42:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:42:19 --> URI Class Initialized
INFO - 2023-03-24 10:42:19 --> URI Class Initialized
INFO - 2023-03-24 10:42:19 --> Router Class Initialized
INFO - 2023-03-24 10:42:19 --> Router Class Initialized
INFO - 2023-03-24 10:42:19 --> Output Class Initialized
INFO - 2023-03-24 10:42:19 --> Security Class Initialized
INFO - 2023-03-24 10:42:19 --> Output Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:42:19 --> Security Class Initialized
INFO - 2023-03-24 10:42:19 --> Input Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:42:19 --> Language Class Initialized
INFO - 2023-03-24 10:42:19 --> Input Class Initialized
INFO - 2023-03-24 10:42:19 --> Loader Class Initialized
INFO - 2023-03-24 10:42:19 --> Language Class Initialized
INFO - 2023-03-24 10:42:19 --> Controller Class Initialized
INFO - 2023-03-24 10:42:19 --> Loader Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:42:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:42:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:19 --> Model "Login_model" initialized
INFO - 2023-03-24 10:42:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:42:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:42:19 --> Total execution time: 0.0257
INFO - 2023-03-24 10:42:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:42:19 --> Config Class Initialized
INFO - 2023-03-24 10:42:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:42:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:42:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:42:19 --> URI Class Initialized
INFO - 2023-03-24 10:42:19 --> Router Class Initialized
INFO - 2023-03-24 10:42:19 --> Output Class Initialized
INFO - 2023-03-24 10:42:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:42:19 --> Input Class Initialized
INFO - 2023-03-24 10:42:19 --> Language Class Initialized
INFO - 2023-03-24 10:42:19 --> Loader Class Initialized
INFO - 2023-03-24 10:42:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:42:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:42:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:42:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:42:19 --> Total execution time: 0.0515
INFO - 2023-03-24 10:42:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:42:20 --> Total execution time: 0.2059
INFO - 2023-03-24 10:42:20 --> Config Class Initialized
INFO - 2023-03-24 10:42:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:42:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:42:20 --> Utf8 Class Initialized
INFO - 2023-03-24 10:42:20 --> URI Class Initialized
INFO - 2023-03-24 10:42:20 --> Router Class Initialized
INFO - 2023-03-24 10:42:20 --> Output Class Initialized
INFO - 2023-03-24 10:42:20 --> Security Class Initialized
DEBUG - 2023-03-24 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:42:20 --> Input Class Initialized
INFO - 2023-03-24 10:42:20 --> Language Class Initialized
INFO - 2023-03-24 10:42:20 --> Loader Class Initialized
INFO - 2023-03-24 10:42:20 --> Controller Class Initialized
DEBUG - 2023-03-24 10:42:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:42:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:20 --> Model "Login_model" initialized
INFO - 2023-03-24 10:42:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:42:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:42:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:42:20 --> Total execution time: 0.2144
INFO - 2023-03-24 10:43:19 --> Config Class Initialized
INFO - 2023-03-24 10:43:19 --> Config Class Initialized
INFO - 2023-03-24 10:43:19 --> Hooks Class Initialized
INFO - 2023-03-24 10:43:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:43:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:19 --> URI Class Initialized
INFO - 2023-03-24 10:43:19 --> URI Class Initialized
INFO - 2023-03-24 10:43:19 --> Router Class Initialized
INFO - 2023-03-24 10:43:19 --> Router Class Initialized
INFO - 2023-03-24 10:43:19 --> Output Class Initialized
INFO - 2023-03-24 10:43:19 --> Output Class Initialized
INFO - 2023-03-24 10:43:19 --> Security Class Initialized
INFO - 2023-03-24 10:43:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:19 --> Input Class Initialized
INFO - 2023-03-24 10:43:19 --> Input Class Initialized
INFO - 2023-03-24 10:43:19 --> Language Class Initialized
INFO - 2023-03-24 10:43:19 --> Language Class Initialized
INFO - 2023-03-24 10:43:19 --> Loader Class Initialized
INFO - 2023-03-24 10:43:19 --> Loader Class Initialized
INFO - 2023-03-24 10:43:19 --> Controller Class Initialized
INFO - 2023-03-24 10:43:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:19 --> Model "Login_model" initialized
INFO - 2023-03-24 10:43:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:19 --> Total execution time: 0.1029
INFO - 2023-03-24 10:43:19 --> Config Class Initialized
INFO - 2023-03-24 10:43:19 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:19 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:19 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:19 --> URI Class Initialized
INFO - 2023-03-24 10:43:19 --> Router Class Initialized
INFO - 2023-03-24 10:43:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:19 --> Output Class Initialized
INFO - 2023-03-24 10:43:19 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:19 --> Input Class Initialized
INFO - 2023-03-24 10:43:19 --> Language Class Initialized
INFO - 2023-03-24 10:43:19 --> Loader Class Initialized
INFO - 2023-03-24 10:43:19 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:19 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:19 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:19 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:19 --> Total execution time: 0.0154
INFO - 2023-03-24 10:43:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:20 --> Total execution time: 0.2629
INFO - 2023-03-24 10:43:20 --> Config Class Initialized
INFO - 2023-03-24 10:43:20 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:20 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:20 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:20 --> URI Class Initialized
INFO - 2023-03-24 10:43:20 --> Router Class Initialized
INFO - 2023-03-24 10:43:20 --> Output Class Initialized
INFO - 2023-03-24 10:43:20 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:20 --> Input Class Initialized
INFO - 2023-03-24 10:43:20 --> Language Class Initialized
INFO - 2023-03-24 10:43:20 --> Loader Class Initialized
INFO - 2023-03-24 10:43:20 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:20 --> Model "Login_model" initialized
INFO - 2023-03-24 10:43:20 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:20 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:20 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:20 --> Total execution time: 0.2174
INFO - 2023-03-24 10:43:34 --> Config Class Initialized
INFO - 2023-03-24 10:43:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:34 --> URI Class Initialized
INFO - 2023-03-24 10:43:34 --> Router Class Initialized
INFO - 2023-03-24 10:43:34 --> Output Class Initialized
INFO - 2023-03-24 10:43:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:34 --> Input Class Initialized
INFO - 2023-03-24 10:43:34 --> Language Class Initialized
INFO - 2023-03-24 10:43:34 --> Loader Class Initialized
INFO - 2023-03-24 10:43:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:34 --> Total execution time: 0.0419
INFO - 2023-03-24 10:43:34 --> Config Class Initialized
INFO - 2023-03-24 10:43:34 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:34 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:34 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:34 --> URI Class Initialized
INFO - 2023-03-24 10:43:34 --> Router Class Initialized
INFO - 2023-03-24 10:43:34 --> Output Class Initialized
INFO - 2023-03-24 10:43:34 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:34 --> Input Class Initialized
INFO - 2023-03-24 10:43:34 --> Language Class Initialized
INFO - 2023-03-24 10:43:34 --> Loader Class Initialized
INFO - 2023-03-24 10:43:34 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:34 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:34 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:34 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:34 --> Total execution time: 0.0574
INFO - 2023-03-24 10:43:36 --> Config Class Initialized
INFO - 2023-03-24 10:43:36 --> Config Class Initialized
INFO - 2023-03-24 10:43:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:43:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:43:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:36 --> URI Class Initialized
INFO - 2023-03-24 10:43:36 --> URI Class Initialized
INFO - 2023-03-24 10:43:36 --> Router Class Initialized
INFO - 2023-03-24 10:43:36 --> Router Class Initialized
INFO - 2023-03-24 10:43:36 --> Output Class Initialized
INFO - 2023-03-24 10:43:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:36 --> Output Class Initialized
INFO - 2023-03-24 10:43:36 --> Input Class Initialized
INFO - 2023-03-24 10:43:36 --> Language Class Initialized
INFO - 2023-03-24 10:43:36 --> Security Class Initialized
INFO - 2023-03-24 10:43:36 --> Loader Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:36 --> Controller Class Initialized
INFO - 2023-03-24 10:43:36 --> Input Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:36 --> Language Class Initialized
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Loader Class Initialized
INFO - 2023-03-24 10:43:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:36 --> Total execution time: 0.0289
INFO - 2023-03-24 10:43:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:43:36 --> Config Class Initialized
INFO - 2023-03-24 10:43:36 --> Final output sent to browser
INFO - 2023-03-24 10:43:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Total execution time: 0.0334
DEBUG - 2023-03-24 10:43:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:36 --> URI Class Initialized
INFO - 2023-03-24 10:43:36 --> Router Class Initialized
INFO - 2023-03-24 10:43:36 --> Output Class Initialized
INFO - 2023-03-24 10:43:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:36 --> Input Class Initialized
INFO - 2023-03-24 10:43:36 --> Language Class Initialized
INFO - 2023-03-24 10:43:36 --> Loader Class Initialized
INFO - 2023-03-24 10:43:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Config Class Initialized
INFO - 2023-03-24 10:43:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:43:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:43:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:43:36 --> URI Class Initialized
INFO - 2023-03-24 10:43:36 --> Router Class Initialized
INFO - 2023-03-24 10:43:36 --> Output Class Initialized
INFO - 2023-03-24 10:43:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:43:36 --> Input Class Initialized
INFO - 2023-03-24 10:43:36 --> Language Class Initialized
INFO - 2023-03-24 10:43:36 --> Loader Class Initialized
INFO - 2023-03-24 10:43:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:43:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:43:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:43:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:36 --> Total execution time: 0.1255
INFO - 2023-03-24 10:43:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:43:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:43:36 --> Total execution time: 0.1179
INFO - 2023-03-24 10:44:36 --> Config Class Initialized
INFO - 2023-03-24 10:44:36 --> Config Class Initialized
INFO - 2023-03-24 10:44:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:44:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:44:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:44:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:44:36 --> URI Class Initialized
INFO - 2023-03-24 10:44:36 --> URI Class Initialized
INFO - 2023-03-24 10:44:36 --> Router Class Initialized
INFO - 2023-03-24 10:44:36 --> Router Class Initialized
INFO - 2023-03-24 10:44:36 --> Output Class Initialized
INFO - 2023-03-24 10:44:36 --> Output Class Initialized
INFO - 2023-03-24 10:44:36 --> Security Class Initialized
INFO - 2023-03-24 10:44:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:44:36 --> Input Class Initialized
INFO - 2023-03-24 10:44:36 --> Input Class Initialized
INFO - 2023-03-24 10:44:36 --> Language Class Initialized
INFO - 2023-03-24 10:44:36 --> Language Class Initialized
INFO - 2023-03-24 10:44:36 --> Loader Class Initialized
INFO - 2023-03-24 10:44:36 --> Loader Class Initialized
INFO - 2023-03-24 10:44:36 --> Controller Class Initialized
INFO - 2023-03-24 10:44:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:44:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:44:36 --> Total execution time: 0.0195
INFO - 2023-03-24 10:44:36 --> Config Class Initialized
INFO - 2023-03-24 10:44:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:44:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:44:36 --> URI Class Initialized
INFO - 2023-03-24 10:44:36 --> Router Class Initialized
INFO - 2023-03-24 10:44:36 --> Output Class Initialized
INFO - 2023-03-24 10:44:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:44:36 --> Input Class Initialized
INFO - 2023-03-24 10:44:36 --> Language Class Initialized
INFO - 2023-03-24 10:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:44:36 --> Loader Class Initialized
INFO - 2023-03-24 10:44:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:44:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:44:36 --> Total execution time: 0.0144
INFO - 2023-03-24 10:44:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:44:36 --> Total execution time: 0.1614
INFO - 2023-03-24 10:44:36 --> Config Class Initialized
INFO - 2023-03-24 10:44:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:44:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:44:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:44:36 --> URI Class Initialized
INFO - 2023-03-24 10:44:36 --> Router Class Initialized
INFO - 2023-03-24 10:44:36 --> Output Class Initialized
INFO - 2023-03-24 10:44:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:44:36 --> Input Class Initialized
INFO - 2023-03-24 10:44:36 --> Language Class Initialized
INFO - 2023-03-24 10:44:36 --> Loader Class Initialized
INFO - 2023-03-24 10:44:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:44:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:44:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:44:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:44:37 --> Total execution time: 0.1684
INFO - 2023-03-24 10:45:36 --> Config Class Initialized
INFO - 2023-03-24 10:45:36 --> Config Class Initialized
INFO - 2023-03-24 10:45:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:45:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:45:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:45:36 --> URI Class Initialized
INFO - 2023-03-24 10:45:36 --> URI Class Initialized
INFO - 2023-03-24 10:45:36 --> Router Class Initialized
INFO - 2023-03-24 10:45:36 --> Router Class Initialized
INFO - 2023-03-24 10:45:36 --> Output Class Initialized
INFO - 2023-03-24 10:45:36 --> Output Class Initialized
INFO - 2023-03-24 10:45:36 --> Security Class Initialized
INFO - 2023-03-24 10:45:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:45:36 --> Input Class Initialized
INFO - 2023-03-24 10:45:36 --> Input Class Initialized
INFO - 2023-03-24 10:45:36 --> Language Class Initialized
INFO - 2023-03-24 10:45:36 --> Language Class Initialized
INFO - 2023-03-24 10:45:36 --> Loader Class Initialized
INFO - 2023-03-24 10:45:36 --> Loader Class Initialized
INFO - 2023-03-24 10:45:36 --> Controller Class Initialized
INFO - 2023-03-24 10:45:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-24 10:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:45:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:45:36 --> Total execution time: 0.0200
INFO - 2023-03-24 10:45:36 --> Config Class Initialized
INFO - 2023-03-24 10:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:45:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:45:36 --> URI Class Initialized
INFO - 2023-03-24 10:45:36 --> Router Class Initialized
INFO - 2023-03-24 10:45:36 --> Output Class Initialized
INFO - 2023-03-24 10:45:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:45:36 --> Input Class Initialized
INFO - 2023-03-24 10:45:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:45:36 --> Language Class Initialized
INFO - 2023-03-24 10:45:36 --> Loader Class Initialized
INFO - 2023-03-24 10:45:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:45:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:45:36 --> Total execution time: 0.0159
INFO - 2023-03-24 10:45:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:45:36 --> Total execution time: 0.1771
INFO - 2023-03-24 10:45:36 --> Config Class Initialized
INFO - 2023-03-24 10:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:45:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:45:36 --> URI Class Initialized
INFO - 2023-03-24 10:45:36 --> Router Class Initialized
INFO - 2023-03-24 10:45:36 --> Output Class Initialized
INFO - 2023-03-24 10:45:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:45:36 --> Input Class Initialized
INFO - 2023-03-24 10:45:36 --> Language Class Initialized
INFO - 2023-03-24 10:45:36 --> Loader Class Initialized
INFO - 2023-03-24 10:45:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:45:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:45:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:45:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:45:37 --> Total execution time: 0.1614
INFO - 2023-03-24 10:46:36 --> Config Class Initialized
INFO - 2023-03-24 10:46:36 --> Config Class Initialized
INFO - 2023-03-24 10:46:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:46:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-24 10:46:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:46:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:46:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:46:36 --> URI Class Initialized
INFO - 2023-03-24 10:46:36 --> URI Class Initialized
INFO - 2023-03-24 10:46:36 --> Router Class Initialized
INFO - 2023-03-24 10:46:36 --> Router Class Initialized
INFO - 2023-03-24 10:46:36 --> Output Class Initialized
INFO - 2023-03-24 10:46:36 --> Output Class Initialized
INFO - 2023-03-24 10:46:36 --> Security Class Initialized
INFO - 2023-03-24 10:46:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:46:36 --> Input Class Initialized
INFO - 2023-03-24 10:46:36 --> Language Class Initialized
INFO - 2023-03-24 10:46:36 --> Input Class Initialized
INFO - 2023-03-24 10:46:36 --> Loader Class Initialized
INFO - 2023-03-24 10:46:36 --> Language Class Initialized
INFO - 2023-03-24 10:46:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:46:36 --> Loader Class Initialized
INFO - 2023-03-24 10:46:36 --> Controller Class Initialized
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:46:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:46:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:46:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:46:36 --> Total execution time: 0.0248
INFO - 2023-03-24 10:46:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:46:36 --> Config Class Initialized
INFO - 2023-03-24 10:46:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:46:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:46:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:46:36 --> URI Class Initialized
INFO - 2023-03-24 10:46:36 --> Router Class Initialized
INFO - 2023-03-24 10:46:36 --> Output Class Initialized
INFO - 2023-03-24 10:46:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:46:36 --> Input Class Initialized
INFO - 2023-03-24 10:46:36 --> Language Class Initialized
INFO - 2023-03-24 10:46:36 --> Loader Class Initialized
INFO - 2023-03-24 10:46:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:46:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:46:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:46:36 --> Total execution time: 0.0550
INFO - 2023-03-24 10:46:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:46:36 --> Total execution time: 0.2230
INFO - 2023-03-24 10:46:36 --> Config Class Initialized
INFO - 2023-03-24 10:46:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:46:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:46:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:46:36 --> URI Class Initialized
INFO - 2023-03-24 10:46:36 --> Router Class Initialized
INFO - 2023-03-24 10:46:36 --> Output Class Initialized
INFO - 2023-03-24 10:46:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:46:36 --> Input Class Initialized
INFO - 2023-03-24 10:46:36 --> Language Class Initialized
INFO - 2023-03-24 10:46:36 --> Loader Class Initialized
INFO - 2023-03-24 10:46:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:46:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:46:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:46:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:46:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:46:37 --> Total execution time: 0.2226
INFO - 2023-03-24 10:47:36 --> Config Class Initialized
INFO - 2023-03-24 10:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:47:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:47:36 --> URI Class Initialized
INFO - 2023-03-24 10:47:36 --> Router Class Initialized
INFO - 2023-03-24 10:47:36 --> Output Class Initialized
INFO - 2023-03-24 10:47:36 --> Config Class Initialized
INFO - 2023-03-24 10:47:36 --> Security Class Initialized
INFO - 2023-03-24 10:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-24 10:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:47:36 --> Input Class Initialized
INFO - 2023-03-24 10:47:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:47:36 --> Language Class Initialized
INFO - 2023-03-24 10:47:36 --> URI Class Initialized
INFO - 2023-03-24 10:47:36 --> Loader Class Initialized
INFO - 2023-03-24 10:47:36 --> Router Class Initialized
INFO - 2023-03-24 10:47:36 --> Controller Class Initialized
INFO - 2023-03-24 10:47:36 --> Output Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:47:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Input Class Initialized
INFO - 2023-03-24 10:47:36 --> Language Class Initialized
INFO - 2023-03-24 10:47:36 --> Loader Class Initialized
INFO - 2023-03-24 10:47:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:47:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:47:36 --> Total execution time: 0.0199
INFO - 2023-03-24 10:47:36 --> Config Class Initialized
INFO - 2023-03-24 10:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:47:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:47:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:47:36 --> URI Class Initialized
INFO - 2023-03-24 10:47:36 --> Router Class Initialized
INFO - 2023-03-24 10:47:36 --> Output Class Initialized
INFO - 2023-03-24 10:47:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:47:36 --> Input Class Initialized
INFO - 2023-03-24 10:47:36 --> Language Class Initialized
INFO - 2023-03-24 10:47:36 --> Loader Class Initialized
INFO - 2023-03-24 10:47:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:47:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:47:36 --> Total execution time: 0.0138
INFO - 2023-03-24 10:47:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:47:36 --> Total execution time: 0.1725
INFO - 2023-03-24 10:47:36 --> Config Class Initialized
INFO - 2023-03-24 10:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:47:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:47:36 --> URI Class Initialized
INFO - 2023-03-24 10:47:36 --> Router Class Initialized
INFO - 2023-03-24 10:47:36 --> Output Class Initialized
INFO - 2023-03-24 10:47:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:47:36 --> Input Class Initialized
INFO - 2023-03-24 10:47:36 --> Language Class Initialized
INFO - 2023-03-24 10:47:36 --> Loader Class Initialized
INFO - 2023-03-24 10:47:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:47:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:47:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:47:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:47:37 --> Total execution time: 0.1741
INFO - 2023-03-24 10:48:36 --> Config Class Initialized
INFO - 2023-03-24 10:48:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:48:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:48:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:48:36 --> URI Class Initialized
INFO - 2023-03-24 10:48:36 --> Router Class Initialized
INFO - 2023-03-24 10:48:36 --> Output Class Initialized
INFO - 2023-03-24 10:48:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:48:36 --> Input Class Initialized
INFO - 2023-03-24 10:48:36 --> Config Class Initialized
INFO - 2023-03-24 10:48:36 --> Language Class Initialized
INFO - 2023-03-24 10:48:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:48:36 --> Loader Class Initialized
DEBUG - 2023-03-24 10:48:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:48:36 --> Controller Class Initialized
INFO - 2023-03-24 10:48:36 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:48:36 --> URI Class Initialized
INFO - 2023-03-24 10:48:36 --> Router Class Initialized
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Output Class Initialized
INFO - 2023-03-24 10:48:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:48:36 --> Input Class Initialized
INFO - 2023-03-24 10:48:36 --> Language Class Initialized
INFO - 2023-03-24 10:48:36 --> Loader Class Initialized
INFO - 2023-03-24 10:48:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:48:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:48:36 --> Total execution time: 0.0163
INFO - 2023-03-24 10:48:36 --> Config Class Initialized
INFO - 2023-03-24 10:48:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:48:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:48:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:48:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:48:36 --> URI Class Initialized
INFO - 2023-03-24 10:48:36 --> Router Class Initialized
INFO - 2023-03-24 10:48:36 --> Output Class Initialized
INFO - 2023-03-24 10:48:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:48:36 --> Input Class Initialized
INFO - 2023-03-24 10:48:36 --> Language Class Initialized
INFO - 2023-03-24 10:48:36 --> Loader Class Initialized
INFO - 2023-03-24 10:48:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:48:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:48:36 --> Total execution time: 0.0575
INFO - 2023-03-24 10:48:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:48:36 --> Total execution time: 0.1932
INFO - 2023-03-24 10:48:36 --> Config Class Initialized
INFO - 2023-03-24 10:48:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:48:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:48:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:48:36 --> URI Class Initialized
INFO - 2023-03-24 10:48:36 --> Router Class Initialized
INFO - 2023-03-24 10:48:36 --> Output Class Initialized
INFO - 2023-03-24 10:48:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:48:36 --> Input Class Initialized
INFO - 2023-03-24 10:48:36 --> Language Class Initialized
INFO - 2023-03-24 10:48:36 --> Loader Class Initialized
INFO - 2023-03-24 10:48:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:48:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:48:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:48:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:48:37 --> Total execution time: 0.2120
INFO - 2023-03-24 10:49:36 --> Config Class Initialized
INFO - 2023-03-24 10:49:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:49:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:49:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:49:36 --> URI Class Initialized
INFO - 2023-03-24 10:49:36 --> Config Class Initialized
INFO - 2023-03-24 10:49:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:49:36 --> Router Class Initialized
DEBUG - 2023-03-24 10:49:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:49:36 --> Output Class Initialized
INFO - 2023-03-24 10:49:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:49:36 --> Security Class Initialized
INFO - 2023-03-24 10:49:36 --> URI Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:49:36 --> Router Class Initialized
INFO - 2023-03-24 10:49:36 --> Input Class Initialized
INFO - 2023-03-24 10:49:36 --> Output Class Initialized
INFO - 2023-03-24 10:49:36 --> Language Class Initialized
INFO - 2023-03-24 10:49:36 --> Security Class Initialized
INFO - 2023-03-24 10:49:36 --> Loader Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:49:36 --> Controller Class Initialized
INFO - 2023-03-24 10:49:36 --> Input Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:49:36 --> Language Class Initialized
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Loader Class Initialized
INFO - 2023-03-24 10:49:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:49:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:49:36 --> Total execution time: 0.0255
INFO - 2023-03-24 10:49:36 --> Config Class Initialized
INFO - 2023-03-24 10:49:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:49:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:49:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:49:36 --> URI Class Initialized
INFO - 2023-03-24 10:49:36 --> Router Class Initialized
INFO - 2023-03-24 10:49:36 --> Output Class Initialized
INFO - 2023-03-24 10:49:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:49:36 --> Input Class Initialized
INFO - 2023-03-24 10:49:36 --> Language Class Initialized
INFO - 2023-03-24 10:49:36 --> Loader Class Initialized
INFO - 2023-03-24 10:49:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:49:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:49:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:49:36 --> Total execution time: 0.0145
INFO - 2023-03-24 10:49:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:49:36 --> Total execution time: 0.1804
INFO - 2023-03-24 10:49:36 --> Config Class Initialized
INFO - 2023-03-24 10:49:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:49:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:49:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:49:36 --> URI Class Initialized
INFO - 2023-03-24 10:49:36 --> Router Class Initialized
INFO - 2023-03-24 10:49:36 --> Output Class Initialized
INFO - 2023-03-24 10:49:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:49:36 --> Input Class Initialized
INFO - 2023-03-24 10:49:36 --> Language Class Initialized
INFO - 2023-03-24 10:49:36 --> Loader Class Initialized
INFO - 2023-03-24 10:49:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:49:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:49:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:49:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:49:37 --> Total execution time: 0.1673
INFO - 2023-03-24 10:50:36 --> Config Class Initialized
INFO - 2023-03-24 10:50:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:50:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:50:36 --> URI Class Initialized
INFO - 2023-03-24 10:50:36 --> Router Class Initialized
INFO - 2023-03-24 10:50:36 --> Output Class Initialized
INFO - 2023-03-24 10:50:36 --> Security Class Initialized
INFO - 2023-03-24 10:50:36 --> Config Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:50:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:50:36 --> Input Class Initialized
DEBUG - 2023-03-24 10:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:50:36 --> Language Class Initialized
INFO - 2023-03-24 10:50:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:50:36 --> URI Class Initialized
INFO - 2023-03-24 10:50:36 --> Loader Class Initialized
INFO - 2023-03-24 10:50:36 --> Router Class Initialized
INFO - 2023-03-24 10:50:36 --> Controller Class Initialized
INFO - 2023-03-24 10:50:36 --> Output Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:50:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Input Class Initialized
INFO - 2023-03-24 10:50:36 --> Language Class Initialized
INFO - 2023-03-24 10:50:36 --> Loader Class Initialized
INFO - 2023-03-24 10:50:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:50:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:50:36 --> Total execution time: 0.0203
INFO - 2023-03-24 10:50:36 --> Config Class Initialized
INFO - 2023-03-24 10:50:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:50:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:50:36 --> URI Class Initialized
INFO - 2023-03-24 10:50:36 --> Router Class Initialized
INFO - 2023-03-24 10:50:36 --> Output Class Initialized
INFO - 2023-03-24 10:50:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:50:36 --> Input Class Initialized
INFO - 2023-03-24 10:50:36 --> Language Class Initialized
INFO - 2023-03-24 10:50:36 --> Loader Class Initialized
INFO - 2023-03-24 10:50:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:50:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:50:36 --> Total execution time: 0.0175
INFO - 2023-03-24 10:50:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:50:36 --> Total execution time: 0.2484
INFO - 2023-03-24 10:50:36 --> Config Class Initialized
INFO - 2023-03-24 10:50:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:50:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:50:36 --> URI Class Initialized
INFO - 2023-03-24 10:50:36 --> Router Class Initialized
INFO - 2023-03-24 10:50:36 --> Output Class Initialized
INFO - 2023-03-24 10:50:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:50:36 --> Input Class Initialized
INFO - 2023-03-24 10:50:36 --> Language Class Initialized
INFO - 2023-03-24 10:50:36 --> Loader Class Initialized
INFO - 2023-03-24 10:50:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:50:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:50:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:50:37 --> Total execution time: 0.1752
INFO - 2023-03-24 10:51:36 --> Config Class Initialized
INFO - 2023-03-24 10:51:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:51:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:51:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:51:36 --> URI Class Initialized
INFO - 2023-03-24 10:51:36 --> Config Class Initialized
INFO - 2023-03-24 10:51:36 --> Router Class Initialized
INFO - 2023-03-24 10:51:36 --> Hooks Class Initialized
INFO - 2023-03-24 10:51:36 --> Output Class Initialized
DEBUG - 2023-03-24 10:51:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:51:36 --> Security Class Initialized
INFO - 2023-03-24 10:51:36 --> Utf8 Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:51:36 --> URI Class Initialized
INFO - 2023-03-24 10:51:36 --> Input Class Initialized
INFO - 2023-03-24 10:51:36 --> Router Class Initialized
INFO - 2023-03-24 10:51:36 --> Language Class Initialized
INFO - 2023-03-24 10:51:36 --> Output Class Initialized
INFO - 2023-03-24 10:51:36 --> Security Class Initialized
INFO - 2023-03-24 10:51:36 --> Loader Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:51:36 --> Controller Class Initialized
INFO - 2023-03-24 10:51:36 --> Input Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:51:36 --> Language Class Initialized
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Loader Class Initialized
INFO - 2023-03-24 10:51:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:51:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:51:36 --> Total execution time: 0.0207
INFO - 2023-03-24 10:51:36 --> Config Class Initialized
INFO - 2023-03-24 10:51:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:51:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:51:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:51:36 --> URI Class Initialized
INFO - 2023-03-24 10:51:36 --> Router Class Initialized
INFO - 2023-03-24 10:51:36 --> Output Class Initialized
INFO - 2023-03-24 10:51:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:51:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:51:36 --> Input Class Initialized
INFO - 2023-03-24 10:51:36 --> Language Class Initialized
INFO - 2023-03-24 10:51:36 --> Loader Class Initialized
INFO - 2023-03-24 10:51:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:51:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:51:36 --> Total execution time: 0.0136
INFO - 2023-03-24 10:51:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:51:36 --> Total execution time: 0.1653
INFO - 2023-03-24 10:51:36 --> Config Class Initialized
INFO - 2023-03-24 10:51:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:51:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:51:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:51:36 --> URI Class Initialized
INFO - 2023-03-24 10:51:36 --> Router Class Initialized
INFO - 2023-03-24 10:51:36 --> Output Class Initialized
INFO - 2023-03-24 10:51:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:51:36 --> Input Class Initialized
INFO - 2023-03-24 10:51:36 --> Language Class Initialized
INFO - 2023-03-24 10:51:36 --> Loader Class Initialized
INFO - 2023-03-24 10:51:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Model "Login_model" initialized
INFO - 2023-03-24 10:51:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:51:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:51:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:51:37 --> Total execution time: 0.1929
INFO - 2023-03-24 10:52:36 --> Config Class Initialized
INFO - 2023-03-24 10:52:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:52:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:52:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:52:36 --> URI Class Initialized
INFO - 2023-03-24 10:52:36 --> Router Class Initialized
INFO - 2023-03-24 10:52:36 --> Output Class Initialized
INFO - 2023-03-24 10:52:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:52:36 --> Input Class Initialized
INFO - 2023-03-24 10:52:36 --> Language Class Initialized
INFO - 2023-03-24 10:52:36 --> Loader Class Initialized
INFO - 2023-03-24 10:52:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:52:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:52:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:52:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:52:36 --> Total execution time: 0.0599
INFO - 2023-03-24 10:52:36 --> Config Class Initialized
INFO - 2023-03-24 10:52:36 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:52:36 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:52:36 --> Utf8 Class Initialized
INFO - 2023-03-24 10:52:36 --> URI Class Initialized
INFO - 2023-03-24 10:52:36 --> Router Class Initialized
INFO - 2023-03-24 10:52:36 --> Output Class Initialized
INFO - 2023-03-24 10:52:36 --> Security Class Initialized
DEBUG - 2023-03-24 10:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:52:36 --> Input Class Initialized
INFO - 2023-03-24 10:52:36 --> Language Class Initialized
INFO - 2023-03-24 10:52:36 --> Loader Class Initialized
INFO - 2023-03-24 10:52:36 --> Controller Class Initialized
DEBUG - 2023-03-24 10:52:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:52:36 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:36 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:52:36 --> Final output sent to browser
DEBUG - 2023-03-24 10:52:36 --> Total execution time: 0.0154
INFO - 2023-03-24 10:52:37 --> Config Class Initialized
INFO - 2023-03-24 10:52:37 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:52:37 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:52:37 --> Utf8 Class Initialized
INFO - 2023-03-24 10:52:37 --> URI Class Initialized
INFO - 2023-03-24 10:52:37 --> Router Class Initialized
INFO - 2023-03-24 10:52:37 --> Output Class Initialized
INFO - 2023-03-24 10:52:37 --> Security Class Initialized
DEBUG - 2023-03-24 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:52:37 --> Input Class Initialized
INFO - 2023-03-24 10:52:37 --> Language Class Initialized
INFO - 2023-03-24 10:52:37 --> Loader Class Initialized
INFO - 2023-03-24 10:52:37 --> Controller Class Initialized
DEBUG - 2023-03-24 10:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:52:37 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:37 --> Model "Login_model" initialized
INFO - 2023-03-24 10:52:37 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:37 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:52:37 --> Final output sent to browser
DEBUG - 2023-03-24 10:52:37 --> Total execution time: 0.1900
INFO - 2023-03-24 10:52:37 --> Config Class Initialized
INFO - 2023-03-24 10:52:38 --> Hooks Class Initialized
DEBUG - 2023-03-24 10:52:38 --> UTF-8 Support Enabled
INFO - 2023-03-24 10:52:38 --> Utf8 Class Initialized
INFO - 2023-03-24 10:52:38 --> URI Class Initialized
INFO - 2023-03-24 10:52:38 --> Router Class Initialized
INFO - 2023-03-24 10:52:38 --> Output Class Initialized
INFO - 2023-03-24 10:52:38 --> Security Class Initialized
DEBUG - 2023-03-24 10:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 10:52:38 --> Input Class Initialized
INFO - 2023-03-24 10:52:38 --> Language Class Initialized
INFO - 2023-03-24 10:52:38 --> Loader Class Initialized
INFO - 2023-03-24 10:52:38 --> Controller Class Initialized
DEBUG - 2023-03-24 10:52:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 10:52:38 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:38 --> Model "Login_model" initialized
INFO - 2023-03-24 10:52:38 --> Database Driver Class Initialized
INFO - 2023-03-24 10:52:38 --> Model "Cluster_model" initialized
INFO - 2023-03-24 10:52:38 --> Final output sent to browser
DEBUG - 2023-03-24 10:52:38 --> Total execution time: 0.2288
INFO - 2023-03-24 11:36:39 --> Config Class Initialized
INFO - 2023-03-24 11:36:39 --> Hooks Class Initialized
DEBUG - 2023-03-24 11:36:39 --> UTF-8 Support Enabled
INFO - 2023-03-24 11:36:39 --> Utf8 Class Initialized
INFO - 2023-03-24 11:36:39 --> URI Class Initialized
INFO - 2023-03-24 11:36:39 --> Router Class Initialized
INFO - 2023-03-24 11:36:39 --> Output Class Initialized
INFO - 2023-03-24 11:36:39 --> Security Class Initialized
DEBUG - 2023-03-24 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 11:36:39 --> Input Class Initialized
INFO - 2023-03-24 11:36:39 --> Language Class Initialized
INFO - 2023-03-24 11:36:39 --> Loader Class Initialized
INFO - 2023-03-24 11:36:39 --> Controller Class Initialized
DEBUG - 2023-03-24 11:36:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 11:36:39 --> Database Driver Class Initialized
INFO - 2023-03-24 11:36:40 --> Config Class Initialized
INFO - 2023-03-24 11:36:40 --> Hooks Class Initialized
DEBUG - 2023-03-24 11:36:40 --> UTF-8 Support Enabled
INFO - 2023-03-24 11:36:40 --> Utf8 Class Initialized
INFO - 2023-03-24 11:36:40 --> URI Class Initialized
INFO - 2023-03-24 11:36:40 --> Router Class Initialized
INFO - 2023-03-24 11:36:40 --> Output Class Initialized
INFO - 2023-03-24 11:36:40 --> Security Class Initialized
DEBUG - 2023-03-24 11:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 11:36:40 --> Input Class Initialized
INFO - 2023-03-24 11:36:40 --> Language Class Initialized
INFO - 2023-03-24 11:36:40 --> Loader Class Initialized
INFO - 2023-03-24 11:36:40 --> Controller Class Initialized
DEBUG - 2023-03-24 11:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 11:36:40 --> Database Driver Class Initialized
ERROR - 2023-03-24 11:36:49 --> Unable to connect to the database
INFO - 2023-03-24 11:36:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-24 11:36:50 --> Unable to connect to the database
INFO - 2023-03-24 11:36:50 --> Model "Login_model" initialized
ERROR - 2023-03-24 11:36:50 --> Unable to connect to the database
ERROR - 2023-03-24 11:36:50 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 11:36:50 --> Final output sent to browser
DEBUG - 2023-03-24 11:36:50 --> Total execution time: 9.9948
INFO - 2023-03-24 11:36:50 --> Config Class Initialized
INFO - 2023-03-24 11:36:50 --> Hooks Class Initialized
DEBUG - 2023-03-24 11:36:50 --> UTF-8 Support Enabled
INFO - 2023-03-24 11:36:50 --> Utf8 Class Initialized
INFO - 2023-03-24 11:36:50 --> URI Class Initialized
INFO - 2023-03-24 11:36:50 --> Router Class Initialized
INFO - 2023-03-24 11:36:50 --> Output Class Initialized
INFO - 2023-03-24 11:36:50 --> Security Class Initialized
DEBUG - 2023-03-24 11:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 11:36:50 --> Input Class Initialized
INFO - 2023-03-24 11:36:50 --> Language Class Initialized
INFO - 2023-03-24 11:36:50 --> Loader Class Initialized
INFO - 2023-03-24 11:36:50 --> Controller Class Initialized
DEBUG - 2023-03-24 11:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 11:36:50 --> Database Driver Class Initialized
ERROR - 2023-03-24 11:36:50 --> Unable to connect to the database
INFO - 2023-03-24 11:36:50 --> Model "Login_model" initialized
ERROR - 2023-03-24 11:36:50 --> Unable to connect to the database
ERROR - 2023-03-24 11:36:50 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 11:36:50 --> Final output sent to browser
DEBUG - 2023-03-24 11:36:50 --> Total execution time: 0.0429
INFO - 2023-03-24 14:55:39 --> Config Class Initialized
INFO - 2023-03-24 14:55:39 --> Hooks Class Initialized
DEBUG - 2023-03-24 14:55:39 --> UTF-8 Support Enabled
INFO - 2023-03-24 14:55:39 --> Utf8 Class Initialized
INFO - 2023-03-24 14:55:39 --> URI Class Initialized
INFO - 2023-03-24 14:55:39 --> Router Class Initialized
INFO - 2023-03-24 14:55:39 --> Output Class Initialized
INFO - 2023-03-24 14:55:39 --> Security Class Initialized
DEBUG - 2023-03-24 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 14:55:39 --> Input Class Initialized
INFO - 2023-03-24 14:55:39 --> Language Class Initialized
INFO - 2023-03-24 14:55:39 --> Loader Class Initialized
INFO - 2023-03-24 14:55:39 --> Controller Class Initialized
DEBUG - 2023-03-24 14:55:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 14:55:39 --> Database Driver Class Initialized
INFO - 2023-03-24 14:55:41 --> Config Class Initialized
INFO - 2023-03-24 14:55:41 --> Hooks Class Initialized
DEBUG - 2023-03-24 14:55:41 --> UTF-8 Support Enabled
INFO - 2023-03-24 14:55:41 --> Utf8 Class Initialized
INFO - 2023-03-24 14:55:41 --> URI Class Initialized
INFO - 2023-03-24 14:55:41 --> Router Class Initialized
INFO - 2023-03-24 14:55:41 --> Output Class Initialized
INFO - 2023-03-24 14:55:41 --> Security Class Initialized
DEBUG - 2023-03-24 14:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 14:55:41 --> Input Class Initialized
INFO - 2023-03-24 14:55:41 --> Language Class Initialized
INFO - 2023-03-24 14:55:41 --> Loader Class Initialized
INFO - 2023-03-24 14:55:41 --> Controller Class Initialized
DEBUG - 2023-03-24 14:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 14:55:41 --> Database Driver Class Initialized
ERROR - 2023-03-24 14:55:49 --> Unable to connect to the database
INFO - 2023-03-24 14:55:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-24 14:55:51 --> Unable to connect to the database
INFO - 2023-03-24 14:55:51 --> Model "Login_model" initialized
ERROR - 2023-03-24 14:56:01 --> Unable to connect to the database
ERROR - 2023-03-24 14:56:01 --> Query error: Operation timed out - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 14:56:01 --> Final output sent to browser
DEBUG - 2023-03-24 14:56:01 --> Total execution time: 20.0103
INFO - 2023-03-24 14:56:01 --> Config Class Initialized
INFO - 2023-03-24 14:56:01 --> Hooks Class Initialized
DEBUG - 2023-03-24 14:56:01 --> UTF-8 Support Enabled
INFO - 2023-03-24 14:56:01 --> Utf8 Class Initialized
INFO - 2023-03-24 14:56:01 --> URI Class Initialized
INFO - 2023-03-24 14:56:01 --> Router Class Initialized
INFO - 2023-03-24 14:56:01 --> Output Class Initialized
INFO - 2023-03-24 14:56:01 --> Security Class Initialized
DEBUG - 2023-03-24 14:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 14:56:01 --> Input Class Initialized
INFO - 2023-03-24 14:56:01 --> Language Class Initialized
INFO - 2023-03-24 14:56:01 --> Loader Class Initialized
INFO - 2023-03-24 14:56:01 --> Controller Class Initialized
DEBUG - 2023-03-24 14:56:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 14:56:01 --> Database Driver Class Initialized
ERROR - 2023-03-24 14:56:11 --> Unable to connect to the database
INFO - 2023-03-24 14:56:11 --> Model "Login_model" initialized
ERROR - 2023-03-24 14:56:11 --> Unable to connect to the database
ERROR - 2023-03-24 14:56:11 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 14:56:11 --> Final output sent to browser
DEBUG - 2023-03-24 14:56:11 --> Total execution time: 10.0044
INFO - 2023-03-24 16:11:56 --> Config Class Initialized
INFO - 2023-03-24 16:11:56 --> Hooks Class Initialized
DEBUG - 2023-03-24 16:11:56 --> UTF-8 Support Enabled
INFO - 2023-03-24 16:11:56 --> Utf8 Class Initialized
INFO - 2023-03-24 16:11:56 --> URI Class Initialized
INFO - 2023-03-24 16:11:56 --> Router Class Initialized
INFO - 2023-03-24 16:11:56 --> Output Class Initialized
INFO - 2023-03-24 16:11:56 --> Security Class Initialized
DEBUG - 2023-03-24 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 16:11:56 --> Input Class Initialized
INFO - 2023-03-24 16:11:56 --> Language Class Initialized
INFO - 2023-03-24 16:11:56 --> Loader Class Initialized
INFO - 2023-03-24 16:11:56 --> Controller Class Initialized
DEBUG - 2023-03-24 16:11:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 16:11:56 --> Database Driver Class Initialized
INFO - 2023-03-24 16:11:57 --> Config Class Initialized
INFO - 2023-03-24 16:11:57 --> Hooks Class Initialized
DEBUG - 2023-03-24 16:11:57 --> UTF-8 Support Enabled
INFO - 2023-03-24 16:11:57 --> Utf8 Class Initialized
INFO - 2023-03-24 16:11:57 --> URI Class Initialized
INFO - 2023-03-24 16:11:57 --> Router Class Initialized
INFO - 2023-03-24 16:11:57 --> Output Class Initialized
INFO - 2023-03-24 16:11:57 --> Security Class Initialized
DEBUG - 2023-03-24 16:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 16:11:57 --> Input Class Initialized
INFO - 2023-03-24 16:11:57 --> Language Class Initialized
INFO - 2023-03-24 16:11:57 --> Loader Class Initialized
INFO - 2023-03-24 16:11:57 --> Controller Class Initialized
DEBUG - 2023-03-24 16:11:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 16:11:57 --> Database Driver Class Initialized
ERROR - 2023-03-24 16:12:06 --> Unable to connect to the database
INFO - 2023-03-24 16:12:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-24 16:12:07 --> Unable to connect to the database
INFO - 2023-03-24 16:12:07 --> Model "Login_model" initialized
ERROR - 2023-03-24 16:12:07 --> Unable to connect to the database
ERROR - 2023-03-24 16:12:07 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 16:12:07 --> Final output sent to browser
DEBUG - 2023-03-24 16:12:07 --> Total execution time: 10.0079
INFO - 2023-03-24 16:12:07 --> Config Class Initialized
INFO - 2023-03-24 16:12:07 --> Hooks Class Initialized
DEBUG - 2023-03-24 16:12:07 --> UTF-8 Support Enabled
INFO - 2023-03-24 16:12:07 --> Utf8 Class Initialized
INFO - 2023-03-24 16:12:07 --> URI Class Initialized
INFO - 2023-03-24 16:12:07 --> Router Class Initialized
INFO - 2023-03-24 16:12:07 --> Output Class Initialized
INFO - 2023-03-24 16:12:07 --> Security Class Initialized
DEBUG - 2023-03-24 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-24 16:12:07 --> Input Class Initialized
INFO - 2023-03-24 16:12:07 --> Language Class Initialized
INFO - 2023-03-24 16:12:07 --> Loader Class Initialized
INFO - 2023-03-24 16:12:07 --> Controller Class Initialized
DEBUG - 2023-03-24 16:12:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-24 16:12:07 --> Database Driver Class Initialized
ERROR - 2023-03-24 16:12:07 --> Unable to connect to the database
INFO - 2023-03-24 16:12:07 --> Model "Login_model" initialized
ERROR - 2023-03-24 16:12:07 --> Unable to connect to the database
ERROR - 2023-03-24 16:12:07 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-24 16:12:07 --> Final output sent to browser
DEBUG - 2023-03-24 16:12:07 --> Total execution time: 0.0045
