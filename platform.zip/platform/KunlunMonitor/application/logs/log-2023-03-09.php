<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-09 02:07:10 --> Config Class Initialized
INFO - 2023-03-09 02:07:10 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:07:10 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:07:10 --> Utf8 Class Initialized
INFO - 2023-03-09 02:07:10 --> URI Class Initialized
INFO - 2023-03-09 02:07:10 --> Router Class Initialized
INFO - 2023-03-09 02:07:10 --> Output Class Initialized
INFO - 2023-03-09 02:07:10 --> Security Class Initialized
DEBUG - 2023-03-09 02:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:07:10 --> Input Class Initialized
INFO - 2023-03-09 02:07:10 --> Language Class Initialized
INFO - 2023-03-09 02:07:10 --> Loader Class Initialized
INFO - 2023-03-09 02:07:10 --> Controller Class Initialized
DEBUG - 2023-03-09 02:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:07:10 --> Database Driver Class Initialized
INFO - 2023-03-09 02:07:10 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:07:10 --> Final output sent to browser
DEBUG - 2023-03-09 02:07:10 --> Total execution time: 0.1496
INFO - 2023-03-09 02:07:10 --> Config Class Initialized
INFO - 2023-03-09 02:07:10 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:07:10 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:07:10 --> Utf8 Class Initialized
INFO - 2023-03-09 02:07:10 --> URI Class Initialized
INFO - 2023-03-09 02:07:10 --> Router Class Initialized
INFO - 2023-03-09 02:07:10 --> Output Class Initialized
INFO - 2023-03-09 02:07:10 --> Security Class Initialized
DEBUG - 2023-03-09 02:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:07:10 --> Input Class Initialized
INFO - 2023-03-09 02:07:10 --> Language Class Initialized
INFO - 2023-03-09 02:07:10 --> Loader Class Initialized
INFO - 2023-03-09 02:07:10 --> Controller Class Initialized
DEBUG - 2023-03-09 02:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:07:10 --> Database Driver Class Initialized
INFO - 2023-03-09 02:07:10 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:07:10 --> Final output sent to browser
DEBUG - 2023-03-09 02:07:10 --> Total execution time: 0.0792
INFO - 2023-03-09 02:21:25 --> Config Class Initialized
INFO - 2023-03-09 02:21:25 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:21:25 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:21:25 --> Utf8 Class Initialized
INFO - 2023-03-09 02:21:25 --> URI Class Initialized
INFO - 2023-03-09 02:21:25 --> Router Class Initialized
INFO - 2023-03-09 02:21:25 --> Output Class Initialized
INFO - 2023-03-09 02:21:25 --> Security Class Initialized
DEBUG - 2023-03-09 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:21:25 --> Input Class Initialized
INFO - 2023-03-09 02:21:25 --> Language Class Initialized
INFO - 2023-03-09 02:21:25 --> Loader Class Initialized
INFO - 2023-03-09 02:21:25 --> Controller Class Initialized
DEBUG - 2023-03-09 02:21:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:21:25 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:25 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:21:25 --> Final output sent to browser
DEBUG - 2023-03-09 02:21:25 --> Total execution time: 0.0206
INFO - 2023-03-09 02:21:25 --> Config Class Initialized
INFO - 2023-03-09 02:21:25 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:21:25 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:21:25 --> Utf8 Class Initialized
INFO - 2023-03-09 02:21:25 --> URI Class Initialized
INFO - 2023-03-09 02:21:25 --> Router Class Initialized
INFO - 2023-03-09 02:21:25 --> Output Class Initialized
INFO - 2023-03-09 02:21:25 --> Security Class Initialized
DEBUG - 2023-03-09 02:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:21:25 --> Input Class Initialized
INFO - 2023-03-09 02:21:25 --> Language Class Initialized
INFO - 2023-03-09 02:21:25 --> Loader Class Initialized
INFO - 2023-03-09 02:21:25 --> Controller Class Initialized
DEBUG - 2023-03-09 02:21:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:21:25 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:25 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:21:25 --> Final output sent to browser
DEBUG - 2023-03-09 02:21:25 --> Total execution time: 0.0588
INFO - 2023-03-09 02:21:27 --> Config Class Initialized
INFO - 2023-03-09 02:21:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:21:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:21:27 --> Utf8 Class Initialized
INFO - 2023-03-09 02:21:27 --> URI Class Initialized
INFO - 2023-03-09 02:21:27 --> Router Class Initialized
INFO - 2023-03-09 02:21:27 --> Output Class Initialized
INFO - 2023-03-09 02:21:27 --> Security Class Initialized
DEBUG - 2023-03-09 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:21:27 --> Input Class Initialized
INFO - 2023-03-09 02:21:27 --> Language Class Initialized
INFO - 2023-03-09 02:21:27 --> Loader Class Initialized
INFO - 2023-03-09 02:21:27 --> Controller Class Initialized
DEBUG - 2023-03-09 02:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:21:27 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:27 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:21:27 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:27 --> Model "Login_model" initialized
INFO - 2023-03-09 02:21:27 --> Final output sent to browser
DEBUG - 2023-03-09 02:21:27 --> Total execution time: 0.0942
INFO - 2023-03-09 02:21:27 --> Config Class Initialized
INFO - 2023-03-09 02:21:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 02:21:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 02:21:27 --> Utf8 Class Initialized
INFO - 2023-03-09 02:21:27 --> URI Class Initialized
INFO - 2023-03-09 02:21:27 --> Router Class Initialized
INFO - 2023-03-09 02:21:27 --> Output Class Initialized
INFO - 2023-03-09 02:21:27 --> Security Class Initialized
DEBUG - 2023-03-09 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 02:21:27 --> Input Class Initialized
INFO - 2023-03-09 02:21:27 --> Language Class Initialized
INFO - 2023-03-09 02:21:27 --> Loader Class Initialized
INFO - 2023-03-09 02:21:27 --> Controller Class Initialized
DEBUG - 2023-03-09 02:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 02:21:27 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:27 --> Model "Cluster_model" initialized
INFO - 2023-03-09 02:21:27 --> Database Driver Class Initialized
INFO - 2023-03-09 02:21:27 --> Model "Login_model" initialized
INFO - 2023-03-09 02:21:28 --> Final output sent to browser
DEBUG - 2023-03-09 02:21:28 --> Total execution time: 0.0961
INFO - 2023-03-09 08:01:52 --> Config Class Initialized
INFO - 2023-03-09 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:01:52 --> Utf8 Class Initialized
INFO - 2023-03-09 08:01:52 --> URI Class Initialized
INFO - 2023-03-09 08:01:52 --> Router Class Initialized
INFO - 2023-03-09 08:01:52 --> Output Class Initialized
INFO - 2023-03-09 08:01:52 --> Security Class Initialized
DEBUG - 2023-03-09 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:01:52 --> Input Class Initialized
INFO - 2023-03-09 08:01:52 --> Language Class Initialized
INFO - 2023-03-09 08:01:52 --> Loader Class Initialized
INFO - 2023-03-09 08:01:52 --> Controller Class Initialized
DEBUG - 2023-03-09 08:01:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:01:52 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:52 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:01:52 --> Final output sent to browser
DEBUG - 2023-03-09 08:01:52 --> Total execution time: 0.0986
INFO - 2023-03-09 08:01:52 --> Config Class Initialized
INFO - 2023-03-09 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:01:52 --> Utf8 Class Initialized
INFO - 2023-03-09 08:01:52 --> URI Class Initialized
INFO - 2023-03-09 08:01:52 --> Router Class Initialized
INFO - 2023-03-09 08:01:52 --> Output Class Initialized
INFO - 2023-03-09 08:01:52 --> Security Class Initialized
DEBUG - 2023-03-09 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:01:52 --> Input Class Initialized
INFO - 2023-03-09 08:01:52 --> Language Class Initialized
INFO - 2023-03-09 08:01:52 --> Loader Class Initialized
INFO - 2023-03-09 08:01:52 --> Controller Class Initialized
DEBUG - 2023-03-09 08:01:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:01:52 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:52 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:01:52 --> Final output sent to browser
DEBUG - 2023-03-09 08:01:52 --> Total execution time: 0.1222
INFO - 2023-03-09 08:01:56 --> Config Class Initialized
INFO - 2023-03-09 08:01:56 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:01:56 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:01:56 --> Utf8 Class Initialized
INFO - 2023-03-09 08:01:56 --> URI Class Initialized
INFO - 2023-03-09 08:01:56 --> Router Class Initialized
INFO - 2023-03-09 08:01:56 --> Output Class Initialized
INFO - 2023-03-09 08:01:56 --> Security Class Initialized
DEBUG - 2023-03-09 08:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:01:56 --> Input Class Initialized
INFO - 2023-03-09 08:01:56 --> Language Class Initialized
INFO - 2023-03-09 08:01:56 --> Loader Class Initialized
INFO - 2023-03-09 08:01:56 --> Controller Class Initialized
DEBUG - 2023-03-09 08:01:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:01:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:56 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:01:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:56 --> Model "Login_model" initialized
INFO - 2023-03-09 08:01:56 --> Final output sent to browser
DEBUG - 2023-03-09 08:01:56 --> Total execution time: 0.0853
INFO - 2023-03-09 08:01:56 --> Config Class Initialized
INFO - 2023-03-09 08:01:56 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:01:56 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:01:56 --> Utf8 Class Initialized
INFO - 2023-03-09 08:01:56 --> URI Class Initialized
INFO - 2023-03-09 08:01:56 --> Router Class Initialized
INFO - 2023-03-09 08:01:56 --> Output Class Initialized
INFO - 2023-03-09 08:01:56 --> Security Class Initialized
DEBUG - 2023-03-09 08:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:01:56 --> Input Class Initialized
INFO - 2023-03-09 08:01:56 --> Language Class Initialized
INFO - 2023-03-09 08:01:56 --> Loader Class Initialized
INFO - 2023-03-09 08:01:56 --> Controller Class Initialized
DEBUG - 2023-03-09 08:01:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:01:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:56 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:01:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:01:56 --> Model "Login_model" initialized
INFO - 2023-03-09 08:01:56 --> Final output sent to browser
DEBUG - 2023-03-09 08:01:56 --> Total execution time: 0.1221
INFO - 2023-03-09 08:02:04 --> Config Class Initialized
INFO - 2023-03-09 08:02:04 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:04 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:04 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:04 --> URI Class Initialized
INFO - 2023-03-09 08:02:04 --> Router Class Initialized
INFO - 2023-03-09 08:02:04 --> Output Class Initialized
INFO - 2023-03-09 08:02:04 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:04 --> Input Class Initialized
INFO - 2023-03-09 08:02:04 --> Language Class Initialized
INFO - 2023-03-09 08:02:04 --> Loader Class Initialized
INFO - 2023-03-09 08:02:04 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:04 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:04 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:04 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:04 --> Model "Login_model" initialized
INFO - 2023-03-09 08:02:04 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:04 --> Total execution time: 0.0747
INFO - 2023-03-09 08:02:04 --> Config Class Initialized
INFO - 2023-03-09 08:02:04 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:04 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:04 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:04 --> URI Class Initialized
INFO - 2023-03-09 08:02:04 --> Router Class Initialized
INFO - 2023-03-09 08:02:04 --> Output Class Initialized
INFO - 2023-03-09 08:02:04 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:04 --> Input Class Initialized
INFO - 2023-03-09 08:02:04 --> Language Class Initialized
INFO - 2023-03-09 08:02:04 --> Loader Class Initialized
INFO - 2023-03-09 08:02:04 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:04 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:04 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:04 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:04 --> Model "Login_model" initialized
INFO - 2023-03-09 08:02:04 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:04 --> Total execution time: 0.0642
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
INFO - 2023-03-09 08:02:12 --> Helper loaded: form_helper
INFO - 2023-03-09 08:02:12 --> Helper loaded: url_helper
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Model "Change_model" initialized
INFO - 2023-03-09 08:02:12 --> Model "Grafana_model" initialized
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.1226
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
INFO - 2023-03-09 08:02:12 --> Helper loaded: form_helper
INFO - 2023-03-09 08:02:12 --> Helper loaded: url_helper
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.0455
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
INFO - 2023-03-09 08:02:12 --> Helper loaded: form_helper
INFO - 2023-03-09 08:02:12 --> Helper loaded: url_helper
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Login_model" initialized
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.0184
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.0651
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.0150
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Login_model" initialized
INFO - 2023-03-09 08:02:12 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:12 --> Total execution time: 0.1869
INFO - 2023-03-09 08:02:12 --> Config Class Initialized
INFO - 2023-03-09 08:02:12 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:12 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:12 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:12 --> URI Class Initialized
INFO - 2023-03-09 08:02:12 --> Router Class Initialized
INFO - 2023-03-09 08:02:12 --> Output Class Initialized
INFO - 2023-03-09 08:02:12 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:12 --> Input Class Initialized
INFO - 2023-03-09 08:02:12 --> Language Class Initialized
INFO - 2023-03-09 08:02:12 --> Loader Class Initialized
INFO - 2023-03-09 08:02:12 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:12 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:12 --> Model "Login_model" initialized
INFO - 2023-03-09 08:02:13 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:13 --> Total execution time: 0.3985
INFO - 2023-03-09 08:02:25 --> Config Class Initialized
INFO - 2023-03-09 08:02:25 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:25 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:25 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:25 --> URI Class Initialized
INFO - 2023-03-09 08:02:25 --> Router Class Initialized
INFO - 2023-03-09 08:02:25 --> Output Class Initialized
INFO - 2023-03-09 08:02:25 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:25 --> Input Class Initialized
INFO - 2023-03-09 08:02:25 --> Language Class Initialized
INFO - 2023-03-09 08:02:25 --> Loader Class Initialized
INFO - 2023-03-09 08:02:25 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:25 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:25 --> Total execution time: 0.0055
INFO - 2023-03-09 08:02:25 --> Config Class Initialized
INFO - 2023-03-09 08:02:25 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:25 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:25 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:25 --> URI Class Initialized
INFO - 2023-03-09 08:02:25 --> Router Class Initialized
INFO - 2023-03-09 08:02:25 --> Output Class Initialized
INFO - 2023-03-09 08:02:25 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:25 --> Input Class Initialized
INFO - 2023-03-09 08:02:25 --> Language Class Initialized
INFO - 2023-03-09 08:02:25 --> Loader Class Initialized
INFO - 2023-03-09 08:02:25 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:25 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:25 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:25 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:25 --> Total execution time: 0.0122
INFO - 2023-03-09 08:02:27 --> Config Class Initialized
INFO - 2023-03-09 08:02:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:27 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:27 --> URI Class Initialized
INFO - 2023-03-09 08:02:27 --> Router Class Initialized
INFO - 2023-03-09 08:02:27 --> Output Class Initialized
INFO - 2023-03-09 08:02:27 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:27 --> Input Class Initialized
INFO - 2023-03-09 08:02:27 --> Language Class Initialized
INFO - 2023-03-09 08:02:27 --> Loader Class Initialized
INFO - 2023-03-09 08:02:27 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:27 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:27 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:27 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:27 --> Total execution time: 0.0558
INFO - 2023-03-09 08:02:27 --> Config Class Initialized
INFO - 2023-03-09 08:02:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:27 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:27 --> URI Class Initialized
INFO - 2023-03-09 08:02:27 --> Router Class Initialized
INFO - 2023-03-09 08:02:27 --> Output Class Initialized
INFO - 2023-03-09 08:02:27 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:27 --> Input Class Initialized
INFO - 2023-03-09 08:02:27 --> Language Class Initialized
INFO - 2023-03-09 08:02:27 --> Loader Class Initialized
INFO - 2023-03-09 08:02:27 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:27 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:27 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:27 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:27 --> Total execution time: 0.0518
INFO - 2023-03-09 08:02:28 --> Config Class Initialized
INFO - 2023-03-09 08:02:28 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:28 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:28 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:28 --> URI Class Initialized
INFO - 2023-03-09 08:02:28 --> Router Class Initialized
INFO - 2023-03-09 08:02:28 --> Output Class Initialized
INFO - 2023-03-09 08:02:28 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:28 --> Input Class Initialized
INFO - 2023-03-09 08:02:28 --> Language Class Initialized
INFO - 2023-03-09 08:02:28 --> Loader Class Initialized
INFO - 2023-03-09 08:02:28 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:28 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:28 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:28 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:28 --> Total execution time: 0.0608
INFO - 2023-03-09 08:02:28 --> Config Class Initialized
INFO - 2023-03-09 08:02:28 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:28 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:28 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:28 --> URI Class Initialized
INFO - 2023-03-09 08:02:28 --> Router Class Initialized
INFO - 2023-03-09 08:02:28 --> Output Class Initialized
INFO - 2023-03-09 08:02:28 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:29 --> Input Class Initialized
INFO - 2023-03-09 08:02:29 --> Language Class Initialized
INFO - 2023-03-09 08:02:29 --> Loader Class Initialized
INFO - 2023-03-09 08:02:29 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:29 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:29 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:29 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:29 --> Total execution time: 0.0669
INFO - 2023-03-09 08:02:43 --> Config Class Initialized
INFO - 2023-03-09 08:02:43 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:43 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:43 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:43 --> URI Class Initialized
INFO - 2023-03-09 08:02:43 --> Router Class Initialized
INFO - 2023-03-09 08:02:43 --> Output Class Initialized
INFO - 2023-03-09 08:02:43 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:43 --> Input Class Initialized
INFO - 2023-03-09 08:02:43 --> Language Class Initialized
INFO - 2023-03-09 08:02:43 --> Loader Class Initialized
INFO - 2023-03-09 08:02:43 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:43 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:43 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:43 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:43 --> Total execution time: 0.0237
INFO - 2023-03-09 08:02:43 --> Config Class Initialized
INFO - 2023-03-09 08:02:43 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:43 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:43 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:43 --> URI Class Initialized
INFO - 2023-03-09 08:02:43 --> Router Class Initialized
INFO - 2023-03-09 08:02:43 --> Output Class Initialized
INFO - 2023-03-09 08:02:43 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:43 --> Input Class Initialized
INFO - 2023-03-09 08:02:43 --> Language Class Initialized
INFO - 2023-03-09 08:02:43 --> Loader Class Initialized
INFO - 2023-03-09 08:02:43 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:43 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:43 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:43 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:43 --> Total execution time: 0.0607
INFO - 2023-03-09 08:02:47 --> Config Class Initialized
INFO - 2023-03-09 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:47 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:47 --> URI Class Initialized
INFO - 2023-03-09 08:02:47 --> Router Class Initialized
INFO - 2023-03-09 08:02:47 --> Output Class Initialized
INFO - 2023-03-09 08:02:47 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:47 --> Input Class Initialized
INFO - 2023-03-09 08:02:47 --> Language Class Initialized
INFO - 2023-03-09 08:02:47 --> Loader Class Initialized
INFO - 2023-03-09 08:02:47 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:47 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:47 --> Total execution time: 0.0039
INFO - 2023-03-09 08:02:47 --> Config Class Initialized
INFO - 2023-03-09 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:47 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:47 --> URI Class Initialized
INFO - 2023-03-09 08:02:47 --> Router Class Initialized
INFO - 2023-03-09 08:02:47 --> Output Class Initialized
INFO - 2023-03-09 08:02:47 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:47 --> Input Class Initialized
INFO - 2023-03-09 08:02:47 --> Language Class Initialized
INFO - 2023-03-09 08:02:47 --> Loader Class Initialized
INFO - 2023-03-09 08:02:47 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:47 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:47 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:47 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:47 --> Total execution time: 0.0099
INFO - 2023-03-09 08:02:48 --> Config Class Initialized
INFO - 2023-03-09 08:02:48 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:48 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:48 --> URI Class Initialized
INFO - 2023-03-09 08:02:48 --> Router Class Initialized
INFO - 2023-03-09 08:02:48 --> Output Class Initialized
INFO - 2023-03-09 08:02:48 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:48 --> Input Class Initialized
INFO - 2023-03-09 08:02:48 --> Language Class Initialized
INFO - 2023-03-09 08:02:48 --> Loader Class Initialized
INFO - 2023-03-09 08:02:48 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:48 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:48 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:48 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:48 --> Total execution time: 0.0874
INFO - 2023-03-09 08:02:49 --> Config Class Initialized
INFO - 2023-03-09 08:02:49 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:49 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:49 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:49 --> URI Class Initialized
INFO - 2023-03-09 08:02:49 --> Router Class Initialized
INFO - 2023-03-09 08:02:49 --> Output Class Initialized
INFO - 2023-03-09 08:02:49 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:49 --> Input Class Initialized
INFO - 2023-03-09 08:02:49 --> Language Class Initialized
INFO - 2023-03-09 08:02:49 --> Loader Class Initialized
INFO - 2023-03-09 08:02:49 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:49 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:49 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:49 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:49 --> Total execution time: 0.0222
INFO - 2023-03-09 08:02:49 --> Config Class Initialized
INFO - 2023-03-09 08:02:49 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:49 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:49 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:49 --> URI Class Initialized
INFO - 2023-03-09 08:02:49 --> Router Class Initialized
INFO - 2023-03-09 08:02:49 --> Output Class Initialized
INFO - 2023-03-09 08:02:49 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:49 --> Input Class Initialized
INFO - 2023-03-09 08:02:49 --> Language Class Initialized
INFO - 2023-03-09 08:02:49 --> Loader Class Initialized
INFO - 2023-03-09 08:02:49 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:49 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:49 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:49 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:49 --> Total execution time: 0.0185
INFO - 2023-03-09 08:02:53 --> Config Class Initialized
INFO - 2023-03-09 08:02:53 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:53 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:53 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:53 --> URI Class Initialized
INFO - 2023-03-09 08:02:53 --> Router Class Initialized
INFO - 2023-03-09 08:02:53 --> Output Class Initialized
INFO - 2023-03-09 08:02:53 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:53 --> Input Class Initialized
INFO - 2023-03-09 08:02:53 --> Language Class Initialized
INFO - 2023-03-09 08:02:53 --> Loader Class Initialized
INFO - 2023-03-09 08:02:53 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:53 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:53 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:53 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:53 --> Total execution time: 0.0455
INFO - 2023-03-09 08:02:53 --> Config Class Initialized
INFO - 2023-03-09 08:02:53 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:53 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:53 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:53 --> URI Class Initialized
INFO - 2023-03-09 08:02:53 --> Router Class Initialized
INFO - 2023-03-09 08:02:53 --> Output Class Initialized
INFO - 2023-03-09 08:02:53 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:53 --> Input Class Initialized
INFO - 2023-03-09 08:02:53 --> Language Class Initialized
INFO - 2023-03-09 08:02:53 --> Loader Class Initialized
INFO - 2023-03-09 08:02:53 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:53 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:53 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:53 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:53 --> Total execution time: 0.0112
INFO - 2023-03-09 08:02:54 --> Config Class Initialized
INFO - 2023-03-09 08:02:54 --> Config Class Initialized
INFO - 2023-03-09 08:02:54 --> Hooks Class Initialized
INFO - 2023-03-09 08:02:54 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-03-09 08:02:54 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:54 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:54 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:54 --> URI Class Initialized
INFO - 2023-03-09 08:02:54 --> URI Class Initialized
INFO - 2023-03-09 08:02:54 --> Router Class Initialized
INFO - 2023-03-09 08:02:54 --> Router Class Initialized
INFO - 2023-03-09 08:02:54 --> Output Class Initialized
INFO - 2023-03-09 08:02:54 --> Output Class Initialized
INFO - 2023-03-09 08:02:54 --> Security Class Initialized
INFO - 2023-03-09 08:02:54 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-09 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:54 --> Input Class Initialized
INFO - 2023-03-09 08:02:54 --> Input Class Initialized
INFO - 2023-03-09 08:02:54 --> Language Class Initialized
INFO - 2023-03-09 08:02:54 --> Language Class Initialized
INFO - 2023-03-09 08:02:54 --> Loader Class Initialized
INFO - 2023-03-09 08:02:54 --> Controller Class Initialized
INFO - 2023-03-09 08:02:54 --> Loader Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:54 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:54 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:54 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:54 --> Total execution time: 0.0053
INFO - 2023-03-09 08:02:54 --> Config Class Initialized
INFO - 2023-03-09 08:02:54 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:54 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:54 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:54 --> URI Class Initialized
INFO - 2023-03-09 08:02:54 --> Router Class Initialized
INFO - 2023-03-09 08:02:54 --> Output Class Initialized
INFO - 2023-03-09 08:02:54 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:54 --> Input Class Initialized
INFO - 2023-03-09 08:02:54 --> Language Class Initialized
INFO - 2023-03-09 08:02:54 --> Loader Class Initialized
INFO - 2023-03-09 08:02:54 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:54 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:54 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:54 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:54 --> Total execution time: 0.0170
INFO - 2023-03-09 08:02:54 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:54 --> Config Class Initialized
INFO - 2023-03-09 08:02:54 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:54 --> Total execution time: 0.0131
INFO - 2023-03-09 08:02:54 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:54 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:54 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:54 --> URI Class Initialized
INFO - 2023-03-09 08:02:54 --> Router Class Initialized
INFO - 2023-03-09 08:02:54 --> Output Class Initialized
INFO - 2023-03-09 08:02:54 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:54 --> Input Class Initialized
INFO - 2023-03-09 08:02:54 --> Language Class Initialized
INFO - 2023-03-09 08:02:54 --> Loader Class Initialized
INFO - 2023-03-09 08:02:54 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:54 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:54 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:54 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:54 --> Total execution time: 0.0523
INFO - 2023-03-09 08:02:56 --> Config Class Initialized
INFO - 2023-03-09 08:02:56 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:56 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:56 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:56 --> URI Class Initialized
INFO - 2023-03-09 08:02:56 --> Router Class Initialized
INFO - 2023-03-09 08:02:56 --> Output Class Initialized
INFO - 2023-03-09 08:02:56 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:56 --> Input Class Initialized
INFO - 2023-03-09 08:02:56 --> Language Class Initialized
INFO - 2023-03-09 08:02:56 --> Loader Class Initialized
INFO - 2023-03-09 08:02:56 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:56 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:56 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:56 --> Total execution time: 0.0236
INFO - 2023-03-09 08:02:56 --> Config Class Initialized
INFO - 2023-03-09 08:02:56 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:56 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:56 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:56 --> URI Class Initialized
INFO - 2023-03-09 08:02:56 --> Router Class Initialized
INFO - 2023-03-09 08:02:56 --> Output Class Initialized
INFO - 2023-03-09 08:02:56 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:56 --> Input Class Initialized
INFO - 2023-03-09 08:02:56 --> Language Class Initialized
INFO - 2023-03-09 08:02:56 --> Loader Class Initialized
INFO - 2023-03-09 08:02:56 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:56 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:56 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:56 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:56 --> Total execution time: 0.0170
INFO - 2023-03-09 08:02:59 --> Config Class Initialized
INFO - 2023-03-09 08:02:59 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:59 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:59 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:59 --> URI Class Initialized
INFO - 2023-03-09 08:02:59 --> Router Class Initialized
INFO - 2023-03-09 08:02:59 --> Output Class Initialized
INFO - 2023-03-09 08:02:59 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:59 --> Input Class Initialized
INFO - 2023-03-09 08:02:59 --> Language Class Initialized
INFO - 2023-03-09 08:02:59 --> Loader Class Initialized
INFO - 2023-03-09 08:02:59 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:59 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:59 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:59 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:59 --> Total execution time: 0.0156
INFO - 2023-03-09 08:02:59 --> Config Class Initialized
INFO - 2023-03-09 08:02:59 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:02:59 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:02:59 --> Utf8 Class Initialized
INFO - 2023-03-09 08:02:59 --> URI Class Initialized
INFO - 2023-03-09 08:02:59 --> Router Class Initialized
INFO - 2023-03-09 08:02:59 --> Output Class Initialized
INFO - 2023-03-09 08:02:59 --> Security Class Initialized
DEBUG - 2023-03-09 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:02:59 --> Input Class Initialized
INFO - 2023-03-09 08:02:59 --> Language Class Initialized
INFO - 2023-03-09 08:02:59 --> Loader Class Initialized
INFO - 2023-03-09 08:02:59 --> Controller Class Initialized
DEBUG - 2023-03-09 08:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:02:59 --> Database Driver Class Initialized
INFO - 2023-03-09 08:02:59 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:02:59 --> Final output sent to browser
DEBUG - 2023-03-09 08:02:59 --> Total execution time: 0.0119
INFO - 2023-03-09 08:03:02 --> Config Class Initialized
INFO - 2023-03-09 08:03:02 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:02 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:02 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:02 --> URI Class Initialized
INFO - 2023-03-09 08:03:02 --> Router Class Initialized
INFO - 2023-03-09 08:03:02 --> Output Class Initialized
INFO - 2023-03-09 08:03:02 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:02 --> Input Class Initialized
INFO - 2023-03-09 08:03:02 --> Language Class Initialized
INFO - 2023-03-09 08:03:02 --> Loader Class Initialized
INFO - 2023-03-09 08:03:02 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:02 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:02 --> Total execution time: 0.0039
INFO - 2023-03-09 08:03:02 --> Config Class Initialized
INFO - 2023-03-09 08:03:03 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:03 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:03 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:03 --> URI Class Initialized
INFO - 2023-03-09 08:03:03 --> Router Class Initialized
INFO - 2023-03-09 08:03:03 --> Output Class Initialized
INFO - 2023-03-09 08:03:03 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:03 --> Input Class Initialized
INFO - 2023-03-09 08:03:03 --> Language Class Initialized
INFO - 2023-03-09 08:03:03 --> Loader Class Initialized
INFO - 2023-03-09 08:03:03 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:03 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:03 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:03 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:03 --> Total execution time: 0.0589
INFO - 2023-03-09 08:03:16 --> Config Class Initialized
INFO - 2023-03-09 08:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:16 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:16 --> URI Class Initialized
INFO - 2023-03-09 08:03:16 --> Router Class Initialized
INFO - 2023-03-09 08:03:16 --> Output Class Initialized
INFO - 2023-03-09 08:03:16 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:16 --> Input Class Initialized
INFO - 2023-03-09 08:03:16 --> Language Class Initialized
INFO - 2023-03-09 08:03:16 --> Loader Class Initialized
INFO - 2023-03-09 08:03:16 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:16 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:16 --> Total execution time: 0.0076
INFO - 2023-03-09 08:03:16 --> Config Class Initialized
INFO - 2023-03-09 08:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:16 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:16 --> URI Class Initialized
INFO - 2023-03-09 08:03:16 --> Router Class Initialized
INFO - 2023-03-09 08:03:16 --> Output Class Initialized
INFO - 2023-03-09 08:03:16 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:16 --> Input Class Initialized
INFO - 2023-03-09 08:03:16 --> Language Class Initialized
INFO - 2023-03-09 08:03:16 --> Loader Class Initialized
INFO - 2023-03-09 08:03:16 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:16 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:16 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:16 --> Total execution time: 0.0120
INFO - 2023-03-09 08:03:17 --> Config Class Initialized
INFO - 2023-03-09 08:03:17 --> Config Class Initialized
INFO - 2023-03-09 08:03:17 --> Hooks Class Initialized
INFO - 2023-03-09 08:03:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-03-09 08:03:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:17 --> URI Class Initialized
INFO - 2023-03-09 08:03:17 --> URI Class Initialized
INFO - 2023-03-09 08:03:17 --> Router Class Initialized
INFO - 2023-03-09 08:03:17 --> Router Class Initialized
INFO - 2023-03-09 08:03:17 --> Output Class Initialized
INFO - 2023-03-09 08:03:17 --> Output Class Initialized
INFO - 2023-03-09 08:03:17 --> Security Class Initialized
INFO - 2023-03-09 08:03:17 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:17 --> Input Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:17 --> Language Class Initialized
INFO - 2023-03-09 08:03:17 --> Input Class Initialized
INFO - 2023-03-09 08:03:17 --> Language Class Initialized
INFO - 2023-03-09 08:03:17 --> Loader Class Initialized
INFO - 2023-03-09 08:03:17 --> Loader Class Initialized
INFO - 2023-03-09 08:03:17 --> Controller Class Initialized
INFO - 2023-03-09 08:03:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-09 08:03:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:17 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:17 --> Total execution time: 0.0186
INFO - 2023-03-09 08:03:17 --> Config Class Initialized
INFO - 2023-03-09 08:03:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:17 --> URI Class Initialized
INFO - 2023-03-09 08:03:17 --> Router Class Initialized
INFO - 2023-03-09 08:03:17 --> Output Class Initialized
INFO - 2023-03-09 08:03:17 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:17 --> Input Class Initialized
INFO - 2023-03-09 08:03:17 --> Language Class Initialized
INFO - 2023-03-09 08:03:17 --> Loader Class Initialized
INFO - 2023-03-09 08:03:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:17 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:17 --> Total execution time: 0.0498
INFO - 2023-03-09 08:03:17 --> Config Class Initialized
INFO - 2023-03-09 08:03:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:17 --> URI Class Initialized
INFO - 2023-03-09 08:03:17 --> Router Class Initialized
INFO - 2023-03-09 08:03:17 --> Output Class Initialized
INFO - 2023-03-09 08:03:17 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:17 --> Input Class Initialized
INFO - 2023-03-09 08:03:17 --> Language Class Initialized
INFO - 2023-03-09 08:03:17 --> Loader Class Initialized
INFO - 2023-03-09 08:03:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:20 --> Config Class Initialized
INFO - 2023-03-09 08:03:20 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:20 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:20 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:20 --> URI Class Initialized
INFO - 2023-03-09 08:03:20 --> Router Class Initialized
INFO - 2023-03-09 08:03:20 --> Output Class Initialized
INFO - 2023-03-09 08:03:20 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:20 --> Input Class Initialized
INFO - 2023-03-09 08:03:20 --> Language Class Initialized
INFO - 2023-03-09 08:03:20 --> Loader Class Initialized
INFO - 2023-03-09 08:03:20 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:20 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:20 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:20 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:20 --> Total execution time: 0.0433
INFO - 2023-03-09 08:03:22 --> Config Class Initialized
INFO - 2023-03-09 08:03:22 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:22 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:22 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:22 --> URI Class Initialized
INFO - 2023-03-09 08:03:22 --> Router Class Initialized
INFO - 2023-03-09 08:03:22 --> Output Class Initialized
INFO - 2023-03-09 08:03:22 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:22 --> Input Class Initialized
INFO - 2023-03-09 08:03:22 --> Language Class Initialized
INFO - 2023-03-09 08:03:22 --> Loader Class Initialized
INFO - 2023-03-09 08:03:22 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:22 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:22 --> Total execution time: 0.0042
INFO - 2023-03-09 08:03:22 --> Config Class Initialized
INFO - 2023-03-09 08:03:22 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:22 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:22 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:22 --> URI Class Initialized
INFO - 2023-03-09 08:03:22 --> Router Class Initialized
INFO - 2023-03-09 08:03:22 --> Output Class Initialized
INFO - 2023-03-09 08:03:22 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:22 --> Input Class Initialized
INFO - 2023-03-09 08:03:22 --> Language Class Initialized
INFO - 2023-03-09 08:03:22 --> Loader Class Initialized
INFO - 2023-03-09 08:03:22 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:22 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:22 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:22 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:22 --> Total execution time: 0.0128
INFO - 2023-03-09 08:03:26 --> Config Class Initialized
INFO - 2023-03-09 08:03:26 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:26 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:26 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:26 --> URI Class Initialized
INFO - 2023-03-09 08:03:26 --> Router Class Initialized
INFO - 2023-03-09 08:03:26 --> Output Class Initialized
INFO - 2023-03-09 08:03:26 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:26 --> Input Class Initialized
INFO - 2023-03-09 08:03:26 --> Language Class Initialized
INFO - 2023-03-09 08:03:26 --> Loader Class Initialized
INFO - 2023-03-09 08:03:26 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:26 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:26 --> Total execution time: 0.0042
INFO - 2023-03-09 08:03:26 --> Config Class Initialized
INFO - 2023-03-09 08:03:26 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:03:26 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:03:26 --> Utf8 Class Initialized
INFO - 2023-03-09 08:03:26 --> URI Class Initialized
INFO - 2023-03-09 08:03:26 --> Router Class Initialized
INFO - 2023-03-09 08:03:26 --> Output Class Initialized
INFO - 2023-03-09 08:03:26 --> Security Class Initialized
DEBUG - 2023-03-09 08:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:03:26 --> Input Class Initialized
INFO - 2023-03-09 08:03:26 --> Language Class Initialized
INFO - 2023-03-09 08:03:26 --> Loader Class Initialized
INFO - 2023-03-09 08:03:26 --> Controller Class Initialized
DEBUG - 2023-03-09 08:03:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:03:26 --> Database Driver Class Initialized
INFO - 2023-03-09 08:03:26 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:03:26 --> Final output sent to browser
DEBUG - 2023-03-09 08:03:26 --> Total execution time: 0.0121
INFO - 2023-03-09 08:06:13 --> Config Class Initialized
INFO - 2023-03-09 08:06:13 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:13 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:13 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:13 --> URI Class Initialized
INFO - 2023-03-09 08:06:13 --> Router Class Initialized
INFO - 2023-03-09 08:06:13 --> Output Class Initialized
INFO - 2023-03-09 08:06:13 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:13 --> Input Class Initialized
INFO - 2023-03-09 08:06:13 --> Language Class Initialized
INFO - 2023-03-09 08:06:13 --> Loader Class Initialized
INFO - 2023-03-09 08:06:13 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:13 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:13 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:13 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:13 --> Total execution time: 0.0228
INFO - 2023-03-09 08:06:13 --> Config Class Initialized
INFO - 2023-03-09 08:06:13 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:13 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:13 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:13 --> URI Class Initialized
INFO - 2023-03-09 08:06:13 --> Router Class Initialized
INFO - 2023-03-09 08:06:13 --> Output Class Initialized
INFO - 2023-03-09 08:06:13 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:13 --> Input Class Initialized
INFO - 2023-03-09 08:06:13 --> Language Class Initialized
INFO - 2023-03-09 08:06:13 --> Loader Class Initialized
INFO - 2023-03-09 08:06:13 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:13 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:13 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:13 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:13 --> Total execution time: 0.0596
INFO - 2023-03-09 08:06:17 --> Config Class Initialized
INFO - 2023-03-09 08:06:17 --> Hooks Class Initialized
INFO - 2023-03-09 08:06:17 --> Config Class Initialized
INFO - 2023-03-09 08:06:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:17 --> Utf8 Class Initialized
DEBUG - 2023-03-09 08:06:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:17 --> URI Class Initialized
INFO - 2023-03-09 08:06:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:17 --> Router Class Initialized
INFO - 2023-03-09 08:06:17 --> URI Class Initialized
INFO - 2023-03-09 08:06:17 --> Output Class Initialized
INFO - 2023-03-09 08:06:17 --> Router Class Initialized
INFO - 2023-03-09 08:06:17 --> Security Class Initialized
INFO - 2023-03-09 08:06:17 --> Output Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:17 --> Security Class Initialized
INFO - 2023-03-09 08:06:17 --> Input Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:17 --> Language Class Initialized
INFO - 2023-03-09 08:06:17 --> Input Class Initialized
INFO - 2023-03-09 08:06:17 --> Language Class Initialized
INFO - 2023-03-09 08:06:17 --> Loader Class Initialized
INFO - 2023-03-09 08:06:17 --> Loader Class Initialized
INFO - 2023-03-09 08:06:17 --> Controller Class Initialized
INFO - 2023-03-09 08:06:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-09 08:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:17 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:17 --> Total execution time: 0.0049
INFO - 2023-03-09 08:06:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:17 --> Config Class Initialized
INFO - 2023-03-09 08:06:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:17 --> URI Class Initialized
INFO - 2023-03-09 08:06:17 --> Router Class Initialized
INFO - 2023-03-09 08:06:17 --> Output Class Initialized
INFO - 2023-03-09 08:06:17 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:17 --> Input Class Initialized
INFO - 2023-03-09 08:06:17 --> Language Class Initialized
INFO - 2023-03-09 08:06:17 --> Loader Class Initialized
INFO - 2023-03-09 08:06:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:17 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:17 --> Total execution time: 0.0163
INFO - 2023-03-09 08:06:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:17 --> Config Class Initialized
INFO - 2023-03-09 08:06:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:17 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:17 --> URI Class Initialized
INFO - 2023-03-09 08:06:17 --> Router Class Initialized
INFO - 2023-03-09 08:06:17 --> Output Class Initialized
INFO - 2023-03-09 08:06:17 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:17 --> Input Class Initialized
INFO - 2023-03-09 08:06:17 --> Language Class Initialized
INFO - 2023-03-09 08:06:17 --> Final output sent to browser
INFO - 2023-03-09 08:06:17 --> Loader Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Total execution time: 0.0534
INFO - 2023-03-09 08:06:17 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:17 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:17 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:17 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:17 --> Total execution time: 0.0926
INFO - 2023-03-09 08:06:18 --> Config Class Initialized
INFO - 2023-03-09 08:06:18 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:18 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:18 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:18 --> URI Class Initialized
INFO - 2023-03-09 08:06:18 --> Router Class Initialized
INFO - 2023-03-09 08:06:18 --> Output Class Initialized
INFO - 2023-03-09 08:06:18 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:18 --> Input Class Initialized
INFO - 2023-03-09 08:06:18 --> Language Class Initialized
INFO - 2023-03-09 08:06:18 --> Loader Class Initialized
INFO - 2023-03-09 08:06:18 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:18 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:18 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:18 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:18 --> Total execution time: 0.0654
INFO - 2023-03-09 08:06:18 --> Config Class Initialized
INFO - 2023-03-09 08:06:19 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:19 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:19 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:19 --> URI Class Initialized
INFO - 2023-03-09 08:06:19 --> Router Class Initialized
INFO - 2023-03-09 08:06:19 --> Output Class Initialized
INFO - 2023-03-09 08:06:19 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:19 --> Input Class Initialized
INFO - 2023-03-09 08:06:19 --> Language Class Initialized
INFO - 2023-03-09 08:06:19 --> Loader Class Initialized
INFO - 2023-03-09 08:06:19 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:19 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:19 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:19 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:19 --> Total execution time: 0.1045
INFO - 2023-03-09 08:06:23 --> Config Class Initialized
INFO - 2023-03-09 08:06:23 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:23 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:23 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:23 --> URI Class Initialized
INFO - 2023-03-09 08:06:23 --> Router Class Initialized
INFO - 2023-03-09 08:06:23 --> Output Class Initialized
INFO - 2023-03-09 08:06:23 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:23 --> Input Class Initialized
INFO - 2023-03-09 08:06:23 --> Language Class Initialized
INFO - 2023-03-09 08:06:23 --> Loader Class Initialized
INFO - 2023-03-09 08:06:23 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:23 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:23 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:23 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:23 --> Total execution time: 0.0170
INFO - 2023-03-09 08:06:23 --> Config Class Initialized
INFO - 2023-03-09 08:06:23 --> Hooks Class Initialized
DEBUG - 2023-03-09 08:06:23 --> UTF-8 Support Enabled
INFO - 2023-03-09 08:06:23 --> Utf8 Class Initialized
INFO - 2023-03-09 08:06:23 --> URI Class Initialized
INFO - 2023-03-09 08:06:23 --> Router Class Initialized
INFO - 2023-03-09 08:06:23 --> Output Class Initialized
INFO - 2023-03-09 08:06:23 --> Security Class Initialized
DEBUG - 2023-03-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 08:06:23 --> Input Class Initialized
INFO - 2023-03-09 08:06:23 --> Language Class Initialized
INFO - 2023-03-09 08:06:23 --> Loader Class Initialized
INFO - 2023-03-09 08:06:23 --> Controller Class Initialized
DEBUG - 2023-03-09 08:06:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 08:06:23 --> Database Driver Class Initialized
INFO - 2023-03-09 08:06:23 --> Model "Cluster_model" initialized
INFO - 2023-03-09 08:06:23 --> Final output sent to browser
DEBUG - 2023-03-09 08:06:23 --> Total execution time: 0.0589
INFO - 2023-03-09 09:53:48 --> Config Class Initialized
INFO - 2023-03-09 09:53:48 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:48 --> Utf8 Class Initialized
INFO - 2023-03-09 09:53:48 --> URI Class Initialized
INFO - 2023-03-09 09:53:48 --> Router Class Initialized
INFO - 2023-03-09 09:53:48 --> Output Class Initialized
INFO - 2023-03-09 09:53:48 --> Security Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:48 --> Input Class Initialized
INFO - 2023-03-09 09:53:48 --> Language Class Initialized
INFO - 2023-03-09 09:53:48 --> Loader Class Initialized
INFO - 2023-03-09 09:53:48 --> Controller Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:48 --> Final output sent to browser
DEBUG - 2023-03-09 09:53:48 --> Total execution time: 0.0062
INFO - 2023-03-09 09:53:48 --> Config Class Initialized
INFO - 2023-03-09 09:53:48 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:48 --> Utf8 Class Initialized
INFO - 2023-03-09 09:53:48 --> URI Class Initialized
INFO - 2023-03-09 09:53:48 --> Router Class Initialized
INFO - 2023-03-09 09:53:48 --> Output Class Initialized
INFO - 2023-03-09 09:53:48 --> Security Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:48 --> Input Class Initialized
INFO - 2023-03-09 09:53:48 --> Language Class Initialized
INFO - 2023-03-09 09:53:48 --> Loader Class Initialized
INFO - 2023-03-09 09:53:48 --> Controller Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:48 --> Database Driver Class Initialized
INFO - 2023-03-09 09:53:48 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:53:48 --> Final output sent to browser
DEBUG - 2023-03-09 09:53:48 --> Total execution time: 0.0187
INFO - 2023-03-09 09:53:48 --> Config Class Initialized
INFO - 2023-03-09 09:53:48 --> Config Class Initialized
INFO - 2023-03-09 09:53:48 --> Hooks Class Initialized
INFO - 2023-03-09 09:53:48 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:48 --> Utf8 Class Initialized
DEBUG - 2023-03-09 09:53:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:48 --> URI Class Initialized
INFO - 2023-03-09 09:53:48 --> Utf8 Class Initialized
INFO - 2023-03-09 09:53:48 --> Router Class Initialized
INFO - 2023-03-09 09:53:48 --> URI Class Initialized
INFO - 2023-03-09 09:53:48 --> Output Class Initialized
INFO - 2023-03-09 09:53:48 --> Router Class Initialized
INFO - 2023-03-09 09:53:48 --> Security Class Initialized
INFO - 2023-03-09 09:53:48 --> Output Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:48 --> Security Class Initialized
INFO - 2023-03-09 09:53:48 --> Input Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:48 --> Language Class Initialized
INFO - 2023-03-09 09:53:48 --> Input Class Initialized
INFO - 2023-03-09 09:53:48 --> Language Class Initialized
INFO - 2023-03-09 09:53:48 --> Loader Class Initialized
INFO - 2023-03-09 09:53:48 --> Controller Class Initialized
INFO - 2023-03-09 09:53:48 --> Loader Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:48 --> Controller Class Initialized
DEBUG - 2023-03-09 09:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:48 --> Database Driver Class Initialized
INFO - 2023-03-09 09:53:48 --> Database Driver Class Initialized
INFO - 2023-03-09 09:53:48 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:53:48 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:53:48 --> Final output sent to browser
DEBUG - 2023-03-09 09:53:48 --> Total execution time: 0.0194
INFO - 2023-03-09 09:53:48 --> Config Class Initialized
INFO - 2023-03-09 09:53:48 --> Hooks Class Initialized
INFO - 2023-03-09 09:53:49 --> Config Class Initialized
INFO - 2023-03-09 09:53:49 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:53:49 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:49 --> Utf8 Class Initialized
DEBUG - 2023-03-09 09:53:49 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:53:49 --> URI Class Initialized
INFO - 2023-03-09 09:53:49 --> Utf8 Class Initialized
INFO - 2023-03-09 09:53:49 --> Router Class Initialized
INFO - 2023-03-09 09:53:49 --> URI Class Initialized
INFO - 2023-03-09 09:53:49 --> Output Class Initialized
INFO - 2023-03-09 09:53:49 --> Router Class Initialized
INFO - 2023-03-09 09:53:49 --> Security Class Initialized
INFO - 2023-03-09 09:53:49 --> Output Class Initialized
DEBUG - 2023-03-09 09:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:49 --> Security Class Initialized
INFO - 2023-03-09 09:53:49 --> Input Class Initialized
DEBUG - 2023-03-09 09:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:53:49 --> Language Class Initialized
INFO - 2023-03-09 09:53:49 --> Input Class Initialized
INFO - 2023-03-09 09:53:49 --> Loader Class Initialized
INFO - 2023-03-09 09:53:49 --> Language Class Initialized
INFO - 2023-03-09 09:53:49 --> Controller Class Initialized
INFO - 2023-03-09 09:53:49 --> Loader Class Initialized
DEBUG - 2023-03-09 09:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:49 --> Controller Class Initialized
INFO - 2023-03-09 09:53:49 --> Database Driver Class Initialized
DEBUG - 2023-03-09 09:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:53:49 --> Database Driver Class Initialized
INFO - 2023-03-09 09:53:49 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:53:49 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:53:49 --> Final output sent to browser
DEBUG - 2023-03-09 09:53:49 --> Total execution time: 0.1791
INFO - 2023-03-09 09:54:16 --> Config Class Initialized
INFO - 2023-03-09 09:54:16 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:16 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:16 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:16 --> URI Class Initialized
INFO - 2023-03-09 09:54:16 --> Router Class Initialized
INFO - 2023-03-09 09:54:16 --> Output Class Initialized
INFO - 2023-03-09 09:54:16 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:16 --> Input Class Initialized
INFO - 2023-03-09 09:54:16 --> Language Class Initialized
INFO - 2023-03-09 09:54:16 --> Loader Class Initialized
INFO - 2023-03-09 09:54:16 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:16 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:16 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:16 --> Config Class Initialized
INFO - 2023-03-09 09:54:16 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:16 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:16 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:16 --> URI Class Initialized
INFO - 2023-03-09 09:54:16 --> Router Class Initialized
INFO - 2023-03-09 09:54:16 --> Output Class Initialized
INFO - 2023-03-09 09:54:16 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:16 --> Input Class Initialized
INFO - 2023-03-09 09:54:16 --> Language Class Initialized
INFO - 2023-03-09 09:54:16 --> Loader Class Initialized
INFO - 2023-03-09 09:54:16 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:16 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:16 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:22 --> Config Class Initialized
INFO - 2023-03-09 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:22 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:22 --> URI Class Initialized
INFO - 2023-03-09 09:54:22 --> Router Class Initialized
INFO - 2023-03-09 09:54:22 --> Output Class Initialized
INFO - 2023-03-09 09:54:22 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:22 --> Input Class Initialized
INFO - 2023-03-09 09:54:22 --> Language Class Initialized
INFO - 2023-03-09 09:54:22 --> Loader Class Initialized
INFO - 2023-03-09 09:54:22 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-09 09:54:22 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 220
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-09 09:54:22 --> Config Class Initialized
INFO - 2023-03-09 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:22 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:22 --> URI Class Initialized
INFO - 2023-03-09 09:54:22 --> Router Class Initialized
INFO - 2023-03-09 09:54:22 --> Output Class Initialized
INFO - 2023-03-09 09:54:22 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:22 --> Input Class Initialized
INFO - 2023-03-09 09:54:22 --> Language Class Initialized
INFO - 2023-03-09 09:54:22 --> Loader Class Initialized
INFO - 2023-03-09 09:54:22 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:22 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:22 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:22 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:22 --> Total execution time: 0.0224
INFO - 2023-03-09 09:54:23 --> Config Class Initialized
INFO - 2023-03-09 09:54:23 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:23 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:23 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:23 --> URI Class Initialized
INFO - 2023-03-09 09:54:23 --> Router Class Initialized
INFO - 2023-03-09 09:54:23 --> Output Class Initialized
INFO - 2023-03-09 09:54:23 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:23 --> Input Class Initialized
INFO - 2023-03-09 09:54:23 --> Language Class Initialized
INFO - 2023-03-09 09:54:23 --> Loader Class Initialized
INFO - 2023-03-09 09:54:23 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:23 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:23 --> Total execution time: 0.0054
INFO - 2023-03-09 09:54:23 --> Config Class Initialized
INFO - 2023-03-09 09:54:23 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:23 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:23 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:23 --> URI Class Initialized
INFO - 2023-03-09 09:54:23 --> Router Class Initialized
INFO - 2023-03-09 09:54:23 --> Output Class Initialized
INFO - 2023-03-09 09:54:23 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:23 --> Input Class Initialized
INFO - 2023-03-09 09:54:23 --> Language Class Initialized
INFO - 2023-03-09 09:54:23 --> Loader Class Initialized
INFO - 2023-03-09 09:54:23 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:23 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:23 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:23 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:23 --> Total execution time: 0.0184
INFO - 2023-03-09 09:54:24 --> Config Class Initialized
INFO - 2023-03-09 09:54:24 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:24 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:24 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:24 --> URI Class Initialized
INFO - 2023-03-09 09:54:24 --> Router Class Initialized
INFO - 2023-03-09 09:54:24 --> Output Class Initialized
INFO - 2023-03-09 09:54:24 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:24 --> Input Class Initialized
INFO - 2023-03-09 09:54:24 --> Language Class Initialized
INFO - 2023-03-09 09:54:24 --> Loader Class Initialized
INFO - 2023-03-09 09:54:24 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:24 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:24 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:24 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:24 --> Total execution time: 0.0216
INFO - 2023-03-09 09:54:25 --> Config Class Initialized
INFO - 2023-03-09 09:54:25 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:25 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:25 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:25 --> URI Class Initialized
INFO - 2023-03-09 09:54:25 --> Router Class Initialized
INFO - 2023-03-09 09:54:25 --> Output Class Initialized
INFO - 2023-03-09 09:54:25 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:25 --> Input Class Initialized
INFO - 2023-03-09 09:54:25 --> Language Class Initialized
INFO - 2023-03-09 09:54:25 --> Loader Class Initialized
INFO - 2023-03-09 09:54:25 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:25 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:25 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:25 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:25 --> Total execution time: 0.0191
INFO - 2023-03-09 09:54:26 --> Config Class Initialized
INFO - 2023-03-09 09:54:26 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:26 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:26 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:26 --> URI Class Initialized
INFO - 2023-03-09 09:54:26 --> Router Class Initialized
INFO - 2023-03-09 09:54:26 --> Output Class Initialized
INFO - 2023-03-09 09:54:26 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:26 --> Input Class Initialized
INFO - 2023-03-09 09:54:26 --> Language Class Initialized
INFO - 2023-03-09 09:54:26 --> Loader Class Initialized
INFO - 2023-03-09 09:54:26 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:26 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:26 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:26 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:26 --> Total execution time: 0.0207
INFO - 2023-03-09 09:54:27 --> Config Class Initialized
INFO - 2023-03-09 09:54:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:27 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:27 --> URI Class Initialized
INFO - 2023-03-09 09:54:27 --> Router Class Initialized
INFO - 2023-03-09 09:54:27 --> Output Class Initialized
INFO - 2023-03-09 09:54:27 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:27 --> Input Class Initialized
INFO - 2023-03-09 09:54:27 --> Language Class Initialized
INFO - 2023-03-09 09:54:27 --> Loader Class Initialized
INFO - 2023-03-09 09:54:27 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:27 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:27 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:27 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:27 --> Total execution time: 0.0207
INFO - 2023-03-09 09:54:32 --> Config Class Initialized
INFO - 2023-03-09 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:32 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:32 --> URI Class Initialized
INFO - 2023-03-09 09:54:32 --> Router Class Initialized
INFO - 2023-03-09 09:54:32 --> Output Class Initialized
INFO - 2023-03-09 09:54:32 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:32 --> Input Class Initialized
INFO - 2023-03-09 09:54:32 --> Language Class Initialized
INFO - 2023-03-09 09:54:32 --> Loader Class Initialized
INFO - 2023-03-09 09:54:32 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:32 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:32 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:32 --> Model "Login_model" initialized
INFO - 2023-03-09 09:54:32 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:32 --> Total execution time: 0.0426
INFO - 2023-03-09 09:54:32 --> Config Class Initialized
INFO - 2023-03-09 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:32 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:32 --> URI Class Initialized
INFO - 2023-03-09 09:54:32 --> Router Class Initialized
INFO - 2023-03-09 09:54:32 --> Output Class Initialized
INFO - 2023-03-09 09:54:32 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:32 --> Input Class Initialized
INFO - 2023-03-09 09:54:32 --> Language Class Initialized
INFO - 2023-03-09 09:54:32 --> Loader Class Initialized
INFO - 2023-03-09 09:54:32 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:32 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:32 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:32 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:32 --> Model "Login_model" initialized
INFO - 2023-03-09 09:54:32 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:32 --> Total execution time: 0.0735
INFO - 2023-03-09 09:54:38 --> Config Class Initialized
INFO - 2023-03-09 09:54:38 --> Config Class Initialized
INFO - 2023-03-09 09:54:38 --> Hooks Class Initialized
INFO - 2023-03-09 09:54:38 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-03-09 09:54:38 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:38 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:38 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:38 --> URI Class Initialized
INFO - 2023-03-09 09:54:38 --> URI Class Initialized
INFO - 2023-03-09 09:54:38 --> Router Class Initialized
INFO - 2023-03-09 09:54:38 --> Router Class Initialized
INFO - 2023-03-09 09:54:38 --> Output Class Initialized
INFO - 2023-03-09 09:54:38 --> Output Class Initialized
INFO - 2023-03-09 09:54:38 --> Security Class Initialized
INFO - 2023-03-09 09:54:38 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-09 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:38 --> Input Class Initialized
INFO - 2023-03-09 09:54:38 --> Input Class Initialized
INFO - 2023-03-09 09:54:38 --> Language Class Initialized
INFO - 2023-03-09 09:54:38 --> Language Class Initialized
INFO - 2023-03-09 09:54:38 --> Loader Class Initialized
INFO - 2023-03-09 09:54:38 --> Loader Class Initialized
INFO - 2023-03-09 09:54:38 --> Controller Class Initialized
INFO - 2023-03-09 09:54:38 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-09 09:54:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:38 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:38 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:38 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:38 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:38 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:38 --> Total execution time: 0.0165
INFO - 2023-03-09 09:54:38 --> Config Class Initialized
INFO - 2023-03-09 09:54:38 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:38 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:38 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:38 --> URI Class Initialized
INFO - 2023-03-09 09:54:38 --> Router Class Initialized
INFO - 2023-03-09 09:54:38 --> Output Class Initialized
INFO - 2023-03-09 09:54:38 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:38 --> Input Class Initialized
INFO - 2023-03-09 09:54:38 --> Language Class Initialized
INFO - 2023-03-09 09:54:38 --> Loader Class Initialized
INFO - 2023-03-09 09:54:38 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:38 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:38 --> Model "Cluster_model" initialized
INFO - 2023-03-09 09:54:38 --> Final output sent to browser
DEBUG - 2023-03-09 09:54:38 --> Total execution time: 0.0606
INFO - 2023-03-09 09:54:38 --> Config Class Initialized
INFO - 2023-03-09 09:54:38 --> Hooks Class Initialized
DEBUG - 2023-03-09 09:54:38 --> UTF-8 Support Enabled
INFO - 2023-03-09 09:54:38 --> Utf8 Class Initialized
INFO - 2023-03-09 09:54:38 --> URI Class Initialized
INFO - 2023-03-09 09:54:38 --> Router Class Initialized
INFO - 2023-03-09 09:54:38 --> Output Class Initialized
INFO - 2023-03-09 09:54:38 --> Security Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 09:54:38 --> Input Class Initialized
INFO - 2023-03-09 09:54:38 --> Language Class Initialized
INFO - 2023-03-09 09:54:38 --> Loader Class Initialized
INFO - 2023-03-09 09:54:38 --> Controller Class Initialized
DEBUG - 2023-03-09 09:54:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 09:54:38 --> Database Driver Class Initialized
INFO - 2023-03-09 09:54:38 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:44 --> Config Class Initialized
INFO - 2023-03-09 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:44 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:44 --> URI Class Initialized
INFO - 2023-03-09 10:23:44 --> Router Class Initialized
INFO - 2023-03-09 10:23:44 --> Output Class Initialized
INFO - 2023-03-09 10:23:44 --> Security Class Initialized
DEBUG - 2023-03-09 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:44 --> Input Class Initialized
INFO - 2023-03-09 10:23:44 --> Language Class Initialized
INFO - 2023-03-09 10:23:44 --> Loader Class Initialized
INFO - 2023-03-09 10:23:44 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:44 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:44 --> Final output sent to browser
DEBUG - 2023-03-09 10:23:44 --> Total execution time: 0.0208
INFO - 2023-03-09 10:23:44 --> Config Class Initialized
INFO - 2023-03-09 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:44 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:44 --> URI Class Initialized
INFO - 2023-03-09 10:23:44 --> Router Class Initialized
INFO - 2023-03-09 10:23:44 --> Output Class Initialized
INFO - 2023-03-09 10:23:44 --> Security Class Initialized
DEBUG - 2023-03-09 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:44 --> Input Class Initialized
INFO - 2023-03-09 10:23:44 --> Language Class Initialized
INFO - 2023-03-09 10:23:44 --> Loader Class Initialized
INFO - 2023-03-09 10:23:44 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:44 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:44 --> Final output sent to browser
DEBUG - 2023-03-09 10:23:44 --> Total execution time: 0.0577
INFO - 2023-03-09 10:23:46 --> Config Class Initialized
INFO - 2023-03-09 10:23:46 --> Hooks Class Initialized
INFO - 2023-03-09 10:23:46 --> Config Class Initialized
INFO - 2023-03-09 10:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:46 --> Utf8 Class Initialized
DEBUG - 2023-03-09 10:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:46 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:46 --> URI Class Initialized
INFO - 2023-03-09 10:23:46 --> URI Class Initialized
INFO - 2023-03-09 10:23:46 --> Router Class Initialized
INFO - 2023-03-09 10:23:46 --> Output Class Initialized
INFO - 2023-03-09 10:23:46 --> Router Class Initialized
INFO - 2023-03-09 10:23:46 --> Security Class Initialized
INFO - 2023-03-09 10:23:46 --> Output Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:46 --> Security Class Initialized
INFO - 2023-03-09 10:23:46 --> Input Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:46 --> Language Class Initialized
INFO - 2023-03-09 10:23:46 --> Input Class Initialized
INFO - 2023-03-09 10:23:46 --> Language Class Initialized
INFO - 2023-03-09 10:23:46 --> Loader Class Initialized
INFO - 2023-03-09 10:23:46 --> Controller Class Initialized
INFO - 2023-03-09 10:23:46 --> Loader Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:46 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:46 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:46 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:46 --> Final output sent to browser
DEBUG - 2023-03-09 10:23:46 --> Total execution time: 0.0197
INFO - 2023-03-09 10:23:46 --> Config Class Initialized
INFO - 2023-03-09 10:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:46 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:46 --> URI Class Initialized
INFO - 2023-03-09 10:23:46 --> Router Class Initialized
INFO - 2023-03-09 10:23:46 --> Output Class Initialized
INFO - 2023-03-09 10:23:46 --> Security Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:46 --> Input Class Initialized
INFO - 2023-03-09 10:23:46 --> Language Class Initialized
INFO - 2023-03-09 10:23:46 --> Loader Class Initialized
INFO - 2023-03-09 10:23:46 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:46 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:46 --> Final output sent to browser
DEBUG - 2023-03-09 10:23:46 --> Total execution time: 0.0518
INFO - 2023-03-09 10:23:46 --> Config Class Initialized
INFO - 2023-03-09 10:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:46 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:46 --> URI Class Initialized
INFO - 2023-03-09 10:23:46 --> Router Class Initialized
INFO - 2023-03-09 10:23:46 --> Output Class Initialized
INFO - 2023-03-09 10:23:46 --> Security Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:46 --> Input Class Initialized
INFO - 2023-03-09 10:23:46 --> Language Class Initialized
INFO - 2023-03-09 10:23:46 --> Loader Class Initialized
INFO - 2023-03-09 10:23:46 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:46 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:46 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:48 --> Config Class Initialized
INFO - 2023-03-09 10:23:48 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:23:48 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:23:48 --> Utf8 Class Initialized
INFO - 2023-03-09 10:23:48 --> URI Class Initialized
INFO - 2023-03-09 10:23:48 --> Router Class Initialized
INFO - 2023-03-09 10:23:48 --> Output Class Initialized
INFO - 2023-03-09 10:23:48 --> Security Class Initialized
DEBUG - 2023-03-09 10:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:23:48 --> Input Class Initialized
INFO - 2023-03-09 10:23:48 --> Language Class Initialized
INFO - 2023-03-09 10:23:48 --> Loader Class Initialized
INFO - 2023-03-09 10:23:48 --> Controller Class Initialized
DEBUG - 2023-03-09 10:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:23:48 --> Database Driver Class Initialized
INFO - 2023-03-09 10:23:48 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:23:48 --> Final output sent to browser
DEBUG - 2023-03-09 10:23:48 --> Total execution time: 0.0691
INFO - 2023-03-09 10:24:42 --> Config Class Initialized
INFO - 2023-03-09 10:24:42 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:24:42 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:24:42 --> Utf8 Class Initialized
INFO - 2023-03-09 10:24:42 --> URI Class Initialized
INFO - 2023-03-09 10:24:42 --> Router Class Initialized
INFO - 2023-03-09 10:24:42 --> Output Class Initialized
INFO - 2023-03-09 10:24:42 --> Security Class Initialized
DEBUG - 2023-03-09 10:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:24:42 --> Input Class Initialized
INFO - 2023-03-09 10:24:42 --> Language Class Initialized
INFO - 2023-03-09 10:24:42 --> Loader Class Initialized
INFO - 2023-03-09 10:24:42 --> Controller Class Initialized
DEBUG - 2023-03-09 10:24:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:24:42 --> Final output sent to browser
DEBUG - 2023-03-09 10:24:42 --> Total execution time: 0.0043
INFO - 2023-03-09 10:24:42 --> Config Class Initialized
INFO - 2023-03-09 10:24:42 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:24:42 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:24:42 --> Utf8 Class Initialized
INFO - 2023-03-09 10:24:42 --> URI Class Initialized
INFO - 2023-03-09 10:24:42 --> Router Class Initialized
INFO - 2023-03-09 10:24:42 --> Output Class Initialized
INFO - 2023-03-09 10:24:42 --> Security Class Initialized
DEBUG - 2023-03-09 10:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:24:42 --> Input Class Initialized
INFO - 2023-03-09 10:24:42 --> Language Class Initialized
INFO - 2023-03-09 10:24:42 --> Loader Class Initialized
INFO - 2023-03-09 10:24:42 --> Controller Class Initialized
DEBUG - 2023-03-09 10:24:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:24:42 --> Database Driver Class Initialized
INFO - 2023-03-09 10:24:42 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:24:42 --> Final output sent to browser
DEBUG - 2023-03-09 10:24:42 --> Total execution time: 0.0104
INFO - 2023-03-09 10:24:47 --> Config Class Initialized
INFO - 2023-03-09 10:24:47 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:24:47 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:24:47 --> Utf8 Class Initialized
INFO - 2023-03-09 10:24:47 --> URI Class Initialized
INFO - 2023-03-09 10:24:47 --> Router Class Initialized
INFO - 2023-03-09 10:24:47 --> Output Class Initialized
INFO - 2023-03-09 10:24:47 --> Security Class Initialized
DEBUG - 2023-03-09 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:24:47 --> Input Class Initialized
INFO - 2023-03-09 10:24:47 --> Language Class Initialized
INFO - 2023-03-09 10:24:47 --> Loader Class Initialized
INFO - 2023-03-09 10:24:47 --> Controller Class Initialized
DEBUG - 2023-03-09 10:24:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:24:47 --> Final output sent to browser
DEBUG - 2023-03-09 10:24:47 --> Total execution time: 0.0045
INFO - 2023-03-09 10:24:47 --> Config Class Initialized
INFO - 2023-03-09 10:24:47 --> Hooks Class Initialized
DEBUG - 2023-03-09 10:24:47 --> UTF-8 Support Enabled
INFO - 2023-03-09 10:24:47 --> Utf8 Class Initialized
INFO - 2023-03-09 10:24:47 --> URI Class Initialized
INFO - 2023-03-09 10:24:47 --> Router Class Initialized
INFO - 2023-03-09 10:24:47 --> Output Class Initialized
INFO - 2023-03-09 10:24:47 --> Security Class Initialized
DEBUG - 2023-03-09 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 10:24:47 --> Input Class Initialized
INFO - 2023-03-09 10:24:47 --> Language Class Initialized
INFO - 2023-03-09 10:24:47 --> Loader Class Initialized
INFO - 2023-03-09 10:24:47 --> Controller Class Initialized
DEBUG - 2023-03-09 10:24:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 10:24:47 --> Database Driver Class Initialized
INFO - 2023-03-09 10:24:47 --> Model "Cluster_model" initialized
INFO - 2023-03-09 10:24:47 --> Final output sent to browser
DEBUG - 2023-03-09 10:24:47 --> Total execution time: 0.0106
INFO - 2023-03-09 15:00:17 --> Config Class Initialized
INFO - 2023-03-09 15:00:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:17 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:17 --> URI Class Initialized
INFO - 2023-03-09 15:00:17 --> Router Class Initialized
INFO - 2023-03-09 15:00:17 --> Output Class Initialized
INFO - 2023-03-09 15:00:17 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:17 --> Input Class Initialized
INFO - 2023-03-09 15:00:17 --> Language Class Initialized
INFO - 2023-03-09 15:00:17 --> Loader Class Initialized
INFO - 2023-03-09 15:00:17 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:17 --> Final output sent to browser
DEBUG - 2023-03-09 15:00:17 --> Total execution time: 0.0071
INFO - 2023-03-09 15:00:17 --> Config Class Initialized
INFO - 2023-03-09 15:00:17 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:17 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:17 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:17 --> URI Class Initialized
INFO - 2023-03-09 15:00:17 --> Router Class Initialized
INFO - 2023-03-09 15:00:17 --> Output Class Initialized
INFO - 2023-03-09 15:00:17 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:17 --> Input Class Initialized
INFO - 2023-03-09 15:00:17 --> Language Class Initialized
INFO - 2023-03-09 15:00:17 --> Loader Class Initialized
INFO - 2023-03-09 15:00:17 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:17 --> Database Driver Class Initialized
INFO - 2023-03-09 15:00:20 --> Config Class Initialized
INFO - 2023-03-09 15:00:20 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:20 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:20 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:20 --> URI Class Initialized
INFO - 2023-03-09 15:00:20 --> Router Class Initialized
INFO - 2023-03-09 15:00:20 --> Output Class Initialized
INFO - 2023-03-09 15:00:20 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:20 --> Input Class Initialized
INFO - 2023-03-09 15:00:20 --> Language Class Initialized
INFO - 2023-03-09 15:00:20 --> Loader Class Initialized
INFO - 2023-03-09 15:00:20 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:20 --> Database Driver Class Initialized
INFO - 2023-03-09 15:00:21 --> Config Class Initialized
INFO - 2023-03-09 15:00:21 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:21 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:21 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:21 --> URI Class Initialized
INFO - 2023-03-09 15:00:21 --> Router Class Initialized
INFO - 2023-03-09 15:00:21 --> Output Class Initialized
INFO - 2023-03-09 15:00:21 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:21 --> Input Class Initialized
INFO - 2023-03-09 15:00:21 --> Language Class Initialized
INFO - 2023-03-09 15:00:21 --> Loader Class Initialized
INFO - 2023-03-09 15:00:21 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:21 --> Final output sent to browser
DEBUG - 2023-03-09 15:00:21 --> Total execution time: 0.0023
INFO - 2023-03-09 15:00:21 --> Config Class Initialized
INFO - 2023-03-09 15:00:21 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:21 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:21 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:21 --> URI Class Initialized
INFO - 2023-03-09 15:00:21 --> Router Class Initialized
INFO - 2023-03-09 15:00:21 --> Output Class Initialized
INFO - 2023-03-09 15:00:21 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:21 --> Input Class Initialized
INFO - 2023-03-09 15:00:21 --> Language Class Initialized
INFO - 2023-03-09 15:00:21 --> Loader Class Initialized
INFO - 2023-03-09 15:00:21 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:21 --> Database Driver Class Initialized
INFO - 2023-03-09 15:00:22 --> Config Class Initialized
INFO - 2023-03-09 15:00:22 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:22 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:22 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:22 --> URI Class Initialized
INFO - 2023-03-09 15:00:22 --> Router Class Initialized
INFO - 2023-03-09 15:00:22 --> Output Class Initialized
INFO - 2023-03-09 15:00:22 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:22 --> Input Class Initialized
INFO - 2023-03-09 15:00:22 --> Language Class Initialized
INFO - 2023-03-09 15:00:22 --> Loader Class Initialized
INFO - 2023-03-09 15:00:22 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:22 --> Database Driver Class Initialized
INFO - 2023-03-09 15:00:26 --> Config Class Initialized
INFO - 2023-03-09 15:00:26 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:26 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:26 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:26 --> URI Class Initialized
INFO - 2023-03-09 15:00:26 --> Router Class Initialized
INFO - 2023-03-09 15:00:26 --> Output Class Initialized
INFO - 2023-03-09 15:00:26 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:26 --> Input Class Initialized
INFO - 2023-03-09 15:00:26 --> Language Class Initialized
INFO - 2023-03-09 15:00:26 --> Loader Class Initialized
INFO - 2023-03-09 15:00:26 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:26 --> Database Driver Class Initialized
ERROR - 2023-03-09 15:00:27 --> Unable to connect to the database
INFO - 2023-03-09 15:00:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-09 15:00:27 --> Config Class Initialized
INFO - 2023-03-09 15:00:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:27 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:27 --> URI Class Initialized
INFO - 2023-03-09 15:00:27 --> Router Class Initialized
INFO - 2023-03-09 15:00:27 --> Output Class Initialized
INFO - 2023-03-09 15:00:27 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:27 --> Input Class Initialized
INFO - 2023-03-09 15:00:27 --> Language Class Initialized
INFO - 2023-03-09 15:00:27 --> Loader Class Initialized
INFO - 2023-03-09 15:00:27 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:27 --> Final output sent to browser
DEBUG - 2023-03-09 15:00:27 --> Total execution time: 0.0055
INFO - 2023-03-09 15:00:27 --> Config Class Initialized
INFO - 2023-03-09 15:00:27 --> Hooks Class Initialized
DEBUG - 2023-03-09 15:00:27 --> UTF-8 Support Enabled
INFO - 2023-03-09 15:00:27 --> Utf8 Class Initialized
INFO - 2023-03-09 15:00:27 --> URI Class Initialized
INFO - 2023-03-09 15:00:27 --> Router Class Initialized
INFO - 2023-03-09 15:00:27 --> Output Class Initialized
INFO - 2023-03-09 15:00:27 --> Security Class Initialized
DEBUG - 2023-03-09 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-09 15:00:27 --> Input Class Initialized
INFO - 2023-03-09 15:00:27 --> Language Class Initialized
INFO - 2023-03-09 15:00:27 --> Loader Class Initialized
INFO - 2023-03-09 15:00:27 --> Controller Class Initialized
DEBUG - 2023-03-09 15:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-09 15:00:27 --> Database Driver Class Initialized
ERROR - 2023-03-09 15:00:30 --> Unable to connect to the database
INFO - 2023-03-09 15:00:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-09 15:00:31 --> Unable to connect to the database
INFO - 2023-03-09 15:00:31 --> Model "Login_model" initialized
ERROR - 2023-03-09 15:00:32 --> Unable to connect to the database
INFO - 2023-03-09 15:00:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-09 15:00:36 --> Unable to connect to the database
INFO - 2023-03-09 15:00:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-09 15:00:37 --> Unable to connect to the database
INFO - 2023-03-09 15:00:37 --> Model "Login_model" initialized
ERROR - 2023-03-09 15:00:41 --> Unable to connect to the database
ERROR - 2023-03-09 15:00:41 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-03-09 15:00:41 --> Final output sent to browser
DEBUG - 2023-03-09 15:00:41 --> Total execution time: 20.0068
ERROR - 2023-03-09 15:00:47 --> Unable to connect to the database
ERROR - 2023-03-09 15:00:47 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-03-09 15:00:47 --> Final output sent to browser
DEBUG - 2023-03-09 15:00:47 --> Total execution time: 20.0472
