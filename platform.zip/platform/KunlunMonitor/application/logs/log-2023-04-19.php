<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-19 06:34:41 --> Config Class Initialized
INFO - 2023-04-19 06:34:41 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:41 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:41 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:41 --> URI Class Initialized
INFO - 2023-04-19 06:34:41 --> Router Class Initialized
INFO - 2023-04-19 06:34:41 --> Output Class Initialized
INFO - 2023-04-19 06:34:41 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
INFO - 2023-04-19 06:34:42 --> Helper loaded: form_helper
INFO - 2023-04-19 06:34:42 --> Helper loaded: url_helper
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Model "Change_model" initialized
INFO - 2023-04-19 06:34:42 --> Model "Grafana_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.0606
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
INFO - 2023-04-19 06:34:42 --> Helper loaded: form_helper
INFO - 2023-04-19 06:34:42 --> Helper loaded: url_helper
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.0478
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
INFO - 2023-04-19 06:34:42 --> Helper loaded: form_helper
INFO - 2023-04-19 06:34:42 --> Helper loaded: url_helper
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Login_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.0199
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.0546
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.0168
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Login_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.1035
INFO - 2023-04-19 06:34:42 --> Config Class Initialized
INFO - 2023-04-19 06:34:42 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:42 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:42 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:42 --> URI Class Initialized
INFO - 2023-04-19 06:34:42 --> Router Class Initialized
INFO - 2023-04-19 06:34:42 --> Output Class Initialized
INFO - 2023-04-19 06:34:42 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:42 --> Input Class Initialized
INFO - 2023-04-19 06:34:42 --> Language Class Initialized
INFO - 2023-04-19 06:34:42 --> Loader Class Initialized
INFO - 2023-04-19 06:34:42 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:42 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:42 --> Model "Login_model" initialized
INFO - 2023-04-19 06:34:42 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:42 --> Total execution time: 0.1062
INFO - 2023-04-19 06:34:44 --> Config Class Initialized
INFO - 2023-04-19 06:34:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:44 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:44 --> URI Class Initialized
INFO - 2023-04-19 06:34:44 --> Router Class Initialized
INFO - 2023-04-19 06:34:44 --> Output Class Initialized
INFO - 2023-04-19 06:34:44 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:44 --> Input Class Initialized
INFO - 2023-04-19 06:34:44 --> Language Class Initialized
INFO - 2023-04-19 06:34:44 --> Loader Class Initialized
INFO - 2023-04-19 06:34:44 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:44 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:44 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:44 --> Total execution time: 0.0156
INFO - 2023-04-19 06:34:44 --> Config Class Initialized
INFO - 2023-04-19 06:34:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:44 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:44 --> URI Class Initialized
INFO - 2023-04-19 06:34:44 --> Router Class Initialized
INFO - 2023-04-19 06:34:44 --> Output Class Initialized
INFO - 2023-04-19 06:34:44 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:44 --> Input Class Initialized
INFO - 2023-04-19 06:34:44 --> Language Class Initialized
INFO - 2023-04-19 06:34:44 --> Loader Class Initialized
INFO - 2023-04-19 06:34:44 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:44 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:44 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:44 --> Total execution time: 0.0503
INFO - 2023-04-19 06:34:44 --> Config Class Initialized
INFO - 2023-04-19 06:34:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:44 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:44 --> URI Class Initialized
INFO - 2023-04-19 06:34:44 --> Router Class Initialized
INFO - 2023-04-19 06:34:44 --> Output Class Initialized
INFO - 2023-04-19 06:34:44 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:44 --> Input Class Initialized
INFO - 2023-04-19 06:34:44 --> Language Class Initialized
INFO - 2023-04-19 06:34:44 --> Loader Class Initialized
INFO - 2023-04-19 06:34:44 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:44 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:44 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:44 --> Total execution time: 0.0525
INFO - 2023-04-19 06:34:44 --> Config Class Initialized
INFO - 2023-04-19 06:34:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:34:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:34:44 --> Utf8 Class Initialized
INFO - 2023-04-19 06:34:44 --> URI Class Initialized
INFO - 2023-04-19 06:34:44 --> Router Class Initialized
INFO - 2023-04-19 06:34:44 --> Output Class Initialized
INFO - 2023-04-19 06:34:44 --> Security Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:34:44 --> Input Class Initialized
INFO - 2023-04-19 06:34:44 --> Language Class Initialized
INFO - 2023-04-19 06:34:44 --> Loader Class Initialized
INFO - 2023-04-19 06:34:44 --> Controller Class Initialized
DEBUG - 2023-04-19 06:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:34:44 --> Database Driver Class Initialized
INFO - 2023-04-19 06:34:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:34:44 --> Final output sent to browser
DEBUG - 2023-04-19 06:34:44 --> Total execution time: 0.0522
INFO - 2023-04-19 06:50:25 --> Config Class Initialized
INFO - 2023-04-19 06:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:50:25 --> Utf8 Class Initialized
INFO - 2023-04-19 06:50:25 --> URI Class Initialized
INFO - 2023-04-19 06:50:25 --> Router Class Initialized
INFO - 2023-04-19 06:50:25 --> Output Class Initialized
INFO - 2023-04-19 06:50:25 --> Security Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:50:25 --> Input Class Initialized
INFO - 2023-04-19 06:50:25 --> Language Class Initialized
INFO - 2023-04-19 06:50:25 --> Loader Class Initialized
INFO - 2023-04-19 06:50:25 --> Controller Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:50:25 --> Database Driver Class Initialized
INFO - 2023-04-19 06:50:25 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:50:25 --> Final output sent to browser
DEBUG - 2023-04-19 06:50:25 --> Total execution time: 0.0117
INFO - 2023-04-19 06:50:25 --> Config Class Initialized
INFO - 2023-04-19 06:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:50:25 --> Utf8 Class Initialized
INFO - 2023-04-19 06:50:25 --> URI Class Initialized
INFO - 2023-04-19 06:50:25 --> Router Class Initialized
INFO - 2023-04-19 06:50:25 --> Output Class Initialized
INFO - 2023-04-19 06:50:25 --> Security Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:50:25 --> Input Class Initialized
INFO - 2023-04-19 06:50:25 --> Language Class Initialized
INFO - 2023-04-19 06:50:25 --> Loader Class Initialized
INFO - 2023-04-19 06:50:25 --> Controller Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:50:25 --> Database Driver Class Initialized
INFO - 2023-04-19 06:50:25 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:50:25 --> Final output sent to browser
DEBUG - 2023-04-19 06:50:25 --> Total execution time: 0.0517
INFO - 2023-04-19 06:50:25 --> Config Class Initialized
INFO - 2023-04-19 06:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:50:25 --> Utf8 Class Initialized
INFO - 2023-04-19 06:50:25 --> URI Class Initialized
INFO - 2023-04-19 06:50:25 --> Router Class Initialized
INFO - 2023-04-19 06:50:25 --> Output Class Initialized
INFO - 2023-04-19 06:50:25 --> Security Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:50:25 --> Input Class Initialized
INFO - 2023-04-19 06:50:25 --> Language Class Initialized
INFO - 2023-04-19 06:50:25 --> Loader Class Initialized
INFO - 2023-04-19 06:50:25 --> Controller Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:50:25 --> Database Driver Class Initialized
INFO - 2023-04-19 06:50:25 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:50:25 --> Final output sent to browser
DEBUG - 2023-04-19 06:50:25 --> Total execution time: 0.0524
INFO - 2023-04-19 06:50:25 --> Config Class Initialized
INFO - 2023-04-19 06:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-19 06:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-19 06:50:25 --> Utf8 Class Initialized
INFO - 2023-04-19 06:50:25 --> URI Class Initialized
INFO - 2023-04-19 06:50:25 --> Router Class Initialized
INFO - 2023-04-19 06:50:25 --> Output Class Initialized
INFO - 2023-04-19 06:50:25 --> Security Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 06:50:25 --> Input Class Initialized
INFO - 2023-04-19 06:50:25 --> Language Class Initialized
INFO - 2023-04-19 06:50:25 --> Loader Class Initialized
INFO - 2023-04-19 06:50:25 --> Controller Class Initialized
DEBUG - 2023-04-19 06:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 06:50:25 --> Database Driver Class Initialized
INFO - 2023-04-19 06:50:25 --> Model "Cluster_model" initialized
INFO - 2023-04-19 06:50:25 --> Final output sent to browser
DEBUG - 2023-04-19 06:50:25 --> Total execution time: 0.0505
INFO - 2023-04-19 07:15:45 --> Config Class Initialized
INFO - 2023-04-19 07:15:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:15:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:15:45 --> Utf8 Class Initialized
INFO - 2023-04-19 07:15:45 --> URI Class Initialized
INFO - 2023-04-19 07:15:45 --> Router Class Initialized
INFO - 2023-04-19 07:15:45 --> Output Class Initialized
INFO - 2023-04-19 07:15:45 --> Security Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:15:45 --> Input Class Initialized
INFO - 2023-04-19 07:15:45 --> Language Class Initialized
INFO - 2023-04-19 07:15:45 --> Loader Class Initialized
INFO - 2023-04-19 07:15:45 --> Controller Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:15:45 --> Database Driver Class Initialized
INFO - 2023-04-19 07:15:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:15:45 --> Final output sent to browser
DEBUG - 2023-04-19 07:15:45 --> Total execution time: 0.0148
INFO - 2023-04-19 07:15:45 --> Config Class Initialized
INFO - 2023-04-19 07:15:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:15:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:15:45 --> Utf8 Class Initialized
INFO - 2023-04-19 07:15:45 --> URI Class Initialized
INFO - 2023-04-19 07:15:45 --> Router Class Initialized
INFO - 2023-04-19 07:15:45 --> Output Class Initialized
INFO - 2023-04-19 07:15:45 --> Security Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:15:45 --> Input Class Initialized
INFO - 2023-04-19 07:15:45 --> Language Class Initialized
INFO - 2023-04-19 07:15:45 --> Loader Class Initialized
INFO - 2023-04-19 07:15:45 --> Controller Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:15:45 --> Database Driver Class Initialized
INFO - 2023-04-19 07:15:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:15:45 --> Final output sent to browser
DEBUG - 2023-04-19 07:15:45 --> Total execution time: 0.0552
INFO - 2023-04-19 07:15:45 --> Config Class Initialized
INFO - 2023-04-19 07:15:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:15:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:15:45 --> Utf8 Class Initialized
INFO - 2023-04-19 07:15:45 --> URI Class Initialized
INFO - 2023-04-19 07:15:45 --> Router Class Initialized
INFO - 2023-04-19 07:15:45 --> Output Class Initialized
INFO - 2023-04-19 07:15:45 --> Security Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:15:45 --> Input Class Initialized
INFO - 2023-04-19 07:15:45 --> Language Class Initialized
INFO - 2023-04-19 07:15:45 --> Loader Class Initialized
INFO - 2023-04-19 07:15:45 --> Controller Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:15:45 --> Database Driver Class Initialized
INFO - 2023-04-19 07:15:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:15:45 --> Final output sent to browser
DEBUG - 2023-04-19 07:15:45 --> Total execution time: 0.0557
INFO - 2023-04-19 07:15:45 --> Config Class Initialized
INFO - 2023-04-19 07:15:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:15:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:15:45 --> Utf8 Class Initialized
INFO - 2023-04-19 07:15:45 --> URI Class Initialized
INFO - 2023-04-19 07:15:45 --> Router Class Initialized
INFO - 2023-04-19 07:15:45 --> Output Class Initialized
INFO - 2023-04-19 07:15:45 --> Security Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:15:45 --> Input Class Initialized
INFO - 2023-04-19 07:15:45 --> Language Class Initialized
INFO - 2023-04-19 07:15:45 --> Loader Class Initialized
INFO - 2023-04-19 07:15:45 --> Controller Class Initialized
DEBUG - 2023-04-19 07:15:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:15:45 --> Database Driver Class Initialized
INFO - 2023-04-19 07:15:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:15:45 --> Final output sent to browser
DEBUG - 2023-04-19 07:15:45 --> Total execution time: 0.0510
INFO - 2023-04-19 07:16:10 --> Config Class Initialized
INFO - 2023-04-19 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:10 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:10 --> URI Class Initialized
INFO - 2023-04-19 07:16:10 --> Router Class Initialized
INFO - 2023-04-19 07:16:10 --> Output Class Initialized
INFO - 2023-04-19 07:16:10 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:10 --> Input Class Initialized
INFO - 2023-04-19 07:16:10 --> Language Class Initialized
INFO - 2023-04-19 07:16:10 --> Loader Class Initialized
INFO - 2023-04-19 07:16:10 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:10 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:10 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:10 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:10 --> Total execution time: 0.1116
INFO - 2023-04-19 07:16:10 --> Config Class Initialized
INFO - 2023-04-19 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:10 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:10 --> URI Class Initialized
INFO - 2023-04-19 07:16:10 --> Router Class Initialized
INFO - 2023-04-19 07:16:10 --> Output Class Initialized
INFO - 2023-04-19 07:16:10 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:10 --> Input Class Initialized
INFO - 2023-04-19 07:16:10 --> Language Class Initialized
INFO - 2023-04-19 07:16:10 --> Loader Class Initialized
INFO - 2023-04-19 07:16:10 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:10 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:10 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:10 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:10 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:10 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:10 --> Total execution time: 0.2804
INFO - 2023-04-19 07:16:10 --> Config Class Initialized
INFO - 2023-04-19 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:10 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:10 --> URI Class Initialized
INFO - 2023-04-19 07:16:10 --> Router Class Initialized
INFO - 2023-04-19 07:16:10 --> Output Class Initialized
INFO - 2023-04-19 07:16:10 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:10 --> Input Class Initialized
INFO - 2023-04-19 07:16:10 --> Language Class Initialized
INFO - 2023-04-19 07:16:10 --> Loader Class Initialized
INFO - 2023-04-19 07:16:10 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:10 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:10 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:10 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:10 --> Total execution time: 0.2198
INFO - 2023-04-19 07:16:10 --> Config Class Initialized
INFO - 2023-04-19 07:16:10 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:10 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:10 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:10 --> URI Class Initialized
INFO - 2023-04-19 07:16:10 --> Router Class Initialized
INFO - 2023-04-19 07:16:10 --> Output Class Initialized
INFO - 2023-04-19 07:16:10 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:10 --> Input Class Initialized
INFO - 2023-04-19 07:16:10 --> Language Class Initialized
INFO - 2023-04-19 07:16:10 --> Loader Class Initialized
INFO - 2023-04-19 07:16:10 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:10 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:11 --> Config Class Initialized
INFO - 2023-04-19 07:16:11 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:11 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:11 --> URI Class Initialized
INFO - 2023-04-19 07:16:11 --> Router Class Initialized
INFO - 2023-04-19 07:16:11 --> Output Class Initialized
INFO - 2023-04-19 07:16:11 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:11 --> Input Class Initialized
INFO - 2023-04-19 07:16:11 --> Language Class Initialized
INFO - 2023-04-19 07:16:11 --> Loader Class Initialized
INFO - 2023-04-19 07:16:11 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:11 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:11 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:11 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:11 --> Total execution time: 0.2475
INFO - 2023-04-19 07:16:11 --> Config Class Initialized
INFO - 2023-04-19 07:16:11 --> Hooks Class Initialized
INFO - 2023-04-19 07:16:11 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 07:16:11 --> Total execution time: 0.4281
INFO - 2023-04-19 07:16:11 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:11 --> URI Class Initialized
INFO - 2023-04-19 07:16:11 --> Router Class Initialized
INFO - 2023-04-19 07:16:11 --> Output Class Initialized
INFO - 2023-04-19 07:16:11 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:11 --> Input Class Initialized
INFO - 2023-04-19 07:16:11 --> Language Class Initialized
INFO - 2023-04-19 07:16:11 --> Loader Class Initialized
INFO - 2023-04-19 07:16:11 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:11 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:11 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:11 --> Total execution time: 0.2429
INFO - 2023-04-19 07:16:12 --> Config Class Initialized
INFO - 2023-04-19 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:12 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:12 --> URI Class Initialized
INFO - 2023-04-19 07:16:12 --> Router Class Initialized
INFO - 2023-04-19 07:16:12 --> Output Class Initialized
INFO - 2023-04-19 07:16:12 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:12 --> Input Class Initialized
INFO - 2023-04-19 07:16:12 --> Language Class Initialized
INFO - 2023-04-19 07:16:12 --> Loader Class Initialized
INFO - 2023-04-19 07:16:12 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:12 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:12 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:12 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:12 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:12 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:12 --> Total execution time: 0.0231
INFO - 2023-04-19 07:16:12 --> Config Class Initialized
INFO - 2023-04-19 07:16:12 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:12 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:12 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:12 --> URI Class Initialized
INFO - 2023-04-19 07:16:12 --> Router Class Initialized
INFO - 2023-04-19 07:16:12 --> Output Class Initialized
INFO - 2023-04-19 07:16:12 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:12 --> Input Class Initialized
INFO - 2023-04-19 07:16:12 --> Language Class Initialized
INFO - 2023-04-19 07:16:12 --> Loader Class Initialized
INFO - 2023-04-19 07:16:12 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:12 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:12 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:12 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:12 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:12 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:12 --> Total execution time: 0.0254
INFO - 2023-04-19 07:16:17 --> Config Class Initialized
INFO - 2023-04-19 07:16:17 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:17 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:17 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:17 --> URI Class Initialized
INFO - 2023-04-19 07:16:17 --> Router Class Initialized
INFO - 2023-04-19 07:16:17 --> Output Class Initialized
INFO - 2023-04-19 07:16:17 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:17 --> Input Class Initialized
INFO - 2023-04-19 07:16:17 --> Language Class Initialized
INFO - 2023-04-19 07:16:17 --> Loader Class Initialized
INFO - 2023-04-19 07:16:17 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:17 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:17 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:17 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:17 --> Total execution time: 0.0113
INFO - 2023-04-19 07:16:17 --> Config Class Initialized
INFO - 2023-04-19 07:16:17 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:17 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:17 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:17 --> URI Class Initialized
INFO - 2023-04-19 07:16:17 --> Router Class Initialized
INFO - 2023-04-19 07:16:17 --> Output Class Initialized
INFO - 2023-04-19 07:16:17 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:17 --> Input Class Initialized
INFO - 2023-04-19 07:16:17 --> Language Class Initialized
INFO - 2023-04-19 07:16:17 --> Loader Class Initialized
INFO - 2023-04-19 07:16:17 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:17 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:17 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:17 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:17 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:17 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:17 --> Total execution time: 0.0339
INFO - 2023-04-19 07:16:33 --> Config Class Initialized
INFO - 2023-04-19 07:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:33 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:33 --> URI Class Initialized
INFO - 2023-04-19 07:16:33 --> Router Class Initialized
INFO - 2023-04-19 07:16:33 --> Output Class Initialized
INFO - 2023-04-19 07:16:33 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:33 --> Input Class Initialized
INFO - 2023-04-19 07:16:33 --> Language Class Initialized
INFO - 2023-04-19 07:16:33 --> Loader Class Initialized
INFO - 2023-04-19 07:16:33 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:33 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:33 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:33 --> Total execution time: 0.0561
INFO - 2023-04-19 07:16:33 --> Config Class Initialized
INFO - 2023-04-19 07:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:33 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:33 --> URI Class Initialized
INFO - 2023-04-19 07:16:33 --> Router Class Initialized
INFO - 2023-04-19 07:16:33 --> Output Class Initialized
INFO - 2023-04-19 07:16:33 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:33 --> Input Class Initialized
INFO - 2023-04-19 07:16:33 --> Language Class Initialized
INFO - 2023-04-19 07:16:33 --> Loader Class Initialized
INFO - 2023-04-19 07:16:33 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:33 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:33 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:33 --> Total execution time: 0.0915
INFO - 2023-04-19 07:16:54 --> Config Class Initialized
INFO - 2023-04-19 07:16:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:54 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:54 --> URI Class Initialized
INFO - 2023-04-19 07:16:54 --> Router Class Initialized
INFO - 2023-04-19 07:16:54 --> Output Class Initialized
INFO - 2023-04-19 07:16:54 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:54 --> Input Class Initialized
INFO - 2023-04-19 07:16:54 --> Language Class Initialized
INFO - 2023-04-19 07:16:54 --> Loader Class Initialized
INFO - 2023-04-19 07:16:54 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:54 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:54 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:54 --> Total execution time: 0.0552
INFO - 2023-04-19 07:16:54 --> Config Class Initialized
INFO - 2023-04-19 07:16:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:16:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:16:54 --> Utf8 Class Initialized
INFO - 2023-04-19 07:16:54 --> URI Class Initialized
INFO - 2023-04-19 07:16:54 --> Router Class Initialized
INFO - 2023-04-19 07:16:54 --> Output Class Initialized
INFO - 2023-04-19 07:16:54 --> Security Class Initialized
DEBUG - 2023-04-19 07:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:16:54 --> Input Class Initialized
INFO - 2023-04-19 07:16:54 --> Language Class Initialized
INFO - 2023-04-19 07:16:54 --> Loader Class Initialized
INFO - 2023-04-19 07:16:54 --> Controller Class Initialized
DEBUG - 2023-04-19 07:16:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:16:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:16:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:16:54 --> Model "Login_model" initialized
INFO - 2023-04-19 07:16:54 --> Final output sent to browser
DEBUG - 2023-04-19 07:16:54 --> Total execution time: 0.0429
INFO - 2023-04-19 07:17:13 --> Config Class Initialized
INFO - 2023-04-19 07:17:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:13 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:13 --> URI Class Initialized
INFO - 2023-04-19 07:17:13 --> Router Class Initialized
INFO - 2023-04-19 07:17:13 --> Output Class Initialized
INFO - 2023-04-19 07:17:13 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:13 --> Input Class Initialized
INFO - 2023-04-19 07:17:13 --> Language Class Initialized
INFO - 2023-04-19 07:17:13 --> Loader Class Initialized
INFO - 2023-04-19 07:17:13 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:13 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:13 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:13 --> Total execution time: 0.0558
INFO - 2023-04-19 07:17:13 --> Config Class Initialized
INFO - 2023-04-19 07:17:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:13 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:13 --> URI Class Initialized
INFO - 2023-04-19 07:17:13 --> Router Class Initialized
INFO - 2023-04-19 07:17:13 --> Output Class Initialized
INFO - 2023-04-19 07:17:13 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:13 --> Input Class Initialized
INFO - 2023-04-19 07:17:13 --> Language Class Initialized
INFO - 2023-04-19 07:17:13 --> Loader Class Initialized
INFO - 2023-04-19 07:17:13 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:13 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:13 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:13 --> Total execution time: 0.0439
INFO - 2023-04-19 07:17:33 --> Config Class Initialized
INFO - 2023-04-19 07:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:33 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:33 --> URI Class Initialized
INFO - 2023-04-19 07:17:33 --> Router Class Initialized
INFO - 2023-04-19 07:17:33 --> Output Class Initialized
INFO - 2023-04-19 07:17:33 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:33 --> Input Class Initialized
INFO - 2023-04-19 07:17:33 --> Language Class Initialized
INFO - 2023-04-19 07:17:33 --> Loader Class Initialized
INFO - 2023-04-19 07:17:33 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:33 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:33 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:33 --> Total execution time: 0.2038
INFO - 2023-04-19 07:17:33 --> Config Class Initialized
INFO - 2023-04-19 07:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:33 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:33 --> URI Class Initialized
INFO - 2023-04-19 07:17:33 --> Router Class Initialized
INFO - 2023-04-19 07:17:33 --> Output Class Initialized
INFO - 2023-04-19 07:17:33 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:33 --> Input Class Initialized
INFO - 2023-04-19 07:17:33 --> Language Class Initialized
INFO - 2023-04-19 07:17:33 --> Loader Class Initialized
INFO - 2023-04-19 07:17:33 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:33 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:33 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:34 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:34 --> Total execution time: 0.0409
INFO - 2023-04-19 07:17:54 --> Config Class Initialized
INFO - 2023-04-19 07:17:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:54 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:54 --> URI Class Initialized
INFO - 2023-04-19 07:17:54 --> Router Class Initialized
INFO - 2023-04-19 07:17:54 --> Output Class Initialized
INFO - 2023-04-19 07:17:54 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:54 --> Input Class Initialized
INFO - 2023-04-19 07:17:54 --> Language Class Initialized
INFO - 2023-04-19 07:17:54 --> Loader Class Initialized
INFO - 2023-04-19 07:17:54 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:54 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:54 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:54 --> Total execution time: 0.0727
INFO - 2023-04-19 07:17:54 --> Config Class Initialized
INFO - 2023-04-19 07:17:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:17:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:17:54 --> Utf8 Class Initialized
INFO - 2023-04-19 07:17:54 --> URI Class Initialized
INFO - 2023-04-19 07:17:54 --> Router Class Initialized
INFO - 2023-04-19 07:17:54 --> Output Class Initialized
INFO - 2023-04-19 07:17:54 --> Security Class Initialized
DEBUG - 2023-04-19 07:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:17:54 --> Input Class Initialized
INFO - 2023-04-19 07:17:54 --> Language Class Initialized
INFO - 2023-04-19 07:17:54 --> Loader Class Initialized
INFO - 2023-04-19 07:17:54 --> Controller Class Initialized
DEBUG - 2023-04-19 07:17:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:17:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:17:54 --> Database Driver Class Initialized
INFO - 2023-04-19 07:17:54 --> Model "Login_model" initialized
INFO - 2023-04-19 07:17:54 --> Final output sent to browser
DEBUG - 2023-04-19 07:17:54 --> Total execution time: 0.0482
INFO - 2023-04-19 07:18:13 --> Config Class Initialized
INFO - 2023-04-19 07:18:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:13 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:13 --> URI Class Initialized
INFO - 2023-04-19 07:18:13 --> Router Class Initialized
INFO - 2023-04-19 07:18:13 --> Output Class Initialized
INFO - 2023-04-19 07:18:13 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:13 --> Input Class Initialized
INFO - 2023-04-19 07:18:13 --> Language Class Initialized
INFO - 2023-04-19 07:18:13 --> Loader Class Initialized
INFO - 2023-04-19 07:18:13 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:13 --> Model "Login_model" initialized
INFO - 2023-04-19 07:18:13 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:13 --> Total execution time: 0.0579
INFO - 2023-04-19 07:18:13 --> Config Class Initialized
INFO - 2023-04-19 07:18:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:13 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:13 --> URI Class Initialized
INFO - 2023-04-19 07:18:13 --> Router Class Initialized
INFO - 2023-04-19 07:18:13 --> Output Class Initialized
INFO - 2023-04-19 07:18:13 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:13 --> Input Class Initialized
INFO - 2023-04-19 07:18:13 --> Language Class Initialized
INFO - 2023-04-19 07:18:13 --> Loader Class Initialized
INFO - 2023-04-19 07:18:13 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:13 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:13 --> Model "Login_model" initialized
INFO - 2023-04-19 07:18:13 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:13 --> Total execution time: 0.0906
INFO - 2023-04-19 07:18:30 --> Config Class Initialized
INFO - 2023-04-19 07:18:30 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:30 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:30 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:30 --> URI Class Initialized
INFO - 2023-04-19 07:18:30 --> Router Class Initialized
INFO - 2023-04-19 07:18:30 --> Output Class Initialized
INFO - 2023-04-19 07:18:30 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:30 --> Input Class Initialized
INFO - 2023-04-19 07:18:30 --> Language Class Initialized
INFO - 2023-04-19 07:18:30 --> Loader Class Initialized
INFO - 2023-04-19 07:18:30 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:30 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:30 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:30 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:30 --> Total execution time: 0.0221
INFO - 2023-04-19 07:18:30 --> Config Class Initialized
INFO - 2023-04-19 07:18:30 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:30 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:30 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:30 --> URI Class Initialized
INFO - 2023-04-19 07:18:30 --> Router Class Initialized
INFO - 2023-04-19 07:18:30 --> Output Class Initialized
INFO - 2023-04-19 07:18:30 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:30 --> Input Class Initialized
INFO - 2023-04-19 07:18:30 --> Language Class Initialized
INFO - 2023-04-19 07:18:30 --> Loader Class Initialized
INFO - 2023-04-19 07:18:30 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:30 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:30 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:30 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:30 --> Total execution time: 0.0960
INFO - 2023-04-19 07:18:32 --> Config Class Initialized
INFO - 2023-04-19 07:18:32 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:32 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:32 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:32 --> URI Class Initialized
INFO - 2023-04-19 07:18:32 --> Router Class Initialized
INFO - 2023-04-19 07:18:32 --> Output Class Initialized
INFO - 2023-04-19 07:18:32 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:32 --> Input Class Initialized
INFO - 2023-04-19 07:18:32 --> Language Class Initialized
INFO - 2023-04-19 07:18:32 --> Loader Class Initialized
INFO - 2023-04-19 07:18:32 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:32 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:32 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:32 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:32 --> Model "Login_model" initialized
INFO - 2023-04-19 07:18:32 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:32 --> Total execution time: 0.0811
INFO - 2023-04-19 07:18:32 --> Config Class Initialized
INFO - 2023-04-19 07:18:32 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:32 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:32 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:32 --> URI Class Initialized
INFO - 2023-04-19 07:18:32 --> Router Class Initialized
INFO - 2023-04-19 07:18:32 --> Output Class Initialized
INFO - 2023-04-19 07:18:32 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:32 --> Input Class Initialized
INFO - 2023-04-19 07:18:32 --> Language Class Initialized
INFO - 2023-04-19 07:18:32 --> Loader Class Initialized
INFO - 2023-04-19 07:18:32 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:32 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:32 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:32 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:32 --> Model "Login_model" initialized
INFO - 2023-04-19 07:18:32 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:32 --> Total execution time: 0.1438
INFO - 2023-04-19 07:18:35 --> Config Class Initialized
INFO - 2023-04-19 07:18:35 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:35 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:35 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:35 --> URI Class Initialized
INFO - 2023-04-19 07:18:35 --> Router Class Initialized
INFO - 2023-04-19 07:18:35 --> Output Class Initialized
INFO - 2023-04-19 07:18:35 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:35 --> Input Class Initialized
INFO - 2023-04-19 07:18:35 --> Language Class Initialized
INFO - 2023-04-19 07:18:35 --> Loader Class Initialized
INFO - 2023-04-19 07:18:35 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:35 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:35 --> Total execution time: 0.0051
INFO - 2023-04-19 07:18:35 --> Config Class Initialized
INFO - 2023-04-19 07:18:35 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:35 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:35 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:35 --> URI Class Initialized
INFO - 2023-04-19 07:18:35 --> Router Class Initialized
INFO - 2023-04-19 07:18:35 --> Output Class Initialized
INFO - 2023-04-19 07:18:35 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:35 --> Input Class Initialized
INFO - 2023-04-19 07:18:35 --> Language Class Initialized
INFO - 2023-04-19 07:18:35 --> Loader Class Initialized
INFO - 2023-04-19 07:18:35 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:35 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:35 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:35 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:35 --> Total execution time: 0.0651
INFO - 2023-04-19 07:18:39 --> Config Class Initialized
INFO - 2023-04-19 07:18:39 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:39 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:39 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:39 --> URI Class Initialized
INFO - 2023-04-19 07:18:39 --> Router Class Initialized
INFO - 2023-04-19 07:18:39 --> Output Class Initialized
INFO - 2023-04-19 07:18:39 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:39 --> Input Class Initialized
INFO - 2023-04-19 07:18:39 --> Language Class Initialized
INFO - 2023-04-19 07:18:39 --> Loader Class Initialized
INFO - 2023-04-19 07:18:39 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:39 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:39 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:39 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:39 --> Total execution time: 0.0336
INFO - 2023-04-19 07:18:39 --> Config Class Initialized
INFO - 2023-04-19 07:18:39 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:39 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:39 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:39 --> URI Class Initialized
INFO - 2023-04-19 07:18:39 --> Router Class Initialized
INFO - 2023-04-19 07:18:39 --> Output Class Initialized
INFO - 2023-04-19 07:18:39 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:39 --> Input Class Initialized
INFO - 2023-04-19 07:18:39 --> Language Class Initialized
INFO - 2023-04-19 07:18:39 --> Loader Class Initialized
INFO - 2023-04-19 07:18:39 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:39 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:39 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:39 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:39 --> Total execution time: 0.0677
INFO - 2023-04-19 07:18:46 --> Config Class Initialized
INFO - 2023-04-19 07:18:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:46 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:46 --> URI Class Initialized
INFO - 2023-04-19 07:18:46 --> Router Class Initialized
INFO - 2023-04-19 07:18:46 --> Output Class Initialized
INFO - 2023-04-19 07:18:46 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:46 --> Input Class Initialized
INFO - 2023-04-19 07:18:46 --> Language Class Initialized
INFO - 2023-04-19 07:18:46 --> Loader Class Initialized
INFO - 2023-04-19 07:18:46 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:46 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:46 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:46 --> Total execution time: 0.0166
INFO - 2023-04-19 07:18:46 --> Config Class Initialized
INFO - 2023-04-19 07:18:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:18:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:18:46 --> Utf8 Class Initialized
INFO - 2023-04-19 07:18:46 --> URI Class Initialized
INFO - 2023-04-19 07:18:46 --> Router Class Initialized
INFO - 2023-04-19 07:18:46 --> Output Class Initialized
INFO - 2023-04-19 07:18:46 --> Security Class Initialized
DEBUG - 2023-04-19 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:18:46 --> Input Class Initialized
INFO - 2023-04-19 07:18:46 --> Language Class Initialized
INFO - 2023-04-19 07:18:46 --> Loader Class Initialized
INFO - 2023-04-19 07:18:46 --> Controller Class Initialized
DEBUG - 2023-04-19 07:18:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:18:46 --> Database Driver Class Initialized
INFO - 2023-04-19 07:18:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:18:46 --> Final output sent to browser
DEBUG - 2023-04-19 07:18:46 --> Total execution time: 0.0610
INFO - 2023-04-19 07:19:00 --> Config Class Initialized
INFO - 2023-04-19 07:19:00 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:00 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:00 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:00 --> URI Class Initialized
INFO - 2023-04-19 07:19:00 --> Router Class Initialized
INFO - 2023-04-19 07:19:00 --> Output Class Initialized
INFO - 2023-04-19 07:19:00 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:00 --> Input Class Initialized
INFO - 2023-04-19 07:19:00 --> Language Class Initialized
INFO - 2023-04-19 07:19:00 --> Loader Class Initialized
INFO - 2023-04-19 07:19:00 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:00 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:00 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:00 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:00 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:00 --> Total execution time: 0.0357
INFO - 2023-04-19 07:19:00 --> Config Class Initialized
INFO - 2023-04-19 07:19:00 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:00 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:00 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:00 --> URI Class Initialized
INFO - 2023-04-19 07:19:00 --> Router Class Initialized
INFO - 2023-04-19 07:19:00 --> Output Class Initialized
INFO - 2023-04-19 07:19:00 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:00 --> Input Class Initialized
INFO - 2023-04-19 07:19:00 --> Language Class Initialized
INFO - 2023-04-19 07:19:00 --> Loader Class Initialized
INFO - 2023-04-19 07:19:00 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:00 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:00 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:00 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:00 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:00 --> Total execution time: 0.0662
INFO - 2023-04-19 07:19:02 --> Config Class Initialized
INFO - 2023-04-19 07:19:02 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:02 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:02 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:02 --> URI Class Initialized
INFO - 2023-04-19 07:19:02 --> Router Class Initialized
INFO - 2023-04-19 07:19:02 --> Output Class Initialized
INFO - 2023-04-19 07:19:02 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:02 --> Input Class Initialized
INFO - 2023-04-19 07:19:02 --> Language Class Initialized
INFO - 2023-04-19 07:19:02 --> Loader Class Initialized
INFO - 2023-04-19 07:19:02 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:02 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:02 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:02 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:02 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:02 --> Total execution time: 0.0270
INFO - 2023-04-19 07:19:02 --> Config Class Initialized
INFO - 2023-04-19 07:19:02 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:02 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:02 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:02 --> URI Class Initialized
INFO - 2023-04-19 07:19:02 --> Router Class Initialized
INFO - 2023-04-19 07:19:02 --> Output Class Initialized
INFO - 2023-04-19 07:19:02 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:02 --> Input Class Initialized
INFO - 2023-04-19 07:19:02 --> Language Class Initialized
INFO - 2023-04-19 07:19:02 --> Loader Class Initialized
INFO - 2023-04-19 07:19:02 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:02 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:02 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:02 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:02 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:02 --> Total execution time: 0.0673
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.0169
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.0169
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.0243
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.0840
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:05 --> Router Class Initialized
INFO - 2023-04-19 07:19:05 --> Output Class Initialized
INFO - 2023-04-19 07:19:05 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:05 --> Input Class Initialized
INFO - 2023-04-19 07:19:05 --> Language Class Initialized
INFO - 2023-04-19 07:19:05 --> Loader Class Initialized
INFO - 2023-04-19 07:19:05 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:05 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:05 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.1401
INFO - 2023-04-19 07:19:05 --> Config Class Initialized
INFO - 2023-04-19 07:19:05 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
INFO - 2023-04-19 07:19:05 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.0627
DEBUG - 2023-04-19 07:19:05 --> Total execution time: 0.1077
INFO - 2023-04-19 07:19:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:19:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:19:05 --> Utf8 Class Initialized
INFO - 2023-04-19 07:19:05 --> URI Class Initialized
INFO - 2023-04-19 07:19:06 --> Router Class Initialized
INFO - 2023-04-19 07:19:06 --> Output Class Initialized
INFO - 2023-04-19 07:19:06 --> Security Class Initialized
DEBUG - 2023-04-19 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:19:06 --> Input Class Initialized
INFO - 2023-04-19 07:19:06 --> Language Class Initialized
INFO - 2023-04-19 07:19:06 --> Loader Class Initialized
INFO - 2023-04-19 07:19:06 --> Controller Class Initialized
DEBUG - 2023-04-19 07:19:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:19:06 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:06 --> Model "Login_model" initialized
INFO - 2023-04-19 07:19:06 --> Database Driver Class Initialized
INFO - 2023-04-19 07:19:06 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:19:06 --> Final output sent to browser
DEBUG - 2023-04-19 07:19:06 --> Total execution time: 0.1071
INFO - 2023-04-19 07:41:22 --> Config Class Initialized
INFO - 2023-04-19 07:41:22 --> Config Class Initialized
INFO - 2023-04-19 07:41:22 --> Config Class Initialized
INFO - 2023-04-19 07:41:22 --> Hooks Class Initialized
INFO - 2023-04-19 07:41:22 --> Hooks Class Initialized
INFO - 2023-04-19 07:41:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 07:41:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:22 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:22 --> Utf8 Class Initialized
DEBUG - 2023-04-19 07:41:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:22 --> URI Class Initialized
INFO - 2023-04-19 07:41:22 --> URI Class Initialized
INFO - 2023-04-19 07:41:22 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:22 --> Router Class Initialized
INFO - 2023-04-19 07:41:22 --> Router Class Initialized
INFO - 2023-04-19 07:41:22 --> URI Class Initialized
INFO - 2023-04-19 07:41:22 --> Output Class Initialized
INFO - 2023-04-19 07:41:22 --> Output Class Initialized
INFO - 2023-04-19 07:41:22 --> Router Class Initialized
INFO - 2023-04-19 07:41:22 --> Security Class Initialized
INFO - 2023-04-19 07:41:22 --> Security Class Initialized
INFO - 2023-04-19 07:41:22 --> Output Class Initialized
DEBUG - 2023-04-19 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-19 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:22 --> Input Class Initialized
INFO - 2023-04-19 07:41:22 --> Security Class Initialized
INFO - 2023-04-19 07:41:22 --> Language Class Initialized
INFO - 2023-04-19 07:41:22 --> Input Class Initialized
DEBUG - 2023-04-19 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:22 --> Language Class Initialized
INFO - 2023-04-19 07:41:22 --> Input Class Initialized
INFO - 2023-04-19 07:41:22 --> Loader Class Initialized
INFO - 2023-04-19 07:41:22 --> Language Class Initialized
INFO - 2023-04-19 07:41:22 --> Loader Class Initialized
INFO - 2023-04-19 07:41:22 --> Controller Class Initialized
INFO - 2023-04-19 07:41:22 --> Loader Class Initialized
INFO - 2023-04-19 07:41:22 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 07:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:22 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:22 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:22 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:22 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:22 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:22 --> Final output sent to browser
INFO - 2023-04-19 07:41:22 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:22 --> Total execution time: 0.0933
DEBUG - 2023-04-19 07:41:22 --> Total execution time: 0.0933
INFO - 2023-04-19 07:41:22 --> Config Class Initialized
INFO - 2023-04-19 07:41:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:22 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.1013
INFO - 2023-04-19 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:23 --> URI Class Initialized
INFO - 2023-04-19 07:41:23 --> Config Class Initialized
INFO - 2023-04-19 07:41:23 --> Hooks Class Initialized
INFO - 2023-04-19 07:41:23 --> Router Class Initialized
DEBUG - 2023-04-19 07:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:23 --> Output Class Initialized
INFO - 2023-04-19 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:23 --> Config Class Initialized
INFO - 2023-04-19 07:41:23 --> Hooks Class Initialized
INFO - 2023-04-19 07:41:23 --> Security Class Initialized
INFO - 2023-04-19 07:41:23 --> URI Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:23 --> Router Class Initialized
DEBUG - 2023-04-19 07:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:23 --> Input Class Initialized
INFO - 2023-04-19 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:23 --> Output Class Initialized
INFO - 2023-04-19 07:41:23 --> Language Class Initialized
INFO - 2023-04-19 07:41:23 --> URI Class Initialized
INFO - 2023-04-19 07:41:23 --> Security Class Initialized
INFO - 2023-04-19 07:41:23 --> Loader Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:23 --> Router Class Initialized
INFO - 2023-04-19 07:41:23 --> Input Class Initialized
INFO - 2023-04-19 07:41:23 --> Controller Class Initialized
INFO - 2023-04-19 07:41:23 --> Output Class Initialized
INFO - 2023-04-19 07:41:23 --> Language Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:23 --> Security Class Initialized
INFO - 2023-04-19 07:41:23 --> Final output sent to browser
INFO - 2023-04-19 07:41:23 --> Loader Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.0830
INFO - 2023-04-19 07:41:23 --> Input Class Initialized
INFO - 2023-04-19 07:41:23 --> Controller Class Initialized
INFO - 2023-04-19 07:41:23 --> Language Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:23 --> Loader Class Initialized
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Controller Class Initialized
INFO - 2023-04-19 07:41:23 --> Config Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:23 --> Hooks Class Initialized
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
DEBUG - 2023-04-19 07:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:23 --> URI Class Initialized
INFO - 2023-04-19 07:41:23 --> Router Class Initialized
INFO - 2023-04-19 07:41:23 --> Output Class Initialized
INFO - 2023-04-19 07:41:23 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:23 --> Input Class Initialized
INFO - 2023-04-19 07:41:23 --> Language Class Initialized
INFO - 2023-04-19 07:41:23 --> Loader Class Initialized
INFO - 2023-04-19 07:41:23 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.0963
INFO - 2023-04-19 07:41:23 --> Config Class Initialized
INFO - 2023-04-19 07:41:23 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:23 --> Final output sent to browser
INFO - 2023-04-19 07:41:23 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.0594
DEBUG - 2023-04-19 07:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:23 --> URI Class Initialized
INFO - 2023-04-19 07:41:23 --> Router Class Initialized
INFO - 2023-04-19 07:41:23 --> Output Class Initialized
INFO - 2023-04-19 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.1393
INFO - 2023-04-19 07:41:23 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:23 --> Input Class Initialized
INFO - 2023-04-19 07:41:23 --> Language Class Initialized
INFO - 2023-04-19 07:41:23 --> Loader Class Initialized
INFO - 2023-04-19 07:41:23 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:23 --> Total execution time: 0.1428
INFO - 2023-04-19 07:41:27 --> Config Class Initialized
INFO - 2023-04-19 07:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:27 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:27 --> URI Class Initialized
INFO - 2023-04-19 07:41:27 --> Router Class Initialized
INFO - 2023-04-19 07:41:27 --> Output Class Initialized
INFO - 2023-04-19 07:41:27 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:27 --> Input Class Initialized
INFO - 2023-04-19 07:41:27 --> Language Class Initialized
INFO - 2023-04-19 07:41:27 --> Loader Class Initialized
INFO - 2023-04-19 07:41:27 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:27 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:27 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:27 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:27 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:27 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:27 --> Total execution time: 0.0964
INFO - 2023-04-19 07:41:27 --> Config Class Initialized
INFO - 2023-04-19 07:41:27 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:27 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:27 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:27 --> URI Class Initialized
INFO - 2023-04-19 07:41:27 --> Router Class Initialized
INFO - 2023-04-19 07:41:27 --> Output Class Initialized
INFO - 2023-04-19 07:41:27 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:27 --> Input Class Initialized
INFO - 2023-04-19 07:41:27 --> Language Class Initialized
INFO - 2023-04-19 07:41:27 --> Loader Class Initialized
INFO - 2023-04-19 07:41:27 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:27 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:27 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:27 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:27 --> Model "Login_model" initialized
INFO - 2023-04-19 07:41:27 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:27 --> Total execution time: 0.1090
INFO - 2023-04-19 07:41:29 --> Config Class Initialized
INFO - 2023-04-19 07:41:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:29 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:29 --> URI Class Initialized
INFO - 2023-04-19 07:41:29 --> Router Class Initialized
INFO - 2023-04-19 07:41:29 --> Output Class Initialized
INFO - 2023-04-19 07:41:29 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:29 --> Input Class Initialized
INFO - 2023-04-19 07:41:29 --> Language Class Initialized
INFO - 2023-04-19 07:41:29 --> Loader Class Initialized
INFO - 2023-04-19 07:41:29 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:29 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:29 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:29 --> Total execution time: 0.0534
INFO - 2023-04-19 07:41:29 --> Config Class Initialized
INFO - 2023-04-19 07:41:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:29 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:29 --> URI Class Initialized
INFO - 2023-04-19 07:41:29 --> Router Class Initialized
INFO - 2023-04-19 07:41:29 --> Output Class Initialized
INFO - 2023-04-19 07:41:29 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:29 --> Input Class Initialized
INFO - 2023-04-19 07:41:29 --> Language Class Initialized
INFO - 2023-04-19 07:41:29 --> Loader Class Initialized
INFO - 2023-04-19 07:41:29 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:29 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:29 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:29 --> Total execution time: 0.0705
INFO - 2023-04-19 07:41:29 --> Config Class Initialized
INFO - 2023-04-19 07:41:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:29 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:29 --> URI Class Initialized
INFO - 2023-04-19 07:41:29 --> Router Class Initialized
INFO - 2023-04-19 07:41:29 --> Output Class Initialized
INFO - 2023-04-19 07:41:29 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:29 --> Input Class Initialized
INFO - 2023-04-19 07:41:29 --> Language Class Initialized
INFO - 2023-04-19 07:41:29 --> Loader Class Initialized
INFO - 2023-04-19 07:41:29 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:29 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:29 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:29 --> Total execution time: 0.0538
INFO - 2023-04-19 07:41:29 --> Config Class Initialized
INFO - 2023-04-19 07:41:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:41:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:41:29 --> Utf8 Class Initialized
INFO - 2023-04-19 07:41:29 --> URI Class Initialized
INFO - 2023-04-19 07:41:29 --> Router Class Initialized
INFO - 2023-04-19 07:41:29 --> Output Class Initialized
INFO - 2023-04-19 07:41:29 --> Security Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:41:29 --> Input Class Initialized
INFO - 2023-04-19 07:41:29 --> Language Class Initialized
INFO - 2023-04-19 07:41:29 --> Loader Class Initialized
INFO - 2023-04-19 07:41:29 --> Controller Class Initialized
DEBUG - 2023-04-19 07:41:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:41:29 --> Database Driver Class Initialized
INFO - 2023-04-19 07:41:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:41:29 --> Final output sent to browser
DEBUG - 2023-04-19 07:41:29 --> Total execution time: 0.0557
INFO - 2023-04-19 07:57:53 --> Config Class Initialized
INFO - 2023-04-19 07:57:53 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:57:53 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:57:53 --> Utf8 Class Initialized
INFO - 2023-04-19 07:57:53 --> URI Class Initialized
INFO - 2023-04-19 07:57:53 --> Router Class Initialized
INFO - 2023-04-19 07:57:53 --> Output Class Initialized
INFO - 2023-04-19 07:57:53 --> Security Class Initialized
DEBUG - 2023-04-19 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:57:53 --> Input Class Initialized
INFO - 2023-04-19 07:57:53 --> Language Class Initialized
INFO - 2023-04-19 07:57:53 --> Loader Class Initialized
INFO - 2023-04-19 07:57:53 --> Controller Class Initialized
DEBUG - 2023-04-19 07:57:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:57:53 --> Database Driver Class Initialized
INFO - 2023-04-19 07:57:53 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:57:53 --> Database Driver Class Initialized
INFO - 2023-04-19 07:57:53 --> Model "Login_model" initialized
INFO - 2023-04-19 07:57:53 --> Final output sent to browser
DEBUG - 2023-04-19 07:57:53 --> Total execution time: 0.1365
INFO - 2023-04-19 07:57:53 --> Config Class Initialized
INFO - 2023-04-19 07:57:53 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:57:53 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:57:53 --> Utf8 Class Initialized
INFO - 2023-04-19 07:57:53 --> URI Class Initialized
INFO - 2023-04-19 07:57:53 --> Router Class Initialized
INFO - 2023-04-19 07:57:53 --> Output Class Initialized
INFO - 2023-04-19 07:57:53 --> Security Class Initialized
DEBUG - 2023-04-19 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:57:53 --> Input Class Initialized
INFO - 2023-04-19 07:57:53 --> Language Class Initialized
INFO - 2023-04-19 07:57:53 --> Loader Class Initialized
INFO - 2023-04-19 07:57:53 --> Controller Class Initialized
DEBUG - 2023-04-19 07:57:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:57:53 --> Database Driver Class Initialized
INFO - 2023-04-19 07:57:53 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:57:53 --> Database Driver Class Initialized
INFO - 2023-04-19 07:57:53 --> Model "Login_model" initialized
INFO - 2023-04-19 07:57:53 --> Final output sent to browser
DEBUG - 2023-04-19 07:57:53 --> Total execution time: 0.0948
INFO - 2023-04-19 07:58:28 --> Config Class Initialized
INFO - 2023-04-19 07:58:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:28 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:28 --> URI Class Initialized
INFO - 2023-04-19 07:58:28 --> Router Class Initialized
INFO - 2023-04-19 07:58:28 --> Output Class Initialized
INFO - 2023-04-19 07:58:28 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:28 --> Input Class Initialized
INFO - 2023-04-19 07:58:28 --> Language Class Initialized
INFO - 2023-04-19 07:58:28 --> Loader Class Initialized
INFO - 2023-04-19 07:58:28 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:28 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:28 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:28 --> Model "Login_model" initialized
INFO - 2023-04-19 07:58:28 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:28 --> Total execution time: 0.1553
INFO - 2023-04-19 07:58:28 --> Config Class Initialized
INFO - 2023-04-19 07:58:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:28 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:28 --> URI Class Initialized
INFO - 2023-04-19 07:58:28 --> Router Class Initialized
INFO - 2023-04-19 07:58:28 --> Output Class Initialized
INFO - 2023-04-19 07:58:28 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:28 --> Input Class Initialized
INFO - 2023-04-19 07:58:28 --> Language Class Initialized
INFO - 2023-04-19 07:58:28 --> Loader Class Initialized
INFO - 2023-04-19 07:58:28 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:28 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:28 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:28 --> Model "Login_model" initialized
INFO - 2023-04-19 07:58:28 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:28 --> Total execution time: 0.1055
INFO - 2023-04-19 07:58:31 --> Config Class Initialized
INFO - 2023-04-19 07:58:31 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:31 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:31 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:31 --> URI Class Initialized
INFO - 2023-04-19 07:58:31 --> Router Class Initialized
INFO - 2023-04-19 07:58:31 --> Output Class Initialized
INFO - 2023-04-19 07:58:31 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:31 --> Input Class Initialized
INFO - 2023-04-19 07:58:31 --> Language Class Initialized
INFO - 2023-04-19 07:58:31 --> Loader Class Initialized
INFO - 2023-04-19 07:58:31 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:31 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:31 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:31 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:31 --> Total execution time: 0.0115
INFO - 2023-04-19 07:58:31 --> Config Class Initialized
INFO - 2023-04-19 07:58:31 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:31 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:31 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:31 --> URI Class Initialized
INFO - 2023-04-19 07:58:31 --> Router Class Initialized
INFO - 2023-04-19 07:58:31 --> Output Class Initialized
INFO - 2023-04-19 07:58:31 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:31 --> Input Class Initialized
INFO - 2023-04-19 07:58:31 --> Language Class Initialized
INFO - 2023-04-19 07:58:31 --> Loader Class Initialized
INFO - 2023-04-19 07:58:31 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:31 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:31 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:31 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:31 --> Total execution time: 0.0542
INFO - 2023-04-19 07:58:31 --> Config Class Initialized
INFO - 2023-04-19 07:58:31 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:31 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:31 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:31 --> URI Class Initialized
INFO - 2023-04-19 07:58:31 --> Router Class Initialized
INFO - 2023-04-19 07:58:31 --> Output Class Initialized
INFO - 2023-04-19 07:58:31 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:31 --> Input Class Initialized
INFO - 2023-04-19 07:58:31 --> Language Class Initialized
INFO - 2023-04-19 07:58:31 --> Loader Class Initialized
INFO - 2023-04-19 07:58:31 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:31 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:31 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:31 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:31 --> Total execution time: 0.0597
INFO - 2023-04-19 07:58:31 --> Config Class Initialized
INFO - 2023-04-19 07:58:31 --> Hooks Class Initialized
DEBUG - 2023-04-19 07:58:31 --> UTF-8 Support Enabled
INFO - 2023-04-19 07:58:31 --> Utf8 Class Initialized
INFO - 2023-04-19 07:58:31 --> URI Class Initialized
INFO - 2023-04-19 07:58:31 --> Router Class Initialized
INFO - 2023-04-19 07:58:31 --> Output Class Initialized
INFO - 2023-04-19 07:58:31 --> Security Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 07:58:31 --> Input Class Initialized
INFO - 2023-04-19 07:58:31 --> Language Class Initialized
INFO - 2023-04-19 07:58:31 --> Loader Class Initialized
INFO - 2023-04-19 07:58:31 --> Controller Class Initialized
DEBUG - 2023-04-19 07:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 07:58:31 --> Database Driver Class Initialized
INFO - 2023-04-19 07:58:31 --> Model "Cluster_model" initialized
INFO - 2023-04-19 07:58:31 --> Final output sent to browser
DEBUG - 2023-04-19 07:58:31 --> Total execution time: 0.0522
INFO - 2023-04-19 08:01:26 --> Config Class Initialized
INFO - 2023-04-19 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:26 --> URI Class Initialized
INFO - 2023-04-19 08:01:26 --> Router Class Initialized
INFO - 2023-04-19 08:01:26 --> Output Class Initialized
INFO - 2023-04-19 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:26 --> Input Class Initialized
INFO - 2023-04-19 08:01:26 --> Language Class Initialized
INFO - 2023-04-19 08:01:26 --> Loader Class Initialized
INFO - 2023-04-19 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:26 --> Total execution time: 0.0945
INFO - 2023-04-19 08:01:26 --> Config Class Initialized
INFO - 2023-04-19 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:26 --> URI Class Initialized
INFO - 2023-04-19 08:01:26 --> Router Class Initialized
INFO - 2023-04-19 08:01:26 --> Output Class Initialized
INFO - 2023-04-19 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:26 --> Input Class Initialized
INFO - 2023-04-19 08:01:26 --> Language Class Initialized
INFO - 2023-04-19 08:01:26 --> Loader Class Initialized
INFO - 2023-04-19 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:26 --> Total execution time: 0.0112
INFO - 2023-04-19 08:01:26 --> Config Class Initialized
INFO - 2023-04-19 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:26 --> URI Class Initialized
INFO - 2023-04-19 08:01:26 --> Router Class Initialized
INFO - 2023-04-19 08:01:26 --> Output Class Initialized
INFO - 2023-04-19 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:26 --> Input Class Initialized
INFO - 2023-04-19 08:01:26 --> Language Class Initialized
INFO - 2023-04-19 08:01:26 --> Loader Class Initialized
INFO - 2023-04-19 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:26 --> Total execution time: 0.0508
INFO - 2023-04-19 08:01:26 --> Config Class Initialized
INFO - 2023-04-19 08:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:26 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:26 --> URI Class Initialized
INFO - 2023-04-19 08:01:26 --> Router Class Initialized
INFO - 2023-04-19 08:01:26 --> Output Class Initialized
INFO - 2023-04-19 08:01:26 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:26 --> Input Class Initialized
INFO - 2023-04-19 08:01:26 --> Language Class Initialized
INFO - 2023-04-19 08:01:26 --> Loader Class Initialized
INFO - 2023-04-19 08:01:26 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:26 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:26 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:26 --> Total execution time: 0.0135
INFO - 2023-04-19 08:01:32 --> Config Class Initialized
INFO - 2023-04-19 08:01:32 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:32 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:32 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:32 --> URI Class Initialized
INFO - 2023-04-19 08:01:32 --> Router Class Initialized
INFO - 2023-04-19 08:01:32 --> Output Class Initialized
INFO - 2023-04-19 08:01:32 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:32 --> Input Class Initialized
INFO - 2023-04-19 08:01:32 --> Language Class Initialized
INFO - 2023-04-19 08:01:32 --> Loader Class Initialized
INFO - 2023-04-19 08:01:32 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:32 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:33 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:33 --> Model "Login_model" initialized
INFO - 2023-04-19 08:01:33 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:33 --> Total execution time: 0.2106
INFO - 2023-04-19 08:01:33 --> Config Class Initialized
INFO - 2023-04-19 08:01:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:01:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:01:33 --> Utf8 Class Initialized
INFO - 2023-04-19 08:01:33 --> URI Class Initialized
INFO - 2023-04-19 08:01:33 --> Router Class Initialized
INFO - 2023-04-19 08:01:33 --> Output Class Initialized
INFO - 2023-04-19 08:01:33 --> Security Class Initialized
DEBUG - 2023-04-19 08:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:01:33 --> Input Class Initialized
INFO - 2023-04-19 08:01:33 --> Language Class Initialized
INFO - 2023-04-19 08:01:33 --> Loader Class Initialized
INFO - 2023-04-19 08:01:33 --> Controller Class Initialized
DEBUG - 2023-04-19 08:01:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:01:33 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:01:33 --> Database Driver Class Initialized
INFO - 2023-04-19 08:01:33 --> Model "Login_model" initialized
INFO - 2023-04-19 08:01:33 --> Final output sent to browser
DEBUG - 2023-04-19 08:01:33 --> Total execution time: 0.1660
INFO - 2023-04-19 08:02:55 --> Config Class Initialized
INFO - 2023-04-19 08:02:55 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:02:55 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:02:55 --> Utf8 Class Initialized
INFO - 2023-04-19 08:02:55 --> URI Class Initialized
INFO - 2023-04-19 08:02:55 --> Router Class Initialized
INFO - 2023-04-19 08:02:55 --> Output Class Initialized
INFO - 2023-04-19 08:02:55 --> Security Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:02:55 --> Input Class Initialized
INFO - 2023-04-19 08:02:55 --> Language Class Initialized
INFO - 2023-04-19 08:02:55 --> Loader Class Initialized
INFO - 2023-04-19 08:02:55 --> Controller Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:02:55 --> Database Driver Class Initialized
INFO - 2023-04-19 08:02:55 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:02:55 --> Final output sent to browser
DEBUG - 2023-04-19 08:02:55 --> Total execution time: 0.0196
INFO - 2023-04-19 08:02:55 --> Config Class Initialized
INFO - 2023-04-19 08:02:55 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:02:55 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:02:55 --> Utf8 Class Initialized
INFO - 2023-04-19 08:02:55 --> URI Class Initialized
INFO - 2023-04-19 08:02:55 --> Router Class Initialized
INFO - 2023-04-19 08:02:55 --> Output Class Initialized
INFO - 2023-04-19 08:02:55 --> Security Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:02:55 --> Input Class Initialized
INFO - 2023-04-19 08:02:55 --> Language Class Initialized
INFO - 2023-04-19 08:02:55 --> Loader Class Initialized
INFO - 2023-04-19 08:02:55 --> Controller Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:02:55 --> Database Driver Class Initialized
INFO - 2023-04-19 08:02:55 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:02:55 --> Final output sent to browser
DEBUG - 2023-04-19 08:02:55 --> Total execution time: 0.0550
INFO - 2023-04-19 08:02:55 --> Config Class Initialized
INFO - 2023-04-19 08:02:55 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:02:55 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:02:55 --> Utf8 Class Initialized
INFO - 2023-04-19 08:02:55 --> URI Class Initialized
INFO - 2023-04-19 08:02:55 --> Router Class Initialized
INFO - 2023-04-19 08:02:55 --> Output Class Initialized
INFO - 2023-04-19 08:02:55 --> Security Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:02:55 --> Input Class Initialized
INFO - 2023-04-19 08:02:55 --> Language Class Initialized
INFO - 2023-04-19 08:02:55 --> Loader Class Initialized
INFO - 2023-04-19 08:02:55 --> Controller Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:02:55 --> Database Driver Class Initialized
INFO - 2023-04-19 08:02:55 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:02:55 --> Final output sent to browser
DEBUG - 2023-04-19 08:02:55 --> Total execution time: 0.0506
INFO - 2023-04-19 08:02:55 --> Config Class Initialized
INFO - 2023-04-19 08:02:55 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:02:55 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:02:55 --> Utf8 Class Initialized
INFO - 2023-04-19 08:02:55 --> URI Class Initialized
INFO - 2023-04-19 08:02:55 --> Router Class Initialized
INFO - 2023-04-19 08:02:55 --> Output Class Initialized
INFO - 2023-04-19 08:02:55 --> Security Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:02:55 --> Input Class Initialized
INFO - 2023-04-19 08:02:55 --> Language Class Initialized
INFO - 2023-04-19 08:02:55 --> Loader Class Initialized
INFO - 2023-04-19 08:02:55 --> Controller Class Initialized
DEBUG - 2023-04-19 08:02:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:02:55 --> Database Driver Class Initialized
INFO - 2023-04-19 08:02:55 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:02:55 --> Final output sent to browser
DEBUG - 2023-04-19 08:02:55 --> Total execution time: 0.0136
INFO - 2023-04-19 08:56:03 --> Config Class Initialized
INFO - 2023-04-19 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:56:03 --> Utf8 Class Initialized
INFO - 2023-04-19 08:56:03 --> URI Class Initialized
INFO - 2023-04-19 08:56:03 --> Router Class Initialized
INFO - 2023-04-19 08:56:03 --> Output Class Initialized
INFO - 2023-04-19 08:56:03 --> Security Class Initialized
DEBUG - 2023-04-19 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:56:03 --> Input Class Initialized
INFO - 2023-04-19 08:56:03 --> Language Class Initialized
INFO - 2023-04-19 08:56:03 --> Loader Class Initialized
INFO - 2023-04-19 08:56:03 --> Controller Class Initialized
DEBUG - 2023-04-19 08:56:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:56:03 --> Database Driver Class Initialized
INFO - 2023-04-19 08:56:03 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:56:03 --> Database Driver Class Initialized
INFO - 2023-04-19 08:56:03 --> Model "Login_model" initialized
INFO - 2023-04-19 08:56:03 --> Final output sent to browser
DEBUG - 2023-04-19 08:56:03 --> Total execution time: 0.1702
INFO - 2023-04-19 08:56:03 --> Config Class Initialized
INFO - 2023-04-19 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:56:03 --> Utf8 Class Initialized
INFO - 2023-04-19 08:56:03 --> URI Class Initialized
INFO - 2023-04-19 08:56:03 --> Router Class Initialized
INFO - 2023-04-19 08:56:03 --> Output Class Initialized
INFO - 2023-04-19 08:56:03 --> Security Class Initialized
DEBUG - 2023-04-19 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:56:03 --> Input Class Initialized
INFO - 2023-04-19 08:56:03 --> Language Class Initialized
INFO - 2023-04-19 08:56:03 --> Loader Class Initialized
INFO - 2023-04-19 08:56:03 --> Controller Class Initialized
DEBUG - 2023-04-19 08:56:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:56:03 --> Database Driver Class Initialized
INFO - 2023-04-19 08:56:03 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:56:03 --> Database Driver Class Initialized
INFO - 2023-04-19 08:56:03 --> Model "Login_model" initialized
INFO - 2023-04-19 08:56:03 --> Final output sent to browser
DEBUG - 2023-04-19 08:56:03 --> Total execution time: 0.1766
INFO - 2023-04-19 08:57:11 --> Config Class Initialized
INFO - 2023-04-19 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:57:11 --> Utf8 Class Initialized
INFO - 2023-04-19 08:57:11 --> URI Class Initialized
INFO - 2023-04-19 08:57:11 --> Router Class Initialized
INFO - 2023-04-19 08:57:11 --> Output Class Initialized
INFO - 2023-04-19 08:57:11 --> Security Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:57:11 --> Input Class Initialized
INFO - 2023-04-19 08:57:11 --> Language Class Initialized
INFO - 2023-04-19 08:57:11 --> Loader Class Initialized
INFO - 2023-04-19 08:57:11 --> Controller Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:57:11 --> Database Driver Class Initialized
INFO - 2023-04-19 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:57:11 --> Final output sent to browser
DEBUG - 2023-04-19 08:57:11 --> Total execution time: 0.0515
INFO - 2023-04-19 08:57:11 --> Config Class Initialized
INFO - 2023-04-19 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:57:11 --> Utf8 Class Initialized
INFO - 2023-04-19 08:57:11 --> URI Class Initialized
INFO - 2023-04-19 08:57:11 --> Router Class Initialized
INFO - 2023-04-19 08:57:11 --> Output Class Initialized
INFO - 2023-04-19 08:57:11 --> Security Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:57:11 --> Input Class Initialized
INFO - 2023-04-19 08:57:11 --> Language Class Initialized
INFO - 2023-04-19 08:57:11 --> Loader Class Initialized
INFO - 2023-04-19 08:57:11 --> Controller Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:57:11 --> Database Driver Class Initialized
INFO - 2023-04-19 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:57:11 --> Final output sent to browser
DEBUG - 2023-04-19 08:57:11 --> Total execution time: 0.0532
INFO - 2023-04-19 08:57:11 --> Config Class Initialized
INFO - 2023-04-19 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:57:11 --> Utf8 Class Initialized
INFO - 2023-04-19 08:57:11 --> URI Class Initialized
INFO - 2023-04-19 08:57:11 --> Router Class Initialized
INFO - 2023-04-19 08:57:11 --> Output Class Initialized
INFO - 2023-04-19 08:57:11 --> Security Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:57:11 --> Input Class Initialized
INFO - 2023-04-19 08:57:11 --> Language Class Initialized
INFO - 2023-04-19 08:57:11 --> Loader Class Initialized
INFO - 2023-04-19 08:57:11 --> Controller Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:57:11 --> Database Driver Class Initialized
INFO - 2023-04-19 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:57:11 --> Final output sent to browser
DEBUG - 2023-04-19 08:57:11 --> Total execution time: 0.0527
INFO - 2023-04-19 08:57:11 --> Config Class Initialized
INFO - 2023-04-19 08:57:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:57:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:57:11 --> Utf8 Class Initialized
INFO - 2023-04-19 08:57:11 --> URI Class Initialized
INFO - 2023-04-19 08:57:11 --> Router Class Initialized
INFO - 2023-04-19 08:57:11 --> Output Class Initialized
INFO - 2023-04-19 08:57:11 --> Security Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:57:11 --> Input Class Initialized
INFO - 2023-04-19 08:57:11 --> Language Class Initialized
INFO - 2023-04-19 08:57:11 --> Loader Class Initialized
INFO - 2023-04-19 08:57:11 --> Controller Class Initialized
DEBUG - 2023-04-19 08:57:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:57:11 --> Database Driver Class Initialized
INFO - 2023-04-19 08:57:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:57:11 --> Final output sent to browser
DEBUG - 2023-04-19 08:57:11 --> Total execution time: 0.0536
INFO - 2023-04-19 08:58:00 --> Config Class Initialized
INFO - 2023-04-19 08:58:00 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:58:00 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:58:00 --> Utf8 Class Initialized
INFO - 2023-04-19 08:58:00 --> URI Class Initialized
INFO - 2023-04-19 08:58:00 --> Router Class Initialized
INFO - 2023-04-19 08:58:00 --> Output Class Initialized
INFO - 2023-04-19 08:58:00 --> Security Class Initialized
DEBUG - 2023-04-19 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:58:00 --> Input Class Initialized
INFO - 2023-04-19 08:58:00 --> Language Class Initialized
INFO - 2023-04-19 08:58:00 --> Loader Class Initialized
INFO - 2023-04-19 08:58:00 --> Controller Class Initialized
DEBUG - 2023-04-19 08:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:58:00 --> Database Driver Class Initialized
INFO - 2023-04-19 08:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:58:00 --> Database Driver Class Initialized
INFO - 2023-04-19 08:58:00 --> Model "Login_model" initialized
INFO - 2023-04-19 08:58:00 --> Final output sent to browser
DEBUG - 2023-04-19 08:58:00 --> Total execution time: 0.1000
INFO - 2023-04-19 08:58:00 --> Config Class Initialized
INFO - 2023-04-19 08:58:00 --> Hooks Class Initialized
DEBUG - 2023-04-19 08:58:00 --> UTF-8 Support Enabled
INFO - 2023-04-19 08:58:00 --> Utf8 Class Initialized
INFO - 2023-04-19 08:58:00 --> URI Class Initialized
INFO - 2023-04-19 08:58:00 --> Router Class Initialized
INFO - 2023-04-19 08:58:00 --> Output Class Initialized
INFO - 2023-04-19 08:58:00 --> Security Class Initialized
DEBUG - 2023-04-19 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 08:58:00 --> Input Class Initialized
INFO - 2023-04-19 08:58:00 --> Language Class Initialized
INFO - 2023-04-19 08:58:00 --> Loader Class Initialized
INFO - 2023-04-19 08:58:00 --> Controller Class Initialized
DEBUG - 2023-04-19 08:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 08:58:00 --> Database Driver Class Initialized
INFO - 2023-04-19 08:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-19 08:58:00 --> Database Driver Class Initialized
INFO - 2023-04-19 08:58:00 --> Model "Login_model" initialized
INFO - 2023-04-19 08:58:00 --> Final output sent to browser
DEBUG - 2023-04-19 08:58:00 --> Total execution time: 0.0978
INFO - 2023-04-19 09:00:03 --> Config Class Initialized
INFO - 2023-04-19 09:00:03 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:00:03 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:00:03 --> Utf8 Class Initialized
INFO - 2023-04-19 09:00:03 --> URI Class Initialized
INFO - 2023-04-19 09:00:03 --> Router Class Initialized
INFO - 2023-04-19 09:00:03 --> Output Class Initialized
INFO - 2023-04-19 09:00:03 --> Security Class Initialized
DEBUG - 2023-04-19 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:00:03 --> Input Class Initialized
INFO - 2023-04-19 09:00:03 --> Language Class Initialized
INFO - 2023-04-19 09:00:03 --> Loader Class Initialized
INFO - 2023-04-19 09:00:03 --> Controller Class Initialized
DEBUG - 2023-04-19 09:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:00:03 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:03 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:00:03 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:03 --> Model "Login_model" initialized
INFO - 2023-04-19 09:00:04 --> Final output sent to browser
DEBUG - 2023-04-19 09:00:04 --> Total execution time: 0.2006
INFO - 2023-04-19 09:00:04 --> Config Class Initialized
INFO - 2023-04-19 09:00:04 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:00:04 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:00:04 --> Utf8 Class Initialized
INFO - 2023-04-19 09:00:04 --> URI Class Initialized
INFO - 2023-04-19 09:00:04 --> Router Class Initialized
INFO - 2023-04-19 09:00:04 --> Output Class Initialized
INFO - 2023-04-19 09:00:04 --> Security Class Initialized
DEBUG - 2023-04-19 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:00:04 --> Input Class Initialized
INFO - 2023-04-19 09:00:04 --> Language Class Initialized
INFO - 2023-04-19 09:00:04 --> Loader Class Initialized
INFO - 2023-04-19 09:00:04 --> Controller Class Initialized
DEBUG - 2023-04-19 09:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:00:04 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:04 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:00:04 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:04 --> Model "Login_model" initialized
INFO - 2023-04-19 09:00:04 --> Final output sent to browser
DEBUG - 2023-04-19 09:00:04 --> Total execution time: 0.1255
INFO - 2023-04-19 09:00:53 --> Config Class Initialized
INFO - 2023-04-19 09:00:53 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:00:53 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:00:53 --> Utf8 Class Initialized
INFO - 2023-04-19 09:00:53 --> URI Class Initialized
INFO - 2023-04-19 09:00:53 --> Router Class Initialized
INFO - 2023-04-19 09:00:53 --> Output Class Initialized
INFO - 2023-04-19 09:00:53 --> Security Class Initialized
DEBUG - 2023-04-19 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:00:53 --> Input Class Initialized
INFO - 2023-04-19 09:00:53 --> Language Class Initialized
INFO - 2023-04-19 09:00:53 --> Loader Class Initialized
INFO - 2023-04-19 09:00:53 --> Controller Class Initialized
DEBUG - 2023-04-19 09:00:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:00:53 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:53 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:00:53 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:53 --> Model "Login_model" initialized
INFO - 2023-04-19 09:00:53 --> Final output sent to browser
DEBUG - 2023-04-19 09:00:53 --> Total execution time: 0.1370
INFO - 2023-04-19 09:00:53 --> Config Class Initialized
INFO - 2023-04-19 09:00:53 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:00:53 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:00:53 --> Utf8 Class Initialized
INFO - 2023-04-19 09:00:53 --> URI Class Initialized
INFO - 2023-04-19 09:00:53 --> Router Class Initialized
INFO - 2023-04-19 09:00:53 --> Output Class Initialized
INFO - 2023-04-19 09:00:53 --> Security Class Initialized
DEBUG - 2023-04-19 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:00:53 --> Input Class Initialized
INFO - 2023-04-19 09:00:53 --> Language Class Initialized
INFO - 2023-04-19 09:00:53 --> Loader Class Initialized
INFO - 2023-04-19 09:00:53 --> Controller Class Initialized
DEBUG - 2023-04-19 09:00:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:00:53 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:53 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:00:53 --> Database Driver Class Initialized
INFO - 2023-04-19 09:00:53 --> Model "Login_model" initialized
INFO - 2023-04-19 09:00:53 --> Final output sent to browser
DEBUG - 2023-04-19 09:00:53 --> Total execution time: 0.0660
INFO - 2023-04-19 09:01:09 --> Config Class Initialized
INFO - 2023-04-19 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:09 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:09 --> URI Class Initialized
INFO - 2023-04-19 09:01:09 --> Router Class Initialized
INFO - 2023-04-19 09:01:09 --> Output Class Initialized
INFO - 2023-04-19 09:01:09 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:09 --> Input Class Initialized
INFO - 2023-04-19 09:01:09 --> Language Class Initialized
INFO - 2023-04-19 09:01:09 --> Loader Class Initialized
INFO - 2023-04-19 09:01:09 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:09 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:09 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:09 --> Model "Login_model" initialized
INFO - 2023-04-19 09:01:09 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:09 --> Total execution time: 0.1463
INFO - 2023-04-19 09:01:09 --> Config Class Initialized
INFO - 2023-04-19 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:09 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:09 --> URI Class Initialized
INFO - 2023-04-19 09:01:09 --> Router Class Initialized
INFO - 2023-04-19 09:01:09 --> Output Class Initialized
INFO - 2023-04-19 09:01:09 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:09 --> Input Class Initialized
INFO - 2023-04-19 09:01:09 --> Language Class Initialized
INFO - 2023-04-19 09:01:09 --> Loader Class Initialized
INFO - 2023-04-19 09:01:09 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:09 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:09 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:09 --> Model "Login_model" initialized
INFO - 2023-04-19 09:01:09 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:09 --> Total execution time: 0.0678
INFO - 2023-04-19 09:01:29 --> Config Class Initialized
INFO - 2023-04-19 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:29 --> URI Class Initialized
INFO - 2023-04-19 09:01:29 --> Router Class Initialized
INFO - 2023-04-19 09:01:29 --> Output Class Initialized
INFO - 2023-04-19 09:01:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:29 --> Input Class Initialized
INFO - 2023-04-19 09:01:29 --> Language Class Initialized
INFO - 2023-04-19 09:01:29 --> Loader Class Initialized
INFO - 2023-04-19 09:01:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:29 --> Total execution time: 0.0153
INFO - 2023-04-19 09:01:29 --> Config Class Initialized
INFO - 2023-04-19 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:29 --> URI Class Initialized
INFO - 2023-04-19 09:01:29 --> Router Class Initialized
INFO - 2023-04-19 09:01:29 --> Output Class Initialized
INFO - 2023-04-19 09:01:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:29 --> Input Class Initialized
INFO - 2023-04-19 09:01:29 --> Language Class Initialized
INFO - 2023-04-19 09:01:29 --> Loader Class Initialized
INFO - 2023-04-19 09:01:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:29 --> Total execution time: 0.0526
INFO - 2023-04-19 09:01:29 --> Config Class Initialized
INFO - 2023-04-19 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:29 --> URI Class Initialized
INFO - 2023-04-19 09:01:29 --> Router Class Initialized
INFO - 2023-04-19 09:01:29 --> Output Class Initialized
INFO - 2023-04-19 09:01:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:29 --> Input Class Initialized
INFO - 2023-04-19 09:01:29 --> Language Class Initialized
INFO - 2023-04-19 09:01:29 --> Loader Class Initialized
INFO - 2023-04-19 09:01:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:29 --> Total execution time: 0.0496
INFO - 2023-04-19 09:01:29 --> Config Class Initialized
INFO - 2023-04-19 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:01:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:01:29 --> URI Class Initialized
INFO - 2023-04-19 09:01:29 --> Router Class Initialized
INFO - 2023-04-19 09:01:29 --> Output Class Initialized
INFO - 2023-04-19 09:01:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:01:29 --> Input Class Initialized
INFO - 2023-04-19 09:01:29 --> Language Class Initialized
INFO - 2023-04-19 09:01:29 --> Loader Class Initialized
INFO - 2023-04-19 09:01:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:01:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:01:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:01:29 --> Total execution time: 0.0106
INFO - 2023-04-19 09:02:54 --> Config Class Initialized
INFO - 2023-04-19 09:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:54 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:54 --> URI Class Initialized
INFO - 2023-04-19 09:02:54 --> Router Class Initialized
INFO - 2023-04-19 09:02:54 --> Output Class Initialized
INFO - 2023-04-19 09:02:54 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:54 --> Input Class Initialized
INFO - 2023-04-19 09:02:54 --> Language Class Initialized
INFO - 2023-04-19 09:02:54 --> Loader Class Initialized
INFO - 2023-04-19 09:02:54 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:54 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:54 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:54 --> Model "Login_model" initialized
INFO - 2023-04-19 09:02:54 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:54 --> Total execution time: 0.1541
INFO - 2023-04-19 09:02:54 --> Config Class Initialized
INFO - 2023-04-19 09:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:54 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:54 --> URI Class Initialized
INFO - 2023-04-19 09:02:54 --> Router Class Initialized
INFO - 2023-04-19 09:02:54 --> Output Class Initialized
INFO - 2023-04-19 09:02:54 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:54 --> Input Class Initialized
INFO - 2023-04-19 09:02:54 --> Language Class Initialized
INFO - 2023-04-19 09:02:54 --> Loader Class Initialized
INFO - 2023-04-19 09:02:54 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:54 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:54 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:54 --> Model "Login_model" initialized
INFO - 2023-04-19 09:02:54 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:54 --> Total execution time: 0.0810
INFO - 2023-04-19 09:02:58 --> Config Class Initialized
INFO - 2023-04-19 09:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:58 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:58 --> URI Class Initialized
INFO - 2023-04-19 09:02:58 --> Router Class Initialized
INFO - 2023-04-19 09:02:58 --> Output Class Initialized
INFO - 2023-04-19 09:02:58 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:58 --> Input Class Initialized
INFO - 2023-04-19 09:02:58 --> Language Class Initialized
INFO - 2023-04-19 09:02:58 --> Loader Class Initialized
INFO - 2023-04-19 09:02:58 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:58 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:58 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:58 --> Total execution time: 0.0144
INFO - 2023-04-19 09:02:58 --> Config Class Initialized
INFO - 2023-04-19 09:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:58 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:58 --> URI Class Initialized
INFO - 2023-04-19 09:02:58 --> Router Class Initialized
INFO - 2023-04-19 09:02:58 --> Output Class Initialized
INFO - 2023-04-19 09:02:58 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:58 --> Input Class Initialized
INFO - 2023-04-19 09:02:58 --> Language Class Initialized
INFO - 2023-04-19 09:02:58 --> Loader Class Initialized
INFO - 2023-04-19 09:02:58 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:58 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:58 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:58 --> Total execution time: 0.0123
INFO - 2023-04-19 09:02:58 --> Config Class Initialized
INFO - 2023-04-19 09:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:58 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:58 --> URI Class Initialized
INFO - 2023-04-19 09:02:58 --> Router Class Initialized
INFO - 2023-04-19 09:02:58 --> Output Class Initialized
INFO - 2023-04-19 09:02:58 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:58 --> Input Class Initialized
INFO - 2023-04-19 09:02:58 --> Language Class Initialized
INFO - 2023-04-19 09:02:58 --> Loader Class Initialized
INFO - 2023-04-19 09:02:58 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:58 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:58 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:58 --> Total execution time: 0.0499
INFO - 2023-04-19 09:02:58 --> Config Class Initialized
INFO - 2023-04-19 09:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:02:58 --> Utf8 Class Initialized
INFO - 2023-04-19 09:02:58 --> URI Class Initialized
INFO - 2023-04-19 09:02:58 --> Router Class Initialized
INFO - 2023-04-19 09:02:58 --> Output Class Initialized
INFO - 2023-04-19 09:02:58 --> Security Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:02:58 --> Input Class Initialized
INFO - 2023-04-19 09:02:58 --> Language Class Initialized
INFO - 2023-04-19 09:02:58 --> Loader Class Initialized
INFO - 2023-04-19 09:02:58 --> Controller Class Initialized
DEBUG - 2023-04-19 09:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:02:58 --> Database Driver Class Initialized
INFO - 2023-04-19 09:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:02:58 --> Final output sent to browser
DEBUG - 2023-04-19 09:02:58 --> Total execution time: 0.0101
INFO - 2023-04-19 09:04:34 --> Config Class Initialized
INFO - 2023-04-19 09:04:34 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:34 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:34 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:34 --> URI Class Initialized
INFO - 2023-04-19 09:04:34 --> Router Class Initialized
INFO - 2023-04-19 09:04:34 --> Output Class Initialized
INFO - 2023-04-19 09:04:34 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:34 --> Input Class Initialized
INFO - 2023-04-19 09:04:34 --> Language Class Initialized
INFO - 2023-04-19 09:04:34 --> Loader Class Initialized
INFO - 2023-04-19 09:04:34 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:34 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:34 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:34 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:34 --> Model "Login_model" initialized
INFO - 2023-04-19 09:04:34 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:34 --> Total execution time: 0.1486
INFO - 2023-04-19 09:04:34 --> Config Class Initialized
INFO - 2023-04-19 09:04:34 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:34 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:34 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:34 --> URI Class Initialized
INFO - 2023-04-19 09:04:34 --> Router Class Initialized
INFO - 2023-04-19 09:04:34 --> Output Class Initialized
INFO - 2023-04-19 09:04:34 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:34 --> Input Class Initialized
INFO - 2023-04-19 09:04:34 --> Language Class Initialized
INFO - 2023-04-19 09:04:34 --> Loader Class Initialized
INFO - 2023-04-19 09:04:34 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:34 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:34 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:34 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:34 --> Model "Login_model" initialized
INFO - 2023-04-19 09:04:34 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:34 --> Total execution time: 0.1128
INFO - 2023-04-19 09:04:37 --> Config Class Initialized
INFO - 2023-04-19 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:37 --> URI Class Initialized
INFO - 2023-04-19 09:04:37 --> Router Class Initialized
INFO - 2023-04-19 09:04:37 --> Output Class Initialized
INFO - 2023-04-19 09:04:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:37 --> Input Class Initialized
INFO - 2023-04-19 09:04:37 --> Language Class Initialized
INFO - 2023-04-19 09:04:37 --> Loader Class Initialized
INFO - 2023-04-19 09:04:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:37 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:37 --> Total execution time: 0.0118
INFO - 2023-04-19 09:04:37 --> Config Class Initialized
INFO - 2023-04-19 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:37 --> URI Class Initialized
INFO - 2023-04-19 09:04:37 --> Router Class Initialized
INFO - 2023-04-19 09:04:37 --> Output Class Initialized
INFO - 2023-04-19 09:04:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:37 --> Input Class Initialized
INFO - 2023-04-19 09:04:37 --> Language Class Initialized
INFO - 2023-04-19 09:04:37 --> Loader Class Initialized
INFO - 2023-04-19 09:04:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:37 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:37 --> Total execution time: 0.0539
INFO - 2023-04-19 09:04:37 --> Config Class Initialized
INFO - 2023-04-19 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:37 --> URI Class Initialized
INFO - 2023-04-19 09:04:37 --> Router Class Initialized
INFO - 2023-04-19 09:04:37 --> Output Class Initialized
INFO - 2023-04-19 09:04:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:37 --> Input Class Initialized
INFO - 2023-04-19 09:04:37 --> Language Class Initialized
INFO - 2023-04-19 09:04:37 --> Loader Class Initialized
INFO - 2023-04-19 09:04:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:37 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:37 --> Total execution time: 0.0531
INFO - 2023-04-19 09:04:37 --> Config Class Initialized
INFO - 2023-04-19 09:04:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:04:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:04:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:04:37 --> URI Class Initialized
INFO - 2023-04-19 09:04:37 --> Router Class Initialized
INFO - 2023-04-19 09:04:37 --> Output Class Initialized
INFO - 2023-04-19 09:04:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:04:37 --> Input Class Initialized
INFO - 2023-04-19 09:04:37 --> Language Class Initialized
INFO - 2023-04-19 09:04:37 --> Loader Class Initialized
INFO - 2023-04-19 09:04:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:04:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:04:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:04:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:04:37 --> Final output sent to browser
DEBUG - 2023-04-19 09:04:37 --> Total execution time: 0.0519
INFO - 2023-04-19 09:07:52 --> Config Class Initialized
INFO - 2023-04-19 09:07:52 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:52 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:52 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:52 --> URI Class Initialized
INFO - 2023-04-19 09:07:52 --> Router Class Initialized
INFO - 2023-04-19 09:07:52 --> Output Class Initialized
INFO - 2023-04-19 09:07:52 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:52 --> Input Class Initialized
INFO - 2023-04-19 09:07:52 --> Language Class Initialized
INFO - 2023-04-19 09:07:52 --> Loader Class Initialized
INFO - 2023-04-19 09:07:52 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:52 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:52 --> Model "Login_model" initialized
INFO - 2023-04-19 09:07:52 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:52 --> Total execution time: 0.1113
INFO - 2023-04-19 09:07:52 --> Config Class Initialized
INFO - 2023-04-19 09:07:52 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:52 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:52 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:52 --> URI Class Initialized
INFO - 2023-04-19 09:07:52 --> Router Class Initialized
INFO - 2023-04-19 09:07:52 --> Output Class Initialized
INFO - 2023-04-19 09:07:52 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:52 --> Input Class Initialized
INFO - 2023-04-19 09:07:52 --> Language Class Initialized
INFO - 2023-04-19 09:07:52 --> Loader Class Initialized
INFO - 2023-04-19 09:07:52 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:52 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:52 --> Model "Login_model" initialized
INFO - 2023-04-19 09:07:52 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:52 --> Total execution time: 0.1073
INFO - 2023-04-19 09:07:57 --> Config Class Initialized
INFO - 2023-04-19 09:07:57 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:57 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:57 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:57 --> URI Class Initialized
INFO - 2023-04-19 09:07:57 --> Router Class Initialized
INFO - 2023-04-19 09:07:57 --> Output Class Initialized
INFO - 2023-04-19 09:07:57 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:57 --> Input Class Initialized
INFO - 2023-04-19 09:07:57 --> Language Class Initialized
INFO - 2023-04-19 09:07:57 --> Loader Class Initialized
INFO - 2023-04-19 09:07:57 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:57 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:57 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:57 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:57 --> Model "Login_model" initialized
INFO - 2023-04-19 09:07:57 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:57 --> Total execution time: 0.1929
INFO - 2023-04-19 09:07:59 --> Config Class Initialized
INFO - 2023-04-19 09:07:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:59 --> URI Class Initialized
INFO - 2023-04-19 09:07:59 --> Router Class Initialized
INFO - 2023-04-19 09:07:59 --> Output Class Initialized
INFO - 2023-04-19 09:07:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:59 --> Input Class Initialized
INFO - 2023-04-19 09:07:59 --> Language Class Initialized
INFO - 2023-04-19 09:07:59 --> Loader Class Initialized
INFO - 2023-04-19 09:07:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:59 --> Total execution time: 0.0181
INFO - 2023-04-19 09:07:59 --> Config Class Initialized
INFO - 2023-04-19 09:07:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:59 --> URI Class Initialized
INFO - 2023-04-19 09:07:59 --> Router Class Initialized
INFO - 2023-04-19 09:07:59 --> Output Class Initialized
INFO - 2023-04-19 09:07:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:59 --> Input Class Initialized
INFO - 2023-04-19 09:07:59 --> Language Class Initialized
INFO - 2023-04-19 09:07:59 --> Loader Class Initialized
INFO - 2023-04-19 09:07:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:59 --> Total execution time: 0.0108
INFO - 2023-04-19 09:07:59 --> Config Class Initialized
INFO - 2023-04-19 09:07:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:59 --> URI Class Initialized
INFO - 2023-04-19 09:07:59 --> Router Class Initialized
INFO - 2023-04-19 09:07:59 --> Output Class Initialized
INFO - 2023-04-19 09:07:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:59 --> Input Class Initialized
INFO - 2023-04-19 09:07:59 --> Language Class Initialized
INFO - 2023-04-19 09:07:59 --> Loader Class Initialized
INFO - 2023-04-19 09:07:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:59 --> Total execution time: 0.0530
INFO - 2023-04-19 09:07:59 --> Config Class Initialized
INFO - 2023-04-19 09:07:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:07:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:07:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:07:59 --> URI Class Initialized
INFO - 2023-04-19 09:07:59 --> Router Class Initialized
INFO - 2023-04-19 09:07:59 --> Output Class Initialized
INFO - 2023-04-19 09:07:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:07:59 --> Input Class Initialized
INFO - 2023-04-19 09:07:59 --> Language Class Initialized
INFO - 2023-04-19 09:07:59 --> Loader Class Initialized
INFO - 2023-04-19 09:07:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:07:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:07:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:07:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:07:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:07:59 --> Total execution time: 0.0527
INFO - 2023-04-19 09:08:17 --> Config Class Initialized
INFO - 2023-04-19 09:08:17 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:17 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:17 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:17 --> URI Class Initialized
INFO - 2023-04-19 09:08:17 --> Router Class Initialized
INFO - 2023-04-19 09:08:17 --> Output Class Initialized
INFO - 2023-04-19 09:08:17 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:17 --> Input Class Initialized
INFO - 2023-04-19 09:08:17 --> Language Class Initialized
INFO - 2023-04-19 09:08:17 --> Loader Class Initialized
INFO - 2023-04-19 09:08:17 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:17 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:17 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:17 --> Model "Login_model" initialized
INFO - 2023-04-19 09:08:18 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:18 --> Total execution time: 0.2437
INFO - 2023-04-19 09:08:18 --> Config Class Initialized
INFO - 2023-04-19 09:08:18 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:18 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:18 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:18 --> URI Class Initialized
INFO - 2023-04-19 09:08:18 --> Router Class Initialized
INFO - 2023-04-19 09:08:18 --> Output Class Initialized
INFO - 2023-04-19 09:08:18 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:18 --> Input Class Initialized
INFO - 2023-04-19 09:08:18 --> Language Class Initialized
INFO - 2023-04-19 09:08:18 --> Loader Class Initialized
INFO - 2023-04-19 09:08:18 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:18 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:18 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:18 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:18 --> Model "Login_model" initialized
INFO - 2023-04-19 09:08:18 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:18 --> Total execution time: 0.0613
INFO - 2023-04-19 09:08:20 --> Config Class Initialized
INFO - 2023-04-19 09:08:20 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:20 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:20 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:20 --> URI Class Initialized
INFO - 2023-04-19 09:08:20 --> Router Class Initialized
INFO - 2023-04-19 09:08:20 --> Output Class Initialized
INFO - 2023-04-19 09:08:20 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:20 --> Input Class Initialized
INFO - 2023-04-19 09:08:20 --> Language Class Initialized
INFO - 2023-04-19 09:08:20 --> Loader Class Initialized
INFO - 2023-04-19 09:08:20 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:20 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:20 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:21 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:21 --> Total execution time: 0.0547
INFO - 2023-04-19 09:08:21 --> Config Class Initialized
INFO - 2023-04-19 09:08:21 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:21 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:21 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:21 --> URI Class Initialized
INFO - 2023-04-19 09:08:21 --> Router Class Initialized
INFO - 2023-04-19 09:08:21 --> Output Class Initialized
INFO - 2023-04-19 09:08:21 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:21 --> Input Class Initialized
INFO - 2023-04-19 09:08:21 --> Language Class Initialized
INFO - 2023-04-19 09:08:21 --> Loader Class Initialized
INFO - 2023-04-19 09:08:21 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:21 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:21 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:21 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:21 --> Total execution time: 0.0099
INFO - 2023-04-19 09:08:21 --> Config Class Initialized
INFO - 2023-04-19 09:08:21 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:21 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:21 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:21 --> URI Class Initialized
INFO - 2023-04-19 09:08:21 --> Router Class Initialized
INFO - 2023-04-19 09:08:21 --> Output Class Initialized
INFO - 2023-04-19 09:08:21 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:21 --> Input Class Initialized
INFO - 2023-04-19 09:08:21 --> Language Class Initialized
INFO - 2023-04-19 09:08:21 --> Loader Class Initialized
INFO - 2023-04-19 09:08:21 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:21 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:21 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:21 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:21 --> Total execution time: 0.0514
INFO - 2023-04-19 09:08:21 --> Config Class Initialized
INFO - 2023-04-19 09:08:21 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:21 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:21 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:21 --> URI Class Initialized
INFO - 2023-04-19 09:08:21 --> Router Class Initialized
INFO - 2023-04-19 09:08:21 --> Output Class Initialized
INFO - 2023-04-19 09:08:21 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:21 --> Input Class Initialized
INFO - 2023-04-19 09:08:21 --> Language Class Initialized
INFO - 2023-04-19 09:08:21 --> Loader Class Initialized
INFO - 2023-04-19 09:08:21 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:21 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:21 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:21 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:21 --> Total execution time: 0.0115
INFO - 2023-04-19 09:08:29 --> Config Class Initialized
INFO - 2023-04-19 09:08:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:29 --> URI Class Initialized
INFO - 2023-04-19 09:08:29 --> Router Class Initialized
INFO - 2023-04-19 09:08:29 --> Output Class Initialized
INFO - 2023-04-19 09:08:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:29 --> Input Class Initialized
INFO - 2023-04-19 09:08:29 --> Language Class Initialized
INFO - 2023-04-19 09:08:29 --> Loader Class Initialized
INFO - 2023-04-19 09:08:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:29 --> Model "Login_model" initialized
INFO - 2023-04-19 09:08:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:29 --> Total execution time: 0.1125
INFO - 2023-04-19 09:08:29 --> Config Class Initialized
INFO - 2023-04-19 09:08:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:08:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:08:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:08:29 --> URI Class Initialized
INFO - 2023-04-19 09:08:29 --> Router Class Initialized
INFO - 2023-04-19 09:08:29 --> Output Class Initialized
INFO - 2023-04-19 09:08:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:08:29 --> Input Class Initialized
INFO - 2023-04-19 09:08:29 --> Language Class Initialized
INFO - 2023-04-19 09:08:29 --> Loader Class Initialized
INFO - 2023-04-19 09:08:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:08:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:08:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:08:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:08:29 --> Model "Login_model" initialized
INFO - 2023-04-19 09:08:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:08:29 --> Total execution time: 0.0605
INFO - 2023-04-19 09:09:22 --> Config Class Initialized
INFO - 2023-04-19 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:22 --> URI Class Initialized
INFO - 2023-04-19 09:09:22 --> Router Class Initialized
INFO - 2023-04-19 09:09:22 --> Output Class Initialized
INFO - 2023-04-19 09:09:22 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:22 --> Input Class Initialized
INFO - 2023-04-19 09:09:22 --> Language Class Initialized
INFO - 2023-04-19 09:09:22 --> Loader Class Initialized
INFO - 2023-04-19 09:09:22 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:22 --> Total execution time: 0.0575
INFO - 2023-04-19 09:09:22 --> Config Class Initialized
INFO - 2023-04-19 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:22 --> URI Class Initialized
INFO - 2023-04-19 09:09:22 --> Router Class Initialized
INFO - 2023-04-19 09:09:22 --> Output Class Initialized
INFO - 2023-04-19 09:09:22 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:22 --> Input Class Initialized
INFO - 2023-04-19 09:09:22 --> Language Class Initialized
INFO - 2023-04-19 09:09:22 --> Loader Class Initialized
INFO - 2023-04-19 09:09:22 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:22 --> Total execution time: 0.0525
INFO - 2023-04-19 09:09:26 --> Config Class Initialized
INFO - 2023-04-19 09:09:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:26 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:26 --> URI Class Initialized
INFO - 2023-04-19 09:09:26 --> Router Class Initialized
INFO - 2023-04-19 09:09:26 --> Output Class Initialized
INFO - 2023-04-19 09:09:26 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:26 --> Input Class Initialized
INFO - 2023-04-19 09:09:26 --> Language Class Initialized
INFO - 2023-04-19 09:09:26 --> Loader Class Initialized
INFO - 2023-04-19 09:09:26 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:26 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:26 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:26 --> Total execution time: 0.0285
INFO - 2023-04-19 09:09:26 --> Config Class Initialized
INFO - 2023-04-19 09:09:26 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:26 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:26 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:26 --> URI Class Initialized
INFO - 2023-04-19 09:09:26 --> Router Class Initialized
INFO - 2023-04-19 09:09:26 --> Output Class Initialized
INFO - 2023-04-19 09:09:26 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:26 --> Input Class Initialized
INFO - 2023-04-19 09:09:26 --> Language Class Initialized
INFO - 2023-04-19 09:09:26 --> Loader Class Initialized
INFO - 2023-04-19 09:09:26 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:26 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:26 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:26 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:26 --> Total execution time: 0.0726
INFO - 2023-04-19 09:09:33 --> Config Class Initialized
INFO - 2023-04-19 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:33 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:33 --> URI Class Initialized
INFO - 2023-04-19 09:09:33 --> Router Class Initialized
INFO - 2023-04-19 09:09:33 --> Output Class Initialized
INFO - 2023-04-19 09:09:33 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:33 --> Input Class Initialized
INFO - 2023-04-19 09:09:33 --> Language Class Initialized
INFO - 2023-04-19 09:09:33 --> Loader Class Initialized
INFO - 2023-04-19 09:09:33 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:33 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:33 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:33 --> Total execution time: 0.0194
INFO - 2023-04-19 09:09:33 --> Config Class Initialized
INFO - 2023-04-19 09:09:33 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:33 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:33 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:33 --> URI Class Initialized
INFO - 2023-04-19 09:09:33 --> Router Class Initialized
INFO - 2023-04-19 09:09:33 --> Output Class Initialized
INFO - 2023-04-19 09:09:33 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:33 --> Input Class Initialized
INFO - 2023-04-19 09:09:33 --> Language Class Initialized
INFO - 2023-04-19 09:09:33 --> Loader Class Initialized
INFO - 2023-04-19 09:09:33 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:33 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:33 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:33 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:33 --> Total execution time: 0.0540
INFO - 2023-04-19 09:09:36 --> Config Class Initialized
INFO - 2023-04-19 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:36 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:36 --> URI Class Initialized
INFO - 2023-04-19 09:09:36 --> Router Class Initialized
INFO - 2023-04-19 09:09:36 --> Output Class Initialized
INFO - 2023-04-19 09:09:36 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:36 --> Input Class Initialized
INFO - 2023-04-19 09:09:36 --> Language Class Initialized
INFO - 2023-04-19 09:09:36 --> Loader Class Initialized
INFO - 2023-04-19 09:09:36 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:36 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:36 --> Total execution time: 0.0113
INFO - 2023-04-19 09:09:36 --> Config Class Initialized
INFO - 2023-04-19 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:36 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:36 --> URI Class Initialized
INFO - 2023-04-19 09:09:36 --> Router Class Initialized
INFO - 2023-04-19 09:09:36 --> Output Class Initialized
INFO - 2023-04-19 09:09:36 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:36 --> Input Class Initialized
INFO - 2023-04-19 09:09:36 --> Language Class Initialized
INFO - 2023-04-19 09:09:36 --> Loader Class Initialized
INFO - 2023-04-19 09:09:36 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Login_model" initialized
INFO - 2023-04-19 09:09:36 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:36 --> Total execution time: 0.0185
INFO - 2023-04-19 09:09:36 --> Config Class Initialized
INFO - 2023-04-19 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:36 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:36 --> URI Class Initialized
INFO - 2023-04-19 09:09:36 --> Router Class Initialized
INFO - 2023-04-19 09:09:36 --> Output Class Initialized
INFO - 2023-04-19 09:09:36 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:36 --> Input Class Initialized
INFO - 2023-04-19 09:09:36 --> Language Class Initialized
INFO - 2023-04-19 09:09:36 --> Loader Class Initialized
INFO - 2023-04-19 09:09:36 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:36 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:36 --> Total execution time: 0.0487
INFO - 2023-04-19 09:09:36 --> Config Class Initialized
INFO - 2023-04-19 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:36 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:36 --> URI Class Initialized
INFO - 2023-04-19 09:09:36 --> Router Class Initialized
INFO - 2023-04-19 09:09:36 --> Output Class Initialized
INFO - 2023-04-19 09:09:36 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:36 --> Input Class Initialized
INFO - 2023-04-19 09:09:36 --> Language Class Initialized
INFO - 2023-04-19 09:09:36 --> Loader Class Initialized
INFO - 2023-04-19 09:09:36 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:36 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:36 --> Model "Login_model" initialized
INFO - 2023-04-19 09:09:36 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:36 --> Total execution time: 0.0231
INFO - 2023-04-19 09:09:37 --> Config Class Initialized
INFO - 2023-04-19 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:37 --> URI Class Initialized
INFO - 2023-04-19 09:09:37 --> Router Class Initialized
INFO - 2023-04-19 09:09:37 --> Output Class Initialized
INFO - 2023-04-19 09:09:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:37 --> Input Class Initialized
INFO - 2023-04-19 09:09:37 --> Language Class Initialized
INFO - 2023-04-19 09:09:37 --> Loader Class Initialized
INFO - 2023-04-19 09:09:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:37 --> Model "Login_model" initialized
INFO - 2023-04-19 09:09:37 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:37 --> Total execution time: 0.0946
INFO - 2023-04-19 09:09:37 --> Config Class Initialized
INFO - 2023-04-19 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:37 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:37 --> URI Class Initialized
INFO - 2023-04-19 09:09:37 --> Router Class Initialized
INFO - 2023-04-19 09:09:37 --> Output Class Initialized
INFO - 2023-04-19 09:09:37 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:37 --> Input Class Initialized
INFO - 2023-04-19 09:09:37 --> Language Class Initialized
INFO - 2023-04-19 09:09:37 --> Loader Class Initialized
INFO - 2023-04-19 09:09:37 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:37 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:38 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:38 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:38 --> Model "Login_model" initialized
INFO - 2023-04-19 09:09:38 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:38 --> Total execution time: 0.0576
INFO - 2023-04-19 09:09:43 --> Config Class Initialized
INFO - 2023-04-19 09:09:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:43 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:43 --> URI Class Initialized
INFO - 2023-04-19 09:09:43 --> Router Class Initialized
INFO - 2023-04-19 09:09:43 --> Output Class Initialized
INFO - 2023-04-19 09:09:43 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:43 --> Input Class Initialized
INFO - 2023-04-19 09:09:43 --> Language Class Initialized
INFO - 2023-04-19 09:09:43 --> Loader Class Initialized
INFO - 2023-04-19 09:09:43 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:43 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:43 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:43 --> Total execution time: 0.0617
INFO - 2023-04-19 09:09:43 --> Config Class Initialized
INFO - 2023-04-19 09:09:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:43 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:43 --> URI Class Initialized
INFO - 2023-04-19 09:09:43 --> Router Class Initialized
INFO - 2023-04-19 09:09:43 --> Output Class Initialized
INFO - 2023-04-19 09:09:43 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:43 --> Input Class Initialized
INFO - 2023-04-19 09:09:43 --> Language Class Initialized
INFO - 2023-04-19 09:09:43 --> Loader Class Initialized
INFO - 2023-04-19 09:09:43 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:43 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:43 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:43 --> Total execution time: 0.0829
INFO - 2023-04-19 09:09:44 --> Config Class Initialized
INFO - 2023-04-19 09:09:44 --> Config Class Initialized
INFO - 2023-04-19 09:09:44 --> Hooks Class Initialized
INFO - 2023-04-19 09:09:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:44 --> Utf8 Class Initialized
DEBUG - 2023-04-19 09:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:44 --> URI Class Initialized
INFO - 2023-04-19 09:09:44 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:44 --> Router Class Initialized
INFO - 2023-04-19 09:09:44 --> URI Class Initialized
INFO - 2023-04-19 09:09:44 --> Output Class Initialized
INFO - 2023-04-19 09:09:44 --> Router Class Initialized
INFO - 2023-04-19 09:09:44 --> Security Class Initialized
INFO - 2023-04-19 09:09:44 --> Output Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:44 --> Input Class Initialized
INFO - 2023-04-19 09:09:44 --> Security Class Initialized
INFO - 2023-04-19 09:09:44 --> Language Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:44 --> Input Class Initialized
INFO - 2023-04-19 09:09:44 --> Loader Class Initialized
INFO - 2023-04-19 09:09:44 --> Language Class Initialized
INFO - 2023-04-19 09:09:44 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:44 --> Loader Class Initialized
INFO - 2023-04-19 09:09:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:44 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:44 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:44 --> Total execution time: 0.0149
INFO - 2023-04-19 09:09:44 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:44 --> Total execution time: 0.0166
INFO - 2023-04-19 09:09:44 --> Config Class Initialized
INFO - 2023-04-19 09:09:44 --> Config Class Initialized
INFO - 2023-04-19 09:09:44 --> Hooks Class Initialized
INFO - 2023-04-19 09:09:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:44 --> Utf8 Class Initialized
DEBUG - 2023-04-19 09:09:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:44 --> URI Class Initialized
INFO - 2023-04-19 09:09:44 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:44 --> Router Class Initialized
INFO - 2023-04-19 09:09:44 --> URI Class Initialized
INFO - 2023-04-19 09:09:44 --> Output Class Initialized
INFO - 2023-04-19 09:09:44 --> Router Class Initialized
INFO - 2023-04-19 09:09:44 --> Security Class Initialized
INFO - 2023-04-19 09:09:44 --> Output Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:44 --> Security Class Initialized
INFO - 2023-04-19 09:09:44 --> Input Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:44 --> Language Class Initialized
INFO - 2023-04-19 09:09:44 --> Input Class Initialized
INFO - 2023-04-19 09:09:44 --> Language Class Initialized
INFO - 2023-04-19 09:09:44 --> Loader Class Initialized
INFO - 2023-04-19 09:09:44 --> Loader Class Initialized
INFO - 2023-04-19 09:09:44 --> Controller Class Initialized
INFO - 2023-04-19 09:09:44 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 09:09:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:44 --> Final output sent to browser
INFO - 2023-04-19 09:09:44 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:44 --> Total execution time: 0.0544
DEBUG - 2023-04-19 09:09:44 --> Total execution time: 0.0541
INFO - 2023-04-19 09:09:47 --> Config Class Initialized
INFO - 2023-04-19 09:09:47 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:47 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:47 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:47 --> URI Class Initialized
INFO - 2023-04-19 09:09:47 --> Router Class Initialized
INFO - 2023-04-19 09:09:47 --> Output Class Initialized
INFO - 2023-04-19 09:09:47 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:47 --> Input Class Initialized
INFO - 2023-04-19 09:09:47 --> Language Class Initialized
INFO - 2023-04-19 09:09:47 --> Loader Class Initialized
INFO - 2023-04-19 09:09:47 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:47 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:47 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:47 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:47 --> Total execution time: 0.0154
INFO - 2023-04-19 09:09:47 --> Config Class Initialized
INFO - 2023-04-19 09:09:47 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:09:47 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:09:47 --> Utf8 Class Initialized
INFO - 2023-04-19 09:09:47 --> URI Class Initialized
INFO - 2023-04-19 09:09:47 --> Router Class Initialized
INFO - 2023-04-19 09:09:47 --> Output Class Initialized
INFO - 2023-04-19 09:09:47 --> Security Class Initialized
DEBUG - 2023-04-19 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:09:47 --> Input Class Initialized
INFO - 2023-04-19 09:09:47 --> Language Class Initialized
INFO - 2023-04-19 09:09:47 --> Loader Class Initialized
INFO - 2023-04-19 09:09:47 --> Controller Class Initialized
DEBUG - 2023-04-19 09:09:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:09:47 --> Database Driver Class Initialized
INFO - 2023-04-19 09:09:47 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:09:47 --> Final output sent to browser
DEBUG - 2023-04-19 09:09:47 --> Total execution time: 0.0106
INFO - 2023-04-19 09:11:13 --> Config Class Initialized
INFO - 2023-04-19 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-19 09:11:13 --> URI Class Initialized
INFO - 2023-04-19 09:11:13 --> Router Class Initialized
INFO - 2023-04-19 09:11:13 --> Output Class Initialized
INFO - 2023-04-19 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:11:13 --> Input Class Initialized
INFO - 2023-04-19 09:11:13 --> Language Class Initialized
INFO - 2023-04-19 09:11:13 --> Loader Class Initialized
INFO - 2023-04-19 09:11:13 --> Controller Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:11:13 --> Database Driver Class Initialized
INFO - 2023-04-19 09:11:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-19 09:11:13 --> Total execution time: 0.0118
INFO - 2023-04-19 09:11:13 --> Config Class Initialized
INFO - 2023-04-19 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-19 09:11:13 --> URI Class Initialized
INFO - 2023-04-19 09:11:13 --> Router Class Initialized
INFO - 2023-04-19 09:11:13 --> Output Class Initialized
INFO - 2023-04-19 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:11:13 --> Input Class Initialized
INFO - 2023-04-19 09:11:13 --> Language Class Initialized
INFO - 2023-04-19 09:11:13 --> Loader Class Initialized
INFO - 2023-04-19 09:11:13 --> Controller Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:11:13 --> Database Driver Class Initialized
INFO - 2023-04-19 09:11:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-19 09:11:13 --> Total execution time: 0.0103
INFO - 2023-04-19 09:11:13 --> Config Class Initialized
INFO - 2023-04-19 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-19 09:11:13 --> URI Class Initialized
INFO - 2023-04-19 09:11:13 --> Router Class Initialized
INFO - 2023-04-19 09:11:13 --> Output Class Initialized
INFO - 2023-04-19 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:11:13 --> Input Class Initialized
INFO - 2023-04-19 09:11:13 --> Language Class Initialized
INFO - 2023-04-19 09:11:13 --> Loader Class Initialized
INFO - 2023-04-19 09:11:13 --> Controller Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:11:13 --> Database Driver Class Initialized
INFO - 2023-04-19 09:11:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-19 09:11:13 --> Total execution time: 0.0523
INFO - 2023-04-19 09:11:13 --> Config Class Initialized
INFO - 2023-04-19 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-19 09:11:13 --> URI Class Initialized
INFO - 2023-04-19 09:11:13 --> Router Class Initialized
INFO - 2023-04-19 09:11:13 --> Output Class Initialized
INFO - 2023-04-19 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:11:13 --> Input Class Initialized
INFO - 2023-04-19 09:11:13 --> Language Class Initialized
INFO - 2023-04-19 09:11:13 --> Loader Class Initialized
INFO - 2023-04-19 09:11:13 --> Controller Class Initialized
DEBUG - 2023-04-19 09:11:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:11:13 --> Database Driver Class Initialized
INFO - 2023-04-19 09:11:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-19 09:11:13 --> Total execution time: 0.0108
INFO - 2023-04-19 09:15:32 --> Config Class Initialized
INFO - 2023-04-19 09:15:32 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:15:32 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:15:32 --> Utf8 Class Initialized
INFO - 2023-04-19 09:15:32 --> URI Class Initialized
INFO - 2023-04-19 09:15:32 --> Router Class Initialized
INFO - 2023-04-19 09:15:32 --> Output Class Initialized
INFO - 2023-04-19 09:15:32 --> Security Class Initialized
DEBUG - 2023-04-19 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:15:32 --> Input Class Initialized
INFO - 2023-04-19 09:15:32 --> Language Class Initialized
INFO - 2023-04-19 09:15:32 --> Loader Class Initialized
INFO - 2023-04-19 09:15:32 --> Controller Class Initialized
DEBUG - 2023-04-19 09:15:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:15:32 --> Database Driver Class Initialized
INFO - 2023-04-19 09:15:32 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:15:32 --> Database Driver Class Initialized
INFO - 2023-04-19 09:15:32 --> Model "Login_model" initialized
INFO - 2023-04-19 09:15:32 --> Final output sent to browser
DEBUG - 2023-04-19 09:15:32 --> Total execution time: 0.0729
INFO - 2023-04-19 09:15:32 --> Config Class Initialized
INFO - 2023-04-19 09:15:32 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:15:32 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:15:32 --> Utf8 Class Initialized
INFO - 2023-04-19 09:15:32 --> URI Class Initialized
INFO - 2023-04-19 09:15:32 --> Router Class Initialized
INFO - 2023-04-19 09:15:32 --> Output Class Initialized
INFO - 2023-04-19 09:15:32 --> Security Class Initialized
DEBUG - 2023-04-19 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:15:32 --> Input Class Initialized
INFO - 2023-04-19 09:15:32 --> Language Class Initialized
INFO - 2023-04-19 09:15:32 --> Loader Class Initialized
INFO - 2023-04-19 09:15:32 --> Controller Class Initialized
DEBUG - 2023-04-19 09:15:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:15:32 --> Database Driver Class Initialized
INFO - 2023-04-19 09:15:32 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:15:33 --> Database Driver Class Initialized
INFO - 2023-04-19 09:15:33 --> Model "Login_model" initialized
INFO - 2023-04-19 09:15:33 --> Final output sent to browser
DEBUG - 2023-04-19 09:15:33 --> Total execution time: 0.1065
INFO - 2023-04-19 09:23:45 --> Config Class Initialized
INFO - 2023-04-19 09:23:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:23:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:23:45 --> Utf8 Class Initialized
INFO - 2023-04-19 09:23:45 --> URI Class Initialized
INFO - 2023-04-19 09:23:45 --> Router Class Initialized
INFO - 2023-04-19 09:23:45 --> Output Class Initialized
INFO - 2023-04-19 09:23:45 --> Security Class Initialized
DEBUG - 2023-04-19 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:23:45 --> Input Class Initialized
INFO - 2023-04-19 09:23:45 --> Language Class Initialized
INFO - 2023-04-19 09:23:45 --> Loader Class Initialized
INFO - 2023-04-19 09:23:45 --> Controller Class Initialized
DEBUG - 2023-04-19 09:23:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:23:45 --> Database Driver Class Initialized
INFO - 2023-04-19 09:23:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:23:45 --> Database Driver Class Initialized
INFO - 2023-04-19 09:23:45 --> Model "Login_model" initialized
INFO - 2023-04-19 09:23:45 --> Final output sent to browser
DEBUG - 2023-04-19 09:23:45 --> Total execution time: 0.1279
INFO - 2023-04-19 09:23:45 --> Config Class Initialized
INFO - 2023-04-19 09:23:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:23:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:23:45 --> Utf8 Class Initialized
INFO - 2023-04-19 09:23:45 --> URI Class Initialized
INFO - 2023-04-19 09:23:45 --> Router Class Initialized
INFO - 2023-04-19 09:23:45 --> Output Class Initialized
INFO - 2023-04-19 09:23:45 --> Security Class Initialized
DEBUG - 2023-04-19 09:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:23:45 --> Input Class Initialized
INFO - 2023-04-19 09:23:45 --> Language Class Initialized
INFO - 2023-04-19 09:23:45 --> Loader Class Initialized
INFO - 2023-04-19 09:23:45 --> Controller Class Initialized
DEBUG - 2023-04-19 09:23:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:23:45 --> Database Driver Class Initialized
INFO - 2023-04-19 09:23:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:23:45 --> Database Driver Class Initialized
INFO - 2023-04-19 09:23:45 --> Model "Login_model" initialized
INFO - 2023-04-19 09:23:45 --> Final output sent to browser
DEBUG - 2023-04-19 09:23:45 --> Total execution time: 0.1076
INFO - 2023-04-19 09:24:08 --> Config Class Initialized
INFO - 2023-04-19 09:24:08 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:08 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:08 --> URI Class Initialized
INFO - 2023-04-19 09:24:08 --> Router Class Initialized
INFO - 2023-04-19 09:24:08 --> Output Class Initialized
INFO - 2023-04-19 09:24:08 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:08 --> Input Class Initialized
INFO - 2023-04-19 09:24:08 --> Language Class Initialized
INFO - 2023-04-19 09:24:08 --> Loader Class Initialized
INFO - 2023-04-19 09:24:08 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:08 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:08 --> Model "Login_model" initialized
INFO - 2023-04-19 09:24:08 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:08 --> Total execution time: 0.1187
INFO - 2023-04-19 09:24:08 --> Config Class Initialized
INFO - 2023-04-19 09:24:08 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:08 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:08 --> URI Class Initialized
INFO - 2023-04-19 09:24:08 --> Router Class Initialized
INFO - 2023-04-19 09:24:08 --> Output Class Initialized
INFO - 2023-04-19 09:24:08 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:08 --> Input Class Initialized
INFO - 2023-04-19 09:24:08 --> Language Class Initialized
INFO - 2023-04-19 09:24:08 --> Loader Class Initialized
INFO - 2023-04-19 09:24:08 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:08 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:08 --> Model "Login_model" initialized
INFO - 2023-04-19 09:24:08 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:08 --> Total execution time: 0.1555
INFO - 2023-04-19 09:24:29 --> Config Class Initialized
INFO - 2023-04-19 09:24:29 --> Config Class Initialized
INFO - 2023-04-19 09:24:29 --> Hooks Class Initialized
INFO - 2023-04-19 09:24:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:29 --> Utf8 Class Initialized
DEBUG - 2023-04-19 09:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:29 --> URI Class Initialized
INFO - 2023-04-19 09:24:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:29 --> Router Class Initialized
INFO - 2023-04-19 09:24:29 --> URI Class Initialized
INFO - 2023-04-19 09:24:29 --> Output Class Initialized
INFO - 2023-04-19 09:24:29 --> Router Class Initialized
INFO - 2023-04-19 09:24:29 --> Security Class Initialized
INFO - 2023-04-19 09:24:29 --> Output Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:29 --> Security Class Initialized
INFO - 2023-04-19 09:24:29 --> Input Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:29 --> Language Class Initialized
INFO - 2023-04-19 09:24:29 --> Input Class Initialized
INFO - 2023-04-19 09:24:29 --> Language Class Initialized
INFO - 2023-04-19 09:24:29 --> Loader Class Initialized
INFO - 2023-04-19 09:24:29 --> Loader Class Initialized
INFO - 2023-04-19 09:24:29 --> Controller Class Initialized
INFO - 2023-04-19 09:24:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 09:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:29 --> Final output sent to browser
INFO - 2023-04-19 09:24:29 --> Database Driver Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Total execution time: 0.0067
INFO - 2023-04-19 09:24:29 --> Config Class Initialized
INFO - 2023-04-19 09:24:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:29 --> URI Class Initialized
INFO - 2023-04-19 09:24:29 --> Router Class Initialized
INFO - 2023-04-19 09:24:29 --> Output Class Initialized
INFO - 2023-04-19 09:24:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:29 --> Input Class Initialized
INFO - 2023-04-19 09:24:29 --> Language Class Initialized
INFO - 2023-04-19 09:24:29 --> Loader Class Initialized
INFO - 2023-04-19 09:24:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:29 --> Total execution time: 0.0557
INFO - 2023-04-19 09:24:29 --> Config Class Initialized
INFO - 2023-04-19 09:24:29 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:29 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:29 --> URI Class Initialized
INFO - 2023-04-19 09:24:29 --> Router Class Initialized
INFO - 2023-04-19 09:24:29 --> Output Class Initialized
INFO - 2023-04-19 09:24:29 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:29 --> Input Class Initialized
INFO - 2023-04-19 09:24:29 --> Language Class Initialized
INFO - 2023-04-19 09:24:29 --> Loader Class Initialized
INFO - 2023-04-19 09:24:29 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:29 --> Model "Login_model" initialized
INFO - 2023-04-19 09:24:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:29 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:29 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:29 --> Final output sent to browser
INFO - 2023-04-19 09:24:29 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:29 --> Total execution time: 0.0659
DEBUG - 2023-04-19 09:24:29 --> Total execution time: 0.0158
INFO - 2023-04-19 09:24:30 --> Config Class Initialized
INFO - 2023-04-19 09:24:30 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:30 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:30 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:30 --> URI Class Initialized
INFO - 2023-04-19 09:24:30 --> Router Class Initialized
INFO - 2023-04-19 09:24:30 --> Output Class Initialized
INFO - 2023-04-19 09:24:30 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:30 --> Input Class Initialized
INFO - 2023-04-19 09:24:30 --> Language Class Initialized
INFO - 2023-04-19 09:24:30 --> Loader Class Initialized
INFO - 2023-04-19 09:24:30 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:30 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:30 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:30 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:30 --> Model "Login_model" initialized
INFO - 2023-04-19 09:24:30 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:30 --> Total execution time: 0.0639
INFO - 2023-04-19 09:24:30 --> Config Class Initialized
INFO - 2023-04-19 09:24:30 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:24:30 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:24:30 --> Utf8 Class Initialized
INFO - 2023-04-19 09:24:30 --> URI Class Initialized
INFO - 2023-04-19 09:24:30 --> Router Class Initialized
INFO - 2023-04-19 09:24:30 --> Output Class Initialized
INFO - 2023-04-19 09:24:30 --> Security Class Initialized
DEBUG - 2023-04-19 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:24:30 --> Input Class Initialized
INFO - 2023-04-19 09:24:30 --> Language Class Initialized
INFO - 2023-04-19 09:24:30 --> Loader Class Initialized
INFO - 2023-04-19 09:24:30 --> Controller Class Initialized
DEBUG - 2023-04-19 09:24:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:24:30 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:30 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:24:30 --> Database Driver Class Initialized
INFO - 2023-04-19 09:24:30 --> Model "Login_model" initialized
INFO - 2023-04-19 09:24:31 --> Final output sent to browser
DEBUG - 2023-04-19 09:24:31 --> Total execution time: 0.0612
INFO - 2023-04-19 09:26:44 --> Config Class Initialized
INFO - 2023-04-19 09:26:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:44 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:44 --> URI Class Initialized
INFO - 2023-04-19 09:26:44 --> Router Class Initialized
INFO - 2023-04-19 09:26:44 --> Output Class Initialized
INFO - 2023-04-19 09:26:44 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:44 --> Input Class Initialized
INFO - 2023-04-19 09:26:44 --> Language Class Initialized
INFO - 2023-04-19 09:26:44 --> Loader Class Initialized
INFO - 2023-04-19 09:26:44 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:44 --> Model "Login_model" initialized
INFO - 2023-04-19 09:26:44 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:44 --> Total execution time: 0.0841
INFO - 2023-04-19 09:26:44 --> Config Class Initialized
INFO - 2023-04-19 09:26:44 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:44 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:44 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:44 --> URI Class Initialized
INFO - 2023-04-19 09:26:44 --> Router Class Initialized
INFO - 2023-04-19 09:26:44 --> Output Class Initialized
INFO - 2023-04-19 09:26:44 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:44 --> Input Class Initialized
INFO - 2023-04-19 09:26:44 --> Language Class Initialized
INFO - 2023-04-19 09:26:44 --> Loader Class Initialized
INFO - 2023-04-19 09:26:44 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:44 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:44 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:44 --> Model "Login_model" initialized
INFO - 2023-04-19 09:26:44 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:44 --> Total execution time: 0.0619
INFO - 2023-04-19 09:26:52 --> Config Class Initialized
INFO - 2023-04-19 09:26:52 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:52 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:52 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:52 --> URI Class Initialized
INFO - 2023-04-19 09:26:52 --> Router Class Initialized
INFO - 2023-04-19 09:26:52 --> Output Class Initialized
INFO - 2023-04-19 09:26:52 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:52 --> Input Class Initialized
INFO - 2023-04-19 09:26:52 --> Language Class Initialized
INFO - 2023-04-19 09:26:52 --> Loader Class Initialized
INFO - 2023-04-19 09:26:52 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:52 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:52 --> Model "Login_model" initialized
INFO - 2023-04-19 09:26:52 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:52 --> Total execution time: 0.1008
INFO - 2023-04-19 09:26:52 --> Config Class Initialized
INFO - 2023-04-19 09:26:52 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:52 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:52 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:52 --> URI Class Initialized
INFO - 2023-04-19 09:26:52 --> Router Class Initialized
INFO - 2023-04-19 09:26:52 --> Output Class Initialized
INFO - 2023-04-19 09:26:52 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:52 --> Input Class Initialized
INFO - 2023-04-19 09:26:52 --> Language Class Initialized
INFO - 2023-04-19 09:26:52 --> Loader Class Initialized
INFO - 2023-04-19 09:26:52 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:52 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:52 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:52 --> Model "Login_model" initialized
INFO - 2023-04-19 09:26:52 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:52 --> Total execution time: 0.1024
INFO - 2023-04-19 09:26:59 --> Config Class Initialized
INFO - 2023-04-19 09:26:59 --> Config Class Initialized
INFO - 2023-04-19 09:26:59 --> Hooks Class Initialized
INFO - 2023-04-19 09:26:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:59 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 09:26:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:59 --> URI Class Initialized
INFO - 2023-04-19 09:26:59 --> URI Class Initialized
INFO - 2023-04-19 09:26:59 --> Router Class Initialized
INFO - 2023-04-19 09:26:59 --> Router Class Initialized
INFO - 2023-04-19 09:26:59 --> Output Class Initialized
INFO - 2023-04-19 09:26:59 --> Output Class Initialized
INFO - 2023-04-19 09:26:59 --> Security Class Initialized
INFO - 2023-04-19 09:26:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-19 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:59 --> Input Class Initialized
INFO - 2023-04-19 09:26:59 --> Input Class Initialized
INFO - 2023-04-19 09:26:59 --> Language Class Initialized
INFO - 2023-04-19 09:26:59 --> Language Class Initialized
INFO - 2023-04-19 09:26:59 --> Loader Class Initialized
INFO - 2023-04-19 09:26:59 --> Loader Class Initialized
INFO - 2023-04-19 09:26:59 --> Controller Class Initialized
INFO - 2023-04-19 09:26:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 09:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:59 --> Final output sent to browser
INFO - 2023-04-19 09:26:59 --> Database Driver Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Total execution time: 0.0043
INFO - 2023-04-19 09:26:59 --> Config Class Initialized
INFO - 2023-04-19 09:26:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:59 --> URI Class Initialized
INFO - 2023-04-19 09:26:59 --> Router Class Initialized
INFO - 2023-04-19 09:26:59 --> Output Class Initialized
INFO - 2023-04-19 09:26:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:59 --> Input Class Initialized
INFO - 2023-04-19 09:26:59 --> Language Class Initialized
INFO - 2023-04-19 09:26:59 --> Loader Class Initialized
INFO - 2023-04-19 09:26:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:59 --> Model "Login_model" initialized
INFO - 2023-04-19 09:26:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:59 --> Total execution time: 0.0243
INFO - 2023-04-19 09:26:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:59 --> Config Class Initialized
INFO - 2023-04-19 09:26:59 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:26:59 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:26:59 --> Utf8 Class Initialized
INFO - 2023-04-19 09:26:59 --> URI Class Initialized
INFO - 2023-04-19 09:26:59 --> Router Class Initialized
INFO - 2023-04-19 09:26:59 --> Output Class Initialized
INFO - 2023-04-19 09:26:59 --> Security Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:26:59 --> Input Class Initialized
INFO - 2023-04-19 09:26:59 --> Language Class Initialized
INFO - 2023-04-19 09:26:59 --> Loader Class Initialized
INFO - 2023-04-19 09:26:59 --> Controller Class Initialized
DEBUG - 2023-04-19 09:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:26:59 --> Database Driver Class Initialized
INFO - 2023-04-19 09:26:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:59 --> Total execution time: 0.0299
INFO - 2023-04-19 09:26:59 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:26:59 --> Final output sent to browser
DEBUG - 2023-04-19 09:26:59 --> Total execution time: 0.0549
INFO - 2023-04-19 09:27:01 --> Config Class Initialized
INFO - 2023-04-19 09:27:01 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:01 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:01 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:01 --> URI Class Initialized
INFO - 2023-04-19 09:27:01 --> Router Class Initialized
INFO - 2023-04-19 09:27:01 --> Output Class Initialized
INFO - 2023-04-19 09:27:01 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:01 --> Input Class Initialized
INFO - 2023-04-19 09:27:01 --> Language Class Initialized
INFO - 2023-04-19 09:27:01 --> Loader Class Initialized
INFO - 2023-04-19 09:27:01 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:01 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:01 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:02 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:02 --> Total execution time: 0.0440
INFO - 2023-04-19 09:27:02 --> Config Class Initialized
INFO - 2023-04-19 09:27:02 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:02 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:02 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:02 --> URI Class Initialized
INFO - 2023-04-19 09:27:02 --> Router Class Initialized
INFO - 2023-04-19 09:27:02 --> Output Class Initialized
INFO - 2023-04-19 09:27:02 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:02 --> Input Class Initialized
INFO - 2023-04-19 09:27:02 --> Language Class Initialized
INFO - 2023-04-19 09:27:02 --> Loader Class Initialized
INFO - 2023-04-19 09:27:02 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:02 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:02 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:02 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:02 --> Total execution time: 0.0837
INFO - 2023-04-19 09:27:04 --> Config Class Initialized
INFO - 2023-04-19 09:27:04 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:04 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:04 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:04 --> URI Class Initialized
INFO - 2023-04-19 09:27:04 --> Router Class Initialized
INFO - 2023-04-19 09:27:04 --> Output Class Initialized
INFO - 2023-04-19 09:27:04 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:05 --> Input Class Initialized
INFO - 2023-04-19 09:27:05 --> Language Class Initialized
INFO - 2023-04-19 09:27:05 --> Loader Class Initialized
INFO - 2023-04-19 09:27:05 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:05 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:05 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:05 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:05 --> Model "Login_model" initialized
INFO - 2023-04-19 09:27:05 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:05 --> Total execution time: 0.0868
INFO - 2023-04-19 09:27:05 --> Config Class Initialized
INFO - 2023-04-19 09:27:05 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:05 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:05 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:05 --> URI Class Initialized
INFO - 2023-04-19 09:27:05 --> Router Class Initialized
INFO - 2023-04-19 09:27:05 --> Output Class Initialized
INFO - 2023-04-19 09:27:05 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:05 --> Input Class Initialized
INFO - 2023-04-19 09:27:05 --> Language Class Initialized
INFO - 2023-04-19 09:27:05 --> Loader Class Initialized
INFO - 2023-04-19 09:27:05 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:05 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:05 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:05 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:05 --> Model "Login_model" initialized
INFO - 2023-04-19 09:27:05 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:05 --> Total execution time: 0.0591
INFO - 2023-04-19 09:27:06 --> Config Class Initialized
INFO - 2023-04-19 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:06 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:06 --> URI Class Initialized
INFO - 2023-04-19 09:27:06 --> Router Class Initialized
INFO - 2023-04-19 09:27:06 --> Output Class Initialized
INFO - 2023-04-19 09:27:06 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:06 --> Input Class Initialized
INFO - 2023-04-19 09:27:06 --> Language Class Initialized
INFO - 2023-04-19 09:27:06 --> Loader Class Initialized
INFO - 2023-04-19 09:27:06 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:06 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:06 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:06 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:06 --> Total execution time: 0.0145
INFO - 2023-04-19 09:27:06 --> Config Class Initialized
INFO - 2023-04-19 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:06 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:06 --> URI Class Initialized
INFO - 2023-04-19 09:27:06 --> Router Class Initialized
INFO - 2023-04-19 09:27:06 --> Output Class Initialized
INFO - 2023-04-19 09:27:06 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:06 --> Input Class Initialized
INFO - 2023-04-19 09:27:06 --> Language Class Initialized
INFO - 2023-04-19 09:27:06 --> Loader Class Initialized
INFO - 2023-04-19 09:27:06 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:06 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:06 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:06 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:06 --> Total execution time: 0.0551
INFO - 2023-04-19 09:27:06 --> Config Class Initialized
INFO - 2023-04-19 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:06 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:06 --> URI Class Initialized
INFO - 2023-04-19 09:27:06 --> Router Class Initialized
INFO - 2023-04-19 09:27:06 --> Output Class Initialized
INFO - 2023-04-19 09:27:06 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:06 --> Input Class Initialized
INFO - 2023-04-19 09:27:06 --> Language Class Initialized
INFO - 2023-04-19 09:27:06 --> Loader Class Initialized
INFO - 2023-04-19 09:27:06 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:06 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:06 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:06 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:06 --> Total execution time: 0.0523
INFO - 2023-04-19 09:27:06 --> Config Class Initialized
INFO - 2023-04-19 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-04-19 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-04-19 09:27:06 --> Utf8 Class Initialized
INFO - 2023-04-19 09:27:06 --> URI Class Initialized
INFO - 2023-04-19 09:27:06 --> Router Class Initialized
INFO - 2023-04-19 09:27:06 --> Output Class Initialized
INFO - 2023-04-19 09:27:06 --> Security Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 09:27:06 --> Input Class Initialized
INFO - 2023-04-19 09:27:06 --> Language Class Initialized
INFO - 2023-04-19 09:27:06 --> Loader Class Initialized
INFO - 2023-04-19 09:27:06 --> Controller Class Initialized
DEBUG - 2023-04-19 09:27:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 09:27:06 --> Database Driver Class Initialized
INFO - 2023-04-19 09:27:06 --> Model "Cluster_model" initialized
INFO - 2023-04-19 09:27:06 --> Final output sent to browser
DEBUG - 2023-04-19 09:27:06 --> Total execution time: 0.0532
INFO - 2023-04-19 10:01:13 --> Config Class Initialized
INFO - 2023-04-19 10:01:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:01:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:01:13 --> Utf8 Class Initialized
INFO - 2023-04-19 10:01:13 --> URI Class Initialized
INFO - 2023-04-19 10:01:13 --> Router Class Initialized
INFO - 2023-04-19 10:01:13 --> Output Class Initialized
INFO - 2023-04-19 10:01:13 --> Security Class Initialized
DEBUG - 2023-04-19 10:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:01:13 --> Input Class Initialized
INFO - 2023-04-19 10:01:13 --> Language Class Initialized
INFO - 2023-04-19 10:01:13 --> Loader Class Initialized
INFO - 2023-04-19 10:01:13 --> Controller Class Initialized
DEBUG - 2023-04-19 10:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:01:13 --> Database Driver Class Initialized
INFO - 2023-04-19 10:01:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:01:13 --> Database Driver Class Initialized
INFO - 2023-04-19 10:01:13 --> Model "Login_model" initialized
INFO - 2023-04-19 10:01:13 --> Final output sent to browser
DEBUG - 2023-04-19 10:01:13 --> Total execution time: 0.1021
INFO - 2023-04-19 10:01:13 --> Config Class Initialized
INFO - 2023-04-19 10:01:13 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:01:13 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:01:13 --> Utf8 Class Initialized
INFO - 2023-04-19 10:01:13 --> URI Class Initialized
INFO - 2023-04-19 10:01:13 --> Router Class Initialized
INFO - 2023-04-19 10:01:13 --> Output Class Initialized
INFO - 2023-04-19 10:01:13 --> Security Class Initialized
DEBUG - 2023-04-19 10:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:01:13 --> Input Class Initialized
INFO - 2023-04-19 10:01:13 --> Language Class Initialized
INFO - 2023-04-19 10:01:13 --> Loader Class Initialized
INFO - 2023-04-19 10:01:13 --> Controller Class Initialized
DEBUG - 2023-04-19 10:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:01:13 --> Database Driver Class Initialized
INFO - 2023-04-19 10:01:13 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:01:13 --> Database Driver Class Initialized
INFO - 2023-04-19 10:01:13 --> Model "Login_model" initialized
INFO - 2023-04-19 10:01:13 --> Final output sent to browser
DEBUG - 2023-04-19 10:01:13 --> Total execution time: 0.1003
INFO - 2023-04-19 10:08:50 --> Config Class Initialized
INFO - 2023-04-19 10:08:50 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:08:50 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:08:50 --> Utf8 Class Initialized
INFO - 2023-04-19 10:08:50 --> URI Class Initialized
INFO - 2023-04-19 10:08:50 --> Router Class Initialized
INFO - 2023-04-19 10:08:50 --> Output Class Initialized
INFO - 2023-04-19 10:08:50 --> Security Class Initialized
DEBUG - 2023-04-19 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:08:50 --> Input Class Initialized
INFO - 2023-04-19 10:08:50 --> Language Class Initialized
INFO - 2023-04-19 10:08:50 --> Loader Class Initialized
INFO - 2023-04-19 10:08:50 --> Controller Class Initialized
DEBUG - 2023-04-19 10:08:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:08:50 --> Database Driver Class Initialized
INFO - 2023-04-19 10:08:50 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:08:50 --> Database Driver Class Initialized
INFO - 2023-04-19 10:08:50 --> Model "Login_model" initialized
INFO - 2023-04-19 10:08:50 --> Final output sent to browser
DEBUG - 2023-04-19 10:08:50 --> Total execution time: 0.1132
INFO - 2023-04-19 10:08:50 --> Config Class Initialized
INFO - 2023-04-19 10:08:50 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:08:50 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:08:50 --> Utf8 Class Initialized
INFO - 2023-04-19 10:08:50 --> URI Class Initialized
INFO - 2023-04-19 10:08:50 --> Router Class Initialized
INFO - 2023-04-19 10:08:50 --> Output Class Initialized
INFO - 2023-04-19 10:08:50 --> Security Class Initialized
DEBUG - 2023-04-19 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:08:50 --> Input Class Initialized
INFO - 2023-04-19 10:08:50 --> Language Class Initialized
INFO - 2023-04-19 10:08:50 --> Loader Class Initialized
INFO - 2023-04-19 10:08:50 --> Controller Class Initialized
DEBUG - 2023-04-19 10:08:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:08:50 --> Database Driver Class Initialized
INFO - 2023-04-19 10:08:50 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:08:50 --> Database Driver Class Initialized
INFO - 2023-04-19 10:08:50 --> Model "Login_model" initialized
INFO - 2023-04-19 10:08:50 --> Final output sent to browser
DEBUG - 2023-04-19 10:08:50 --> Total execution time: 0.0685
INFO - 2023-04-19 10:09:22 --> Config Class Initialized
INFO - 2023-04-19 10:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:09:22 --> Utf8 Class Initialized
INFO - 2023-04-19 10:09:22 --> URI Class Initialized
INFO - 2023-04-19 10:09:22 --> Router Class Initialized
INFO - 2023-04-19 10:09:22 --> Output Class Initialized
INFO - 2023-04-19 10:09:22 --> Security Class Initialized
DEBUG - 2023-04-19 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:09:22 --> Input Class Initialized
INFO - 2023-04-19 10:09:22 --> Language Class Initialized
INFO - 2023-04-19 10:09:22 --> Loader Class Initialized
INFO - 2023-04-19 10:09:22 --> Controller Class Initialized
DEBUG - 2023-04-19 10:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 10:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 10:09:22 --> Model "Login_model" initialized
INFO - 2023-04-19 10:09:22 --> Final output sent to browser
DEBUG - 2023-04-19 10:09:22 --> Total execution time: 0.1293
INFO - 2023-04-19 10:09:22 --> Config Class Initialized
INFO - 2023-04-19 10:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:09:22 --> Utf8 Class Initialized
INFO - 2023-04-19 10:09:22 --> URI Class Initialized
INFO - 2023-04-19 10:09:22 --> Router Class Initialized
INFO - 2023-04-19 10:09:22 --> Output Class Initialized
INFO - 2023-04-19 10:09:22 --> Security Class Initialized
DEBUG - 2023-04-19 10:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:09:22 --> Input Class Initialized
INFO - 2023-04-19 10:09:22 --> Language Class Initialized
INFO - 2023-04-19 10:09:22 --> Loader Class Initialized
INFO - 2023-04-19 10:09:22 --> Controller Class Initialized
DEBUG - 2023-04-19 10:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 10:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:09:22 --> Database Driver Class Initialized
INFO - 2023-04-19 10:09:22 --> Model "Login_model" initialized
INFO - 2023-04-19 10:09:22 --> Final output sent to browser
DEBUG - 2023-04-19 10:09:22 --> Total execution time: 0.0632
INFO - 2023-04-19 10:10:15 --> Config Class Initialized
INFO - 2023-04-19 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:15 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:15 --> URI Class Initialized
INFO - 2023-04-19 10:10:15 --> Router Class Initialized
INFO - 2023-04-19 10:10:15 --> Output Class Initialized
INFO - 2023-04-19 10:10:15 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:15 --> Input Class Initialized
INFO - 2023-04-19 10:10:15 --> Language Class Initialized
INFO - 2023-04-19 10:10:15 --> Loader Class Initialized
INFO - 2023-04-19 10:10:15 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:15 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:15 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:15 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:15 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:15 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:15 --> Total execution time: 0.1726
INFO - 2023-04-19 10:10:15 --> Config Class Initialized
INFO - 2023-04-19 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:15 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:15 --> URI Class Initialized
INFO - 2023-04-19 10:10:15 --> Router Class Initialized
INFO - 2023-04-19 10:10:15 --> Output Class Initialized
INFO - 2023-04-19 10:10:15 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:15 --> Input Class Initialized
INFO - 2023-04-19 10:10:15 --> Language Class Initialized
INFO - 2023-04-19 10:10:15 --> Loader Class Initialized
INFO - 2023-04-19 10:10:15 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:15 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:15 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:15 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:15 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:15 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:15 --> Total execution time: 0.0730
INFO - 2023-04-19 10:10:28 --> Config Class Initialized
INFO - 2023-04-19 10:10:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:28 --> URI Class Initialized
INFO - 2023-04-19 10:10:28 --> Router Class Initialized
INFO - 2023-04-19 10:10:28 --> Output Class Initialized
INFO - 2023-04-19 10:10:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:28 --> Input Class Initialized
INFO - 2023-04-19 10:10:28 --> Language Class Initialized
INFO - 2023-04-19 10:10:28 --> Loader Class Initialized
INFO - 2023-04-19 10:10:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:28 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:28 --> Total execution time: 0.1068
INFO - 2023-04-19 10:10:28 --> Config Class Initialized
INFO - 2023-04-19 10:10:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:28 --> URI Class Initialized
INFO - 2023-04-19 10:10:28 --> Router Class Initialized
INFO - 2023-04-19 10:10:28 --> Output Class Initialized
INFO - 2023-04-19 10:10:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:28 --> Input Class Initialized
INFO - 2023-04-19 10:10:28 --> Language Class Initialized
INFO - 2023-04-19 10:10:28 --> Loader Class Initialized
INFO - 2023-04-19 10:10:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:28 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:28 --> Total execution time: 0.0664
INFO - 2023-04-19 10:10:44 --> Config Class Initialized
INFO - 2023-04-19 10:10:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:45 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:45 --> URI Class Initialized
INFO - 2023-04-19 10:10:45 --> Router Class Initialized
INFO - 2023-04-19 10:10:45 --> Output Class Initialized
INFO - 2023-04-19 10:10:45 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:45 --> Input Class Initialized
INFO - 2023-04-19 10:10:45 --> Language Class Initialized
INFO - 2023-04-19 10:10:45 --> Loader Class Initialized
INFO - 2023-04-19 10:10:45 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:45 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:45 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:45 --> Total execution time: 0.1180
INFO - 2023-04-19 10:10:45 --> Config Class Initialized
INFO - 2023-04-19 10:10:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:10:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:10:45 --> Utf8 Class Initialized
INFO - 2023-04-19 10:10:45 --> URI Class Initialized
INFO - 2023-04-19 10:10:45 --> Router Class Initialized
INFO - 2023-04-19 10:10:45 --> Output Class Initialized
INFO - 2023-04-19 10:10:45 --> Security Class Initialized
DEBUG - 2023-04-19 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:10:45 --> Input Class Initialized
INFO - 2023-04-19 10:10:45 --> Language Class Initialized
INFO - 2023-04-19 10:10:45 --> Loader Class Initialized
INFO - 2023-04-19 10:10:45 --> Controller Class Initialized
DEBUG - 2023-04-19 10:10:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:10:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:10:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:10:45 --> Model "Login_model" initialized
INFO - 2023-04-19 10:10:45 --> Final output sent to browser
DEBUG - 2023-04-19 10:10:45 --> Total execution time: 0.0588
INFO - 2023-04-19 10:11:09 --> Config Class Initialized
INFO - 2023-04-19 10:11:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:11:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:11:09 --> Utf8 Class Initialized
INFO - 2023-04-19 10:11:09 --> URI Class Initialized
INFO - 2023-04-19 10:11:09 --> Router Class Initialized
INFO - 2023-04-19 10:11:09 --> Output Class Initialized
INFO - 2023-04-19 10:11:09 --> Security Class Initialized
DEBUG - 2023-04-19 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:11:09 --> Input Class Initialized
INFO - 2023-04-19 10:11:09 --> Language Class Initialized
INFO - 2023-04-19 10:11:09 --> Loader Class Initialized
INFO - 2023-04-19 10:11:09 --> Controller Class Initialized
DEBUG - 2023-04-19 10:11:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:11:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:11:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:11:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:11:09 --> Model "Login_model" initialized
INFO - 2023-04-19 10:11:09 --> Final output sent to browser
DEBUG - 2023-04-19 10:11:09 --> Total execution time: 0.1873
INFO - 2023-04-19 10:11:09 --> Config Class Initialized
INFO - 2023-04-19 10:11:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:11:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:11:09 --> Utf8 Class Initialized
INFO - 2023-04-19 10:11:09 --> URI Class Initialized
INFO - 2023-04-19 10:11:09 --> Router Class Initialized
INFO - 2023-04-19 10:11:09 --> Output Class Initialized
INFO - 2023-04-19 10:11:09 --> Security Class Initialized
DEBUG - 2023-04-19 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:11:09 --> Input Class Initialized
INFO - 2023-04-19 10:11:09 --> Language Class Initialized
INFO - 2023-04-19 10:11:09 --> Loader Class Initialized
INFO - 2023-04-19 10:11:09 --> Controller Class Initialized
DEBUG - 2023-04-19 10:11:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:11:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:11:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:11:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:11:09 --> Model "Login_model" initialized
INFO - 2023-04-19 10:11:09 --> Final output sent to browser
DEBUG - 2023-04-19 10:11:09 --> Total execution time: 0.0631
INFO - 2023-04-19 10:15:28 --> Config Class Initialized
INFO - 2023-04-19 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:15:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:15:28 --> URI Class Initialized
INFO - 2023-04-19 10:15:28 --> Router Class Initialized
INFO - 2023-04-19 10:15:28 --> Output Class Initialized
INFO - 2023-04-19 10:15:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:15:28 --> Input Class Initialized
INFO - 2023-04-19 10:15:28 --> Language Class Initialized
INFO - 2023-04-19 10:15:28 --> Loader Class Initialized
INFO - 2023-04-19 10:15:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:15:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:15:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:15:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:15:28 --> Total execution time: 0.0125
INFO - 2023-04-19 10:15:28 --> Config Class Initialized
INFO - 2023-04-19 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:15:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:15:28 --> URI Class Initialized
INFO - 2023-04-19 10:15:28 --> Router Class Initialized
INFO - 2023-04-19 10:15:28 --> Output Class Initialized
INFO - 2023-04-19 10:15:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:15:28 --> Input Class Initialized
INFO - 2023-04-19 10:15:28 --> Language Class Initialized
INFO - 2023-04-19 10:15:28 --> Loader Class Initialized
INFO - 2023-04-19 10:15:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:15:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:15:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:15:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:15:28 --> Total execution time: 0.0527
INFO - 2023-04-19 10:15:28 --> Config Class Initialized
INFO - 2023-04-19 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:15:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:15:28 --> URI Class Initialized
INFO - 2023-04-19 10:15:28 --> Router Class Initialized
INFO - 2023-04-19 10:15:28 --> Output Class Initialized
INFO - 2023-04-19 10:15:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:15:28 --> Input Class Initialized
INFO - 2023-04-19 10:15:28 --> Language Class Initialized
INFO - 2023-04-19 10:15:28 --> Loader Class Initialized
INFO - 2023-04-19 10:15:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:15:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:15:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:15:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:15:28 --> Total execution time: 0.0497
INFO - 2023-04-19 10:15:28 --> Config Class Initialized
INFO - 2023-04-19 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:15:28 --> Utf8 Class Initialized
INFO - 2023-04-19 10:15:28 --> URI Class Initialized
INFO - 2023-04-19 10:15:28 --> Router Class Initialized
INFO - 2023-04-19 10:15:28 --> Output Class Initialized
INFO - 2023-04-19 10:15:28 --> Security Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:15:28 --> Input Class Initialized
INFO - 2023-04-19 10:15:28 --> Language Class Initialized
INFO - 2023-04-19 10:15:28 --> Loader Class Initialized
INFO - 2023-04-19 10:15:28 --> Controller Class Initialized
DEBUG - 2023-04-19 10:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:15:28 --> Database Driver Class Initialized
INFO - 2023-04-19 10:15:28 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:15:28 --> Final output sent to browser
DEBUG - 2023-04-19 10:15:28 --> Total execution time: 0.0132
INFO - 2023-04-19 10:19:03 --> Config Class Initialized
INFO - 2023-04-19 10:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:19:03 --> Utf8 Class Initialized
INFO - 2023-04-19 10:19:03 --> URI Class Initialized
INFO - 2023-04-19 10:19:03 --> Router Class Initialized
INFO - 2023-04-19 10:19:03 --> Output Class Initialized
INFO - 2023-04-19 10:19:03 --> Security Class Initialized
DEBUG - 2023-04-19 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:19:03 --> Input Class Initialized
INFO - 2023-04-19 10:19:03 --> Language Class Initialized
INFO - 2023-04-19 10:19:03 --> Loader Class Initialized
INFO - 2023-04-19 10:19:03 --> Controller Class Initialized
DEBUG - 2023-04-19 10:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:19:03 --> Database Driver Class Initialized
INFO - 2023-04-19 10:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:19:03 --> Database Driver Class Initialized
INFO - 2023-04-19 10:19:03 --> Model "Login_model" initialized
INFO - 2023-04-19 10:19:03 --> Final output sent to browser
DEBUG - 2023-04-19 10:19:03 --> Total execution time: 0.0626
INFO - 2023-04-19 10:19:03 --> Config Class Initialized
INFO - 2023-04-19 10:19:03 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:19:03 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:19:03 --> Utf8 Class Initialized
INFO - 2023-04-19 10:19:03 --> URI Class Initialized
INFO - 2023-04-19 10:19:03 --> Router Class Initialized
INFO - 2023-04-19 10:19:03 --> Output Class Initialized
INFO - 2023-04-19 10:19:03 --> Security Class Initialized
DEBUG - 2023-04-19 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:19:03 --> Input Class Initialized
INFO - 2023-04-19 10:19:03 --> Language Class Initialized
INFO - 2023-04-19 10:19:03 --> Loader Class Initialized
INFO - 2023-04-19 10:19:03 --> Controller Class Initialized
DEBUG - 2023-04-19 10:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:19:03 --> Database Driver Class Initialized
INFO - 2023-04-19 10:19:03 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:19:03 --> Database Driver Class Initialized
INFO - 2023-04-19 10:19:03 --> Model "Login_model" initialized
INFO - 2023-04-19 10:19:03 --> Final output sent to browser
DEBUG - 2023-04-19 10:19:03 --> Total execution time: 0.0723
INFO - 2023-04-19 10:20:36 --> Config Class Initialized
INFO - 2023-04-19 10:20:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:36 --> URI Class Initialized
INFO - 2023-04-19 10:20:36 --> Router Class Initialized
INFO - 2023-04-19 10:20:36 --> Output Class Initialized
INFO - 2023-04-19 10:20:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:36 --> Input Class Initialized
INFO - 2023-04-19 10:20:36 --> Language Class Initialized
INFO - 2023-04-19 10:20:36 --> Loader Class Initialized
INFO - 2023-04-19 10:20:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:36 --> Model "Login_model" initialized
INFO - 2023-04-19 10:20:36 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:36 --> Total execution time: 0.1077
INFO - 2023-04-19 10:20:36 --> Config Class Initialized
INFO - 2023-04-19 10:20:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:36 --> URI Class Initialized
INFO - 2023-04-19 10:20:36 --> Router Class Initialized
INFO - 2023-04-19 10:20:36 --> Output Class Initialized
INFO - 2023-04-19 10:20:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:36 --> Input Class Initialized
INFO - 2023-04-19 10:20:36 --> Language Class Initialized
INFO - 2023-04-19 10:20:36 --> Loader Class Initialized
INFO - 2023-04-19 10:20:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:36 --> Model "Login_model" initialized
INFO - 2023-04-19 10:20:37 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:37 --> Total execution time: 0.0643
INFO - 2023-04-19 10:20:46 --> Config Class Initialized
INFO - 2023-04-19 10:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:46 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:46 --> URI Class Initialized
INFO - 2023-04-19 10:20:46 --> Router Class Initialized
INFO - 2023-04-19 10:20:46 --> Output Class Initialized
INFO - 2023-04-19 10:20:46 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:46 --> Input Class Initialized
INFO - 2023-04-19 10:20:46 --> Language Class Initialized
INFO - 2023-04-19 10:20:46 --> Loader Class Initialized
INFO - 2023-04-19 10:20:46 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:46 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:46 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:46 --> Total execution time: 0.0122
INFO - 2023-04-19 10:20:46 --> Config Class Initialized
INFO - 2023-04-19 10:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:46 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:46 --> URI Class Initialized
INFO - 2023-04-19 10:20:46 --> Router Class Initialized
INFO - 2023-04-19 10:20:46 --> Output Class Initialized
INFO - 2023-04-19 10:20:46 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:46 --> Input Class Initialized
INFO - 2023-04-19 10:20:46 --> Language Class Initialized
INFO - 2023-04-19 10:20:46 --> Loader Class Initialized
INFO - 2023-04-19 10:20:46 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:46 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:46 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:46 --> Total execution time: 0.0121
INFO - 2023-04-19 10:20:46 --> Config Class Initialized
INFO - 2023-04-19 10:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:46 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:46 --> URI Class Initialized
INFO - 2023-04-19 10:20:46 --> Router Class Initialized
INFO - 2023-04-19 10:20:46 --> Output Class Initialized
INFO - 2023-04-19 10:20:46 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:46 --> Input Class Initialized
INFO - 2023-04-19 10:20:46 --> Language Class Initialized
INFO - 2023-04-19 10:20:46 --> Loader Class Initialized
INFO - 2023-04-19 10:20:46 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:46 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:46 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:46 --> Total execution time: 0.0520
INFO - 2023-04-19 10:20:46 --> Config Class Initialized
INFO - 2023-04-19 10:20:46 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:20:46 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:20:46 --> Utf8 Class Initialized
INFO - 2023-04-19 10:20:46 --> URI Class Initialized
INFO - 2023-04-19 10:20:46 --> Router Class Initialized
INFO - 2023-04-19 10:20:46 --> Output Class Initialized
INFO - 2023-04-19 10:20:46 --> Security Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:20:46 --> Input Class Initialized
INFO - 2023-04-19 10:20:46 --> Language Class Initialized
INFO - 2023-04-19 10:20:46 --> Loader Class Initialized
INFO - 2023-04-19 10:20:46 --> Controller Class Initialized
DEBUG - 2023-04-19 10:20:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:20:46 --> Database Driver Class Initialized
INFO - 2023-04-19 10:20:46 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:20:46 --> Final output sent to browser
DEBUG - 2023-04-19 10:20:46 --> Total execution time: 0.0129
INFO - 2023-04-19 10:21:04 --> Config Class Initialized
INFO - 2023-04-19 10:21:04 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:04 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:04 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:04 --> URI Class Initialized
INFO - 2023-04-19 10:21:04 --> Router Class Initialized
INFO - 2023-04-19 10:21:04 --> Output Class Initialized
INFO - 2023-04-19 10:21:04 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:04 --> Input Class Initialized
INFO - 2023-04-19 10:21:04 --> Language Class Initialized
INFO - 2023-04-19 10:21:04 --> Loader Class Initialized
INFO - 2023-04-19 10:21:04 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:04 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:04 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:04 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:04 --> Model "Login_model" initialized
INFO - 2023-04-19 10:21:04 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:04 --> Total execution time: 0.1015
INFO - 2023-04-19 10:21:04 --> Config Class Initialized
INFO - 2023-04-19 10:21:04 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:04 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:04 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:04 --> URI Class Initialized
INFO - 2023-04-19 10:21:04 --> Router Class Initialized
INFO - 2023-04-19 10:21:04 --> Output Class Initialized
INFO - 2023-04-19 10:21:04 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:04 --> Input Class Initialized
INFO - 2023-04-19 10:21:04 --> Language Class Initialized
INFO - 2023-04-19 10:21:04 --> Loader Class Initialized
INFO - 2023-04-19 10:21:04 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:04 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:04 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:04 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:04 --> Model "Login_model" initialized
INFO - 2023-04-19 10:21:04 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:04 --> Total execution time: 0.0679
INFO - 2023-04-19 10:21:07 --> Config Class Initialized
INFO - 2023-04-19 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:07 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:07 --> URI Class Initialized
INFO - 2023-04-19 10:21:07 --> Router Class Initialized
INFO - 2023-04-19 10:21:07 --> Output Class Initialized
INFO - 2023-04-19 10:21:07 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:07 --> Input Class Initialized
INFO - 2023-04-19 10:21:07 --> Language Class Initialized
INFO - 2023-04-19 10:21:07 --> Loader Class Initialized
INFO - 2023-04-19 10:21:07 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:07 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:07 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:07 --> Total execution time: 0.0159
INFO - 2023-04-19 10:21:07 --> Config Class Initialized
INFO - 2023-04-19 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:07 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:07 --> URI Class Initialized
INFO - 2023-04-19 10:21:07 --> Router Class Initialized
INFO - 2023-04-19 10:21:07 --> Output Class Initialized
INFO - 2023-04-19 10:21:07 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:07 --> Input Class Initialized
INFO - 2023-04-19 10:21:07 --> Language Class Initialized
INFO - 2023-04-19 10:21:07 --> Loader Class Initialized
INFO - 2023-04-19 10:21:07 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:07 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:07 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:07 --> Total execution time: 0.0109
INFO - 2023-04-19 10:21:07 --> Config Class Initialized
INFO - 2023-04-19 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:07 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:07 --> URI Class Initialized
INFO - 2023-04-19 10:21:07 --> Router Class Initialized
INFO - 2023-04-19 10:21:07 --> Output Class Initialized
INFO - 2023-04-19 10:21:07 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:07 --> Input Class Initialized
INFO - 2023-04-19 10:21:07 --> Language Class Initialized
INFO - 2023-04-19 10:21:07 --> Loader Class Initialized
INFO - 2023-04-19 10:21:07 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:07 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:07 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:07 --> Total execution time: 0.0530
INFO - 2023-04-19 10:21:07 --> Config Class Initialized
INFO - 2023-04-19 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:21:07 --> Utf8 Class Initialized
INFO - 2023-04-19 10:21:07 --> URI Class Initialized
INFO - 2023-04-19 10:21:07 --> Router Class Initialized
INFO - 2023-04-19 10:21:07 --> Output Class Initialized
INFO - 2023-04-19 10:21:07 --> Security Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:21:07 --> Input Class Initialized
INFO - 2023-04-19 10:21:07 --> Language Class Initialized
INFO - 2023-04-19 10:21:07 --> Loader Class Initialized
INFO - 2023-04-19 10:21:07 --> Controller Class Initialized
DEBUG - 2023-04-19 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:21:07 --> Database Driver Class Initialized
INFO - 2023-04-19 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:21:07 --> Final output sent to browser
DEBUG - 2023-04-19 10:21:07 --> Total execution time: 0.0125
INFO - 2023-04-19 10:22:09 --> Config Class Initialized
INFO - 2023-04-19 10:22:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:22:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:22:09 --> Utf8 Class Initialized
INFO - 2023-04-19 10:22:09 --> URI Class Initialized
INFO - 2023-04-19 10:22:09 --> Router Class Initialized
INFO - 2023-04-19 10:22:09 --> Output Class Initialized
INFO - 2023-04-19 10:22:09 --> Security Class Initialized
DEBUG - 2023-04-19 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:22:09 --> Input Class Initialized
INFO - 2023-04-19 10:22:09 --> Language Class Initialized
INFO - 2023-04-19 10:22:09 --> Loader Class Initialized
INFO - 2023-04-19 10:22:09 --> Controller Class Initialized
DEBUG - 2023-04-19 10:22:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:22:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:22:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:22:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:22:09 --> Model "Login_model" initialized
INFO - 2023-04-19 10:22:09 --> Final output sent to browser
DEBUG - 2023-04-19 10:22:09 --> Total execution time: 0.1016
INFO - 2023-04-19 10:22:09 --> Config Class Initialized
INFO - 2023-04-19 10:22:09 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:22:09 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:22:09 --> Utf8 Class Initialized
INFO - 2023-04-19 10:22:09 --> URI Class Initialized
INFO - 2023-04-19 10:22:09 --> Router Class Initialized
INFO - 2023-04-19 10:22:09 --> Output Class Initialized
INFO - 2023-04-19 10:22:09 --> Security Class Initialized
DEBUG - 2023-04-19 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:22:09 --> Input Class Initialized
INFO - 2023-04-19 10:22:09 --> Language Class Initialized
INFO - 2023-04-19 10:22:09 --> Loader Class Initialized
INFO - 2023-04-19 10:22:09 --> Controller Class Initialized
DEBUG - 2023-04-19 10:22:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:22:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:22:09 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:22:09 --> Database Driver Class Initialized
INFO - 2023-04-19 10:22:09 --> Model "Login_model" initialized
INFO - 2023-04-19 10:22:09 --> Final output sent to browser
DEBUG - 2023-04-19 10:22:09 --> Total execution time: 0.0565
INFO - 2023-04-19 10:23:51 --> Config Class Initialized
INFO - 2023-04-19 10:23:51 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:23:51 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:23:51 --> Utf8 Class Initialized
INFO - 2023-04-19 10:23:51 --> URI Class Initialized
INFO - 2023-04-19 10:23:51 --> Router Class Initialized
INFO - 2023-04-19 10:23:51 --> Output Class Initialized
INFO - 2023-04-19 10:23:51 --> Security Class Initialized
DEBUG - 2023-04-19 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:23:51 --> Input Class Initialized
INFO - 2023-04-19 10:23:51 --> Language Class Initialized
INFO - 2023-04-19 10:23:51 --> Loader Class Initialized
INFO - 2023-04-19 10:23:51 --> Controller Class Initialized
DEBUG - 2023-04-19 10:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:23:51 --> Database Driver Class Initialized
INFO - 2023-04-19 10:23:51 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:23:51 --> Database Driver Class Initialized
INFO - 2023-04-19 10:23:51 --> Model "Login_model" initialized
INFO - 2023-04-19 10:23:51 --> Final output sent to browser
DEBUG - 2023-04-19 10:23:51 --> Total execution time: 0.2012
INFO - 2023-04-19 10:23:51 --> Config Class Initialized
INFO - 2023-04-19 10:23:51 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:23:51 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:23:51 --> Utf8 Class Initialized
INFO - 2023-04-19 10:23:51 --> URI Class Initialized
INFO - 2023-04-19 10:23:51 --> Router Class Initialized
INFO - 2023-04-19 10:23:51 --> Output Class Initialized
INFO - 2023-04-19 10:23:51 --> Security Class Initialized
DEBUG - 2023-04-19 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:23:51 --> Input Class Initialized
INFO - 2023-04-19 10:23:51 --> Language Class Initialized
INFO - 2023-04-19 10:23:51 --> Loader Class Initialized
INFO - 2023-04-19 10:23:51 --> Controller Class Initialized
DEBUG - 2023-04-19 10:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:23:51 --> Database Driver Class Initialized
INFO - 2023-04-19 10:23:51 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:23:51 --> Database Driver Class Initialized
INFO - 2023-04-19 10:23:51 --> Model "Login_model" initialized
INFO - 2023-04-19 10:23:51 --> Final output sent to browser
DEBUG - 2023-04-19 10:23:51 --> Total execution time: 0.0779
INFO - 2023-04-19 10:24:01 --> Config Class Initialized
INFO - 2023-04-19 10:24:01 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:01 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:01 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:01 --> URI Class Initialized
INFO - 2023-04-19 10:24:01 --> Router Class Initialized
INFO - 2023-04-19 10:24:01 --> Output Class Initialized
INFO - 2023-04-19 10:24:01 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:01 --> Input Class Initialized
INFO - 2023-04-19 10:24:01 --> Language Class Initialized
INFO - 2023-04-19 10:24:01 --> Loader Class Initialized
INFO - 2023-04-19 10:24:01 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:01 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:01 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:01 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:01 --> Model "Login_model" initialized
INFO - 2023-04-19 10:24:01 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:01 --> Total execution time: 0.1116
INFO - 2023-04-19 10:24:01 --> Config Class Initialized
INFO - 2023-04-19 10:24:01 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:01 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:01 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:01 --> URI Class Initialized
INFO - 2023-04-19 10:24:01 --> Router Class Initialized
INFO - 2023-04-19 10:24:01 --> Output Class Initialized
INFO - 2023-04-19 10:24:01 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:01 --> Input Class Initialized
INFO - 2023-04-19 10:24:01 --> Language Class Initialized
INFO - 2023-04-19 10:24:01 --> Loader Class Initialized
INFO - 2023-04-19 10:24:01 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:01 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:01 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:01 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:01 --> Model "Login_model" initialized
INFO - 2023-04-19 10:24:01 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:01 --> Total execution time: 0.0676
INFO - 2023-04-19 10:24:08 --> Config Class Initialized
INFO - 2023-04-19 10:24:08 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:08 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:08 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:08 --> URI Class Initialized
INFO - 2023-04-19 10:24:08 --> Router Class Initialized
INFO - 2023-04-19 10:24:08 --> Output Class Initialized
INFO - 2023-04-19 10:24:08 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:08 --> Input Class Initialized
INFO - 2023-04-19 10:24:08 --> Language Class Initialized
INFO - 2023-04-19 10:24:08 --> Loader Class Initialized
INFO - 2023-04-19 10:24:08 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:08 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:08 --> Model "Login_model" initialized
INFO - 2023-04-19 10:24:08 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:08 --> Total execution time: 0.2153
INFO - 2023-04-19 10:24:08 --> Config Class Initialized
INFO - 2023-04-19 10:24:08 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:08 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:08 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:08 --> URI Class Initialized
INFO - 2023-04-19 10:24:08 --> Router Class Initialized
INFO - 2023-04-19 10:24:08 --> Output Class Initialized
INFO - 2023-04-19 10:24:08 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:08 --> Input Class Initialized
INFO - 2023-04-19 10:24:08 --> Language Class Initialized
INFO - 2023-04-19 10:24:08 --> Loader Class Initialized
INFO - 2023-04-19 10:24:08 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:08 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:08 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:08 --> Model "Login_model" initialized
INFO - 2023-04-19 10:24:08 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:08 --> Total execution time: 0.0755
INFO - 2023-04-19 10:24:11 --> Config Class Initialized
INFO - 2023-04-19 10:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:11 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:11 --> URI Class Initialized
INFO - 2023-04-19 10:24:11 --> Router Class Initialized
INFO - 2023-04-19 10:24:11 --> Output Class Initialized
INFO - 2023-04-19 10:24:11 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:11 --> Input Class Initialized
INFO - 2023-04-19 10:24:11 --> Language Class Initialized
INFO - 2023-04-19 10:24:11 --> Loader Class Initialized
INFO - 2023-04-19 10:24:11 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:11 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:11 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:11 --> Total execution time: 0.0153
INFO - 2023-04-19 10:24:11 --> Config Class Initialized
INFO - 2023-04-19 10:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:11 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:11 --> URI Class Initialized
INFO - 2023-04-19 10:24:11 --> Router Class Initialized
INFO - 2023-04-19 10:24:11 --> Output Class Initialized
INFO - 2023-04-19 10:24:11 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:11 --> Input Class Initialized
INFO - 2023-04-19 10:24:11 --> Language Class Initialized
INFO - 2023-04-19 10:24:11 --> Loader Class Initialized
INFO - 2023-04-19 10:24:11 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:11 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:11 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:11 --> Total execution time: 0.0146
INFO - 2023-04-19 10:24:11 --> Config Class Initialized
INFO - 2023-04-19 10:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:11 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:11 --> URI Class Initialized
INFO - 2023-04-19 10:24:11 --> Router Class Initialized
INFO - 2023-04-19 10:24:11 --> Output Class Initialized
INFO - 2023-04-19 10:24:11 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:11 --> Input Class Initialized
INFO - 2023-04-19 10:24:11 --> Language Class Initialized
INFO - 2023-04-19 10:24:11 --> Loader Class Initialized
INFO - 2023-04-19 10:24:11 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:11 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:11 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:11 --> Total execution time: 0.0111
INFO - 2023-04-19 10:24:11 --> Config Class Initialized
INFO - 2023-04-19 10:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:24:11 --> Utf8 Class Initialized
INFO - 2023-04-19 10:24:11 --> URI Class Initialized
INFO - 2023-04-19 10:24:11 --> Router Class Initialized
INFO - 2023-04-19 10:24:11 --> Output Class Initialized
INFO - 2023-04-19 10:24:11 --> Security Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:24:11 --> Input Class Initialized
INFO - 2023-04-19 10:24:11 --> Language Class Initialized
INFO - 2023-04-19 10:24:11 --> Loader Class Initialized
INFO - 2023-04-19 10:24:11 --> Controller Class Initialized
DEBUG - 2023-04-19 10:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:24:11 --> Database Driver Class Initialized
INFO - 2023-04-19 10:24:11 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:24:11 --> Final output sent to browser
DEBUG - 2023-04-19 10:24:11 --> Total execution time: 0.0140
INFO - 2023-04-19 10:29:27 --> Config Class Initialized
INFO - 2023-04-19 10:29:27 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:27 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:27 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:27 --> URI Class Initialized
INFO - 2023-04-19 10:29:27 --> Router Class Initialized
INFO - 2023-04-19 10:29:27 --> Output Class Initialized
INFO - 2023-04-19 10:29:27 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:27 --> Input Class Initialized
INFO - 2023-04-19 10:29:27 --> Language Class Initialized
INFO - 2023-04-19 10:29:27 --> Loader Class Initialized
INFO - 2023-04-19 10:29:27 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:27 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:27 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:27 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:27 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:27 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:27 --> Total execution time: 0.1453
INFO - 2023-04-19 10:29:27 --> Config Class Initialized
INFO - 2023-04-19 10:29:27 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:27 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:27 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:27 --> URI Class Initialized
INFO - 2023-04-19 10:29:27 --> Router Class Initialized
INFO - 2023-04-19 10:29:27 --> Output Class Initialized
INFO - 2023-04-19 10:29:27 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:27 --> Input Class Initialized
INFO - 2023-04-19 10:29:27 --> Language Class Initialized
INFO - 2023-04-19 10:29:27 --> Loader Class Initialized
INFO - 2023-04-19 10:29:27 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:27 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:27 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:27 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:27 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:27 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:27 --> Total execution time: 0.0608
INFO - 2023-04-19 10:29:36 --> Config Class Initialized
INFO - 2023-04-19 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:36 --> URI Class Initialized
INFO - 2023-04-19 10:29:36 --> Router Class Initialized
INFO - 2023-04-19 10:29:36 --> Output Class Initialized
INFO - 2023-04-19 10:29:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:36 --> Input Class Initialized
INFO - 2023-04-19 10:29:36 --> Language Class Initialized
INFO - 2023-04-19 10:29:36 --> Loader Class Initialized
INFO - 2023-04-19 10:29:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:36 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:36 --> Total execution time: 0.0120
INFO - 2023-04-19 10:29:36 --> Config Class Initialized
INFO - 2023-04-19 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:36 --> URI Class Initialized
INFO - 2023-04-19 10:29:36 --> Router Class Initialized
INFO - 2023-04-19 10:29:36 --> Output Class Initialized
INFO - 2023-04-19 10:29:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:36 --> Input Class Initialized
INFO - 2023-04-19 10:29:36 --> Language Class Initialized
INFO - 2023-04-19 10:29:36 --> Loader Class Initialized
INFO - 2023-04-19 10:29:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:36 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:36 --> Total execution time: 0.0226
INFO - 2023-04-19 10:29:36 --> Config Class Initialized
INFO - 2023-04-19 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:36 --> URI Class Initialized
INFO - 2023-04-19 10:29:36 --> Router Class Initialized
INFO - 2023-04-19 10:29:36 --> Output Class Initialized
INFO - 2023-04-19 10:29:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:36 --> Input Class Initialized
INFO - 2023-04-19 10:29:36 --> Language Class Initialized
INFO - 2023-04-19 10:29:36 --> Loader Class Initialized
INFO - 2023-04-19 10:29:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:36 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:36 --> Total execution time: 0.0513
INFO - 2023-04-19 10:29:36 --> Config Class Initialized
INFO - 2023-04-19 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:36 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:36 --> URI Class Initialized
INFO - 2023-04-19 10:29:36 --> Router Class Initialized
INFO - 2023-04-19 10:29:36 --> Output Class Initialized
INFO - 2023-04-19 10:29:36 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:36 --> Input Class Initialized
INFO - 2023-04-19 10:29:36 --> Language Class Initialized
INFO - 2023-04-19 10:29:36 --> Loader Class Initialized
INFO - 2023-04-19 10:29:36 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:36 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:36 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:36 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:36 --> Total execution time: 0.0197
INFO - 2023-04-19 10:29:37 --> Config Class Initialized
INFO - 2023-04-19 10:29:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:37 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:37 --> URI Class Initialized
INFO - 2023-04-19 10:29:37 --> Router Class Initialized
INFO - 2023-04-19 10:29:37 --> Output Class Initialized
INFO - 2023-04-19 10:29:37 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:37 --> Input Class Initialized
INFO - 2023-04-19 10:29:37 --> Language Class Initialized
INFO - 2023-04-19 10:29:37 --> Loader Class Initialized
INFO - 2023-04-19 10:29:37 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:37 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:37 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:37 --> Total execution time: 0.0172
INFO - 2023-04-19 10:29:37 --> Config Class Initialized
INFO - 2023-04-19 10:29:37 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:37 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:37 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:37 --> URI Class Initialized
INFO - 2023-04-19 10:29:37 --> Router Class Initialized
INFO - 2023-04-19 10:29:37 --> Output Class Initialized
INFO - 2023-04-19 10:29:37 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:37 --> Input Class Initialized
INFO - 2023-04-19 10:29:37 --> Language Class Initialized
INFO - 2023-04-19 10:29:37 --> Loader Class Initialized
INFO - 2023-04-19 10:29:37 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:37 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:37 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:37 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:37 --> Total execution time: 0.0535
INFO - 2023-04-19 10:29:38 --> Config Class Initialized
INFO - 2023-04-19 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:38 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:38 --> URI Class Initialized
INFO - 2023-04-19 10:29:38 --> Router Class Initialized
INFO - 2023-04-19 10:29:38 --> Output Class Initialized
INFO - 2023-04-19 10:29:38 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:38 --> Input Class Initialized
INFO - 2023-04-19 10:29:38 --> Language Class Initialized
INFO - 2023-04-19 10:29:38 --> Loader Class Initialized
INFO - 2023-04-19 10:29:38 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:38 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:38 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:38 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:38 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:38 --> Total execution time: 0.1029
INFO - 2023-04-19 10:29:38 --> Config Class Initialized
INFO - 2023-04-19 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:38 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:38 --> URI Class Initialized
INFO - 2023-04-19 10:29:38 --> Router Class Initialized
INFO - 2023-04-19 10:29:38 --> Output Class Initialized
INFO - 2023-04-19 10:29:38 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:38 --> Input Class Initialized
INFO - 2023-04-19 10:29:38 --> Language Class Initialized
INFO - 2023-04-19 10:29:38 --> Loader Class Initialized
INFO - 2023-04-19 10:29:38 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:38 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:38 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:38 --> Model "Login_model" initialized
INFO - 2023-04-19 10:29:38 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:38 --> Total execution time: 0.0703
INFO - 2023-04-19 10:29:39 --> Config Class Initialized
INFO - 2023-04-19 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:39 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:39 --> URI Class Initialized
INFO - 2023-04-19 10:29:39 --> Router Class Initialized
INFO - 2023-04-19 10:29:39 --> Output Class Initialized
INFO - 2023-04-19 10:29:39 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:39 --> Input Class Initialized
INFO - 2023-04-19 10:29:39 --> Language Class Initialized
INFO - 2023-04-19 10:29:39 --> Loader Class Initialized
INFO - 2023-04-19 10:29:39 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:39 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:39 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:39 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:39 --> Total execution time: 0.0175
INFO - 2023-04-19 10:29:39 --> Config Class Initialized
INFO - 2023-04-19 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:39 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:39 --> URI Class Initialized
INFO - 2023-04-19 10:29:39 --> Router Class Initialized
INFO - 2023-04-19 10:29:39 --> Output Class Initialized
INFO - 2023-04-19 10:29:39 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:39 --> Input Class Initialized
INFO - 2023-04-19 10:29:39 --> Language Class Initialized
INFO - 2023-04-19 10:29:39 --> Loader Class Initialized
INFO - 2023-04-19 10:29:39 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:39 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:39 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:39 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:39 --> Total execution time: 0.0102
INFO - 2023-04-19 10:29:39 --> Config Class Initialized
INFO - 2023-04-19 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:39 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:39 --> URI Class Initialized
INFO - 2023-04-19 10:29:39 --> Router Class Initialized
INFO - 2023-04-19 10:29:39 --> Output Class Initialized
INFO - 2023-04-19 10:29:39 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:39 --> Input Class Initialized
INFO - 2023-04-19 10:29:39 --> Language Class Initialized
INFO - 2023-04-19 10:29:39 --> Loader Class Initialized
INFO - 2023-04-19 10:29:39 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:39 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:39 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:39 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:39 --> Total execution time: 0.0477
INFO - 2023-04-19 10:29:40 --> Config Class Initialized
INFO - 2023-04-19 10:29:40 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:29:40 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:29:40 --> Utf8 Class Initialized
INFO - 2023-04-19 10:29:40 --> URI Class Initialized
INFO - 2023-04-19 10:29:40 --> Router Class Initialized
INFO - 2023-04-19 10:29:40 --> Output Class Initialized
INFO - 2023-04-19 10:29:40 --> Security Class Initialized
DEBUG - 2023-04-19 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:29:40 --> Input Class Initialized
INFO - 2023-04-19 10:29:40 --> Language Class Initialized
INFO - 2023-04-19 10:29:40 --> Loader Class Initialized
INFO - 2023-04-19 10:29:40 --> Controller Class Initialized
DEBUG - 2023-04-19 10:29:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:29:40 --> Database Driver Class Initialized
INFO - 2023-04-19 10:29:40 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:29:40 --> Final output sent to browser
DEBUG - 2023-04-19 10:29:40 --> Total execution time: 0.0109
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Model "Login_model" initialized
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.0257
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.0420
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.0365
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Model "Login_model" initialized
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.0714
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.1135
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Config Class Initialized
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.0776
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
INFO - 2023-04-19 10:31:43 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
DEBUG - 2023-04-19 10:31:43 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> URI Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
INFO - 2023-04-19 10:31:43 --> Router Class Initialized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Output Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Security Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Input Class Initialized
INFO - 2023-04-19 10:31:43 --> Language Class Initialized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Loader Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
INFO - 2023-04-19 10:31:43 --> Controller Class Initialized
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-19 10:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.1081
INFO - 2023-04-19 10:31:43 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:43 --> Total execution time: 0.1105
INFO - 2023-04-19 10:31:45 --> Config Class Initialized
INFO - 2023-04-19 10:31:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:45 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:45 --> URI Class Initialized
INFO - 2023-04-19 10:31:45 --> Router Class Initialized
INFO - 2023-04-19 10:31:45 --> Output Class Initialized
INFO - 2023-04-19 10:31:45 --> Security Class Initialized
DEBUG - 2023-04-19 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:45 --> Input Class Initialized
INFO - 2023-04-19 10:31:45 --> Language Class Initialized
INFO - 2023-04-19 10:31:45 --> Loader Class Initialized
INFO - 2023-04-19 10:31:45 --> Controller Class Initialized
DEBUG - 2023-04-19 10:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:45 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:45 --> Total execution time: 0.0537
INFO - 2023-04-19 10:31:45 --> Config Class Initialized
INFO - 2023-04-19 10:31:45 --> Hooks Class Initialized
DEBUG - 2023-04-19 10:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-19 10:31:45 --> Utf8 Class Initialized
INFO - 2023-04-19 10:31:45 --> URI Class Initialized
INFO - 2023-04-19 10:31:45 --> Router Class Initialized
INFO - 2023-04-19 10:31:45 --> Output Class Initialized
INFO - 2023-04-19 10:31:45 --> Security Class Initialized
DEBUG - 2023-04-19 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 10:31:45 --> Input Class Initialized
INFO - 2023-04-19 10:31:45 --> Language Class Initialized
INFO - 2023-04-19 10:31:45 --> Loader Class Initialized
INFO - 2023-04-19 10:31:45 --> Controller Class Initialized
DEBUG - 2023-04-19 10:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 10:31:45 --> Database Driver Class Initialized
INFO - 2023-04-19 10:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-19 10:31:45 --> Final output sent to browser
DEBUG - 2023-04-19 10:31:45 --> Total execution time: 0.0510
INFO - 2023-04-19 14:18:49 --> Config Class Initialized
INFO - 2023-04-19 14:18:49 --> Hooks Class Initialized
DEBUG - 2023-04-19 14:18:49 --> UTF-8 Support Enabled
INFO - 2023-04-19 14:18:49 --> Utf8 Class Initialized
INFO - 2023-04-19 14:18:49 --> URI Class Initialized
INFO - 2023-04-19 14:18:49 --> Router Class Initialized
INFO - 2023-04-19 14:18:49 --> Output Class Initialized
INFO - 2023-04-19 14:18:49 --> Security Class Initialized
DEBUG - 2023-04-19 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-19 14:18:49 --> Input Class Initialized
INFO - 2023-04-19 14:18:49 --> Language Class Initialized
INFO - 2023-04-19 14:18:49 --> Loader Class Initialized
INFO - 2023-04-19 14:18:49 --> Controller Class Initialized
DEBUG - 2023-04-19 14:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-19 14:18:49 --> Database Driver Class Initialized
ERROR - 2023-04-19 14:18:59 --> Unable to connect to the database
INFO - 2023-04-19 14:18:59 --> Language file loaded: language/english/db_lang.php
