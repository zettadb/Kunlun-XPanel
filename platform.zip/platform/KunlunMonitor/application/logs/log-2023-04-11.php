<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
INFO - 2023-04-11 05:39:44 --> Helper loaded: form_helper
INFO - 2023-04-11 05:39:44 --> Helper loaded: url_helper
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Model "Change_model" initialized
INFO - 2023-04-11 05:39:44 --> Model "Grafana_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.0433
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
INFO - 2023-04-11 05:39:44 --> Helper loaded: form_helper
INFO - 2023-04-11 05:39:44 --> Helper loaded: url_helper
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.0453
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
INFO - 2023-04-11 05:39:44 --> Helper loaded: form_helper
INFO - 2023-04-11 05:39:44 --> Helper loaded: url_helper
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Login_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.0218
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.0564
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.0141
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Login_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.1498
INFO - 2023-04-11 05:39:44 --> Config Class Initialized
INFO - 2023-04-11 05:39:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:44 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:44 --> URI Class Initialized
INFO - 2023-04-11 05:39:44 --> Router Class Initialized
INFO - 2023-04-11 05:39:44 --> Output Class Initialized
INFO - 2023-04-11 05:39:44 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:44 --> Input Class Initialized
INFO - 2023-04-11 05:39:44 --> Language Class Initialized
INFO - 2023-04-11 05:39:44 --> Loader Class Initialized
INFO - 2023-04-11 05:39:44 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:44 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:44 --> Model "Login_model" initialized
INFO - 2023-04-11 05:39:44 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:44 --> Total execution time: 0.1066
INFO - 2023-04-11 05:39:49 --> Config Class Initialized
INFO - 2023-04-11 05:39:49 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:49 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:49 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:49 --> URI Class Initialized
INFO - 2023-04-11 05:39:49 --> Router Class Initialized
INFO - 2023-04-11 05:39:49 --> Output Class Initialized
INFO - 2023-04-11 05:39:49 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:49 --> Input Class Initialized
INFO - 2023-04-11 05:39:49 --> Language Class Initialized
INFO - 2023-04-11 05:39:49 --> Loader Class Initialized
INFO - 2023-04-11 05:39:49 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:49 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:49 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:49 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:49 --> Total execution time: 0.0959
INFO - 2023-04-11 05:39:49 --> Config Class Initialized
INFO - 2023-04-11 05:39:49 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:39:49 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:39:49 --> Utf8 Class Initialized
INFO - 2023-04-11 05:39:49 --> URI Class Initialized
INFO - 2023-04-11 05:39:49 --> Router Class Initialized
INFO - 2023-04-11 05:39:49 --> Output Class Initialized
INFO - 2023-04-11 05:39:49 --> Security Class Initialized
DEBUG - 2023-04-11 05:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:39:49 --> Input Class Initialized
INFO - 2023-04-11 05:39:49 --> Language Class Initialized
INFO - 2023-04-11 05:39:49 --> Loader Class Initialized
INFO - 2023-04-11 05:39:49 --> Controller Class Initialized
DEBUG - 2023-04-11 05:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:39:49 --> Database Driver Class Initialized
INFO - 2023-04-11 05:39:49 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:39:49 --> Final output sent to browser
DEBUG - 2023-04-11 05:39:49 --> Total execution time: 0.0805
INFO - 2023-04-11 05:41:20 --> Config Class Initialized
INFO - 2023-04-11 05:41:20 --> Config Class Initialized
INFO - 2023-04-11 05:41:20 --> Hooks Class Initialized
INFO - 2023-04-11 05:41:20 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 05:41:20 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:41:20 --> Utf8 Class Initialized
INFO - 2023-04-11 05:41:20 --> Utf8 Class Initialized
INFO - 2023-04-11 05:41:20 --> URI Class Initialized
INFO - 2023-04-11 05:41:20 --> URI Class Initialized
INFO - 2023-04-11 05:41:20 --> Router Class Initialized
INFO - 2023-04-11 05:41:20 --> Router Class Initialized
INFO - 2023-04-11 05:41:20 --> Output Class Initialized
INFO - 2023-04-11 05:41:20 --> Output Class Initialized
INFO - 2023-04-11 05:41:20 --> Security Class Initialized
INFO - 2023-04-11 05:41:20 --> Security Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 05:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:41:20 --> Input Class Initialized
INFO - 2023-04-11 05:41:20 --> Input Class Initialized
INFO - 2023-04-11 05:41:20 --> Language Class Initialized
INFO - 2023-04-11 05:41:20 --> Language Class Initialized
INFO - 2023-04-11 05:41:20 --> Loader Class Initialized
INFO - 2023-04-11 05:41:20 --> Loader Class Initialized
INFO - 2023-04-11 05:41:20 --> Controller Class Initialized
INFO - 2023-04-11 05:41:20 --> Controller Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 05:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:41:20 --> Final output sent to browser
DEBUG - 2023-04-11 05:41:20 --> Total execution time: 0.0527
INFO - 2023-04-11 05:41:20 --> Database Driver Class Initialized
INFO - 2023-04-11 05:41:20 --> Config Class Initialized
INFO - 2023-04-11 05:41:20 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:41:20 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:41:20 --> Utf8 Class Initialized
INFO - 2023-04-11 05:41:20 --> URI Class Initialized
INFO - 2023-04-11 05:41:20 --> Router Class Initialized
INFO - 2023-04-11 05:41:20 --> Output Class Initialized
INFO - 2023-04-11 05:41:20 --> Security Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:41:20 --> Input Class Initialized
INFO - 2023-04-11 05:41:20 --> Language Class Initialized
INFO - 2023-04-11 05:41:20 --> Loader Class Initialized
INFO - 2023-04-11 05:41:20 --> Controller Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:41:20 --> Database Driver Class Initialized
INFO - 2023-04-11 05:41:20 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:41:20 --> Final output sent to browser
DEBUG - 2023-04-11 05:41:20 --> Total execution time: 0.0701
INFO - 2023-04-11 05:41:20 --> Config Class Initialized
INFO - 2023-04-11 05:41:20 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:41:20 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:41:20 --> Utf8 Class Initialized
INFO - 2023-04-11 05:41:20 --> URI Class Initialized
INFO - 2023-04-11 05:41:20 --> Model "Login_model" initialized
INFO - 2023-04-11 05:41:20 --> Router Class Initialized
INFO - 2023-04-11 05:41:20 --> Output Class Initialized
INFO - 2023-04-11 05:41:20 --> Security Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:41:20 --> Input Class Initialized
INFO - 2023-04-11 05:41:20 --> Language Class Initialized
INFO - 2023-04-11 05:41:20 --> Loader Class Initialized
INFO - 2023-04-11 05:41:20 --> Controller Class Initialized
DEBUG - 2023-04-11 05:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:41:20 --> Database Driver Class Initialized
INFO - 2023-04-11 05:41:20 --> Database Driver Class Initialized
INFO - 2023-04-11 05:41:20 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:41:20 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:41:20 --> Final output sent to browser
DEBUG - 2023-04-11 05:41:20 --> Total execution time: 0.0297
INFO - 2023-04-11 05:41:20 --> Final output sent to browser
DEBUG - 2023-04-11 05:41:21 --> Total execution time: 0.0184
INFO - 2023-04-11 05:42:02 --> Config Class Initialized
INFO - 2023-04-11 05:42:02 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:02 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:02 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:02 --> URI Class Initialized
INFO - 2023-04-11 05:42:02 --> Router Class Initialized
INFO - 2023-04-11 05:42:02 --> Output Class Initialized
INFO - 2023-04-11 05:42:02 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:02 --> Input Class Initialized
INFO - 2023-04-11 05:42:02 --> Language Class Initialized
INFO - 2023-04-11 05:42:02 --> Loader Class Initialized
INFO - 2023-04-11 05:42:02 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:02 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:02 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:03 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:03 --> Total execution time: 0.0462
INFO - 2023-04-11 05:42:03 --> Config Class Initialized
INFO - 2023-04-11 05:42:03 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:03 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:03 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:03 --> URI Class Initialized
INFO - 2023-04-11 05:42:03 --> Router Class Initialized
INFO - 2023-04-11 05:42:03 --> Output Class Initialized
INFO - 2023-04-11 05:42:03 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:03 --> Input Class Initialized
INFO - 2023-04-11 05:42:03 --> Language Class Initialized
INFO - 2023-04-11 05:42:03 --> Loader Class Initialized
INFO - 2023-04-11 05:42:03 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:03 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:03 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:03 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:03 --> Total execution time: 0.0837
INFO - 2023-04-11 05:42:05 --> Config Class Initialized
INFO - 2023-04-11 05:42:05 --> Config Class Initialized
INFO - 2023-04-11 05:42:05 --> Hooks Class Initialized
INFO - 2023-04-11 05:42:05 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 05:42:05 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:05 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:05 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:05 --> URI Class Initialized
INFO - 2023-04-11 05:42:05 --> URI Class Initialized
INFO - 2023-04-11 05:42:05 --> Router Class Initialized
INFO - 2023-04-11 05:42:05 --> Router Class Initialized
INFO - 2023-04-11 05:42:05 --> Output Class Initialized
INFO - 2023-04-11 05:42:05 --> Output Class Initialized
INFO - 2023-04-11 05:42:05 --> Security Class Initialized
INFO - 2023-04-11 05:42:05 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:05 --> Input Class Initialized
INFO - 2023-04-11 05:42:05 --> Input Class Initialized
INFO - 2023-04-11 05:42:05 --> Language Class Initialized
INFO - 2023-04-11 05:42:05 --> Language Class Initialized
INFO - 2023-04-11 05:42:05 --> Loader Class Initialized
INFO - 2023-04-11 05:42:05 --> Loader Class Initialized
INFO - 2023-04-11 05:42:05 --> Controller Class Initialized
INFO - 2023-04-11 05:42:05 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 05:42:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:05 --> Final output sent to browser
INFO - 2023-04-11 05:42:05 --> Database Driver Class Initialized
DEBUG - 2023-04-11 05:42:05 --> Total execution time: 0.0045
INFO - 2023-04-11 05:42:05 --> Config Class Initialized
INFO - 2023-04-11 05:42:05 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:05 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:05 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:05 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:06 --> URI Class Initialized
INFO - 2023-04-11 05:42:06 --> Router Class Initialized
INFO - 2023-04-11 05:42:06 --> Output Class Initialized
INFO - 2023-04-11 05:42:06 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:06 --> Input Class Initialized
INFO - 2023-04-11 05:42:06 --> Language Class Initialized
INFO - 2023-04-11 05:42:06 --> Loader Class Initialized
INFO - 2023-04-11 05:42:06 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:06 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:06 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:06 --> Total execution time: 0.0493
INFO - 2023-04-11 05:42:06 --> Config Class Initialized
INFO - 2023-04-11 05:42:06 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:06 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:06 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:06 --> URI Class Initialized
INFO - 2023-04-11 05:42:06 --> Router Class Initialized
INFO - 2023-04-11 05:42:06 --> Output Class Initialized
INFO - 2023-04-11 05:42:06 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:06 --> Input Class Initialized
INFO - 2023-04-11 05:42:06 --> Language Class Initialized
INFO - 2023-04-11 05:42:06 --> Loader Class Initialized
INFO - 2023-04-11 05:42:06 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:06 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:06 --> Model "Login_model" initialized
INFO - 2023-04-11 05:42:06 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:06 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:06 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:06 --> Total execution time: 0.0125
INFO - 2023-04-11 05:42:06 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:06 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:06 --> Total execution time: 0.0604
INFO - 2023-04-11 05:42:07 --> Config Class Initialized
INFO - 2023-04-11 05:42:07 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:07 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:07 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:07 --> URI Class Initialized
INFO - 2023-04-11 05:42:07 --> Router Class Initialized
INFO - 2023-04-11 05:42:07 --> Output Class Initialized
INFO - 2023-04-11 05:42:07 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:07 --> Input Class Initialized
INFO - 2023-04-11 05:42:07 --> Language Class Initialized
INFO - 2023-04-11 05:42:07 --> Loader Class Initialized
INFO - 2023-04-11 05:42:07 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:07 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:07 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:07 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:07 --> Model "Login_model" initialized
INFO - 2023-04-11 05:42:07 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:07 --> Total execution time: 0.0559
INFO - 2023-04-11 05:42:07 --> Config Class Initialized
INFO - 2023-04-11 05:42:08 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:08 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:08 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:08 --> URI Class Initialized
INFO - 2023-04-11 05:42:08 --> Router Class Initialized
INFO - 2023-04-11 05:42:08 --> Output Class Initialized
INFO - 2023-04-11 05:42:08 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:08 --> Input Class Initialized
INFO - 2023-04-11 05:42:08 --> Language Class Initialized
INFO - 2023-04-11 05:42:08 --> Loader Class Initialized
INFO - 2023-04-11 05:42:08 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:08 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:08 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:08 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:08 --> Model "Login_model" initialized
INFO - 2023-04-11 05:42:08 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:08 --> Total execution time: 0.1022
INFO - 2023-04-11 05:42:10 --> Config Class Initialized
INFO - 2023-04-11 05:42:10 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:10 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:10 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:10 --> URI Class Initialized
INFO - 2023-04-11 05:42:10 --> Router Class Initialized
INFO - 2023-04-11 05:42:10 --> Output Class Initialized
INFO - 2023-04-11 05:42:10 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:10 --> Input Class Initialized
INFO - 2023-04-11 05:42:10 --> Language Class Initialized
INFO - 2023-04-11 05:42:10 --> Loader Class Initialized
INFO - 2023-04-11 05:42:10 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:10 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:10 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:10 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:10 --> Total execution time: 0.2688
INFO - 2023-04-11 05:42:10 --> Config Class Initialized
INFO - 2023-04-11 05:42:10 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:10 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:10 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:10 --> URI Class Initialized
INFO - 2023-04-11 05:42:10 --> Router Class Initialized
INFO - 2023-04-11 05:42:10 --> Output Class Initialized
INFO - 2023-04-11 05:42:10 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:10 --> Input Class Initialized
INFO - 2023-04-11 05:42:10 --> Language Class Initialized
INFO - 2023-04-11 05:42:10 --> Loader Class Initialized
INFO - 2023-04-11 05:42:10 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:10 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:10 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:10 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:10 --> Total execution time: 0.0119
INFO - 2023-04-11 05:42:18 --> Config Class Initialized
INFO - 2023-04-11 05:42:18 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:18 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:18 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:18 --> URI Class Initialized
INFO - 2023-04-11 05:42:18 --> Router Class Initialized
INFO - 2023-04-11 05:42:18 --> Output Class Initialized
INFO - 2023-04-11 05:42:18 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:18 --> Input Class Initialized
INFO - 2023-04-11 05:42:18 --> Language Class Initialized
INFO - 2023-04-11 05:42:18 --> Loader Class Initialized
INFO - 2023-04-11 05:42:18 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:18 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:18 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:18 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:18 --> Total execution time: 0.0507
INFO - 2023-04-11 05:42:18 --> Config Class Initialized
INFO - 2023-04-11 05:42:18 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:18 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:18 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:18 --> URI Class Initialized
INFO - 2023-04-11 05:42:18 --> Router Class Initialized
INFO - 2023-04-11 05:42:18 --> Output Class Initialized
INFO - 2023-04-11 05:42:18 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:18 --> Input Class Initialized
INFO - 2023-04-11 05:42:18 --> Language Class Initialized
INFO - 2023-04-11 05:42:18 --> Loader Class Initialized
INFO - 2023-04-11 05:42:18 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:18 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:18 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:18 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:18 --> Total execution time: 0.0434
INFO - 2023-04-11 05:42:21 --> Config Class Initialized
INFO - 2023-04-11 05:42:21 --> Config Class Initialized
INFO - 2023-04-11 05:42:21 --> Hooks Class Initialized
INFO - 2023-04-11 05:42:21 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 05:42:21 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:21 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:21 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:21 --> URI Class Initialized
INFO - 2023-04-11 05:42:21 --> URI Class Initialized
INFO - 2023-04-11 05:42:21 --> Router Class Initialized
INFO - 2023-04-11 05:42:21 --> Router Class Initialized
INFO - 2023-04-11 05:42:21 --> Output Class Initialized
INFO - 2023-04-11 05:42:21 --> Output Class Initialized
INFO - 2023-04-11 05:42:21 --> Security Class Initialized
INFO - 2023-04-11 05:42:21 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:21 --> Input Class Initialized
INFO - 2023-04-11 05:42:21 --> Input Class Initialized
INFO - 2023-04-11 05:42:21 --> Language Class Initialized
INFO - 2023-04-11 05:42:21 --> Language Class Initialized
INFO - 2023-04-11 05:42:21 --> Loader Class Initialized
INFO - 2023-04-11 05:42:21 --> Loader Class Initialized
INFO - 2023-04-11 05:42:21 --> Controller Class Initialized
INFO - 2023-04-11 05:42:21 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 05:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:21 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:21 --> Total execution time: 0.0046
INFO - 2023-04-11 05:42:21 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:21 --> Config Class Initialized
INFO - 2023-04-11 05:42:21 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:21 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:21 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:21 --> URI Class Initialized
INFO - 2023-04-11 05:42:21 --> Router Class Initialized
INFO - 2023-04-11 05:42:21 --> Output Class Initialized
INFO - 2023-04-11 05:42:21 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:21 --> Input Class Initialized
INFO - 2023-04-11 05:42:21 --> Language Class Initialized
INFO - 2023-04-11 05:42:21 --> Loader Class Initialized
INFO - 2023-04-11 05:42:21 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:21 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:21 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:21 --> Model "Login_model" initialized
INFO - 2023-04-11 05:42:21 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:21 --> Total execution time: 0.0172
INFO - 2023-04-11 05:42:21 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:21 --> Config Class Initialized
INFO - 2023-04-11 05:42:21 --> Hooks Class Initialized
DEBUG - 2023-04-11 05:42:21 --> UTF-8 Support Enabled
INFO - 2023-04-11 05:42:21 --> Utf8 Class Initialized
INFO - 2023-04-11 05:42:21 --> URI Class Initialized
INFO - 2023-04-11 05:42:21 --> Router Class Initialized
INFO - 2023-04-11 05:42:21 --> Output Class Initialized
INFO - 2023-04-11 05:42:21 --> Security Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 05:42:21 --> Input Class Initialized
INFO - 2023-04-11 05:42:21 --> Language Class Initialized
INFO - 2023-04-11 05:42:21 --> Loader Class Initialized
INFO - 2023-04-11 05:42:21 --> Controller Class Initialized
DEBUG - 2023-04-11 05:42:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 05:42:21 --> Database Driver Class Initialized
INFO - 2023-04-11 05:42:21 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:21 --> Model "Cluster_model" initialized
INFO - 2023-04-11 05:42:21 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:21 --> Total execution time: 0.0212
INFO - 2023-04-11 05:42:21 --> Final output sent to browser
DEBUG - 2023-04-11 05:42:21 --> Total execution time: 0.0137
INFO - 2023-04-11 06:01:23 --> Config Class Initialized
INFO - 2023-04-11 06:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:23 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:23 --> URI Class Initialized
INFO - 2023-04-11 06:01:23 --> Router Class Initialized
INFO - 2023-04-11 06:01:23 --> Output Class Initialized
INFO - 2023-04-11 06:01:23 --> Security Class Initialized
DEBUG - 2023-04-11 06:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:23 --> Input Class Initialized
INFO - 2023-04-11 06:01:23 --> Language Class Initialized
INFO - 2023-04-11 06:01:23 --> Loader Class Initialized
INFO - 2023-04-11 06:01:23 --> Controller Class Initialized
DEBUG - 2023-04-11 06:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:01:23 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:23 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:01:23 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:23 --> Total execution time: 0.5805
INFO - 2023-04-11 06:01:23 --> Config Class Initialized
INFO - 2023-04-11 06:01:24 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:01:24 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:24 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:24 --> URI Class Initialized
INFO - 2023-04-11 06:01:24 --> Router Class Initialized
INFO - 2023-04-11 06:01:24 --> Output Class Initialized
INFO - 2023-04-11 06:01:24 --> Security Class Initialized
DEBUG - 2023-04-11 06:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:24 --> Input Class Initialized
INFO - 2023-04-11 06:01:24 --> Language Class Initialized
INFO - 2023-04-11 06:01:24 --> Loader Class Initialized
INFO - 2023-04-11 06:01:24 --> Controller Class Initialized
DEBUG - 2023-04-11 06:01:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:01:24 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:24 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:01:24 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:24 --> Total execution time: 0.2629
INFO - 2023-04-11 06:01:26 --> Config Class Initialized
INFO - 2023-04-11 06:01:26 --> Config Class Initialized
INFO - 2023-04-11 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:26 --> URI Class Initialized
INFO - 2023-04-11 06:01:26 --> Router Class Initialized
INFO - 2023-04-11 06:01:26 --> Output Class Initialized
INFO - 2023-04-11 06:01:26 --> Security Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:26 --> Input Class Initialized
INFO - 2023-04-11 06:01:26 --> Language Class Initialized
INFO - 2023-04-11 06:01:26 --> Loader Class Initialized
INFO - 2023-04-11 06:01:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:01:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:26 --> Total execution time: 0.0973
INFO - 2023-04-11 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:26 --> Config Class Initialized
INFO - 2023-04-11 06:01:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:26 --> Hooks Class Initialized
INFO - 2023-04-11 06:01:26 --> URI Class Initialized
DEBUG - 2023-04-11 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:26 --> Router Class Initialized
INFO - 2023-04-11 06:01:26 --> URI Class Initialized
INFO - 2023-04-11 06:01:26 --> Output Class Initialized
INFO - 2023-04-11 06:01:26 --> Router Class Initialized
INFO - 2023-04-11 06:01:26 --> Security Class Initialized
INFO - 2023-04-11 06:01:26 --> Output Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:26 --> Security Class Initialized
INFO - 2023-04-11 06:01:26 --> Input Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:26 --> Language Class Initialized
INFO - 2023-04-11 06:01:26 --> Input Class Initialized
INFO - 2023-04-11 06:01:26 --> Language Class Initialized
INFO - 2023-04-11 06:01:26 --> Loader Class Initialized
INFO - 2023-04-11 06:01:26 --> Loader Class Initialized
INFO - 2023-04-11 06:01:26 --> Controller Class Initialized
INFO - 2023-04-11 06:01:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:01:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:26 --> Model "Login_model" initialized
INFO - 2023-04-11 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:01:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:26 --> Total execution time: 0.1639
INFO - 2023-04-11 06:01:26 --> Config Class Initialized
INFO - 2023-04-11 06:01:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:01:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:01:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:01:26 --> URI Class Initialized
INFO - 2023-04-11 06:01:26 --> Router Class Initialized
INFO - 2023-04-11 06:01:26 --> Output Class Initialized
INFO - 2023-04-11 06:01:26 --> Security Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:01:26 --> Input Class Initialized
INFO - 2023-04-11 06:01:26 --> Language Class Initialized
INFO - 2023-04-11 06:01:26 --> Loader Class Initialized
INFO - 2023-04-11 06:01:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:01:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:01:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:26 --> Total execution time: 0.0631
INFO - 2023-04-11 06:01:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:01:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:01:26 --> Total execution time: 0.0525
INFO - 2023-04-11 06:11:29 --> Config Class Initialized
INFO - 2023-04-11 06:11:29 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:11:29 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:11:29 --> Utf8 Class Initialized
INFO - 2023-04-11 06:11:29 --> URI Class Initialized
INFO - 2023-04-11 06:11:29 --> Router Class Initialized
INFO - 2023-04-11 06:11:29 --> Output Class Initialized
INFO - 2023-04-11 06:11:29 --> Security Class Initialized
DEBUG - 2023-04-11 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:11:29 --> Input Class Initialized
INFO - 2023-04-11 06:11:29 --> Language Class Initialized
INFO - 2023-04-11 06:11:29 --> Loader Class Initialized
INFO - 2023-04-11 06:11:29 --> Controller Class Initialized
DEBUG - 2023-04-11 06:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:11:29 --> Database Driver Class Initialized
INFO - 2023-04-11 06:11:29 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:11:29 --> Final output sent to browser
DEBUG - 2023-04-11 06:11:29 --> Total execution time: 0.0522
INFO - 2023-04-11 06:11:29 --> Config Class Initialized
INFO - 2023-04-11 06:11:29 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:11:29 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:11:29 --> Utf8 Class Initialized
INFO - 2023-04-11 06:11:29 --> URI Class Initialized
INFO - 2023-04-11 06:11:29 --> Router Class Initialized
INFO - 2023-04-11 06:11:29 --> Output Class Initialized
INFO - 2023-04-11 06:11:29 --> Security Class Initialized
DEBUG - 2023-04-11 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:11:29 --> Input Class Initialized
INFO - 2023-04-11 06:11:29 --> Language Class Initialized
INFO - 2023-04-11 06:11:29 --> Loader Class Initialized
INFO - 2023-04-11 06:11:29 --> Controller Class Initialized
DEBUG - 2023-04-11 06:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:11:29 --> Database Driver Class Initialized
INFO - 2023-04-11 06:11:29 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:11:30 --> Final output sent to browser
DEBUG - 2023-04-11 06:11:30 --> Total execution time: 0.0906
INFO - 2023-04-11 06:20:26 --> Config Class Initialized
INFO - 2023-04-11 06:20:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:20:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:20:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:20:26 --> URI Class Initialized
INFO - 2023-04-11 06:20:26 --> Router Class Initialized
INFO - 2023-04-11 06:20:26 --> Output Class Initialized
INFO - 2023-04-11 06:20:26 --> Security Class Initialized
DEBUG - 2023-04-11 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:20:26 --> Input Class Initialized
INFO - 2023-04-11 06:20:26 --> Language Class Initialized
INFO - 2023-04-11 06:20:26 --> Loader Class Initialized
INFO - 2023-04-11 06:20:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:20:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:20:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:20:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:20:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:20:26 --> Total execution time: 0.2302
INFO - 2023-04-11 06:20:26 --> Config Class Initialized
INFO - 2023-04-11 06:20:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:20:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:20:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:20:26 --> URI Class Initialized
INFO - 2023-04-11 06:20:26 --> Router Class Initialized
INFO - 2023-04-11 06:20:26 --> Output Class Initialized
INFO - 2023-04-11 06:20:26 --> Security Class Initialized
DEBUG - 2023-04-11 06:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:20:26 --> Input Class Initialized
INFO - 2023-04-11 06:20:26 --> Language Class Initialized
INFO - 2023-04-11 06:20:26 --> Loader Class Initialized
INFO - 2023-04-11 06:20:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:20:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:20:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:20:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:20:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:20:26 --> Total execution time: 0.0135
INFO - 2023-04-11 06:22:22 --> Config Class Initialized
INFO - 2023-04-11 06:22:22 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:22 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:22 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:22 --> URI Class Initialized
INFO - 2023-04-11 06:22:22 --> Router Class Initialized
INFO - 2023-04-11 06:22:22 --> Output Class Initialized
INFO - 2023-04-11 06:22:22 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:22 --> Input Class Initialized
INFO - 2023-04-11 06:22:22 --> Language Class Initialized
INFO - 2023-04-11 06:22:22 --> Loader Class Initialized
INFO - 2023-04-11 06:22:22 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:22 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:22 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:22 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:22 --> Total execution time: 0.0554
INFO - 2023-04-11 06:22:22 --> Config Class Initialized
INFO - 2023-04-11 06:22:22 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:22 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:22 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:22 --> URI Class Initialized
INFO - 2023-04-11 06:22:22 --> Router Class Initialized
INFO - 2023-04-11 06:22:22 --> Output Class Initialized
INFO - 2023-04-11 06:22:22 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:22 --> Input Class Initialized
INFO - 2023-04-11 06:22:22 --> Language Class Initialized
INFO - 2023-04-11 06:22:22 --> Loader Class Initialized
INFO - 2023-04-11 06:22:22 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:22 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:22 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:22 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:22 --> Total execution time: 0.0937
INFO - 2023-04-11 06:22:23 --> Config Class Initialized
INFO - 2023-04-11 06:22:23 --> Config Class Initialized
INFO - 2023-04-11 06:22:23 --> Hooks Class Initialized
INFO - 2023-04-11 06:22:23 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 06:22:23 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:23 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:23 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:23 --> URI Class Initialized
INFO - 2023-04-11 06:22:23 --> URI Class Initialized
INFO - 2023-04-11 06:22:23 --> Router Class Initialized
INFO - 2023-04-11 06:22:23 --> Router Class Initialized
INFO - 2023-04-11 06:22:23 --> Output Class Initialized
INFO - 2023-04-11 06:22:23 --> Output Class Initialized
INFO - 2023-04-11 06:22:23 --> Security Class Initialized
INFO - 2023-04-11 06:22:23 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 06:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:23 --> Input Class Initialized
INFO - 2023-04-11 06:22:23 --> Input Class Initialized
INFO - 2023-04-11 06:22:23 --> Language Class Initialized
INFO - 2023-04-11 06:22:23 --> Language Class Initialized
INFO - 2023-04-11 06:22:23 --> Loader Class Initialized
INFO - 2023-04-11 06:22:23 --> Loader Class Initialized
INFO - 2023-04-11 06:22:23 --> Controller Class Initialized
INFO - 2023-04-11 06:22:23 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 06:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:23 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:23 --> Total execution time: 0.0048
INFO - 2023-04-11 06:22:23 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:23 --> Config Class Initialized
INFO - 2023-04-11 06:22:23 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:23 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:23 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:23 --> URI Class Initialized
INFO - 2023-04-11 06:22:23 --> Router Class Initialized
INFO - 2023-04-11 06:22:23 --> Output Class Initialized
INFO - 2023-04-11 06:22:23 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:23 --> Input Class Initialized
INFO - 2023-04-11 06:22:23 --> Language Class Initialized
INFO - 2023-04-11 06:22:23 --> Loader Class Initialized
INFO - 2023-04-11 06:22:23 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:23 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:23 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:23 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:23 --> Total execution time: 0.0188
INFO - 2023-04-11 06:22:23 --> Model "Login_model" initialized
INFO - 2023-04-11 06:22:23 --> Config Class Initialized
INFO - 2023-04-11 06:22:23 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:23 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:23 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:23 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:23 --> URI Class Initialized
INFO - 2023-04-11 06:22:23 --> Router Class Initialized
INFO - 2023-04-11 06:22:23 --> Output Class Initialized
INFO - 2023-04-11 06:22:23 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:23 --> Input Class Initialized
INFO - 2023-04-11 06:22:23 --> Language Class Initialized
INFO - 2023-04-11 06:22:23 --> Loader Class Initialized
INFO - 2023-04-11 06:22:23 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:23 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:23 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:23 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:23 --> Total execution time: 0.0648
INFO - 2023-04-11 06:22:23 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:23 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:23 --> Total execution time: 0.0993
INFO - 2023-04-11 06:22:26 --> Config Class Initialized
INFO - 2023-04-11 06:22:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:22:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:22:26 --> Utf8 Class Initialized
INFO - 2023-04-11 06:22:26 --> URI Class Initialized
INFO - 2023-04-11 06:22:26 --> Router Class Initialized
INFO - 2023-04-11 06:22:26 --> Output Class Initialized
INFO - 2023-04-11 06:22:26 --> Security Class Initialized
DEBUG - 2023-04-11 06:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:22:26 --> Input Class Initialized
INFO - 2023-04-11 06:22:26 --> Language Class Initialized
INFO - 2023-04-11 06:22:26 --> Loader Class Initialized
INFO - 2023-04-11 06:22:26 --> Controller Class Initialized
DEBUG - 2023-04-11 06:22:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:22:26 --> Database Driver Class Initialized
INFO - 2023-04-11 06:22:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:22:26 --> Final output sent to browser
DEBUG - 2023-04-11 06:22:26 --> Total execution time: 0.0854
INFO - 2023-04-11 06:28:14 --> Config Class Initialized
INFO - 2023-04-11 06:28:14 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:28:14 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:28:14 --> Utf8 Class Initialized
INFO - 2023-04-11 06:28:14 --> URI Class Initialized
INFO - 2023-04-11 06:28:14 --> Router Class Initialized
INFO - 2023-04-11 06:28:14 --> Output Class Initialized
INFO - 2023-04-11 06:28:14 --> Security Class Initialized
DEBUG - 2023-04-11 06:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:28:14 --> Input Class Initialized
INFO - 2023-04-11 06:28:14 --> Language Class Initialized
INFO - 2023-04-11 06:28:14 --> Loader Class Initialized
INFO - 2023-04-11 06:28:14 --> Controller Class Initialized
DEBUG - 2023-04-11 06:28:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:28:14 --> Database Driver Class Initialized
INFO - 2023-04-11 06:28:14 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:28:14 --> Final output sent to browser
DEBUG - 2023-04-11 06:28:14 --> Total execution time: 0.0614
INFO - 2023-04-11 06:28:15 --> Config Class Initialized
INFO - 2023-04-11 06:28:15 --> Hooks Class Initialized
DEBUG - 2023-04-11 06:28:15 --> UTF-8 Support Enabled
INFO - 2023-04-11 06:28:15 --> Utf8 Class Initialized
INFO - 2023-04-11 06:28:15 --> URI Class Initialized
INFO - 2023-04-11 06:28:15 --> Router Class Initialized
INFO - 2023-04-11 06:28:15 --> Output Class Initialized
INFO - 2023-04-11 06:28:15 --> Security Class Initialized
DEBUG - 2023-04-11 06:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 06:28:15 --> Input Class Initialized
INFO - 2023-04-11 06:28:15 --> Language Class Initialized
INFO - 2023-04-11 06:28:15 --> Loader Class Initialized
INFO - 2023-04-11 06:28:15 --> Controller Class Initialized
DEBUG - 2023-04-11 06:28:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 06:28:15 --> Database Driver Class Initialized
INFO - 2023-04-11 06:28:15 --> Model "Cluster_model" initialized
INFO - 2023-04-11 06:28:15 --> Final output sent to browser
DEBUG - 2023-04-11 06:28:15 --> Total execution time: 0.0867
INFO - 2023-04-11 07:24:38 --> Config Class Initialized
INFO - 2023-04-11 07:24:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:38 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:38 --> URI Class Initialized
INFO - 2023-04-11 07:24:38 --> Router Class Initialized
INFO - 2023-04-11 07:24:38 --> Output Class Initialized
INFO - 2023-04-11 07:24:38 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:38 --> Input Class Initialized
INFO - 2023-04-11 07:24:38 --> Language Class Initialized
INFO - 2023-04-11 07:24:38 --> Loader Class Initialized
INFO - 2023-04-11 07:24:38 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:38 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:38 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:38 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:38 --> Total execution time: 0.0655
INFO - 2023-04-11 07:24:38 --> Config Class Initialized
INFO - 2023-04-11 07:24:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:38 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:38 --> URI Class Initialized
INFO - 2023-04-11 07:24:38 --> Router Class Initialized
INFO - 2023-04-11 07:24:38 --> Output Class Initialized
INFO - 2023-04-11 07:24:38 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:38 --> Input Class Initialized
INFO - 2023-04-11 07:24:38 --> Language Class Initialized
INFO - 2023-04-11 07:24:38 --> Loader Class Initialized
INFO - 2023-04-11 07:24:38 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:38 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:38 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:38 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:38 --> Total execution time: 0.0547
INFO - 2023-04-11 07:24:40 --> Config Class Initialized
INFO - 2023-04-11 07:24:40 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:40 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:40 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:40 --> URI Class Initialized
INFO - 2023-04-11 07:24:40 --> Router Class Initialized
INFO - 2023-04-11 07:24:40 --> Output Class Initialized
INFO - 2023-04-11 07:24:40 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:40 --> Input Class Initialized
INFO - 2023-04-11 07:24:40 --> Language Class Initialized
INFO - 2023-04-11 07:24:40 --> Loader Class Initialized
INFO - 2023-04-11 07:24:40 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:40 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
INFO - 2023-04-11 07:24:41 --> Config Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.0528
INFO - 2023-04-11 07:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:41 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:41 --> URI Class Initialized
INFO - 2023-04-11 07:24:41 --> Router Class Initialized
INFO - 2023-04-11 07:24:41 --> Output Class Initialized
INFO - 2023-04-11 07:24:41 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:41 --> Input Class Initialized
INFO - 2023-04-11 07:24:41 --> Language Class Initialized
INFO - 2023-04-11 07:24:41 --> Loader Class Initialized
INFO - 2023-04-11 07:24:41 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:41 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.4091
INFO - 2023-04-11 07:24:41 --> Config Class Initialized
INFO - 2023-04-11 07:24:41 --> Config Class Initialized
INFO - 2023-04-11 07:24:41 --> Hooks Class Initialized
INFO - 2023-04-11 07:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 07:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:41 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:41 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:41 --> URI Class Initialized
INFO - 2023-04-11 07:24:41 --> URI Class Initialized
INFO - 2023-04-11 07:24:41 --> Router Class Initialized
INFO - 2023-04-11 07:24:41 --> Output Class Initialized
INFO - 2023-04-11 07:24:41 --> Router Class Initialized
INFO - 2023-04-11 07:24:41 --> Security Class Initialized
INFO - 2023-04-11 07:24:41 --> Output Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:41 --> Security Class Initialized
INFO - 2023-04-11 07:24:41 --> Input Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:41 --> Language Class Initialized
INFO - 2023-04-11 07:24:41 --> Input Class Initialized
INFO - 2023-04-11 07:24:41 --> Language Class Initialized
INFO - 2023-04-11 07:24:41 --> Loader Class Initialized
INFO - 2023-04-11 07:24:41 --> Controller Class Initialized
INFO - 2023-04-11 07:24:41 --> Loader Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:41 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:41 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.0043
INFO - 2023-04-11 07:24:41 --> Config Class Initialized
INFO - 2023-04-11 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:41 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:41 --> URI Class Initialized
INFO - 2023-04-11 07:24:41 --> Router Class Initialized
INFO - 2023-04-11 07:24:41 --> Output Class Initialized
INFO - 2023-04-11 07:24:41 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:41 --> Input Class Initialized
INFO - 2023-04-11 07:24:41 --> Language Class Initialized
INFO - 2023-04-11 07:24:41 --> Loader Class Initialized
INFO - 2023-04-11 07:24:41 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:41 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.0529
INFO - 2023-04-11 07:24:41 --> Config Class Initialized
INFO - 2023-04-11 07:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-11 07:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-11 07:24:41 --> Utf8 Class Initialized
INFO - 2023-04-11 07:24:41 --> URI Class Initialized
INFO - 2023-04-11 07:24:41 --> Router Class Initialized
INFO - 2023-04-11 07:24:41 --> Output Class Initialized
INFO - 2023-04-11 07:24:41 --> Security Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 07:24:41 --> Input Class Initialized
INFO - 2023-04-11 07:24:41 --> Language Class Initialized
INFO - 2023-04-11 07:24:41 --> Loader Class Initialized
INFO - 2023-04-11 07:24:41 --> Controller Class Initialized
DEBUG - 2023-04-11 07:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 07:24:41 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Model "Login_model" initialized
INFO - 2023-04-11 07:24:41 --> Database Driver Class Initialized
INFO - 2023-04-11 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.0630
INFO - 2023-04-11 07:24:41 --> Final output sent to browser
DEBUG - 2023-04-11 07:24:41 --> Total execution time: 0.0161
INFO - 2023-04-11 08:22:36 --> Config Class Initialized
INFO - 2023-04-11 08:22:36 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:36 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:36 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:36 --> URI Class Initialized
INFO - 2023-04-11 08:22:36 --> Router Class Initialized
INFO - 2023-04-11 08:22:36 --> Output Class Initialized
INFO - 2023-04-11 08:22:36 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:36 --> Input Class Initialized
INFO - 2023-04-11 08:22:36 --> Language Class Initialized
INFO - 2023-04-11 08:22:36 --> Loader Class Initialized
INFO - 2023-04-11 08:22:36 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:36 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:37 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:38 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:38 --> Total execution time: 1.6223
INFO - 2023-04-11 08:22:38 --> Config Class Initialized
INFO - 2023-04-11 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:38 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:38 --> URI Class Initialized
INFO - 2023-04-11 08:22:38 --> Router Class Initialized
INFO - 2023-04-11 08:22:38 --> Output Class Initialized
INFO - 2023-04-11 08:22:38 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:38 --> Input Class Initialized
INFO - 2023-04-11 08:22:38 --> Language Class Initialized
INFO - 2023-04-11 08:22:38 --> Loader Class Initialized
INFO - 2023-04-11 08:22:38 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:38 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:38 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:38 --> Config Class Initialized
INFO - 2023-04-11 08:22:38 --> Config Class Initialized
INFO - 2023-04-11 08:22:38 --> Hooks Class Initialized
INFO - 2023-04-11 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:38 --> Utf8 Class Initialized
DEBUG - 2023-04-11 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:38 --> URI Class Initialized
INFO - 2023-04-11 08:22:38 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:38 --> Router Class Initialized
INFO - 2023-04-11 08:22:38 --> Output Class Initialized
INFO - 2023-04-11 08:22:38 --> URI Class Initialized
INFO - 2023-04-11 08:22:38 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:38 --> Router Class Initialized
INFO - 2023-04-11 08:22:38 --> Input Class Initialized
INFO - 2023-04-11 08:22:38 --> Output Class Initialized
INFO - 2023-04-11 08:22:38 --> Language Class Initialized
INFO - 2023-04-11 08:22:38 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:38 --> Loader Class Initialized
INFO - 2023-04-11 08:22:38 --> Input Class Initialized
INFO - 2023-04-11 08:22:38 --> Controller Class Initialized
INFO - 2023-04-11 08:22:38 --> Language Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:38 --> Final output sent to browser
INFO - 2023-04-11 08:22:38 --> Loader Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Total execution time: 0.0431
INFO - 2023-04-11 08:22:38 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:38 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:38 --> Config Class Initialized
INFO - 2023-04-11 08:22:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:38 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:38 --> URI Class Initialized
INFO - 2023-04-11 08:22:38 --> Router Class Initialized
INFO - 2023-04-11 08:22:38 --> Output Class Initialized
INFO - 2023-04-11 08:22:38 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:38 --> Input Class Initialized
INFO - 2023-04-11 08:22:38 --> Language Class Initialized
INFO - 2023-04-11 08:22:38 --> Loader Class Initialized
INFO - 2023-04-11 08:22:38 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:38 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:38 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:38 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:38 --> Final output sent to browser
INFO - 2023-04-11 08:22:38 --> Database Driver Class Initialized
DEBUG - 2023-04-11 08:22:38 --> Total execution time: 0.6258
INFO - 2023-04-11 08:22:39 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:39 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:39 --> Total execution time: 0.3909
INFO - 2023-04-11 08:22:39 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:39 --> Total execution time: 1.2428
INFO - 2023-04-11 08:22:39 --> Config Class Initialized
INFO - 2023-04-11 08:22:39 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:39 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:39 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:39 --> URI Class Initialized
INFO - 2023-04-11 08:22:39 --> Router Class Initialized
INFO - 2023-04-11 08:22:39 --> Output Class Initialized
INFO - 2023-04-11 08:22:39 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:39 --> Input Class Initialized
INFO - 2023-04-11 08:22:39 --> Language Class Initialized
INFO - 2023-04-11 08:22:39 --> Loader Class Initialized
INFO - 2023-04-11 08:22:39 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:39 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:40 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:40 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:40 --> Total execution time: 0.2340
INFO - 2023-04-11 08:22:43 --> Config Class Initialized
INFO - 2023-04-11 08:22:43 --> Config Class Initialized
INFO - 2023-04-11 08:22:43 --> Hooks Class Initialized
INFO - 2023-04-11 08:22:43 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:22:43 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:43 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:43 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:43 --> URI Class Initialized
INFO - 2023-04-11 08:22:43 --> URI Class Initialized
INFO - 2023-04-11 08:22:43 --> Router Class Initialized
INFO - 2023-04-11 08:22:43 --> Router Class Initialized
INFO - 2023-04-11 08:22:43 --> Output Class Initialized
INFO - 2023-04-11 08:22:43 --> Output Class Initialized
INFO - 2023-04-11 08:22:43 --> Security Class Initialized
INFO - 2023-04-11 08:22:43 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:43 --> Input Class Initialized
INFO - 2023-04-11 08:22:43 --> Input Class Initialized
INFO - 2023-04-11 08:22:43 --> Language Class Initialized
INFO - 2023-04-11 08:22:43 --> Language Class Initialized
INFO - 2023-04-11 08:22:43 --> Loader Class Initialized
INFO - 2023-04-11 08:22:43 --> Loader Class Initialized
INFO - 2023-04-11 08:22:43 --> Controller Class Initialized
INFO - 2023-04-11 08:22:43 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:43 --> Final output sent to browser
INFO - 2023-04-11 08:22:43 --> Database Driver Class Initialized
DEBUG - 2023-04-11 08:22:43 --> Total execution time: 0.0867
INFO - 2023-04-11 08:22:43 --> Config Class Initialized
INFO - 2023-04-11 08:22:43 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:43 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:43 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:43 --> URI Class Initialized
INFO - 2023-04-11 08:22:43 --> Router Class Initialized
INFO - 2023-04-11 08:22:43 --> Output Class Initialized
INFO - 2023-04-11 08:22:43 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:43 --> Input Class Initialized
INFO - 2023-04-11 08:22:43 --> Language Class Initialized
INFO - 2023-04-11 08:22:43 --> Loader Class Initialized
INFO - 2023-04-11 08:22:43 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:43 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:43 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:43 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:43 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:44 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:44 --> Total execution time: 0.2601
INFO - 2023-04-11 08:22:44 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:44 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:44 --> Total execution time: 0.2656
INFO - 2023-04-11 08:22:47 --> Config Class Initialized
INFO - 2023-04-11 08:22:47 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:47 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:47 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:47 --> URI Class Initialized
INFO - 2023-04-11 08:22:47 --> Router Class Initialized
INFO - 2023-04-11 08:22:47 --> Output Class Initialized
INFO - 2023-04-11 08:22:47 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:47 --> Input Class Initialized
INFO - 2023-04-11 08:22:47 --> Language Class Initialized
INFO - 2023-04-11 08:22:47 --> Loader Class Initialized
INFO - 2023-04-11 08:22:47 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:47 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:48 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:48 --> Total execution time: 0.6934
INFO - 2023-04-11 08:22:48 --> Config Class Initialized
INFO - 2023-04-11 08:22:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:48 --> URI Class Initialized
INFO - 2023-04-11 08:22:48 --> Router Class Initialized
INFO - 2023-04-11 08:22:48 --> Output Class Initialized
INFO - 2023-04-11 08:22:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:48 --> Input Class Initialized
INFO - 2023-04-11 08:22:48 --> Language Class Initialized
INFO - 2023-04-11 08:22:48 --> Loader Class Initialized
INFO - 2023-04-11 08:22:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:48 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:48 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:48 --> Total execution time: 0.6374
INFO - 2023-04-11 08:22:55 --> Config Class Initialized
INFO - 2023-04-11 08:22:55 --> Hooks Class Initialized
INFO - 2023-04-11 08:22:55 --> Config Class Initialized
INFO - 2023-04-11 08:22:55 --> Config Class Initialized
INFO - 2023-04-11 08:22:55 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:55 --> Hooks Class Initialized
INFO - 2023-04-11 08:22:55 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:55 --> Utf8 Class Initialized
DEBUG - 2023-04-11 08:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:55 --> URI Class Initialized
INFO - 2023-04-11 08:22:55 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:55 --> URI Class Initialized
INFO - 2023-04-11 08:22:55 --> URI Class Initialized
INFO - 2023-04-11 08:22:55 --> Router Class Initialized
INFO - 2023-04-11 08:22:55 --> Router Class Initialized
INFO - 2023-04-11 08:22:55 --> Router Class Initialized
INFO - 2023-04-11 08:22:55 --> Output Class Initialized
INFO - 2023-04-11 08:22:55 --> Output Class Initialized
INFO - 2023-04-11 08:22:55 --> Output Class Initialized
INFO - 2023-04-11 08:22:55 --> Security Class Initialized
INFO - 2023-04-11 08:22:55 --> Security Class Initialized
INFO - 2023-04-11 08:22:55 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:55 --> Input Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:55 --> Language Class Initialized
INFO - 2023-04-11 08:22:55 --> Input Class Initialized
INFO - 2023-04-11 08:22:55 --> Input Class Initialized
INFO - 2023-04-11 08:22:55 --> Language Class Initialized
INFO - 2023-04-11 08:22:55 --> Language Class Initialized
INFO - 2023-04-11 08:22:55 --> Loader Class Initialized
INFO - 2023-04-11 08:22:55 --> Loader Class Initialized
INFO - 2023-04-11 08:22:55 --> Loader Class Initialized
INFO - 2023-04-11 08:22:55 --> Controller Class Initialized
INFO - 2023-04-11 08:22:55 --> Controller Class Initialized
INFO - 2023-04-11 08:22:55 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> Config Class Initialized
INFO - 2023-04-11 08:22:55 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:55 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:55 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:55 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> URI Class Initialized
INFO - 2023-04-11 08:22:55 --> Router Class Initialized
INFO - 2023-04-11 08:22:55 --> Output Class Initialized
INFO - 2023-04-11 08:22:55 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:55 --> Input Class Initialized
INFO - 2023-04-11 08:22:55 --> Language Class Initialized
INFO - 2023-04-11 08:22:55 --> Loader Class Initialized
INFO - 2023-04-11 08:22:55 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:22:55 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-04-11 08:22:55 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:22:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:22:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:22:55 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:55 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:22:55 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:55 --> Total execution time: 0.3098
INFO - 2023-04-11 08:22:55 --> Config Class Initialized
ERROR - 2023-04-11 08:22:55 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:22:55 --> Hooks Class Initialized
INFO - 2023-04-11 08:22:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2023-04-11 08:22:55 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:22:55 --> Utf8 Class Initialized
INFO - 2023-04-11 08:22:55 --> URI Class Initialized
INFO - 2023-04-11 08:22:55 --> Router Class Initialized
INFO - 2023-04-11 08:22:55 --> Output Class Initialized
INFO - 2023-04-11 08:22:55 --> Security Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:22:55 --> Input Class Initialized
INFO - 2023-04-11 08:22:55 --> Language Class Initialized
INFO - 2023-04-11 08:22:55 --> Loader Class Initialized
INFO - 2023-04-11 08:22:55 --> Controller Class Initialized
DEBUG - 2023-04-11 08:22:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> Database Driver Class Initialized
INFO - 2023-04-11 08:22:55 --> Model "Login_model" initialized
INFO - 2023-04-11 08:22:55 --> Final output sent to browser
DEBUG - 2023-04-11 08:22:55 --> Total execution time: 0.3106
INFO - 2023-04-11 08:23:24 --> Config Class Initialized
INFO - 2023-04-11 08:23:24 --> Config Class Initialized
INFO - 2023-04-11 08:23:24 --> Config Class Initialized
INFO - 2023-04-11 08:23:24 --> Hooks Class Initialized
INFO - 2023-04-11 08:23:24 --> Hooks Class Initialized
INFO - 2023-04-11 08:23:24 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:23:24 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:24 --> Utf8 Class Initialized
DEBUG - 2023-04-11 08:23:24 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:24 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:24 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:24 --> URI Class Initialized
INFO - 2023-04-11 08:23:24 --> URI Class Initialized
INFO - 2023-04-11 08:23:24 --> URI Class Initialized
INFO - 2023-04-11 08:23:24 --> Router Class Initialized
INFO - 2023-04-11 08:23:24 --> Router Class Initialized
INFO - 2023-04-11 08:23:24 --> Router Class Initialized
INFO - 2023-04-11 08:23:24 --> Output Class Initialized
INFO - 2023-04-11 08:23:24 --> Output Class Initialized
INFO - 2023-04-11 08:23:24 --> Output Class Initialized
INFO - 2023-04-11 08:23:24 --> Security Class Initialized
INFO - 2023-04-11 08:23:24 --> Security Class Initialized
INFO - 2023-04-11 08:23:24 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:24 --> Input Class Initialized
INFO - 2023-04-11 08:23:24 --> Input Class Initialized
INFO - 2023-04-11 08:23:24 --> Input Class Initialized
INFO - 2023-04-11 08:23:24 --> Language Class Initialized
INFO - 2023-04-11 08:23:24 --> Language Class Initialized
INFO - 2023-04-11 08:23:24 --> Language Class Initialized
INFO - 2023-04-11 08:23:24 --> Loader Class Initialized
INFO - 2023-04-11 08:23:24 --> Loader Class Initialized
INFO - 2023-04-11 08:23:24 --> Loader Class Initialized
INFO - 2023-04-11 08:23:24 --> Controller Class Initialized
INFO - 2023-04-11 08:23:24 --> Controller Class Initialized
INFO - 2023-04-11 08:23:24 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:24 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:24 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:24 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:25 --> Config Class Initialized
INFO - 2023-04-11 08:23:25 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:25 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:25 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:25 --> URI Class Initialized
INFO - 2023-04-11 08:23:25 --> Router Class Initialized
INFO - 2023-04-11 08:23:25 --> Output Class Initialized
INFO - 2023-04-11 08:23:25 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:25 --> Input Class Initialized
INFO - 2023-04-11 08:23:25 --> Language Class Initialized
INFO - 2023-04-11 08:23:25 --> Loader Class Initialized
INFO - 2023-04-11 08:23:25 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:25 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:23:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:23:26 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:23:26 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-04-11 08:23:26 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:23:26 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:23:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-11 08:23:26 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:23:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:23:27 --> Model "Login_model" initialized
INFO - 2023-04-11 08:23:27 --> Final output sent to browser
DEBUG - 2023-04-11 08:23:27 --> Total execution time: 2.7684
INFO - 2023-04-11 08:23:27 --> Config Class Initialized
INFO - 2023-04-11 08:23:27 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:27 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:27 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:27 --> URI Class Initialized
INFO - 2023-04-11 08:23:27 --> Router Class Initialized
INFO - 2023-04-11 08:23:27 --> Output Class Initialized
INFO - 2023-04-11 08:23:27 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:27 --> Input Class Initialized
INFO - 2023-04-11 08:23:27 --> Language Class Initialized
INFO - 2023-04-11 08:23:27 --> Loader Class Initialized
INFO - 2023-04-11 08:23:27 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:27 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:27 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:29 --> Config Class Initialized
INFO - 2023-04-11 08:23:29 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:29 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:29 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:29 --> URI Class Initialized
INFO - 2023-04-11 08:23:29 --> Router Class Initialized
INFO - 2023-04-11 08:23:29 --> Output Class Initialized
INFO - 2023-04-11 08:23:29 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:29 --> Input Class Initialized
INFO - 2023-04-11 08:23:29 --> Language Class Initialized
INFO - 2023-04-11 08:23:29 --> Loader Class Initialized
INFO - 2023-04-11 08:23:29 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:29 --> Final output sent to browser
DEBUG - 2023-04-11 08:23:29 --> Total execution time: 0.0417
INFO - 2023-04-11 08:23:29 --> Config Class Initialized
INFO - 2023-04-11 08:23:29 --> Model "Login_model" initialized
INFO - 2023-04-11 08:23:29 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:29 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:29 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:29 --> URI Class Initialized
INFO - 2023-04-11 08:23:29 --> Router Class Initialized
INFO - 2023-04-11 08:23:29 --> Output Class Initialized
INFO - 2023-04-11 08:23:29 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:29 --> Input Class Initialized
INFO - 2023-04-11 08:23:29 --> Language Class Initialized
INFO - 2023-04-11 08:23:29 --> Loader Class Initialized
INFO - 2023-04-11 08:23:29 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:29 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:29 --> Final output sent to browser
DEBUG - 2023-04-11 08:23:29 --> Total execution time: 1.9083
INFO - 2023-04-11 08:23:29 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:23:29 --> Final output sent to browser
DEBUG - 2023-04-11 08:23:29 --> Total execution time: 0.1226
INFO - 2023-04-11 08:23:32 --> Config Class Initialized
INFO - 2023-04-11 08:23:32 --> Config Class Initialized
INFO - 2023-04-11 08:23:32 --> Hooks Class Initialized
INFO - 2023-04-11 08:23:32 --> Config Class Initialized
INFO - 2023-04-11 08:23:32 --> Hooks Class Initialized
INFO - 2023-04-11 08:23:32 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:23:32 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:32 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:32 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:32 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:32 --> URI Class Initialized
INFO - 2023-04-11 08:23:32 --> URI Class Initialized
INFO - 2023-04-11 08:23:32 --> URI Class Initialized
INFO - 2023-04-11 08:23:32 --> Router Class Initialized
INFO - 2023-04-11 08:23:32 --> Router Class Initialized
INFO - 2023-04-11 08:23:32 --> Router Class Initialized
INFO - 2023-04-11 08:23:32 --> Output Class Initialized
INFO - 2023-04-11 08:23:32 --> Output Class Initialized
INFO - 2023-04-11 08:23:32 --> Output Class Initialized
INFO - 2023-04-11 08:23:32 --> Security Class Initialized
INFO - 2023-04-11 08:23:32 --> Security Class Initialized
INFO - 2023-04-11 08:23:32 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:32 --> Input Class Initialized
INFO - 2023-04-11 08:23:32 --> Input Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:32 --> Language Class Initialized
INFO - 2023-04-11 08:23:32 --> Language Class Initialized
INFO - 2023-04-11 08:23:32 --> Input Class Initialized
INFO - 2023-04-11 08:23:32 --> Language Class Initialized
INFO - 2023-04-11 08:23:32 --> Loader Class Initialized
INFO - 2023-04-11 08:23:32 --> Loader Class Initialized
INFO - 2023-04-11 08:23:32 --> Controller Class Initialized
INFO - 2023-04-11 08:23:32 --> Loader Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:32 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:32 --> Controller Class Initialized
INFO - 2023-04-11 08:23:32 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:32 --> Database Driver Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:32 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:32 --> Config Class Initialized
INFO - 2023-04-11 08:23:32 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:23:32 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:23:32 --> Utf8 Class Initialized
INFO - 2023-04-11 08:23:32 --> URI Class Initialized
INFO - 2023-04-11 08:23:32 --> Router Class Initialized
INFO - 2023-04-11 08:23:32 --> Output Class Initialized
INFO - 2023-04-11 08:23:32 --> Security Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:23:32 --> Input Class Initialized
INFO - 2023-04-11 08:23:32 --> Language Class Initialized
INFO - 2023-04-11 08:23:32 --> Loader Class Initialized
INFO - 2023-04-11 08:23:32 --> Controller Class Initialized
DEBUG - 2023-04-11 08:23:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:23:32 --> Database Driver Class Initialized
INFO - 2023-04-11 08:23:32 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:23:32 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:23:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:23:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:23:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:23:33 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:23:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-04-11 08:23:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:23:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:23:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:23:33 --> Model "Login_model" initialized
INFO - 2023-04-11 08:23:33 --> Final output sent to browser
DEBUG - 2023-04-11 08:23:33 --> Total execution time: 1.2354
INFO - 2023-04-11 08:24:33 --> Config Class Initialized
INFO - 2023-04-11 08:24:33 --> Config Class Initialized
INFO - 2023-04-11 08:24:33 --> Hooks Class Initialized
INFO - 2023-04-11 08:24:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:24:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:24:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:24:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:24:33 --> URI Class Initialized
INFO - 2023-04-11 08:24:33 --> URI Class Initialized
INFO - 2023-04-11 08:24:33 --> Router Class Initialized
INFO - 2023-04-11 08:24:33 --> Router Class Initialized
INFO - 2023-04-11 08:24:33 --> Output Class Initialized
INFO - 2023-04-11 08:24:33 --> Output Class Initialized
INFO - 2023-04-11 08:24:33 --> Security Class Initialized
INFO - 2023-04-11 08:24:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:24:33 --> Input Class Initialized
INFO - 2023-04-11 08:24:33 --> Input Class Initialized
INFO - 2023-04-11 08:24:33 --> Language Class Initialized
INFO - 2023-04-11 08:24:33 --> Language Class Initialized
INFO - 2023-04-11 08:24:33 --> Loader Class Initialized
INFO - 2023-04-11 08:24:33 --> Loader Class Initialized
INFO - 2023-04-11 08:24:33 --> Controller Class Initialized
INFO - 2023-04-11 08:24:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:24:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:24:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:24:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:24:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:24:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:24:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:24:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:24:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:24:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:24:33 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:24:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:24:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:25:33 --> Config Class Initialized
INFO - 2023-04-11 08:25:33 --> Config Class Initialized
INFO - 2023-04-11 08:25:33 --> Hooks Class Initialized
INFO - 2023-04-11 08:25:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:25:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:25:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:25:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:25:33 --> URI Class Initialized
INFO - 2023-04-11 08:25:33 --> URI Class Initialized
INFO - 2023-04-11 08:25:33 --> Router Class Initialized
INFO - 2023-04-11 08:25:33 --> Router Class Initialized
INFO - 2023-04-11 08:25:33 --> Output Class Initialized
INFO - 2023-04-11 08:25:33 --> Output Class Initialized
INFO - 2023-04-11 08:25:33 --> Security Class Initialized
INFO - 2023-04-11 08:25:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:25:33 --> Input Class Initialized
INFO - 2023-04-11 08:25:33 --> Input Class Initialized
INFO - 2023-04-11 08:25:33 --> Language Class Initialized
INFO - 2023-04-11 08:25:33 --> Language Class Initialized
INFO - 2023-04-11 08:25:33 --> Loader Class Initialized
INFO - 2023-04-11 08:25:33 --> Loader Class Initialized
INFO - 2023-04-11 08:25:33 --> Controller Class Initialized
INFO - 2023-04-11 08:25:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:25:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:25:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:25:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:25:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:25:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:25:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:25:33 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:25:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:25:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:25:33 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:25:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:25:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:26:33 --> Config Class Initialized
INFO - 2023-04-11 08:26:33 --> Config Class Initialized
INFO - 2023-04-11 08:26:33 --> Hooks Class Initialized
INFO - 2023-04-11 08:26:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:26:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:26:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:26:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:26:33 --> URI Class Initialized
INFO - 2023-04-11 08:26:33 --> URI Class Initialized
INFO - 2023-04-11 08:26:33 --> Router Class Initialized
INFO - 2023-04-11 08:26:33 --> Router Class Initialized
INFO - 2023-04-11 08:26:33 --> Output Class Initialized
INFO - 2023-04-11 08:26:33 --> Output Class Initialized
INFO - 2023-04-11 08:26:33 --> Security Class Initialized
INFO - 2023-04-11 08:26:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:26:33 --> Input Class Initialized
DEBUG - 2023-04-11 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:26:33 --> Language Class Initialized
INFO - 2023-04-11 08:26:33 --> Input Class Initialized
INFO - 2023-04-11 08:26:33 --> Language Class Initialized
INFO - 2023-04-11 08:26:33 --> Loader Class Initialized
INFO - 2023-04-11 08:26:33 --> Loader Class Initialized
INFO - 2023-04-11 08:26:33 --> Controller Class Initialized
INFO - 2023-04-11 08:26:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:26:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:26:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:26:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:26:33 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:26:33 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:26:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:26:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:26:33 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:26:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:26:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:27:33 --> Config Class Initialized
INFO - 2023-04-11 08:27:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:27:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:27:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:27:33 --> URI Class Initialized
INFO - 2023-04-11 08:27:33 --> Router Class Initialized
INFO - 2023-04-11 08:27:33 --> Output Class Initialized
INFO - 2023-04-11 08:27:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:27:33 --> Input Class Initialized
INFO - 2023-04-11 08:27:33 --> Language Class Initialized
INFO - 2023-04-11 08:27:33 --> Loader Class Initialized
INFO - 2023-04-11 08:27:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:27:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:27:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:27:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:27:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:27:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:27:34 --> Config Class Initialized
INFO - 2023-04-11 08:27:34 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:27:34 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:27:34 --> Utf8 Class Initialized
INFO - 2023-04-11 08:27:34 --> URI Class Initialized
INFO - 2023-04-11 08:27:34 --> Router Class Initialized
INFO - 2023-04-11 08:27:34 --> Output Class Initialized
INFO - 2023-04-11 08:27:34 --> Security Class Initialized
DEBUG - 2023-04-11 08:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:27:34 --> Input Class Initialized
INFO - 2023-04-11 08:27:34 --> Language Class Initialized
INFO - 2023-04-11 08:27:34 --> Loader Class Initialized
INFO - 2023-04-11 08:27:34 --> Controller Class Initialized
DEBUG - 2023-04-11 08:27:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:27:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:27:34 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:27:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:27:34 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:27:34 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:27:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:28:33 --> Config Class Initialized
INFO - 2023-04-11 08:28:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:28:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:28:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:28:33 --> URI Class Initialized
INFO - 2023-04-11 08:28:33 --> Router Class Initialized
INFO - 2023-04-11 08:28:33 --> Output Class Initialized
INFO - 2023-04-11 08:28:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:28:33 --> Input Class Initialized
INFO - 2023-04-11 08:28:33 --> Language Class Initialized
INFO - 2023-04-11 08:28:33 --> Loader Class Initialized
INFO - 2023-04-11 08:28:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:28:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:28:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:28:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:28:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:28:34 --> Config Class Initialized
INFO - 2023-04-11 08:28:34 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:28:34 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:28:34 --> Utf8 Class Initialized
INFO - 2023-04-11 08:28:34 --> URI Class Initialized
INFO - 2023-04-11 08:28:34 --> Router Class Initialized
INFO - 2023-04-11 08:28:34 --> Output Class Initialized
INFO - 2023-04-11 08:28:34 --> Security Class Initialized
DEBUG - 2023-04-11 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:28:34 --> Input Class Initialized
INFO - 2023-04-11 08:28:34 --> Language Class Initialized
INFO - 2023-04-11 08:28:34 --> Loader Class Initialized
INFO - 2023-04-11 08:28:34 --> Controller Class Initialized
DEBUG - 2023-04-11 08:28:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:28:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:28:34 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:28:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:28:34 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:28:34 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:28:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:29:51 --> Config Class Initialized
INFO - 2023-04-11 08:29:51 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:29:51 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:29:51 --> Utf8 Class Initialized
INFO - 2023-04-11 08:29:51 --> URI Class Initialized
INFO - 2023-04-11 08:29:51 --> Router Class Initialized
INFO - 2023-04-11 08:29:51 --> Output Class Initialized
INFO - 2023-04-11 08:29:51 --> Security Class Initialized
DEBUG - 2023-04-11 08:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:29:51 --> Input Class Initialized
INFO - 2023-04-11 08:29:51 --> Language Class Initialized
INFO - 2023-04-11 08:29:51 --> Loader Class Initialized
INFO - 2023-04-11 08:29:51 --> Controller Class Initialized
DEBUG - 2023-04-11 08:29:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:29:51 --> Database Driver Class Initialized
INFO - 2023-04-11 08:29:51 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:29:51 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:29:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:30:51 --> Config Class Initialized
INFO - 2023-04-11 08:30:51 --> Config Class Initialized
INFO - 2023-04-11 08:30:51 --> Hooks Class Initialized
INFO - 2023-04-11 08:30:51 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:30:51 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:30:51 --> Utf8 Class Initialized
INFO - 2023-04-11 08:30:51 --> Utf8 Class Initialized
INFO - 2023-04-11 08:30:51 --> URI Class Initialized
INFO - 2023-04-11 08:30:51 --> URI Class Initialized
INFO - 2023-04-11 08:30:51 --> Router Class Initialized
INFO - 2023-04-11 08:30:51 --> Router Class Initialized
INFO - 2023-04-11 08:30:51 --> Output Class Initialized
INFO - 2023-04-11 08:30:51 --> Output Class Initialized
INFO - 2023-04-11 08:30:51 --> Security Class Initialized
INFO - 2023-04-11 08:30:51 --> Security Class Initialized
DEBUG - 2023-04-11 08:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:30:51 --> Input Class Initialized
INFO - 2023-04-11 08:30:51 --> Input Class Initialized
INFO - 2023-04-11 08:30:51 --> Language Class Initialized
INFO - 2023-04-11 08:30:51 --> Language Class Initialized
INFO - 2023-04-11 08:30:51 --> Loader Class Initialized
INFO - 2023-04-11 08:30:51 --> Loader Class Initialized
INFO - 2023-04-11 08:30:51 --> Controller Class Initialized
INFO - 2023-04-11 08:30:51 --> Controller Class Initialized
DEBUG - 2023-04-11 08:30:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:30:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:30:51 --> Database Driver Class Initialized
INFO - 2023-04-11 08:30:51 --> Database Driver Class Initialized
INFO - 2023-04-11 08:30:51 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:30:51 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:30:51 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:30:51 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:30:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:30:51 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:30:51 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:30:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:31:48 --> Config Class Initialized
INFO - 2023-04-11 08:31:48 --> Config Class Initialized
INFO - 2023-04-11 08:31:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:31:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:31:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:31:48 --> URI Class Initialized
INFO - 2023-04-11 08:31:48 --> URI Class Initialized
INFO - 2023-04-11 08:31:48 --> Router Class Initialized
INFO - 2023-04-11 08:31:48 --> Router Class Initialized
INFO - 2023-04-11 08:31:48 --> Output Class Initialized
INFO - 2023-04-11 08:31:48 --> Output Class Initialized
INFO - 2023-04-11 08:31:48 --> Security Class Initialized
INFO - 2023-04-11 08:31:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:31:48 --> Input Class Initialized
INFO - 2023-04-11 08:31:48 --> Input Class Initialized
INFO - 2023-04-11 08:31:48 --> Language Class Initialized
INFO - 2023-04-11 08:31:48 --> Language Class Initialized
INFO - 2023-04-11 08:31:48 --> Loader Class Initialized
INFO - 2023-04-11 08:31:48 --> Loader Class Initialized
INFO - 2023-04-11 08:31:48 --> Controller Class Initialized
INFO - 2023-04-11 08:31:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:31:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:31:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:31:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:31:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:31:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:31:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:31:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:31:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:31:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:31:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:31:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:31:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:32:48 --> Config Class Initialized
INFO - 2023-04-11 08:32:48 --> Config Class Initialized
INFO - 2023-04-11 08:32:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:32:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:32:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:32:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:32:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:32:48 --> URI Class Initialized
INFO - 2023-04-11 08:32:48 --> URI Class Initialized
INFO - 2023-04-11 08:32:48 --> Router Class Initialized
INFO - 2023-04-11 08:32:48 --> Router Class Initialized
INFO - 2023-04-11 08:32:48 --> Output Class Initialized
INFO - 2023-04-11 08:32:48 --> Output Class Initialized
INFO - 2023-04-11 08:32:48 --> Security Class Initialized
INFO - 2023-04-11 08:32:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:32:48 --> Input Class Initialized
INFO - 2023-04-11 08:32:48 --> Input Class Initialized
INFO - 2023-04-11 08:32:48 --> Language Class Initialized
INFO - 2023-04-11 08:32:48 --> Language Class Initialized
INFO - 2023-04-11 08:32:48 --> Loader Class Initialized
INFO - 2023-04-11 08:32:48 --> Loader Class Initialized
INFO - 2023-04-11 08:32:48 --> Controller Class Initialized
INFO - 2023-04-11 08:32:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:32:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:32:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:32:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:32:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:32:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:32:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:32:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:32:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:32:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:32:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:33:48 --> Config Class Initialized
INFO - 2023-04-11 08:33:48 --> Config Class Initialized
INFO - 2023-04-11 08:33:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:33:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:33:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:33:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:33:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:33:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:33:48 --> URI Class Initialized
INFO - 2023-04-11 08:33:48 --> URI Class Initialized
INFO - 2023-04-11 08:33:48 --> Router Class Initialized
INFO - 2023-04-11 08:33:48 --> Router Class Initialized
INFO - 2023-04-11 08:33:48 --> Output Class Initialized
INFO - 2023-04-11 08:33:48 --> Output Class Initialized
INFO - 2023-04-11 08:33:48 --> Security Class Initialized
INFO - 2023-04-11 08:33:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:33:48 --> Input Class Initialized
INFO - 2023-04-11 08:33:48 --> Input Class Initialized
INFO - 2023-04-11 08:33:48 --> Language Class Initialized
INFO - 2023-04-11 08:33:48 --> Language Class Initialized
INFO - 2023-04-11 08:33:48 --> Loader Class Initialized
INFO - 2023-04-11 08:33:48 --> Loader Class Initialized
INFO - 2023-04-11 08:33:48 --> Controller Class Initialized
INFO - 2023-04-11 08:33:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:33:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:33:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:33:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:33:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:33:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:33:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:33:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:33:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:33:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:33:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:34:48 --> Config Class Initialized
INFO - 2023-04-11 08:34:48 --> Config Class Initialized
INFO - 2023-04-11 08:34:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:34:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:34:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:34:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:34:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:34:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:34:48 --> URI Class Initialized
INFO - 2023-04-11 08:34:48 --> URI Class Initialized
INFO - 2023-04-11 08:34:48 --> Router Class Initialized
INFO - 2023-04-11 08:34:48 --> Router Class Initialized
INFO - 2023-04-11 08:34:48 --> Output Class Initialized
INFO - 2023-04-11 08:34:48 --> Output Class Initialized
INFO - 2023-04-11 08:34:48 --> Security Class Initialized
INFO - 2023-04-11 08:34:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:34:48 --> Input Class Initialized
INFO - 2023-04-11 08:34:48 --> Input Class Initialized
INFO - 2023-04-11 08:34:48 --> Language Class Initialized
INFO - 2023-04-11 08:34:48 --> Language Class Initialized
INFO - 2023-04-11 08:34:48 --> Loader Class Initialized
INFO - 2023-04-11 08:34:48 --> Loader Class Initialized
INFO - 2023-04-11 08:34:48 --> Controller Class Initialized
INFO - 2023-04-11 08:34:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:34:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:34:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:34:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:34:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:34:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:34:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:34:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:34:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:34:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:34:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:34:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:34:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:35:48 --> Config Class Initialized
INFO - 2023-04-11 08:35:48 --> Config Class Initialized
INFO - 2023-04-11 08:35:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:35:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:35:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:35:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:35:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:35:48 --> URI Class Initialized
INFO - 2023-04-11 08:35:48 --> URI Class Initialized
INFO - 2023-04-11 08:35:48 --> Router Class Initialized
INFO - 2023-04-11 08:35:48 --> Router Class Initialized
INFO - 2023-04-11 08:35:48 --> Output Class Initialized
INFO - 2023-04-11 08:35:48 --> Output Class Initialized
INFO - 2023-04-11 08:35:48 --> Security Class Initialized
INFO - 2023-04-11 08:35:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:35:48 --> Input Class Initialized
INFO - 2023-04-11 08:35:48 --> Input Class Initialized
INFO - 2023-04-11 08:35:48 --> Language Class Initialized
INFO - 2023-04-11 08:35:48 --> Language Class Initialized
INFO - 2023-04-11 08:35:48 --> Loader Class Initialized
INFO - 2023-04-11 08:35:48 --> Loader Class Initialized
INFO - 2023-04-11 08:35:48 --> Controller Class Initialized
INFO - 2023-04-11 08:35:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:35:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:35:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:35:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:35:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:35:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:35:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:35:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:35:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:35:49 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:35:49 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:36:54 --> Config Class Initialized
INFO - 2023-04-11 08:36:54 --> Config Class Initialized
INFO - 2023-04-11 08:36:54 --> Hooks Class Initialized
INFO - 2023-04-11 08:36:54 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:36:54 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:36:54 --> Utf8 Class Initialized
INFO - 2023-04-11 08:36:54 --> URI Class Initialized
INFO - 2023-04-11 08:36:54 --> Router Class Initialized
INFO - 2023-04-11 08:36:54 --> Output Class Initialized
INFO - 2023-04-11 08:36:54 --> Security Class Initialized
DEBUG - 2023-04-11 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:36:54 --> Input Class Initialized
INFO - 2023-04-11 08:36:54 --> Language Class Initialized
INFO - 2023-04-11 08:36:54 --> Loader Class Initialized
INFO - 2023-04-11 08:36:54 --> Controller Class Initialized
DEBUG - 2023-04-11 08:36:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:36:54 --> Database Driver Class Initialized
DEBUG - 2023-04-11 08:36:54 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:36:54 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:36:54 --> Utf8 Class Initialized
INFO - 2023-04-11 08:36:54 --> URI Class Initialized
INFO - 2023-04-11 08:36:54 --> Router Class Initialized
INFO - 2023-04-11 08:36:54 --> Output Class Initialized
INFO - 2023-04-11 08:36:54 --> Security Class Initialized
DEBUG - 2023-04-11 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:36:54 --> Input Class Initialized
INFO - 2023-04-11 08:36:54 --> Language Class Initialized
INFO - 2023-04-11 08:36:54 --> Loader Class Initialized
INFO - 2023-04-11 08:36:54 --> Controller Class Initialized
ERROR - 2023-04-11 08:36:54 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
DEBUG - 2023-04-11 08:36:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:36:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:36:54 --> Database Driver Class Initialized
INFO - 2023-04-11 08:36:54 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:36:54 --> Database Driver Class Initialized
INFO - 2023-04-11 08:36:54 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:36:54 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:36:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:37:48 --> Config Class Initialized
INFO - 2023-04-11 08:37:48 --> Config Class Initialized
INFO - 2023-04-11 08:37:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:37:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:37:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:37:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:37:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:37:48 --> URI Class Initialized
INFO - 2023-04-11 08:37:48 --> URI Class Initialized
INFO - 2023-04-11 08:37:48 --> Router Class Initialized
INFO - 2023-04-11 08:37:48 --> Router Class Initialized
INFO - 2023-04-11 08:37:48 --> Output Class Initialized
INFO - 2023-04-11 08:37:48 --> Output Class Initialized
INFO - 2023-04-11 08:37:48 --> Security Class Initialized
INFO - 2023-04-11 08:37:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:37:48 --> Input Class Initialized
INFO - 2023-04-11 08:37:48 --> Input Class Initialized
INFO - 2023-04-11 08:37:48 --> Language Class Initialized
INFO - 2023-04-11 08:37:48 --> Language Class Initialized
INFO - 2023-04-11 08:37:48 --> Loader Class Initialized
INFO - 2023-04-11 08:37:48 --> Loader Class Initialized
INFO - 2023-04-11 08:37:48 --> Controller Class Initialized
INFO - 2023-04-11 08:37:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:37:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:37:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:37:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:37:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:37:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:37:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:37:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:37:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:37:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:37:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:38:48 --> Config Class Initialized
INFO - 2023-04-11 08:38:48 --> Config Class Initialized
INFO - 2023-04-11 08:38:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:38:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:38:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:38:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:38:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:38:48 --> URI Class Initialized
INFO - 2023-04-11 08:38:48 --> URI Class Initialized
INFO - 2023-04-11 08:38:48 --> Router Class Initialized
INFO - 2023-04-11 08:38:48 --> Router Class Initialized
INFO - 2023-04-11 08:38:48 --> Output Class Initialized
INFO - 2023-04-11 08:38:48 --> Output Class Initialized
INFO - 2023-04-11 08:38:48 --> Security Class Initialized
INFO - 2023-04-11 08:38:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:38:48 --> Input Class Initialized
INFO - 2023-04-11 08:38:48 --> Input Class Initialized
INFO - 2023-04-11 08:38:48 --> Language Class Initialized
INFO - 2023-04-11 08:38:48 --> Language Class Initialized
INFO - 2023-04-11 08:38:48 --> Loader Class Initialized
INFO - 2023-04-11 08:38:48 --> Loader Class Initialized
INFO - 2023-04-11 08:38:48 --> Controller Class Initialized
INFO - 2023-04-11 08:38:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:38:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:38:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:38:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:38:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:38:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:38:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:38:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:38:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:38:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:38:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:38:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:38:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:39:48 --> Config Class Initialized
INFO - 2023-04-11 08:39:48 --> Config Class Initialized
INFO - 2023-04-11 08:39:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:39:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:39:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:39:48 --> URI Class Initialized
INFO - 2023-04-11 08:39:48 --> URI Class Initialized
INFO - 2023-04-11 08:39:48 --> Router Class Initialized
INFO - 2023-04-11 08:39:48 --> Router Class Initialized
INFO - 2023-04-11 08:39:48 --> Output Class Initialized
INFO - 2023-04-11 08:39:48 --> Output Class Initialized
INFO - 2023-04-11 08:39:48 --> Security Class Initialized
INFO - 2023-04-11 08:39:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:39:48 --> Input Class Initialized
INFO - 2023-04-11 08:39:48 --> Input Class Initialized
INFO - 2023-04-11 08:39:48 --> Language Class Initialized
INFO - 2023-04-11 08:39:48 --> Language Class Initialized
INFO - 2023-04-11 08:39:48 --> Loader Class Initialized
INFO - 2023-04-11 08:39:48 --> Loader Class Initialized
INFO - 2023-04-11 08:39:48 --> Controller Class Initialized
INFO - 2023-04-11 08:39:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:39:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:39:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:39:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:39:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:39:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:39:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:39:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:39:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:39:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:39:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:40:48 --> Config Class Initialized
INFO - 2023-04-11 08:40:48 --> Config Class Initialized
INFO - 2023-04-11 08:40:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:40:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:40:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:40:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:40:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:40:48 --> URI Class Initialized
INFO - 2023-04-11 08:40:48 --> URI Class Initialized
INFO - 2023-04-11 08:40:48 --> Router Class Initialized
INFO - 2023-04-11 08:40:48 --> Router Class Initialized
INFO - 2023-04-11 08:40:48 --> Output Class Initialized
INFO - 2023-04-11 08:40:48 --> Output Class Initialized
INFO - 2023-04-11 08:40:48 --> Security Class Initialized
INFO - 2023-04-11 08:40:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:40:48 --> Input Class Initialized
INFO - 2023-04-11 08:40:48 --> Input Class Initialized
INFO - 2023-04-11 08:40:48 --> Language Class Initialized
INFO - 2023-04-11 08:40:48 --> Language Class Initialized
INFO - 2023-04-11 08:40:48 --> Loader Class Initialized
INFO - 2023-04-11 08:40:48 --> Loader Class Initialized
INFO - 2023-04-11 08:40:48 --> Controller Class Initialized
INFO - 2023-04-11 08:40:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:40:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:40:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:40:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:40:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:40:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:40:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:40:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:40:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:40:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:40:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:41:48 --> Config Class Initialized
INFO - 2023-04-11 08:41:48 --> Config Class Initialized
INFO - 2023-04-11 08:41:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:41:48 --> URI Class Initialized
INFO - 2023-04-11 08:41:48 --> URI Class Initialized
INFO - 2023-04-11 08:41:48 --> Router Class Initialized
INFO - 2023-04-11 08:41:48 --> Router Class Initialized
INFO - 2023-04-11 08:41:48 --> Output Class Initialized
INFO - 2023-04-11 08:41:48 --> Output Class Initialized
INFO - 2023-04-11 08:41:48 --> Security Class Initialized
INFO - 2023-04-11 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:41:48 --> Input Class Initialized
INFO - 2023-04-11 08:41:48 --> Input Class Initialized
INFO - 2023-04-11 08:41:48 --> Language Class Initialized
INFO - 2023-04-11 08:41:48 --> Language Class Initialized
INFO - 2023-04-11 08:41:48 --> Loader Class Initialized
INFO - 2023-04-11 08:41:48 --> Loader Class Initialized
INFO - 2023-04-11 08:41:48 --> Controller Class Initialized
INFO - 2023-04-11 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:41:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:41:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:41:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:41:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:41:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:41:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:42:48 --> Config Class Initialized
INFO - 2023-04-11 08:42:48 --> Config Class Initialized
INFO - 2023-04-11 08:42:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:42:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:42:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:42:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:42:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:42:48 --> URI Class Initialized
INFO - 2023-04-11 08:42:48 --> URI Class Initialized
INFO - 2023-04-11 08:42:48 --> Router Class Initialized
INFO - 2023-04-11 08:42:48 --> Router Class Initialized
INFO - 2023-04-11 08:42:48 --> Output Class Initialized
INFO - 2023-04-11 08:42:48 --> Output Class Initialized
INFO - 2023-04-11 08:42:48 --> Security Class Initialized
INFO - 2023-04-11 08:42:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:42:48 --> Input Class Initialized
INFO - 2023-04-11 08:42:48 --> Input Class Initialized
INFO - 2023-04-11 08:42:48 --> Language Class Initialized
INFO - 2023-04-11 08:42:48 --> Language Class Initialized
INFO - 2023-04-11 08:42:48 --> Loader Class Initialized
INFO - 2023-04-11 08:42:48 --> Loader Class Initialized
INFO - 2023-04-11 08:42:48 --> Controller Class Initialized
INFO - 2023-04-11 08:42:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:42:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:42:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:42:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:42:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:42:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:42:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:42:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:42:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:43:47 --> Config Class Initialized
INFO - 2023-04-11 08:43:47 --> Config Class Initialized
INFO - 2023-04-11 08:43:47 --> Hooks Class Initialized
INFO - 2023-04-11 08:43:47 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:43:47 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:43:47 --> Utf8 Class Initialized
INFO - 2023-04-11 08:43:47 --> Utf8 Class Initialized
INFO - 2023-04-11 08:43:47 --> URI Class Initialized
INFO - 2023-04-11 08:43:47 --> URI Class Initialized
INFO - 2023-04-11 08:43:47 --> Router Class Initialized
INFO - 2023-04-11 08:43:47 --> Router Class Initialized
INFO - 2023-04-11 08:43:47 --> Output Class Initialized
INFO - 2023-04-11 08:43:47 --> Output Class Initialized
INFO - 2023-04-11 08:43:47 --> Security Class Initialized
INFO - 2023-04-11 08:43:47 --> Security Class Initialized
DEBUG - 2023-04-11 08:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:43:47 --> Input Class Initialized
INFO - 2023-04-11 08:43:47 --> Input Class Initialized
INFO - 2023-04-11 08:43:47 --> Language Class Initialized
INFO - 2023-04-11 08:43:47 --> Language Class Initialized
INFO - 2023-04-11 08:43:47 --> Loader Class Initialized
INFO - 2023-04-11 08:43:47 --> Loader Class Initialized
INFO - 2023-04-11 08:43:47 --> Controller Class Initialized
INFO - 2023-04-11 08:43:47 --> Controller Class Initialized
DEBUG - 2023-04-11 08:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:43:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:43:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:43:47 --> Config Class Initialized
INFO - 2023-04-11 08:43:47 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:43:47 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:43:47 --> Utf8 Class Initialized
INFO - 2023-04-11 08:43:47 --> URI Class Initialized
INFO - 2023-04-11 08:43:47 --> Router Class Initialized
INFO - 2023-04-11 08:43:47 --> Output Class Initialized
INFO - 2023-04-11 08:43:47 --> Security Class Initialized
DEBUG - 2023-04-11 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:43:47 --> Input Class Initialized
INFO - 2023-04-11 08:43:47 --> Language Class Initialized
INFO - 2023-04-11 08:43:47 --> Loader Class Initialized
INFO - 2023-04-11 08:43:47 --> Controller Class Initialized
DEBUG - 2023-04-11 08:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:43:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:43:47 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:43:47 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:43:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:43:47 --> Database Driver Class Initialized
INFO - 2023-04-11 08:43:47 --> Model "Login_model" initialized
INFO - 2023-04-11 08:43:47 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:43:47 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:43:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-11 08:43:47 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:43:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:44:33 --> Config Class Initialized
INFO - 2023-04-11 08:44:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:44:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:44:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:44:33 --> URI Class Initialized
INFO - 2023-04-11 08:44:33 --> Router Class Initialized
INFO - 2023-04-11 08:44:33 --> Output Class Initialized
INFO - 2023-04-11 08:44:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:44:33 --> Input Class Initialized
INFO - 2023-04-11 08:44:33 --> Language Class Initialized
INFO - 2023-04-11 08:44:33 --> Loader Class Initialized
INFO - 2023-04-11 08:44:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:44:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:44:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:44:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:44:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:44:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:44:34 --> Config Class Initialized
INFO - 2023-04-11 08:44:34 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:44:34 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:44:34 --> Utf8 Class Initialized
INFO - 2023-04-11 08:44:34 --> URI Class Initialized
INFO - 2023-04-11 08:44:34 --> Router Class Initialized
INFO - 2023-04-11 08:44:34 --> Output Class Initialized
INFO - 2023-04-11 08:44:34 --> Security Class Initialized
DEBUG - 2023-04-11 08:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:44:34 --> Input Class Initialized
INFO - 2023-04-11 08:44:34 --> Language Class Initialized
INFO - 2023-04-11 08:44:34 --> Loader Class Initialized
INFO - 2023-04-11 08:44:34 --> Controller Class Initialized
DEBUG - 2023-04-11 08:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:44:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:44:34 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:44:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:44:34 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:44:34 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:44:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:45:35 --> Config Class Initialized
INFO - 2023-04-11 08:45:35 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:45:35 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:45:35 --> Utf8 Class Initialized
INFO - 2023-04-11 08:45:35 --> URI Class Initialized
INFO - 2023-04-11 08:45:35 --> Router Class Initialized
INFO - 2023-04-11 08:45:35 --> Output Class Initialized
INFO - 2023-04-11 08:45:35 --> Security Class Initialized
DEBUG - 2023-04-11 08:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:45:35 --> Input Class Initialized
INFO - 2023-04-11 08:45:35 --> Language Class Initialized
INFO - 2023-04-11 08:45:35 --> Loader Class Initialized
INFO - 2023-04-11 08:45:35 --> Controller Class Initialized
DEBUG - 2023-04-11 08:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:45:35 --> Database Driver Class Initialized
INFO - 2023-04-11 08:45:35 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:45:35 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:45:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:45:36 --> Config Class Initialized
INFO - 2023-04-11 08:45:36 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:45:36 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:45:36 --> Utf8 Class Initialized
INFO - 2023-04-11 08:45:36 --> URI Class Initialized
INFO - 2023-04-11 08:45:36 --> Router Class Initialized
INFO - 2023-04-11 08:45:36 --> Output Class Initialized
INFO - 2023-04-11 08:45:36 --> Security Class Initialized
DEBUG - 2023-04-11 08:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:45:36 --> Input Class Initialized
INFO - 2023-04-11 08:45:36 --> Language Class Initialized
INFO - 2023-04-11 08:45:36 --> Loader Class Initialized
INFO - 2023-04-11 08:45:36 --> Controller Class Initialized
DEBUG - 2023-04-11 08:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:45:36 --> Database Driver Class Initialized
INFO - 2023-04-11 08:45:36 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:45:36 --> Database Driver Class Initialized
INFO - 2023-04-11 08:45:36 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:45:36 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:45:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:46:37 --> Config Class Initialized
INFO - 2023-04-11 08:46:37 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:46:37 --> Utf8 Class Initialized
INFO - 2023-04-11 08:46:37 --> URI Class Initialized
INFO - 2023-04-11 08:46:37 --> Router Class Initialized
INFO - 2023-04-11 08:46:37 --> Output Class Initialized
INFO - 2023-04-11 08:46:37 --> Security Class Initialized
DEBUG - 2023-04-11 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:46:37 --> Input Class Initialized
INFO - 2023-04-11 08:46:37 --> Language Class Initialized
INFO - 2023-04-11 08:46:37 --> Loader Class Initialized
INFO - 2023-04-11 08:46:37 --> Controller Class Initialized
DEBUG - 2023-04-11 08:46:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:46:37 --> Database Driver Class Initialized
INFO - 2023-04-11 08:46:37 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:46:37 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:46:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:46:38 --> Config Class Initialized
INFO - 2023-04-11 08:46:38 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:46:38 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:46:38 --> Utf8 Class Initialized
INFO - 2023-04-11 08:46:38 --> URI Class Initialized
INFO - 2023-04-11 08:46:38 --> Router Class Initialized
INFO - 2023-04-11 08:46:38 --> Output Class Initialized
INFO - 2023-04-11 08:46:38 --> Security Class Initialized
DEBUG - 2023-04-11 08:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:46:38 --> Input Class Initialized
INFO - 2023-04-11 08:46:38 --> Language Class Initialized
INFO - 2023-04-11 08:46:38 --> Loader Class Initialized
INFO - 2023-04-11 08:46:38 --> Controller Class Initialized
DEBUG - 2023-04-11 08:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:46:38 --> Database Driver Class Initialized
INFO - 2023-04-11 08:46:38 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:46:38 --> Database Driver Class Initialized
INFO - 2023-04-11 08:46:38 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:46:38 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:46:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:47:33 --> Config Class Initialized
INFO - 2023-04-11 08:47:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:47:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:47:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:47:33 --> URI Class Initialized
INFO - 2023-04-11 08:47:33 --> Router Class Initialized
INFO - 2023-04-11 08:47:33 --> Output Class Initialized
INFO - 2023-04-11 08:47:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:47:33 --> Input Class Initialized
INFO - 2023-04-11 08:47:33 --> Language Class Initialized
INFO - 2023-04-11 08:47:33 --> Loader Class Initialized
INFO - 2023-04-11 08:47:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:47:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:47:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:47:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:47:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:47:34 --> Config Class Initialized
INFO - 2023-04-11 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:47:34 --> Utf8 Class Initialized
INFO - 2023-04-11 08:47:34 --> URI Class Initialized
INFO - 2023-04-11 08:47:34 --> Router Class Initialized
INFO - 2023-04-11 08:47:34 --> Output Class Initialized
INFO - 2023-04-11 08:47:34 --> Security Class Initialized
DEBUG - 2023-04-11 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:47:34 --> Input Class Initialized
INFO - 2023-04-11 08:47:34 --> Language Class Initialized
INFO - 2023-04-11 08:47:34 --> Loader Class Initialized
INFO - 2023-04-11 08:47:34 --> Controller Class Initialized
DEBUG - 2023-04-11 08:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:47:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:47:34 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:47:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:47:34 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:47:34 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:47:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:48:33 --> Config Class Initialized
INFO - 2023-04-11 08:48:33 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:48:33 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:48:33 --> Utf8 Class Initialized
INFO - 2023-04-11 08:48:33 --> URI Class Initialized
INFO - 2023-04-11 08:48:33 --> Router Class Initialized
INFO - 2023-04-11 08:48:33 --> Output Class Initialized
INFO - 2023-04-11 08:48:33 --> Security Class Initialized
DEBUG - 2023-04-11 08:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:48:33 --> Input Class Initialized
INFO - 2023-04-11 08:48:33 --> Language Class Initialized
INFO - 2023-04-11 08:48:33 --> Loader Class Initialized
INFO - 2023-04-11 08:48:33 --> Controller Class Initialized
DEBUG - 2023-04-11 08:48:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:48:33 --> Database Driver Class Initialized
INFO - 2023-04-11 08:48:33 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:48:33 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:48:33 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:48:34 --> Config Class Initialized
INFO - 2023-04-11 08:48:34 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:48:34 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:48:34 --> Utf8 Class Initialized
INFO - 2023-04-11 08:48:34 --> URI Class Initialized
INFO - 2023-04-11 08:48:34 --> Router Class Initialized
INFO - 2023-04-11 08:48:34 --> Output Class Initialized
INFO - 2023-04-11 08:48:34 --> Security Class Initialized
DEBUG - 2023-04-11 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:48:34 --> Input Class Initialized
INFO - 2023-04-11 08:48:34 --> Language Class Initialized
INFO - 2023-04-11 08:48:34 --> Loader Class Initialized
INFO - 2023-04-11 08:48:34 --> Controller Class Initialized
DEBUG - 2023-04-11 08:48:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:48:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:48:34 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:48:34 --> Database Driver Class Initialized
INFO - 2023-04-11 08:48:34 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:48:34 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:48:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:49:44 --> Config Class Initialized
INFO - 2023-04-11 08:49:44 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:49:44 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:49:44 --> Utf8 Class Initialized
INFO - 2023-04-11 08:49:44 --> URI Class Initialized
INFO - 2023-04-11 08:49:44 --> Router Class Initialized
INFO - 2023-04-11 08:49:44 --> Output Class Initialized
INFO - 2023-04-11 08:49:44 --> Security Class Initialized
DEBUG - 2023-04-11 08:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:49:44 --> Input Class Initialized
INFO - 2023-04-11 08:49:44 --> Language Class Initialized
INFO - 2023-04-11 08:49:44 --> Loader Class Initialized
INFO - 2023-04-11 08:49:44 --> Controller Class Initialized
DEBUG - 2023-04-11 08:49:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:49:44 --> Database Driver Class Initialized
INFO - 2023-04-11 08:49:44 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:49:44 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:49:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:49:50 --> Config Class Initialized
INFO - 2023-04-11 08:49:50 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:49:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:49:50 --> Utf8 Class Initialized
INFO - 2023-04-11 08:49:50 --> URI Class Initialized
INFO - 2023-04-11 08:49:50 --> Router Class Initialized
INFO - 2023-04-11 08:49:50 --> Output Class Initialized
INFO - 2023-04-11 08:49:50 --> Security Class Initialized
DEBUG - 2023-04-11 08:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:49:50 --> Input Class Initialized
INFO - 2023-04-11 08:49:50 --> Language Class Initialized
INFO - 2023-04-11 08:49:50 --> Loader Class Initialized
INFO - 2023-04-11 08:49:50 --> Controller Class Initialized
DEBUG - 2023-04-11 08:49:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:49:50 --> Database Driver Class Initialized
INFO - 2023-04-11 08:49:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:49:50 --> Database Driver Class Initialized
INFO - 2023-04-11 08:49:50 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:49:50 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:49:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:50:48 --> Config Class Initialized
INFO - 2023-04-11 08:50:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:50:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:50:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:50:48 --> URI Class Initialized
INFO - 2023-04-11 08:50:48 --> Router Class Initialized
INFO - 2023-04-11 08:50:48 --> Output Class Initialized
INFO - 2023-04-11 08:50:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:50:48 --> Input Class Initialized
INFO - 2023-04-11 08:50:48 --> Language Class Initialized
INFO - 2023-04-11 08:50:48 --> Loader Class Initialized
INFO - 2023-04-11 08:50:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:50:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:50:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 08:50:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:50:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:51:48 --> Config Class Initialized
INFO - 2023-04-11 08:51:48 --> Config Class Initialized
INFO - 2023-04-11 08:51:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:51:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:51:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:51:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:51:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:51:48 --> URI Class Initialized
INFO - 2023-04-11 08:51:48 --> URI Class Initialized
INFO - 2023-04-11 08:51:48 --> Router Class Initialized
INFO - 2023-04-11 08:51:48 --> Router Class Initialized
INFO - 2023-04-11 08:51:48 --> Output Class Initialized
INFO - 2023-04-11 08:51:48 --> Output Class Initialized
INFO - 2023-04-11 08:51:48 --> Security Class Initialized
INFO - 2023-04-11 08:51:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:51:48 --> Input Class Initialized
INFO - 2023-04-11 08:51:48 --> Input Class Initialized
INFO - 2023-04-11 08:51:48 --> Language Class Initialized
INFO - 2023-04-11 08:51:48 --> Language Class Initialized
INFO - 2023-04-11 08:51:48 --> Loader Class Initialized
INFO - 2023-04-11 08:51:48 --> Loader Class Initialized
INFO - 2023-04-11 08:51:48 --> Controller Class Initialized
INFO - 2023-04-11 08:51:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:51:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:51:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:51:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:51:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:51:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:51:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:51:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:51:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:51:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:51:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:52:48 --> Config Class Initialized
INFO - 2023-04-11 08:52:48 --> Config Class Initialized
INFO - 2023-04-11 08:52:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:52:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:52:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:52:48 --> URI Class Initialized
INFO - 2023-04-11 08:52:48 --> URI Class Initialized
INFO - 2023-04-11 08:52:48 --> Router Class Initialized
INFO - 2023-04-11 08:52:48 --> Router Class Initialized
INFO - 2023-04-11 08:52:48 --> Output Class Initialized
INFO - 2023-04-11 08:52:48 --> Output Class Initialized
INFO - 2023-04-11 08:52:48 --> Security Class Initialized
INFO - 2023-04-11 08:52:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:52:48 --> Input Class Initialized
INFO - 2023-04-11 08:52:48 --> Input Class Initialized
INFO - 2023-04-11 08:52:48 --> Language Class Initialized
INFO - 2023-04-11 08:52:48 --> Language Class Initialized
INFO - 2023-04-11 08:52:48 --> Loader Class Initialized
INFO - 2023-04-11 08:52:48 --> Loader Class Initialized
INFO - 2023-04-11 08:52:48 --> Controller Class Initialized
INFO - 2023-04-11 08:52:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:52:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:52:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:52:55 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:52:55 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:52:55 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:52:55 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:52:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:52:55 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:52:55 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:52:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:53:48 --> Config Class Initialized
INFO - 2023-04-11 08:53:48 --> Config Class Initialized
INFO - 2023-04-11 08:53:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:53:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:53:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:53:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:53:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:53:48 --> URI Class Initialized
INFO - 2023-04-11 08:53:48 --> URI Class Initialized
INFO - 2023-04-11 08:53:48 --> Router Class Initialized
INFO - 2023-04-11 08:53:48 --> Router Class Initialized
INFO - 2023-04-11 08:53:48 --> Output Class Initialized
INFO - 2023-04-11 08:53:48 --> Output Class Initialized
INFO - 2023-04-11 08:53:48 --> Security Class Initialized
INFO - 2023-04-11 08:53:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:53:48 --> Input Class Initialized
INFO - 2023-04-11 08:53:48 --> Input Class Initialized
INFO - 2023-04-11 08:53:48 --> Language Class Initialized
INFO - 2023-04-11 08:53:48 --> Language Class Initialized
INFO - 2023-04-11 08:53:48 --> Loader Class Initialized
INFO - 2023-04-11 08:53:48 --> Loader Class Initialized
INFO - 2023-04-11 08:53:48 --> Controller Class Initialized
INFO - 2023-04-11 08:53:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:53:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:53:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:53:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:53:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:53:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:53:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:53:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:53:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:53:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:53:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:53:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:54:48 --> Config Class Initialized
INFO - 2023-04-11 08:54:48 --> Config Class Initialized
INFO - 2023-04-11 08:54:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:54:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:54:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:54:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:54:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:54:48 --> URI Class Initialized
INFO - 2023-04-11 08:54:48 --> URI Class Initialized
INFO - 2023-04-11 08:54:48 --> Router Class Initialized
INFO - 2023-04-11 08:54:48 --> Router Class Initialized
INFO - 2023-04-11 08:54:48 --> Output Class Initialized
INFO - 2023-04-11 08:54:48 --> Output Class Initialized
INFO - 2023-04-11 08:54:48 --> Security Class Initialized
INFO - 2023-04-11 08:54:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:54:48 --> Input Class Initialized
INFO - 2023-04-11 08:54:48 --> Input Class Initialized
INFO - 2023-04-11 08:54:48 --> Language Class Initialized
INFO - 2023-04-11 08:54:48 --> Language Class Initialized
INFO - 2023-04-11 08:54:48 --> Loader Class Initialized
INFO - 2023-04-11 08:54:48 --> Loader Class Initialized
INFO - 2023-04-11 08:54:48 --> Controller Class Initialized
INFO - 2023-04-11 08:54:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:54:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:54:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:54:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:54:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:54:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:54:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:54:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:54:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:54:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:54:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:54:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:54:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:55:48 --> Config Class Initialized
INFO - 2023-04-11 08:55:48 --> Config Class Initialized
INFO - 2023-04-11 08:55:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:55:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:55:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:55:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:55:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:55:48 --> URI Class Initialized
INFO - 2023-04-11 08:55:48 --> URI Class Initialized
INFO - 2023-04-11 08:55:48 --> Router Class Initialized
INFO - 2023-04-11 08:55:48 --> Router Class Initialized
INFO - 2023-04-11 08:55:48 --> Output Class Initialized
INFO - 2023-04-11 08:55:48 --> Output Class Initialized
INFO - 2023-04-11 08:55:48 --> Security Class Initialized
INFO - 2023-04-11 08:55:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:55:48 --> Input Class Initialized
DEBUG - 2023-04-11 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:55:48 --> Language Class Initialized
INFO - 2023-04-11 08:55:48 --> Input Class Initialized
INFO - 2023-04-11 08:55:48 --> Language Class Initialized
INFO - 2023-04-11 08:55:48 --> Loader Class Initialized
INFO - 2023-04-11 08:55:48 --> Loader Class Initialized
INFO - 2023-04-11 08:55:48 --> Controller Class Initialized
INFO - 2023-04-11 08:55:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:55:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:55:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:55:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:55:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:55:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:55:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:55:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:55:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:55:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:55:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:55:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:55:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:56:48 --> Config Class Initialized
INFO - 2023-04-11 08:56:48 --> Config Class Initialized
INFO - 2023-04-11 08:56:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:56:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:56:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:56:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:56:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:56:48 --> URI Class Initialized
INFO - 2023-04-11 08:56:48 --> URI Class Initialized
INFO - 2023-04-11 08:56:48 --> Router Class Initialized
INFO - 2023-04-11 08:56:48 --> Router Class Initialized
INFO - 2023-04-11 08:56:48 --> Output Class Initialized
INFO - 2023-04-11 08:56:48 --> Output Class Initialized
INFO - 2023-04-11 08:56:48 --> Security Class Initialized
INFO - 2023-04-11 08:56:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:56:48 --> Input Class Initialized
INFO - 2023-04-11 08:56:48 --> Input Class Initialized
INFO - 2023-04-11 08:56:48 --> Language Class Initialized
INFO - 2023-04-11 08:56:48 --> Language Class Initialized
INFO - 2023-04-11 08:56:48 --> Loader Class Initialized
INFO - 2023-04-11 08:56:48 --> Loader Class Initialized
INFO - 2023-04-11 08:56:48 --> Controller Class Initialized
INFO - 2023-04-11 08:56:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:56:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:56:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:56:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:56:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:56:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:56:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:56:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:56:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:56:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:56:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:56:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:56:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:57:48 --> Config Class Initialized
INFO - 2023-04-11 08:57:48 --> Config Class Initialized
INFO - 2023-04-11 08:57:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:57:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:57:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:57:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 08:57:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:57:48 --> URI Class Initialized
INFO - 2023-04-11 08:57:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:57:48 --> Router Class Initialized
INFO - 2023-04-11 08:57:48 --> URI Class Initialized
INFO - 2023-04-11 08:57:48 --> Output Class Initialized
INFO - 2023-04-11 08:57:48 --> Router Class Initialized
INFO - 2023-04-11 08:57:48 --> Security Class Initialized
INFO - 2023-04-11 08:57:48 --> Output Class Initialized
DEBUG - 2023-04-11 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:57:48 --> Security Class Initialized
INFO - 2023-04-11 08:57:48 --> Input Class Initialized
DEBUG - 2023-04-11 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:57:48 --> Language Class Initialized
INFO - 2023-04-11 08:57:48 --> Input Class Initialized
INFO - 2023-04-11 08:57:48 --> Language Class Initialized
INFO - 2023-04-11 08:57:48 --> Loader Class Initialized
INFO - 2023-04-11 08:57:48 --> Loader Class Initialized
INFO - 2023-04-11 08:57:48 --> Controller Class Initialized
INFO - 2023-04-11 08:57:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:57:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:57:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:57:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:57:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:57:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:57:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:57:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:57:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:57:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:57:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:57:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:57:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:58:48 --> Config Class Initialized
INFO - 2023-04-11 08:58:48 --> Config Class Initialized
INFO - 2023-04-11 08:58:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:58:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:58:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:58:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:58:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:58:48 --> URI Class Initialized
INFO - 2023-04-11 08:58:48 --> URI Class Initialized
INFO - 2023-04-11 08:58:48 --> Router Class Initialized
INFO - 2023-04-11 08:58:48 --> Router Class Initialized
INFO - 2023-04-11 08:58:48 --> Output Class Initialized
INFO - 2023-04-11 08:58:48 --> Output Class Initialized
INFO - 2023-04-11 08:58:48 --> Security Class Initialized
INFO - 2023-04-11 08:58:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:58:48 --> Input Class Initialized
INFO - 2023-04-11 08:58:48 --> Input Class Initialized
INFO - 2023-04-11 08:58:48 --> Language Class Initialized
INFO - 2023-04-11 08:58:48 --> Language Class Initialized
INFO - 2023-04-11 08:58:48 --> Loader Class Initialized
INFO - 2023-04-11 08:58:48 --> Loader Class Initialized
INFO - 2023-04-11 08:58:48 --> Controller Class Initialized
INFO - 2023-04-11 08:58:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:58:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:58:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:58:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:58:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:58:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:58:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:58:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:58:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:59:48 --> Config Class Initialized
INFO - 2023-04-11 08:59:48 --> Config Class Initialized
INFO - 2023-04-11 08:59:48 --> Hooks Class Initialized
INFO - 2023-04-11 08:59:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 08:59:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 08:59:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:59:48 --> Utf8 Class Initialized
INFO - 2023-04-11 08:59:48 --> URI Class Initialized
INFO - 2023-04-11 08:59:48 --> URI Class Initialized
INFO - 2023-04-11 08:59:48 --> Router Class Initialized
INFO - 2023-04-11 08:59:48 --> Router Class Initialized
INFO - 2023-04-11 08:59:48 --> Output Class Initialized
INFO - 2023-04-11 08:59:48 --> Output Class Initialized
INFO - 2023-04-11 08:59:48 --> Security Class Initialized
INFO - 2023-04-11 08:59:48 --> Security Class Initialized
DEBUG - 2023-04-11 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 08:59:48 --> Input Class Initialized
INFO - 2023-04-11 08:59:48 --> Input Class Initialized
INFO - 2023-04-11 08:59:48 --> Language Class Initialized
INFO - 2023-04-11 08:59:48 --> Language Class Initialized
INFO - 2023-04-11 08:59:48 --> Loader Class Initialized
INFO - 2023-04-11 08:59:48 --> Loader Class Initialized
INFO - 2023-04-11 08:59:48 --> Controller Class Initialized
INFO - 2023-04-11 08:59:48 --> Controller Class Initialized
DEBUG - 2023-04-11 08:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 08:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 08:59:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:59:48 --> Database Driver Class Initialized
INFO - 2023-04-11 08:59:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:59:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 08:59:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 08:59:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 08:59:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 08:59:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 08:59:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 08:59:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:00:48 --> Config Class Initialized
INFO - 2023-04-11 09:00:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:00:48 --> Config Class Initialized
DEBUG - 2023-04-11 09:00:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:00:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:00:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:00:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:00:48 --> URI Class Initialized
INFO - 2023-04-11 09:00:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:00:48 --> URI Class Initialized
INFO - 2023-04-11 09:00:48 --> Router Class Initialized
INFO - 2023-04-11 09:00:48 --> Router Class Initialized
INFO - 2023-04-11 09:00:48 --> Output Class Initialized
INFO - 2023-04-11 09:00:48 --> Output Class Initialized
INFO - 2023-04-11 09:00:48 --> Security Class Initialized
INFO - 2023-04-11 09:00:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:00:48 --> Input Class Initialized
INFO - 2023-04-11 09:00:48 --> Input Class Initialized
INFO - 2023-04-11 09:00:48 --> Language Class Initialized
INFO - 2023-04-11 09:00:48 --> Language Class Initialized
INFO - 2023-04-11 09:00:48 --> Loader Class Initialized
INFO - 2023-04-11 09:00:48 --> Loader Class Initialized
INFO - 2023-04-11 09:00:48 --> Controller Class Initialized
INFO - 2023-04-11 09:00:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:00:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:00:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:00:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:00:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 09:00:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:00:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:00:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:00:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:00:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:00:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:01:48 --> Config Class Initialized
INFO - 2023-04-11 09:01:48 --> Config Class Initialized
INFO - 2023-04-11 09:01:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:01:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:01:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:01:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:01:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:01:48 --> URI Class Initialized
INFO - 2023-04-11 09:01:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:01:48 --> Router Class Initialized
INFO - 2023-04-11 09:01:48 --> URI Class Initialized
INFO - 2023-04-11 09:01:48 --> Output Class Initialized
INFO - 2023-04-11 09:01:48 --> Router Class Initialized
INFO - 2023-04-11 09:01:48 --> Security Class Initialized
INFO - 2023-04-11 09:01:48 --> Output Class Initialized
INFO - 2023-04-11 09:01:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:01:48 --> Input Class Initialized
INFO - 2023-04-11 09:01:48 --> Input Class Initialized
INFO - 2023-04-11 09:01:48 --> Language Class Initialized
INFO - 2023-04-11 09:01:48 --> Language Class Initialized
INFO - 2023-04-11 09:01:48 --> Loader Class Initialized
INFO - 2023-04-11 09:01:48 --> Loader Class Initialized
INFO - 2023-04-11 09:01:48 --> Controller Class Initialized
INFO - 2023-04-11 09:01:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:01:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:01:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:01:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:01:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:01:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:01:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:01:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:01:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:01:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:01:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:01:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:01:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:02:48 --> Config Class Initialized
INFO - 2023-04-11 09:02:48 --> Config Class Initialized
INFO - 2023-04-11 09:02:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:02:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:02:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:02:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:02:48 --> URI Class Initialized
INFO - 2023-04-11 09:02:48 --> URI Class Initialized
INFO - 2023-04-11 09:02:48 --> Router Class Initialized
INFO - 2023-04-11 09:02:48 --> Router Class Initialized
INFO - 2023-04-11 09:02:48 --> Output Class Initialized
INFO - 2023-04-11 09:02:48 --> Output Class Initialized
INFO - 2023-04-11 09:02:48 --> Security Class Initialized
INFO - 2023-04-11 09:02:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:02:48 --> Input Class Initialized
INFO - 2023-04-11 09:02:48 --> Input Class Initialized
INFO - 2023-04-11 09:02:48 --> Language Class Initialized
INFO - 2023-04-11 09:02:48 --> Language Class Initialized
INFO - 2023-04-11 09:02:48 --> Loader Class Initialized
INFO - 2023-04-11 09:02:48 --> Loader Class Initialized
INFO - 2023-04-11 09:02:48 --> Controller Class Initialized
INFO - 2023-04-11 09:02:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:02:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:02:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:02:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:02:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:02:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:02:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:02:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:02:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:03:48 --> Config Class Initialized
INFO - 2023-04-11 09:03:48 --> Config Class Initialized
INFO - 2023-04-11 09:03:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:03:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:03:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:03:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:03:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:03:48 --> URI Class Initialized
INFO - 2023-04-11 09:03:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:03:48 --> URI Class Initialized
INFO - 2023-04-11 09:03:48 --> Router Class Initialized
INFO - 2023-04-11 09:03:48 --> Router Class Initialized
INFO - 2023-04-11 09:03:48 --> Output Class Initialized
INFO - 2023-04-11 09:03:48 --> Output Class Initialized
INFO - 2023-04-11 09:03:48 --> Security Class Initialized
INFO - 2023-04-11 09:03:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:03:48 --> Input Class Initialized
DEBUG - 2023-04-11 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:03:48 --> Input Class Initialized
INFO - 2023-04-11 09:03:48 --> Language Class Initialized
INFO - 2023-04-11 09:03:48 --> Language Class Initialized
INFO - 2023-04-11 09:03:48 --> Loader Class Initialized
INFO - 2023-04-11 09:03:48 --> Loader Class Initialized
INFO - 2023-04-11 09:03:48 --> Controller Class Initialized
INFO - 2023-04-11 09:03:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:03:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:03:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:03:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:03:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:03:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:03:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:03:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:03:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:03:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:03:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:03:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:03:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:05:04 --> Config Class Initialized
INFO - 2023-04-11 09:05:04 --> Config Class Initialized
INFO - 2023-04-11 09:05:04 --> Hooks Class Initialized
INFO - 2023-04-11 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:05:04 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:05:04 --> URI Class Initialized
INFO - 2023-04-11 09:05:04 --> Utf8 Class Initialized
INFO - 2023-04-11 09:05:04 --> Router Class Initialized
INFO - 2023-04-11 09:05:04 --> URI Class Initialized
INFO - 2023-04-11 09:05:04 --> Output Class Initialized
INFO - 2023-04-11 09:05:04 --> Security Class Initialized
INFO - 2023-04-11 09:05:04 --> Router Class Initialized
DEBUG - 2023-04-11 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:05:04 --> Output Class Initialized
INFO - 2023-04-11 09:05:04 --> Input Class Initialized
INFO - 2023-04-11 09:05:04 --> Security Class Initialized
INFO - 2023-04-11 09:05:04 --> Language Class Initialized
DEBUG - 2023-04-11 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:05:04 --> Input Class Initialized
INFO - 2023-04-11 09:05:04 --> Loader Class Initialized
INFO - 2023-04-11 09:05:04 --> Language Class Initialized
INFO - 2023-04-11 09:05:04 --> Controller Class Initialized
INFO - 2023-04-11 09:05:04 --> Loader Class Initialized
DEBUG - 2023-04-11 09:05:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:05:04 --> Controller Class Initialized
DEBUG - 2023-04-11 09:05:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:05:04 --> Database Driver Class Initialized
INFO - 2023-04-11 09:05:04 --> Database Driver Class Initialized
INFO - 2023-04-11 09:05:04 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:05:04 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:05:04 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:05:04 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:05:04 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:05:04 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:05:04 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:05:04 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:05:48 --> Config Class Initialized
INFO - 2023-04-11 09:05:48 --> Config Class Initialized
INFO - 2023-04-11 09:05:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:05:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:05:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:05:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:05:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:05:48 --> URI Class Initialized
INFO - 2023-04-11 09:05:48 --> URI Class Initialized
INFO - 2023-04-11 09:05:48 --> Router Class Initialized
INFO - 2023-04-11 09:05:48 --> Router Class Initialized
INFO - 2023-04-11 09:05:48 --> Output Class Initialized
INFO - 2023-04-11 09:05:48 --> Output Class Initialized
INFO - 2023-04-11 09:05:48 --> Security Class Initialized
INFO - 2023-04-11 09:05:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:05:48 --> Input Class Initialized
INFO - 2023-04-11 09:05:48 --> Input Class Initialized
INFO - 2023-04-11 09:05:48 --> Language Class Initialized
INFO - 2023-04-11 09:05:48 --> Language Class Initialized
INFO - 2023-04-11 09:05:48 --> Loader Class Initialized
INFO - 2023-04-11 09:05:48 --> Loader Class Initialized
INFO - 2023-04-11 09:05:48 --> Controller Class Initialized
INFO - 2023-04-11 09:05:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:05:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:05:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:05:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:05:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:05:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:05:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:05:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:05:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:05:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:05:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:05:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:05:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:06:48 --> Config Class Initialized
INFO - 2023-04-11 09:06:48 --> Config Class Initialized
INFO - 2023-04-11 09:06:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:06:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:06:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:06:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:06:48 --> URI Class Initialized
INFO - 2023-04-11 09:06:48 --> URI Class Initialized
INFO - 2023-04-11 09:06:48 --> Router Class Initialized
INFO - 2023-04-11 09:06:48 --> Router Class Initialized
INFO - 2023-04-11 09:06:48 --> Output Class Initialized
INFO - 2023-04-11 09:06:48 --> Output Class Initialized
INFO - 2023-04-11 09:06:48 --> Security Class Initialized
INFO - 2023-04-11 09:06:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:06:48 --> Input Class Initialized
DEBUG - 2023-04-11 09:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:06:48 --> Language Class Initialized
INFO - 2023-04-11 09:06:48 --> Input Class Initialized
INFO - 2023-04-11 09:06:48 --> Language Class Initialized
INFO - 2023-04-11 09:06:48 --> Loader Class Initialized
INFO - 2023-04-11 09:06:48 --> Loader Class Initialized
INFO - 2023-04-11 09:06:48 --> Controller Class Initialized
INFO - 2023-04-11 09:06:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:06:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:06:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:06:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:06:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:06:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:06:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:06:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:06:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:06:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:06:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:07:48 --> Config Class Initialized
INFO - 2023-04-11 09:07:48 --> Config Class Initialized
INFO - 2023-04-11 09:07:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:07:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:07:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:07:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:07:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:07:48 --> URI Class Initialized
INFO - 2023-04-11 09:07:48 --> URI Class Initialized
INFO - 2023-04-11 09:07:48 --> Router Class Initialized
INFO - 2023-04-11 09:07:48 --> Router Class Initialized
INFO - 2023-04-11 09:07:48 --> Output Class Initialized
INFO - 2023-04-11 09:07:48 --> Output Class Initialized
INFO - 2023-04-11 09:07:48 --> Security Class Initialized
INFO - 2023-04-11 09:07:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:07:48 --> Input Class Initialized
INFO - 2023-04-11 09:07:48 --> Input Class Initialized
INFO - 2023-04-11 09:07:48 --> Language Class Initialized
INFO - 2023-04-11 09:07:48 --> Language Class Initialized
INFO - 2023-04-11 09:07:48 --> Loader Class Initialized
INFO - 2023-04-11 09:07:48 --> Loader Class Initialized
INFO - 2023-04-11 09:07:48 --> Controller Class Initialized
INFO - 2023-04-11 09:07:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:07:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:07:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:07:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:07:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:07:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:07:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:07:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:07:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:07:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:07:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:07:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:07:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:08:48 --> Config Class Initialized
INFO - 2023-04-11 09:08:48 --> Config Class Initialized
INFO - 2023-04-11 09:08:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:08:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:08:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:08:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:08:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:08:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:08:48 --> URI Class Initialized
INFO - 2023-04-11 09:08:48 --> URI Class Initialized
INFO - 2023-04-11 09:08:48 --> Router Class Initialized
INFO - 2023-04-11 09:08:48 --> Router Class Initialized
INFO - 2023-04-11 09:08:48 --> Output Class Initialized
INFO - 2023-04-11 09:08:48 --> Output Class Initialized
INFO - 2023-04-11 09:08:48 --> Security Class Initialized
INFO - 2023-04-11 09:08:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:08:48 --> Input Class Initialized
INFO - 2023-04-11 09:08:48 --> Input Class Initialized
INFO - 2023-04-11 09:08:48 --> Language Class Initialized
INFO - 2023-04-11 09:08:48 --> Language Class Initialized
INFO - 2023-04-11 09:08:48 --> Loader Class Initialized
INFO - 2023-04-11 09:08:48 --> Loader Class Initialized
INFO - 2023-04-11 09:08:48 --> Controller Class Initialized
INFO - 2023-04-11 09:08:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:08:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:08:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:08:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:08:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:08:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:08:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:08:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 09:08:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:08:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:08:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:08:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:08:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:09:48 --> Config Class Initialized
INFO - 2023-04-11 09:09:48 --> Config Class Initialized
INFO - 2023-04-11 09:09:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:09:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:09:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:09:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:09:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:09:48 --> URI Class Initialized
INFO - 2023-04-11 09:09:48 --> URI Class Initialized
INFO - 2023-04-11 09:09:48 --> Router Class Initialized
INFO - 2023-04-11 09:09:48 --> Router Class Initialized
INFO - 2023-04-11 09:09:48 --> Output Class Initialized
INFO - 2023-04-11 09:09:48 --> Output Class Initialized
INFO - 2023-04-11 09:09:48 --> Security Class Initialized
INFO - 2023-04-11 09:09:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:09:48 --> Input Class Initialized
INFO - 2023-04-11 09:09:48 --> Input Class Initialized
INFO - 2023-04-11 09:09:48 --> Language Class Initialized
INFO - 2023-04-11 09:09:48 --> Language Class Initialized
INFO - 2023-04-11 09:09:48 --> Loader Class Initialized
INFO - 2023-04-11 09:09:48 --> Loader Class Initialized
INFO - 2023-04-11 09:09:48 --> Controller Class Initialized
INFO - 2023-04-11 09:09:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:09:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:09:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:09:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:09:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:09:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:09:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:09:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:09:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:09:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:09:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:09:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:09:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:10:48 --> Config Class Initialized
INFO - 2023-04-11 09:10:48 --> Config Class Initialized
INFO - 2023-04-11 09:10:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:10:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:10:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:10:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:10:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:10:48 --> URI Class Initialized
INFO - 2023-04-11 09:10:48 --> URI Class Initialized
INFO - 2023-04-11 09:10:48 --> Router Class Initialized
INFO - 2023-04-11 09:10:48 --> Router Class Initialized
INFO - 2023-04-11 09:10:48 --> Output Class Initialized
INFO - 2023-04-11 09:10:48 --> Output Class Initialized
INFO - 2023-04-11 09:10:48 --> Security Class Initialized
INFO - 2023-04-11 09:10:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:10:48 --> Input Class Initialized
INFO - 2023-04-11 09:10:48 --> Input Class Initialized
INFO - 2023-04-11 09:10:48 --> Language Class Initialized
INFO - 2023-04-11 09:10:48 --> Language Class Initialized
INFO - 2023-04-11 09:10:48 --> Loader Class Initialized
INFO - 2023-04-11 09:10:48 --> Loader Class Initialized
INFO - 2023-04-11 09:10:48 --> Controller Class Initialized
INFO - 2023-04-11 09:10:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:10:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:10:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:10:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:10:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:10:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:10:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:10:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:10:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:10:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:10:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:10:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:10:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:11:48 --> Config Class Initialized
INFO - 2023-04-11 09:11:48 --> Config Class Initialized
INFO - 2023-04-11 09:11:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:11:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:11:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:11:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:11:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:11:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:11:48 --> URI Class Initialized
INFO - 2023-04-11 09:11:48 --> URI Class Initialized
INFO - 2023-04-11 09:11:48 --> Router Class Initialized
INFO - 2023-04-11 09:11:48 --> Router Class Initialized
INFO - 2023-04-11 09:11:48 --> Output Class Initialized
INFO - 2023-04-11 09:11:48 --> Output Class Initialized
INFO - 2023-04-11 09:11:48 --> Security Class Initialized
INFO - 2023-04-11 09:11:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:11:48 --> Input Class Initialized
INFO - 2023-04-11 09:11:48 --> Input Class Initialized
INFO - 2023-04-11 09:11:48 --> Language Class Initialized
INFO - 2023-04-11 09:11:48 --> Language Class Initialized
INFO - 2023-04-11 09:11:48 --> Loader Class Initialized
INFO - 2023-04-11 09:11:48 --> Loader Class Initialized
INFO - 2023-04-11 09:11:48 --> Controller Class Initialized
INFO - 2023-04-11 09:11:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:11:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:11:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:11:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:11:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:11:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:11:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:11:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:11:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:11:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:11:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:11:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:11:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:12:48 --> Config Class Initialized
INFO - 2023-04-11 09:12:48 --> Config Class Initialized
INFO - 2023-04-11 09:12:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:12:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:12:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:12:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:12:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:12:48 --> URI Class Initialized
INFO - 2023-04-11 09:12:48 --> URI Class Initialized
INFO - 2023-04-11 09:12:48 --> Router Class Initialized
INFO - 2023-04-11 09:12:48 --> Router Class Initialized
INFO - 2023-04-11 09:12:48 --> Output Class Initialized
INFO - 2023-04-11 09:12:48 --> Output Class Initialized
INFO - 2023-04-11 09:12:48 --> Security Class Initialized
INFO - 2023-04-11 09:12:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:12:48 --> Input Class Initialized
INFO - 2023-04-11 09:12:48 --> Input Class Initialized
INFO - 2023-04-11 09:12:48 --> Language Class Initialized
INFO - 2023-04-11 09:12:48 --> Language Class Initialized
INFO - 2023-04-11 09:12:48 --> Loader Class Initialized
INFO - 2023-04-11 09:12:48 --> Loader Class Initialized
INFO - 2023-04-11 09:12:48 --> Controller Class Initialized
INFO - 2023-04-11 09:12:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:12:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:12:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:12:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:12:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:12:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:12:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:12:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:12:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:12:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:12:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:12:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:12:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:13:48 --> Config Class Initialized
INFO - 2023-04-11 09:13:48 --> Config Class Initialized
INFO - 2023-04-11 09:13:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:13:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:13:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:13:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:13:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:13:48 --> URI Class Initialized
INFO - 2023-04-11 09:13:48 --> URI Class Initialized
INFO - 2023-04-11 09:13:48 --> Router Class Initialized
INFO - 2023-04-11 09:13:48 --> Router Class Initialized
INFO - 2023-04-11 09:13:48 --> Output Class Initialized
INFO - 2023-04-11 09:13:48 --> Output Class Initialized
INFO - 2023-04-11 09:13:48 --> Security Class Initialized
INFO - 2023-04-11 09:13:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:13:48 --> Input Class Initialized
INFO - 2023-04-11 09:13:48 --> Input Class Initialized
INFO - 2023-04-11 09:13:48 --> Language Class Initialized
INFO - 2023-04-11 09:13:48 --> Language Class Initialized
INFO - 2023-04-11 09:13:48 --> Loader Class Initialized
INFO - 2023-04-11 09:13:48 --> Loader Class Initialized
INFO - 2023-04-11 09:13:48 --> Controller Class Initialized
INFO - 2023-04-11 09:13:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:13:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:13:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:13:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:13:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:13:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:13:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:13:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:13:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:13:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:13:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:14:48 --> Config Class Initialized
INFO - 2023-04-11 09:14:48 --> Config Class Initialized
INFO - 2023-04-11 09:14:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:14:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:14:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:14:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:14:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:14:48 --> URI Class Initialized
INFO - 2023-04-11 09:14:48 --> URI Class Initialized
INFO - 2023-04-11 09:14:48 --> Router Class Initialized
INFO - 2023-04-11 09:14:48 --> Router Class Initialized
INFO - 2023-04-11 09:14:48 --> Output Class Initialized
INFO - 2023-04-11 09:14:48 --> Output Class Initialized
INFO - 2023-04-11 09:14:48 --> Security Class Initialized
INFO - 2023-04-11 09:14:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:14:48 --> Input Class Initialized
INFO - 2023-04-11 09:14:48 --> Input Class Initialized
INFO - 2023-04-11 09:14:48 --> Language Class Initialized
INFO - 2023-04-11 09:14:48 --> Language Class Initialized
INFO - 2023-04-11 09:14:48 --> Loader Class Initialized
INFO - 2023-04-11 09:14:48 --> Loader Class Initialized
INFO - 2023-04-11 09:14:48 --> Controller Class Initialized
INFO - 2023-04-11 09:14:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:14:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:14:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:14:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:14:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:14:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:14:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:14:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:14:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:14:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:14:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:15:50 --> Config Class Initialized
INFO - 2023-04-11 09:15:50 --> Config Class Initialized
INFO - 2023-04-11 09:15:50 --> Hooks Class Initialized
INFO - 2023-04-11 09:15:50 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:15:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:15:50 --> Utf8 Class Initialized
INFO - 2023-04-11 09:15:50 --> Utf8 Class Initialized
INFO - 2023-04-11 09:15:50 --> URI Class Initialized
INFO - 2023-04-11 09:15:50 --> URI Class Initialized
INFO - 2023-04-11 09:15:50 --> Router Class Initialized
INFO - 2023-04-11 09:15:50 --> Router Class Initialized
INFO - 2023-04-11 09:15:50 --> Output Class Initialized
INFO - 2023-04-11 09:15:50 --> Output Class Initialized
INFO - 2023-04-11 09:15:50 --> Security Class Initialized
INFO - 2023-04-11 09:15:50 --> Security Class Initialized
DEBUG - 2023-04-11 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:15:50 --> Input Class Initialized
INFO - 2023-04-11 09:15:50 --> Input Class Initialized
INFO - 2023-04-11 09:15:50 --> Language Class Initialized
INFO - 2023-04-11 09:15:50 --> Language Class Initialized
INFO - 2023-04-11 09:15:50 --> Loader Class Initialized
INFO - 2023-04-11 09:15:50 --> Loader Class Initialized
INFO - 2023-04-11 09:15:50 --> Controller Class Initialized
INFO - 2023-04-11 09:15:50 --> Controller Class Initialized
DEBUG - 2023-04-11 09:15:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:15:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:15:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:15:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:15:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:15:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:15:50 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:15:50 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:15:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:15:50 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:15:50 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:15:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:16:48 --> Config Class Initialized
INFO - 2023-04-11 09:16:48 --> Config Class Initialized
INFO - 2023-04-11 09:16:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:16:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:16:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:16:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:16:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:16:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:16:48 --> URI Class Initialized
INFO - 2023-04-11 09:16:48 --> URI Class Initialized
INFO - 2023-04-11 09:16:48 --> Router Class Initialized
INFO - 2023-04-11 09:16:48 --> Router Class Initialized
INFO - 2023-04-11 09:16:48 --> Output Class Initialized
INFO - 2023-04-11 09:16:48 --> Output Class Initialized
INFO - 2023-04-11 09:16:48 --> Security Class Initialized
INFO - 2023-04-11 09:16:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:16:48 --> Input Class Initialized
INFO - 2023-04-11 09:16:48 --> Input Class Initialized
INFO - 2023-04-11 09:16:48 --> Language Class Initialized
INFO - 2023-04-11 09:16:48 --> Language Class Initialized
INFO - 2023-04-11 09:16:48 --> Loader Class Initialized
INFO - 2023-04-11 09:16:48 --> Loader Class Initialized
INFO - 2023-04-11 09:16:48 --> Controller Class Initialized
INFO - 2023-04-11 09:16:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:16:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:16:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:16:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:16:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:16:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:16:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:16:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:16:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:16:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:16:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:17:48 --> Config Class Initialized
INFO - 2023-04-11 09:17:48 --> Config Class Initialized
INFO - 2023-04-11 09:17:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:17:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:17:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:17:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:17:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:17:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:17:48 --> URI Class Initialized
INFO - 2023-04-11 09:17:48 --> URI Class Initialized
INFO - 2023-04-11 09:17:48 --> Router Class Initialized
INFO - 2023-04-11 09:17:48 --> Router Class Initialized
INFO - 2023-04-11 09:17:48 --> Output Class Initialized
INFO - 2023-04-11 09:17:48 --> Output Class Initialized
INFO - 2023-04-11 09:17:48 --> Security Class Initialized
INFO - 2023-04-11 09:17:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:17:48 --> Input Class Initialized
INFO - 2023-04-11 09:17:48 --> Input Class Initialized
INFO - 2023-04-11 09:17:48 --> Language Class Initialized
INFO - 2023-04-11 09:17:48 --> Language Class Initialized
INFO - 2023-04-11 09:17:48 --> Loader Class Initialized
INFO - 2023-04-11 09:17:48 --> Loader Class Initialized
INFO - 2023-04-11 09:17:48 --> Controller Class Initialized
INFO - 2023-04-11 09:17:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:17:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:17:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:17:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:17:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:17:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:17:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:17:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:17:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:17:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:17:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:17:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:17:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:18:48 --> Config Class Initialized
INFO - 2023-04-11 09:18:48 --> Config Class Initialized
INFO - 2023-04-11 09:18:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:18:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:18:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:18:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:18:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:18:48 --> URI Class Initialized
INFO - 2023-04-11 09:18:48 --> URI Class Initialized
INFO - 2023-04-11 09:18:48 --> Router Class Initialized
INFO - 2023-04-11 09:18:48 --> Router Class Initialized
INFO - 2023-04-11 09:18:48 --> Output Class Initialized
INFO - 2023-04-11 09:18:48 --> Output Class Initialized
INFO - 2023-04-11 09:18:48 --> Security Class Initialized
INFO - 2023-04-11 09:18:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:18:48 --> Input Class Initialized
INFO - 2023-04-11 09:18:48 --> Input Class Initialized
INFO - 2023-04-11 09:18:48 --> Language Class Initialized
INFO - 2023-04-11 09:18:48 --> Language Class Initialized
INFO - 2023-04-11 09:18:48 --> Loader Class Initialized
INFO - 2023-04-11 09:18:48 --> Loader Class Initialized
INFO - 2023-04-11 09:18:48 --> Controller Class Initialized
INFO - 2023-04-11 09:18:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:18:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:18:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:18:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:18:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:18:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:18:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:18:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:18:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:18:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:18:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:18:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:18:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:19:48 --> Config Class Initialized
INFO - 2023-04-11 09:19:48 --> Config Class Initialized
INFO - 2023-04-11 09:19:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:19:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:19:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:19:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:19:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:19:48 --> URI Class Initialized
INFO - 2023-04-11 09:19:48 --> URI Class Initialized
INFO - 2023-04-11 09:19:48 --> Router Class Initialized
INFO - 2023-04-11 09:19:48 --> Router Class Initialized
INFO - 2023-04-11 09:19:48 --> Output Class Initialized
INFO - 2023-04-11 09:19:48 --> Output Class Initialized
INFO - 2023-04-11 09:19:48 --> Security Class Initialized
INFO - 2023-04-11 09:19:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:19:48 --> Input Class Initialized
INFO - 2023-04-11 09:19:48 --> Input Class Initialized
INFO - 2023-04-11 09:19:48 --> Language Class Initialized
INFO - 2023-04-11 09:19:48 --> Language Class Initialized
INFO - 2023-04-11 09:19:48 --> Loader Class Initialized
INFO - 2023-04-11 09:19:48 --> Loader Class Initialized
INFO - 2023-04-11 09:19:48 --> Controller Class Initialized
INFO - 2023-04-11 09:19:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:19:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:19:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:19:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:19:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:19:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:19:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:19:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:19:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:19:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:19:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:19:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:19:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:20:48 --> Config Class Initialized
INFO - 2023-04-11 09:20:48 --> Config Class Initialized
INFO - 2023-04-11 09:20:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:20:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:20:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:20:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:20:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:20:48 --> URI Class Initialized
INFO - 2023-04-11 09:20:48 --> URI Class Initialized
INFO - 2023-04-11 09:20:48 --> Router Class Initialized
INFO - 2023-04-11 09:20:48 --> Router Class Initialized
INFO - 2023-04-11 09:20:48 --> Output Class Initialized
INFO - 2023-04-11 09:20:48 --> Output Class Initialized
INFO - 2023-04-11 09:20:48 --> Security Class Initialized
INFO - 2023-04-11 09:20:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:20:48 --> Input Class Initialized
INFO - 2023-04-11 09:20:48 --> Input Class Initialized
INFO - 2023-04-11 09:20:48 --> Language Class Initialized
INFO - 2023-04-11 09:20:48 --> Language Class Initialized
INFO - 2023-04-11 09:20:48 --> Loader Class Initialized
INFO - 2023-04-11 09:20:48 --> Loader Class Initialized
INFO - 2023-04-11 09:20:48 --> Controller Class Initialized
INFO - 2023-04-11 09:20:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:20:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:20:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:20:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:20:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:20:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:20:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:20:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:20:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:20:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:20:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:20:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:20:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:21:48 --> Config Class Initialized
INFO - 2023-04-11 09:21:48 --> Config Class Initialized
INFO - 2023-04-11 09:21:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:21:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:21:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:21:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:21:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:21:48 --> URI Class Initialized
INFO - 2023-04-11 09:21:48 --> URI Class Initialized
INFO - 2023-04-11 09:21:48 --> Router Class Initialized
INFO - 2023-04-11 09:21:48 --> Router Class Initialized
INFO - 2023-04-11 09:21:48 --> Output Class Initialized
INFO - 2023-04-11 09:21:48 --> Output Class Initialized
INFO - 2023-04-11 09:21:48 --> Security Class Initialized
INFO - 2023-04-11 09:21:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:21:48 --> Input Class Initialized
DEBUG - 2023-04-11 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:21:48 --> Language Class Initialized
INFO - 2023-04-11 09:21:48 --> Input Class Initialized
INFO - 2023-04-11 09:21:48 --> Loader Class Initialized
INFO - 2023-04-11 09:21:48 --> Language Class Initialized
INFO - 2023-04-11 09:21:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:21:48 --> Loader Class Initialized
INFO - 2023-04-11 09:21:48 --> Controller Class Initialized
INFO - 2023-04-11 09:21:48 --> Database Driver Class Initialized
DEBUG - 2023-04-11 09:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:21:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:21:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:21:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:21:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:21:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:21:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:21:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:21:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:21:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:22:48 --> Config Class Initialized
INFO - 2023-04-11 09:22:48 --> Config Class Initialized
INFO - 2023-04-11 09:22:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:22:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:22:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:22:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:22:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:22:48 --> URI Class Initialized
INFO - 2023-04-11 09:22:48 --> URI Class Initialized
INFO - 2023-04-11 09:22:48 --> Router Class Initialized
INFO - 2023-04-11 09:22:48 --> Router Class Initialized
INFO - 2023-04-11 09:22:48 --> Output Class Initialized
INFO - 2023-04-11 09:22:48 --> Output Class Initialized
INFO - 2023-04-11 09:22:48 --> Security Class Initialized
INFO - 2023-04-11 09:22:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:22:48 --> Input Class Initialized
INFO - 2023-04-11 09:22:48 --> Input Class Initialized
INFO - 2023-04-11 09:22:48 --> Language Class Initialized
INFO - 2023-04-11 09:22:48 --> Language Class Initialized
INFO - 2023-04-11 09:22:48 --> Loader Class Initialized
INFO - 2023-04-11 09:22:48 --> Loader Class Initialized
INFO - 2023-04-11 09:22:48 --> Controller Class Initialized
INFO - 2023-04-11 09:22:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:22:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:22:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:22:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:22:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:22:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:22:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:22:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:22:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:22:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:22:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:22:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:22:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:23:48 --> Config Class Initialized
INFO - 2023-04-11 09:23:48 --> Config Class Initialized
INFO - 2023-04-11 09:23:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:23:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:23:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:23:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:23:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:23:48 --> URI Class Initialized
INFO - 2023-04-11 09:23:48 --> URI Class Initialized
INFO - 2023-04-11 09:23:48 --> Router Class Initialized
INFO - 2023-04-11 09:23:48 --> Router Class Initialized
INFO - 2023-04-11 09:23:48 --> Output Class Initialized
INFO - 2023-04-11 09:23:48 --> Output Class Initialized
INFO - 2023-04-11 09:23:48 --> Security Class Initialized
INFO - 2023-04-11 09:23:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:23:48 --> Input Class Initialized
INFO - 2023-04-11 09:23:48 --> Input Class Initialized
INFO - 2023-04-11 09:23:48 --> Language Class Initialized
INFO - 2023-04-11 09:23:48 --> Language Class Initialized
INFO - 2023-04-11 09:23:48 --> Loader Class Initialized
INFO - 2023-04-11 09:23:48 --> Loader Class Initialized
INFO - 2023-04-11 09:23:48 --> Controller Class Initialized
INFO - 2023-04-11 09:23:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:23:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:23:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:23:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:23:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:23:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:23:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:23:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:23:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:23:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:23:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:24:50 --> Config Class Initialized
INFO - 2023-04-11 09:24:50 --> Config Class Initialized
INFO - 2023-04-11 09:24:50 --> Hooks Class Initialized
INFO - 2023-04-11 09:24:50 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:24:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:24:50 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:24:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:24:50 --> Utf8 Class Initialized
INFO - 2023-04-11 09:24:50 --> URI Class Initialized
INFO - 2023-04-11 09:24:50 --> URI Class Initialized
INFO - 2023-04-11 09:24:50 --> Router Class Initialized
INFO - 2023-04-11 09:24:50 --> Router Class Initialized
INFO - 2023-04-11 09:24:50 --> Output Class Initialized
INFO - 2023-04-11 09:24:50 --> Output Class Initialized
INFO - 2023-04-11 09:24:50 --> Security Class Initialized
INFO - 2023-04-11 09:24:50 --> Security Class Initialized
DEBUG - 2023-04-11 09:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:24:50 --> Input Class Initialized
INFO - 2023-04-11 09:24:50 --> Input Class Initialized
INFO - 2023-04-11 09:24:50 --> Language Class Initialized
INFO - 2023-04-11 09:24:50 --> Language Class Initialized
INFO - 2023-04-11 09:24:50 --> Loader Class Initialized
INFO - 2023-04-11 09:24:50 --> Loader Class Initialized
INFO - 2023-04-11 09:24:50 --> Controller Class Initialized
INFO - 2023-04-11 09:24:50 --> Controller Class Initialized
DEBUG - 2023-04-11 09:24:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:24:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:24:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:24:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:24:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:24:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:24:50 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:24:50 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:24:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:24:50 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:24:50 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:24:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:25:48 --> Config Class Initialized
INFO - 2023-04-11 09:25:48 --> Config Class Initialized
INFO - 2023-04-11 09:25:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:25:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:25:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:25:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:25:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:25:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:25:48 --> URI Class Initialized
INFO - 2023-04-11 09:25:48 --> URI Class Initialized
INFO - 2023-04-11 09:25:48 --> Router Class Initialized
INFO - 2023-04-11 09:25:48 --> Router Class Initialized
INFO - 2023-04-11 09:25:48 --> Output Class Initialized
INFO - 2023-04-11 09:25:48 --> Output Class Initialized
INFO - 2023-04-11 09:25:48 --> Security Class Initialized
INFO - 2023-04-11 09:25:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:25:48 --> Input Class Initialized
INFO - 2023-04-11 09:25:48 --> Input Class Initialized
INFO - 2023-04-11 09:25:48 --> Language Class Initialized
INFO - 2023-04-11 09:25:48 --> Language Class Initialized
INFO - 2023-04-11 09:25:48 --> Loader Class Initialized
INFO - 2023-04-11 09:25:48 --> Loader Class Initialized
INFO - 2023-04-11 09:25:48 --> Controller Class Initialized
INFO - 2023-04-11 09:25:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:25:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:25:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:25:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:25:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:25:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:25:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:25:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:25:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:25:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:25:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:25:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:25:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:26:58 --> Config Class Initialized
INFO - 2023-04-11 09:26:58 --> Config Class Initialized
INFO - 2023-04-11 09:26:58 --> Hooks Class Initialized
INFO - 2023-04-11 09:26:58 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:26:58 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:26:58 --> Utf8 Class Initialized
INFO - 2023-04-11 09:26:58 --> Utf8 Class Initialized
INFO - 2023-04-11 09:26:58 --> URI Class Initialized
INFO - 2023-04-11 09:26:58 --> URI Class Initialized
INFO - 2023-04-11 09:26:58 --> Router Class Initialized
INFO - 2023-04-11 09:26:58 --> Router Class Initialized
INFO - 2023-04-11 09:26:58 --> Output Class Initialized
INFO - 2023-04-11 09:26:58 --> Output Class Initialized
INFO - 2023-04-11 09:26:58 --> Security Class Initialized
INFO - 2023-04-11 09:26:58 --> Security Class Initialized
DEBUG - 2023-04-11 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:26:58 --> Input Class Initialized
DEBUG - 2023-04-11 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:26:58 --> Language Class Initialized
INFO - 2023-04-11 09:26:58 --> Input Class Initialized
INFO - 2023-04-11 09:26:58 --> Loader Class Initialized
INFO - 2023-04-11 09:26:58 --> Language Class Initialized
INFO - 2023-04-11 09:26:58 --> Controller Class Initialized
INFO - 2023-04-11 09:26:58 --> Loader Class Initialized
DEBUG - 2023-04-11 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:26:58 --> Controller Class Initialized
DEBUG - 2023-04-11 09:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:26:58 --> Database Driver Class Initialized
INFO - 2023-04-11 09:26:58 --> Database Driver Class Initialized
INFO - 2023-04-11 09:26:58 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:26:58 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:26:58 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:26:58 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:26:58 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:26:58 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:26:58 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:26:58 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:27:48 --> Config Class Initialized
INFO - 2023-04-11 09:27:48 --> Config Class Initialized
INFO - 2023-04-11 09:27:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:27:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:27:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:27:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:27:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:27:48 --> URI Class Initialized
INFO - 2023-04-11 09:27:48 --> URI Class Initialized
INFO - 2023-04-11 09:27:48 --> Router Class Initialized
INFO - 2023-04-11 09:27:48 --> Router Class Initialized
INFO - 2023-04-11 09:27:48 --> Output Class Initialized
INFO - 2023-04-11 09:27:48 --> Output Class Initialized
INFO - 2023-04-11 09:27:48 --> Security Class Initialized
INFO - 2023-04-11 09:27:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:27:48 --> Input Class Initialized
INFO - 2023-04-11 09:27:48 --> Input Class Initialized
INFO - 2023-04-11 09:27:48 --> Language Class Initialized
INFO - 2023-04-11 09:27:48 --> Language Class Initialized
INFO - 2023-04-11 09:27:48 --> Loader Class Initialized
INFO - 2023-04-11 09:27:48 --> Loader Class Initialized
INFO - 2023-04-11 09:27:48 --> Controller Class Initialized
INFO - 2023-04-11 09:27:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:27:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:27:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:27:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:27:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:27:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:27:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:27:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:27:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:27:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:27:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:27:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:27:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:28:48 --> Config Class Initialized
INFO - 2023-04-11 09:28:48 --> Config Class Initialized
INFO - 2023-04-11 09:28:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:28:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:28:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:28:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:28:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:28:48 --> URI Class Initialized
INFO - 2023-04-11 09:28:48 --> URI Class Initialized
INFO - 2023-04-11 09:28:48 --> Router Class Initialized
INFO - 2023-04-11 09:28:48 --> Router Class Initialized
INFO - 2023-04-11 09:28:48 --> Output Class Initialized
INFO - 2023-04-11 09:28:48 --> Output Class Initialized
INFO - 2023-04-11 09:28:48 --> Security Class Initialized
INFO - 2023-04-11 09:28:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:28:48 --> Input Class Initialized
DEBUG - 2023-04-11 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:28:48 --> Language Class Initialized
INFO - 2023-04-11 09:28:48 --> Input Class Initialized
INFO - 2023-04-11 09:28:48 --> Loader Class Initialized
INFO - 2023-04-11 09:28:48 --> Language Class Initialized
INFO - 2023-04-11 09:28:48 --> Controller Class Initialized
INFO - 2023-04-11 09:28:48 --> Loader Class Initialized
DEBUG - 2023-04-11 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:28:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:28:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:28:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:28:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:28:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:28:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:28:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:28:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:28:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:28:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:28:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:29:48 --> Config Class Initialized
INFO - 2023-04-11 09:29:48 --> Config Class Initialized
INFO - 2023-04-11 09:29:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:29:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:29:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:29:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:29:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:29:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:29:48 --> URI Class Initialized
INFO - 2023-04-11 09:29:48 --> URI Class Initialized
INFO - 2023-04-11 09:29:48 --> Router Class Initialized
INFO - 2023-04-11 09:29:48 --> Router Class Initialized
INFO - 2023-04-11 09:29:48 --> Output Class Initialized
INFO - 2023-04-11 09:29:48 --> Output Class Initialized
INFO - 2023-04-11 09:29:48 --> Security Class Initialized
INFO - 2023-04-11 09:29:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:29:48 --> Input Class Initialized
INFO - 2023-04-11 09:29:48 --> Input Class Initialized
INFO - 2023-04-11 09:29:48 --> Language Class Initialized
INFO - 2023-04-11 09:29:48 --> Language Class Initialized
INFO - 2023-04-11 09:29:48 --> Loader Class Initialized
INFO - 2023-04-11 09:29:48 --> Loader Class Initialized
INFO - 2023-04-11 09:29:48 --> Controller Class Initialized
INFO - 2023-04-11 09:29:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:29:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:29:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:29:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:29:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:29:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:29:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:29:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:29:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:29:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:29:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:29:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:29:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:30:48 --> Config Class Initialized
INFO - 2023-04-11 09:30:48 --> Config Class Initialized
INFO - 2023-04-11 09:30:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:30:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:30:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:30:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:30:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:30:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:30:48 --> URI Class Initialized
INFO - 2023-04-11 09:30:48 --> URI Class Initialized
INFO - 2023-04-11 09:30:48 --> Router Class Initialized
INFO - 2023-04-11 09:30:48 --> Router Class Initialized
INFO - 2023-04-11 09:30:48 --> Output Class Initialized
INFO - 2023-04-11 09:30:48 --> Output Class Initialized
INFO - 2023-04-11 09:30:48 --> Security Class Initialized
INFO - 2023-04-11 09:30:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:30:48 --> Input Class Initialized
INFO - 2023-04-11 09:30:48 --> Input Class Initialized
INFO - 2023-04-11 09:30:48 --> Language Class Initialized
INFO - 2023-04-11 09:30:48 --> Language Class Initialized
INFO - 2023-04-11 09:30:48 --> Loader Class Initialized
INFO - 2023-04-11 09:30:48 --> Loader Class Initialized
INFO - 2023-04-11 09:30:48 --> Controller Class Initialized
INFO - 2023-04-11 09:30:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:30:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:30:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:30:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:30:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:30:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:30:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:30:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:30:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:30:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:30:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:30:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:30:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:31:48 --> Config Class Initialized
INFO - 2023-04-11 09:31:48 --> Config Class Initialized
INFO - 2023-04-11 09:31:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:31:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:31:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:31:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:31:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:31:48 --> URI Class Initialized
INFO - 2023-04-11 09:31:48 --> URI Class Initialized
INFO - 2023-04-11 09:31:48 --> Router Class Initialized
INFO - 2023-04-11 09:31:48 --> Router Class Initialized
INFO - 2023-04-11 09:31:48 --> Output Class Initialized
INFO - 2023-04-11 09:31:48 --> Output Class Initialized
INFO - 2023-04-11 09:31:48 --> Security Class Initialized
INFO - 2023-04-11 09:31:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:31:48 --> Input Class Initialized
INFO - 2023-04-11 09:31:48 --> Input Class Initialized
INFO - 2023-04-11 09:31:48 --> Language Class Initialized
INFO - 2023-04-11 09:31:48 --> Language Class Initialized
INFO - 2023-04-11 09:31:48 --> Loader Class Initialized
INFO - 2023-04-11 09:31:48 --> Loader Class Initialized
INFO - 2023-04-11 09:31:48 --> Controller Class Initialized
INFO - 2023-04-11 09:31:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:31:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:31:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:31:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:31:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:31:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:31:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:31:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:31:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:31:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:31:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:31:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:31:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:32:48 --> Config Class Initialized
INFO - 2023-04-11 09:32:48 --> Config Class Initialized
INFO - 2023-04-11 09:32:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:32:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:32:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:32:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:32:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:32:48 --> URI Class Initialized
INFO - 2023-04-11 09:32:48 --> URI Class Initialized
INFO - 2023-04-11 09:32:48 --> Router Class Initialized
INFO - 2023-04-11 09:32:48 --> Router Class Initialized
INFO - 2023-04-11 09:32:48 --> Output Class Initialized
INFO - 2023-04-11 09:32:48 --> Output Class Initialized
INFO - 2023-04-11 09:32:48 --> Security Class Initialized
INFO - 2023-04-11 09:32:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:32:48 --> Input Class Initialized
INFO - 2023-04-11 09:32:48 --> Input Class Initialized
INFO - 2023-04-11 09:32:48 --> Language Class Initialized
INFO - 2023-04-11 09:32:48 --> Language Class Initialized
INFO - 2023-04-11 09:32:48 --> Loader Class Initialized
INFO - 2023-04-11 09:32:48 --> Loader Class Initialized
INFO - 2023-04-11 09:32:48 --> Controller Class Initialized
INFO - 2023-04-11 09:32:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:32:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:32:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:32:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:32:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:32:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:32:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:32:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:32:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:32:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:32:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:33:48 --> Config Class Initialized
INFO - 2023-04-11 09:33:48 --> Config Class Initialized
INFO - 2023-04-11 09:33:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:33:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:33:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:33:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:33:48 --> URI Class Initialized
INFO - 2023-04-11 09:33:48 --> URI Class Initialized
INFO - 2023-04-11 09:33:48 --> Router Class Initialized
INFO - 2023-04-11 09:33:48 --> Router Class Initialized
INFO - 2023-04-11 09:33:48 --> Output Class Initialized
INFO - 2023-04-11 09:33:48 --> Output Class Initialized
INFO - 2023-04-11 09:33:48 --> Security Class Initialized
INFO - 2023-04-11 09:33:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:33:48 --> Input Class Initialized
INFO - 2023-04-11 09:33:48 --> Input Class Initialized
INFO - 2023-04-11 09:33:48 --> Language Class Initialized
INFO - 2023-04-11 09:33:48 --> Language Class Initialized
INFO - 2023-04-11 09:33:48 --> Loader Class Initialized
INFO - 2023-04-11 09:33:48 --> Loader Class Initialized
INFO - 2023-04-11 09:33:48 --> Controller Class Initialized
INFO - 2023-04-11 09:33:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:33:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:33:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:33:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:33:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:33:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:33:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:33:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:33:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:33:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:33:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:34:48 --> Config Class Initialized
INFO - 2023-04-11 09:34:48 --> Config Class Initialized
INFO - 2023-04-11 09:34:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:34:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:34:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:34:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:34:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:34:48 --> URI Class Initialized
INFO - 2023-04-11 09:34:48 --> URI Class Initialized
INFO - 2023-04-11 09:34:48 --> Router Class Initialized
INFO - 2023-04-11 09:34:48 --> Router Class Initialized
INFO - 2023-04-11 09:34:48 --> Output Class Initialized
INFO - 2023-04-11 09:34:48 --> Output Class Initialized
INFO - 2023-04-11 09:34:48 --> Security Class Initialized
INFO - 2023-04-11 09:34:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:34:48 --> Input Class Initialized
INFO - 2023-04-11 09:34:48 --> Input Class Initialized
INFO - 2023-04-11 09:34:48 --> Language Class Initialized
INFO - 2023-04-11 09:34:48 --> Language Class Initialized
INFO - 2023-04-11 09:34:48 --> Loader Class Initialized
INFO - 2023-04-11 09:34:48 --> Loader Class Initialized
INFO - 2023-04-11 09:34:48 --> Controller Class Initialized
INFO - 2023-04-11 09:34:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:34:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:34:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:34:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:34:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:34:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:34:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:34:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 09:34:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:34:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:34:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:34:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:34:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:35:57 --> Config Class Initialized
INFO - 2023-04-11 09:35:57 --> Config Class Initialized
INFO - 2023-04-11 09:35:57 --> Hooks Class Initialized
INFO - 2023-04-11 09:35:57 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:35:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:35:57 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:35:57 --> Utf8 Class Initialized
INFO - 2023-04-11 09:35:57 --> Utf8 Class Initialized
INFO - 2023-04-11 09:35:57 --> URI Class Initialized
INFO - 2023-04-11 09:35:57 --> URI Class Initialized
INFO - 2023-04-11 09:35:57 --> Router Class Initialized
INFO - 2023-04-11 09:35:57 --> Router Class Initialized
INFO - 2023-04-11 09:35:57 --> Output Class Initialized
INFO - 2023-04-11 09:35:57 --> Output Class Initialized
INFO - 2023-04-11 09:35:57 --> Security Class Initialized
INFO - 2023-04-11 09:35:57 --> Security Class Initialized
DEBUG - 2023-04-11 09:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:35:57 --> Input Class Initialized
INFO - 2023-04-11 09:35:57 --> Input Class Initialized
INFO - 2023-04-11 09:35:57 --> Language Class Initialized
INFO - 2023-04-11 09:35:57 --> Language Class Initialized
INFO - 2023-04-11 09:35:57 --> Loader Class Initialized
INFO - 2023-04-11 09:35:57 --> Loader Class Initialized
INFO - 2023-04-11 09:35:57 --> Controller Class Initialized
INFO - 2023-04-11 09:35:57 --> Controller Class Initialized
DEBUG - 2023-04-11 09:35:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:35:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:35:57 --> Database Driver Class Initialized
INFO - 2023-04-11 09:35:57 --> Database Driver Class Initialized
INFO - 2023-04-11 09:35:57 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:35:57 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:35:57 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:35:57 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:35:57 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:35:57 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:35:57 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:35:57 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:36:48 --> Config Class Initialized
INFO - 2023-04-11 09:36:48 --> Config Class Initialized
INFO - 2023-04-11 09:36:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:36:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:36:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:36:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:36:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:36:48 --> URI Class Initialized
INFO - 2023-04-11 09:36:48 --> URI Class Initialized
INFO - 2023-04-11 09:36:48 --> Router Class Initialized
INFO - 2023-04-11 09:36:48 --> Router Class Initialized
INFO - 2023-04-11 09:36:48 --> Output Class Initialized
INFO - 2023-04-11 09:36:48 --> Output Class Initialized
INFO - 2023-04-11 09:36:48 --> Security Class Initialized
INFO - 2023-04-11 09:36:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:36:48 --> Input Class Initialized
INFO - 2023-04-11 09:36:48 --> Input Class Initialized
INFO - 2023-04-11 09:36:48 --> Language Class Initialized
INFO - 2023-04-11 09:36:48 --> Language Class Initialized
INFO - 2023-04-11 09:36:48 --> Loader Class Initialized
INFO - 2023-04-11 09:36:48 --> Loader Class Initialized
INFO - 2023-04-11 09:36:48 --> Controller Class Initialized
INFO - 2023-04-11 09:36:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:36:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:36:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:36:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:36:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:36:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:36:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:36:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:36:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:37:48 --> Config Class Initialized
INFO - 2023-04-11 09:37:48 --> Config Class Initialized
INFO - 2023-04-11 09:37:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:37:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:37:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:37:48 --> URI Class Initialized
INFO - 2023-04-11 09:37:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:37:48 --> URI Class Initialized
INFO - 2023-04-11 09:37:48 --> Router Class Initialized
INFO - 2023-04-11 09:37:48 --> Router Class Initialized
INFO - 2023-04-11 09:37:48 --> Output Class Initialized
INFO - 2023-04-11 09:37:48 --> Output Class Initialized
INFO - 2023-04-11 09:37:48 --> Security Class Initialized
INFO - 2023-04-11 09:37:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:37:48 --> Input Class Initialized
INFO - 2023-04-11 09:37:48 --> Input Class Initialized
INFO - 2023-04-11 09:37:48 --> Language Class Initialized
INFO - 2023-04-11 09:37:48 --> Language Class Initialized
INFO - 2023-04-11 09:37:48 --> Loader Class Initialized
INFO - 2023-04-11 09:37:48 --> Loader Class Initialized
INFO - 2023-04-11 09:37:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:37:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:37:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:37:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:37:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:37:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:37:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:37:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:37:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:37:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:37:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:37:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:38:52 --> Config Class Initialized
INFO - 2023-04-11 09:38:52 --> Config Class Initialized
INFO - 2023-04-11 09:38:52 --> Hooks Class Initialized
INFO - 2023-04-11 09:38:52 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:38:52 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:38:52 --> Utf8 Class Initialized
INFO - 2023-04-11 09:38:52 --> Utf8 Class Initialized
INFO - 2023-04-11 09:38:52 --> URI Class Initialized
INFO - 2023-04-11 09:38:52 --> URI Class Initialized
INFO - 2023-04-11 09:38:52 --> Router Class Initialized
INFO - 2023-04-11 09:38:52 --> Router Class Initialized
INFO - 2023-04-11 09:38:52 --> Output Class Initialized
INFO - 2023-04-11 09:38:52 --> Output Class Initialized
INFO - 2023-04-11 09:38:52 --> Security Class Initialized
INFO - 2023-04-11 09:38:52 --> Security Class Initialized
DEBUG - 2023-04-11 09:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:38:52 --> Input Class Initialized
INFO - 2023-04-11 09:38:52 --> Input Class Initialized
INFO - 2023-04-11 09:38:52 --> Language Class Initialized
INFO - 2023-04-11 09:38:52 --> Language Class Initialized
INFO - 2023-04-11 09:38:52 --> Loader Class Initialized
INFO - 2023-04-11 09:38:52 --> Loader Class Initialized
INFO - 2023-04-11 09:38:52 --> Controller Class Initialized
INFO - 2023-04-11 09:38:52 --> Controller Class Initialized
DEBUG - 2023-04-11 09:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:38:52 --> Database Driver Class Initialized
INFO - 2023-04-11 09:38:52 --> Database Driver Class Initialized
INFO - 2023-04-11 09:38:52 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:38:52 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:38:52 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:38:52 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:38:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:38:52 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:38:52 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:38:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:39:48 --> Config Class Initialized
INFO - 2023-04-11 09:39:48 --> Config Class Initialized
INFO - 2023-04-11 09:39:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:39:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:39:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:39:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:39:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:39:48 --> URI Class Initialized
INFO - 2023-04-11 09:39:48 --> URI Class Initialized
INFO - 2023-04-11 09:39:48 --> Router Class Initialized
INFO - 2023-04-11 09:39:48 --> Router Class Initialized
INFO - 2023-04-11 09:39:48 --> Output Class Initialized
INFO - 2023-04-11 09:39:48 --> Output Class Initialized
INFO - 2023-04-11 09:39:48 --> Security Class Initialized
INFO - 2023-04-11 09:39:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:39:48 --> Input Class Initialized
INFO - 2023-04-11 09:39:48 --> Input Class Initialized
INFO - 2023-04-11 09:39:48 --> Language Class Initialized
INFO - 2023-04-11 09:39:48 --> Language Class Initialized
INFO - 2023-04-11 09:39:48 --> Loader Class Initialized
INFO - 2023-04-11 09:39:48 --> Loader Class Initialized
INFO - 2023-04-11 09:39:48 --> Controller Class Initialized
INFO - 2023-04-11 09:39:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:39:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:39:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:39:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:39:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:39:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:39:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:39:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:39:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:39:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:39:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:40:48 --> Config Class Initialized
INFO - 2023-04-11 09:40:48 --> Config Class Initialized
INFO - 2023-04-11 09:40:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:40:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:40:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:40:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:40:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:40:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:40:48 --> URI Class Initialized
INFO - 2023-04-11 09:40:48 --> URI Class Initialized
INFO - 2023-04-11 09:40:48 --> Router Class Initialized
INFO - 2023-04-11 09:40:48 --> Router Class Initialized
INFO - 2023-04-11 09:40:48 --> Output Class Initialized
INFO - 2023-04-11 09:40:48 --> Output Class Initialized
INFO - 2023-04-11 09:40:48 --> Security Class Initialized
INFO - 2023-04-11 09:40:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:40:48 --> Input Class Initialized
INFO - 2023-04-11 09:40:48 --> Input Class Initialized
INFO - 2023-04-11 09:40:48 --> Language Class Initialized
INFO - 2023-04-11 09:40:48 --> Language Class Initialized
INFO - 2023-04-11 09:40:48 --> Loader Class Initialized
INFO - 2023-04-11 09:40:48 --> Loader Class Initialized
INFO - 2023-04-11 09:40:48 --> Controller Class Initialized
INFO - 2023-04-11 09:40:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:40:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:40:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:40:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:40:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:40:48 --> Model "Cluster_model" initialized
ERROR - 2023-04-11 09:40:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:40:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:40:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:40:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:40:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:41:48 --> Config Class Initialized
INFO - 2023-04-11 09:41:48 --> Config Class Initialized
INFO - 2023-04-11 09:41:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:41:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:41:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:41:48 --> URI Class Initialized
INFO - 2023-04-11 09:41:48 --> URI Class Initialized
INFO - 2023-04-11 09:41:48 --> Router Class Initialized
INFO - 2023-04-11 09:41:48 --> Router Class Initialized
INFO - 2023-04-11 09:41:48 --> Output Class Initialized
INFO - 2023-04-11 09:41:48 --> Output Class Initialized
INFO - 2023-04-11 09:41:48 --> Security Class Initialized
INFO - 2023-04-11 09:41:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:41:48 --> Input Class Initialized
INFO - 2023-04-11 09:41:48 --> Input Class Initialized
INFO - 2023-04-11 09:41:48 --> Language Class Initialized
INFO - 2023-04-11 09:41:48 --> Language Class Initialized
INFO - 2023-04-11 09:41:48 --> Loader Class Initialized
INFO - 2023-04-11 09:41:48 --> Loader Class Initialized
INFO - 2023-04-11 09:41:48 --> Controller Class Initialized
INFO - 2023-04-11 09:41:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:41:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:41:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:41:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:41:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:41:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:41:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:41:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:41:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:42:48 --> Config Class Initialized
INFO - 2023-04-11 09:42:48 --> Config Class Initialized
INFO - 2023-04-11 09:42:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:42:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:42:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:42:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:42:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:42:48 --> URI Class Initialized
INFO - 2023-04-11 09:42:48 --> URI Class Initialized
INFO - 2023-04-11 09:42:48 --> Router Class Initialized
INFO - 2023-04-11 09:42:48 --> Router Class Initialized
INFO - 2023-04-11 09:42:48 --> Output Class Initialized
INFO - 2023-04-11 09:42:48 --> Output Class Initialized
INFO - 2023-04-11 09:42:48 --> Security Class Initialized
INFO - 2023-04-11 09:42:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:42:48 --> Input Class Initialized
INFO - 2023-04-11 09:42:48 --> Input Class Initialized
INFO - 2023-04-11 09:42:48 --> Language Class Initialized
INFO - 2023-04-11 09:42:48 --> Language Class Initialized
INFO - 2023-04-11 09:42:48 --> Loader Class Initialized
INFO - 2023-04-11 09:42:48 --> Loader Class Initialized
INFO - 2023-04-11 09:42:48 --> Controller Class Initialized
INFO - 2023-04-11 09:42:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:42:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:42:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:42:48 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:42:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:42:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:42:48 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:42:48 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:42:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:09 --> Config Class Initialized
INFO - 2023-04-11 09:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:09 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:09 --> URI Class Initialized
INFO - 2023-04-11 09:43:09 --> Router Class Initialized
INFO - 2023-04-11 09:43:09 --> Output Class Initialized
INFO - 2023-04-11 09:43:09 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:09 --> Input Class Initialized
INFO - 2023-04-11 09:43:09 --> Language Class Initialized
INFO - 2023-04-11 09:43:09 --> Loader Class Initialized
INFO - 2023-04-11 09:43:09 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:09 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:09 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:09 --> Model "Login_model" initialized
ERROR - 2023-04-11 09:43:09 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS cluster_alarm_info (id bigint unsigned NOT NULL AUTO_INCREMENT,job_id VARCHAR (128) DEFAULT NULL,alarm_level enum('FATAL','ERROR','WARNING') NOT NULL DEFAULT 'WARNING',alarm_type varchar(128) DEFAULT NULL,status enum('unhandled','handled','ignore') NOT NULL DEFAULT 'unhandled',occur_timestamp timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),job_info text,handle_time timestamp(6) NULL DEFAULT NULL,handler_name varchar(128) DEFAULT NULL,cluster_id int unsigned DEFAULT NULL,shardid int unsigned DEFAULT NULL,compnodeid int unsigned DEFAULT NULL,svrid int unsigned DEFAULT NULL,PRIMARY KEY (id),UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-04-11 09:43:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:12 --> Config Class Initialized
INFO - 2023-04-11 09:43:12 --> Config Class Initialized
INFO - 2023-04-11 09:43:12 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:12 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:12 --> Config Class Initialized
INFO - 2023-04-11 09:43:12 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:12 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:12 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:12 --> URI Class Initialized
INFO - 2023-04-11 09:43:12 --> URI Class Initialized
DEBUG - 2023-04-11 09:43:12 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:12 --> Router Class Initialized
INFO - 2023-04-11 09:43:12 --> Router Class Initialized
INFO - 2023-04-11 09:43:12 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:13 --> Output Class Initialized
INFO - 2023-04-11 09:43:13 --> Output Class Initialized
INFO - 2023-04-11 09:43:13 --> URI Class Initialized
INFO - 2023-04-11 09:43:13 --> Security Class Initialized
INFO - 2023-04-11 09:43:13 --> Security Class Initialized
INFO - 2023-04-11 09:43:13 --> Router Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:13 --> Output Class Initialized
INFO - 2023-04-11 09:43:13 --> Input Class Initialized
INFO - 2023-04-11 09:43:13 --> Input Class Initialized
INFO - 2023-04-11 09:43:13 --> Security Class Initialized
INFO - 2023-04-11 09:43:13 --> Language Class Initialized
INFO - 2023-04-11 09:43:13 --> Language Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:13 --> Loader Class Initialized
INFO - 2023-04-11 09:43:13 --> Loader Class Initialized
INFO - 2023-04-11 09:43:13 --> Input Class Initialized
INFO - 2023-04-11 09:43:13 --> Controller Class Initialized
INFO - 2023-04-11 09:43:13 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:13 --> Language Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Loader Class Initialized
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:43:13 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-04-11 09:43:13 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:13 --> Config Class Initialized
INFO - 2023-04-11 09:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:13 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:13 --> URI Class Initialized
INFO - 2023-04-11 09:43:13 --> Router Class Initialized
INFO - 2023-04-11 09:43:13 --> Output Class Initialized
INFO - 2023-04-11 09:43:13 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:13 --> Input Class Initialized
INFO - 2023-04-11 09:43:13 --> Language Class Initialized
INFO - 2023-04-11 09:43:13 --> Loader Class Initialized
INFO - 2023-04-11 09:43:13 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:13 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:13 --> Total execution time: 0.1172
INFO - 2023-04-11 09:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:13 --> Config Class Initialized
INFO - 2023-04-11 09:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:13 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:13 --> URI Class Initialized
INFO - 2023-04-11 09:43:13 --> Router Class Initialized
INFO - 2023-04-11 09:43:13 --> Output Class Initialized
INFO - 2023-04-11 09:43:13 --> Security Class Initialized
ERROR - 2023-04-11 09:43:13 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
DEBUG - 2023-04-11 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:13 --> Input Class Initialized
INFO - 2023-04-11 09:43:13 --> Language Class Initialized
INFO - 2023-04-11 09:43:13 --> Loader Class Initialized
INFO - 2023-04-11 09:43:13 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:13 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:13 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:13 --> Total execution time: 0.0194
INFO - 2023-04-11 09:43:26 --> Config Class Initialized
INFO - 2023-04-11 09:43:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:26 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:26 --> URI Class Initialized
INFO - 2023-04-11 09:43:26 --> Router Class Initialized
INFO - 2023-04-11 09:43:26 --> Output Class Initialized
INFO - 2023-04-11 09:43:26 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:26 --> Input Class Initialized
INFO - 2023-04-11 09:43:26 --> Language Class Initialized
INFO - 2023-04-11 09:43:26 --> Loader Class Initialized
INFO - 2023-04-11 09:43:26 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:26 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:26 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:26 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:26 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:26 --> Total execution time: 0.1749
INFO - 2023-04-11 09:43:26 --> Config Class Initialized
INFO - 2023-04-11 09:43:26 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:26 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:26 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:26 --> URI Class Initialized
INFO - 2023-04-11 09:43:26 --> Router Class Initialized
INFO - 2023-04-11 09:43:26 --> Output Class Initialized
INFO - 2023-04-11 09:43:26 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:26 --> Input Class Initialized
INFO - 2023-04-11 09:43:26 --> Language Class Initialized
INFO - 2023-04-11 09:43:26 --> Loader Class Initialized
INFO - 2023-04-11 09:43:26 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:26 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:26 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:26 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:26 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:26 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:26 --> Total execution time: 0.1144
INFO - 2023-04-11 09:43:30 --> Config Class Initialized
INFO - 2023-04-11 09:43:30 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:30 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:30 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:30 --> URI Class Initialized
INFO - 2023-04-11 09:43:30 --> Router Class Initialized
INFO - 2023-04-11 09:43:30 --> Output Class Initialized
INFO - 2023-04-11 09:43:30 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:30 --> Input Class Initialized
INFO - 2023-04-11 09:43:30 --> Language Class Initialized
INFO - 2023-04-11 09:43:30 --> Loader Class Initialized
INFO - 2023-04-11 09:43:30 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:30 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:30 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:30 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:30 --> Total execution time: 0.0162
INFO - 2023-04-11 09:43:30 --> Config Class Initialized
INFO - 2023-04-11 09:43:30 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:30 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:30 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:30 --> URI Class Initialized
INFO - 2023-04-11 09:43:30 --> Router Class Initialized
INFO - 2023-04-11 09:43:30 --> Output Class Initialized
INFO - 2023-04-11 09:43:30 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:30 --> Input Class Initialized
INFO - 2023-04-11 09:43:30 --> Language Class Initialized
INFO - 2023-04-11 09:43:30 --> Loader Class Initialized
INFO - 2023-04-11 09:43:30 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:30 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:30 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:30 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:30 --> Total execution time: 0.0532
INFO - 2023-04-11 09:43:32 --> Config Class Initialized
INFO - 2023-04-11 09:43:32 --> Config Class Initialized
INFO - 2023-04-11 09:43:32 --> Config Class Initialized
INFO - 2023-04-11 09:43:32 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:32 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:32 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:43:32 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:32 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:32 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:32 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:32 --> URI Class Initialized
INFO - 2023-04-11 09:43:32 --> URI Class Initialized
INFO - 2023-04-11 09:43:32 --> URI Class Initialized
INFO - 2023-04-11 09:43:32 --> Router Class Initialized
INFO - 2023-04-11 09:43:32 --> Router Class Initialized
INFO - 2023-04-11 09:43:32 --> Router Class Initialized
INFO - 2023-04-11 09:43:32 --> Output Class Initialized
INFO - 2023-04-11 09:43:32 --> Output Class Initialized
INFO - 2023-04-11 09:43:32 --> Security Class Initialized
INFO - 2023-04-11 09:43:32 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:32 --> Output Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:32 --> Input Class Initialized
INFO - 2023-04-11 09:43:32 --> Security Class Initialized
INFO - 2023-04-11 09:43:32 --> Input Class Initialized
INFO - 2023-04-11 09:43:32 --> Language Class Initialized
INFO - 2023-04-11 09:43:32 --> Language Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:32 --> Input Class Initialized
INFO - 2023-04-11 09:43:32 --> Loader Class Initialized
INFO - 2023-04-11 09:43:32 --> Loader Class Initialized
INFO - 2023-04-11 09:43:32 --> Language Class Initialized
INFO - 2023-04-11 09:43:32 --> Controller Class Initialized
INFO - 2023-04-11 09:43:32 --> Controller Class Initialized
INFO - 2023-04-11 09:43:32 --> Loader Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:32 --> Controller Class Initialized
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:32 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:32 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
ERROR - 2023-04-11 09:43:32 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
ERROR - 2023-04-11 09:43:32 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:43:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:32 --> Config Class Initialized
INFO - 2023-04-11 09:43:32 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:32 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:32 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:32 --> URI Class Initialized
INFO - 2023-04-11 09:43:32 --> Router Class Initialized
INFO - 2023-04-11 09:43:32 --> Output Class Initialized
INFO - 2023-04-11 09:43:32 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:32 --> Input Class Initialized
INFO - 2023-04-11 09:43:32 --> Language Class Initialized
INFO - 2023-04-11 09:43:32 --> Loader Class Initialized
INFO - 2023-04-11 09:43:32 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:32 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:32 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:32 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:32 --> Total execution time: 0.0449
ERROR - 2023-04-11 09:43:32 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-11 09:43:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-11 09:43:32 --> Config Class Initialized
INFO - 2023-04-11 09:43:32 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:32 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:32 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:32 --> URI Class Initialized
INFO - 2023-04-11 09:43:32 --> Router Class Initialized
INFO - 2023-04-11 09:43:32 --> Output Class Initialized
INFO - 2023-04-11 09:43:32 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:32 --> Input Class Initialized
INFO - 2023-04-11 09:43:32 --> Language Class Initialized
INFO - 2023-04-11 09:43:32 --> Loader Class Initialized
INFO - 2023-04-11 09:43:32 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:32 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:32 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:32 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:32 --> Total execution time: 0.0276
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
INFO - 2023-04-11 09:43:45 --> Helper loaded: form_helper
INFO - 2023-04-11 09:43:45 --> Helper loaded: url_helper
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Model "Change_model" initialized
INFO - 2023-04-11 09:43:45 --> Model "Grafana_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0608
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
INFO - 2023-04-11 09:43:45 --> Helper loaded: form_helper
INFO - 2023-04-11 09:43:45 --> Helper loaded: url_helper
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0027
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
INFO - 2023-04-11 09:43:45 --> Helper loaded: form_helper
INFO - 2023-04-11 09:43:45 --> Helper loaded: url_helper
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0581
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0208
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0235
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0767
INFO - 2023-04-11 09:43:45 --> Config Class Initialized
INFO - 2023-04-11 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:45 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:45 --> URI Class Initialized
INFO - 2023-04-11 09:43:45 --> Router Class Initialized
INFO - 2023-04-11 09:43:45 --> Output Class Initialized
INFO - 2023-04-11 09:43:45 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:45 --> Input Class Initialized
INFO - 2023-04-11 09:43:45 --> Language Class Initialized
INFO - 2023-04-11 09:43:45 --> Loader Class Initialized
INFO - 2023-04-11 09:43:45 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:45 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:45 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:45 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:45 --> Total execution time: 0.0595
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:48 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0319
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0404
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0483
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:48 --> Model "Login_model" initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0651
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.1453
INFO - 2023-04-11 09:43:48 --> Config Class Initialized
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
INFO - 2023-04-11 09:43:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0789
DEBUG - 2023-04-11 09:43:48 --> Total execution time: 0.0995
INFO - 2023-04-11 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:43:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:43:48 --> URI Class Initialized
INFO - 2023-04-11 09:43:48 --> Router Class Initialized
INFO - 2023-04-11 09:43:48 --> Output Class Initialized
INFO - 2023-04-11 09:43:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:43:48 --> Input Class Initialized
INFO - 2023-04-11 09:43:48 --> Language Class Initialized
INFO - 2023-04-11 09:43:48 --> Loader Class Initialized
INFO - 2023-04-11 09:43:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:43:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:43:49 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:43:49 --> Final output sent to browser
DEBUG - 2023-04-11 09:43:49 --> Total execution time: 0.5778
INFO - 2023-04-11 09:44:47 --> Config Class Initialized
INFO - 2023-04-11 09:44:47 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:47 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:47 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:47 --> URI Class Initialized
INFO - 2023-04-11 09:44:47 --> Router Class Initialized
INFO - 2023-04-11 09:44:47 --> Output Class Initialized
INFO - 2023-04-11 09:44:47 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:47 --> Input Class Initialized
INFO - 2023-04-11 09:44:47 --> Language Class Initialized
INFO - 2023-04-11 09:44:47 --> Loader Class Initialized
INFO - 2023-04-11 09:44:47 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:47 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:47 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:47 --> Total execution time: 0.0888
INFO - 2023-04-11 09:44:47 --> Config Class Initialized
INFO - 2023-04-11 09:44:47 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:47 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:47 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:47 --> URI Class Initialized
INFO - 2023-04-11 09:44:47 --> Router Class Initialized
INFO - 2023-04-11 09:44:47 --> Output Class Initialized
INFO - 2023-04-11 09:44:47 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:47 --> Input Class Initialized
INFO - 2023-04-11 09:44:47 --> Language Class Initialized
INFO - 2023-04-11 09:44:47 --> Loader Class Initialized
INFO - 2023-04-11 09:44:47 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:47 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:47 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:47 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:47 --> Total execution time: 0.0679
INFO - 2023-04-11 09:44:48 --> Config Class Initialized
INFO - 2023-04-11 09:44:48 --> Config Class Initialized
INFO - 2023-04-11 09:44:48 --> Hooks Class Initialized
INFO - 2023-04-11 09:44:48 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:44:48 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:48 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:48 --> URI Class Initialized
INFO - 2023-04-11 09:44:48 --> URI Class Initialized
INFO - 2023-04-11 09:44:48 --> Router Class Initialized
INFO - 2023-04-11 09:44:48 --> Router Class Initialized
INFO - 2023-04-11 09:44:48 --> Output Class Initialized
INFO - 2023-04-11 09:44:48 --> Output Class Initialized
INFO - 2023-04-11 09:44:48 --> Security Class Initialized
INFO - 2023-04-11 09:44:48 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:48 --> Input Class Initialized
INFO - 2023-04-11 09:44:48 --> Input Class Initialized
INFO - 2023-04-11 09:44:48 --> Language Class Initialized
INFO - 2023-04-11 09:44:48 --> Language Class Initialized
INFO - 2023-04-11 09:44:48 --> Loader Class Initialized
INFO - 2023-04-11 09:44:48 --> Loader Class Initialized
INFO - 2023-04-11 09:44:48 --> Controller Class Initialized
INFO - 2023-04-11 09:44:48 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:44:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:48 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:48 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:48 --> Model "Login_model" initialized
INFO - 2023-04-11 09:44:48 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:48 --> Total execution time: 0.0751
INFO - 2023-04-11 09:44:49 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:49 --> Total execution time: 0.9248
INFO - 2023-04-11 09:44:49 --> Config Class Initialized
INFO - 2023-04-11 09:44:49 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:49 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:49 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:49 --> URI Class Initialized
INFO - 2023-04-11 09:44:49 --> Router Class Initialized
INFO - 2023-04-11 09:44:49 --> Output Class Initialized
INFO - 2023-04-11 09:44:49 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:49 --> Input Class Initialized
INFO - 2023-04-11 09:44:49 --> Language Class Initialized
INFO - 2023-04-11 09:44:49 --> Loader Class Initialized
INFO - 2023-04-11 09:44:49 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:49 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:49 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:49 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:49 --> Model "Login_model" initialized
INFO - 2023-04-11 09:44:50 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:50 --> Total execution time: 0.7984
INFO - 2023-04-11 09:44:50 --> Config Class Initialized
INFO - 2023-04-11 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:50 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:50 --> URI Class Initialized
INFO - 2023-04-11 09:44:50 --> Router Class Initialized
INFO - 2023-04-11 09:44:50 --> Output Class Initialized
INFO - 2023-04-11 09:44:50 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:50 --> Input Class Initialized
INFO - 2023-04-11 09:44:50 --> Language Class Initialized
INFO - 2023-04-11 09:44:50 --> Loader Class Initialized
INFO - 2023-04-11 09:44:50 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:50 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:50 --> Total execution time: 0.0205
INFO - 2023-04-11 09:44:50 --> Config Class Initialized
INFO - 2023-04-11 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:50 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:50 --> URI Class Initialized
INFO - 2023-04-11 09:44:50 --> Router Class Initialized
INFO - 2023-04-11 09:44:50 --> Output Class Initialized
INFO - 2023-04-11 09:44:50 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:50 --> Input Class Initialized
INFO - 2023-04-11 09:44:50 --> Language Class Initialized
INFO - 2023-04-11 09:44:50 --> Loader Class Initialized
INFO - 2023-04-11 09:44:50 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:50 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:50 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:50 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:50 --> Total execution time: 0.0142
INFO - 2023-04-11 09:44:53 --> Config Class Initialized
INFO - 2023-04-11 09:44:53 --> Config Class Initialized
INFO - 2023-04-11 09:44:53 --> Hooks Class Initialized
INFO - 2023-04-11 09:44:53 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-11 09:44:53 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:53 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:53 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:53 --> URI Class Initialized
INFO - 2023-04-11 09:44:53 --> URI Class Initialized
INFO - 2023-04-11 09:44:53 --> Router Class Initialized
INFO - 2023-04-11 09:44:53 --> Router Class Initialized
INFO - 2023-04-11 09:44:53 --> Output Class Initialized
INFO - 2023-04-11 09:44:53 --> Output Class Initialized
INFO - 2023-04-11 09:44:53 --> Security Class Initialized
INFO - 2023-04-11 09:44:53 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-11 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:53 --> Input Class Initialized
INFO - 2023-04-11 09:44:53 --> Input Class Initialized
INFO - 2023-04-11 09:44:53 --> Language Class Initialized
INFO - 2023-04-11 09:44:53 --> Language Class Initialized
INFO - 2023-04-11 09:44:53 --> Loader Class Initialized
INFO - 2023-04-11 09:44:53 --> Loader Class Initialized
INFO - 2023-04-11 09:44:53 --> Controller Class Initialized
INFO - 2023-04-11 09:44:53 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-11 09:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:53 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:53 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:53 --> Total execution time: 0.0030
INFO - 2023-04-11 09:44:53 --> Config Class Initialized
INFO - 2023-04-11 09:44:53 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:53 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:53 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:53 --> URI Class Initialized
INFO - 2023-04-11 09:44:53 --> Router Class Initialized
INFO - 2023-04-11 09:44:53 --> Output Class Initialized
INFO - 2023-04-11 09:44:53 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:53 --> Input Class Initialized
INFO - 2023-04-11 09:44:53 --> Language Class Initialized
INFO - 2023-04-11 09:44:53 --> Loader Class Initialized
INFO - 2023-04-11 09:44:53 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:53 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:53 --> Model "Login_model" initialized
INFO - 2023-04-11 09:44:53 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:53 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:53 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:53 --> Total execution time: 0.2087
INFO - 2023-04-11 09:44:53 --> Config Class Initialized
INFO - 2023-04-11 09:44:53 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:53 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:53 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:53 --> URI Class Initialized
INFO - 2023-04-11 09:44:53 --> Router Class Initialized
INFO - 2023-04-11 09:44:53 --> Output Class Initialized
INFO - 2023-04-11 09:44:53 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:53 --> Input Class Initialized
INFO - 2023-04-11 09:44:53 --> Language Class Initialized
INFO - 2023-04-11 09:44:53 --> Loader Class Initialized
INFO - 2023-04-11 09:44:53 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:53 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:53 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:53 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:53 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:53 --> Total execution time: 0.2270
INFO - 2023-04-11 09:44:53 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:53 --> Total execution time: 0.0337
INFO - 2023-04-11 09:44:56 --> Config Class Initialized
INFO - 2023-04-11 09:44:56 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:56 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:56 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:56 --> URI Class Initialized
INFO - 2023-04-11 09:44:56 --> Router Class Initialized
INFO - 2023-04-11 09:44:56 --> Output Class Initialized
INFO - 2023-04-11 09:44:56 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:56 --> Input Class Initialized
INFO - 2023-04-11 09:44:56 --> Language Class Initialized
INFO - 2023-04-11 09:44:56 --> Loader Class Initialized
INFO - 2023-04-11 09:44:56 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:56 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:56 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:56 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:56 --> Model "Login_model" initialized
INFO - 2023-04-11 09:44:56 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:56 --> Total execution time: 0.0971
INFO - 2023-04-11 09:44:56 --> Config Class Initialized
INFO - 2023-04-11 09:44:56 --> Hooks Class Initialized
DEBUG - 2023-04-11 09:44:56 --> UTF-8 Support Enabled
INFO - 2023-04-11 09:44:56 --> Utf8 Class Initialized
INFO - 2023-04-11 09:44:56 --> URI Class Initialized
INFO - 2023-04-11 09:44:56 --> Router Class Initialized
INFO - 2023-04-11 09:44:56 --> Output Class Initialized
INFO - 2023-04-11 09:44:56 --> Security Class Initialized
DEBUG - 2023-04-11 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 09:44:56 --> Input Class Initialized
INFO - 2023-04-11 09:44:56 --> Language Class Initialized
INFO - 2023-04-11 09:44:56 --> Loader Class Initialized
INFO - 2023-04-11 09:44:56 --> Controller Class Initialized
DEBUG - 2023-04-11 09:44:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 09:44:56 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:56 --> Model "Cluster_model" initialized
INFO - 2023-04-11 09:44:56 --> Database Driver Class Initialized
INFO - 2023-04-11 09:44:56 --> Model "Login_model" initialized
INFO - 2023-04-11 09:44:56 --> Final output sent to browser
DEBUG - 2023-04-11 09:44:56 --> Total execution time: 0.2583
INFO - 2023-04-11 10:29:10 --> Config Class Initialized
INFO - 2023-04-11 10:29:10 --> Hooks Class Initialized
DEBUG - 2023-04-11 10:29:10 --> UTF-8 Support Enabled
INFO - 2023-04-11 10:29:10 --> Utf8 Class Initialized
INFO - 2023-04-11 10:29:10 --> URI Class Initialized
INFO - 2023-04-11 10:29:10 --> Router Class Initialized
INFO - 2023-04-11 10:29:10 --> Output Class Initialized
INFO - 2023-04-11 10:29:10 --> Security Class Initialized
DEBUG - 2023-04-11 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 10:29:10 --> Input Class Initialized
INFO - 2023-04-11 10:29:10 --> Language Class Initialized
INFO - 2023-04-11 10:29:10 --> Loader Class Initialized
INFO - 2023-04-11 10:29:10 --> Controller Class Initialized
DEBUG - 2023-04-11 10:29:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 10:29:11 --> Database Driver Class Initialized
INFO - 2023-04-11 10:29:11 --> Model "Cluster_model" initialized
INFO - 2023-04-11 10:29:11 --> Database Driver Class Initialized
INFO - 2023-04-11 10:29:11 --> Model "Login_model" initialized
INFO - 2023-04-11 10:29:11 --> Final output sent to browser
DEBUG - 2023-04-11 10:29:11 --> Total execution time: 0.1224
INFO - 2023-04-11 10:29:11 --> Config Class Initialized
INFO - 2023-04-11 10:29:11 --> Hooks Class Initialized
DEBUG - 2023-04-11 10:29:11 --> UTF-8 Support Enabled
INFO - 2023-04-11 10:29:11 --> Utf8 Class Initialized
INFO - 2023-04-11 10:29:11 --> URI Class Initialized
INFO - 2023-04-11 10:29:11 --> Router Class Initialized
INFO - 2023-04-11 10:29:11 --> Output Class Initialized
INFO - 2023-04-11 10:29:11 --> Security Class Initialized
DEBUG - 2023-04-11 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-11 10:29:11 --> Input Class Initialized
INFO - 2023-04-11 10:29:11 --> Language Class Initialized
INFO - 2023-04-11 10:29:11 --> Loader Class Initialized
INFO - 2023-04-11 10:29:11 --> Controller Class Initialized
DEBUG - 2023-04-11 10:29:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-11 10:29:11 --> Database Driver Class Initialized
INFO - 2023-04-11 10:29:11 --> Model "Cluster_model" initialized
INFO - 2023-04-11 10:29:11 --> Database Driver Class Initialized
INFO - 2023-04-11 10:29:11 --> Model "Login_model" initialized
INFO - 2023-04-11 10:29:11 --> Final output sent to browser
DEBUG - 2023-04-11 10:29:11 --> Total execution time: 0.0994
