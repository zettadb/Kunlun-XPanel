<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-06 02:55:20 --> Config Class Initialized
INFO - 2023-02-06 02:55:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:20 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:20 --> URI Class Initialized
INFO - 2023-02-06 02:55:20 --> Router Class Initialized
INFO - 2023-02-06 02:55:20 --> Output Class Initialized
INFO - 2023-02-06 02:55:20 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:20 --> Input Class Initialized
INFO - 2023-02-06 02:55:20 --> Language Class Initialized
ERROR - 2023-02-06 02:55:20 --> 404 Page Not Found: /index
INFO - 2023-02-06 02:55:20 --> Config Class Initialized
INFO - 2023-02-06 02:55:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:21 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:21 --> URI Class Initialized
INFO - 2023-02-06 02:55:21 --> Router Class Initialized
INFO - 2023-02-06 02:55:21 --> Output Class Initialized
INFO - 2023-02-06 02:55:21 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:21 --> Input Class Initialized
INFO - 2023-02-06 02:55:21 --> Language Class Initialized
ERROR - 2023-02-06 02:55:21 --> 404 Page Not Found: Faviconico/index
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
INFO - 2023-02-06 02:55:29 --> Helper loaded: form_helper
INFO - 2023-02-06 02:55:29 --> Helper loaded: url_helper
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Model "Change_model" initialized
INFO - 2023-02-06 02:55:29 --> Model "Grafana_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0574
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
INFO - 2023-02-06 02:55:29 --> Helper loaded: form_helper
INFO - 2023-02-06 02:55:29 --> Helper loaded: url_helper
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0037
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
INFO - 2023-02-06 02:55:29 --> Helper loaded: form_helper
INFO - 2023-02-06 02:55:29 --> Helper loaded: url_helper
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Login_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0799
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0442
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0179
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Login_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0862
INFO - 2023-02-06 02:55:29 --> Config Class Initialized
INFO - 2023-02-06 02:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:29 --> URI Class Initialized
INFO - 2023-02-06 02:55:29 --> Router Class Initialized
INFO - 2023-02-06 02:55:29 --> Output Class Initialized
INFO - 2023-02-06 02:55:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:29 --> Input Class Initialized
INFO - 2023-02-06 02:55:29 --> Language Class Initialized
INFO - 2023-02-06 02:55:29 --> Loader Class Initialized
INFO - 2023-02-06 02:55:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:29 --> Model "Login_model" initialized
INFO - 2023-02-06 02:55:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:29 --> Total execution time: 0.0411
INFO - 2023-02-06 02:55:43 --> Config Class Initialized
INFO - 2023-02-06 02:55:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:43 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:43 --> URI Class Initialized
INFO - 2023-02-06 02:55:43 --> Router Class Initialized
INFO - 2023-02-06 02:55:43 --> Output Class Initialized
INFO - 2023-02-06 02:55:43 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:43 --> Input Class Initialized
INFO - 2023-02-06 02:55:43 --> Language Class Initialized
INFO - 2023-02-06 02:55:43 --> Loader Class Initialized
INFO - 2023-02-06 02:55:43 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:43 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:43 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:43 --> Total execution time: 0.0213
INFO - 2023-02-06 02:55:43 --> Config Class Initialized
INFO - 2023-02-06 02:55:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:43 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:43 --> URI Class Initialized
INFO - 2023-02-06 02:55:43 --> Router Class Initialized
INFO - 2023-02-06 02:55:43 --> Output Class Initialized
INFO - 2023-02-06 02:55:43 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:43 --> Input Class Initialized
INFO - 2023-02-06 02:55:43 --> Language Class Initialized
INFO - 2023-02-06 02:55:43 --> Loader Class Initialized
INFO - 2023-02-06 02:55:43 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:43 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:43 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:43 --> Total execution time: 0.0118
INFO - 2023-02-06 02:55:45 --> Config Class Initialized
INFO - 2023-02-06 02:55:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:45 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:45 --> URI Class Initialized
INFO - 2023-02-06 02:55:45 --> Router Class Initialized
INFO - 2023-02-06 02:55:45 --> Output Class Initialized
INFO - 2023-02-06 02:55:45 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:45 --> Input Class Initialized
INFO - 2023-02-06 02:55:45 --> Language Class Initialized
INFO - 2023-02-06 02:55:45 --> Loader Class Initialized
INFO - 2023-02-06 02:55:45 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:45 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:45 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:45 --> Total execution time: 0.0244
INFO - 2023-02-06 02:55:45 --> Config Class Initialized
INFO - 2023-02-06 02:55:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:55:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:55:45 --> Utf8 Class Initialized
INFO - 2023-02-06 02:55:45 --> URI Class Initialized
INFO - 2023-02-06 02:55:45 --> Router Class Initialized
INFO - 2023-02-06 02:55:45 --> Output Class Initialized
INFO - 2023-02-06 02:55:45 --> Security Class Initialized
DEBUG - 2023-02-06 02:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:55:45 --> Input Class Initialized
INFO - 2023-02-06 02:55:45 --> Language Class Initialized
INFO - 2023-02-06 02:55:45 --> Loader Class Initialized
INFO - 2023-02-06 02:55:45 --> Controller Class Initialized
DEBUG - 2023-02-06 02:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:55:45 --> Database Driver Class Initialized
INFO - 2023-02-06 02:55:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:55:45 --> Final output sent to browser
DEBUG - 2023-02-06 02:55:45 --> Total execution time: 0.0197
INFO - 2023-02-06 02:56:52 --> Config Class Initialized
INFO - 2023-02-06 02:56:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:56:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:56:52 --> Utf8 Class Initialized
INFO - 2023-02-06 02:56:52 --> URI Class Initialized
INFO - 2023-02-06 02:56:52 --> Router Class Initialized
INFO - 2023-02-06 02:56:52 --> Output Class Initialized
INFO - 2023-02-06 02:56:52 --> Security Class Initialized
DEBUG - 2023-02-06 02:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:56:52 --> Input Class Initialized
INFO - 2023-02-06 02:56:52 --> Language Class Initialized
INFO - 2023-02-06 02:56:52 --> Loader Class Initialized
INFO - 2023-02-06 02:56:52 --> Controller Class Initialized
DEBUG - 2023-02-06 02:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:56:52 --> Final output sent to browser
DEBUG - 2023-02-06 02:56:52 --> Total execution time: 0.0470
INFO - 2023-02-06 02:56:52 --> Config Class Initialized
INFO - 2023-02-06 02:56:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:56:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:56:52 --> Utf8 Class Initialized
INFO - 2023-02-06 02:56:52 --> URI Class Initialized
INFO - 2023-02-06 02:56:52 --> Router Class Initialized
INFO - 2023-02-06 02:56:52 --> Output Class Initialized
INFO - 2023-02-06 02:56:52 --> Security Class Initialized
DEBUG - 2023-02-06 02:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:56:52 --> Input Class Initialized
INFO - 2023-02-06 02:56:52 --> Language Class Initialized
INFO - 2023-02-06 02:56:52 --> Loader Class Initialized
INFO - 2023-02-06 02:56:52 --> Controller Class Initialized
DEBUG - 2023-02-06 02:56:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:56:52 --> Database Driver Class Initialized
INFO - 2023-02-06 02:56:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:56:52 --> Final output sent to browser
DEBUG - 2023-02-06 02:56:52 --> Total execution time: 0.0137
INFO - 2023-02-06 02:56:56 --> Config Class Initialized
INFO - 2023-02-06 02:56:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:56:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:56:56 --> Utf8 Class Initialized
INFO - 2023-02-06 02:56:56 --> URI Class Initialized
INFO - 2023-02-06 02:56:56 --> Router Class Initialized
INFO - 2023-02-06 02:56:56 --> Output Class Initialized
INFO - 2023-02-06 02:56:56 --> Security Class Initialized
DEBUG - 2023-02-06 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:56:56 --> Input Class Initialized
INFO - 2023-02-06 02:56:56 --> Language Class Initialized
INFO - 2023-02-06 02:56:56 --> Loader Class Initialized
INFO - 2023-02-06 02:56:56 --> Controller Class Initialized
DEBUG - 2023-02-06 02:56:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:56:56 --> Database Driver Class Initialized
INFO - 2023-02-06 02:56:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:56:56 --> Final output sent to browser
DEBUG - 2023-02-06 02:56:56 --> Total execution time: 0.0169
INFO - 2023-02-06 02:56:56 --> Config Class Initialized
INFO - 2023-02-06 02:56:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:56:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:56:56 --> Utf8 Class Initialized
INFO - 2023-02-06 02:56:56 --> URI Class Initialized
INFO - 2023-02-06 02:56:56 --> Router Class Initialized
INFO - 2023-02-06 02:56:56 --> Output Class Initialized
INFO - 2023-02-06 02:56:56 --> Security Class Initialized
DEBUG - 2023-02-06 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:56:56 --> Input Class Initialized
INFO - 2023-02-06 02:56:56 --> Language Class Initialized
INFO - 2023-02-06 02:56:56 --> Loader Class Initialized
INFO - 2023-02-06 02:56:56 --> Controller Class Initialized
DEBUG - 2023-02-06 02:56:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:56:56 --> Database Driver Class Initialized
INFO - 2023-02-06 02:56:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:56:56 --> Final output sent to browser
DEBUG - 2023-02-06 02:56:56 --> Total execution time: 0.0097
INFO - 2023-02-06 02:57:00 --> Config Class Initialized
INFO - 2023-02-06 02:57:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:00 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:00 --> URI Class Initialized
INFO - 2023-02-06 02:57:00 --> Router Class Initialized
INFO - 2023-02-06 02:57:00 --> Output Class Initialized
INFO - 2023-02-06 02:57:00 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:00 --> Input Class Initialized
INFO - 2023-02-06 02:57:00 --> Language Class Initialized
INFO - 2023-02-06 02:57:00 --> Loader Class Initialized
INFO - 2023-02-06 02:57:00 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:00 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:00 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:00 --> Total execution time: 0.0190
INFO - 2023-02-06 02:57:02 --> Config Class Initialized
INFO - 2023-02-06 02:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:02 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:02 --> URI Class Initialized
INFO - 2023-02-06 02:57:02 --> Router Class Initialized
INFO - 2023-02-06 02:57:02 --> Output Class Initialized
INFO - 2023-02-06 02:57:02 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:02 --> Input Class Initialized
INFO - 2023-02-06 02:57:02 --> Language Class Initialized
INFO - 2023-02-06 02:57:02 --> Loader Class Initialized
INFO - 2023-02-06 02:57:02 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:02 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:02 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:02 --> Total execution time: 0.0197
INFO - 2023-02-06 02:57:02 --> Config Class Initialized
INFO - 2023-02-06 02:57:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:02 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:02 --> URI Class Initialized
INFO - 2023-02-06 02:57:02 --> Router Class Initialized
INFO - 2023-02-06 02:57:02 --> Output Class Initialized
INFO - 2023-02-06 02:57:02 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:02 --> Input Class Initialized
INFO - 2023-02-06 02:57:02 --> Language Class Initialized
INFO - 2023-02-06 02:57:02 --> Loader Class Initialized
INFO - 2023-02-06 02:57:02 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:02 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:02 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:02 --> Total execution time: 0.0126
INFO - 2023-02-06 02:57:03 --> Config Class Initialized
INFO - 2023-02-06 02:57:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:03 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:03 --> URI Class Initialized
INFO - 2023-02-06 02:57:03 --> Router Class Initialized
INFO - 2023-02-06 02:57:03 --> Output Class Initialized
INFO - 2023-02-06 02:57:03 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:03 --> Input Class Initialized
INFO - 2023-02-06 02:57:03 --> Language Class Initialized
INFO - 2023-02-06 02:57:03 --> Loader Class Initialized
INFO - 2023-02-06 02:57:03 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:03 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:03 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:03 --> Total execution time: 0.0446
INFO - 2023-02-06 02:57:03 --> Config Class Initialized
INFO - 2023-02-06 02:57:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:03 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:03 --> URI Class Initialized
INFO - 2023-02-06 02:57:03 --> Router Class Initialized
INFO - 2023-02-06 02:57:03 --> Output Class Initialized
INFO - 2023-02-06 02:57:03 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:03 --> Input Class Initialized
INFO - 2023-02-06 02:57:03 --> Language Class Initialized
INFO - 2023-02-06 02:57:03 --> Loader Class Initialized
INFO - 2023-02-06 02:57:03 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:03 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:03 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:03 --> Total execution time: 0.0287
INFO - 2023-02-06 02:57:03 --> Config Class Initialized
INFO - 2023-02-06 02:57:03 --> Hooks Class Initialized
INFO - 2023-02-06 02:57:03 --> Config Class Initialized
DEBUG - 2023-02-06 02:57:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:03 --> Hooks Class Initialized
INFO - 2023-02-06 02:57:03 --> Utf8 Class Initialized
DEBUG - 2023-02-06 02:57:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:04 --> URI Class Initialized
INFO - 2023-02-06 02:57:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:04 --> Router Class Initialized
INFO - 2023-02-06 02:57:04 --> URI Class Initialized
INFO - 2023-02-06 02:57:04 --> Output Class Initialized
INFO - 2023-02-06 02:57:04 --> Router Class Initialized
INFO - 2023-02-06 02:57:04 --> Security Class Initialized
INFO - 2023-02-06 02:57:04 --> Output Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:04 --> Security Class Initialized
INFO - 2023-02-06 02:57:04 --> Input Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:04 --> Language Class Initialized
INFO - 2023-02-06 02:57:04 --> Input Class Initialized
INFO - 2023-02-06 02:57:04 --> Language Class Initialized
INFO - 2023-02-06 02:57:04 --> Loader Class Initialized
INFO - 2023-02-06 02:57:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:04 --> Loader Class Initialized
INFO - 2023-02-06 02:57:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:04 --> Total execution time: 0.0225
INFO - 2023-02-06 02:57:04 --> Config Class Initialized
INFO - 2023-02-06 02:57:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:04 --> URI Class Initialized
INFO - 2023-02-06 02:57:04 --> Router Class Initialized
INFO - 2023-02-06 02:57:04 --> Output Class Initialized
INFO - 2023-02-06 02:57:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:04 --> Input Class Initialized
INFO - 2023-02-06 02:57:04 --> Language Class Initialized
INFO - 2023-02-06 02:57:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:04 --> Loader Class Initialized
INFO - 2023-02-06 02:57:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:04 --> Total execution time: 0.0314
INFO - 2023-02-06 02:57:04 --> Config Class Initialized
INFO - 2023-02-06 02:57:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:04 --> URI Class Initialized
INFO - 2023-02-06 02:57:04 --> Router Class Initialized
INFO - 2023-02-06 02:57:04 --> Output Class Initialized
INFO - 2023-02-06 02:57:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:04 --> Input Class Initialized
INFO - 2023-02-06 02:57:04 --> Language Class Initialized
INFO - 2023-02-06 02:57:04 --> Loader Class Initialized
INFO - 2023-02-06 02:57:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:04 --> Model "Login_model" initialized
INFO - 2023-02-06 02:57:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:04 --> Final output sent to browser
INFO - 2023-02-06 02:57:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:04 --> Total execution time: 0.0226
DEBUG - 2023-02-06 02:57:04 --> Total execution time: 0.0141
INFO - 2023-02-06 02:57:05 --> Config Class Initialized
INFO - 2023-02-06 02:57:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:05 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:05 --> URI Class Initialized
INFO - 2023-02-06 02:57:05 --> Router Class Initialized
INFO - 2023-02-06 02:57:05 --> Output Class Initialized
INFO - 2023-02-06 02:57:05 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:05 --> Input Class Initialized
INFO - 2023-02-06 02:57:05 --> Language Class Initialized
INFO - 2023-02-06 02:57:05 --> Loader Class Initialized
INFO - 2023-02-06 02:57:05 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:05 --> Model "Login_model" initialized
INFO - 2023-02-06 02:57:05 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:05 --> Total execution time: 0.0417
INFO - 2023-02-06 02:57:05 --> Config Class Initialized
INFO - 2023-02-06 02:57:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:05 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:05 --> URI Class Initialized
INFO - 2023-02-06 02:57:05 --> Router Class Initialized
INFO - 2023-02-06 02:57:05 --> Output Class Initialized
INFO - 2023-02-06 02:57:05 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:05 --> Input Class Initialized
INFO - 2023-02-06 02:57:05 --> Language Class Initialized
INFO - 2023-02-06 02:57:05 --> Loader Class Initialized
INFO - 2023-02-06 02:57:05 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:05 --> Model "Login_model" initialized
INFO - 2023-02-06 02:57:05 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:05 --> Total execution time: 0.0351
INFO - 2023-02-06 02:57:14 --> Config Class Initialized
INFO - 2023-02-06 02:57:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:14 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:14 --> URI Class Initialized
INFO - 2023-02-06 02:57:14 --> Router Class Initialized
INFO - 2023-02-06 02:57:14 --> Output Class Initialized
INFO - 2023-02-06 02:57:14 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:14 --> Input Class Initialized
INFO - 2023-02-06 02:57:14 --> Language Class Initialized
INFO - 2023-02-06 02:57:14 --> Loader Class Initialized
INFO - 2023-02-06 02:57:14 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:14 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:14 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:14 --> Model "Login_model" initialized
INFO - 2023-02-06 02:57:14 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:14 --> Total execution time: 0.0386
INFO - 2023-02-06 02:57:14 --> Config Class Initialized
INFO - 2023-02-06 02:57:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:14 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:14 --> URI Class Initialized
INFO - 2023-02-06 02:57:14 --> Router Class Initialized
INFO - 2023-02-06 02:57:14 --> Output Class Initialized
INFO - 2023-02-06 02:57:14 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:14 --> Input Class Initialized
INFO - 2023-02-06 02:57:14 --> Language Class Initialized
INFO - 2023-02-06 02:57:14 --> Loader Class Initialized
INFO - 2023-02-06 02:57:14 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:14 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:14 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:14 --> Model "Login_model" initialized
INFO - 2023-02-06 02:57:14 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:14 --> Total execution time: 0.0390
INFO - 2023-02-06 02:57:21 --> Config Class Initialized
INFO - 2023-02-06 02:57:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:21 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:21 --> URI Class Initialized
INFO - 2023-02-06 02:57:21 --> Router Class Initialized
INFO - 2023-02-06 02:57:21 --> Output Class Initialized
INFO - 2023-02-06 02:57:21 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:21 --> Input Class Initialized
INFO - 2023-02-06 02:57:21 --> Language Class Initialized
INFO - 2023-02-06 02:57:21 --> Loader Class Initialized
INFO - 2023-02-06 02:57:21 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:21 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:21 --> Total execution time: 0.0042
INFO - 2023-02-06 02:57:21 --> Config Class Initialized
INFO - 2023-02-06 02:57:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:21 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:21 --> URI Class Initialized
INFO - 2023-02-06 02:57:21 --> Router Class Initialized
INFO - 2023-02-06 02:57:21 --> Output Class Initialized
INFO - 2023-02-06 02:57:21 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:21 --> Input Class Initialized
INFO - 2023-02-06 02:57:21 --> Language Class Initialized
INFO - 2023-02-06 02:57:21 --> Loader Class Initialized
INFO - 2023-02-06 02:57:21 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:21 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:21 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:21 --> Total execution time: 0.0132
INFO - 2023-02-06 02:57:26 --> Config Class Initialized
INFO - 2023-02-06 02:57:26 --> Config Class Initialized
INFO - 2023-02-06 02:57:26 --> Hooks Class Initialized
INFO - 2023-02-06 02:57:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 02:57:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:26 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:26 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:26 --> URI Class Initialized
INFO - 2023-02-06 02:57:26 --> URI Class Initialized
INFO - 2023-02-06 02:57:26 --> Router Class Initialized
INFO - 2023-02-06 02:57:26 --> Router Class Initialized
INFO - 2023-02-06 02:57:26 --> Output Class Initialized
INFO - 2023-02-06 02:57:26 --> Output Class Initialized
INFO - 2023-02-06 02:57:26 --> Security Class Initialized
INFO - 2023-02-06 02:57:26 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:26 --> Input Class Initialized
INFO - 2023-02-06 02:57:26 --> Input Class Initialized
INFO - 2023-02-06 02:57:26 --> Language Class Initialized
INFO - 2023-02-06 02:57:26 --> Language Class Initialized
INFO - 2023-02-06 02:57:26 --> Loader Class Initialized
INFO - 2023-02-06 02:57:26 --> Loader Class Initialized
INFO - 2023-02-06 02:57:26 --> Controller Class Initialized
INFO - 2023-02-06 02:57:26 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 02:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:26 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:26 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:26 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:26 --> Total execution time: 0.0173
INFO - 2023-02-06 02:57:26 --> Config Class Initialized
INFO - 2023-02-06 02:57:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:26 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:26 --> URI Class Initialized
INFO - 2023-02-06 02:57:26 --> Router Class Initialized
INFO - 2023-02-06 02:57:26 --> Output Class Initialized
INFO - 2023-02-06 02:57:26 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:26 --> Input Class Initialized
INFO - 2023-02-06 02:57:26 --> Language Class Initialized
INFO - 2023-02-06 02:57:26 --> Loader Class Initialized
INFO - 2023-02-06 02:57:26 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:26 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:26 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:26 --> Total execution time: 0.0115
INFO - 2023-02-06 02:57:26 --> Config Class Initialized
INFO - 2023-02-06 02:57:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:26 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:26 --> URI Class Initialized
INFO - 2023-02-06 02:57:26 --> Router Class Initialized
INFO - 2023-02-06 02:57:26 --> Output Class Initialized
INFO - 2023-02-06 02:57:26 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:26 --> Input Class Initialized
INFO - 2023-02-06 02:57:26 --> Language Class Initialized
INFO - 2023-02-06 02:57:26 --> Loader Class Initialized
INFO - 2023-02-06 02:57:26 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:26 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:27 --> Config Class Initialized
INFO - 2023-02-06 02:57:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:27 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:27 --> URI Class Initialized
INFO - 2023-02-06 02:57:27 --> Router Class Initialized
INFO - 2023-02-06 02:57:27 --> Output Class Initialized
INFO - 2023-02-06 02:57:27 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:27 --> Input Class Initialized
INFO - 2023-02-06 02:57:27 --> Language Class Initialized
INFO - 2023-02-06 02:57:27 --> Loader Class Initialized
INFO - 2023-02-06 02:57:27 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:27 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:27 --> Config Class Initialized
INFO - 2023-02-06 02:57:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:27 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:27 --> URI Class Initialized
INFO - 2023-02-06 02:57:27 --> Router Class Initialized
INFO - 2023-02-06 02:57:27 --> Output Class Initialized
INFO - 2023-02-06 02:57:27 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:27 --> Input Class Initialized
INFO - 2023-02-06 02:57:27 --> Language Class Initialized
INFO - 2023-02-06 02:57:27 --> Loader Class Initialized
INFO - 2023-02-06 02:57:27 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:27 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:29 --> Config Class Initialized
INFO - 2023-02-06 02:57:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:29 --> URI Class Initialized
INFO - 2023-02-06 02:57:29 --> Router Class Initialized
INFO - 2023-02-06 02:57:29 --> Output Class Initialized
INFO - 2023-02-06 02:57:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:29 --> Input Class Initialized
INFO - 2023-02-06 02:57:29 --> Language Class Initialized
INFO - 2023-02-06 02:57:29 --> Loader Class Initialized
INFO - 2023-02-06 02:57:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:29 --> Total execution time: 0.0134
INFO - 2023-02-06 02:57:29 --> Config Class Initialized
INFO - 2023-02-06 02:57:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:29 --> URI Class Initialized
INFO - 2023-02-06 02:57:29 --> Router Class Initialized
INFO - 2023-02-06 02:57:29 --> Output Class Initialized
INFO - 2023-02-06 02:57:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:29 --> Input Class Initialized
INFO - 2023-02-06 02:57:29 --> Language Class Initialized
INFO - 2023-02-06 02:57:29 --> Loader Class Initialized
INFO - 2023-02-06 02:57:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:29 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:29 --> Total execution time: 0.0107
INFO - 2023-02-06 02:57:29 --> Config Class Initialized
INFO - 2023-02-06 02:57:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:29 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:29 --> URI Class Initialized
INFO - 2023-02-06 02:57:29 --> Router Class Initialized
INFO - 2023-02-06 02:57:29 --> Output Class Initialized
INFO - 2023-02-06 02:57:29 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:29 --> Input Class Initialized
INFO - 2023-02-06 02:57:29 --> Language Class Initialized
INFO - 2023-02-06 02:57:29 --> Loader Class Initialized
INFO - 2023-02-06 02:57:29 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:29 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:30 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:30 --> Total execution time: 0.0371
INFO - 2023-02-06 02:57:30 --> Config Class Initialized
INFO - 2023-02-06 02:57:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:30 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:30 --> URI Class Initialized
INFO - 2023-02-06 02:57:30 --> Router Class Initialized
INFO - 2023-02-06 02:57:30 --> Output Class Initialized
INFO - 2023-02-06 02:57:30 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:30 --> Input Class Initialized
INFO - 2023-02-06 02:57:30 --> Language Class Initialized
INFO - 2023-02-06 02:57:30 --> Loader Class Initialized
INFO - 2023-02-06 02:57:30 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:30 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:30 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:30 --> Total execution time: 0.0291
INFO - 2023-02-06 02:57:44 --> Config Class Initialized
INFO - 2023-02-06 02:57:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:44 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:44 --> URI Class Initialized
INFO - 2023-02-06 02:57:44 --> Router Class Initialized
INFO - 2023-02-06 02:57:44 --> Output Class Initialized
INFO - 2023-02-06 02:57:44 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:44 --> Input Class Initialized
INFO - 2023-02-06 02:57:44 --> Language Class Initialized
INFO - 2023-02-06 02:57:44 --> Loader Class Initialized
INFO - 2023-02-06 02:57:44 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:44 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:44 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:44 --> Total execution time: 0.0129
INFO - 2023-02-06 02:57:44 --> Config Class Initialized
INFO - 2023-02-06 02:57:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:44 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:44 --> URI Class Initialized
INFO - 2023-02-06 02:57:44 --> Router Class Initialized
INFO - 2023-02-06 02:57:44 --> Output Class Initialized
INFO - 2023-02-06 02:57:44 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:44 --> Input Class Initialized
INFO - 2023-02-06 02:57:44 --> Language Class Initialized
INFO - 2023-02-06 02:57:44 --> Loader Class Initialized
INFO - 2023-02-06 02:57:44 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:44 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:44 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:44 --> Total execution time: 0.0099
INFO - 2023-02-06 02:57:47 --> Config Class Initialized
INFO - 2023-02-06 02:57:47 --> Config Class Initialized
INFO - 2023-02-06 02:57:47 --> Hooks Class Initialized
INFO - 2023-02-06 02:57:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 02:57:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:47 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:47 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:47 --> URI Class Initialized
INFO - 2023-02-06 02:57:47 --> URI Class Initialized
INFO - 2023-02-06 02:57:47 --> Router Class Initialized
INFO - 2023-02-06 02:57:47 --> Router Class Initialized
INFO - 2023-02-06 02:57:47 --> Output Class Initialized
INFO - 2023-02-06 02:57:47 --> Output Class Initialized
INFO - 2023-02-06 02:57:47 --> Security Class Initialized
INFO - 2023-02-06 02:57:47 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:47 --> Input Class Initialized
INFO - 2023-02-06 02:57:47 --> Input Class Initialized
INFO - 2023-02-06 02:57:47 --> Language Class Initialized
INFO - 2023-02-06 02:57:47 --> Language Class Initialized
INFO - 2023-02-06 02:57:47 --> Loader Class Initialized
INFO - 2023-02-06 02:57:47 --> Loader Class Initialized
INFO - 2023-02-06 02:57:47 --> Controller Class Initialized
INFO - 2023-02-06 02:57:47 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 02:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:47 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:47 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:47 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:47 --> Total execution time: 0.0161
INFO - 2023-02-06 02:57:47 --> Config Class Initialized
INFO - 2023-02-06 02:57:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:47 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:47 --> URI Class Initialized
INFO - 2023-02-06 02:57:47 --> Router Class Initialized
INFO - 2023-02-06 02:57:47 --> Output Class Initialized
INFO - 2023-02-06 02:57:47 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:47 --> Input Class Initialized
INFO - 2023-02-06 02:57:47 --> Language Class Initialized
INFO - 2023-02-06 02:57:47 --> Loader Class Initialized
INFO - 2023-02-06 02:57:47 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:47 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:47 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:47 --> Total execution time: 0.0103
INFO - 2023-02-06 02:57:48 --> Config Class Initialized
INFO - 2023-02-06 02:57:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:48 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:48 --> URI Class Initialized
INFO - 2023-02-06 02:57:48 --> Router Class Initialized
INFO - 2023-02-06 02:57:48 --> Output Class Initialized
INFO - 2023-02-06 02:57:48 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:48 --> Input Class Initialized
INFO - 2023-02-06 02:57:48 --> Language Class Initialized
INFO - 2023-02-06 02:57:48 --> Loader Class Initialized
INFO - 2023-02-06 02:57:48 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:48 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:49 --> Config Class Initialized
INFO - 2023-02-06 02:57:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:49 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:49 --> URI Class Initialized
INFO - 2023-02-06 02:57:49 --> Router Class Initialized
INFO - 2023-02-06 02:57:49 --> Output Class Initialized
INFO - 2023-02-06 02:57:49 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:49 --> Input Class Initialized
INFO - 2023-02-06 02:57:49 --> Language Class Initialized
INFO - 2023-02-06 02:57:49 --> Loader Class Initialized
INFO - 2023-02-06 02:57:49 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:49 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:49 --> Config Class Initialized
INFO - 2023-02-06 02:57:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:49 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:49 --> URI Class Initialized
INFO - 2023-02-06 02:57:49 --> Router Class Initialized
INFO - 2023-02-06 02:57:49 --> Output Class Initialized
INFO - 2023-02-06 02:57:49 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:49 --> Input Class Initialized
INFO - 2023-02-06 02:57:49 --> Language Class Initialized
INFO - 2023-02-06 02:57:49 --> Loader Class Initialized
INFO - 2023-02-06 02:57:49 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:49 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:50 --> Config Class Initialized
INFO - 2023-02-06 02:57:50 --> Config Class Initialized
INFO - 2023-02-06 02:57:50 --> Hooks Class Initialized
INFO - 2023-02-06 02:57:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:57:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 02:57:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:57:50 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:50 --> Utf8 Class Initialized
INFO - 2023-02-06 02:57:50 --> URI Class Initialized
INFO - 2023-02-06 02:57:50 --> URI Class Initialized
INFO - 2023-02-06 02:57:50 --> Router Class Initialized
INFO - 2023-02-06 02:57:50 --> Router Class Initialized
INFO - 2023-02-06 02:57:50 --> Output Class Initialized
INFO - 2023-02-06 02:57:50 --> Output Class Initialized
INFO - 2023-02-06 02:57:50 --> Security Class Initialized
INFO - 2023-02-06 02:57:50 --> Security Class Initialized
DEBUG - 2023-02-06 02:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:57:50 --> Input Class Initialized
INFO - 2023-02-06 02:57:50 --> Input Class Initialized
INFO - 2023-02-06 02:57:50 --> Language Class Initialized
INFO - 2023-02-06 02:57:50 --> Language Class Initialized
INFO - 2023-02-06 02:57:50 --> Loader Class Initialized
INFO - 2023-02-06 02:57:50 --> Loader Class Initialized
INFO - 2023-02-06 02:57:50 --> Controller Class Initialized
INFO - 2023-02-06 02:57:50 --> Controller Class Initialized
DEBUG - 2023-02-06 02:57:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 02:57:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:57:50 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:50 --> Database Driver Class Initialized
INFO - 2023-02-06 02:57:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:57:50 --> Final output sent to browser
DEBUG - 2023-02-06 02:57:50 --> Total execution time: 0.0153
INFO - 2023-02-06 02:58:01 --> Config Class Initialized
INFO - 2023-02-06 02:58:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:01 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:01 --> URI Class Initialized
INFO - 2023-02-06 02:58:01 --> Router Class Initialized
INFO - 2023-02-06 02:58:01 --> Output Class Initialized
INFO - 2023-02-06 02:58:01 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:01 --> Input Class Initialized
INFO - 2023-02-06 02:58:01 --> Language Class Initialized
INFO - 2023-02-06 02:58:01 --> Loader Class Initialized
INFO - 2023-02-06 02:58:01 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:01 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:01 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:01 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:01 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:01 --> Total execution time: 0.0402
INFO - 2023-02-06 02:58:01 --> Config Class Initialized
INFO - 2023-02-06 02:58:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:01 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:01 --> URI Class Initialized
INFO - 2023-02-06 02:58:01 --> Router Class Initialized
INFO - 2023-02-06 02:58:01 --> Output Class Initialized
INFO - 2023-02-06 02:58:01 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:01 --> Input Class Initialized
INFO - 2023-02-06 02:58:01 --> Language Class Initialized
INFO - 2023-02-06 02:58:01 --> Loader Class Initialized
INFO - 2023-02-06 02:58:01 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:01 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:01 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:01 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:01 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:01 --> Total execution time: 0.0400
INFO - 2023-02-06 02:58:02 --> Config Class Initialized
INFO - 2023-02-06 02:58:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:02 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:02 --> URI Class Initialized
INFO - 2023-02-06 02:58:02 --> Router Class Initialized
INFO - 2023-02-06 02:58:02 --> Output Class Initialized
INFO - 2023-02-06 02:58:02 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:02 --> Input Class Initialized
INFO - 2023-02-06 02:58:02 --> Language Class Initialized
INFO - 2023-02-06 02:58:02 --> Loader Class Initialized
INFO - 2023-02-06 02:58:02 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:02 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:02 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:02 --> Total execution time: 0.0170
INFO - 2023-02-06 02:58:02 --> Config Class Initialized
INFO - 2023-02-06 02:58:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:02 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:02 --> URI Class Initialized
INFO - 2023-02-06 02:58:02 --> Router Class Initialized
INFO - 2023-02-06 02:58:02 --> Output Class Initialized
INFO - 2023-02-06 02:58:02 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:02 --> Input Class Initialized
INFO - 2023-02-06 02:58:02 --> Language Class Initialized
INFO - 2023-02-06 02:58:02 --> Loader Class Initialized
INFO - 2023-02-06 02:58:02 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:02 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:02 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:02 --> Total execution time: 0.0126
INFO - 2023-02-06 02:58:04 --> Config Class Initialized
INFO - 2023-02-06 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:04 --> URI Class Initialized
INFO - 2023-02-06 02:58:04 --> Router Class Initialized
INFO - 2023-02-06 02:58:04 --> Output Class Initialized
INFO - 2023-02-06 02:58:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:04 --> Input Class Initialized
INFO - 2023-02-06 02:58:04 --> Language Class Initialized
INFO - 2023-02-06 02:58:04 --> Loader Class Initialized
INFO - 2023-02-06 02:58:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:04 --> Total execution time: 0.0035
INFO - 2023-02-06 02:58:04 --> Config Class Initialized
INFO - 2023-02-06 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:04 --> URI Class Initialized
INFO - 2023-02-06 02:58:04 --> Router Class Initialized
INFO - 2023-02-06 02:58:04 --> Output Class Initialized
INFO - 2023-02-06 02:58:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:04 --> Input Class Initialized
INFO - 2023-02-06 02:58:04 --> Language Class Initialized
INFO - 2023-02-06 02:58:04 --> Loader Class Initialized
INFO - 2023-02-06 02:58:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:04 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:04 --> Total execution time: 0.0216
INFO - 2023-02-06 02:58:04 --> Config Class Initialized
INFO - 2023-02-06 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:04 --> URI Class Initialized
INFO - 2023-02-06 02:58:04 --> Router Class Initialized
INFO - 2023-02-06 02:58:04 --> Output Class Initialized
INFO - 2023-02-06 02:58:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:04 --> Input Class Initialized
INFO - 2023-02-06 02:58:04 --> Language Class Initialized
INFO - 2023-02-06 02:58:04 --> Loader Class Initialized
INFO - 2023-02-06 02:58:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:04 --> Total execution time: 0.0423
INFO - 2023-02-06 02:58:04 --> Config Class Initialized
INFO - 2023-02-06 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:04 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:04 --> URI Class Initialized
INFO - 2023-02-06 02:58:04 --> Router Class Initialized
INFO - 2023-02-06 02:58:04 --> Output Class Initialized
INFO - 2023-02-06 02:58:04 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:04 --> Input Class Initialized
INFO - 2023-02-06 02:58:04 --> Language Class Initialized
INFO - 2023-02-06 02:58:04 --> Loader Class Initialized
INFO - 2023-02-06 02:58:04 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:04 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:04 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:04 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:04 --> Total execution time: 0.0233
INFO - 2023-02-06 02:58:05 --> Config Class Initialized
INFO - 2023-02-06 02:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:05 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:05 --> URI Class Initialized
INFO - 2023-02-06 02:58:05 --> Router Class Initialized
INFO - 2023-02-06 02:58:05 --> Output Class Initialized
INFO - 2023-02-06 02:58:05 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:05 --> Input Class Initialized
INFO - 2023-02-06 02:58:05 --> Language Class Initialized
INFO - 2023-02-06 02:58:05 --> Loader Class Initialized
INFO - 2023-02-06 02:58:05 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:05 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:05 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:05 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:05 --> Total execution time: 0.0575
INFO - 2023-02-06 02:58:07 --> Config Class Initialized
INFO - 2023-02-06 02:58:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:07 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:07 --> URI Class Initialized
INFO - 2023-02-06 02:58:07 --> Router Class Initialized
INFO - 2023-02-06 02:58:07 --> Output Class Initialized
INFO - 2023-02-06 02:58:07 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:07 --> Input Class Initialized
INFO - 2023-02-06 02:58:07 --> Language Class Initialized
INFO - 2023-02-06 02:58:07 --> Loader Class Initialized
INFO - 2023-02-06 02:58:07 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:07 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:07 --> Total execution time: 0.0036
INFO - 2023-02-06 02:58:07 --> Config Class Initialized
INFO - 2023-02-06 02:58:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:07 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:07 --> URI Class Initialized
INFO - 2023-02-06 02:58:07 --> Router Class Initialized
INFO - 2023-02-06 02:58:07 --> Output Class Initialized
INFO - 2023-02-06 02:58:07 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:07 --> Input Class Initialized
INFO - 2023-02-06 02:58:07 --> Language Class Initialized
INFO - 2023-02-06 02:58:07 --> Loader Class Initialized
INFO - 2023-02-06 02:58:07 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:07 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:07 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:07 --> Total execution time: 0.0113
INFO - 2023-02-06 02:58:08 --> Config Class Initialized
INFO - 2023-02-06 02:58:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:08 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:08 --> URI Class Initialized
INFO - 2023-02-06 02:58:08 --> Router Class Initialized
INFO - 2023-02-06 02:58:08 --> Output Class Initialized
INFO - 2023-02-06 02:58:08 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:08 --> Input Class Initialized
INFO - 2023-02-06 02:58:08 --> Language Class Initialized
INFO - 2023-02-06 02:58:08 --> Loader Class Initialized
INFO - 2023-02-06 02:58:08 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:08 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:08 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:08 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:08 --> Total execution time: 0.0210
INFO - 2023-02-06 02:58:08 --> Config Class Initialized
INFO - 2023-02-06 02:58:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:08 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:08 --> URI Class Initialized
INFO - 2023-02-06 02:58:08 --> Router Class Initialized
INFO - 2023-02-06 02:58:08 --> Output Class Initialized
INFO - 2023-02-06 02:58:08 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:08 --> Input Class Initialized
INFO - 2023-02-06 02:58:08 --> Language Class Initialized
INFO - 2023-02-06 02:58:08 --> Loader Class Initialized
INFO - 2023-02-06 02:58:08 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:08 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:08 --> Model "Cluster_model" initialized
INFO - 2023-02-06 02:58:08 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:08 --> Total execution time: 0.0167
INFO - 2023-02-06 02:58:09 --> Config Class Initialized
INFO - 2023-02-06 02:58:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:09 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:09 --> URI Class Initialized
INFO - 2023-02-06 02:58:09 --> Router Class Initialized
INFO - 2023-02-06 02:58:09 --> Output Class Initialized
INFO - 2023-02-06 02:58:09 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:09 --> Input Class Initialized
INFO - 2023-02-06 02:58:09 --> Language Class Initialized
INFO - 2023-02-06 02:58:09 --> Loader Class Initialized
INFO - 2023-02-06 02:58:09 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:09 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:09 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:09 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:09 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:09 --> Total execution time: 0.0240
INFO - 2023-02-06 02:58:09 --> Config Class Initialized
INFO - 2023-02-06 02:58:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 02:58:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 02:58:09 --> Utf8 Class Initialized
INFO - 2023-02-06 02:58:09 --> URI Class Initialized
INFO - 2023-02-06 02:58:09 --> Router Class Initialized
INFO - 2023-02-06 02:58:09 --> Output Class Initialized
INFO - 2023-02-06 02:58:09 --> Security Class Initialized
DEBUG - 2023-02-06 02:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 02:58:09 --> Input Class Initialized
INFO - 2023-02-06 02:58:09 --> Language Class Initialized
INFO - 2023-02-06 02:58:09 --> Loader Class Initialized
INFO - 2023-02-06 02:58:09 --> Controller Class Initialized
DEBUG - 2023-02-06 02:58:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 02:58:09 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:09 --> Database Driver Class Initialized
INFO - 2023-02-06 02:58:09 --> Model "Login_model" initialized
INFO - 2023-02-06 02:58:09 --> Final output sent to browser
DEBUG - 2023-02-06 02:58:09 --> Total execution time: 0.0183
INFO - 2023-02-06 03:01:59 --> Config Class Initialized
INFO - 2023-02-06 03:01:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:01:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:01:59 --> Utf8 Class Initialized
INFO - 2023-02-06 03:01:59 --> URI Class Initialized
INFO - 2023-02-06 03:01:59 --> Router Class Initialized
INFO - 2023-02-06 03:01:59 --> Output Class Initialized
INFO - 2023-02-06 03:01:59 --> Security Class Initialized
DEBUG - 2023-02-06 03:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:01:59 --> Input Class Initialized
INFO - 2023-02-06 03:01:59 --> Language Class Initialized
INFO - 2023-02-06 03:01:59 --> Loader Class Initialized
INFO - 2023-02-06 03:01:59 --> Controller Class Initialized
DEBUG - 2023-02-06 03:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:01:59 --> Database Driver Class Initialized
INFO - 2023-02-06 03:01:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 03:01:59 --> Database Driver Class Initialized
INFO - 2023-02-06 03:01:59 --> Model "Login_model" initialized
INFO - 2023-02-06 03:01:59 --> Final output sent to browser
DEBUG - 2023-02-06 03:01:59 --> Total execution time: 0.3977
INFO - 2023-02-06 03:01:59 --> Config Class Initialized
INFO - 2023-02-06 03:01:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:01:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:01:59 --> Utf8 Class Initialized
INFO - 2023-02-06 03:01:59 --> URI Class Initialized
INFO - 2023-02-06 03:01:59 --> Router Class Initialized
INFO - 2023-02-06 03:01:59 --> Output Class Initialized
INFO - 2023-02-06 03:01:59 --> Security Class Initialized
DEBUG - 2023-02-06 03:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:01:59 --> Input Class Initialized
INFO - 2023-02-06 03:01:59 --> Language Class Initialized
INFO - 2023-02-06 03:01:59 --> Loader Class Initialized
INFO - 2023-02-06 03:01:59 --> Controller Class Initialized
DEBUG - 2023-02-06 03:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:01:59 --> Database Driver Class Initialized
INFO - 2023-02-06 03:01:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 03:01:59 --> Database Driver Class Initialized
INFO - 2023-02-06 03:01:59 --> Model "Login_model" initialized
INFO - 2023-02-06 03:02:00 --> Final output sent to browser
DEBUG - 2023-02-06 03:02:00 --> Total execution time: 0.3896
INFO - 2023-02-06 03:10:12 --> Config Class Initialized
INFO - 2023-02-06 03:10:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:10:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:10:12 --> Utf8 Class Initialized
INFO - 2023-02-06 03:10:12 --> URI Class Initialized
INFO - 2023-02-06 03:10:12 --> Router Class Initialized
INFO - 2023-02-06 03:10:12 --> Output Class Initialized
INFO - 2023-02-06 03:10:12 --> Security Class Initialized
DEBUG - 2023-02-06 03:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:10:12 --> Input Class Initialized
INFO - 2023-02-06 03:10:12 --> Language Class Initialized
INFO - 2023-02-06 03:10:12 --> Loader Class Initialized
INFO - 2023-02-06 03:10:12 --> Controller Class Initialized
DEBUG - 2023-02-06 03:10:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:10:12 --> Database Driver Class Initialized
INFO - 2023-02-06 03:10:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 03:10:12 --> Database Driver Class Initialized
INFO - 2023-02-06 03:10:12 --> Model "Login_model" initialized
INFO - 2023-02-06 03:10:13 --> Final output sent to browser
DEBUG - 2023-02-06 03:10:13 --> Total execution time: 0.4856
INFO - 2023-02-06 03:10:13 --> Config Class Initialized
INFO - 2023-02-06 03:10:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:10:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:10:13 --> Utf8 Class Initialized
INFO - 2023-02-06 03:10:13 --> URI Class Initialized
INFO - 2023-02-06 03:10:13 --> Router Class Initialized
INFO - 2023-02-06 03:10:13 --> Output Class Initialized
INFO - 2023-02-06 03:10:13 --> Security Class Initialized
DEBUG - 2023-02-06 03:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:10:13 --> Input Class Initialized
INFO - 2023-02-06 03:10:13 --> Language Class Initialized
INFO - 2023-02-06 03:10:13 --> Loader Class Initialized
INFO - 2023-02-06 03:10:13 --> Controller Class Initialized
DEBUG - 2023-02-06 03:10:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:10:13 --> Database Driver Class Initialized
INFO - 2023-02-06 03:10:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 03:10:13 --> Database Driver Class Initialized
INFO - 2023-02-06 03:10:13 --> Model "Login_model" initialized
INFO - 2023-02-06 03:10:13 --> Final output sent to browser
DEBUG - 2023-02-06 03:10:13 --> Total execution time: 0.4243
INFO - 2023-02-06 03:36:55 --> Config Class Initialized
INFO - 2023-02-06 03:36:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:36:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:36:55 --> Utf8 Class Initialized
INFO - 2023-02-06 03:36:55 --> URI Class Initialized
INFO - 2023-02-06 03:36:55 --> Router Class Initialized
INFO - 2023-02-06 03:36:55 --> Output Class Initialized
INFO - 2023-02-06 03:36:55 --> Security Class Initialized
DEBUG - 2023-02-06 03:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:36:55 --> Input Class Initialized
INFO - 2023-02-06 03:36:55 --> Language Class Initialized
INFO - 2023-02-06 03:36:55 --> Loader Class Initialized
INFO - 2023-02-06 03:36:55 --> Controller Class Initialized
DEBUG - 2023-02-06 03:36:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:36:55 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:36:55 --> Unable to connect to the database
INFO - 2023-02-06 03:36:55 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:36:55 --> Unable to connect to the database
INFO - 2023-02-06 03:36:55 --> Model "Login_model" initialized
ERROR - 2023-02-06 03:36:55 --> Unable to connect to the database
ERROR - 2023-02-06 03:36:55 --> Query error: Connection refused - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time from kunlun_user  where id is not null  order by id desc limit 10 offset 0
ERROR - 2023-02-06 03:36:55 --> Unable to connect to the database
ERROR - 2023-02-06 03:36:55 --> Query error: Connection refused - Invalid query: select count(id) as count from kunlun_user 
INFO - 2023-02-06 03:36:55 --> Final output sent to browser
DEBUG - 2023-02-06 03:36:55 --> Total execution time: 0.0131
INFO - 2023-02-06 03:36:55 --> Config Class Initialized
INFO - 2023-02-06 03:36:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:36:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:36:56 --> Utf8 Class Initialized
INFO - 2023-02-06 03:36:56 --> URI Class Initialized
INFO - 2023-02-06 03:36:56 --> Router Class Initialized
INFO - 2023-02-06 03:36:56 --> Output Class Initialized
INFO - 2023-02-06 03:36:56 --> Security Class Initialized
DEBUG - 2023-02-06 03:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:36:56 --> Input Class Initialized
INFO - 2023-02-06 03:36:56 --> Language Class Initialized
INFO - 2023-02-06 03:36:56 --> Loader Class Initialized
INFO - 2023-02-06 03:36:56 --> Controller Class Initialized
DEBUG - 2023-02-06 03:36:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:36:56 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:36:56 --> Unable to connect to the database
INFO - 2023-02-06 03:36:56 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:36:56 --> Unable to connect to the database
INFO - 2023-02-06 03:36:56 --> Model "Login_model" initialized
ERROR - 2023-02-06 03:36:56 --> Unable to connect to the database
ERROR - 2023-02-06 03:36:56 --> Query error: Connection refused - Invalid query: select id, name as username,email,phone_number,wechat_number,update_time from kunlun_user  where id is not null  order by id desc limit 10 offset 0
ERROR - 2023-02-06 03:36:56 --> Unable to connect to the database
ERROR - 2023-02-06 03:36:56 --> Query error: Connection refused - Invalid query: select count(id) as count from kunlun_user 
INFO - 2023-02-06 03:36:56 --> Final output sent to browser
DEBUG - 2023-02-06 03:36:56 --> Total execution time: 0.0521
INFO - 2023-02-06 03:36:56 --> Config Class Initialized
INFO - 2023-02-06 03:36:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:36:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:36:56 --> Utf8 Class Initialized
INFO - 2023-02-06 03:36:56 --> URI Class Initialized
INFO - 2023-02-06 03:36:56 --> Router Class Initialized
INFO - 2023-02-06 03:36:56 --> Output Class Initialized
INFO - 2023-02-06 03:36:56 --> Security Class Initialized
DEBUG - 2023-02-06 03:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:36:56 --> Input Class Initialized
INFO - 2023-02-06 03:36:56 --> Language Class Initialized
INFO - 2023-02-06 03:36:56 --> Loader Class Initialized
INFO - 2023-02-06 03:36:56 --> Controller Class Initialized
DEBUG - 2023-02-06 03:36:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:36:56 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:36:56 --> Unable to connect to the database
INFO - 2023-02-06 03:36:56 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-06 03:37:02 --> Config Class Initialized
INFO - 2023-02-06 03:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:02 --> Utf8 Class Initialized
INFO - 2023-02-06 03:37:02 --> URI Class Initialized
INFO - 2023-02-06 03:37:02 --> Router Class Initialized
INFO - 2023-02-06 03:37:02 --> Output Class Initialized
INFO - 2023-02-06 03:37:02 --> Security Class Initialized
DEBUG - 2023-02-06 03:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:37:02 --> Input Class Initialized
INFO - 2023-02-06 03:37:02 --> Language Class Initialized
INFO - 2023-02-06 03:37:02 --> Loader Class Initialized
INFO - 2023-02-06 03:37:02 --> Controller Class Initialized
DEBUG - 2023-02-06 03:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:37:02 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:37:02 --> Unable to connect to the database
INFO - 2023-02-06 03:37:02 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-06 03:37:06 --> Config Class Initialized
INFO - 2023-02-06 03:37:06 --> Config Class Initialized
INFO - 2023-02-06 03:37:06 --> Hooks Class Initialized
INFO - 2023-02-06 03:37:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:37:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:07 --> Utf8 Class Initialized
DEBUG - 2023-02-06 03:37:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:07 --> URI Class Initialized
INFO - 2023-02-06 03:37:07 --> Utf8 Class Initialized
INFO - 2023-02-06 03:37:07 --> URI Class Initialized
INFO - 2023-02-06 03:37:07 --> Router Class Initialized
INFO - 2023-02-06 03:37:07 --> Router Class Initialized
INFO - 2023-02-06 03:37:07 --> Output Class Initialized
INFO - 2023-02-06 03:37:07 --> Output Class Initialized
INFO - 2023-02-06 03:37:07 --> Security Class Initialized
INFO - 2023-02-06 03:37:07 --> Security Class Initialized
DEBUG - 2023-02-06 03:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 03:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:37:07 --> Input Class Initialized
INFO - 2023-02-06 03:37:07 --> Input Class Initialized
INFO - 2023-02-06 03:37:07 --> Language Class Initialized
INFO - 2023-02-06 03:37:07 --> Language Class Initialized
INFO - 2023-02-06 03:37:07 --> Loader Class Initialized
INFO - 2023-02-06 03:37:07 --> Loader Class Initialized
INFO - 2023-02-06 03:37:07 --> Controller Class Initialized
INFO - 2023-02-06 03:37:07 --> Controller Class Initialized
DEBUG - 2023-02-06 03:37:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 03:37:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:37:07 --> Final output sent to browser
DEBUG - 2023-02-06 03:37:07 --> Total execution time: 0.0045
INFO - 2023-02-06 03:37:07 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:37:07 --> Unable to connect to the database
INFO - 2023-02-06 03:37:07 --> Config Class Initialized
INFO - 2023-02-06 03:37:07 --> Hooks Class Initialized
INFO - 2023-02-06 03:37:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2023-02-06 03:37:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:07 --> Utf8 Class Initialized
INFO - 2023-02-06 03:37:07 --> URI Class Initialized
INFO - 2023-02-06 03:37:07 --> Router Class Initialized
INFO - 2023-02-06 03:37:07 --> Output Class Initialized
INFO - 2023-02-06 03:37:07 --> Security Class Initialized
DEBUG - 2023-02-06 03:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:37:07 --> Input Class Initialized
INFO - 2023-02-06 03:37:07 --> Language Class Initialized
INFO - 2023-02-06 03:37:07 --> Loader Class Initialized
INFO - 2023-02-06 03:37:07 --> Controller Class Initialized
DEBUG - 2023-02-06 03:37:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:37:07 --> Database Driver Class Initialized
ERROR - 2023-02-06 03:37:07 --> Unable to connect to the database
INFO - 2023-02-06 03:37:07 --> Model "Login_model" initialized
ERROR - 2023-02-06 03:37:07 --> Unable to connect to the database
ERROR - 2023-02-06 03:37:07 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-02-06 03:37:07 --> Final output sent to browser
DEBUG - 2023-02-06 03:37:07 --> Total execution time: 0.0486
INFO - 2023-02-06 03:37:17 --> Config Class Initialized
INFO - 2023-02-06 03:37:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:37:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:17 --> Utf8 Class Initialized
INFO - 2023-02-06 03:37:17 --> URI Class Initialized
INFO - 2023-02-06 03:37:17 --> Router Class Initialized
INFO - 2023-02-06 03:37:17 --> Output Class Initialized
INFO - 2023-02-06 03:37:17 --> Security Class Initialized
DEBUG - 2023-02-06 03:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:37:17 --> Input Class Initialized
INFO - 2023-02-06 03:37:17 --> Language Class Initialized
INFO - 2023-02-06 03:37:17 --> Loader Class Initialized
INFO - 2023-02-06 03:37:17 --> Controller Class Initialized
INFO - 2023-02-06 03:37:17 --> Helper loaded: form_helper
INFO - 2023-02-06 03:37:17 --> Helper loaded: url_helper
DEBUG - 2023-02-06 03:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:37:17 --> Model "Change_model" initialized
INFO - 2023-02-06 03:37:17 --> Final output sent to browser
DEBUG - 2023-02-06 03:37:17 --> Total execution time: 0.0126
INFO - 2023-02-06 03:37:33 --> Config Class Initialized
INFO - 2023-02-06 03:37:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 03:37:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 03:37:33 --> Utf8 Class Initialized
INFO - 2023-02-06 03:37:33 --> URI Class Initialized
INFO - 2023-02-06 03:37:33 --> Router Class Initialized
INFO - 2023-02-06 03:37:33 --> Output Class Initialized
INFO - 2023-02-06 03:37:33 --> Security Class Initialized
DEBUG - 2023-02-06 03:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 03:37:33 --> Input Class Initialized
INFO - 2023-02-06 03:37:33 --> Language Class Initialized
INFO - 2023-02-06 03:37:33 --> Loader Class Initialized
INFO - 2023-02-06 03:37:33 --> Controller Class Initialized
INFO - 2023-02-06 03:37:33 --> Helper loaded: form_helper
INFO - 2023-02-06 03:37:33 --> Helper loaded: url_helper
DEBUG - 2023-02-06 03:37:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 03:37:33 --> Model "Change_model" initialized
INFO - 2023-02-06 03:37:33 --> Final output sent to browser
DEBUG - 2023-02-06 03:37:33 --> Total execution time: 0.0101
INFO - 2023-02-06 05:44:50 --> Config Class Initialized
INFO - 2023-02-06 05:44:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:44:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:44:50 --> Utf8 Class Initialized
INFO - 2023-02-06 05:44:50 --> URI Class Initialized
INFO - 2023-02-06 05:44:50 --> Router Class Initialized
INFO - 2023-02-06 05:44:50 --> Output Class Initialized
INFO - 2023-02-06 05:44:50 --> Security Class Initialized
DEBUG - 2023-02-06 05:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:44:50 --> Input Class Initialized
INFO - 2023-02-06 05:44:50 --> Language Class Initialized
INFO - 2023-02-06 05:44:50 --> Loader Class Initialized
INFO - 2023-02-06 05:44:50 --> Controller Class Initialized
INFO - 2023-02-06 05:44:50 --> Helper loaded: form_helper
INFO - 2023-02-06 05:44:50 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:44:50 --> Model "Change_model" initialized
INFO - 2023-02-06 05:44:50 --> Model "Grafana_model" initialized
INFO - 2023-02-06 05:44:50 --> Final output sent to browser
DEBUG - 2023-02-06 05:44:50 --> Total execution time: 0.0251
INFO - 2023-02-06 05:44:50 --> Config Class Initialized
INFO - 2023-02-06 05:44:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:44:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:44:50 --> Utf8 Class Initialized
INFO - 2023-02-06 05:44:50 --> URI Class Initialized
INFO - 2023-02-06 05:44:50 --> Router Class Initialized
INFO - 2023-02-06 05:44:50 --> Output Class Initialized
INFO - 2023-02-06 05:44:50 --> Security Class Initialized
DEBUG - 2023-02-06 05:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:44:50 --> Input Class Initialized
INFO - 2023-02-06 05:44:50 --> Language Class Initialized
INFO - 2023-02-06 05:44:50 --> Loader Class Initialized
INFO - 2023-02-06 05:44:50 --> Controller Class Initialized
INFO - 2023-02-06 05:44:50 --> Helper loaded: form_helper
INFO - 2023-02-06 05:44:50 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:44:50 --> Final output sent to browser
DEBUG - 2023-02-06 05:44:50 --> Total execution time: 0.0469
INFO - 2023-02-06 05:44:50 --> Config Class Initialized
INFO - 2023-02-06 05:44:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:44:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:44:50 --> Utf8 Class Initialized
INFO - 2023-02-06 05:44:50 --> URI Class Initialized
INFO - 2023-02-06 05:44:50 --> Router Class Initialized
INFO - 2023-02-06 05:44:50 --> Output Class Initialized
INFO - 2023-02-06 05:44:50 --> Security Class Initialized
DEBUG - 2023-02-06 05:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:44:50 --> Input Class Initialized
INFO - 2023-02-06 05:44:50 --> Language Class Initialized
INFO - 2023-02-06 05:44:50 --> Loader Class Initialized
INFO - 2023-02-06 05:44:50 --> Controller Class Initialized
INFO - 2023-02-06 05:44:50 --> Helper loaded: form_helper
INFO - 2023-02-06 05:44:50 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:44:50 --> Database Driver Class Initialized
INFO - 2023-02-06 05:44:50 --> Model "Login_model" initialized
INFO - 2023-02-06 05:44:50 --> Final output sent to browser
DEBUG - 2023-02-06 05:44:50 --> Total execution time: 0.0116
INFO - 2023-02-06 05:45:00 --> Config Class Initialized
INFO - 2023-02-06 05:45:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:00 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:00 --> URI Class Initialized
INFO - 2023-02-06 05:45:00 --> Router Class Initialized
INFO - 2023-02-06 05:45:00 --> Output Class Initialized
INFO - 2023-02-06 05:45:00 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:00 --> Input Class Initialized
INFO - 2023-02-06 05:45:00 --> Language Class Initialized
INFO - 2023-02-06 05:45:00 --> Loader Class Initialized
INFO - 2023-02-06 05:45:00 --> Controller Class Initialized
INFO - 2023-02-06 05:45:00 --> Helper loaded: form_helper
INFO - 2023-02-06 05:45:00 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:45:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:00 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:00 --> Total execution time: 0.0046
INFO - 2023-02-06 05:45:00 --> Config Class Initialized
INFO - 2023-02-06 05:45:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:00 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:00 --> URI Class Initialized
INFO - 2023-02-06 05:45:00 --> Router Class Initialized
INFO - 2023-02-06 05:45:00 --> Output Class Initialized
INFO - 2023-02-06 05:45:00 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:00 --> Input Class Initialized
INFO - 2023-02-06 05:45:00 --> Language Class Initialized
INFO - 2023-02-06 05:45:00 --> Loader Class Initialized
INFO - 2023-02-06 05:45:00 --> Controller Class Initialized
INFO - 2023-02-06 05:45:00 --> Helper loaded: form_helper
INFO - 2023-02-06 05:45:00 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:45:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:00 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:00 --> Model "Login_model" initialized
INFO - 2023-02-06 05:45:00 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:00 --> Total execution time: 0.0182
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
INFO - 2023-02-06 05:45:11 --> Helper loaded: form_helper
INFO - 2023-02-06 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Model "Change_model" initialized
INFO - 2023-02-06 05:45:11 --> Model "Grafana_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0298
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
INFO - 2023-02-06 05:45:11 --> Helper loaded: form_helper
INFO - 2023-02-06 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0019
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
INFO - 2023-02-06 05:45:11 --> Helper loaded: form_helper
INFO - 2023-02-06 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:11 --> Model "Login_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0172
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0129
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0112
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0526
INFO - 2023-02-06 05:45:11 --> Config Class Initialized
INFO - 2023-02-06 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:11 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:11 --> URI Class Initialized
INFO - 2023-02-06 05:45:11 --> Router Class Initialized
INFO - 2023-02-06 05:45:11 --> Output Class Initialized
INFO - 2023-02-06 05:45:11 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:11 --> Input Class Initialized
INFO - 2023-02-06 05:45:11 --> Language Class Initialized
INFO - 2023-02-06 05:45:11 --> Loader Class Initialized
INFO - 2023-02-06 05:45:11 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:11 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:11 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:11 --> Total execution time: 0.0525
INFO - 2023-02-06 05:45:16 --> Config Class Initialized
INFO - 2023-02-06 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:16 --> URI Class Initialized
INFO - 2023-02-06 05:45:16 --> Router Class Initialized
INFO - 2023-02-06 05:45:16 --> Output Class Initialized
INFO - 2023-02-06 05:45:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:16 --> Input Class Initialized
INFO - 2023-02-06 05:45:16 --> Language Class Initialized
INFO - 2023-02-06 05:45:16 --> Loader Class Initialized
INFO - 2023-02-06 05:45:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:16 --> Total execution time: 0.0042
INFO - 2023-02-06 05:45:16 --> Config Class Initialized
INFO - 2023-02-06 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:16 --> URI Class Initialized
INFO - 2023-02-06 05:45:16 --> Router Class Initialized
INFO - 2023-02-06 05:45:16 --> Output Class Initialized
INFO - 2023-02-06 05:45:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:16 --> Input Class Initialized
INFO - 2023-02-06 05:45:16 --> Language Class Initialized
INFO - 2023-02-06 05:45:16 --> Loader Class Initialized
INFO - 2023-02-06 05:45:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:16 --> Model "Login_model" initialized
INFO - 2023-02-06 05:45:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:16 --> Total execution time: 0.0201
INFO - 2023-02-06 05:45:16 --> Config Class Initialized
INFO - 2023-02-06 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:16 --> URI Class Initialized
INFO - 2023-02-06 05:45:16 --> Router Class Initialized
INFO - 2023-02-06 05:45:16 --> Output Class Initialized
INFO - 2023-02-06 05:45:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:16 --> Input Class Initialized
INFO - 2023-02-06 05:45:16 --> Language Class Initialized
INFO - 2023-02-06 05:45:16 --> Loader Class Initialized
INFO - 2023-02-06 05:45:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:16 --> Total execution time: 0.0167
INFO - 2023-02-06 05:45:16 --> Config Class Initialized
INFO - 2023-02-06 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:16 --> URI Class Initialized
INFO - 2023-02-06 05:45:16 --> Router Class Initialized
INFO - 2023-02-06 05:45:16 --> Output Class Initialized
INFO - 2023-02-06 05:45:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:16 --> Input Class Initialized
INFO - 2023-02-06 05:45:16 --> Language Class Initialized
INFO - 2023-02-06 05:45:16 --> Loader Class Initialized
INFO - 2023-02-06 05:45:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:16 --> Total execution time: 0.0524
INFO - 2023-02-06 05:45:17 --> Config Class Initialized
INFO - 2023-02-06 05:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:17 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:17 --> URI Class Initialized
INFO - 2023-02-06 05:45:17 --> Router Class Initialized
INFO - 2023-02-06 05:45:17 --> Output Class Initialized
INFO - 2023-02-06 05:45:17 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:17 --> Input Class Initialized
INFO - 2023-02-06 05:45:17 --> Language Class Initialized
INFO - 2023-02-06 05:45:17 --> Loader Class Initialized
INFO - 2023-02-06 05:45:17 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:17 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:17 --> Total execution time: 0.0040
INFO - 2023-02-06 05:45:17 --> Config Class Initialized
INFO - 2023-02-06 05:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:17 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:17 --> URI Class Initialized
INFO - 2023-02-06 05:45:17 --> Router Class Initialized
INFO - 2023-02-06 05:45:17 --> Output Class Initialized
INFO - 2023-02-06 05:45:17 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:17 --> Input Class Initialized
INFO - 2023-02-06 05:45:17 --> Language Class Initialized
INFO - 2023-02-06 05:45:17 --> Loader Class Initialized
INFO - 2023-02-06 05:45:17 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:17 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:17 --> Model "Login_model" initialized
INFO - 2023-02-06 05:45:17 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:17 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:17 --> Total execution time: 0.0224
INFO - 2023-02-06 05:45:18 --> Config Class Initialized
INFO - 2023-02-06 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:18 --> URI Class Initialized
INFO - 2023-02-06 05:45:18 --> Router Class Initialized
INFO - 2023-02-06 05:45:18 --> Output Class Initialized
INFO - 2023-02-06 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:18 --> Input Class Initialized
INFO - 2023-02-06 05:45:18 --> Language Class Initialized
INFO - 2023-02-06 05:45:18 --> Loader Class Initialized
INFO - 2023-02-06 05:45:18 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:18 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:18 --> Total execution time: 0.0162
INFO - 2023-02-06 05:45:18 --> Config Class Initialized
INFO - 2023-02-06 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:18 --> URI Class Initialized
INFO - 2023-02-06 05:45:18 --> Router Class Initialized
INFO - 2023-02-06 05:45:18 --> Output Class Initialized
INFO - 2023-02-06 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:18 --> Input Class Initialized
INFO - 2023-02-06 05:45:18 --> Language Class Initialized
INFO - 2023-02-06 05:45:18 --> Loader Class Initialized
INFO - 2023-02-06 05:45:18 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:18 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:18 --> Total execution time: 0.0114
INFO - 2023-02-06 05:45:19 --> Config Class Initialized
INFO - 2023-02-06 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:19 --> URI Class Initialized
INFO - 2023-02-06 05:45:19 --> Router Class Initialized
INFO - 2023-02-06 05:45:19 --> Output Class Initialized
INFO - 2023-02-06 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:19 --> Input Class Initialized
INFO - 2023-02-06 05:45:19 --> Language Class Initialized
INFO - 2023-02-06 05:45:19 --> Loader Class Initialized
INFO - 2023-02-06 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:19 --> Total execution time: 0.0036
INFO - 2023-02-06 05:45:19 --> Config Class Initialized
INFO - 2023-02-06 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:19 --> URI Class Initialized
INFO - 2023-02-06 05:45:19 --> Router Class Initialized
INFO - 2023-02-06 05:45:19 --> Output Class Initialized
INFO - 2023-02-06 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:19 --> Input Class Initialized
INFO - 2023-02-06 05:45:19 --> Language Class Initialized
INFO - 2023-02-06 05:45:19 --> Loader Class Initialized
INFO - 2023-02-06 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:19 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:19 --> Total execution time: 0.0142
INFO - 2023-02-06 05:45:19 --> Config Class Initialized
INFO - 2023-02-06 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:19 --> URI Class Initialized
INFO - 2023-02-06 05:45:19 --> Router Class Initialized
INFO - 2023-02-06 05:45:19 --> Output Class Initialized
INFO - 2023-02-06 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:19 --> Input Class Initialized
INFO - 2023-02-06 05:45:19 --> Language Class Initialized
INFO - 2023-02-06 05:45:19 --> Loader Class Initialized
INFO - 2023-02-06 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:19 --> Total execution time: 0.0426
INFO - 2023-02-06 05:45:19 --> Config Class Initialized
INFO - 2023-02-06 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:19 --> URI Class Initialized
INFO - 2023-02-06 05:45:19 --> Router Class Initialized
INFO - 2023-02-06 05:45:19 --> Output Class Initialized
INFO - 2023-02-06 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:19 --> Input Class Initialized
INFO - 2023-02-06 05:45:19 --> Language Class Initialized
INFO - 2023-02-06 05:45:19 --> Loader Class Initialized
INFO - 2023-02-06 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:19 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:19 --> Total execution time: 0.0104
INFO - 2023-02-06 05:45:31 --> Config Class Initialized
INFO - 2023-02-06 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:31 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:31 --> URI Class Initialized
INFO - 2023-02-06 05:45:31 --> Router Class Initialized
INFO - 2023-02-06 05:45:31 --> Output Class Initialized
INFO - 2023-02-06 05:45:31 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:31 --> Input Class Initialized
INFO - 2023-02-06 05:45:31 --> Language Class Initialized
INFO - 2023-02-06 05:45:31 --> Loader Class Initialized
INFO - 2023-02-06 05:45:31 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:31 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:31 --> Total execution time: 0.0045
INFO - 2023-02-06 05:45:31 --> Config Class Initialized
INFO - 2023-02-06 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:31 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:31 --> URI Class Initialized
INFO - 2023-02-06 05:45:31 --> Router Class Initialized
INFO - 2023-02-06 05:45:31 --> Output Class Initialized
INFO - 2023-02-06 05:45:31 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:31 --> Input Class Initialized
INFO - 2023-02-06 05:45:31 --> Language Class Initialized
INFO - 2023-02-06 05:45:31 --> Loader Class Initialized
INFO - 2023-02-06 05:45:31 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:31 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:31 --> Model "Login_model" initialized
INFO - 2023-02-06 05:45:31 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:31 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:31 --> Total execution time: 0.0309
INFO - 2023-02-06 05:45:31 --> Config Class Initialized
INFO - 2023-02-06 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:31 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:31 --> URI Class Initialized
INFO - 2023-02-06 05:45:31 --> Router Class Initialized
INFO - 2023-02-06 05:45:31 --> Output Class Initialized
INFO - 2023-02-06 05:45:31 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:31 --> Input Class Initialized
INFO - 2023-02-06 05:45:31 --> Language Class Initialized
INFO - 2023-02-06 05:45:31 --> Loader Class Initialized
INFO - 2023-02-06 05:45:31 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:31 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:31 --> Total execution time: 0.0042
INFO - 2023-02-06 05:45:31 --> Config Class Initialized
INFO - 2023-02-06 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:31 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:31 --> URI Class Initialized
INFO - 2023-02-06 05:45:31 --> Router Class Initialized
INFO - 2023-02-06 05:45:31 --> Output Class Initialized
INFO - 2023-02-06 05:45:31 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:31 --> Input Class Initialized
INFO - 2023-02-06 05:45:31 --> Language Class Initialized
INFO - 2023-02-06 05:45:31 --> Loader Class Initialized
INFO - 2023-02-06 05:45:31 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:31 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:31 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:31 --> Total execution time: 0.1491
INFO - 2023-02-06 05:45:36 --> Config Class Initialized
INFO - 2023-02-06 05:45:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:36 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:36 --> URI Class Initialized
INFO - 2023-02-06 05:45:36 --> Router Class Initialized
INFO - 2023-02-06 05:45:36 --> Output Class Initialized
INFO - 2023-02-06 05:45:36 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:36 --> Input Class Initialized
INFO - 2023-02-06 05:45:36 --> Language Class Initialized
INFO - 2023-02-06 05:45:36 --> Loader Class Initialized
INFO - 2023-02-06 05:45:36 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:36 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:36 --> Total execution time: 0.0043
INFO - 2023-02-06 05:45:36 --> Config Class Initialized
INFO - 2023-02-06 05:45:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:36 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:36 --> URI Class Initialized
INFO - 2023-02-06 05:45:36 --> Router Class Initialized
INFO - 2023-02-06 05:45:36 --> Output Class Initialized
INFO - 2023-02-06 05:45:36 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:36 --> Input Class Initialized
INFO - 2023-02-06 05:45:36 --> Language Class Initialized
INFO - 2023-02-06 05:45:36 --> Loader Class Initialized
INFO - 2023-02-06 05:45:36 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:36 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:36 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:36 --> Total execution time: 0.0175
INFO - 2023-02-06 05:45:41 --> Config Class Initialized
INFO - 2023-02-06 05:45:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:41 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:41 --> URI Class Initialized
INFO - 2023-02-06 05:45:41 --> Router Class Initialized
INFO - 2023-02-06 05:45:41 --> Output Class Initialized
INFO - 2023-02-06 05:45:41 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:41 --> Input Class Initialized
INFO - 2023-02-06 05:45:41 --> Language Class Initialized
INFO - 2023-02-06 05:45:41 --> Loader Class Initialized
INFO - 2023-02-06 05:45:41 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:41 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:41 --> Total execution time: 0.0049
INFO - 2023-02-06 05:45:41 --> Config Class Initialized
INFO - 2023-02-06 05:45:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:41 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:41 --> URI Class Initialized
INFO - 2023-02-06 05:45:41 --> Router Class Initialized
INFO - 2023-02-06 05:45:41 --> Output Class Initialized
INFO - 2023-02-06 05:45:41 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:41 --> Input Class Initialized
INFO - 2023-02-06 05:45:41 --> Language Class Initialized
INFO - 2023-02-06 05:45:41 --> Loader Class Initialized
INFO - 2023-02-06 05:45:41 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:41 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:41 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:41 --> Total execution time: 0.0150
INFO - 2023-02-06 05:45:59 --> Config Class Initialized
INFO - 2023-02-06 05:45:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:59 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:59 --> URI Class Initialized
INFO - 2023-02-06 05:45:59 --> Router Class Initialized
INFO - 2023-02-06 05:45:59 --> Output Class Initialized
INFO - 2023-02-06 05:45:59 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:59 --> Input Class Initialized
INFO - 2023-02-06 05:45:59 --> Language Class Initialized
INFO - 2023-02-06 05:45:59 --> Loader Class Initialized
INFO - 2023-02-06 05:45:59 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:59 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:59 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:59 --> Total execution time: 0.0125
INFO - 2023-02-06 05:45:59 --> Config Class Initialized
INFO - 2023-02-06 05:45:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:45:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:45:59 --> Utf8 Class Initialized
INFO - 2023-02-06 05:45:59 --> URI Class Initialized
INFO - 2023-02-06 05:45:59 --> Router Class Initialized
INFO - 2023-02-06 05:45:59 --> Output Class Initialized
INFO - 2023-02-06 05:45:59 --> Security Class Initialized
DEBUG - 2023-02-06 05:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:45:59 --> Input Class Initialized
INFO - 2023-02-06 05:45:59 --> Language Class Initialized
INFO - 2023-02-06 05:45:59 --> Loader Class Initialized
INFO - 2023-02-06 05:45:59 --> Controller Class Initialized
DEBUG - 2023-02-06 05:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:45:59 --> Database Driver Class Initialized
INFO - 2023-02-06 05:45:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:45:59 --> Final output sent to browser
DEBUG - 2023-02-06 05:45:59 --> Total execution time: 0.0121
INFO - 2023-02-06 05:46:03 --> Config Class Initialized
INFO - 2023-02-06 05:46:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:03 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:03 --> URI Class Initialized
INFO - 2023-02-06 05:46:03 --> Router Class Initialized
INFO - 2023-02-06 05:46:03 --> Output Class Initialized
INFO - 2023-02-06 05:46:03 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:03 --> Input Class Initialized
INFO - 2023-02-06 05:46:03 --> Language Class Initialized
INFO - 2023-02-06 05:46:03 --> Loader Class Initialized
INFO - 2023-02-06 05:46:03 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:03 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:03 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:03 --> Total execution time: 0.0196
INFO - 2023-02-06 05:46:03 --> Config Class Initialized
INFO - 2023-02-06 05:46:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:03 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:03 --> URI Class Initialized
INFO - 2023-02-06 05:46:03 --> Router Class Initialized
INFO - 2023-02-06 05:46:03 --> Output Class Initialized
INFO - 2023-02-06 05:46:03 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:03 --> Input Class Initialized
INFO - 2023-02-06 05:46:03 --> Language Class Initialized
INFO - 2023-02-06 05:46:03 --> Loader Class Initialized
INFO - 2023-02-06 05:46:03 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:03 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:03 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:03 --> Total execution time: 0.0142
INFO - 2023-02-06 05:46:10 --> Config Class Initialized
INFO - 2023-02-06 05:46:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:10 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:10 --> URI Class Initialized
INFO - 2023-02-06 05:46:10 --> Router Class Initialized
INFO - 2023-02-06 05:46:10 --> Output Class Initialized
INFO - 2023-02-06 05:46:10 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:10 --> Input Class Initialized
INFO - 2023-02-06 05:46:10 --> Language Class Initialized
INFO - 2023-02-06 05:46:10 --> Loader Class Initialized
INFO - 2023-02-06 05:46:10 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:10 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:10 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:10 --> Total execution time: 0.1005
INFO - 2023-02-06 05:46:10 --> Config Class Initialized
INFO - 2023-02-06 05:46:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:10 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:10 --> URI Class Initialized
INFO - 2023-02-06 05:46:10 --> Router Class Initialized
INFO - 2023-02-06 05:46:10 --> Output Class Initialized
INFO - 2023-02-06 05:46:10 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:10 --> Input Class Initialized
INFO - 2023-02-06 05:46:10 --> Language Class Initialized
INFO - 2023-02-06 05:46:10 --> Loader Class Initialized
INFO - 2023-02-06 05:46:10 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:10 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:10 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:10 --> Total execution time: 0.0204
INFO - 2023-02-06 05:46:14 --> Config Class Initialized
INFO - 2023-02-06 05:46:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:14 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:14 --> URI Class Initialized
INFO - 2023-02-06 05:46:14 --> Router Class Initialized
INFO - 2023-02-06 05:46:14 --> Output Class Initialized
INFO - 2023-02-06 05:46:14 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:14 --> Input Class Initialized
INFO - 2023-02-06 05:46:14 --> Language Class Initialized
INFO - 2023-02-06 05:46:14 --> Loader Class Initialized
INFO - 2023-02-06 05:46:14 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:14 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:14 --> Total execution time: 0.0051
INFO - 2023-02-06 05:46:14 --> Config Class Initialized
INFO - 2023-02-06 05:46:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:14 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:14 --> URI Class Initialized
INFO - 2023-02-06 05:46:14 --> Router Class Initialized
INFO - 2023-02-06 05:46:14 --> Output Class Initialized
INFO - 2023-02-06 05:46:14 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:14 --> Input Class Initialized
INFO - 2023-02-06 05:46:14 --> Language Class Initialized
INFO - 2023-02-06 05:46:14 --> Loader Class Initialized
INFO - 2023-02-06 05:46:14 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:14 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:14 --> Model "Login_model" initialized
INFO - 2023-02-06 05:46:14 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:14 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:14 --> Total execution time: 0.0212
INFO - 2023-02-06 05:46:14 --> Config Class Initialized
INFO - 2023-02-06 05:46:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:14 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:14 --> URI Class Initialized
INFO - 2023-02-06 05:46:14 --> Router Class Initialized
INFO - 2023-02-06 05:46:14 --> Output Class Initialized
INFO - 2023-02-06 05:46:14 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:14 --> Input Class Initialized
INFO - 2023-02-06 05:46:14 --> Language Class Initialized
INFO - 2023-02-06 05:46:14 --> Loader Class Initialized
INFO - 2023-02-06 05:46:14 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:14 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:14 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:14 --> Total execution time: 0.0257
INFO - 2023-02-06 05:46:14 --> Config Class Initialized
INFO - 2023-02-06 05:46:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:14 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:14 --> URI Class Initialized
INFO - 2023-02-06 05:46:14 --> Router Class Initialized
INFO - 2023-02-06 05:46:14 --> Output Class Initialized
INFO - 2023-02-06 05:46:14 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:14 --> Input Class Initialized
INFO - 2023-02-06 05:46:14 --> Language Class Initialized
INFO - 2023-02-06 05:46:14 --> Loader Class Initialized
INFO - 2023-02-06 05:46:14 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:14 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:14 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:14 --> Total execution time: 0.0170
INFO - 2023-02-06 05:46:16 --> Config Class Initialized
INFO - 2023-02-06 05:46:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:16 --> URI Class Initialized
INFO - 2023-02-06 05:46:16 --> Router Class Initialized
INFO - 2023-02-06 05:46:16 --> Output Class Initialized
INFO - 2023-02-06 05:46:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:16 --> Input Class Initialized
INFO - 2023-02-06 05:46:16 --> Language Class Initialized
INFO - 2023-02-06 05:46:16 --> Loader Class Initialized
INFO - 2023-02-06 05:46:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:16 --> Total execution time: 0.0037
INFO - 2023-02-06 05:46:16 --> Config Class Initialized
INFO - 2023-02-06 05:46:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:16 --> URI Class Initialized
INFO - 2023-02-06 05:46:16 --> Router Class Initialized
INFO - 2023-02-06 05:46:16 --> Output Class Initialized
INFO - 2023-02-06 05:46:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:16 --> Input Class Initialized
INFO - 2023-02-06 05:46:16 --> Language Class Initialized
INFO - 2023-02-06 05:46:16 --> Loader Class Initialized
INFO - 2023-02-06 05:46:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:16 --> Model "Login_model" initialized
INFO - 2023-02-06 05:46:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:16 --> Total execution time: 0.0230
INFO - 2023-02-06 05:46:16 --> Config Class Initialized
INFO - 2023-02-06 05:46:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:16 --> URI Class Initialized
INFO - 2023-02-06 05:46:16 --> Router Class Initialized
INFO - 2023-02-06 05:46:16 --> Output Class Initialized
INFO - 2023-02-06 05:46:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:16 --> Input Class Initialized
INFO - 2023-02-06 05:46:16 --> Language Class Initialized
INFO - 2023-02-06 05:46:16 --> Loader Class Initialized
INFO - 2023-02-06 05:46:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:16 --> Total execution time: 0.0234
INFO - 2023-02-06 05:46:16 --> Config Class Initialized
INFO - 2023-02-06 05:46:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:16 --> URI Class Initialized
INFO - 2023-02-06 05:46:16 --> Router Class Initialized
INFO - 2023-02-06 05:46:16 --> Output Class Initialized
INFO - 2023-02-06 05:46:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:16 --> Input Class Initialized
INFO - 2023-02-06 05:46:16 --> Language Class Initialized
INFO - 2023-02-06 05:46:16 --> Loader Class Initialized
INFO - 2023-02-06 05:46:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:16 --> Total execution time: 0.0176
INFO - 2023-02-06 05:46:22 --> Config Class Initialized
INFO - 2023-02-06 05:46:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:22 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:22 --> URI Class Initialized
INFO - 2023-02-06 05:46:22 --> Router Class Initialized
INFO - 2023-02-06 05:46:22 --> Output Class Initialized
INFO - 2023-02-06 05:46:22 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:22 --> Input Class Initialized
INFO - 2023-02-06 05:46:22 --> Language Class Initialized
INFO - 2023-02-06 05:46:22 --> Loader Class Initialized
INFO - 2023-02-06 05:46:22 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:22 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:22 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:22 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:22 --> Total execution time: 0.0650
INFO - 2023-02-06 05:46:22 --> Config Class Initialized
INFO - 2023-02-06 05:46:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:22 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:22 --> URI Class Initialized
INFO - 2023-02-06 05:46:22 --> Router Class Initialized
INFO - 2023-02-06 05:46:22 --> Output Class Initialized
INFO - 2023-02-06 05:46:22 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:22 --> Input Class Initialized
INFO - 2023-02-06 05:46:22 --> Language Class Initialized
INFO - 2023-02-06 05:46:22 --> Loader Class Initialized
INFO - 2023-02-06 05:46:22 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:22 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:22 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:22 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:22 --> Total execution time: 0.0150
INFO - 2023-02-06 05:46:23 --> Config Class Initialized
INFO - 2023-02-06 05:46:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:23 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:23 --> URI Class Initialized
INFO - 2023-02-06 05:46:23 --> Router Class Initialized
INFO - 2023-02-06 05:46:23 --> Output Class Initialized
INFO - 2023-02-06 05:46:23 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:23 --> Input Class Initialized
INFO - 2023-02-06 05:46:23 --> Language Class Initialized
INFO - 2023-02-06 05:46:23 --> Loader Class Initialized
INFO - 2023-02-06 05:46:23 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:23 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:23 --> Total execution time: 0.0038
INFO - 2023-02-06 05:46:23 --> Config Class Initialized
INFO - 2023-02-06 05:46:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:23 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:23 --> URI Class Initialized
INFO - 2023-02-06 05:46:23 --> Router Class Initialized
INFO - 2023-02-06 05:46:23 --> Output Class Initialized
INFO - 2023-02-06 05:46:23 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:23 --> Input Class Initialized
INFO - 2023-02-06 05:46:23 --> Language Class Initialized
INFO - 2023-02-06 05:46:23 --> Loader Class Initialized
INFO - 2023-02-06 05:46:23 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:23 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:23 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:23 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:23 --> Total execution time: 0.0116
INFO - 2023-02-06 05:46:23 --> Config Class Initialized
INFO - 2023-02-06 05:46:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:23 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:23 --> URI Class Initialized
INFO - 2023-02-06 05:46:23 --> Router Class Initialized
INFO - 2023-02-06 05:46:23 --> Output Class Initialized
INFO - 2023-02-06 05:46:23 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:23 --> Input Class Initialized
INFO - 2023-02-06 05:46:23 --> Language Class Initialized
INFO - 2023-02-06 05:46:23 --> Loader Class Initialized
INFO - 2023-02-06 05:46:23 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:23 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:23 --> Total execution time: 0.0417
INFO - 2023-02-06 05:46:23 --> Config Class Initialized
INFO - 2023-02-06 05:46:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:23 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:23 --> URI Class Initialized
INFO - 2023-02-06 05:46:23 --> Router Class Initialized
INFO - 2023-02-06 05:46:23 --> Output Class Initialized
INFO - 2023-02-06 05:46:23 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:23 --> Input Class Initialized
INFO - 2023-02-06 05:46:23 --> Language Class Initialized
INFO - 2023-02-06 05:46:23 --> Loader Class Initialized
INFO - 2023-02-06 05:46:23 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:23 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:23 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:23 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:23 --> Total execution time: 0.0121
INFO - 2023-02-06 05:46:38 --> Config Class Initialized
INFO - 2023-02-06 05:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:38 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:38 --> URI Class Initialized
INFO - 2023-02-06 05:46:38 --> Router Class Initialized
INFO - 2023-02-06 05:46:38 --> Output Class Initialized
INFO - 2023-02-06 05:46:38 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:38 --> Input Class Initialized
INFO - 2023-02-06 05:46:38 --> Language Class Initialized
INFO - 2023-02-06 05:46:38 --> Loader Class Initialized
INFO - 2023-02-06 05:46:38 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:38 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:38 --> Total execution time: 0.0051
INFO - 2023-02-06 05:46:38 --> Config Class Initialized
INFO - 2023-02-06 05:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:38 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:38 --> URI Class Initialized
INFO - 2023-02-06 05:46:38 --> Router Class Initialized
INFO - 2023-02-06 05:46:38 --> Output Class Initialized
INFO - 2023-02-06 05:46:38 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:38 --> Input Class Initialized
INFO - 2023-02-06 05:46:38 --> Language Class Initialized
INFO - 2023-02-06 05:46:38 --> Loader Class Initialized
INFO - 2023-02-06 05:46:38 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:38 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:38 --> Model "Login_model" initialized
INFO - 2023-02-06 05:46:38 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:38 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:38 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:38 --> Total execution time: 0.0383
INFO - 2023-02-06 05:46:38 --> Config Class Initialized
INFO - 2023-02-06 05:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:38 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:38 --> URI Class Initialized
INFO - 2023-02-06 05:46:38 --> Router Class Initialized
INFO - 2023-02-06 05:46:38 --> Output Class Initialized
INFO - 2023-02-06 05:46:38 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:38 --> Input Class Initialized
INFO - 2023-02-06 05:46:38 --> Language Class Initialized
INFO - 2023-02-06 05:46:38 --> Loader Class Initialized
INFO - 2023-02-06 05:46:38 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:38 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:38 --> Total execution time: 0.0073
INFO - 2023-02-06 05:46:38 --> Config Class Initialized
INFO - 2023-02-06 05:46:38 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:38 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:38 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:38 --> URI Class Initialized
INFO - 2023-02-06 05:46:38 --> Router Class Initialized
INFO - 2023-02-06 05:46:38 --> Output Class Initialized
INFO - 2023-02-06 05:46:38 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:38 --> Input Class Initialized
INFO - 2023-02-06 05:46:38 --> Language Class Initialized
INFO - 2023-02-06 05:46:38 --> Loader Class Initialized
INFO - 2023-02-06 05:46:38 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:38 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:38 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:39 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:39 --> Total execution time: 0.1547
INFO - 2023-02-06 05:46:43 --> Config Class Initialized
INFO - 2023-02-06 05:46:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:43 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:43 --> URI Class Initialized
INFO - 2023-02-06 05:46:43 --> Router Class Initialized
INFO - 2023-02-06 05:46:43 --> Output Class Initialized
INFO - 2023-02-06 05:46:43 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:43 --> Input Class Initialized
INFO - 2023-02-06 05:46:43 --> Language Class Initialized
INFO - 2023-02-06 05:46:43 --> Loader Class Initialized
INFO - 2023-02-06 05:46:43 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:43 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:43 --> Total execution time: 0.0038
INFO - 2023-02-06 05:46:43 --> Config Class Initialized
INFO - 2023-02-06 05:46:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:43 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:43 --> URI Class Initialized
INFO - 2023-02-06 05:46:43 --> Router Class Initialized
INFO - 2023-02-06 05:46:43 --> Output Class Initialized
INFO - 2023-02-06 05:46:43 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:43 --> Input Class Initialized
INFO - 2023-02-06 05:46:43 --> Language Class Initialized
INFO - 2023-02-06 05:46:43 --> Loader Class Initialized
INFO - 2023-02-06 05:46:43 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:43 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:43 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:43 --> Total execution time: 0.0163
INFO - 2023-02-06 05:46:48 --> Config Class Initialized
INFO - 2023-02-06 05:46:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:48 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:48 --> URI Class Initialized
INFO - 2023-02-06 05:46:48 --> Router Class Initialized
INFO - 2023-02-06 05:46:48 --> Output Class Initialized
INFO - 2023-02-06 05:46:48 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:48 --> Input Class Initialized
INFO - 2023-02-06 05:46:48 --> Language Class Initialized
INFO - 2023-02-06 05:46:48 --> Loader Class Initialized
INFO - 2023-02-06 05:46:48 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:48 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:48 --> Total execution time: 0.0040
INFO - 2023-02-06 05:46:48 --> Config Class Initialized
INFO - 2023-02-06 05:46:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:48 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:48 --> URI Class Initialized
INFO - 2023-02-06 05:46:48 --> Router Class Initialized
INFO - 2023-02-06 05:46:48 --> Output Class Initialized
INFO - 2023-02-06 05:46:48 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:48 --> Input Class Initialized
INFO - 2023-02-06 05:46:48 --> Language Class Initialized
INFO - 2023-02-06 05:46:48 --> Loader Class Initialized
INFO - 2023-02-06 05:46:48 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:48 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:48 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:48 --> Total execution time: 0.0141
INFO - 2023-02-06 05:46:53 --> Config Class Initialized
INFO - 2023-02-06 05:46:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:53 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:53 --> URI Class Initialized
INFO - 2023-02-06 05:46:53 --> Router Class Initialized
INFO - 2023-02-06 05:46:53 --> Output Class Initialized
INFO - 2023-02-06 05:46:53 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:53 --> Input Class Initialized
INFO - 2023-02-06 05:46:53 --> Language Class Initialized
INFO - 2023-02-06 05:46:53 --> Loader Class Initialized
INFO - 2023-02-06 05:46:53 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:53 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:53 --> Total execution time: 0.0049
INFO - 2023-02-06 05:46:53 --> Config Class Initialized
INFO - 2023-02-06 05:46:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:53 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:53 --> URI Class Initialized
INFO - 2023-02-06 05:46:53 --> Router Class Initialized
INFO - 2023-02-06 05:46:53 --> Output Class Initialized
INFO - 2023-02-06 05:46:53 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:53 --> Input Class Initialized
INFO - 2023-02-06 05:46:53 --> Language Class Initialized
INFO - 2023-02-06 05:46:53 --> Loader Class Initialized
INFO - 2023-02-06 05:46:53 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:53 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:53 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:53 --> Total execution time: 0.0332
INFO - 2023-02-06 05:46:58 --> Config Class Initialized
INFO - 2023-02-06 05:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:58 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:58 --> URI Class Initialized
INFO - 2023-02-06 05:46:58 --> Router Class Initialized
INFO - 2023-02-06 05:46:58 --> Output Class Initialized
INFO - 2023-02-06 05:46:58 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:58 --> Input Class Initialized
INFO - 2023-02-06 05:46:58 --> Language Class Initialized
INFO - 2023-02-06 05:46:58 --> Loader Class Initialized
INFO - 2023-02-06 05:46:58 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:58 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:58 --> Total execution time: 0.0043
INFO - 2023-02-06 05:46:58 --> Config Class Initialized
INFO - 2023-02-06 05:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:46:58 --> Utf8 Class Initialized
INFO - 2023-02-06 05:46:58 --> URI Class Initialized
INFO - 2023-02-06 05:46:58 --> Router Class Initialized
INFO - 2023-02-06 05:46:58 --> Output Class Initialized
INFO - 2023-02-06 05:46:58 --> Security Class Initialized
DEBUG - 2023-02-06 05:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:46:58 --> Input Class Initialized
INFO - 2023-02-06 05:46:58 --> Language Class Initialized
INFO - 2023-02-06 05:46:58 --> Loader Class Initialized
INFO - 2023-02-06 05:46:58 --> Controller Class Initialized
DEBUG - 2023-02-06 05:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:46:58 --> Database Driver Class Initialized
INFO - 2023-02-06 05:46:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:46:58 --> Final output sent to browser
DEBUG - 2023-02-06 05:46:58 --> Total execution time: 0.0802
INFO - 2023-02-06 05:47:01 --> Config Class Initialized
INFO - 2023-02-06 05:47:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:01 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:01 --> URI Class Initialized
INFO - 2023-02-06 05:47:01 --> Router Class Initialized
INFO - 2023-02-06 05:47:01 --> Output Class Initialized
INFO - 2023-02-06 05:47:01 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:01 --> Input Class Initialized
INFO - 2023-02-06 05:47:01 --> Language Class Initialized
INFO - 2023-02-06 05:47:01 --> Loader Class Initialized
INFO - 2023-02-06 05:47:01 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:01 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:01 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:01 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:01 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:01 --> Total execution time: 0.0560
INFO - 2023-02-06 05:47:01 --> Config Class Initialized
INFO - 2023-02-06 05:47:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:01 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:01 --> URI Class Initialized
INFO - 2023-02-06 05:47:01 --> Router Class Initialized
INFO - 2023-02-06 05:47:01 --> Output Class Initialized
INFO - 2023-02-06 05:47:01 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:01 --> Input Class Initialized
INFO - 2023-02-06 05:47:01 --> Language Class Initialized
INFO - 2023-02-06 05:47:01 --> Loader Class Initialized
INFO - 2023-02-06 05:47:01 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:02 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:02 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:02 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:02 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:02 --> Total execution time: 0.0509
INFO - 2023-02-06 05:47:06 --> Config Class Initialized
INFO - 2023-02-06 05:47:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:06 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:06 --> URI Class Initialized
INFO - 2023-02-06 05:47:06 --> Router Class Initialized
INFO - 2023-02-06 05:47:06 --> Output Class Initialized
INFO - 2023-02-06 05:47:06 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:06 --> Input Class Initialized
INFO - 2023-02-06 05:47:06 --> Language Class Initialized
INFO - 2023-02-06 05:47:06 --> Loader Class Initialized
INFO - 2023-02-06 05:47:06 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:06 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:06 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:06 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:06 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:06 --> Total execution time: 0.0893
INFO - 2023-02-06 05:47:06 --> Config Class Initialized
INFO - 2023-02-06 05:47:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:06 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:06 --> URI Class Initialized
INFO - 2023-02-06 05:47:06 --> Router Class Initialized
INFO - 2023-02-06 05:47:06 --> Output Class Initialized
INFO - 2023-02-06 05:47:06 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:06 --> Input Class Initialized
INFO - 2023-02-06 05:47:06 --> Language Class Initialized
INFO - 2023-02-06 05:47:06 --> Loader Class Initialized
INFO - 2023-02-06 05:47:06 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:06 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:06 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:07 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:07 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:07 --> Total execution time: 0.0460
INFO - 2023-02-06 05:47:15 --> Config Class Initialized
INFO - 2023-02-06 05:47:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:15 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:15 --> URI Class Initialized
INFO - 2023-02-06 05:47:15 --> Router Class Initialized
INFO - 2023-02-06 05:47:15 --> Output Class Initialized
INFO - 2023-02-06 05:47:15 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:15 --> Input Class Initialized
INFO - 2023-02-06 05:47:15 --> Language Class Initialized
INFO - 2023-02-06 05:47:15 --> Loader Class Initialized
INFO - 2023-02-06 05:47:15 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:15 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:15 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:15 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:16 --> Total execution time: 0.1841
INFO - 2023-02-06 05:47:16 --> Config Class Initialized
INFO - 2023-02-06 05:47:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:47:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:47:16 --> Utf8 Class Initialized
INFO - 2023-02-06 05:47:16 --> URI Class Initialized
INFO - 2023-02-06 05:47:16 --> Router Class Initialized
INFO - 2023-02-06 05:47:16 --> Output Class Initialized
INFO - 2023-02-06 05:47:16 --> Security Class Initialized
DEBUG - 2023-02-06 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:47:16 --> Input Class Initialized
INFO - 2023-02-06 05:47:16 --> Language Class Initialized
INFO - 2023-02-06 05:47:16 --> Loader Class Initialized
INFO - 2023-02-06 05:47:16 --> Controller Class Initialized
DEBUG - 2023-02-06 05:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:47:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:47:16 --> Database Driver Class Initialized
INFO - 2023-02-06 05:47:16 --> Model "Login_model" initialized
INFO - 2023-02-06 05:47:16 --> Final output sent to browser
DEBUG - 2023-02-06 05:47:16 --> Total execution time: 0.0723
INFO - 2023-02-06 05:49:04 --> Config Class Initialized
INFO - 2023-02-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:04 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:04 --> URI Class Initialized
INFO - 2023-02-06 05:49:04 --> Router Class Initialized
INFO - 2023-02-06 05:49:04 --> Output Class Initialized
INFO - 2023-02-06 05:49:04 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:04 --> Input Class Initialized
INFO - 2023-02-06 05:49:04 --> Language Class Initialized
INFO - 2023-02-06 05:49:04 --> Loader Class Initialized
INFO - 2023-02-06 05:49:04 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:04 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:04 --> Total execution time: 0.0044
INFO - 2023-02-06 05:49:04 --> Config Class Initialized
INFO - 2023-02-06 05:49:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:04 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:04 --> URI Class Initialized
INFO - 2023-02-06 05:49:04 --> Router Class Initialized
INFO - 2023-02-06 05:49:04 --> Output Class Initialized
INFO - 2023-02-06 05:49:04 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:04 --> Input Class Initialized
INFO - 2023-02-06 05:49:04 --> Language Class Initialized
INFO - 2023-02-06 05:49:04 --> Loader Class Initialized
INFO - 2023-02-06 05:49:04 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:04 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:04 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:04 --> Total execution time: 0.0114
INFO - 2023-02-06 05:49:05 --> Config Class Initialized
INFO - 2023-02-06 05:49:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:05 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:05 --> URI Class Initialized
INFO - 2023-02-06 05:49:05 --> Router Class Initialized
INFO - 2023-02-06 05:49:05 --> Output Class Initialized
INFO - 2023-02-06 05:49:05 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:05 --> Input Class Initialized
INFO - 2023-02-06 05:49:05 --> Language Class Initialized
INFO - 2023-02-06 05:49:05 --> Loader Class Initialized
INFO - 2023-02-06 05:49:05 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:05 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:05 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:05 --> Total execution time: 0.0169
INFO - 2023-02-06 05:49:05 --> Config Class Initialized
INFO - 2023-02-06 05:49:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:05 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:05 --> URI Class Initialized
INFO - 2023-02-06 05:49:05 --> Router Class Initialized
INFO - 2023-02-06 05:49:05 --> Output Class Initialized
INFO - 2023-02-06 05:49:05 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:05 --> Input Class Initialized
INFO - 2023-02-06 05:49:05 --> Language Class Initialized
INFO - 2023-02-06 05:49:05 --> Loader Class Initialized
INFO - 2023-02-06 05:49:05 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:05 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:05 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:05 --> Total execution time: 0.0130
INFO - 2023-02-06 05:49:07 --> Config Class Initialized
INFO - 2023-02-06 05:49:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:07 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:07 --> URI Class Initialized
INFO - 2023-02-06 05:49:07 --> Router Class Initialized
INFO - 2023-02-06 05:49:07 --> Output Class Initialized
INFO - 2023-02-06 05:49:07 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:07 --> Input Class Initialized
INFO - 2023-02-06 05:49:07 --> Language Class Initialized
INFO - 2023-02-06 05:49:07 --> Loader Class Initialized
INFO - 2023-02-06 05:49:07 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:07 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:07 --> Total execution time: 0.0053
INFO - 2023-02-06 05:49:07 --> Config Class Initialized
INFO - 2023-02-06 05:49:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:07 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:07 --> URI Class Initialized
INFO - 2023-02-06 05:49:07 --> Router Class Initialized
INFO - 2023-02-06 05:49:07 --> Output Class Initialized
INFO - 2023-02-06 05:49:07 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:07 --> Input Class Initialized
INFO - 2023-02-06 05:49:07 --> Language Class Initialized
INFO - 2023-02-06 05:49:07 --> Loader Class Initialized
INFO - 2023-02-06 05:49:07 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:07 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:07 --> Model "PGsql_model" initialized
INFO - 2023-02-06 05:49:07 --> Model "Grafana_model" initialized
INFO - 2023-02-06 05:49:07 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:07 --> Total execution time: 0.1086
INFO - 2023-02-06 05:49:25 --> Config Class Initialized
INFO - 2023-02-06 05:49:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:25 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:25 --> URI Class Initialized
INFO - 2023-02-06 05:49:25 --> Router Class Initialized
INFO - 2023-02-06 05:49:25 --> Output Class Initialized
INFO - 2023-02-06 05:49:25 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:25 --> Input Class Initialized
INFO - 2023-02-06 05:49:25 --> Language Class Initialized
INFO - 2023-02-06 05:49:25 --> Loader Class Initialized
INFO - 2023-02-06 05:49:25 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:25 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:25 --> Total execution time: 0.0034
INFO - 2023-02-06 05:49:25 --> Config Class Initialized
INFO - 2023-02-06 05:49:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:25 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:25 --> URI Class Initialized
INFO - 2023-02-06 05:49:25 --> Router Class Initialized
INFO - 2023-02-06 05:49:25 --> Output Class Initialized
INFO - 2023-02-06 05:49:25 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:25 --> Input Class Initialized
INFO - 2023-02-06 05:49:25 --> Language Class Initialized
INFO - 2023-02-06 05:49:25 --> Loader Class Initialized
INFO - 2023-02-06 05:49:25 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:25 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:25 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:25 --> Total execution time: 0.0117
INFO - 2023-02-06 05:49:28 --> Config Class Initialized
INFO - 2023-02-06 05:49:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:28 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:28 --> URI Class Initialized
INFO - 2023-02-06 05:49:28 --> Router Class Initialized
INFO - 2023-02-06 05:49:28 --> Output Class Initialized
INFO - 2023-02-06 05:49:28 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:28 --> Input Class Initialized
INFO - 2023-02-06 05:49:28 --> Language Class Initialized
INFO - 2023-02-06 05:49:28 --> Loader Class Initialized
INFO - 2023-02-06 05:49:28 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:28 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:28 --> Total execution time: 0.0424
INFO - 2023-02-06 05:49:28 --> Config Class Initialized
INFO - 2023-02-06 05:49:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:28 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:28 --> URI Class Initialized
INFO - 2023-02-06 05:49:28 --> Router Class Initialized
INFO - 2023-02-06 05:49:28 --> Output Class Initialized
INFO - 2023-02-06 05:49:28 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:28 --> Input Class Initialized
INFO - 2023-02-06 05:49:28 --> Language Class Initialized
INFO - 2023-02-06 05:49:28 --> Loader Class Initialized
INFO - 2023-02-06 05:49:28 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:28 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:28 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:28 --> Total execution time: 0.0122
INFO - 2023-02-06 05:49:33 --> Config Class Initialized
INFO - 2023-02-06 05:49:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:33 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:33 --> URI Class Initialized
INFO - 2023-02-06 05:49:33 --> Router Class Initialized
INFO - 2023-02-06 05:49:33 --> Output Class Initialized
INFO - 2023-02-06 05:49:33 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:33 --> Input Class Initialized
INFO - 2023-02-06 05:49:33 --> Language Class Initialized
INFO - 2023-02-06 05:49:33 --> Loader Class Initialized
INFO - 2023-02-06 05:49:33 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:33 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:33 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:33 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:33 --> Total execution time: 0.0149
INFO - 2023-02-06 05:49:33 --> Config Class Initialized
INFO - 2023-02-06 05:49:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:33 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:33 --> URI Class Initialized
INFO - 2023-02-06 05:49:33 --> Router Class Initialized
INFO - 2023-02-06 05:49:33 --> Output Class Initialized
INFO - 2023-02-06 05:49:33 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:33 --> Input Class Initialized
INFO - 2023-02-06 05:49:33 --> Language Class Initialized
INFO - 2023-02-06 05:49:33 --> Loader Class Initialized
INFO - 2023-02-06 05:49:33 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:33 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:33 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:33 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:33 --> Total execution time: 0.0106
INFO - 2023-02-06 05:49:34 --> Config Class Initialized
INFO - 2023-02-06 05:49:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:34 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:34 --> URI Class Initialized
INFO - 2023-02-06 05:49:34 --> Router Class Initialized
INFO - 2023-02-06 05:49:34 --> Output Class Initialized
INFO - 2023-02-06 05:49:34 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:34 --> Input Class Initialized
INFO - 2023-02-06 05:49:34 --> Language Class Initialized
INFO - 2023-02-06 05:49:34 --> Loader Class Initialized
INFO - 2023-02-06 05:49:34 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:34 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:34 --> Total execution time: 0.0039
INFO - 2023-02-06 05:49:34 --> Config Class Initialized
INFO - 2023-02-06 05:49:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:34 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:34 --> URI Class Initialized
INFO - 2023-02-06 05:49:34 --> Router Class Initialized
INFO - 2023-02-06 05:49:34 --> Output Class Initialized
INFO - 2023-02-06 05:49:34 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:34 --> Input Class Initialized
INFO - 2023-02-06 05:49:34 --> Language Class Initialized
INFO - 2023-02-06 05:49:34 --> Loader Class Initialized
INFO - 2023-02-06 05:49:34 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:34 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:34 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:34 --> Total execution time: 0.0138
INFO - 2023-02-06 05:49:35 --> Config Class Initialized
INFO - 2023-02-06 05:49:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:35 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:35 --> URI Class Initialized
INFO - 2023-02-06 05:49:35 --> Router Class Initialized
INFO - 2023-02-06 05:49:35 --> Output Class Initialized
INFO - 2023-02-06 05:49:35 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:35 --> Input Class Initialized
INFO - 2023-02-06 05:49:35 --> Language Class Initialized
INFO - 2023-02-06 05:49:35 --> Loader Class Initialized
INFO - 2023-02-06 05:49:35 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:35 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:35 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:35 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:35 --> Total execution time: 0.0162
INFO - 2023-02-06 05:49:35 --> Config Class Initialized
INFO - 2023-02-06 05:49:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:35 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:35 --> URI Class Initialized
INFO - 2023-02-06 05:49:35 --> Router Class Initialized
INFO - 2023-02-06 05:49:35 --> Output Class Initialized
INFO - 2023-02-06 05:49:35 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:35 --> Input Class Initialized
INFO - 2023-02-06 05:49:35 --> Language Class Initialized
INFO - 2023-02-06 05:49:35 --> Loader Class Initialized
INFO - 2023-02-06 05:49:35 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:35 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:35 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:35 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:35 --> Total execution time: 0.0139
INFO - 2023-02-06 05:49:40 --> Config Class Initialized
INFO - 2023-02-06 05:49:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:40 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:40 --> URI Class Initialized
INFO - 2023-02-06 05:49:41 --> Router Class Initialized
INFO - 2023-02-06 05:49:41 --> Output Class Initialized
INFO - 2023-02-06 05:49:41 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:41 --> Input Class Initialized
INFO - 2023-02-06 05:49:41 --> Language Class Initialized
INFO - 2023-02-06 05:49:41 --> Loader Class Initialized
INFO - 2023-02-06 05:49:41 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:41 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:41 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:41 --> Total execution time: 0.0469
INFO - 2023-02-06 05:49:41 --> Config Class Initialized
INFO - 2023-02-06 05:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:41 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:41 --> URI Class Initialized
INFO - 2023-02-06 05:49:41 --> Router Class Initialized
INFO - 2023-02-06 05:49:41 --> Output Class Initialized
INFO - 2023-02-06 05:49:41 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:41 --> Input Class Initialized
INFO - 2023-02-06 05:49:41 --> Language Class Initialized
INFO - 2023-02-06 05:49:41 --> Loader Class Initialized
INFO - 2023-02-06 05:49:41 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:41 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:41 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:41 --> Total execution time: 0.0188
INFO - 2023-02-06 05:49:43 --> Config Class Initialized
INFO - 2023-02-06 05:49:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:43 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:43 --> URI Class Initialized
INFO - 2023-02-06 05:49:43 --> Router Class Initialized
INFO - 2023-02-06 05:49:43 --> Output Class Initialized
INFO - 2023-02-06 05:49:43 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:43 --> Input Class Initialized
INFO - 2023-02-06 05:49:43 --> Language Class Initialized
INFO - 2023-02-06 05:49:43 --> Loader Class Initialized
INFO - 2023-02-06 05:49:43 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:43 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:43 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:43 --> Total execution time: 0.0155
INFO - 2023-02-06 05:49:43 --> Config Class Initialized
INFO - 2023-02-06 05:49:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:43 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:43 --> URI Class Initialized
INFO - 2023-02-06 05:49:43 --> Router Class Initialized
INFO - 2023-02-06 05:49:43 --> Output Class Initialized
INFO - 2023-02-06 05:49:43 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:43 --> Input Class Initialized
INFO - 2023-02-06 05:49:43 --> Language Class Initialized
INFO - 2023-02-06 05:49:43 --> Loader Class Initialized
INFO - 2023-02-06 05:49:43 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:43 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:43 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:43 --> Total execution time: 0.0110
INFO - 2023-02-06 05:49:46 --> Config Class Initialized
INFO - 2023-02-06 05:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:46 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:46 --> URI Class Initialized
INFO - 2023-02-06 05:49:46 --> Router Class Initialized
INFO - 2023-02-06 05:49:46 --> Output Class Initialized
INFO - 2023-02-06 05:49:46 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:46 --> Input Class Initialized
INFO - 2023-02-06 05:49:46 --> Language Class Initialized
INFO - 2023-02-06 05:49:46 --> Loader Class Initialized
INFO - 2023-02-06 05:49:46 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:46 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:46 --> Total execution time: 0.0056
INFO - 2023-02-06 05:49:46 --> Config Class Initialized
INFO - 2023-02-06 05:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 05:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 05:49:46 --> Utf8 Class Initialized
INFO - 2023-02-06 05:49:46 --> URI Class Initialized
INFO - 2023-02-06 05:49:46 --> Router Class Initialized
INFO - 2023-02-06 05:49:46 --> Output Class Initialized
INFO - 2023-02-06 05:49:46 --> Security Class Initialized
DEBUG - 2023-02-06 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 05:49:46 --> Input Class Initialized
INFO - 2023-02-06 05:49:46 --> Language Class Initialized
INFO - 2023-02-06 05:49:46 --> Loader Class Initialized
INFO - 2023-02-06 05:49:46 --> Controller Class Initialized
DEBUG - 2023-02-06 05:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 05:49:46 --> Database Driver Class Initialized
INFO - 2023-02-06 05:49:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 05:49:46 --> Model "PGsql_model" initialized
INFO - 2023-02-06 05:49:46 --> Model "Grafana_model" initialized
INFO - 2023-02-06 05:49:46 --> Final output sent to browser
DEBUG - 2023-02-06 05:49:46 --> Total execution time: 0.0200
INFO - 2023-02-06 06:22:29 --> Config Class Initialized
INFO - 2023-02-06 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:29 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:29 --> URI Class Initialized
INFO - 2023-02-06 06:22:29 --> Router Class Initialized
INFO - 2023-02-06 06:22:29 --> Output Class Initialized
INFO - 2023-02-06 06:22:29 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:29 --> Input Class Initialized
INFO - 2023-02-06 06:22:29 --> Language Class Initialized
INFO - 2023-02-06 06:22:29 --> Loader Class Initialized
INFO - 2023-02-06 06:22:29 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:29 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:29 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:29 --> Total execution time: 0.0202
INFO - 2023-02-06 06:22:29 --> Config Class Initialized
INFO - 2023-02-06 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:29 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:29 --> URI Class Initialized
INFO - 2023-02-06 06:22:29 --> Router Class Initialized
INFO - 2023-02-06 06:22:29 --> Output Class Initialized
INFO - 2023-02-06 06:22:29 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:29 --> Input Class Initialized
INFO - 2023-02-06 06:22:29 --> Language Class Initialized
INFO - 2023-02-06 06:22:29 --> Loader Class Initialized
INFO - 2023-02-06 06:22:29 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:29 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:29 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:29 --> Total execution time: 0.0543
INFO - 2023-02-06 06:22:32 --> Config Class Initialized
INFO - 2023-02-06 06:22:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:32 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:32 --> URI Class Initialized
INFO - 2023-02-06 06:22:32 --> Router Class Initialized
INFO - 2023-02-06 06:22:32 --> Output Class Initialized
INFO - 2023-02-06 06:22:32 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:32 --> Input Class Initialized
INFO - 2023-02-06 06:22:32 --> Language Class Initialized
INFO - 2023-02-06 06:22:32 --> Loader Class Initialized
INFO - 2023-02-06 06:22:32 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:32 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:32 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:32 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:32 --> Total execution time: 0.0177
INFO - 2023-02-06 06:22:32 --> Config Class Initialized
INFO - 2023-02-06 06:22:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:32 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:32 --> URI Class Initialized
INFO - 2023-02-06 06:22:32 --> Router Class Initialized
INFO - 2023-02-06 06:22:32 --> Output Class Initialized
INFO - 2023-02-06 06:22:32 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:32 --> Input Class Initialized
INFO - 2023-02-06 06:22:32 --> Language Class Initialized
INFO - 2023-02-06 06:22:32 --> Loader Class Initialized
INFO - 2023-02-06 06:22:32 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:32 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:32 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:32 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:32 --> Total execution time: 0.0157
INFO - 2023-02-06 06:22:34 --> Config Class Initialized
INFO - 2023-02-06 06:22:34 --> Config Class Initialized
INFO - 2023-02-06 06:22:34 --> Hooks Class Initialized
INFO - 2023-02-06 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:34 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:34 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:34 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:34 --> URI Class Initialized
INFO - 2023-02-06 06:22:34 --> URI Class Initialized
INFO - 2023-02-06 06:22:34 --> Router Class Initialized
INFO - 2023-02-06 06:22:34 --> Router Class Initialized
INFO - 2023-02-06 06:22:34 --> Output Class Initialized
INFO - 2023-02-06 06:22:34 --> Output Class Initialized
INFO - 2023-02-06 06:22:34 --> Security Class Initialized
INFO - 2023-02-06 06:22:34 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:34 --> Input Class Initialized
INFO - 2023-02-06 06:22:34 --> Input Class Initialized
INFO - 2023-02-06 06:22:34 --> Language Class Initialized
INFO - 2023-02-06 06:22:34 --> Language Class Initialized
INFO - 2023-02-06 06:22:34 --> Loader Class Initialized
INFO - 2023-02-06 06:22:34 --> Loader Class Initialized
INFO - 2023-02-06 06:22:34 --> Controller Class Initialized
INFO - 2023-02-06 06:22:34 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:34 --> Final output sent to browser
INFO - 2023-02-06 06:22:34 --> Database Driver Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Total execution time: 0.0055
INFO - 2023-02-06 06:22:34 --> Config Class Initialized
INFO - 2023-02-06 06:22:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:34 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:34 --> URI Class Initialized
INFO - 2023-02-06 06:22:34 --> Router Class Initialized
INFO - 2023-02-06 06:22:34 --> Output Class Initialized
INFO - 2023-02-06 06:22:34 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:34 --> Input Class Initialized
INFO - 2023-02-06 06:22:34 --> Language Class Initialized
INFO - 2023-02-06 06:22:34 --> Loader Class Initialized
INFO - 2023-02-06 06:22:34 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:34 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:34 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:34 --> Total execution time: 0.0576
INFO - 2023-02-06 06:22:34 --> Config Class Initialized
INFO - 2023-02-06 06:22:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:34 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:34 --> URI Class Initialized
INFO - 2023-02-06 06:22:34 --> Router Class Initialized
INFO - 2023-02-06 06:22:34 --> Output Class Initialized
INFO - 2023-02-06 06:22:34 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:34 --> Input Class Initialized
INFO - 2023-02-06 06:22:34 --> Language Class Initialized
INFO - 2023-02-06 06:22:34 --> Loader Class Initialized
INFO - 2023-02-06 06:22:34 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:34 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:34 --> Model "Login_model" initialized
INFO - 2023-02-06 06:22:34 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:34 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:34 --> Total execution time: 0.0168
INFO - 2023-02-06 06:22:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:34 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:34 --> Total execution time: 0.0713
INFO - 2023-02-06 06:22:37 --> Config Class Initialized
INFO - 2023-02-06 06:22:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:37 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:37 --> URI Class Initialized
INFO - 2023-02-06 06:22:37 --> Router Class Initialized
INFO - 2023-02-06 06:22:37 --> Output Class Initialized
INFO - 2023-02-06 06:22:37 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:37 --> Input Class Initialized
INFO - 2023-02-06 06:22:37 --> Language Class Initialized
INFO - 2023-02-06 06:22:37 --> Loader Class Initialized
INFO - 2023-02-06 06:22:37 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:37 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:37 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:37 --> Total execution time: 0.0629
INFO - 2023-02-06 06:22:37 --> Config Class Initialized
INFO - 2023-02-06 06:22:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:37 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:37 --> URI Class Initialized
INFO - 2023-02-06 06:22:37 --> Router Class Initialized
INFO - 2023-02-06 06:22:37 --> Output Class Initialized
INFO - 2023-02-06 06:22:37 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:37 --> Input Class Initialized
INFO - 2023-02-06 06:22:37 --> Language Class Initialized
INFO - 2023-02-06 06:22:37 --> Loader Class Initialized
INFO - 2023-02-06 06:22:37 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:37 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:37 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:37 --> Total execution time: 0.0171
INFO - 2023-02-06 06:22:39 --> Config Class Initialized
INFO - 2023-02-06 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:39 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:39 --> URI Class Initialized
INFO - 2023-02-06 06:22:39 --> Router Class Initialized
INFO - 2023-02-06 06:22:39 --> Output Class Initialized
INFO - 2023-02-06 06:22:39 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:39 --> Input Class Initialized
INFO - 2023-02-06 06:22:39 --> Language Class Initialized
INFO - 2023-02-06 06:22:39 --> Loader Class Initialized
INFO - 2023-02-06 06:22:39 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:39 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:39 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:39 --> Total execution time: 0.0194
INFO - 2023-02-06 06:22:39 --> Config Class Initialized
INFO - 2023-02-06 06:22:39 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:39 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:39 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:39 --> URI Class Initialized
INFO - 2023-02-06 06:22:39 --> Router Class Initialized
INFO - 2023-02-06 06:22:39 --> Output Class Initialized
INFO - 2023-02-06 06:22:39 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:39 --> Input Class Initialized
INFO - 2023-02-06 06:22:39 --> Language Class Initialized
INFO - 2023-02-06 06:22:39 --> Loader Class Initialized
INFO - 2023-02-06 06:22:39 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:39 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:39 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:39 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:39 --> Total execution time: 0.0172
INFO - 2023-02-06 06:22:43 --> Config Class Initialized
INFO - 2023-02-06 06:22:43 --> Config Class Initialized
INFO - 2023-02-06 06:22:43 --> Hooks Class Initialized
INFO - 2023-02-06 06:22:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 06:22:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:43 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:43 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:43 --> URI Class Initialized
INFO - 2023-02-06 06:22:43 --> URI Class Initialized
INFO - 2023-02-06 06:22:43 --> Router Class Initialized
INFO - 2023-02-06 06:22:43 --> Router Class Initialized
INFO - 2023-02-06 06:22:43 --> Output Class Initialized
INFO - 2023-02-06 06:22:43 --> Output Class Initialized
INFO - 2023-02-06 06:22:43 --> Security Class Initialized
INFO - 2023-02-06 06:22:43 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 06:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:43 --> Input Class Initialized
INFO - 2023-02-06 06:22:43 --> Input Class Initialized
INFO - 2023-02-06 06:22:43 --> Language Class Initialized
INFO - 2023-02-06 06:22:43 --> Language Class Initialized
INFO - 2023-02-06 06:22:43 --> Loader Class Initialized
INFO - 2023-02-06 06:22:43 --> Loader Class Initialized
INFO - 2023-02-06 06:22:43 --> Controller Class Initialized
INFO - 2023-02-06 06:22:43 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 06:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:43 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:43 --> Total execution time: 0.0078
INFO - 2023-02-06 06:22:43 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:43 --> Config Class Initialized
INFO - 2023-02-06 06:22:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:43 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:43 --> URI Class Initialized
INFO - 2023-02-06 06:22:43 --> Router Class Initialized
INFO - 2023-02-06 06:22:43 --> Output Class Initialized
INFO - 2023-02-06 06:22:43 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:43 --> Input Class Initialized
INFO - 2023-02-06 06:22:43 --> Language Class Initialized
INFO - 2023-02-06 06:22:43 --> Loader Class Initialized
INFO - 2023-02-06 06:22:43 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:43 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:43 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:43 --> Total execution time: 0.0193
INFO - 2023-02-06 06:22:43 --> Model "Login_model" initialized
INFO - 2023-02-06 06:22:43 --> Config Class Initialized
INFO - 2023-02-06 06:22:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:22:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:22:43 --> Utf8 Class Initialized
INFO - 2023-02-06 06:22:43 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:43 --> URI Class Initialized
INFO - 2023-02-06 06:22:43 --> Router Class Initialized
INFO - 2023-02-06 06:22:43 --> Output Class Initialized
INFO - 2023-02-06 06:22:43 --> Security Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:22:43 --> Input Class Initialized
INFO - 2023-02-06 06:22:43 --> Language Class Initialized
INFO - 2023-02-06 06:22:43 --> Loader Class Initialized
INFO - 2023-02-06 06:22:43 --> Controller Class Initialized
DEBUG - 2023-02-06 06:22:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:22:43 --> Database Driver Class Initialized
INFO - 2023-02-06 06:22:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:22:43 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:43 --> Total execution time: 0.0257
INFO - 2023-02-06 06:22:43 --> Final output sent to browser
DEBUG - 2023-02-06 06:22:43 --> Total execution time: 0.0151
INFO - 2023-02-06 06:23:00 --> Config Class Initialized
INFO - 2023-02-06 06:23:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:00 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:00 --> URI Class Initialized
INFO - 2023-02-06 06:23:00 --> Router Class Initialized
INFO - 2023-02-06 06:23:00 --> Output Class Initialized
INFO - 2023-02-06 06:23:00 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:00 --> Input Class Initialized
INFO - 2023-02-06 06:23:00 --> Language Class Initialized
INFO - 2023-02-06 06:23:00 --> Loader Class Initialized
INFO - 2023-02-06 06:23:00 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:00 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:00 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:00 --> Total execution time: 0.0177
INFO - 2023-02-06 06:23:00 --> Config Class Initialized
INFO - 2023-02-06 06:23:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:00 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:00 --> URI Class Initialized
INFO - 2023-02-06 06:23:00 --> Router Class Initialized
INFO - 2023-02-06 06:23:00 --> Output Class Initialized
INFO - 2023-02-06 06:23:00 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:00 --> Input Class Initialized
INFO - 2023-02-06 06:23:00 --> Language Class Initialized
INFO - 2023-02-06 06:23:00 --> Loader Class Initialized
INFO - 2023-02-06 06:23:00 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:00 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:00 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:00 --> Total execution time: 0.0176
INFO - 2023-02-06 06:23:02 --> Config Class Initialized
INFO - 2023-02-06 06:23:02 --> Config Class Initialized
INFO - 2023-02-06 06:23:02 --> Hooks Class Initialized
INFO - 2023-02-06 06:23:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 06:23:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:02 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:02 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:02 --> URI Class Initialized
INFO - 2023-02-06 06:23:02 --> URI Class Initialized
INFO - 2023-02-06 06:23:02 --> Router Class Initialized
INFO - 2023-02-06 06:23:02 --> Router Class Initialized
INFO - 2023-02-06 06:23:02 --> Output Class Initialized
INFO - 2023-02-06 06:23:02 --> Output Class Initialized
INFO - 2023-02-06 06:23:02 --> Security Class Initialized
INFO - 2023-02-06 06:23:02 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 06:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:02 --> Input Class Initialized
INFO - 2023-02-06 06:23:02 --> Input Class Initialized
INFO - 2023-02-06 06:23:02 --> Language Class Initialized
INFO - 2023-02-06 06:23:02 --> Language Class Initialized
INFO - 2023-02-06 06:23:02 --> Loader Class Initialized
INFO - 2023-02-06 06:23:02 --> Loader Class Initialized
INFO - 2023-02-06 06:23:02 --> Controller Class Initialized
INFO - 2023-02-06 06:23:02 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 06:23:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:02 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:02 --> Total execution time: 0.0039
INFO - 2023-02-06 06:23:02 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Config Class Initialized
INFO - 2023-02-06 06:23:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:03 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:03 --> URI Class Initialized
INFO - 2023-02-06 06:23:03 --> Router Class Initialized
INFO - 2023-02-06 06:23:03 --> Output Class Initialized
INFO - 2023-02-06 06:23:03 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:03 --> Input Class Initialized
INFO - 2023-02-06 06:23:03 --> Language Class Initialized
INFO - 2023-02-06 06:23:03 --> Loader Class Initialized
INFO - 2023-02-06 06:23:03 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:03 --> Model "Login_model" initialized
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:03 --> Total execution time: 0.0818
INFO - 2023-02-06 06:23:03 --> Config Class Initialized
INFO - 2023-02-06 06:23:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:03 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:03 --> URI Class Initialized
INFO - 2023-02-06 06:23:03 --> Router Class Initialized
INFO - 2023-02-06 06:23:03 --> Output Class Initialized
INFO - 2023-02-06 06:23:03 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:03 --> Input Class Initialized
INFO - 2023-02-06 06:23:03 --> Language Class Initialized
INFO - 2023-02-06 06:23:03 --> Loader Class Initialized
INFO - 2023-02-06 06:23:03 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:03 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:03 --> Total execution time: 0.0816
INFO - 2023-02-06 06:23:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:03 --> Config Class Initialized
INFO - 2023-02-06 06:23:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:03 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:03 --> URI Class Initialized
INFO - 2023-02-06 06:23:03 --> Router Class Initialized
INFO - 2023-02-06 06:23:03 --> Output Class Initialized
INFO - 2023-02-06 06:23:03 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:03 --> Input Class Initialized
INFO - 2023-02-06 06:23:03 --> Language Class Initialized
INFO - 2023-02-06 06:23:03 --> Loader Class Initialized
INFO - 2023-02-06 06:23:03 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:03 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:03 --> Total execution time: 0.0564
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Login_model" initialized
INFO - 2023-02-06 06:23:03 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:03 --> Total execution time: 0.0744
INFO - 2023-02-06 06:23:03 --> Config Class Initialized
INFO - 2023-02-06 06:23:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:03 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:03 --> URI Class Initialized
INFO - 2023-02-06 06:23:03 --> Router Class Initialized
INFO - 2023-02-06 06:23:03 --> Output Class Initialized
INFO - 2023-02-06 06:23:03 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:03 --> Input Class Initialized
INFO - 2023-02-06 06:23:03 --> Language Class Initialized
INFO - 2023-02-06 06:23:03 --> Loader Class Initialized
INFO - 2023-02-06 06:23:03 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:03 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:03 --> Model "Login_model" initialized
INFO - 2023-02-06 06:23:03 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:03 --> Total execution time: 0.0424
INFO - 2023-02-06 06:23:08 --> Config Class Initialized
INFO - 2023-02-06 06:23:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:08 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:08 --> URI Class Initialized
INFO - 2023-02-06 06:23:08 --> Router Class Initialized
INFO - 2023-02-06 06:23:08 --> Output Class Initialized
INFO - 2023-02-06 06:23:08 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:08 --> Input Class Initialized
INFO - 2023-02-06 06:23:08 --> Language Class Initialized
INFO - 2023-02-06 06:23:08 --> Loader Class Initialized
INFO - 2023-02-06 06:23:08 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:08 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:08 --> Total execution time: 0.0038
INFO - 2023-02-06 06:23:08 --> Config Class Initialized
INFO - 2023-02-06 06:23:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:08 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:08 --> URI Class Initialized
INFO - 2023-02-06 06:23:08 --> Router Class Initialized
INFO - 2023-02-06 06:23:08 --> Output Class Initialized
INFO - 2023-02-06 06:23:08 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:08 --> Input Class Initialized
INFO - 2023-02-06 06:23:08 --> Language Class Initialized
INFO - 2023-02-06 06:23:08 --> Loader Class Initialized
INFO - 2023-02-06 06:23:08 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:08 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:08 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:08 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:08 --> Total execution time: 0.0363
INFO - 2023-02-06 06:23:12 --> Config Class Initialized
INFO - 2023-02-06 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:12 --> URI Class Initialized
INFO - 2023-02-06 06:23:12 --> Router Class Initialized
INFO - 2023-02-06 06:23:12 --> Output Class Initialized
INFO - 2023-02-06 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:12 --> Input Class Initialized
INFO - 2023-02-06 06:23:12 --> Language Class Initialized
INFO - 2023-02-06 06:23:12 --> Loader Class Initialized
INFO - 2023-02-06 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:12 --> Total execution time: 0.0046
INFO - 2023-02-06 06:23:12 --> Config Class Initialized
INFO - 2023-02-06 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:12 --> URI Class Initialized
INFO - 2023-02-06 06:23:12 --> Router Class Initialized
INFO - 2023-02-06 06:23:12 --> Output Class Initialized
INFO - 2023-02-06 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:12 --> Input Class Initialized
INFO - 2023-02-06 06:23:12 --> Language Class Initialized
INFO - 2023-02-06 06:23:12 --> Loader Class Initialized
INFO - 2023-02-06 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:12 --> Total execution time: 0.0131
INFO - 2023-02-06 06:23:12 --> Config Class Initialized
INFO - 2023-02-06 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:12 --> URI Class Initialized
INFO - 2023-02-06 06:23:12 --> Router Class Initialized
INFO - 2023-02-06 06:23:12 --> Output Class Initialized
INFO - 2023-02-06 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:12 --> Input Class Initialized
INFO - 2023-02-06 06:23:12 --> Language Class Initialized
INFO - 2023-02-06 06:23:12 --> Loader Class Initialized
INFO - 2023-02-06 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:12 --> Total execution time: 0.0132
INFO - 2023-02-06 06:23:12 --> Config Class Initialized
INFO - 2023-02-06 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:12 --> URI Class Initialized
INFO - 2023-02-06 06:23:12 --> Router Class Initialized
INFO - 2023-02-06 06:23:12 --> Output Class Initialized
INFO - 2023-02-06 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:12 --> Input Class Initialized
INFO - 2023-02-06 06:23:12 --> Language Class Initialized
INFO - 2023-02-06 06:23:12 --> Loader Class Initialized
INFO - 2023-02-06 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:12 --> Total execution time: 0.0107
INFO - 2023-02-06 06:23:14 --> Config Class Initialized
INFO - 2023-02-06 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:14 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:14 --> URI Class Initialized
INFO - 2023-02-06 06:23:14 --> Router Class Initialized
INFO - 2023-02-06 06:23:14 --> Output Class Initialized
INFO - 2023-02-06 06:23:14 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:14 --> Input Class Initialized
INFO - 2023-02-06 06:23:14 --> Language Class Initialized
INFO - 2023-02-06 06:23:14 --> Loader Class Initialized
INFO - 2023-02-06 06:23:14 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:14 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:14 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:14 --> Total execution time: 0.0435
INFO - 2023-02-06 06:23:14 --> Config Class Initialized
INFO - 2023-02-06 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:14 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:14 --> URI Class Initialized
INFO - 2023-02-06 06:23:14 --> Router Class Initialized
INFO - 2023-02-06 06:23:14 --> Output Class Initialized
INFO - 2023-02-06 06:23:14 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:14 --> Input Class Initialized
INFO - 2023-02-06 06:23:14 --> Language Class Initialized
INFO - 2023-02-06 06:23:14 --> Loader Class Initialized
INFO - 2023-02-06 06:23:14 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:14 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:14 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:14 --> Total execution time: 0.0156
INFO - 2023-02-06 06:23:17 --> Config Class Initialized
INFO - 2023-02-06 06:23:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:17 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:17 --> URI Class Initialized
INFO - 2023-02-06 06:23:17 --> Router Class Initialized
INFO - 2023-02-06 06:23:17 --> Output Class Initialized
INFO - 2023-02-06 06:23:17 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:17 --> Input Class Initialized
INFO - 2023-02-06 06:23:17 --> Language Class Initialized
INFO - 2023-02-06 06:23:17 --> Loader Class Initialized
INFO - 2023-02-06 06:23:17 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:17 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:17 --> Total execution time: 0.0040
INFO - 2023-02-06 06:23:17 --> Config Class Initialized
INFO - 2023-02-06 06:23:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:17 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:17 --> URI Class Initialized
INFO - 2023-02-06 06:23:17 --> Router Class Initialized
INFO - 2023-02-06 06:23:17 --> Output Class Initialized
INFO - 2023-02-06 06:23:17 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:17 --> Input Class Initialized
INFO - 2023-02-06 06:23:17 --> Language Class Initialized
INFO - 2023-02-06 06:23:17 --> Loader Class Initialized
INFO - 2023-02-06 06:23:17 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:17 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:17 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:17 --> Total execution time: 0.0154
INFO - 2023-02-06 06:23:18 --> Config Class Initialized
INFO - 2023-02-06 06:23:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:18 --> URI Class Initialized
INFO - 2023-02-06 06:23:18 --> Router Class Initialized
INFO - 2023-02-06 06:23:18 --> Output Class Initialized
INFO - 2023-02-06 06:23:18 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:18 --> Input Class Initialized
INFO - 2023-02-06 06:23:18 --> Language Class Initialized
INFO - 2023-02-06 06:23:18 --> Loader Class Initialized
INFO - 2023-02-06 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:18 --> Total execution time: 0.0261
INFO - 2023-02-06 06:23:18 --> Config Class Initialized
INFO - 2023-02-06 06:23:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:18 --> URI Class Initialized
INFO - 2023-02-06 06:23:18 --> Router Class Initialized
INFO - 2023-02-06 06:23:18 --> Output Class Initialized
INFO - 2023-02-06 06:23:18 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:18 --> Input Class Initialized
INFO - 2023-02-06 06:23:18 --> Language Class Initialized
INFO - 2023-02-06 06:23:18 --> Loader Class Initialized
INFO - 2023-02-06 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:18 --> Total execution time: 0.0189
INFO - 2023-02-06 06:23:20 --> Config Class Initialized
INFO - 2023-02-06 06:23:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:20 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:20 --> URI Class Initialized
INFO - 2023-02-06 06:23:20 --> Router Class Initialized
INFO - 2023-02-06 06:23:20 --> Output Class Initialized
INFO - 2023-02-06 06:23:20 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:20 --> Input Class Initialized
INFO - 2023-02-06 06:23:20 --> Language Class Initialized
INFO - 2023-02-06 06:23:20 --> Loader Class Initialized
INFO - 2023-02-06 06:23:20 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:20 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:20 --> Total execution time: 0.0038
INFO - 2023-02-06 06:23:20 --> Config Class Initialized
INFO - 2023-02-06 06:23:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:20 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:20 --> URI Class Initialized
INFO - 2023-02-06 06:23:20 --> Router Class Initialized
INFO - 2023-02-06 06:23:20 --> Output Class Initialized
INFO - 2023-02-06 06:23:20 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:20 --> Input Class Initialized
INFO - 2023-02-06 06:23:20 --> Language Class Initialized
INFO - 2023-02-06 06:23:20 --> Loader Class Initialized
INFO - 2023-02-06 06:23:20 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:20 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:20 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:20 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:23:20 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:23:20 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:20 --> Total execution time: 0.0160
INFO - 2023-02-06 06:23:24 --> Config Class Initialized
INFO - 2023-02-06 06:23:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:24 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:24 --> URI Class Initialized
INFO - 2023-02-06 06:23:24 --> Router Class Initialized
INFO - 2023-02-06 06:23:24 --> Output Class Initialized
INFO - 2023-02-06 06:23:24 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:24 --> Input Class Initialized
INFO - 2023-02-06 06:23:24 --> Language Class Initialized
INFO - 2023-02-06 06:23:24 --> Loader Class Initialized
INFO - 2023-02-06 06:23:24 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:24 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:24 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:24 --> Total execution time: 0.0163
INFO - 2023-02-06 06:23:24 --> Config Class Initialized
INFO - 2023-02-06 06:23:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:24 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:24 --> URI Class Initialized
INFO - 2023-02-06 06:23:24 --> Router Class Initialized
INFO - 2023-02-06 06:23:24 --> Output Class Initialized
INFO - 2023-02-06 06:23:24 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:24 --> Input Class Initialized
INFO - 2023-02-06 06:23:24 --> Language Class Initialized
INFO - 2023-02-06 06:23:24 --> Loader Class Initialized
INFO - 2023-02-06 06:23:24 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:24 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:24 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:24 --> Total execution time: 0.0124
INFO - 2023-02-06 06:23:30 --> Config Class Initialized
INFO - 2023-02-06 06:23:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:30 --> URI Class Initialized
INFO - 2023-02-06 06:23:30 --> Router Class Initialized
INFO - 2023-02-06 06:23:30 --> Output Class Initialized
INFO - 2023-02-06 06:23:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:30 --> Input Class Initialized
INFO - 2023-02-06 06:23:30 --> Language Class Initialized
INFO - 2023-02-06 06:23:30 --> Loader Class Initialized
INFO - 2023-02-06 06:23:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:30 --> Total execution time: 0.0037
INFO - 2023-02-06 06:23:30 --> Config Class Initialized
INFO - 2023-02-06 06:23:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:23:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:23:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:23:30 --> URI Class Initialized
INFO - 2023-02-06 06:23:30 --> Router Class Initialized
INFO - 2023-02-06 06:23:30 --> Output Class Initialized
INFO - 2023-02-06 06:23:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:23:30 --> Input Class Initialized
INFO - 2023-02-06 06:23:30 --> Language Class Initialized
INFO - 2023-02-06 06:23:30 --> Loader Class Initialized
INFO - 2023-02-06 06:23:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:23:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:23:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:23:30 --> Model "PGsql_model" initialized
INFO - 2023-02-06 06:23:30 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:23:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:23:30 --> Total execution time: 0.0152
INFO - 2023-02-06 06:24:29 --> Config Class Initialized
INFO - 2023-02-06 06:24:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:30 --> URI Class Initialized
INFO - 2023-02-06 06:24:30 --> Router Class Initialized
INFO - 2023-02-06 06:24:30 --> Output Class Initialized
INFO - 2023-02-06 06:24:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:30 --> Input Class Initialized
INFO - 2023-02-06 06:24:30 --> Language Class Initialized
INFO - 2023-02-06 06:24:30 --> Loader Class Initialized
INFO - 2023-02-06 06:24:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:30 --> Model "Login_model" initialized
INFO - 2023-02-06 06:24:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:30 --> Total execution time: 0.4472
INFO - 2023-02-06 06:24:30 --> Config Class Initialized
INFO - 2023-02-06 06:24:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:30 --> URI Class Initialized
INFO - 2023-02-06 06:24:30 --> Router Class Initialized
INFO - 2023-02-06 06:24:30 --> Output Class Initialized
INFO - 2023-02-06 06:24:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:30 --> Input Class Initialized
INFO - 2023-02-06 06:24:30 --> Language Class Initialized
INFO - 2023-02-06 06:24:30 --> Loader Class Initialized
INFO - 2023-02-06 06:24:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:30 --> Model "Login_model" initialized
INFO - 2023-02-06 06:24:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:30 --> Total execution time: 0.1731
INFO - 2023-02-06 06:24:57 --> Config Class Initialized
INFO - 2023-02-06 06:24:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:57 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:57 --> URI Class Initialized
INFO - 2023-02-06 06:24:57 --> Router Class Initialized
INFO - 2023-02-06 06:24:57 --> Output Class Initialized
INFO - 2023-02-06 06:24:57 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:57 --> Input Class Initialized
INFO - 2023-02-06 06:24:57 --> Language Class Initialized
INFO - 2023-02-06 06:24:57 --> Loader Class Initialized
INFO - 2023-02-06 06:24:57 --> Controller Class Initialized
INFO - 2023-02-06 06:24:57 --> Helper loaded: form_helper
INFO - 2023-02-06 06:24:57 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:24:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:57 --> Model "Change_model" initialized
INFO - 2023-02-06 06:24:57 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:24:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:58 --> Total execution time: 0.2313
INFO - 2023-02-06 06:24:58 --> Config Class Initialized
INFO - 2023-02-06 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:58 --> URI Class Initialized
INFO - 2023-02-06 06:24:58 --> Router Class Initialized
INFO - 2023-02-06 06:24:58 --> Output Class Initialized
INFO - 2023-02-06 06:24:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:58 --> Input Class Initialized
INFO - 2023-02-06 06:24:58 --> Language Class Initialized
INFO - 2023-02-06 06:24:58 --> Loader Class Initialized
INFO - 2023-02-06 06:24:58 --> Controller Class Initialized
INFO - 2023-02-06 06:24:58 --> Helper loaded: form_helper
INFO - 2023-02-06 06:24:58 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:24:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:58 --> Total execution time: 0.0428
INFO - 2023-02-06 06:24:58 --> Config Class Initialized
INFO - 2023-02-06 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:58 --> URI Class Initialized
INFO - 2023-02-06 06:24:58 --> Router Class Initialized
INFO - 2023-02-06 06:24:58 --> Output Class Initialized
INFO - 2023-02-06 06:24:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:58 --> Input Class Initialized
INFO - 2023-02-06 06:24:58 --> Language Class Initialized
INFO - 2023-02-06 06:24:58 --> Loader Class Initialized
INFO - 2023-02-06 06:24:58 --> Controller Class Initialized
INFO - 2023-02-06 06:24:58 --> Helper loaded: form_helper
INFO - 2023-02-06 06:24:58 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:24:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:58 --> Model "Login_model" initialized
INFO - 2023-02-06 06:24:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:58 --> Total execution time: 0.1512
INFO - 2023-02-06 06:24:58 --> Config Class Initialized
INFO - 2023-02-06 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:58 --> URI Class Initialized
INFO - 2023-02-06 06:24:58 --> Router Class Initialized
INFO - 2023-02-06 06:24:58 --> Output Class Initialized
INFO - 2023-02-06 06:24:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:58 --> Input Class Initialized
INFO - 2023-02-06 06:24:58 --> Language Class Initialized
INFO - 2023-02-06 06:24:58 --> Loader Class Initialized
INFO - 2023-02-06 06:24:58 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:58 --> Total execution time: 0.1324
INFO - 2023-02-06 06:24:58 --> Config Class Initialized
INFO - 2023-02-06 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:58 --> URI Class Initialized
INFO - 2023-02-06 06:24:58 --> Router Class Initialized
INFO - 2023-02-06 06:24:58 --> Output Class Initialized
INFO - 2023-02-06 06:24:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:58 --> Input Class Initialized
INFO - 2023-02-06 06:24:58 --> Language Class Initialized
INFO - 2023-02-06 06:24:58 --> Loader Class Initialized
INFO - 2023-02-06 06:24:58 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:58 --> Total execution time: 0.1320
INFO - 2023-02-06 06:24:58 --> Config Class Initialized
INFO - 2023-02-06 06:24:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:58 --> URI Class Initialized
INFO - 2023-02-06 06:24:58 --> Router Class Initialized
INFO - 2023-02-06 06:24:58 --> Output Class Initialized
INFO - 2023-02-06 06:24:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:58 --> Input Class Initialized
INFO - 2023-02-06 06:24:58 --> Language Class Initialized
INFO - 2023-02-06 06:24:58 --> Loader Class Initialized
INFO - 2023-02-06 06:24:58 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:59 --> Model "Login_model" initialized
INFO - 2023-02-06 06:24:59 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:59 --> Total execution time: 0.4468
INFO - 2023-02-06 06:24:59 --> Config Class Initialized
INFO - 2023-02-06 06:24:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:24:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:24:59 --> Utf8 Class Initialized
INFO - 2023-02-06 06:24:59 --> URI Class Initialized
INFO - 2023-02-06 06:24:59 --> Router Class Initialized
INFO - 2023-02-06 06:24:59 --> Output Class Initialized
INFO - 2023-02-06 06:24:59 --> Security Class Initialized
DEBUG - 2023-02-06 06:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:24:59 --> Input Class Initialized
INFO - 2023-02-06 06:24:59 --> Language Class Initialized
INFO - 2023-02-06 06:24:59 --> Loader Class Initialized
INFO - 2023-02-06 06:24:59 --> Controller Class Initialized
DEBUG - 2023-02-06 06:24:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:24:59 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:24:59 --> Database Driver Class Initialized
INFO - 2023-02-06 06:24:59 --> Model "Login_model" initialized
INFO - 2023-02-06 06:24:59 --> Final output sent to browser
DEBUG - 2023-02-06 06:24:59 --> Total execution time: 0.4117
INFO - 2023-02-06 06:25:10 --> Config Class Initialized
INFO - 2023-02-06 06:25:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:10 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:10 --> URI Class Initialized
INFO - 2023-02-06 06:25:10 --> Router Class Initialized
INFO - 2023-02-06 06:25:10 --> Output Class Initialized
INFO - 2023-02-06 06:25:10 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:10 --> Input Class Initialized
INFO - 2023-02-06 06:25:10 --> Language Class Initialized
INFO - 2023-02-06 06:25:10 --> Loader Class Initialized
INFO - 2023-02-06 06:25:10 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:10 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:10 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:10 --> Total execution time: 0.1351
INFO - 2023-02-06 06:25:10 --> Config Class Initialized
INFO - 2023-02-06 06:25:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:10 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:10 --> URI Class Initialized
INFO - 2023-02-06 06:25:10 --> Router Class Initialized
INFO - 2023-02-06 06:25:10 --> Output Class Initialized
INFO - 2023-02-06 06:25:10 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:10 --> Input Class Initialized
INFO - 2023-02-06 06:25:10 --> Language Class Initialized
INFO - 2023-02-06 06:25:10 --> Loader Class Initialized
INFO - 2023-02-06 06:25:10 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:10 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:10 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:10 --> Total execution time: 0.1320
INFO - 2023-02-06 06:25:12 --> Config Class Initialized
INFO - 2023-02-06 06:25:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:12 --> URI Class Initialized
INFO - 2023-02-06 06:25:12 --> Router Class Initialized
INFO - 2023-02-06 06:25:12 --> Output Class Initialized
INFO - 2023-02-06 06:25:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:12 --> Input Class Initialized
INFO - 2023-02-06 06:25:12 --> Language Class Initialized
INFO - 2023-02-06 06:25:12 --> Loader Class Initialized
INFO - 2023-02-06 06:25:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:12 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:12 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:12 --> Total execution time: 0.2043
INFO - 2023-02-06 06:25:12 --> Config Class Initialized
INFO - 2023-02-06 06:25:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:12 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:12 --> URI Class Initialized
INFO - 2023-02-06 06:25:12 --> Router Class Initialized
INFO - 2023-02-06 06:25:12 --> Output Class Initialized
INFO - 2023-02-06 06:25:12 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:12 --> Input Class Initialized
INFO - 2023-02-06 06:25:12 --> Language Class Initialized
INFO - 2023-02-06 06:25:12 --> Loader Class Initialized
INFO - 2023-02-06 06:25:12 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:12 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:13 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:13 --> Total execution time: 0.2036
INFO - 2023-02-06 06:25:14 --> Config Class Initialized
INFO - 2023-02-06 06:25:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:14 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:14 --> URI Class Initialized
INFO - 2023-02-06 06:25:14 --> Router Class Initialized
INFO - 2023-02-06 06:25:14 --> Output Class Initialized
INFO - 2023-02-06 06:25:14 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:14 --> Input Class Initialized
INFO - 2023-02-06 06:25:14 --> Language Class Initialized
INFO - 2023-02-06 06:25:14 --> Loader Class Initialized
INFO - 2023-02-06 06:25:14 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:14 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:14 --> Total execution time: 0.0050
INFO - 2023-02-06 06:25:14 --> Config Class Initialized
INFO - 2023-02-06 06:25:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:14 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:14 --> URI Class Initialized
INFO - 2023-02-06 06:25:14 --> Router Class Initialized
INFO - 2023-02-06 06:25:14 --> Output Class Initialized
INFO - 2023-02-06 06:25:14 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:14 --> Input Class Initialized
INFO - 2023-02-06 06:25:14 --> Language Class Initialized
INFO - 2023-02-06 06:25:14 --> Loader Class Initialized
INFO - 2023-02-06 06:25:14 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:14 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:14 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:25:14 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:14 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:14 --> Total execution time: 0.1180
INFO - 2023-02-06 06:25:17 --> Config Class Initialized
INFO - 2023-02-06 06:25:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:17 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:17 --> URI Class Initialized
INFO - 2023-02-06 06:25:17 --> Router Class Initialized
INFO - 2023-02-06 06:25:17 --> Output Class Initialized
INFO - 2023-02-06 06:25:17 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:17 --> Input Class Initialized
INFO - 2023-02-06 06:25:17 --> Language Class Initialized
INFO - 2023-02-06 06:25:17 --> Loader Class Initialized
INFO - 2023-02-06 06:25:17 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:17 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:17 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:25:17 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:17 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:17 --> Total execution time: 0.1173
INFO - 2023-02-06 06:25:17 --> Config Class Initialized
INFO - 2023-02-06 06:25:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:17 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:17 --> URI Class Initialized
INFO - 2023-02-06 06:25:17 --> Router Class Initialized
INFO - 2023-02-06 06:25:17 --> Output Class Initialized
INFO - 2023-02-06 06:25:17 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:17 --> Input Class Initialized
INFO - 2023-02-06 06:25:17 --> Language Class Initialized
INFO - 2023-02-06 06:25:17 --> Loader Class Initialized
INFO - 2023-02-06 06:25:17 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:17 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:17 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:25:17 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:17 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:17 --> Total execution time: 0.1177
INFO - 2023-02-06 06:25:17 --> Config Class Initialized
INFO - 2023-02-06 06:25:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:17 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:17 --> URI Class Initialized
INFO - 2023-02-06 06:25:17 --> Router Class Initialized
INFO - 2023-02-06 06:25:17 --> Output Class Initialized
INFO - 2023-02-06 06:25:17 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:17 --> Input Class Initialized
INFO - 2023-02-06 06:25:17 --> Language Class Initialized
INFO - 2023-02-06 06:25:17 --> Loader Class Initialized
INFO - 2023-02-06 06:25:17 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:17 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:17 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:25:18 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:18 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:18 --> Total execution time: 0.1561
INFO - 2023-02-06 06:25:18 --> Config Class Initialized
INFO - 2023-02-06 06:25:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:18 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:18 --> URI Class Initialized
INFO - 2023-02-06 06:25:18 --> Router Class Initialized
INFO - 2023-02-06 06:25:18 --> Output Class Initialized
INFO - 2023-02-06 06:25:18 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:18 --> Input Class Initialized
INFO - 2023-02-06 06:25:18 --> Language Class Initialized
INFO - 2023-02-06 06:25:18 --> Loader Class Initialized
INFO - 2023-02-06 06:25:18 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:18 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:18 --> Model "Mysql_model" initialized
INFO - 2023-02-06 06:25:18 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:18 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:18 --> Total execution time: 0.1165
INFO - 2023-02-06 06:25:19 --> Config Class Initialized
INFO - 2023-02-06 06:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:19 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:19 --> URI Class Initialized
INFO - 2023-02-06 06:25:19 --> Router Class Initialized
INFO - 2023-02-06 06:25:19 --> Output Class Initialized
INFO - 2023-02-06 06:25:19 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:19 --> Input Class Initialized
INFO - 2023-02-06 06:25:19 --> Language Class Initialized
INFO - 2023-02-06 06:25:19 --> Loader Class Initialized
INFO - 2023-02-06 06:25:19 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:19 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:19 --> Total execution time: 0.0220
INFO - 2023-02-06 06:25:19 --> Config Class Initialized
INFO - 2023-02-06 06:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:19 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:19 --> URI Class Initialized
INFO - 2023-02-06 06:25:19 --> Router Class Initialized
INFO - 2023-02-06 06:25:19 --> Output Class Initialized
INFO - 2023-02-06 06:25:19 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:19 --> Input Class Initialized
INFO - 2023-02-06 06:25:19 --> Language Class Initialized
INFO - 2023-02-06 06:25:19 --> Loader Class Initialized
INFO - 2023-02-06 06:25:19 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:19 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:19 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:19 --> Total execution time: 0.0204
INFO - 2023-02-06 06:25:21 --> Config Class Initialized
INFO - 2023-02-06 06:25:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:21 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:21 --> URI Class Initialized
INFO - 2023-02-06 06:25:21 --> Router Class Initialized
INFO - 2023-02-06 06:25:21 --> Output Class Initialized
INFO - 2023-02-06 06:25:21 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:21 --> Input Class Initialized
INFO - 2023-02-06 06:25:21 --> Language Class Initialized
INFO - 2023-02-06 06:25:21 --> Loader Class Initialized
INFO - 2023-02-06 06:25:21 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:21 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:21 --> Total execution time: 0.0021
INFO - 2023-02-06 06:25:21 --> Config Class Initialized
INFO - 2023-02-06 06:25:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:21 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:21 --> URI Class Initialized
INFO - 2023-02-06 06:25:21 --> Router Class Initialized
INFO - 2023-02-06 06:25:21 --> Output Class Initialized
INFO - 2023-02-06 06:25:21 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:21 --> Input Class Initialized
INFO - 2023-02-06 06:25:21 --> Language Class Initialized
INFO - 2023-02-06 06:25:21 --> Loader Class Initialized
INFO - 2023-02-06 06:25:21 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:21 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:21 --> Model "PGsql_model" initialized
INFO - 2023-02-06 06:25:21 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:21 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:21 --> Total execution time: 0.0664
INFO - 2023-02-06 06:25:30 --> Config Class Initialized
INFO - 2023-02-06 06:25:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:30 --> URI Class Initialized
INFO - 2023-02-06 06:25:30 --> Router Class Initialized
INFO - 2023-02-06 06:25:30 --> Output Class Initialized
INFO - 2023-02-06 06:25:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:30 --> Input Class Initialized
INFO - 2023-02-06 06:25:30 --> Language Class Initialized
INFO - 2023-02-06 06:25:30 --> Loader Class Initialized
INFO - 2023-02-06 06:25:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:30 --> Total execution time: 0.0036
INFO - 2023-02-06 06:25:30 --> Config Class Initialized
INFO - 2023-02-06 06:25:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:25:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:25:30 --> Utf8 Class Initialized
INFO - 2023-02-06 06:25:30 --> URI Class Initialized
INFO - 2023-02-06 06:25:30 --> Router Class Initialized
INFO - 2023-02-06 06:25:30 --> Output Class Initialized
INFO - 2023-02-06 06:25:30 --> Security Class Initialized
DEBUG - 2023-02-06 06:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:25:30 --> Input Class Initialized
INFO - 2023-02-06 06:25:30 --> Language Class Initialized
INFO - 2023-02-06 06:25:30 --> Loader Class Initialized
INFO - 2023-02-06 06:25:30 --> Controller Class Initialized
DEBUG - 2023-02-06 06:25:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:25:30 --> Database Driver Class Initialized
INFO - 2023-02-06 06:25:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:25:30 --> Model "PGsql_model" initialized
INFO - 2023-02-06 06:25:30 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:25:30 --> Final output sent to browser
DEBUG - 2023-02-06 06:25:30 --> Total execution time: 0.0226
INFO - 2023-02-06 06:26:58 --> Config Class Initialized
INFO - 2023-02-06 06:26:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:26:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:26:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:26:58 --> URI Class Initialized
INFO - 2023-02-06 06:26:58 --> Router Class Initialized
INFO - 2023-02-06 06:26:58 --> Output Class Initialized
INFO - 2023-02-06 06:26:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:26:58 --> Input Class Initialized
INFO - 2023-02-06 06:26:58 --> Language Class Initialized
INFO - 2023-02-06 06:26:58 --> Loader Class Initialized
INFO - 2023-02-06 06:26:58 --> Controller Class Initialized
DEBUG - 2023-02-06 06:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:26:58 --> Final output sent to browser
DEBUG - 2023-02-06 06:26:58 --> Total execution time: 0.0056
INFO - 2023-02-06 06:26:58 --> Config Class Initialized
INFO - 2023-02-06 06:26:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:26:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:26:58 --> Utf8 Class Initialized
INFO - 2023-02-06 06:26:58 --> URI Class Initialized
INFO - 2023-02-06 06:26:58 --> Router Class Initialized
INFO - 2023-02-06 06:26:58 --> Output Class Initialized
INFO - 2023-02-06 06:26:58 --> Security Class Initialized
DEBUG - 2023-02-06 06:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:26:58 --> Input Class Initialized
INFO - 2023-02-06 06:26:58 --> Language Class Initialized
INFO - 2023-02-06 06:26:58 --> Loader Class Initialized
INFO - 2023-02-06 06:26:58 --> Controller Class Initialized
DEBUG - 2023-02-06 06:26:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:26:58 --> Database Driver Class Initialized
INFO - 2023-02-06 06:26:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:26:58 --> Model "PGsql_model" initialized
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
INFO - 2023-02-06 06:59:54 --> Helper loaded: form_helper
INFO - 2023-02-06 06:59:54 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Model "Change_model" initialized
INFO - 2023-02-06 06:59:54 --> Model "Grafana_model" initialized
INFO - 2023-02-06 06:59:54 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:54 --> Total execution time: 0.0233
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
INFO - 2023-02-06 06:59:54 --> Helper loaded: form_helper
INFO - 2023-02-06 06:59:54 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:54 --> Total execution time: 0.0047
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
INFO - 2023-02-06 06:59:54 --> Helper loaded: form_helper
INFO - 2023-02-06 06:59:54 --> Helper loaded: url_helper
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:54 --> Model "Login_model" initialized
INFO - 2023-02-06 06:59:54 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:54 --> Total execution time: 0.0151
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:59:54 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:54 --> Total execution time: 0.0135
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:59:54 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:54 --> Total execution time: 0.0132
INFO - 2023-02-06 06:59:54 --> Config Class Initialized
INFO - 2023-02-06 06:59:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:54 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:54 --> URI Class Initialized
INFO - 2023-02-06 06:59:54 --> Router Class Initialized
INFO - 2023-02-06 06:59:54 --> Output Class Initialized
INFO - 2023-02-06 06:59:54 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:54 --> Input Class Initialized
INFO - 2023-02-06 06:59:54 --> Language Class Initialized
INFO - 2023-02-06 06:59:54 --> Loader Class Initialized
INFO - 2023-02-06 06:59:54 --> Controller Class Initialized
DEBUG - 2023-02-06 06:59:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:54 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:59:54 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:55 --> Model "Login_model" initialized
INFO - 2023-02-06 06:59:55 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:55 --> Total execution time: 0.0782
INFO - 2023-02-06 06:59:55 --> Config Class Initialized
INFO - 2023-02-06 06:59:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 06:59:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 06:59:55 --> Utf8 Class Initialized
INFO - 2023-02-06 06:59:55 --> URI Class Initialized
INFO - 2023-02-06 06:59:55 --> Router Class Initialized
INFO - 2023-02-06 06:59:55 --> Output Class Initialized
INFO - 2023-02-06 06:59:55 --> Security Class Initialized
DEBUG - 2023-02-06 06:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 06:59:55 --> Input Class Initialized
INFO - 2023-02-06 06:59:55 --> Language Class Initialized
INFO - 2023-02-06 06:59:55 --> Loader Class Initialized
INFO - 2023-02-06 06:59:55 --> Controller Class Initialized
DEBUG - 2023-02-06 06:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 06:59:55 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 06:59:55 --> Database Driver Class Initialized
INFO - 2023-02-06 06:59:55 --> Model "Login_model" initialized
INFO - 2023-02-06 06:59:55 --> Final output sent to browser
DEBUG - 2023-02-06 06:59:55 --> Total execution time: 0.0379
INFO - 2023-02-06 07:16:21 --> Config Class Initialized
INFO - 2023-02-06 07:16:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:16:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:16:21 --> Utf8 Class Initialized
INFO - 2023-02-06 07:16:21 --> URI Class Initialized
INFO - 2023-02-06 07:16:21 --> Router Class Initialized
INFO - 2023-02-06 07:16:21 --> Output Class Initialized
INFO - 2023-02-06 07:16:21 --> Security Class Initialized
DEBUG - 2023-02-06 07:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:16:21 --> Input Class Initialized
INFO - 2023-02-06 07:16:21 --> Language Class Initialized
INFO - 2023-02-06 07:16:21 --> Loader Class Initialized
INFO - 2023-02-06 07:16:21 --> Controller Class Initialized
INFO - 2023-02-06 07:16:21 --> Helper loaded: form_helper
INFO - 2023-02-06 07:16:21 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:16:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:16:21 --> Model "Change_model" initialized
INFO - 2023-02-06 07:16:21 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:24:00 --> Config Class Initialized
INFO - 2023-02-06 07:24:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:24:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:24:00 --> Utf8 Class Initialized
INFO - 2023-02-06 07:24:00 --> URI Class Initialized
INFO - 2023-02-06 07:24:00 --> Router Class Initialized
INFO - 2023-02-06 07:24:00 --> Output Class Initialized
INFO - 2023-02-06 07:24:00 --> Security Class Initialized
DEBUG - 2023-02-06 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:24:00 --> Input Class Initialized
INFO - 2023-02-06 07:24:00 --> Language Class Initialized
INFO - 2023-02-06 07:24:00 --> Loader Class Initialized
INFO - 2023-02-06 07:24:00 --> Controller Class Initialized
INFO - 2023-02-06 07:24:00 --> Helper loaded: form_helper
INFO - 2023-02-06 07:24:00 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:24:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:24:00 --> Model "Change_model" initialized
INFO - 2023-02-06 07:24:11 --> Config Class Initialized
INFO - 2023-02-06 07:24:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:24:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:24:11 --> Utf8 Class Initialized
INFO - 2023-02-06 07:24:11 --> URI Class Initialized
INFO - 2023-02-06 07:24:11 --> Router Class Initialized
INFO - 2023-02-06 07:24:11 --> Output Class Initialized
INFO - 2023-02-06 07:24:11 --> Security Class Initialized
DEBUG - 2023-02-06 07:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:24:11 --> Input Class Initialized
INFO - 2023-02-06 07:24:11 --> Language Class Initialized
INFO - 2023-02-06 07:24:11 --> Loader Class Initialized
INFO - 2023-02-06 07:24:11 --> Controller Class Initialized
INFO - 2023-02-06 07:24:11 --> Helper loaded: form_helper
INFO - 2023-02-06 07:24:11 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:24:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:24:11 --> Model "Change_model" initialized
INFO - 2023-02-06 07:28:27 --> Config Class Initialized
INFO - 2023-02-06 07:28:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:28:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:28:27 --> Utf8 Class Initialized
INFO - 2023-02-06 07:28:27 --> URI Class Initialized
INFO - 2023-02-06 07:28:27 --> Router Class Initialized
INFO - 2023-02-06 07:28:27 --> Output Class Initialized
INFO - 2023-02-06 07:28:27 --> Security Class Initialized
DEBUG - 2023-02-06 07:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:28:27 --> Input Class Initialized
INFO - 2023-02-06 07:28:27 --> Language Class Initialized
INFO - 2023-02-06 07:28:27 --> Loader Class Initialized
INFO - 2023-02-06 07:28:27 --> Controller Class Initialized
INFO - 2023-02-06 07:28:27 --> Helper loaded: form_helper
INFO - 2023-02-06 07:28:27 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:28:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:28:27 --> Model "Change_model" initialized
INFO - 2023-02-06 07:28:27 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:30:00 --> Config Class Initialized
INFO - 2023-02-06 07:30:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:00 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:00 --> URI Class Initialized
INFO - 2023-02-06 07:30:00 --> Router Class Initialized
INFO - 2023-02-06 07:30:00 --> Output Class Initialized
INFO - 2023-02-06 07:30:00 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:00 --> Input Class Initialized
INFO - 2023-02-06 07:30:00 --> Language Class Initialized
INFO - 2023-02-06 07:30:00 --> Loader Class Initialized
INFO - 2023-02-06 07:30:00 --> Controller Class Initialized
INFO - 2023-02-06 07:30:00 --> Helper loaded: form_helper
INFO - 2023-02-06 07:30:00 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:30:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:00 --> Model "Change_model" initialized
INFO - 2023-02-06 07:30:01 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:30:01 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:01 --> Total execution time: 0.3273
INFO - 2023-02-06 07:30:01 --> Config Class Initialized
INFO - 2023-02-06 07:30:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:01 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:01 --> URI Class Initialized
INFO - 2023-02-06 07:30:01 --> Router Class Initialized
INFO - 2023-02-06 07:30:01 --> Output Class Initialized
INFO - 2023-02-06 07:30:01 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:01 --> Input Class Initialized
INFO - 2023-02-06 07:30:01 --> Language Class Initialized
INFO - 2023-02-06 07:30:01 --> Loader Class Initialized
INFO - 2023-02-06 07:30:01 --> Controller Class Initialized
INFO - 2023-02-06 07:30:01 --> Helper loaded: form_helper
INFO - 2023-02-06 07:30:01 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:30:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:01 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:01 --> Total execution time: 0.0031
INFO - 2023-02-06 07:30:01 --> Config Class Initialized
INFO - 2023-02-06 07:30:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:01 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:01 --> URI Class Initialized
INFO - 2023-02-06 07:30:01 --> Router Class Initialized
INFO - 2023-02-06 07:30:01 --> Output Class Initialized
INFO - 2023-02-06 07:30:01 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:01 --> Input Class Initialized
INFO - 2023-02-06 07:30:01 --> Language Class Initialized
INFO - 2023-02-06 07:30:01 --> Loader Class Initialized
INFO - 2023-02-06 07:30:01 --> Controller Class Initialized
INFO - 2023-02-06 07:30:01 --> Helper loaded: form_helper
INFO - 2023-02-06 07:30:01 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:30:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:01 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Login_model" initialized
INFO - 2023-02-06 07:30:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:02 --> Total execution time: 1.1537
INFO - 2023-02-06 07:30:02 --> Config Class Initialized
INFO - 2023-02-06 07:30:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:02 --> URI Class Initialized
INFO - 2023-02-06 07:30:02 --> Router Class Initialized
INFO - 2023-02-06 07:30:02 --> Output Class Initialized
INFO - 2023-02-06 07:30:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:02 --> Input Class Initialized
INFO - 2023-02-06 07:30:02 --> Language Class Initialized
INFO - 2023-02-06 07:30:02 --> Loader Class Initialized
INFO - 2023-02-06 07:30:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:30:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:02 --> Total execution time: 0.1282
INFO - 2023-02-06 07:30:02 --> Config Class Initialized
INFO - 2023-02-06 07:30:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:02 --> URI Class Initialized
INFO - 2023-02-06 07:30:02 --> Router Class Initialized
INFO - 2023-02-06 07:30:02 --> Output Class Initialized
INFO - 2023-02-06 07:30:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:02 --> Input Class Initialized
INFO - 2023-02-06 07:30:02 --> Language Class Initialized
INFO - 2023-02-06 07:30:02 --> Loader Class Initialized
INFO - 2023-02-06 07:30:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:30:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:02 --> Total execution time: 0.0854
INFO - 2023-02-06 07:30:02 --> Config Class Initialized
INFO - 2023-02-06 07:30:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:02 --> URI Class Initialized
INFO - 2023-02-06 07:30:02 --> Router Class Initialized
INFO - 2023-02-06 07:30:02 --> Output Class Initialized
INFO - 2023-02-06 07:30:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:02 --> Input Class Initialized
INFO - 2023-02-06 07:30:02 --> Language Class Initialized
INFO - 2023-02-06 07:30:02 --> Loader Class Initialized
INFO - 2023-02-06 07:30:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:30:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Login_model" initialized
INFO - 2023-02-06 07:30:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:02 --> Total execution time: 0.1262
INFO - 2023-02-06 07:30:02 --> Config Class Initialized
INFO - 2023-02-06 07:30:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:30:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:30:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:30:02 --> URI Class Initialized
INFO - 2023-02-06 07:30:02 --> Router Class Initialized
INFO - 2023-02-06 07:30:02 --> Output Class Initialized
INFO - 2023-02-06 07:30:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:30:02 --> Input Class Initialized
INFO - 2023-02-06 07:30:02 --> Language Class Initialized
INFO - 2023-02-06 07:30:02 --> Loader Class Initialized
INFO - 2023-02-06 07:30:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:30:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:30:03 --> Database Driver Class Initialized
INFO - 2023-02-06 07:30:03 --> Model "Login_model" initialized
INFO - 2023-02-06 07:30:03 --> Final output sent to browser
DEBUG - 2023-02-06 07:30:03 --> Total execution time: 0.0449
INFO - 2023-02-06 07:35:57 --> Config Class Initialized
INFO - 2023-02-06 07:35:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:35:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:35:57 --> Utf8 Class Initialized
INFO - 2023-02-06 07:35:57 --> URI Class Initialized
INFO - 2023-02-06 07:35:57 --> Router Class Initialized
INFO - 2023-02-06 07:35:57 --> Output Class Initialized
INFO - 2023-02-06 07:35:57 --> Security Class Initialized
DEBUG - 2023-02-06 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:35:57 --> Input Class Initialized
INFO - 2023-02-06 07:35:57 --> Language Class Initialized
INFO - 2023-02-06 07:35:57 --> Loader Class Initialized
INFO - 2023-02-06 07:35:57 --> Controller Class Initialized
DEBUG - 2023-02-06 07:35:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:35:57 --> Database Driver Class Initialized
INFO - 2023-02-06 07:35:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:35:58 --> Database Driver Class Initialized
INFO - 2023-02-06 07:35:58 --> Model "Login_model" initialized
INFO - 2023-02-06 07:35:58 --> Final output sent to browser
DEBUG - 2023-02-06 07:35:58 --> Total execution time: 0.5362
INFO - 2023-02-06 07:35:58 --> Config Class Initialized
INFO - 2023-02-06 07:35:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:35:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:35:58 --> Utf8 Class Initialized
INFO - 2023-02-06 07:35:58 --> URI Class Initialized
INFO - 2023-02-06 07:35:58 --> Router Class Initialized
INFO - 2023-02-06 07:35:58 --> Output Class Initialized
INFO - 2023-02-06 07:35:58 --> Security Class Initialized
DEBUG - 2023-02-06 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:35:58 --> Input Class Initialized
INFO - 2023-02-06 07:35:58 --> Language Class Initialized
INFO - 2023-02-06 07:35:58 --> Loader Class Initialized
INFO - 2023-02-06 07:35:58 --> Controller Class Initialized
DEBUG - 2023-02-06 07:35:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:35:58 --> Database Driver Class Initialized
INFO - 2023-02-06 07:35:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:35:58 --> Database Driver Class Initialized
INFO - 2023-02-06 07:35:58 --> Model "Login_model" initialized
INFO - 2023-02-06 07:35:58 --> Final output sent to browser
DEBUG - 2023-02-06 07:35:58 --> Total execution time: 0.4662
INFO - 2023-02-06 07:36:02 --> Config Class Initialized
INFO - 2023-02-06 07:36:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:02 --> URI Class Initialized
INFO - 2023-02-06 07:36:02 --> Router Class Initialized
INFO - 2023-02-06 07:36:02 --> Output Class Initialized
INFO - 2023-02-06 07:36:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:02 --> Input Class Initialized
INFO - 2023-02-06 07:36:02 --> Language Class Initialized
INFO - 2023-02-06 07:36:02 --> Loader Class Initialized
INFO - 2023-02-06 07:36:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:02 --> Total execution time: 0.1271
INFO - 2023-02-06 07:36:02 --> Config Class Initialized
INFO - 2023-02-06 07:36:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:02 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:02 --> URI Class Initialized
INFO - 2023-02-06 07:36:02 --> Router Class Initialized
INFO - 2023-02-06 07:36:02 --> Output Class Initialized
INFO - 2023-02-06 07:36:02 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:02 --> Input Class Initialized
INFO - 2023-02-06 07:36:02 --> Language Class Initialized
INFO - 2023-02-06 07:36:02 --> Loader Class Initialized
INFO - 2023-02-06 07:36:02 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:02 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:02 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:02 --> Total execution time: 0.1554
INFO - 2023-02-06 07:36:03 --> Config Class Initialized
INFO - 2023-02-06 07:36:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:03 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:03 --> URI Class Initialized
INFO - 2023-02-06 07:36:03 --> Router Class Initialized
INFO - 2023-02-06 07:36:03 --> Output Class Initialized
INFO - 2023-02-06 07:36:03 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:03 --> Input Class Initialized
INFO - 2023-02-06 07:36:03 --> Language Class Initialized
INFO - 2023-02-06 07:36:03 --> Loader Class Initialized
INFO - 2023-02-06 07:36:03 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:03 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:03 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:03 --> Total execution time: 0.2342
INFO - 2023-02-06 07:36:03 --> Config Class Initialized
INFO - 2023-02-06 07:36:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:03 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:03 --> URI Class Initialized
INFO - 2023-02-06 07:36:03 --> Router Class Initialized
INFO - 2023-02-06 07:36:03 --> Output Class Initialized
INFO - 2023-02-06 07:36:03 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:03 --> Input Class Initialized
INFO - 2023-02-06 07:36:03 --> Language Class Initialized
INFO - 2023-02-06 07:36:03 --> Loader Class Initialized
INFO - 2023-02-06 07:36:03 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:03 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:03 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:03 --> Total execution time: 0.1560
INFO - 2023-02-06 07:36:04 --> Config Class Initialized
INFO - 2023-02-06 07:36:04 --> Hooks Class Initialized
INFO - 2023-02-06 07:36:04 --> Config Class Initialized
DEBUG - 2023-02-06 07:36:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:04 --> Hooks Class Initialized
INFO - 2023-02-06 07:36:04 --> Utf8 Class Initialized
DEBUG - 2023-02-06 07:36:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:04 --> URI Class Initialized
INFO - 2023-02-06 07:36:04 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:04 --> Router Class Initialized
INFO - 2023-02-06 07:36:04 --> URI Class Initialized
INFO - 2023-02-06 07:36:04 --> Output Class Initialized
INFO - 2023-02-06 07:36:04 --> Router Class Initialized
INFO - 2023-02-06 07:36:04 --> Security Class Initialized
INFO - 2023-02-06 07:36:04 --> Output Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:04 --> Input Class Initialized
INFO - 2023-02-06 07:36:04 --> Security Class Initialized
INFO - 2023-02-06 07:36:04 --> Language Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:04 --> Input Class Initialized
INFO - 2023-02-06 07:36:04 --> Loader Class Initialized
INFO - 2023-02-06 07:36:04 --> Language Class Initialized
INFO - 2023-02-06 07:36:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:04 --> Loader Class Initialized
INFO - 2023-02-06 07:36:04 --> Final output sent to browser
INFO - 2023-02-06 07:36:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Total execution time: 0.0042
DEBUG - 2023-02-06 07:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:04 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:04 --> Config Class Initialized
INFO - 2023-02-06 07:36:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:04 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:04 --> URI Class Initialized
INFO - 2023-02-06 07:36:04 --> Router Class Initialized
INFO - 2023-02-06 07:36:04 --> Output Class Initialized
INFO - 2023-02-06 07:36:04 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:04 --> Input Class Initialized
INFO - 2023-02-06 07:36:04 --> Language Class Initialized
INFO - 2023-02-06 07:36:04 --> Loader Class Initialized
INFO - 2023-02-06 07:36:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:04 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:04 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:04 --> Total execution time: 0.1235
INFO - 2023-02-06 07:36:04 --> Final output sent to browser
INFO - 2023-02-06 07:36:04 --> Config Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Total execution time: 0.1222
INFO - 2023-02-06 07:36:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:04 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:04 --> URI Class Initialized
INFO - 2023-02-06 07:36:04 --> Router Class Initialized
INFO - 2023-02-06 07:36:04 --> Output Class Initialized
INFO - 2023-02-06 07:36:04 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:04 --> Input Class Initialized
INFO - 2023-02-06 07:36:04 --> Language Class Initialized
INFO - 2023-02-06 07:36:04 --> Loader Class Initialized
INFO - 2023-02-06 07:36:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:04 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:05 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:05 --> Total execution time: 0.2165
INFO - 2023-02-06 07:36:06 --> Config Class Initialized
INFO - 2023-02-06 07:36:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:06 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:06 --> URI Class Initialized
INFO - 2023-02-06 07:36:06 --> Router Class Initialized
INFO - 2023-02-06 07:36:06 --> Output Class Initialized
INFO - 2023-02-06 07:36:06 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:06 --> Input Class Initialized
INFO - 2023-02-06 07:36:06 --> Language Class Initialized
INFO - 2023-02-06 07:36:06 --> Loader Class Initialized
INFO - 2023-02-06 07:36:06 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:06 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:06 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:06 --> Total execution time: 0.2317
INFO - 2023-02-06 07:36:06 --> Config Class Initialized
INFO - 2023-02-06 07:36:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:06 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:06 --> URI Class Initialized
INFO - 2023-02-06 07:36:06 --> Router Class Initialized
INFO - 2023-02-06 07:36:06 --> Output Class Initialized
INFO - 2023-02-06 07:36:06 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:06 --> Input Class Initialized
INFO - 2023-02-06 07:36:06 --> Language Class Initialized
INFO - 2023-02-06 07:36:06 --> Loader Class Initialized
INFO - 2023-02-06 07:36:06 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:06 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:06 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:06 --> Total execution time: 0.2673
INFO - 2023-02-06 07:36:11 --> Config Class Initialized
INFO - 2023-02-06 07:36:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:11 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:11 --> URI Class Initialized
INFO - 2023-02-06 07:36:11 --> Router Class Initialized
INFO - 2023-02-06 07:36:11 --> Output Class Initialized
INFO - 2023-02-06 07:36:11 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:11 --> Input Class Initialized
INFO - 2023-02-06 07:36:11 --> Language Class Initialized
INFO - 2023-02-06 07:36:11 --> Loader Class Initialized
INFO - 2023-02-06 07:36:11 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:11 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:11 --> Total execution time: 0.0092
INFO - 2023-02-06 07:36:11 --> Config Class Initialized
INFO - 2023-02-06 07:36:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:11 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:11 --> URI Class Initialized
INFO - 2023-02-06 07:36:11 --> Router Class Initialized
INFO - 2023-02-06 07:36:11 --> Output Class Initialized
INFO - 2023-02-06 07:36:11 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:11 --> Input Class Initialized
INFO - 2023-02-06 07:36:11 --> Language Class Initialized
INFO - 2023-02-06 07:36:11 --> Loader Class Initialized
INFO - 2023-02-06 07:36:11 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:11 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:11 --> Model "Mysql_model" initialized
INFO - 2023-02-06 07:36:11 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:36:11 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:11 --> Total execution time: 0.1616
INFO - 2023-02-06 07:36:30 --> Config Class Initialized
INFO - 2023-02-06 07:36:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:30 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:30 --> URI Class Initialized
INFO - 2023-02-06 07:36:30 --> Router Class Initialized
INFO - 2023-02-06 07:36:30 --> Output Class Initialized
INFO - 2023-02-06 07:36:30 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:30 --> Input Class Initialized
INFO - 2023-02-06 07:36:30 --> Language Class Initialized
INFO - 2023-02-06 07:36:30 --> Loader Class Initialized
INFO - 2023-02-06 07:36:30 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:30 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:30 --> Total execution time: 0.0854
INFO - 2023-02-06 07:36:40 --> Config Class Initialized
INFO - 2023-02-06 07:36:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:40 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:40 --> URI Class Initialized
INFO - 2023-02-06 07:36:40 --> Router Class Initialized
INFO - 2023-02-06 07:36:40 --> Output Class Initialized
INFO - 2023-02-06 07:36:40 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:40 --> Input Class Initialized
INFO - 2023-02-06 07:36:40 --> Language Class Initialized
INFO - 2023-02-06 07:36:40 --> Loader Class Initialized
INFO - 2023-02-06 07:36:40 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:40 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:40 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:40 --> Model "Login_model" initialized
INFO - 2023-02-06 07:36:40 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:40 --> Total execution time: 0.2050
INFO - 2023-02-06 07:36:40 --> Config Class Initialized
INFO - 2023-02-06 07:36:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:40 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:40 --> URI Class Initialized
INFO - 2023-02-06 07:36:40 --> Router Class Initialized
INFO - 2023-02-06 07:36:40 --> Output Class Initialized
INFO - 2023-02-06 07:36:40 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:40 --> Input Class Initialized
INFO - 2023-02-06 07:36:40 --> Language Class Initialized
INFO - 2023-02-06 07:36:40 --> Loader Class Initialized
INFO - 2023-02-06 07:36:40 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:40 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:40 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:40 --> Model "Login_model" initialized
INFO - 2023-02-06 07:36:40 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:40 --> Total execution time: 0.0364
INFO - 2023-02-06 07:36:45 --> Config Class Initialized
INFO - 2023-02-06 07:36:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:45 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:45 --> URI Class Initialized
INFO - 2023-02-06 07:36:45 --> Router Class Initialized
INFO - 2023-02-06 07:36:45 --> Output Class Initialized
INFO - 2023-02-06 07:36:45 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:45 --> Input Class Initialized
INFO - 2023-02-06 07:36:45 --> Language Class Initialized
INFO - 2023-02-06 07:36:45 --> Loader Class Initialized
INFO - 2023-02-06 07:36:45 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:45 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:45 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:45 --> Total execution time: 0.0205
INFO - 2023-02-06 07:36:45 --> Config Class Initialized
INFO - 2023-02-06 07:36:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:45 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:45 --> URI Class Initialized
INFO - 2023-02-06 07:36:45 --> Router Class Initialized
INFO - 2023-02-06 07:36:45 --> Output Class Initialized
INFO - 2023-02-06 07:36:45 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:45 --> Input Class Initialized
INFO - 2023-02-06 07:36:45 --> Language Class Initialized
INFO - 2023-02-06 07:36:45 --> Loader Class Initialized
INFO - 2023-02-06 07:36:45 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:45 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:46 --> Total execution time: 0.0579
INFO - 2023-02-06 07:36:48 --> Config Class Initialized
INFO - 2023-02-06 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:48 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:48 --> URI Class Initialized
INFO - 2023-02-06 07:36:48 --> Router Class Initialized
INFO - 2023-02-06 07:36:48 --> Output Class Initialized
INFO - 2023-02-06 07:36:48 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:48 --> Input Class Initialized
INFO - 2023-02-06 07:36:48 --> Language Class Initialized
INFO - 2023-02-06 07:36:48 --> Loader Class Initialized
INFO - 2023-02-06 07:36:48 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:48 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:48 --> Total execution time: 0.0041
INFO - 2023-02-06 07:36:48 --> Config Class Initialized
INFO - 2023-02-06 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:36:48 --> Utf8 Class Initialized
INFO - 2023-02-06 07:36:48 --> URI Class Initialized
INFO - 2023-02-06 07:36:48 --> Router Class Initialized
INFO - 2023-02-06 07:36:48 --> Output Class Initialized
INFO - 2023-02-06 07:36:48 --> Security Class Initialized
DEBUG - 2023-02-06 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:36:48 --> Input Class Initialized
INFO - 2023-02-06 07:36:48 --> Language Class Initialized
INFO - 2023-02-06 07:36:48 --> Loader Class Initialized
INFO - 2023-02-06 07:36:48 --> Controller Class Initialized
DEBUG - 2023-02-06 07:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:36:48 --> Database Driver Class Initialized
INFO - 2023-02-06 07:36:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:36:48 --> Model "PGsql_model" initialized
INFO - 2023-02-06 07:36:48 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:36:48 --> Final output sent to browser
DEBUG - 2023-02-06 07:36:48 --> Total execution time: 0.0175
INFO - 2023-02-06 07:37:27 --> Config Class Initialized
INFO - 2023-02-06 07:37:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:37:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:37:27 --> Utf8 Class Initialized
INFO - 2023-02-06 07:37:27 --> URI Class Initialized
INFO - 2023-02-06 07:37:27 --> Router Class Initialized
INFO - 2023-02-06 07:37:27 --> Output Class Initialized
INFO - 2023-02-06 07:37:27 --> Security Class Initialized
DEBUG - 2023-02-06 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:37:27 --> Input Class Initialized
INFO - 2023-02-06 07:37:27 --> Language Class Initialized
INFO - 2023-02-06 07:37:27 --> Loader Class Initialized
INFO - 2023-02-06 07:37:27 --> Controller Class Initialized
DEBUG - 2023-02-06 07:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:37:27 --> Final output sent to browser
DEBUG - 2023-02-06 07:37:27 --> Total execution time: 0.0049
INFO - 2023-02-06 07:37:27 --> Config Class Initialized
INFO - 2023-02-06 07:37:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:37:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:37:27 --> Utf8 Class Initialized
INFO - 2023-02-06 07:37:27 --> URI Class Initialized
INFO - 2023-02-06 07:37:27 --> Router Class Initialized
INFO - 2023-02-06 07:37:27 --> Output Class Initialized
INFO - 2023-02-06 07:37:27 --> Security Class Initialized
DEBUG - 2023-02-06 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:37:27 --> Input Class Initialized
INFO - 2023-02-06 07:37:27 --> Language Class Initialized
INFO - 2023-02-06 07:37:27 --> Loader Class Initialized
INFO - 2023-02-06 07:37:27 --> Controller Class Initialized
DEBUG - 2023-02-06 07:37:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:37:27 --> Database Driver Class Initialized
INFO - 2023-02-06 07:37:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:37:27 --> Model "PGsql_model" initialized
INFO - 2023-02-06 07:38:09 --> Config Class Initialized
INFO - 2023-02-06 07:38:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:38:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:38:09 --> Utf8 Class Initialized
INFO - 2023-02-06 07:38:09 --> URI Class Initialized
INFO - 2023-02-06 07:38:09 --> Router Class Initialized
INFO - 2023-02-06 07:38:09 --> Output Class Initialized
INFO - 2023-02-06 07:38:09 --> Security Class Initialized
DEBUG - 2023-02-06 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:38:09 --> Input Class Initialized
INFO - 2023-02-06 07:38:09 --> Language Class Initialized
INFO - 2023-02-06 07:38:09 --> Loader Class Initialized
INFO - 2023-02-06 07:38:09 --> Controller Class Initialized
DEBUG - 2023-02-06 07:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:38:09 --> Final output sent to browser
DEBUG - 2023-02-06 07:38:09 --> Total execution time: 0.0050
INFO - 2023-02-06 07:38:09 --> Config Class Initialized
INFO - 2023-02-06 07:38:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:38:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:38:09 --> Utf8 Class Initialized
INFO - 2023-02-06 07:38:09 --> URI Class Initialized
INFO - 2023-02-06 07:38:09 --> Router Class Initialized
INFO - 2023-02-06 07:38:09 --> Output Class Initialized
INFO - 2023-02-06 07:38:09 --> Security Class Initialized
DEBUG - 2023-02-06 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:38:09 --> Input Class Initialized
INFO - 2023-02-06 07:38:09 --> Language Class Initialized
INFO - 2023-02-06 07:38:09 --> Loader Class Initialized
INFO - 2023-02-06 07:38:09 --> Controller Class Initialized
DEBUG - 2023-02-06 07:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:38:09 --> Database Driver Class Initialized
INFO - 2023-02-06 07:38:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:38:09 --> Model "PGsql_model" initialized
INFO - 2023-02-06 07:38:09 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:39:47 --> Config Class Initialized
INFO - 2023-02-06 07:39:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:39:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:39:47 --> Utf8 Class Initialized
INFO - 2023-02-06 07:39:47 --> URI Class Initialized
INFO - 2023-02-06 07:39:47 --> Router Class Initialized
INFO - 2023-02-06 07:39:47 --> Output Class Initialized
INFO - 2023-02-06 07:39:47 --> Security Class Initialized
DEBUG - 2023-02-06 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:39:47 --> Input Class Initialized
INFO - 2023-02-06 07:39:47 --> Language Class Initialized
INFO - 2023-02-06 07:39:47 --> Loader Class Initialized
INFO - 2023-02-06 07:39:47 --> Controller Class Initialized
INFO - 2023-02-06 07:39:47 --> Helper loaded: form_helper
INFO - 2023-02-06 07:39:47 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:39:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:39:47 --> Model "Change_model" initialized
INFO - 2023-02-06 07:39:47 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:41:03 --> Config Class Initialized
INFO - 2023-02-06 07:41:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:41:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:41:03 --> Utf8 Class Initialized
INFO - 2023-02-06 07:41:03 --> URI Class Initialized
INFO - 2023-02-06 07:41:03 --> Router Class Initialized
INFO - 2023-02-06 07:41:03 --> Output Class Initialized
INFO - 2023-02-06 07:41:03 --> Security Class Initialized
DEBUG - 2023-02-06 07:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:41:03 --> Input Class Initialized
INFO - 2023-02-06 07:41:03 --> Language Class Initialized
INFO - 2023-02-06 07:41:03 --> Loader Class Initialized
INFO - 2023-02-06 07:41:03 --> Controller Class Initialized
INFO - 2023-02-06 07:41:03 --> Helper loaded: form_helper
INFO - 2023-02-06 07:41:03 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:41:03 --> Model "Change_model" initialized
INFO - 2023-02-06 07:41:03 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:41:51 --> Config Class Initialized
INFO - 2023-02-06 07:41:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:41:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:41:51 --> Utf8 Class Initialized
INFO - 2023-02-06 07:41:51 --> URI Class Initialized
INFO - 2023-02-06 07:41:51 --> Router Class Initialized
INFO - 2023-02-06 07:41:51 --> Output Class Initialized
INFO - 2023-02-06 07:41:51 --> Security Class Initialized
DEBUG - 2023-02-06 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:41:51 --> Input Class Initialized
INFO - 2023-02-06 07:41:51 --> Language Class Initialized
INFO - 2023-02-06 07:41:51 --> Loader Class Initialized
INFO - 2023-02-06 07:41:51 --> Controller Class Initialized
INFO - 2023-02-06 07:41:51 --> Helper loaded: form_helper
INFO - 2023-02-06 07:41:51 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:41:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:41:51 --> Model "Change_model" initialized
INFO - 2023-02-06 07:41:51 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:42:29 --> Config Class Initialized
INFO - 2023-02-06 07:42:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:42:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:42:29 --> Utf8 Class Initialized
INFO - 2023-02-06 07:42:29 --> URI Class Initialized
INFO - 2023-02-06 07:42:29 --> Router Class Initialized
INFO - 2023-02-06 07:42:29 --> Output Class Initialized
INFO - 2023-02-06 07:42:29 --> Security Class Initialized
DEBUG - 2023-02-06 07:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:42:29 --> Input Class Initialized
INFO - 2023-02-06 07:42:29 --> Language Class Initialized
INFO - 2023-02-06 07:42:29 --> Loader Class Initialized
INFO - 2023-02-06 07:42:29 --> Controller Class Initialized
INFO - 2023-02-06 07:42:29 --> Helper loaded: form_helper
INFO - 2023-02-06 07:42:29 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:42:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:42:29 --> Model "Change_model" initialized
INFO - 2023-02-06 07:42:29 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:43:15 --> Config Class Initialized
INFO - 2023-02-06 07:43:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:43:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:43:15 --> Utf8 Class Initialized
INFO - 2023-02-06 07:43:15 --> URI Class Initialized
INFO - 2023-02-06 07:43:15 --> Router Class Initialized
INFO - 2023-02-06 07:43:15 --> Output Class Initialized
INFO - 2023-02-06 07:43:15 --> Security Class Initialized
DEBUG - 2023-02-06 07:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:43:15 --> Input Class Initialized
INFO - 2023-02-06 07:43:15 --> Language Class Initialized
INFO - 2023-02-06 07:43:15 --> Loader Class Initialized
INFO - 2023-02-06 07:43:15 --> Controller Class Initialized
INFO - 2023-02-06 07:43:15 --> Helper loaded: form_helper
INFO - 2023-02-06 07:43:15 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:43:15 --> Model "Change_model" initialized
INFO - 2023-02-06 07:43:15 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:43:33 --> Config Class Initialized
INFO - 2023-02-06 07:43:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:43:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:43:33 --> Utf8 Class Initialized
INFO - 2023-02-06 07:43:33 --> URI Class Initialized
INFO - 2023-02-06 07:43:33 --> Router Class Initialized
INFO - 2023-02-06 07:43:33 --> Output Class Initialized
INFO - 2023-02-06 07:43:33 --> Security Class Initialized
DEBUG - 2023-02-06 07:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:43:33 --> Input Class Initialized
INFO - 2023-02-06 07:43:33 --> Language Class Initialized
INFO - 2023-02-06 07:43:33 --> Loader Class Initialized
INFO - 2023-02-06 07:43:33 --> Controller Class Initialized
INFO - 2023-02-06 07:43:33 --> Helper loaded: form_helper
INFO - 2023-02-06 07:43:33 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:43:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:43:33 --> Model "Change_model" initialized
INFO - 2023-02-06 07:43:34 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:43:52 --> Config Class Initialized
INFO - 2023-02-06 07:43:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:43:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:43:52 --> Utf8 Class Initialized
INFO - 2023-02-06 07:43:52 --> URI Class Initialized
INFO - 2023-02-06 07:43:52 --> Router Class Initialized
INFO - 2023-02-06 07:43:52 --> Output Class Initialized
INFO - 2023-02-06 07:43:52 --> Security Class Initialized
DEBUG - 2023-02-06 07:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:43:52 --> Input Class Initialized
INFO - 2023-02-06 07:43:52 --> Language Class Initialized
INFO - 2023-02-06 07:43:52 --> Loader Class Initialized
INFO - 2023-02-06 07:43:52 --> Controller Class Initialized
INFO - 2023-02-06 07:43:52 --> Helper loaded: form_helper
INFO - 2023-02-06 07:43:52 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:43:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:43:52 --> Model "Change_model" initialized
INFO - 2023-02-06 07:43:52 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:44:22 --> Config Class Initialized
INFO - 2023-02-06 07:44:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:22 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:22 --> URI Class Initialized
INFO - 2023-02-06 07:44:22 --> Router Class Initialized
INFO - 2023-02-06 07:44:22 --> Output Class Initialized
INFO - 2023-02-06 07:44:22 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:22 --> Input Class Initialized
INFO - 2023-02-06 07:44:22 --> Language Class Initialized
INFO - 2023-02-06 07:44:22 --> Loader Class Initialized
INFO - 2023-02-06 07:44:22 --> Controller Class Initialized
INFO - 2023-02-06 07:44:22 --> Helper loaded: form_helper
INFO - 2023-02-06 07:44:22 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:22 --> Model "Change_model" initialized
INFO - 2023-02-06 07:44:22 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:44:45 --> Config Class Initialized
INFO - 2023-02-06 07:44:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:45 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:45 --> URI Class Initialized
INFO - 2023-02-06 07:44:45 --> Router Class Initialized
INFO - 2023-02-06 07:44:45 --> Output Class Initialized
INFO - 2023-02-06 07:44:45 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:45 --> Input Class Initialized
INFO - 2023-02-06 07:44:45 --> Language Class Initialized
INFO - 2023-02-06 07:44:45 --> Loader Class Initialized
INFO - 2023-02-06 07:44:45 --> Controller Class Initialized
INFO - 2023-02-06 07:44:45 --> Helper loaded: form_helper
INFO - 2023-02-06 07:44:45 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:45 --> Model "Change_model" initialized
INFO - 2023-02-06 07:44:45 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:44:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:46 --> Total execution time: 0.3491
INFO - 2023-02-06 07:44:46 --> Config Class Initialized
INFO - 2023-02-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:46 --> URI Class Initialized
INFO - 2023-02-06 07:44:46 --> Router Class Initialized
INFO - 2023-02-06 07:44:46 --> Output Class Initialized
INFO - 2023-02-06 07:44:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:46 --> Input Class Initialized
INFO - 2023-02-06 07:44:46 --> Language Class Initialized
INFO - 2023-02-06 07:44:46 --> Loader Class Initialized
INFO - 2023-02-06 07:44:46 --> Controller Class Initialized
INFO - 2023-02-06 07:44:46 --> Helper loaded: form_helper
INFO - 2023-02-06 07:44:46 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:46 --> Total execution time: 0.0025
INFO - 2023-02-06 07:44:46 --> Config Class Initialized
INFO - 2023-02-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:46 --> URI Class Initialized
INFO - 2023-02-06 07:44:46 --> Router Class Initialized
INFO - 2023-02-06 07:44:46 --> Output Class Initialized
INFO - 2023-02-06 07:44:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:46 --> Input Class Initialized
INFO - 2023-02-06 07:44:46 --> Language Class Initialized
INFO - 2023-02-06 07:44:46 --> Loader Class Initialized
INFO - 2023-02-06 07:44:46 --> Controller Class Initialized
INFO - 2023-02-06 07:44:46 --> Helper loaded: form_helper
INFO - 2023-02-06 07:44:46 --> Helper loaded: url_helper
DEBUG - 2023-02-06 07:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:46 --> Model "Login_model" initialized
INFO - 2023-02-06 07:44:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:46 --> Total execution time: 0.1685
INFO - 2023-02-06 07:44:46 --> Config Class Initialized
INFO - 2023-02-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:46 --> URI Class Initialized
INFO - 2023-02-06 07:44:46 --> Router Class Initialized
INFO - 2023-02-06 07:44:46 --> Output Class Initialized
INFO - 2023-02-06 07:44:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:46 --> Input Class Initialized
INFO - 2023-02-06 07:44:46 --> Language Class Initialized
INFO - 2023-02-06 07:44:46 --> Loader Class Initialized
INFO - 2023-02-06 07:44:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:46 --> Total execution time: 0.1982
INFO - 2023-02-06 07:44:46 --> Config Class Initialized
INFO - 2023-02-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:46 --> URI Class Initialized
INFO - 2023-02-06 07:44:46 --> Router Class Initialized
INFO - 2023-02-06 07:44:46 --> Output Class Initialized
INFO - 2023-02-06 07:44:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:46 --> Input Class Initialized
INFO - 2023-02-06 07:44:46 --> Language Class Initialized
INFO - 2023-02-06 07:44:46 --> Loader Class Initialized
INFO - 2023-02-06 07:44:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:46 --> Total execution time: 0.1766
INFO - 2023-02-06 07:44:46 --> Config Class Initialized
INFO - 2023-02-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:46 --> URI Class Initialized
INFO - 2023-02-06 07:44:46 --> Router Class Initialized
INFO - 2023-02-06 07:44:46 --> Output Class Initialized
INFO - 2023-02-06 07:44:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:46 --> Input Class Initialized
INFO - 2023-02-06 07:44:46 --> Language Class Initialized
INFO - 2023-02-06 07:44:46 --> Loader Class Initialized
INFO - 2023-02-06 07:44:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:47 --> Model "Login_model" initialized
INFO - 2023-02-06 07:44:47 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:47 --> Total execution time: 0.4717
INFO - 2023-02-06 07:44:47 --> Config Class Initialized
INFO - 2023-02-06 07:44:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:47 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:47 --> URI Class Initialized
INFO - 2023-02-06 07:44:47 --> Router Class Initialized
INFO - 2023-02-06 07:44:47 --> Output Class Initialized
INFO - 2023-02-06 07:44:47 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:47 --> Input Class Initialized
INFO - 2023-02-06 07:44:47 --> Language Class Initialized
INFO - 2023-02-06 07:44:47 --> Loader Class Initialized
INFO - 2023-02-06 07:44:47 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:47 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:47 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:47 --> Model "Login_model" initialized
INFO - 2023-02-06 07:44:47 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:47 --> Total execution time: 0.4700
INFO - 2023-02-06 07:44:53 --> Config Class Initialized
INFO - 2023-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:53 --> URI Class Initialized
INFO - 2023-02-06 07:44:53 --> Router Class Initialized
INFO - 2023-02-06 07:44:53 --> Output Class Initialized
INFO - 2023-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:53 --> Input Class Initialized
INFO - 2023-02-06 07:44:53 --> Language Class Initialized
INFO - 2023-02-06 07:44:53 --> Loader Class Initialized
INFO - 2023-02-06 07:44:53 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:53 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:53 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:53 --> Total execution time: 0.1384
INFO - 2023-02-06 07:44:53 --> Config Class Initialized
INFO - 2023-02-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:53 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:53 --> URI Class Initialized
INFO - 2023-02-06 07:44:53 --> Router Class Initialized
INFO - 2023-02-06 07:44:53 --> Output Class Initialized
INFO - 2023-02-06 07:44:53 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:53 --> Input Class Initialized
INFO - 2023-02-06 07:44:53 --> Language Class Initialized
INFO - 2023-02-06 07:44:53 --> Loader Class Initialized
INFO - 2023-02-06 07:44:53 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:53 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:53 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:53 --> Total execution time: 0.1341
INFO - 2023-02-06 07:44:57 --> Config Class Initialized
INFO - 2023-02-06 07:44:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:57 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:57 --> URI Class Initialized
INFO - 2023-02-06 07:44:57 --> Router Class Initialized
INFO - 2023-02-06 07:44:57 --> Output Class Initialized
INFO - 2023-02-06 07:44:57 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:57 --> Input Class Initialized
INFO - 2023-02-06 07:44:57 --> Language Class Initialized
INFO - 2023-02-06 07:44:57 --> Loader Class Initialized
INFO - 2023-02-06 07:44:57 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:57 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:57 --> Total execution time: 0.0053
INFO - 2023-02-06 07:44:57 --> Config Class Initialized
INFO - 2023-02-06 07:44:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:44:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:44:57 --> Utf8 Class Initialized
INFO - 2023-02-06 07:44:57 --> URI Class Initialized
INFO - 2023-02-06 07:44:57 --> Router Class Initialized
INFO - 2023-02-06 07:44:57 --> Output Class Initialized
INFO - 2023-02-06 07:44:57 --> Security Class Initialized
DEBUG - 2023-02-06 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:44:57 --> Input Class Initialized
INFO - 2023-02-06 07:44:57 --> Language Class Initialized
INFO - 2023-02-06 07:44:57 --> Loader Class Initialized
INFO - 2023-02-06 07:44:57 --> Controller Class Initialized
DEBUG - 2023-02-06 07:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:44:57 --> Database Driver Class Initialized
INFO - 2023-02-06 07:44:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:44:57 --> Model "PGsql_model" initialized
INFO - 2023-02-06 07:44:57 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:44:57 --> Final output sent to browser
DEBUG - 2023-02-06 07:44:57 --> Total execution time: 0.2315
INFO - 2023-02-06 07:46:36 --> Config Class Initialized
INFO - 2023-02-06 07:46:36 --> Config Class Initialized
INFO - 2023-02-06 07:46:36 --> Hooks Class Initialized
INFO - 2023-02-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:36 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:36 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:36 --> URI Class Initialized
INFO - 2023-02-06 07:46:36 --> URI Class Initialized
INFO - 2023-02-06 07:46:36 --> Router Class Initialized
INFO - 2023-02-06 07:46:36 --> Router Class Initialized
INFO - 2023-02-06 07:46:36 --> Output Class Initialized
INFO - 2023-02-06 07:46:36 --> Output Class Initialized
INFO - 2023-02-06 07:46:36 --> Security Class Initialized
INFO - 2023-02-06 07:46:36 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:36 --> Input Class Initialized
INFO - 2023-02-06 07:46:36 --> Input Class Initialized
INFO - 2023-02-06 07:46:36 --> Language Class Initialized
INFO - 2023-02-06 07:46:36 --> Language Class Initialized
INFO - 2023-02-06 07:46:36 --> Loader Class Initialized
INFO - 2023-02-06 07:46:36 --> Loader Class Initialized
INFO - 2023-02-06 07:46:36 --> Controller Class Initialized
INFO - 2023-02-06 07:46:36 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 07:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:36 --> Final output sent to browser
INFO - 2023-02-06 07:46:36 --> Database Driver Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Total execution time: 0.0049
INFO - 2023-02-06 07:46:36 --> Config Class Initialized
INFO - 2023-02-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:36 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:36 --> URI Class Initialized
INFO - 2023-02-06 07:46:36 --> Router Class Initialized
INFO - 2023-02-06 07:46:36 --> Output Class Initialized
INFO - 2023-02-06 07:46:36 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:36 --> Input Class Initialized
INFO - 2023-02-06 07:46:36 --> Language Class Initialized
INFO - 2023-02-06 07:46:36 --> Loader Class Initialized
INFO - 2023-02-06 07:46:36 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:36 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:36 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:36 --> Total execution time: 0.0155
INFO - 2023-02-06 07:46:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:36 --> Final output sent to browser
INFO - 2023-02-06 07:46:36 --> Config Class Initialized
INFO - 2023-02-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Total execution time: 0.0114
DEBUG - 2023-02-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:36 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:36 --> URI Class Initialized
INFO - 2023-02-06 07:46:36 --> Router Class Initialized
INFO - 2023-02-06 07:46:36 --> Output Class Initialized
INFO - 2023-02-06 07:46:36 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:36 --> Input Class Initialized
INFO - 2023-02-06 07:46:36 --> Language Class Initialized
INFO - 2023-02-06 07:46:36 --> Loader Class Initialized
INFO - 2023-02-06 07:46:36 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:36 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:36 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:36 --> Total execution time: 0.0915
INFO - 2023-02-06 07:46:37 --> Config Class Initialized
INFO - 2023-02-06 07:46:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:37 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:37 --> URI Class Initialized
INFO - 2023-02-06 07:46:37 --> Router Class Initialized
INFO - 2023-02-06 07:46:37 --> Output Class Initialized
INFO - 2023-02-06 07:46:37 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:37 --> Input Class Initialized
INFO - 2023-02-06 07:46:37 --> Language Class Initialized
INFO - 2023-02-06 07:46:37 --> Loader Class Initialized
INFO - 2023-02-06 07:46:37 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:37 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:37 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:37 --> Total execution time: 0.0498
INFO - 2023-02-06 07:46:37 --> Config Class Initialized
INFO - 2023-02-06 07:46:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:37 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:37 --> URI Class Initialized
INFO - 2023-02-06 07:46:37 --> Router Class Initialized
INFO - 2023-02-06 07:46:37 --> Output Class Initialized
INFO - 2023-02-06 07:46:37 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:37 --> Input Class Initialized
INFO - 2023-02-06 07:46:37 --> Language Class Initialized
INFO - 2023-02-06 07:46:37 --> Loader Class Initialized
INFO - 2023-02-06 07:46:37 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:37 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:37 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:37 --> Total execution time: 0.0192
INFO - 2023-02-06 07:46:40 --> Config Class Initialized
INFO - 2023-02-06 07:46:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:40 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:40 --> URI Class Initialized
INFO - 2023-02-06 07:46:40 --> Router Class Initialized
INFO - 2023-02-06 07:46:40 --> Output Class Initialized
INFO - 2023-02-06 07:46:40 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:40 --> Input Class Initialized
INFO - 2023-02-06 07:46:40 --> Language Class Initialized
INFO - 2023-02-06 07:46:40 --> Loader Class Initialized
INFO - 2023-02-06 07:46:40 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:40 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:40 --> Total execution time: 0.0037
INFO - 2023-02-06 07:46:40 --> Config Class Initialized
INFO - 2023-02-06 07:46:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:40 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:40 --> URI Class Initialized
INFO - 2023-02-06 07:46:40 --> Router Class Initialized
INFO - 2023-02-06 07:46:40 --> Output Class Initialized
INFO - 2023-02-06 07:46:40 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:40 --> Input Class Initialized
INFO - 2023-02-06 07:46:40 --> Language Class Initialized
INFO - 2023-02-06 07:46:40 --> Loader Class Initialized
INFO - 2023-02-06 07:46:40 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:40 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:40 --> Model "Mysql_model" initialized
INFO - 2023-02-06 07:46:40 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:46:40 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:40 --> Total execution time: 0.0302
INFO - 2023-02-06 07:46:51 --> Config Class Initialized
INFO - 2023-02-06 07:46:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:51 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:51 --> URI Class Initialized
INFO - 2023-02-06 07:46:51 --> Router Class Initialized
INFO - 2023-02-06 07:46:51 --> Output Class Initialized
INFO - 2023-02-06 07:46:51 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:51 --> Input Class Initialized
INFO - 2023-02-06 07:46:51 --> Language Class Initialized
INFO - 2023-02-06 07:46:51 --> Loader Class Initialized
INFO - 2023-02-06 07:46:51 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:51 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:51 --> Total execution time: 0.0431
INFO - 2023-02-06 07:46:55 --> Config Class Initialized
INFO - 2023-02-06 07:46:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:55 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:55 --> URI Class Initialized
INFO - 2023-02-06 07:46:55 --> Router Class Initialized
INFO - 2023-02-06 07:46:55 --> Output Class Initialized
INFO - 2023-02-06 07:46:55 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:55 --> Input Class Initialized
INFO - 2023-02-06 07:46:55 --> Language Class Initialized
INFO - 2023-02-06 07:46:55 --> Loader Class Initialized
INFO - 2023-02-06 07:46:55 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:55 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:55 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:55 --> Total execution time: 0.0171
INFO - 2023-02-06 07:46:55 --> Config Class Initialized
INFO - 2023-02-06 07:46:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:56 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:56 --> URI Class Initialized
INFO - 2023-02-06 07:46:56 --> Router Class Initialized
INFO - 2023-02-06 07:46:56 --> Output Class Initialized
INFO - 2023-02-06 07:46:56 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:56 --> Input Class Initialized
INFO - 2023-02-06 07:46:56 --> Language Class Initialized
INFO - 2023-02-06 07:46:56 --> Loader Class Initialized
INFO - 2023-02-06 07:46:56 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:56 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:56 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:56 --> Total execution time: 0.0530
INFO - 2023-02-06 07:46:58 --> Config Class Initialized
INFO - 2023-02-06 07:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:58 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:58 --> URI Class Initialized
INFO - 2023-02-06 07:46:58 --> Router Class Initialized
INFO - 2023-02-06 07:46:58 --> Output Class Initialized
INFO - 2023-02-06 07:46:58 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:58 --> Input Class Initialized
INFO - 2023-02-06 07:46:58 --> Language Class Initialized
INFO - 2023-02-06 07:46:58 --> Loader Class Initialized
INFO - 2023-02-06 07:46:58 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:58 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:58 --> Total execution time: 0.0035
INFO - 2023-02-06 07:46:58 --> Config Class Initialized
INFO - 2023-02-06 07:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:46:58 --> Utf8 Class Initialized
INFO - 2023-02-06 07:46:58 --> URI Class Initialized
INFO - 2023-02-06 07:46:58 --> Router Class Initialized
INFO - 2023-02-06 07:46:58 --> Output Class Initialized
INFO - 2023-02-06 07:46:58 --> Security Class Initialized
DEBUG - 2023-02-06 07:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:46:58 --> Input Class Initialized
INFO - 2023-02-06 07:46:58 --> Language Class Initialized
INFO - 2023-02-06 07:46:58 --> Loader Class Initialized
INFO - 2023-02-06 07:46:58 --> Controller Class Initialized
DEBUG - 2023-02-06 07:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:46:58 --> Database Driver Class Initialized
INFO - 2023-02-06 07:46:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:46:58 --> Model "PGsql_model" initialized
INFO - 2023-02-06 07:46:58 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:46:58 --> Final output sent to browser
DEBUG - 2023-02-06 07:46:58 --> Total execution time: 0.0237
INFO - 2023-02-06 07:47:16 --> Config Class Initialized
INFO - 2023-02-06 07:47:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:47:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:47:16 --> Utf8 Class Initialized
INFO - 2023-02-06 07:47:16 --> URI Class Initialized
INFO - 2023-02-06 07:47:16 --> Router Class Initialized
INFO - 2023-02-06 07:47:16 --> Output Class Initialized
INFO - 2023-02-06 07:47:16 --> Security Class Initialized
DEBUG - 2023-02-06 07:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:47:16 --> Input Class Initialized
INFO - 2023-02-06 07:47:16 --> Language Class Initialized
INFO - 2023-02-06 07:47:16 --> Loader Class Initialized
INFO - 2023-02-06 07:47:16 --> Controller Class Initialized
DEBUG - 2023-02-06 07:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:47:16 --> Final output sent to browser
DEBUG - 2023-02-06 07:47:16 --> Total execution time: 0.0040
INFO - 2023-02-06 07:47:16 --> Config Class Initialized
INFO - 2023-02-06 07:47:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:47:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:47:16 --> Utf8 Class Initialized
INFO - 2023-02-06 07:47:16 --> URI Class Initialized
INFO - 2023-02-06 07:47:16 --> Router Class Initialized
INFO - 2023-02-06 07:47:16 --> Output Class Initialized
INFO - 2023-02-06 07:47:16 --> Security Class Initialized
DEBUG - 2023-02-06 07:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:47:16 --> Input Class Initialized
INFO - 2023-02-06 07:47:16 --> Language Class Initialized
INFO - 2023-02-06 07:47:16 --> Loader Class Initialized
INFO - 2023-02-06 07:47:16 --> Controller Class Initialized
DEBUG - 2023-02-06 07:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:47:16 --> Database Driver Class Initialized
INFO - 2023-02-06 07:47:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:47:16 --> Model "Node_model" initialized
INFO - 2023-02-06 07:47:16 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:47:16 --> Final output sent to browser
DEBUG - 2023-02-06 07:47:16 --> Total execution time: 0.0332
INFO - 2023-02-06 07:48:07 --> Config Class Initialized
INFO - 2023-02-06 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:48:07 --> Utf8 Class Initialized
INFO - 2023-02-06 07:48:07 --> URI Class Initialized
INFO - 2023-02-06 07:48:07 --> Router Class Initialized
INFO - 2023-02-06 07:48:07 --> Output Class Initialized
INFO - 2023-02-06 07:48:07 --> Security Class Initialized
DEBUG - 2023-02-06 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:48:07 --> Input Class Initialized
INFO - 2023-02-06 07:48:07 --> Language Class Initialized
INFO - 2023-02-06 07:48:07 --> Loader Class Initialized
INFO - 2023-02-06 07:48:07 --> Controller Class Initialized
DEBUG - 2023-02-06 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:48:07 --> Final output sent to browser
DEBUG - 2023-02-06 07:48:07 --> Total execution time: 0.0075
INFO - 2023-02-06 07:48:07 --> Config Class Initialized
INFO - 2023-02-06 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:48:07 --> Utf8 Class Initialized
INFO - 2023-02-06 07:48:07 --> URI Class Initialized
INFO - 2023-02-06 07:48:07 --> Router Class Initialized
INFO - 2023-02-06 07:48:07 --> Output Class Initialized
INFO - 2023-02-06 07:48:07 --> Security Class Initialized
DEBUG - 2023-02-06 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:48:07 --> Input Class Initialized
INFO - 2023-02-06 07:48:07 --> Language Class Initialized
INFO - 2023-02-06 07:48:07 --> Loader Class Initialized
INFO - 2023-02-06 07:48:07 --> Controller Class Initialized
DEBUG - 2023-02-06 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:48:07 --> Database Driver Class Initialized
INFO - 2023-02-06 07:48:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:48:07 --> Model "Node_model" initialized
INFO - 2023-02-06 07:48:07 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:48:46 --> Config Class Initialized
INFO - 2023-02-06 07:48:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:48:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:48:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:48:46 --> URI Class Initialized
INFO - 2023-02-06 07:48:46 --> Router Class Initialized
INFO - 2023-02-06 07:48:46 --> Output Class Initialized
INFO - 2023-02-06 07:48:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:48:46 --> Input Class Initialized
INFO - 2023-02-06 07:48:46 --> Language Class Initialized
INFO - 2023-02-06 07:48:46 --> Loader Class Initialized
INFO - 2023-02-06 07:48:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:48:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:48:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:48:46 --> Total execution time: 0.0048
INFO - 2023-02-06 07:48:46 --> Config Class Initialized
INFO - 2023-02-06 07:48:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:48:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:48:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:48:46 --> URI Class Initialized
INFO - 2023-02-06 07:48:46 --> Router Class Initialized
INFO - 2023-02-06 07:48:46 --> Output Class Initialized
INFO - 2023-02-06 07:48:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:48:46 --> Input Class Initialized
INFO - 2023-02-06 07:48:46 --> Language Class Initialized
INFO - 2023-02-06 07:48:46 --> Loader Class Initialized
INFO - 2023-02-06 07:48:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:48:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:48:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:48:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:48:46 --> Model "Node_model" initialized
INFO - 2023-02-06 07:48:46 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:48:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:48:46 --> Total execution time: 0.0274
INFO - 2023-02-06 07:49:22 --> Config Class Initialized
INFO - 2023-02-06 07:49:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:49:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:49:22 --> Utf8 Class Initialized
INFO - 2023-02-06 07:49:22 --> URI Class Initialized
INFO - 2023-02-06 07:49:22 --> Router Class Initialized
INFO - 2023-02-06 07:49:22 --> Output Class Initialized
INFO - 2023-02-06 07:49:22 --> Security Class Initialized
DEBUG - 2023-02-06 07:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:49:22 --> Input Class Initialized
INFO - 2023-02-06 07:49:22 --> Language Class Initialized
INFO - 2023-02-06 07:49:22 --> Loader Class Initialized
INFO - 2023-02-06 07:49:22 --> Controller Class Initialized
DEBUG - 2023-02-06 07:49:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:49:22 --> Final output sent to browser
DEBUG - 2023-02-06 07:49:22 --> Total execution time: 0.0062
INFO - 2023-02-06 07:49:22 --> Config Class Initialized
INFO - 2023-02-06 07:49:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:49:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:49:22 --> Utf8 Class Initialized
INFO - 2023-02-06 07:49:22 --> URI Class Initialized
INFO - 2023-02-06 07:49:22 --> Router Class Initialized
INFO - 2023-02-06 07:49:22 --> Output Class Initialized
INFO - 2023-02-06 07:49:22 --> Security Class Initialized
DEBUG - 2023-02-06 07:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:49:22 --> Input Class Initialized
INFO - 2023-02-06 07:49:22 --> Language Class Initialized
INFO - 2023-02-06 07:49:22 --> Loader Class Initialized
INFO - 2023-02-06 07:49:22 --> Controller Class Initialized
DEBUG - 2023-02-06 07:49:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:49:22 --> Database Driver Class Initialized
INFO - 2023-02-06 07:49:22 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:49:22 --> Model "Node_model" initialized
INFO - 2023-02-06 07:49:22 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:49:22 --> Final output sent to browser
DEBUG - 2023-02-06 07:49:22 --> Total execution time: 0.0267
INFO - 2023-02-06 07:50:04 --> Config Class Initialized
INFO - 2023-02-06 07:50:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:50:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:50:04 --> Utf8 Class Initialized
INFO - 2023-02-06 07:50:04 --> URI Class Initialized
INFO - 2023-02-06 07:50:04 --> Router Class Initialized
INFO - 2023-02-06 07:50:04 --> Output Class Initialized
INFO - 2023-02-06 07:50:04 --> Security Class Initialized
DEBUG - 2023-02-06 07:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:50:04 --> Input Class Initialized
INFO - 2023-02-06 07:50:04 --> Language Class Initialized
INFO - 2023-02-06 07:50:04 --> Loader Class Initialized
INFO - 2023-02-06 07:50:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:50:04 --> Final output sent to browser
DEBUG - 2023-02-06 07:50:04 --> Total execution time: 0.0048
INFO - 2023-02-06 07:50:04 --> Config Class Initialized
INFO - 2023-02-06 07:50:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:50:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:50:04 --> Utf8 Class Initialized
INFO - 2023-02-06 07:50:04 --> URI Class Initialized
INFO - 2023-02-06 07:50:04 --> Router Class Initialized
INFO - 2023-02-06 07:50:04 --> Output Class Initialized
INFO - 2023-02-06 07:50:04 --> Security Class Initialized
DEBUG - 2023-02-06 07:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:50:04 --> Input Class Initialized
INFO - 2023-02-06 07:50:04 --> Language Class Initialized
INFO - 2023-02-06 07:50:04 --> Loader Class Initialized
INFO - 2023-02-06 07:50:04 --> Controller Class Initialized
DEBUG - 2023-02-06 07:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:50:04 --> Database Driver Class Initialized
INFO - 2023-02-06 07:50:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:50:04 --> Model "Node_model" initialized
INFO - 2023-02-06 07:50:04 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:51:07 --> Config Class Initialized
INFO - 2023-02-06 07:51:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:51:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:51:07 --> Utf8 Class Initialized
INFO - 2023-02-06 07:51:07 --> URI Class Initialized
INFO - 2023-02-06 07:51:07 --> Router Class Initialized
INFO - 2023-02-06 07:51:07 --> Output Class Initialized
INFO - 2023-02-06 07:51:07 --> Security Class Initialized
DEBUG - 2023-02-06 07:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:51:07 --> Input Class Initialized
INFO - 2023-02-06 07:51:07 --> Language Class Initialized
INFO - 2023-02-06 07:51:07 --> Loader Class Initialized
INFO - 2023-02-06 07:51:07 --> Controller Class Initialized
DEBUG - 2023-02-06 07:51:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:51:07 --> Final output sent to browser
DEBUG - 2023-02-06 07:51:07 --> Total execution time: 0.0036
INFO - 2023-02-06 07:51:07 --> Config Class Initialized
INFO - 2023-02-06 07:51:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:51:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:51:07 --> Utf8 Class Initialized
INFO - 2023-02-06 07:51:07 --> URI Class Initialized
INFO - 2023-02-06 07:51:07 --> Router Class Initialized
INFO - 2023-02-06 07:51:07 --> Output Class Initialized
INFO - 2023-02-06 07:51:07 --> Security Class Initialized
DEBUG - 2023-02-06 07:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:51:07 --> Input Class Initialized
INFO - 2023-02-06 07:51:07 --> Language Class Initialized
INFO - 2023-02-06 07:51:07 --> Loader Class Initialized
INFO - 2023-02-06 07:51:07 --> Controller Class Initialized
DEBUG - 2023-02-06 07:51:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:51:07 --> Database Driver Class Initialized
INFO - 2023-02-06 07:51:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:51:07 --> Model "Node_model" initialized
INFO - 2023-02-06 07:51:07 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:51:43 --> Config Class Initialized
INFO - 2023-02-06 07:51:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:51:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:51:43 --> Utf8 Class Initialized
INFO - 2023-02-06 07:51:43 --> URI Class Initialized
INFO - 2023-02-06 07:51:43 --> Router Class Initialized
INFO - 2023-02-06 07:51:43 --> Output Class Initialized
INFO - 2023-02-06 07:51:43 --> Security Class Initialized
DEBUG - 2023-02-06 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:51:43 --> Input Class Initialized
INFO - 2023-02-06 07:51:43 --> Language Class Initialized
INFO - 2023-02-06 07:51:43 --> Loader Class Initialized
INFO - 2023-02-06 07:51:43 --> Controller Class Initialized
DEBUG - 2023-02-06 07:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:51:43 --> Final output sent to browser
DEBUG - 2023-02-06 07:51:43 --> Total execution time: 0.0048
INFO - 2023-02-06 07:51:43 --> Config Class Initialized
INFO - 2023-02-06 07:51:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:51:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:51:43 --> Utf8 Class Initialized
INFO - 2023-02-06 07:51:43 --> URI Class Initialized
INFO - 2023-02-06 07:51:43 --> Router Class Initialized
INFO - 2023-02-06 07:51:43 --> Output Class Initialized
INFO - 2023-02-06 07:51:43 --> Security Class Initialized
DEBUG - 2023-02-06 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:51:43 --> Input Class Initialized
INFO - 2023-02-06 07:51:43 --> Language Class Initialized
INFO - 2023-02-06 07:51:43 --> Loader Class Initialized
INFO - 2023-02-06 07:51:43 --> Controller Class Initialized
DEBUG - 2023-02-06 07:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:51:43 --> Database Driver Class Initialized
INFO - 2023-02-06 07:51:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:51:43 --> Model "Node_model" initialized
INFO - 2023-02-06 07:51:43 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:53:28 --> Config Class Initialized
INFO - 2023-02-06 07:53:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:53:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:53:28 --> Utf8 Class Initialized
INFO - 2023-02-06 07:53:28 --> URI Class Initialized
INFO - 2023-02-06 07:53:28 --> Router Class Initialized
INFO - 2023-02-06 07:53:28 --> Output Class Initialized
INFO - 2023-02-06 07:53:28 --> Security Class Initialized
DEBUG - 2023-02-06 07:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:53:28 --> Input Class Initialized
INFO - 2023-02-06 07:53:28 --> Language Class Initialized
INFO - 2023-02-06 07:53:28 --> Loader Class Initialized
INFO - 2023-02-06 07:53:28 --> Controller Class Initialized
DEBUG - 2023-02-06 07:53:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:53:28 --> Final output sent to browser
DEBUG - 2023-02-06 07:53:28 --> Total execution time: 0.0058
INFO - 2023-02-06 07:53:28 --> Config Class Initialized
INFO - 2023-02-06 07:53:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:53:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:53:28 --> Utf8 Class Initialized
INFO - 2023-02-06 07:53:28 --> URI Class Initialized
INFO - 2023-02-06 07:53:28 --> Router Class Initialized
INFO - 2023-02-06 07:53:28 --> Output Class Initialized
INFO - 2023-02-06 07:53:28 --> Security Class Initialized
DEBUG - 2023-02-06 07:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:53:28 --> Input Class Initialized
INFO - 2023-02-06 07:53:28 --> Language Class Initialized
INFO - 2023-02-06 07:53:28 --> Loader Class Initialized
INFO - 2023-02-06 07:53:28 --> Controller Class Initialized
DEBUG - 2023-02-06 07:53:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:53:28 --> Database Driver Class Initialized
INFO - 2023-02-06 07:53:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:53:28 --> Model "Node_model" initialized
INFO - 2023-02-06 07:53:28 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:53:46 --> Config Class Initialized
INFO - 2023-02-06 07:53:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:53:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:53:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:53:46 --> URI Class Initialized
INFO - 2023-02-06 07:53:46 --> Router Class Initialized
INFO - 2023-02-06 07:53:46 --> Output Class Initialized
INFO - 2023-02-06 07:53:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:53:46 --> Input Class Initialized
INFO - 2023-02-06 07:53:46 --> Language Class Initialized
INFO - 2023-02-06 07:53:46 --> Loader Class Initialized
INFO - 2023-02-06 07:53:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:53:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:53:46 --> Final output sent to browser
DEBUG - 2023-02-06 07:53:46 --> Total execution time: 0.0044
INFO - 2023-02-06 07:53:46 --> Config Class Initialized
INFO - 2023-02-06 07:53:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:53:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:53:46 --> Utf8 Class Initialized
INFO - 2023-02-06 07:53:46 --> URI Class Initialized
INFO - 2023-02-06 07:53:46 --> Router Class Initialized
INFO - 2023-02-06 07:53:46 --> Output Class Initialized
INFO - 2023-02-06 07:53:46 --> Security Class Initialized
DEBUG - 2023-02-06 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:53:46 --> Input Class Initialized
INFO - 2023-02-06 07:53:46 --> Language Class Initialized
INFO - 2023-02-06 07:53:46 --> Loader Class Initialized
INFO - 2023-02-06 07:53:46 --> Controller Class Initialized
DEBUG - 2023-02-06 07:53:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:53:46 --> Database Driver Class Initialized
INFO - 2023-02-06 07:53:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:53:46 --> Model "Node_model" initialized
INFO - 2023-02-06 07:53:46 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:55:54 --> Config Class Initialized
INFO - 2023-02-06 07:55:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:55:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:55:54 --> Utf8 Class Initialized
INFO - 2023-02-06 07:55:54 --> URI Class Initialized
INFO - 2023-02-06 07:55:54 --> Router Class Initialized
INFO - 2023-02-06 07:55:54 --> Output Class Initialized
INFO - 2023-02-06 07:55:54 --> Security Class Initialized
DEBUG - 2023-02-06 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:55:54 --> Input Class Initialized
INFO - 2023-02-06 07:55:54 --> Language Class Initialized
INFO - 2023-02-06 07:55:54 --> Loader Class Initialized
INFO - 2023-02-06 07:55:54 --> Controller Class Initialized
DEBUG - 2023-02-06 07:55:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:55:54 --> Final output sent to browser
DEBUG - 2023-02-06 07:55:54 --> Total execution time: 0.0065
INFO - 2023-02-06 07:55:54 --> Config Class Initialized
INFO - 2023-02-06 07:55:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:55:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:55:54 --> Utf8 Class Initialized
INFO - 2023-02-06 07:55:54 --> URI Class Initialized
INFO - 2023-02-06 07:55:54 --> Router Class Initialized
INFO - 2023-02-06 07:55:54 --> Output Class Initialized
INFO - 2023-02-06 07:55:54 --> Security Class Initialized
DEBUG - 2023-02-06 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:55:54 --> Input Class Initialized
INFO - 2023-02-06 07:55:54 --> Language Class Initialized
INFO - 2023-02-06 07:55:54 --> Loader Class Initialized
INFO - 2023-02-06 07:55:54 --> Controller Class Initialized
DEBUG - 2023-02-06 07:55:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:55:54 --> Database Driver Class Initialized
INFO - 2023-02-06 07:55:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:55:54 --> Model "Node_model" initialized
INFO - 2023-02-06 07:55:54 --> Model "Grafana_model" initialized
INFO - 2023-02-06 07:56:31 --> Config Class Initialized
INFO - 2023-02-06 07:56:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:56:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:56:31 --> Utf8 Class Initialized
INFO - 2023-02-06 07:56:31 --> URI Class Initialized
INFO - 2023-02-06 07:56:31 --> Router Class Initialized
INFO - 2023-02-06 07:56:31 --> Output Class Initialized
INFO - 2023-02-06 07:56:31 --> Security Class Initialized
DEBUG - 2023-02-06 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:56:31 --> Input Class Initialized
INFO - 2023-02-06 07:56:31 --> Language Class Initialized
INFO - 2023-02-06 07:56:31 --> Loader Class Initialized
INFO - 2023-02-06 07:56:31 --> Controller Class Initialized
DEBUG - 2023-02-06 07:56:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:56:31 --> Final output sent to browser
DEBUG - 2023-02-06 07:56:31 --> Total execution time: 0.0053
INFO - 2023-02-06 07:56:31 --> Config Class Initialized
INFO - 2023-02-06 07:56:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 07:56:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 07:56:31 --> Utf8 Class Initialized
INFO - 2023-02-06 07:56:31 --> URI Class Initialized
INFO - 2023-02-06 07:56:31 --> Router Class Initialized
INFO - 2023-02-06 07:56:31 --> Output Class Initialized
INFO - 2023-02-06 07:56:31 --> Security Class Initialized
DEBUG - 2023-02-06 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 07:56:31 --> Input Class Initialized
INFO - 2023-02-06 07:56:31 --> Language Class Initialized
INFO - 2023-02-06 07:56:31 --> Loader Class Initialized
INFO - 2023-02-06 07:56:31 --> Controller Class Initialized
DEBUG - 2023-02-06 07:56:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 07:56:31 --> Database Driver Class Initialized
INFO - 2023-02-06 07:56:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 07:56:31 --> Model "Node_model" initialized
INFO - 2023-02-06 07:56:31 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:16:28 --> Config Class Initialized
INFO - 2023-02-06 08:16:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:16:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:16:28 --> Utf8 Class Initialized
INFO - 2023-02-06 08:16:28 --> URI Class Initialized
INFO - 2023-02-06 08:16:28 --> Router Class Initialized
INFO - 2023-02-06 08:16:28 --> Output Class Initialized
INFO - 2023-02-06 08:16:28 --> Security Class Initialized
DEBUG - 2023-02-06 08:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:16:28 --> Input Class Initialized
INFO - 2023-02-06 08:16:28 --> Language Class Initialized
INFO - 2023-02-06 08:16:28 --> Loader Class Initialized
INFO - 2023-02-06 08:16:28 --> Controller Class Initialized
DEBUG - 2023-02-06 08:16:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:16:28 --> Final output sent to browser
DEBUG - 2023-02-06 08:16:28 --> Total execution time: 0.0040
INFO - 2023-02-06 08:16:28 --> Config Class Initialized
INFO - 2023-02-06 08:16:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:16:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:16:28 --> Utf8 Class Initialized
INFO - 2023-02-06 08:16:28 --> URI Class Initialized
INFO - 2023-02-06 08:16:28 --> Router Class Initialized
INFO - 2023-02-06 08:16:28 --> Output Class Initialized
INFO - 2023-02-06 08:16:28 --> Security Class Initialized
DEBUG - 2023-02-06 08:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:16:28 --> Input Class Initialized
INFO - 2023-02-06 08:16:28 --> Language Class Initialized
INFO - 2023-02-06 08:16:28 --> Loader Class Initialized
INFO - 2023-02-06 08:16:28 --> Controller Class Initialized
DEBUG - 2023-02-06 08:16:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:16:28 --> Database Driver Class Initialized
INFO - 2023-02-06 08:16:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:16:28 --> Model "PGsql_model" initialized
INFO - 2023-02-06 08:16:28 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:16:28 --> Final output sent to browser
DEBUG - 2023-02-06 08:16:28 --> Total execution time: 0.1402
INFO - 2023-02-06 08:16:34 --> Config Class Initialized
INFO - 2023-02-06 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:16:34 --> Utf8 Class Initialized
INFO - 2023-02-06 08:16:34 --> URI Class Initialized
INFO - 2023-02-06 08:16:34 --> Router Class Initialized
INFO - 2023-02-06 08:16:34 --> Output Class Initialized
INFO - 2023-02-06 08:16:34 --> Security Class Initialized
DEBUG - 2023-02-06 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:16:34 --> Input Class Initialized
INFO - 2023-02-06 08:16:34 --> Language Class Initialized
INFO - 2023-02-06 08:16:34 --> Loader Class Initialized
INFO - 2023-02-06 08:16:34 --> Controller Class Initialized
DEBUG - 2023-02-06 08:16:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:16:34 --> Final output sent to browser
DEBUG - 2023-02-06 08:16:34 --> Total execution time: 0.0041
INFO - 2023-02-06 08:16:34 --> Config Class Initialized
INFO - 2023-02-06 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:16:34 --> Utf8 Class Initialized
INFO - 2023-02-06 08:16:34 --> URI Class Initialized
INFO - 2023-02-06 08:16:34 --> Router Class Initialized
INFO - 2023-02-06 08:16:34 --> Output Class Initialized
INFO - 2023-02-06 08:16:34 --> Security Class Initialized
DEBUG - 2023-02-06 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:16:34 --> Input Class Initialized
INFO - 2023-02-06 08:16:34 --> Language Class Initialized
INFO - 2023-02-06 08:16:34 --> Loader Class Initialized
INFO - 2023-02-06 08:16:34 --> Controller Class Initialized
DEBUG - 2023-02-06 08:16:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:16:34 --> Database Driver Class Initialized
INFO - 2023-02-06 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:16:34 --> Model "Node_model" initialized
INFO - 2023-02-06 08:16:34 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:18:10 --> Config Class Initialized
INFO - 2023-02-06 08:18:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:18:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:18:10 --> Utf8 Class Initialized
INFO - 2023-02-06 08:18:10 --> URI Class Initialized
INFO - 2023-02-06 08:18:10 --> Router Class Initialized
INFO - 2023-02-06 08:18:10 --> Output Class Initialized
INFO - 2023-02-06 08:18:10 --> Security Class Initialized
DEBUG - 2023-02-06 08:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:18:10 --> Input Class Initialized
INFO - 2023-02-06 08:18:10 --> Language Class Initialized
INFO - 2023-02-06 08:18:10 --> Loader Class Initialized
INFO - 2023-02-06 08:18:10 --> Controller Class Initialized
DEBUG - 2023-02-06 08:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:18:10 --> Final output sent to browser
DEBUG - 2023-02-06 08:18:10 --> Total execution time: 0.0062
INFO - 2023-02-06 08:18:10 --> Config Class Initialized
INFO - 2023-02-06 08:18:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:18:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:18:10 --> Utf8 Class Initialized
INFO - 2023-02-06 08:18:10 --> URI Class Initialized
INFO - 2023-02-06 08:18:10 --> Router Class Initialized
INFO - 2023-02-06 08:18:10 --> Output Class Initialized
INFO - 2023-02-06 08:18:10 --> Security Class Initialized
DEBUG - 2023-02-06 08:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:18:10 --> Input Class Initialized
INFO - 2023-02-06 08:18:10 --> Language Class Initialized
INFO - 2023-02-06 08:18:10 --> Loader Class Initialized
INFO - 2023-02-06 08:18:10 --> Controller Class Initialized
DEBUG - 2023-02-06 08:18:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:18:10 --> Database Driver Class Initialized
INFO - 2023-02-06 08:18:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:18:10 --> Model "Node_model" initialized
INFO - 2023-02-06 08:18:10 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:18:10 --> Final output sent to browser
DEBUG - 2023-02-06 08:18:10 --> Total execution time: 0.0864
INFO - 2023-02-06 08:30:54 --> Config Class Initialized
INFO - 2023-02-06 08:30:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:30:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:30:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:30:54 --> URI Class Initialized
INFO - 2023-02-06 08:30:54 --> Router Class Initialized
INFO - 2023-02-06 08:30:54 --> Output Class Initialized
INFO - 2023-02-06 08:30:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:30:54 --> Input Class Initialized
INFO - 2023-02-06 08:30:54 --> Language Class Initialized
INFO - 2023-02-06 08:30:54 --> Loader Class Initialized
INFO - 2023-02-06 08:30:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:30:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:30:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:30:54 --> Total execution time: 0.0054
INFO - 2023-02-06 08:30:54 --> Config Class Initialized
INFO - 2023-02-06 08:30:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:30:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:30:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:30:54 --> URI Class Initialized
INFO - 2023-02-06 08:30:54 --> Router Class Initialized
INFO - 2023-02-06 08:30:54 --> Output Class Initialized
INFO - 2023-02-06 08:30:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:30:54 --> Input Class Initialized
INFO - 2023-02-06 08:30:54 --> Language Class Initialized
INFO - 2023-02-06 08:30:54 --> Loader Class Initialized
INFO - 2023-02-06 08:30:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:30:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:30:54 --> Database Driver Class Initialized
INFO - 2023-02-06 08:30:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:30:54 --> Model "Node_model" initialized
INFO - 2023-02-06 08:30:54 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:30:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:30:54 --> Total execution time: 0.0700
INFO - 2023-02-06 08:34:50 --> Config Class Initialized
INFO - 2023-02-06 08:34:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:34:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:34:50 --> Utf8 Class Initialized
INFO - 2023-02-06 08:34:50 --> URI Class Initialized
INFO - 2023-02-06 08:34:50 --> Router Class Initialized
INFO - 2023-02-06 08:34:50 --> Output Class Initialized
INFO - 2023-02-06 08:34:50 --> Security Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:34:50 --> Input Class Initialized
INFO - 2023-02-06 08:34:50 --> Language Class Initialized
INFO - 2023-02-06 08:34:50 --> Loader Class Initialized
INFO - 2023-02-06 08:34:50 --> Controller Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:34:50 --> Final output sent to browser
DEBUG - 2023-02-06 08:34:50 --> Total execution time: 0.0052
INFO - 2023-02-06 08:34:50 --> Config Class Initialized
INFO - 2023-02-06 08:34:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:34:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:34:50 --> Utf8 Class Initialized
INFO - 2023-02-06 08:34:50 --> URI Class Initialized
INFO - 2023-02-06 08:34:50 --> Router Class Initialized
INFO - 2023-02-06 08:34:50 --> Output Class Initialized
INFO - 2023-02-06 08:34:50 --> Security Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:34:50 --> Input Class Initialized
INFO - 2023-02-06 08:34:50 --> Language Class Initialized
INFO - 2023-02-06 08:34:50 --> Loader Class Initialized
INFO - 2023-02-06 08:34:50 --> Controller Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:34:50 --> Database Driver Class Initialized
INFO - 2023-02-06 08:34:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:34:50 --> Final output sent to browser
DEBUG - 2023-02-06 08:34:50 --> Total execution time: 0.0119
INFO - 2023-02-06 08:34:50 --> Config Class Initialized
INFO - 2023-02-06 08:34:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:34:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:34:50 --> Utf8 Class Initialized
INFO - 2023-02-06 08:34:50 --> URI Class Initialized
INFO - 2023-02-06 08:34:50 --> Router Class Initialized
INFO - 2023-02-06 08:34:50 --> Output Class Initialized
INFO - 2023-02-06 08:34:50 --> Security Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:34:50 --> Input Class Initialized
INFO - 2023-02-06 08:34:50 --> Language Class Initialized
INFO - 2023-02-06 08:34:50 --> Loader Class Initialized
INFO - 2023-02-06 08:34:50 --> Controller Class Initialized
DEBUG - 2023-02-06 08:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:34:50 --> Database Driver Class Initialized
INFO - 2023-02-06 08:34:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:34:50 --> Final output sent to browser
DEBUG - 2023-02-06 08:34:50 --> Total execution time: 0.0199
INFO - 2023-02-06 08:34:50 --> Config Class Initialized
INFO - 2023-02-06 08:34:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:34:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:34:51 --> Utf8 Class Initialized
INFO - 2023-02-06 08:34:51 --> URI Class Initialized
INFO - 2023-02-06 08:34:51 --> Router Class Initialized
INFO - 2023-02-06 08:34:51 --> Output Class Initialized
INFO - 2023-02-06 08:34:51 --> Security Class Initialized
DEBUG - 2023-02-06 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:34:51 --> Input Class Initialized
INFO - 2023-02-06 08:34:51 --> Language Class Initialized
INFO - 2023-02-06 08:34:51 --> Loader Class Initialized
INFO - 2023-02-06 08:34:51 --> Controller Class Initialized
DEBUG - 2023-02-06 08:34:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:34:51 --> Database Driver Class Initialized
INFO - 2023-02-06 08:34:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:34:51 --> Final output sent to browser
DEBUG - 2023-02-06 08:34:51 --> Total execution time: 0.0590
INFO - 2023-02-06 08:38:13 --> Config Class Initialized
INFO - 2023-02-06 08:38:13 --> Config Class Initialized
INFO - 2023-02-06 08:38:13 --> Hooks Class Initialized
INFO - 2023-02-06 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:13 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:13 --> URI Class Initialized
INFO - 2023-02-06 08:38:13 --> URI Class Initialized
INFO - 2023-02-06 08:38:13 --> Router Class Initialized
INFO - 2023-02-06 08:38:13 --> Router Class Initialized
INFO - 2023-02-06 08:38:13 --> Output Class Initialized
INFO - 2023-02-06 08:38:13 --> Output Class Initialized
INFO - 2023-02-06 08:38:13 --> Security Class Initialized
INFO - 2023-02-06 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:13 --> Input Class Initialized
INFO - 2023-02-06 08:38:13 --> Input Class Initialized
INFO - 2023-02-06 08:38:13 --> Language Class Initialized
INFO - 2023-02-06 08:38:13 --> Language Class Initialized
INFO - 2023-02-06 08:38:13 --> Loader Class Initialized
INFO - 2023-02-06 08:38:13 --> Loader Class Initialized
INFO - 2023-02-06 08:38:13 --> Controller Class Initialized
INFO - 2023-02-06 08:38:13 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:13 --> Total execution time: 0.0049
INFO - 2023-02-06 08:38:13 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:13 --> Config Class Initialized
INFO - 2023-02-06 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:13 --> URI Class Initialized
INFO - 2023-02-06 08:38:13 --> Router Class Initialized
INFO - 2023-02-06 08:38:13 --> Output Class Initialized
INFO - 2023-02-06 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:13 --> Input Class Initialized
INFO - 2023-02-06 08:38:13 --> Language Class Initialized
INFO - 2023-02-06 08:38:13 --> Loader Class Initialized
INFO - 2023-02-06 08:38:13 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:13 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:13 --> Total execution time: 0.0165
INFO - 2023-02-06 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:13 --> Total execution time: 0.0242
INFO - 2023-02-06 08:38:13 --> Config Class Initialized
INFO - 2023-02-06 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:13 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:13 --> URI Class Initialized
INFO - 2023-02-06 08:38:13 --> Router Class Initialized
INFO - 2023-02-06 08:38:13 --> Output Class Initialized
INFO - 2023-02-06 08:38:13 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:13 --> Input Class Initialized
INFO - 2023-02-06 08:38:13 --> Language Class Initialized
INFO - 2023-02-06 08:38:13 --> Loader Class Initialized
INFO - 2023-02-06 08:38:13 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:13 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:13 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:13 --> Total execution time: 0.0522
INFO - 2023-02-06 08:38:16 --> Config Class Initialized
INFO - 2023-02-06 08:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:16 --> URI Class Initialized
INFO - 2023-02-06 08:38:16 --> Router Class Initialized
INFO - 2023-02-06 08:38:16 --> Output Class Initialized
INFO - 2023-02-06 08:38:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:16 --> Input Class Initialized
INFO - 2023-02-06 08:38:16 --> Language Class Initialized
INFO - 2023-02-06 08:38:16 --> Loader Class Initialized
INFO - 2023-02-06 08:38:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:16 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:16 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:16 --> Total execution time: 0.0474
INFO - 2023-02-06 08:38:16 --> Config Class Initialized
INFO - 2023-02-06 08:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:16 --> URI Class Initialized
INFO - 2023-02-06 08:38:16 --> Router Class Initialized
INFO - 2023-02-06 08:38:16 --> Output Class Initialized
INFO - 2023-02-06 08:38:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:16 --> Input Class Initialized
INFO - 2023-02-06 08:38:16 --> Language Class Initialized
INFO - 2023-02-06 08:38:16 --> Loader Class Initialized
INFO - 2023-02-06 08:38:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:16 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:16 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:16 --> Total execution time: 0.0110
INFO - 2023-02-06 08:38:20 --> Config Class Initialized
INFO - 2023-02-06 08:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:20 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:20 --> URI Class Initialized
INFO - 2023-02-06 08:38:20 --> Router Class Initialized
INFO - 2023-02-06 08:38:20 --> Output Class Initialized
INFO - 2023-02-06 08:38:20 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:20 --> Input Class Initialized
INFO - 2023-02-06 08:38:20 --> Language Class Initialized
INFO - 2023-02-06 08:38:20 --> Loader Class Initialized
INFO - 2023-02-06 08:38:20 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:20 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:20 --> Total execution time: 0.0049
INFO - 2023-02-06 08:38:20 --> Config Class Initialized
INFO - 2023-02-06 08:38:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:20 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:20 --> URI Class Initialized
INFO - 2023-02-06 08:38:20 --> Router Class Initialized
INFO - 2023-02-06 08:38:20 --> Output Class Initialized
INFO - 2023-02-06 08:38:20 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:20 --> Input Class Initialized
INFO - 2023-02-06 08:38:20 --> Language Class Initialized
INFO - 2023-02-06 08:38:20 --> Loader Class Initialized
INFO - 2023-02-06 08:38:20 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:20 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:20 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:20 --> Model "PGsql_model" initialized
INFO - 2023-02-06 08:38:20 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:38:20 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:20 --> Total execution time: 0.1188
INFO - 2023-02-06 08:38:23 --> Config Class Initialized
INFO - 2023-02-06 08:38:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:23 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:23 --> URI Class Initialized
INFO - 2023-02-06 08:38:23 --> Router Class Initialized
INFO - 2023-02-06 08:38:23 --> Output Class Initialized
INFO - 2023-02-06 08:38:23 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:23 --> Input Class Initialized
INFO - 2023-02-06 08:38:23 --> Language Class Initialized
INFO - 2023-02-06 08:38:23 --> Loader Class Initialized
INFO - 2023-02-06 08:38:23 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:23 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:23 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:23 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:23 --> Total execution time: 0.0216
INFO - 2023-02-06 08:38:23 --> Config Class Initialized
INFO - 2023-02-06 08:38:23 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:23 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:23 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:23 --> URI Class Initialized
INFO - 2023-02-06 08:38:23 --> Router Class Initialized
INFO - 2023-02-06 08:38:23 --> Output Class Initialized
INFO - 2023-02-06 08:38:23 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:23 --> Input Class Initialized
INFO - 2023-02-06 08:38:23 --> Language Class Initialized
INFO - 2023-02-06 08:38:23 --> Loader Class Initialized
INFO - 2023-02-06 08:38:23 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:23 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:23 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:23 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:23 --> Total execution time: 0.0174
INFO - 2023-02-06 08:38:26 --> Config Class Initialized
INFO - 2023-02-06 08:38:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:26 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:26 --> URI Class Initialized
INFO - 2023-02-06 08:38:26 --> Router Class Initialized
INFO - 2023-02-06 08:38:26 --> Output Class Initialized
INFO - 2023-02-06 08:38:26 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:26 --> Input Class Initialized
INFO - 2023-02-06 08:38:26 --> Language Class Initialized
INFO - 2023-02-06 08:38:26 --> Loader Class Initialized
INFO - 2023-02-06 08:38:26 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:26 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:26 --> Total execution time: 0.0039
INFO - 2023-02-06 08:38:26 --> Config Class Initialized
INFO - 2023-02-06 08:38:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:26 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:26 --> URI Class Initialized
INFO - 2023-02-06 08:38:26 --> Router Class Initialized
INFO - 2023-02-06 08:38:26 --> Output Class Initialized
INFO - 2023-02-06 08:38:26 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:26 --> Input Class Initialized
INFO - 2023-02-06 08:38:26 --> Language Class Initialized
INFO - 2023-02-06 08:38:26 --> Loader Class Initialized
INFO - 2023-02-06 08:38:26 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:26 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:26 --> Model "Mysql_model" initialized
INFO - 2023-02-06 08:38:26 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:38:26 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:26 --> Total execution time: 0.0711
INFO - 2023-02-06 08:38:30 --> Config Class Initialized
INFO - 2023-02-06 08:38:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:30 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:30 --> URI Class Initialized
INFO - 2023-02-06 08:38:30 --> Router Class Initialized
INFO - 2023-02-06 08:38:30 --> Output Class Initialized
INFO - 2023-02-06 08:38:30 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:30 --> Input Class Initialized
INFO - 2023-02-06 08:38:30 --> Language Class Initialized
INFO - 2023-02-06 08:38:30 --> Loader Class Initialized
INFO - 2023-02-06 08:38:30 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:30 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:30 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:30 --> Total execution time: 0.0183
INFO - 2023-02-06 08:38:30 --> Config Class Initialized
INFO - 2023-02-06 08:38:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:30 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:30 --> URI Class Initialized
INFO - 2023-02-06 08:38:30 --> Router Class Initialized
INFO - 2023-02-06 08:38:30 --> Output Class Initialized
INFO - 2023-02-06 08:38:30 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:30 --> Input Class Initialized
INFO - 2023-02-06 08:38:30 --> Language Class Initialized
INFO - 2023-02-06 08:38:30 --> Loader Class Initialized
INFO - 2023-02-06 08:38:30 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:30 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:30 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:30 --> Total execution time: 0.0126
INFO - 2023-02-06 08:38:33 --> Config Class Initialized
INFO - 2023-02-06 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:33 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:33 --> URI Class Initialized
INFO - 2023-02-06 08:38:33 --> Router Class Initialized
INFO - 2023-02-06 08:38:33 --> Output Class Initialized
INFO - 2023-02-06 08:38:33 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:33 --> Input Class Initialized
INFO - 2023-02-06 08:38:33 --> Language Class Initialized
INFO - 2023-02-06 08:38:33 --> Loader Class Initialized
INFO - 2023-02-06 08:38:33 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:33 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:33 --> Total execution time: 0.0041
INFO - 2023-02-06 08:38:33 --> Config Class Initialized
INFO - 2023-02-06 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:38:33 --> Utf8 Class Initialized
INFO - 2023-02-06 08:38:33 --> URI Class Initialized
INFO - 2023-02-06 08:38:33 --> Router Class Initialized
INFO - 2023-02-06 08:38:33 --> Output Class Initialized
INFO - 2023-02-06 08:38:33 --> Security Class Initialized
DEBUG - 2023-02-06 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:38:33 --> Input Class Initialized
INFO - 2023-02-06 08:38:33 --> Language Class Initialized
INFO - 2023-02-06 08:38:33 --> Loader Class Initialized
INFO - 2023-02-06 08:38:33 --> Controller Class Initialized
DEBUG - 2023-02-06 08:38:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:38:33 --> Database Driver Class Initialized
INFO - 2023-02-06 08:38:33 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:38:33 --> Model "PGsql_model" initialized
INFO - 2023-02-06 08:38:33 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:38:33 --> Final output sent to browser
DEBUG - 2023-02-06 08:38:33 --> Total execution time: 0.1225
INFO - 2023-02-06 08:39:04 --> Config Class Initialized
INFO - 2023-02-06 08:39:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:04 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:04 --> URI Class Initialized
INFO - 2023-02-06 08:39:04 --> Router Class Initialized
INFO - 2023-02-06 08:39:04 --> Output Class Initialized
INFO - 2023-02-06 08:39:04 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:04 --> Input Class Initialized
INFO - 2023-02-06 08:39:04 --> Language Class Initialized
INFO - 2023-02-06 08:39:04 --> Loader Class Initialized
INFO - 2023-02-06 08:39:04 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:04 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:04 --> Total execution time: 0.0037
INFO - 2023-02-06 08:39:04 --> Config Class Initialized
INFO - 2023-02-06 08:39:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:04 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:04 --> URI Class Initialized
INFO - 2023-02-06 08:39:04 --> Router Class Initialized
INFO - 2023-02-06 08:39:04 --> Output Class Initialized
INFO - 2023-02-06 08:39:04 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:04 --> Input Class Initialized
INFO - 2023-02-06 08:39:04 --> Language Class Initialized
INFO - 2023-02-06 08:39:04 --> Loader Class Initialized
INFO - 2023-02-06 08:39:04 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:04 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:04 --> Model "PGsql_model" initialized
INFO - 2023-02-06 08:39:04 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:39:04 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:04 --> Total execution time: 0.1202
INFO - 2023-02-06 08:39:41 --> Config Class Initialized
INFO - 2023-02-06 08:39:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:41 --> URI Class Initialized
INFO - 2023-02-06 08:39:41 --> Router Class Initialized
INFO - 2023-02-06 08:39:41 --> Output Class Initialized
INFO - 2023-02-06 08:39:41 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:41 --> Input Class Initialized
INFO - 2023-02-06 08:39:41 --> Language Class Initialized
INFO - 2023-02-06 08:39:41 --> Loader Class Initialized
INFO - 2023-02-06 08:39:41 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:41 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:41 --> Total execution time: 0.0063
INFO - 2023-02-06 08:39:41 --> Config Class Initialized
INFO - 2023-02-06 08:39:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:41 --> URI Class Initialized
INFO - 2023-02-06 08:39:41 --> Router Class Initialized
INFO - 2023-02-06 08:39:41 --> Output Class Initialized
INFO - 2023-02-06 08:39:41 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:41 --> Input Class Initialized
INFO - 2023-02-06 08:39:41 --> Language Class Initialized
INFO - 2023-02-06 08:39:41 --> Loader Class Initialized
INFO - 2023-02-06 08:39:41 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:41 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:41 --> Model "PGsql_model" initialized
INFO - 2023-02-06 08:39:41 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:39:42 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:42 --> Total execution time: 0.1199
INFO - 2023-02-06 08:39:48 --> Config Class Initialized
INFO - 2023-02-06 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:48 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:48 --> URI Class Initialized
INFO - 2023-02-06 08:39:48 --> Router Class Initialized
INFO - 2023-02-06 08:39:48 --> Output Class Initialized
INFO - 2023-02-06 08:39:48 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:48 --> Input Class Initialized
INFO - 2023-02-06 08:39:48 --> Language Class Initialized
INFO - 2023-02-06 08:39:48 --> Loader Class Initialized
INFO - 2023-02-06 08:39:48 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:48 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:48 --> Total execution time: 0.0039
INFO - 2023-02-06 08:39:48 --> Config Class Initialized
INFO - 2023-02-06 08:39:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:48 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:48 --> URI Class Initialized
INFO - 2023-02-06 08:39:48 --> Router Class Initialized
INFO - 2023-02-06 08:39:48 --> Output Class Initialized
INFO - 2023-02-06 08:39:48 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:48 --> Input Class Initialized
INFO - 2023-02-06 08:39:48 --> Language Class Initialized
INFO - 2023-02-06 08:39:48 --> Loader Class Initialized
INFO - 2023-02-06 08:39:48 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:48 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:48 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:48 --> Total execution time: 0.0126
INFO - 2023-02-06 08:39:49 --> Config Class Initialized
INFO - 2023-02-06 08:39:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:49 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:49 --> URI Class Initialized
INFO - 2023-02-06 08:39:49 --> Router Class Initialized
INFO - 2023-02-06 08:39:49 --> Output Class Initialized
INFO - 2023-02-06 08:39:49 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:49 --> Input Class Initialized
INFO - 2023-02-06 08:39:49 --> Language Class Initialized
INFO - 2023-02-06 08:39:49 --> Loader Class Initialized
INFO - 2023-02-06 08:39:49 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:49 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:49 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:49 --> Total execution time: 0.0178
INFO - 2023-02-06 08:39:49 --> Config Class Initialized
INFO - 2023-02-06 08:39:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:49 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:49 --> URI Class Initialized
INFO - 2023-02-06 08:39:49 --> Router Class Initialized
INFO - 2023-02-06 08:39:49 --> Output Class Initialized
INFO - 2023-02-06 08:39:49 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:49 --> Input Class Initialized
INFO - 2023-02-06 08:39:49 --> Language Class Initialized
INFO - 2023-02-06 08:39:49 --> Loader Class Initialized
INFO - 2023-02-06 08:39:49 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:49 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:49 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:49 --> Total execution time: 0.0180
INFO - 2023-02-06 08:39:50 --> Config Class Initialized
INFO - 2023-02-06 08:39:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:50 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:50 --> URI Class Initialized
INFO - 2023-02-06 08:39:50 --> Router Class Initialized
INFO - 2023-02-06 08:39:50 --> Output Class Initialized
INFO - 2023-02-06 08:39:50 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:50 --> Input Class Initialized
INFO - 2023-02-06 08:39:50 --> Language Class Initialized
INFO - 2023-02-06 08:39:50 --> Loader Class Initialized
INFO - 2023-02-06 08:39:50 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:50 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:50 --> Total execution time: 0.0038
INFO - 2023-02-06 08:39:50 --> Config Class Initialized
INFO - 2023-02-06 08:39:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:50 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:50 --> URI Class Initialized
INFO - 2023-02-06 08:39:50 --> Router Class Initialized
INFO - 2023-02-06 08:39:50 --> Output Class Initialized
INFO - 2023-02-06 08:39:50 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:50 --> Input Class Initialized
INFO - 2023-02-06 08:39:50 --> Language Class Initialized
INFO - 2023-02-06 08:39:50 --> Loader Class Initialized
INFO - 2023-02-06 08:39:50 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:50 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:50 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:50 --> Total execution time: 0.0127
INFO - 2023-02-06 08:39:51 --> Config Class Initialized
INFO - 2023-02-06 08:39:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:51 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:51 --> URI Class Initialized
INFO - 2023-02-06 08:39:51 --> Router Class Initialized
INFO - 2023-02-06 08:39:51 --> Output Class Initialized
INFO - 2023-02-06 08:39:51 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:51 --> Input Class Initialized
INFO - 2023-02-06 08:39:51 --> Language Class Initialized
INFO - 2023-02-06 08:39:51 --> Loader Class Initialized
INFO - 2023-02-06 08:39:51 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:51 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:51 --> Total execution time: 0.0051
INFO - 2023-02-06 08:39:51 --> Config Class Initialized
INFO - 2023-02-06 08:39:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:51 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:51 --> URI Class Initialized
INFO - 2023-02-06 08:39:51 --> Router Class Initialized
INFO - 2023-02-06 08:39:51 --> Output Class Initialized
INFO - 2023-02-06 08:39:51 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:51 --> Input Class Initialized
INFO - 2023-02-06 08:39:51 --> Language Class Initialized
INFO - 2023-02-06 08:39:51 --> Loader Class Initialized
INFO - 2023-02-06 08:39:51 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:51 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:51 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:51 --> Total execution time: 0.0124
INFO - 2023-02-06 08:39:54 --> Config Class Initialized
INFO - 2023-02-06 08:39:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:54 --> URI Class Initialized
INFO - 2023-02-06 08:39:54 --> Router Class Initialized
INFO - 2023-02-06 08:39:54 --> Output Class Initialized
INFO - 2023-02-06 08:39:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:54 --> Input Class Initialized
INFO - 2023-02-06 08:39:54 --> Language Class Initialized
INFO - 2023-02-06 08:39:54 --> Loader Class Initialized
INFO - 2023-02-06 08:39:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:54 --> Total execution time: 0.0049
INFO - 2023-02-06 08:39:54 --> Config Class Initialized
INFO - 2023-02-06 08:39:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:54 --> URI Class Initialized
INFO - 2023-02-06 08:39:54 --> Router Class Initialized
INFO - 2023-02-06 08:39:54 --> Output Class Initialized
INFO - 2023-02-06 08:39:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:54 --> Input Class Initialized
INFO - 2023-02-06 08:39:54 --> Language Class Initialized
INFO - 2023-02-06 08:39:54 --> Loader Class Initialized
INFO - 2023-02-06 08:39:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:54 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:54 --> Total execution time: 0.0195
INFO - 2023-02-06 08:39:55 --> Config Class Initialized
INFO - 2023-02-06 08:39:55 --> Config Class Initialized
INFO - 2023-02-06 08:39:55 --> Hooks Class Initialized
INFO - 2023-02-06 08:39:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 08:39:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:55 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:55 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:55 --> URI Class Initialized
INFO - 2023-02-06 08:39:55 --> URI Class Initialized
INFO - 2023-02-06 08:39:55 --> Router Class Initialized
INFO - 2023-02-06 08:39:55 --> Router Class Initialized
INFO - 2023-02-06 08:39:55 --> Output Class Initialized
INFO - 2023-02-06 08:39:55 --> Output Class Initialized
INFO - 2023-02-06 08:39:55 --> Security Class Initialized
INFO - 2023-02-06 08:39:55 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 08:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:55 --> Input Class Initialized
INFO - 2023-02-06 08:39:55 --> Input Class Initialized
INFO - 2023-02-06 08:39:55 --> Language Class Initialized
INFO - 2023-02-06 08:39:55 --> Language Class Initialized
INFO - 2023-02-06 08:39:55 --> Loader Class Initialized
INFO - 2023-02-06 08:39:55 --> Loader Class Initialized
INFO - 2023-02-06 08:39:55 --> Controller Class Initialized
INFO - 2023-02-06 08:39:55 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 08:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:55 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:55 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:55 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:55 --> Total execution time: 0.0182
INFO - 2023-02-06 08:39:55 --> Config Class Initialized
INFO - 2023-02-06 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:56 --> URI Class Initialized
INFO - 2023-02-06 08:39:56 --> Router Class Initialized
INFO - 2023-02-06 08:39:56 --> Output Class Initialized
INFO - 2023-02-06 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:56 --> Input Class Initialized
INFO - 2023-02-06 08:39:56 --> Language Class Initialized
INFO - 2023-02-06 08:39:56 --> Loader Class Initialized
INFO - 2023-02-06 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:56 --> Final output sent to browser
INFO - 2023-02-06 08:39:56 --> Config Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Total execution time: 0.0926
INFO - 2023-02-06 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:56 --> URI Class Initialized
INFO - 2023-02-06 08:39:56 --> Router Class Initialized
INFO - 2023-02-06 08:39:56 --> Output Class Initialized
INFO - 2023-02-06 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:56 --> Input Class Initialized
INFO - 2023-02-06 08:39:56 --> Language Class Initialized
INFO - 2023-02-06 08:39:56 --> Loader Class Initialized
INFO - 2023-02-06 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:56 --> Config Class Initialized
INFO - 2023-02-06 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:56 --> URI Class Initialized
INFO - 2023-02-06 08:39:56 --> Router Class Initialized
INFO - 2023-02-06 08:39:56 --> Output Class Initialized
INFO - 2023-02-06 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:56 --> Input Class Initialized
INFO - 2023-02-06 08:39:56 --> Language Class Initialized
INFO - 2023-02-06 08:39:56 --> Loader Class Initialized
INFO - 2023-02-06 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:56 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:56 --> Total execution time: 0.0039
INFO - 2023-02-06 08:39:56 --> Config Class Initialized
INFO - 2023-02-06 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:56 --> URI Class Initialized
INFO - 2023-02-06 08:39:56 --> Router Class Initialized
INFO - 2023-02-06 08:39:56 --> Output Class Initialized
INFO - 2023-02-06 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:56 --> Input Class Initialized
INFO - 2023-02-06 08:39:56 --> Language Class Initialized
INFO - 2023-02-06 08:39:56 --> Loader Class Initialized
INFO - 2023-02-06 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:56 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:56 --> Total execution time: 0.0095
INFO - 2023-02-06 08:39:57 --> Config Class Initialized
INFO - 2023-02-06 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:57 --> URI Class Initialized
INFO - 2023-02-06 08:39:57 --> Router Class Initialized
INFO - 2023-02-06 08:39:57 --> Output Class Initialized
INFO - 2023-02-06 08:39:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:57 --> Input Class Initialized
INFO - 2023-02-06 08:39:57 --> Language Class Initialized
INFO - 2023-02-06 08:39:57 --> Loader Class Initialized
INFO - 2023-02-06 08:39:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:57 --> Total execution time: 0.0054
INFO - 2023-02-06 08:39:57 --> Config Class Initialized
INFO - 2023-02-06 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:57 --> URI Class Initialized
INFO - 2023-02-06 08:39:57 --> Router Class Initialized
INFO - 2023-02-06 08:39:57 --> Output Class Initialized
INFO - 2023-02-06 08:39:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:57 --> Input Class Initialized
INFO - 2023-02-06 08:39:57 --> Language Class Initialized
INFO - 2023-02-06 08:39:57 --> Loader Class Initialized
INFO - 2023-02-06 08:39:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:57 --> Total execution time: 0.0129
INFO - 2023-02-06 08:39:57 --> Config Class Initialized
INFO - 2023-02-06 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:57 --> URI Class Initialized
INFO - 2023-02-06 08:39:57 --> Router Class Initialized
INFO - 2023-02-06 08:39:57 --> Output Class Initialized
INFO - 2023-02-06 08:39:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:57 --> Input Class Initialized
INFO - 2023-02-06 08:39:57 --> Language Class Initialized
INFO - 2023-02-06 08:39:57 --> Loader Class Initialized
INFO - 2023-02-06 08:39:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:57 --> Total execution time: 0.0039
INFO - 2023-02-06 08:39:57 --> Config Class Initialized
INFO - 2023-02-06 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:57 --> URI Class Initialized
INFO - 2023-02-06 08:39:57 --> Router Class Initialized
INFO - 2023-02-06 08:39:57 --> Output Class Initialized
INFO - 2023-02-06 08:39:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:57 --> Input Class Initialized
INFO - 2023-02-06 08:39:57 --> Language Class Initialized
INFO - 2023-02-06 08:39:57 --> Loader Class Initialized
INFO - 2023-02-06 08:39:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:57 --> Total execution time: 0.0120
INFO - 2023-02-06 08:39:58 --> Config Class Initialized
INFO - 2023-02-06 08:39:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:58 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:58 --> URI Class Initialized
INFO - 2023-02-06 08:39:58 --> Router Class Initialized
INFO - 2023-02-06 08:39:58 --> Output Class Initialized
INFO - 2023-02-06 08:39:58 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:58 --> Input Class Initialized
INFO - 2023-02-06 08:39:58 --> Language Class Initialized
INFO - 2023-02-06 08:39:58 --> Loader Class Initialized
INFO - 2023-02-06 08:39:58 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:58 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:58 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:58 --> Total execution time: 0.0155
INFO - 2023-02-06 08:39:58 --> Config Class Initialized
INFO - 2023-02-06 08:39:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:58 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:58 --> URI Class Initialized
INFO - 2023-02-06 08:39:58 --> Router Class Initialized
INFO - 2023-02-06 08:39:58 --> Output Class Initialized
INFO - 2023-02-06 08:39:58 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:58 --> Input Class Initialized
INFO - 2023-02-06 08:39:58 --> Language Class Initialized
INFO - 2023-02-06 08:39:58 --> Loader Class Initialized
INFO - 2023-02-06 08:39:58 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:58 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:58 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:58 --> Total execution time: 0.0142
INFO - 2023-02-06 08:39:58 --> Config Class Initialized
INFO - 2023-02-06 08:39:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:58 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:58 --> URI Class Initialized
INFO - 2023-02-06 08:39:58 --> Router Class Initialized
INFO - 2023-02-06 08:39:58 --> Output Class Initialized
INFO - 2023-02-06 08:39:58 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:58 --> Input Class Initialized
INFO - 2023-02-06 08:39:58 --> Language Class Initialized
INFO - 2023-02-06 08:39:58 --> Loader Class Initialized
INFO - 2023-02-06 08:39:58 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:58 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:58 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:58 --> Total execution time: 0.0242
INFO - 2023-02-06 08:39:58 --> Config Class Initialized
INFO - 2023-02-06 08:39:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:58 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:58 --> URI Class Initialized
INFO - 2023-02-06 08:39:58 --> Router Class Initialized
INFO - 2023-02-06 08:39:58 --> Output Class Initialized
INFO - 2023-02-06 08:39:58 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:58 --> Input Class Initialized
INFO - 2023-02-06 08:39:58 --> Language Class Initialized
INFO - 2023-02-06 08:39:58 --> Loader Class Initialized
INFO - 2023-02-06 08:39:58 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:58 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:58 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:58 --> Total execution time: 0.0180
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0409
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0561
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0144
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0125
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0143
INFO - 2023-02-06 08:39:59 --> Config Class Initialized
INFO - 2023-02-06 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:39:59 --> Utf8 Class Initialized
INFO - 2023-02-06 08:39:59 --> URI Class Initialized
INFO - 2023-02-06 08:39:59 --> Router Class Initialized
INFO - 2023-02-06 08:39:59 --> Output Class Initialized
INFO - 2023-02-06 08:39:59 --> Security Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:39:59 --> Input Class Initialized
INFO - 2023-02-06 08:39:59 --> Language Class Initialized
INFO - 2023-02-06 08:39:59 --> Loader Class Initialized
INFO - 2023-02-06 08:39:59 --> Controller Class Initialized
DEBUG - 2023-02-06 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:39:59 --> Database Driver Class Initialized
INFO - 2023-02-06 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:39:59 --> Final output sent to browser
DEBUG - 2023-02-06 08:39:59 --> Total execution time: 0.0107
INFO - 2023-02-06 08:42:14 --> Config Class Initialized
INFO - 2023-02-06 08:42:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:14 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:14 --> URI Class Initialized
INFO - 2023-02-06 08:42:14 --> Router Class Initialized
INFO - 2023-02-06 08:42:14 --> Output Class Initialized
INFO - 2023-02-06 08:42:14 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:14 --> Input Class Initialized
INFO - 2023-02-06 08:42:14 --> Language Class Initialized
INFO - 2023-02-06 08:42:14 --> Loader Class Initialized
INFO - 2023-02-06 08:42:14 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:14 --> Final output sent to browser
DEBUG - 2023-02-06 08:42:14 --> Total execution time: 0.0051
INFO - 2023-02-06 08:42:14 --> Config Class Initialized
INFO - 2023-02-06 08:42:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:14 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:14 --> URI Class Initialized
INFO - 2023-02-06 08:42:14 --> Router Class Initialized
INFO - 2023-02-06 08:42:14 --> Output Class Initialized
INFO - 2023-02-06 08:42:14 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:14 --> Input Class Initialized
INFO - 2023-02-06 08:42:14 --> Language Class Initialized
INFO - 2023-02-06 08:42:14 --> Loader Class Initialized
INFO - 2023-02-06 08:42:14 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:14 --> Database Driver Class Initialized
INFO - 2023-02-06 08:42:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:42:14 --> Model "Node_model" initialized
INFO - 2023-02-06 08:42:14 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:42:16 --> Config Class Initialized
INFO - 2023-02-06 08:42:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:16 --> URI Class Initialized
INFO - 2023-02-06 08:42:16 --> Router Class Initialized
INFO - 2023-02-06 08:42:16 --> Output Class Initialized
INFO - 2023-02-06 08:42:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:16 --> Input Class Initialized
INFO - 2023-02-06 08:42:16 --> Language Class Initialized
INFO - 2023-02-06 08:42:16 --> Loader Class Initialized
INFO - 2023-02-06 08:42:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:16 --> Final output sent to browser
DEBUG - 2023-02-06 08:42:16 --> Total execution time: 0.0037
INFO - 2023-02-06 08:42:16 --> Config Class Initialized
INFO - 2023-02-06 08:42:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:16 --> URI Class Initialized
INFO - 2023-02-06 08:42:16 --> Router Class Initialized
INFO - 2023-02-06 08:42:16 --> Output Class Initialized
INFO - 2023-02-06 08:42:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:16 --> Input Class Initialized
INFO - 2023-02-06 08:42:16 --> Language Class Initialized
INFO - 2023-02-06 08:42:16 --> Loader Class Initialized
INFO - 2023-02-06 08:42:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:16 --> Database Driver Class Initialized
INFO - 2023-02-06 08:42:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:42:16 --> Model "Node_model" initialized
INFO - 2023-02-06 08:42:16 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:42:16 --> Config Class Initialized
INFO - 2023-02-06 08:42:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:16 --> URI Class Initialized
INFO - 2023-02-06 08:42:16 --> Router Class Initialized
INFO - 2023-02-06 08:42:16 --> Output Class Initialized
INFO - 2023-02-06 08:42:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:16 --> Input Class Initialized
INFO - 2023-02-06 08:42:16 --> Language Class Initialized
INFO - 2023-02-06 08:42:16 --> Loader Class Initialized
INFO - 2023-02-06 08:42:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:16 --> Final output sent to browser
DEBUG - 2023-02-06 08:42:16 --> Total execution time: 0.0038
INFO - 2023-02-06 08:42:16 --> Config Class Initialized
INFO - 2023-02-06 08:42:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:16 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:16 --> URI Class Initialized
INFO - 2023-02-06 08:42:16 --> Router Class Initialized
INFO - 2023-02-06 08:42:16 --> Output Class Initialized
INFO - 2023-02-06 08:42:16 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:16 --> Input Class Initialized
INFO - 2023-02-06 08:42:16 --> Language Class Initialized
INFO - 2023-02-06 08:42:16 --> Loader Class Initialized
INFO - 2023-02-06 08:42:16 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:16 --> Database Driver Class Initialized
INFO - 2023-02-06 08:42:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:42:16 --> Model "Node_model" initialized
INFO - 2023-02-06 08:42:16 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:42:27 --> Config Class Initialized
INFO - 2023-02-06 08:42:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:42:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:42:27 --> Utf8 Class Initialized
INFO - 2023-02-06 08:42:27 --> URI Class Initialized
INFO - 2023-02-06 08:42:27 --> Router Class Initialized
INFO - 2023-02-06 08:42:27 --> Output Class Initialized
INFO - 2023-02-06 08:42:27 --> Security Class Initialized
DEBUG - 2023-02-06 08:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:42:27 --> Input Class Initialized
INFO - 2023-02-06 08:42:27 --> Language Class Initialized
INFO - 2023-02-06 08:42:27 --> Loader Class Initialized
INFO - 2023-02-06 08:42:27 --> Controller Class Initialized
DEBUG - 2023-02-06 08:42:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:42:27 --> Final output sent to browser
DEBUG - 2023-02-06 08:42:27 --> Total execution time: 0.0053
INFO - 2023-02-06 08:43:47 --> Config Class Initialized
INFO - 2023-02-06 08:43:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:47 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:47 --> URI Class Initialized
INFO - 2023-02-06 08:43:47 --> Router Class Initialized
INFO - 2023-02-06 08:43:47 --> Output Class Initialized
INFO - 2023-02-06 08:43:47 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:47 --> Input Class Initialized
INFO - 2023-02-06 08:43:47 --> Language Class Initialized
INFO - 2023-02-06 08:43:47 --> Loader Class Initialized
INFO - 2023-02-06 08:43:47 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:47 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:47 --> Total execution time: 0.0065
INFO - 2023-02-06 08:43:47 --> Config Class Initialized
INFO - 2023-02-06 08:43:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:47 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:47 --> URI Class Initialized
INFO - 2023-02-06 08:43:47 --> Router Class Initialized
INFO - 2023-02-06 08:43:47 --> Output Class Initialized
INFO - 2023-02-06 08:43:47 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:47 --> Input Class Initialized
INFO - 2023-02-06 08:43:47 --> Language Class Initialized
INFO - 2023-02-06 08:43:47 --> Loader Class Initialized
INFO - 2023-02-06 08:43:47 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:47 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:47 --> Model "Node_model" initialized
INFO - 2023-02-06 08:43:47 --> Model "Grafana_model" initialized
INFO - 2023-02-06 08:43:47 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:47 --> Total execution time: 0.0145
INFO - 2023-02-06 08:43:53 --> Config Class Initialized
INFO - 2023-02-06 08:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:53 --> URI Class Initialized
INFO - 2023-02-06 08:43:53 --> Router Class Initialized
INFO - 2023-02-06 08:43:53 --> Output Class Initialized
INFO - 2023-02-06 08:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:53 --> Input Class Initialized
INFO - 2023-02-06 08:43:53 --> Language Class Initialized
INFO - 2023-02-06 08:43:53 --> Loader Class Initialized
INFO - 2023-02-06 08:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:53 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:53 --> Total execution time: 0.0151
INFO - 2023-02-06 08:43:53 --> Config Class Initialized
INFO - 2023-02-06 08:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:53 --> URI Class Initialized
INFO - 2023-02-06 08:43:53 --> Router Class Initialized
INFO - 2023-02-06 08:43:53 --> Output Class Initialized
INFO - 2023-02-06 08:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:53 --> Input Class Initialized
INFO - 2023-02-06 08:43:53 --> Language Class Initialized
INFO - 2023-02-06 08:43:53 --> Loader Class Initialized
INFO - 2023-02-06 08:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:53 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:53 --> Total execution time: 0.0134
INFO - 2023-02-06 08:43:54 --> Config Class Initialized
INFO - 2023-02-06 08:43:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:54 --> URI Class Initialized
INFO - 2023-02-06 08:43:54 --> Router Class Initialized
INFO - 2023-02-06 08:43:54 --> Output Class Initialized
INFO - 2023-02-06 08:43:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:54 --> Input Class Initialized
INFO - 2023-02-06 08:43:54 --> Language Class Initialized
INFO - 2023-02-06 08:43:54 --> Loader Class Initialized
INFO - 2023-02-06 08:43:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:54 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:54 --> Total execution time: 0.0187
INFO - 2023-02-06 08:43:54 --> Config Class Initialized
INFO - 2023-02-06 08:43:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:54 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:54 --> URI Class Initialized
INFO - 2023-02-06 08:43:54 --> Router Class Initialized
INFO - 2023-02-06 08:43:54 --> Output Class Initialized
INFO - 2023-02-06 08:43:54 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:54 --> Input Class Initialized
INFO - 2023-02-06 08:43:54 --> Language Class Initialized
INFO - 2023-02-06 08:43:54 --> Loader Class Initialized
INFO - 2023-02-06 08:43:54 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:54 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:54 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:54 --> Total execution time: 0.0579
INFO - 2023-02-06 08:43:57 --> Config Class Initialized
INFO - 2023-02-06 08:43:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:57 --> URI Class Initialized
INFO - 2023-02-06 08:43:57 --> Router Class Initialized
INFO - 2023-02-06 08:43:57 --> Output Class Initialized
INFO - 2023-02-06 08:43:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:57 --> Input Class Initialized
INFO - 2023-02-06 08:43:57 --> Language Class Initialized
INFO - 2023-02-06 08:43:57 --> Loader Class Initialized
INFO - 2023-02-06 08:43:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:57 --> Model "Login_model" initialized
INFO - 2023-02-06 08:43:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:57 --> Total execution time: 0.0473
INFO - 2023-02-06 08:43:57 --> Config Class Initialized
INFO - 2023-02-06 08:43:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:43:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:43:57 --> Utf8 Class Initialized
INFO - 2023-02-06 08:43:57 --> URI Class Initialized
INFO - 2023-02-06 08:43:57 --> Router Class Initialized
INFO - 2023-02-06 08:43:57 --> Output Class Initialized
INFO - 2023-02-06 08:43:57 --> Security Class Initialized
DEBUG - 2023-02-06 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:43:57 --> Input Class Initialized
INFO - 2023-02-06 08:43:57 --> Language Class Initialized
INFO - 2023-02-06 08:43:57 --> Loader Class Initialized
INFO - 2023-02-06 08:43:57 --> Controller Class Initialized
DEBUG - 2023-02-06 08:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:43:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:43:57 --> Database Driver Class Initialized
INFO - 2023-02-06 08:43:57 --> Model "Login_model" initialized
INFO - 2023-02-06 08:43:57 --> Final output sent to browser
DEBUG - 2023-02-06 08:43:57 --> Total execution time: 0.0418
INFO - 2023-02-06 08:44:15 --> Config Class Initialized
INFO - 2023-02-06 08:44:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:15 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:15 --> URI Class Initialized
INFO - 2023-02-06 08:44:15 --> Router Class Initialized
INFO - 2023-02-06 08:44:15 --> Output Class Initialized
INFO - 2023-02-06 08:44:15 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:15 --> Input Class Initialized
INFO - 2023-02-06 08:44:15 --> Language Class Initialized
INFO - 2023-02-06 08:44:15 --> Loader Class Initialized
INFO - 2023-02-06 08:44:15 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:15 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:15 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:15 --> Total execution time: 0.0169
INFO - 2023-02-06 08:44:15 --> Config Class Initialized
INFO - 2023-02-06 08:44:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:15 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:15 --> URI Class Initialized
INFO - 2023-02-06 08:44:15 --> Router Class Initialized
INFO - 2023-02-06 08:44:15 --> Output Class Initialized
INFO - 2023-02-06 08:44:15 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:15 --> Input Class Initialized
INFO - 2023-02-06 08:44:15 --> Language Class Initialized
INFO - 2023-02-06 08:44:15 --> Loader Class Initialized
INFO - 2023-02-06 08:44:15 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:15 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:15 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:15 --> Total execution time: 0.0523
INFO - 2023-02-06 08:44:17 --> Config Class Initialized
INFO - 2023-02-06 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:17 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:17 --> URI Class Initialized
INFO - 2023-02-06 08:44:17 --> Router Class Initialized
INFO - 2023-02-06 08:44:17 --> Output Class Initialized
INFO - 2023-02-06 08:44:17 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:17 --> Input Class Initialized
INFO - 2023-02-06 08:44:17 --> Language Class Initialized
INFO - 2023-02-06 08:44:17 --> Loader Class Initialized
INFO - 2023-02-06 08:44:17 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:17 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:17 --> Total execution time: 0.0044
INFO - 2023-02-06 08:44:17 --> Config Class Initialized
INFO - 2023-02-06 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:17 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:17 --> URI Class Initialized
INFO - 2023-02-06 08:44:17 --> Router Class Initialized
INFO - 2023-02-06 08:44:17 --> Output Class Initialized
INFO - 2023-02-06 08:44:17 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:17 --> Input Class Initialized
INFO - 2023-02-06 08:44:17 --> Language Class Initialized
INFO - 2023-02-06 08:44:17 --> Loader Class Initialized
INFO - 2023-02-06 08:44:17 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:17 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:17 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:17 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:17 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:17 --> Total execution time: 0.0193
INFO - 2023-02-06 08:44:17 --> Config Class Initialized
INFO - 2023-02-06 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:17 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:17 --> URI Class Initialized
INFO - 2023-02-06 08:44:17 --> Router Class Initialized
INFO - 2023-02-06 08:44:17 --> Output Class Initialized
INFO - 2023-02-06 08:44:17 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:17 --> Input Class Initialized
INFO - 2023-02-06 08:44:17 --> Language Class Initialized
INFO - 2023-02-06 08:44:17 --> Loader Class Initialized
INFO - 2023-02-06 08:44:17 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:17 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:17 --> Total execution time: 0.0024
INFO - 2023-02-06 08:44:17 --> Config Class Initialized
INFO - 2023-02-06 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:17 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:17 --> URI Class Initialized
INFO - 2023-02-06 08:44:17 --> Router Class Initialized
INFO - 2023-02-06 08:44:17 --> Output Class Initialized
INFO - 2023-02-06 08:44:17 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:17 --> Input Class Initialized
INFO - 2023-02-06 08:44:17 --> Language Class Initialized
INFO - 2023-02-06 08:44:17 --> Loader Class Initialized
INFO - 2023-02-06 08:44:17 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:17 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:17 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:17 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:17 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:17 --> Total execution time: 0.0633
INFO - 2023-02-06 08:44:18 --> Config Class Initialized
INFO - 2023-02-06 08:44:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:18 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:18 --> URI Class Initialized
INFO - 2023-02-06 08:44:18 --> Router Class Initialized
INFO - 2023-02-06 08:44:18 --> Output Class Initialized
INFO - 2023-02-06 08:44:18 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:18 --> Input Class Initialized
INFO - 2023-02-06 08:44:18 --> Language Class Initialized
INFO - 2023-02-06 08:44:18 --> Loader Class Initialized
INFO - 2023-02-06 08:44:18 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:18 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:18 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:18 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:18 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:18 --> Total execution time: 0.0851
INFO - 2023-02-06 08:44:18 --> Config Class Initialized
INFO - 2023-02-06 08:44:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:18 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:18 --> URI Class Initialized
INFO - 2023-02-06 08:44:18 --> Router Class Initialized
INFO - 2023-02-06 08:44:18 --> Output Class Initialized
INFO - 2023-02-06 08:44:18 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:18 --> Input Class Initialized
INFO - 2023-02-06 08:44:18 --> Language Class Initialized
INFO - 2023-02-06 08:44:18 --> Loader Class Initialized
INFO - 2023-02-06 08:44:18 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:18 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:18 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:18 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:18 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:18 --> Total execution time: 0.0372
INFO - 2023-02-06 08:44:27 --> Config Class Initialized
INFO - 2023-02-06 08:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:27 --> URI Class Initialized
INFO - 2023-02-06 08:44:27 --> Router Class Initialized
INFO - 2023-02-06 08:44:27 --> Output Class Initialized
INFO - 2023-02-06 08:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:27 --> Input Class Initialized
INFO - 2023-02-06 08:44:27 --> Language Class Initialized
INFO - 2023-02-06 08:44:27 --> Loader Class Initialized
INFO - 2023-02-06 08:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:27 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:27 --> Total execution time: 0.1229
INFO - 2023-02-06 08:44:27 --> Config Class Initialized
INFO - 2023-02-06 08:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 08:44:27 --> URI Class Initialized
INFO - 2023-02-06 08:44:27 --> Router Class Initialized
INFO - 2023-02-06 08:44:27 --> Output Class Initialized
INFO - 2023-02-06 08:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:44:27 --> Input Class Initialized
INFO - 2023-02-06 08:44:27 --> Language Class Initialized
INFO - 2023-02-06 08:44:27 --> Loader Class Initialized
INFO - 2023-02-06 08:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 08:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 08:44:27 --> Model "Login_model" initialized
INFO - 2023-02-06 08:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 08:44:27 --> Total execution time: 0.0332
INFO - 2023-02-06 08:51:25 --> Config Class Initialized
INFO - 2023-02-06 08:51:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:51:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:51:25 --> Utf8 Class Initialized
INFO - 2023-02-06 08:51:25 --> URI Class Initialized
INFO - 2023-02-06 08:51:25 --> Router Class Initialized
INFO - 2023-02-06 08:51:25 --> Output Class Initialized
INFO - 2023-02-06 08:51:25 --> Security Class Initialized
DEBUG - 2023-02-06 08:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:51:25 --> Input Class Initialized
INFO - 2023-02-06 08:51:25 --> Language Class Initialized
INFO - 2023-02-06 08:51:25 --> Loader Class Initialized
INFO - 2023-02-06 08:51:25 --> Controller Class Initialized
DEBUG - 2023-02-06 08:51:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:51:25 --> Database Driver Class Initialized
INFO - 2023-02-06 08:51:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:51:25 --> Final output sent to browser
DEBUG - 2023-02-06 08:51:25 --> Total execution time: 0.0197
INFO - 2023-02-06 08:51:25 --> Config Class Initialized
INFO - 2023-02-06 08:51:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:51:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:51:25 --> Utf8 Class Initialized
INFO - 2023-02-06 08:51:25 --> URI Class Initialized
INFO - 2023-02-06 08:51:25 --> Router Class Initialized
INFO - 2023-02-06 08:51:25 --> Output Class Initialized
INFO - 2023-02-06 08:51:25 --> Security Class Initialized
DEBUG - 2023-02-06 08:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:51:25 --> Input Class Initialized
INFO - 2023-02-06 08:51:25 --> Language Class Initialized
INFO - 2023-02-06 08:51:25 --> Loader Class Initialized
INFO - 2023-02-06 08:51:25 --> Controller Class Initialized
DEBUG - 2023-02-06 08:51:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:51:25 --> Database Driver Class Initialized
INFO - 2023-02-06 08:51:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:51:25 --> Final output sent to browser
DEBUG - 2023-02-06 08:51:25 --> Total execution time: 0.0141
INFO - 2023-02-06 08:59:42 --> Config Class Initialized
INFO - 2023-02-06 08:59:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:59:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:59:42 --> Utf8 Class Initialized
INFO - 2023-02-06 08:59:42 --> URI Class Initialized
INFO - 2023-02-06 08:59:42 --> Router Class Initialized
INFO - 2023-02-06 08:59:42 --> Output Class Initialized
INFO - 2023-02-06 08:59:42 --> Security Class Initialized
DEBUG - 2023-02-06 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:59:42 --> Input Class Initialized
INFO - 2023-02-06 08:59:42 --> Language Class Initialized
INFO - 2023-02-06 08:59:42 --> Loader Class Initialized
INFO - 2023-02-06 08:59:42 --> Controller Class Initialized
DEBUG - 2023-02-06 08:59:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:59:42 --> Final output sent to browser
DEBUG - 2023-02-06 08:59:42 --> Total execution time: 0.0605
INFO - 2023-02-06 08:59:42 --> Config Class Initialized
INFO - 2023-02-06 08:59:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:59:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:59:42 --> Utf8 Class Initialized
INFO - 2023-02-06 08:59:42 --> URI Class Initialized
INFO - 2023-02-06 08:59:42 --> Router Class Initialized
INFO - 2023-02-06 08:59:42 --> Output Class Initialized
INFO - 2023-02-06 08:59:42 --> Security Class Initialized
DEBUG - 2023-02-06 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:59:42 --> Input Class Initialized
INFO - 2023-02-06 08:59:42 --> Language Class Initialized
INFO - 2023-02-06 08:59:42 --> Loader Class Initialized
INFO - 2023-02-06 08:59:42 --> Controller Class Initialized
DEBUG - 2023-02-06 08:59:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:59:42 --> Database Driver Class Initialized
INFO - 2023-02-06 08:59:42 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:59:42 --> Final output sent to browser
DEBUG - 2023-02-06 08:59:42 --> Total execution time: 0.0112
INFO - 2023-02-06 08:59:43 --> Config Class Initialized
INFO - 2023-02-06 08:59:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:59:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:59:43 --> Utf8 Class Initialized
INFO - 2023-02-06 08:59:43 --> URI Class Initialized
INFO - 2023-02-06 08:59:43 --> Router Class Initialized
INFO - 2023-02-06 08:59:43 --> Output Class Initialized
INFO - 2023-02-06 08:59:43 --> Security Class Initialized
DEBUG - 2023-02-06 08:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:59:43 --> Input Class Initialized
INFO - 2023-02-06 08:59:43 --> Language Class Initialized
INFO - 2023-02-06 08:59:43 --> Loader Class Initialized
INFO - 2023-02-06 08:59:43 --> Controller Class Initialized
DEBUG - 2023-02-06 08:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:59:43 --> Database Driver Class Initialized
INFO - 2023-02-06 08:59:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:59:43 --> Final output sent to browser
DEBUG - 2023-02-06 08:59:43 --> Total execution time: 0.0197
INFO - 2023-02-06 08:59:43 --> Config Class Initialized
INFO - 2023-02-06 08:59:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 08:59:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 08:59:43 --> Utf8 Class Initialized
INFO - 2023-02-06 08:59:43 --> URI Class Initialized
INFO - 2023-02-06 08:59:43 --> Router Class Initialized
INFO - 2023-02-06 08:59:43 --> Output Class Initialized
INFO - 2023-02-06 08:59:43 --> Security Class Initialized
DEBUG - 2023-02-06 08:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 08:59:43 --> Input Class Initialized
INFO - 2023-02-06 08:59:43 --> Language Class Initialized
INFO - 2023-02-06 08:59:43 --> Loader Class Initialized
INFO - 2023-02-06 08:59:43 --> Controller Class Initialized
DEBUG - 2023-02-06 08:59:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 08:59:43 --> Database Driver Class Initialized
INFO - 2023-02-06 08:59:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 08:59:43 --> Final output sent to browser
DEBUG - 2023-02-06 08:59:43 --> Total execution time: 0.0158
INFO - 2023-02-06 09:00:00 --> Config Class Initialized
INFO - 2023-02-06 09:00:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:00 --> URI Class Initialized
INFO - 2023-02-06 09:00:00 --> Router Class Initialized
INFO - 2023-02-06 09:00:00 --> Output Class Initialized
INFO - 2023-02-06 09:00:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:00 --> Input Class Initialized
INFO - 2023-02-06 09:00:00 --> Language Class Initialized
INFO - 2023-02-06 09:00:00 --> Loader Class Initialized
INFO - 2023-02-06 09:00:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:00 --> Total execution time: 0.0254
INFO - 2023-02-06 09:00:00 --> Config Class Initialized
INFO - 2023-02-06 09:00:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:00 --> URI Class Initialized
INFO - 2023-02-06 09:00:00 --> Router Class Initialized
INFO - 2023-02-06 09:00:00 --> Output Class Initialized
INFO - 2023-02-06 09:00:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:00 --> Input Class Initialized
INFO - 2023-02-06 09:00:00 --> Language Class Initialized
INFO - 2023-02-06 09:00:00 --> Loader Class Initialized
INFO - 2023-02-06 09:00:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:00 --> Total execution time: 0.0201
INFO - 2023-02-06 09:00:03 --> Config Class Initialized
INFO - 2023-02-06 09:00:03 --> Config Class Initialized
INFO - 2023-02-06 09:00:03 --> Hooks Class Initialized
INFO - 2023-02-06 09:00:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 09:00:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:03 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:03 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:03 --> URI Class Initialized
INFO - 2023-02-06 09:00:03 --> URI Class Initialized
INFO - 2023-02-06 09:00:03 --> Router Class Initialized
INFO - 2023-02-06 09:00:03 --> Router Class Initialized
INFO - 2023-02-06 09:00:03 --> Output Class Initialized
INFO - 2023-02-06 09:00:03 --> Output Class Initialized
INFO - 2023-02-06 09:00:03 --> Security Class Initialized
INFO - 2023-02-06 09:00:03 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:03 --> Input Class Initialized
INFO - 2023-02-06 09:00:03 --> Input Class Initialized
INFO - 2023-02-06 09:00:03 --> Language Class Initialized
INFO - 2023-02-06 09:00:03 --> Language Class Initialized
INFO - 2023-02-06 09:00:03 --> Loader Class Initialized
INFO - 2023-02-06 09:00:03 --> Loader Class Initialized
INFO - 2023-02-06 09:00:03 --> Controller Class Initialized
INFO - 2023-02-06 09:00:03 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 09:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:03 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:03 --> Total execution time: 0.0200
INFO - 2023-02-06 09:00:03 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:03 --> Config Class Initialized
INFO - 2023-02-06 09:00:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:03 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:03 --> URI Class Initialized
INFO - 2023-02-06 09:00:03 --> Router Class Initialized
INFO - 2023-02-06 09:00:03 --> Output Class Initialized
INFO - 2023-02-06 09:00:03 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:03 --> Input Class Initialized
INFO - 2023-02-06 09:00:03 --> Language Class Initialized
INFO - 2023-02-06 09:00:03 --> Loader Class Initialized
INFO - 2023-02-06 09:00:03 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:03 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:03 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:03 --> Total execution time: 0.0407
INFO - 2023-02-06 09:00:03 --> Config Class Initialized
INFO - 2023-02-06 09:00:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:03 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:03 --> URI Class Initialized
INFO - 2023-02-06 09:00:03 --> Router Class Initialized
INFO - 2023-02-06 09:00:03 --> Output Class Initialized
INFO - 2023-02-06 09:00:03 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:03 --> Input Class Initialized
INFO - 2023-02-06 09:00:03 --> Language Class Initialized
INFO - 2023-02-06 09:00:03 --> Loader Class Initialized
INFO - 2023-02-06 09:00:03 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:03 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:03 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:03 --> Total execution time: 0.0268
INFO - 2023-02-06 09:00:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:03 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:03 --> Total execution time: 0.0205
INFO - 2023-02-06 09:00:04 --> Config Class Initialized
INFO - 2023-02-06 09:00:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:04 --> URI Class Initialized
INFO - 2023-02-06 09:00:04 --> Router Class Initialized
INFO - 2023-02-06 09:00:04 --> Output Class Initialized
INFO - 2023-02-06 09:00:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:04 --> Input Class Initialized
INFO - 2023-02-06 09:00:04 --> Language Class Initialized
INFO - 2023-02-06 09:00:04 --> Loader Class Initialized
INFO - 2023-02-06 09:00:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:04 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:04 --> Total execution time: 0.0589
INFO - 2023-02-06 09:00:04 --> Config Class Initialized
INFO - 2023-02-06 09:00:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:04 --> URI Class Initialized
INFO - 2023-02-06 09:00:04 --> Router Class Initialized
INFO - 2023-02-06 09:00:04 --> Output Class Initialized
INFO - 2023-02-06 09:00:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:04 --> Input Class Initialized
INFO - 2023-02-06 09:00:04 --> Language Class Initialized
INFO - 2023-02-06 09:00:04 --> Loader Class Initialized
INFO - 2023-02-06 09:00:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:04 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:05 --> Total execution time: 0.0182
INFO - 2023-02-06 09:00:05 --> Config Class Initialized
INFO - 2023-02-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:05 --> URI Class Initialized
INFO - 2023-02-06 09:00:05 --> Router Class Initialized
INFO - 2023-02-06 09:00:05 --> Output Class Initialized
INFO - 2023-02-06 09:00:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:05 --> Input Class Initialized
INFO - 2023-02-06 09:00:05 --> Language Class Initialized
INFO - 2023-02-06 09:00:05 --> Loader Class Initialized
INFO - 2023-02-06 09:00:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:05 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:05 --> Total execution time: 0.0158
INFO - 2023-02-06 09:00:05 --> Config Class Initialized
INFO - 2023-02-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:05 --> URI Class Initialized
INFO - 2023-02-06 09:00:05 --> Router Class Initialized
INFO - 2023-02-06 09:00:05 --> Output Class Initialized
INFO - 2023-02-06 09:00:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:05 --> Input Class Initialized
INFO - 2023-02-06 09:00:05 --> Language Class Initialized
INFO - 2023-02-06 09:00:05 --> Loader Class Initialized
INFO - 2023-02-06 09:00:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:05 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:05 --> Total execution time: 0.0123
INFO - 2023-02-06 09:00:46 --> Config Class Initialized
INFO - 2023-02-06 09:00:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:46 --> URI Class Initialized
INFO - 2023-02-06 09:00:46 --> Router Class Initialized
INFO - 2023-02-06 09:00:46 --> Output Class Initialized
INFO - 2023-02-06 09:00:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:46 --> Input Class Initialized
INFO - 2023-02-06 09:00:46 --> Language Class Initialized
INFO - 2023-02-06 09:00:46 --> Loader Class Initialized
INFO - 2023-02-06 09:00:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:46 --> Total execution time: 0.0037
INFO - 2023-02-06 09:00:46 --> Config Class Initialized
INFO - 2023-02-06 09:00:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:46 --> URI Class Initialized
INFO - 2023-02-06 09:00:46 --> Router Class Initialized
INFO - 2023-02-06 09:00:46 --> Output Class Initialized
INFO - 2023-02-06 09:00:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:46 --> Input Class Initialized
INFO - 2023-02-06 09:00:46 --> Language Class Initialized
INFO - 2023-02-06 09:00:46 --> Loader Class Initialized
INFO - 2023-02-06 09:00:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:46 --> Model "PGsql_model" initialized
INFO - 2023-02-06 09:00:46 --> Model "Grafana_model" initialized
INFO - 2023-02-06 09:00:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:46 --> Total execution time: 0.0153
INFO - 2023-02-06 09:00:54 --> Config Class Initialized
INFO - 2023-02-06 09:00:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:54 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:54 --> URI Class Initialized
INFO - 2023-02-06 09:00:54 --> Router Class Initialized
INFO - 2023-02-06 09:00:54 --> Output Class Initialized
INFO - 2023-02-06 09:00:54 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:54 --> Input Class Initialized
INFO - 2023-02-06 09:00:54 --> Language Class Initialized
INFO - 2023-02-06 09:00:54 --> Loader Class Initialized
INFO - 2023-02-06 09:00:54 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:54 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:54 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:54 --> Total execution time: 0.0157
INFO - 2023-02-06 09:00:54 --> Config Class Initialized
INFO - 2023-02-06 09:00:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:54 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:54 --> URI Class Initialized
INFO - 2023-02-06 09:00:54 --> Router Class Initialized
INFO - 2023-02-06 09:00:54 --> Output Class Initialized
INFO - 2023-02-06 09:00:54 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:54 --> Input Class Initialized
INFO - 2023-02-06 09:00:54 --> Language Class Initialized
INFO - 2023-02-06 09:00:54 --> Loader Class Initialized
INFO - 2023-02-06 09:00:54 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:54 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:54 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:54 --> Total execution time: 0.0574
INFO - 2023-02-06 09:00:55 --> Config Class Initialized
INFO - 2023-02-06 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:55 --> URI Class Initialized
INFO - 2023-02-06 09:00:55 --> Router Class Initialized
INFO - 2023-02-06 09:00:55 --> Output Class Initialized
INFO - 2023-02-06 09:00:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:55 --> Input Class Initialized
INFO - 2023-02-06 09:00:55 --> Language Class Initialized
INFO - 2023-02-06 09:00:55 --> Loader Class Initialized
INFO - 2023-02-06 09:00:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:55 --> Total execution time: 0.0039
INFO - 2023-02-06 09:00:55 --> Config Class Initialized
INFO - 2023-02-06 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:55 --> URI Class Initialized
INFO - 2023-02-06 09:00:55 --> Router Class Initialized
INFO - 2023-02-06 09:00:55 --> Output Class Initialized
INFO - 2023-02-06 09:00:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:55 --> Input Class Initialized
INFO - 2023-02-06 09:00:55 --> Language Class Initialized
INFO - 2023-02-06 09:00:55 --> Loader Class Initialized
INFO - 2023-02-06 09:00:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:55 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:55 --> Total execution time: 0.0159
INFO - 2023-02-06 09:00:56 --> Config Class Initialized
INFO - 2023-02-06 09:00:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:56 --> URI Class Initialized
INFO - 2023-02-06 09:00:56 --> Router Class Initialized
INFO - 2023-02-06 09:00:56 --> Output Class Initialized
INFO - 2023-02-06 09:00:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:56 --> Input Class Initialized
INFO - 2023-02-06 09:00:56 --> Language Class Initialized
INFO - 2023-02-06 09:00:56 --> Loader Class Initialized
INFO - 2023-02-06 09:00:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:56 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:56 --> Total execution time: 0.0161
INFO - 2023-02-06 09:00:56 --> Config Class Initialized
INFO - 2023-02-06 09:00:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:56 --> URI Class Initialized
INFO - 2023-02-06 09:00:56 --> Router Class Initialized
INFO - 2023-02-06 09:00:56 --> Output Class Initialized
INFO - 2023-02-06 09:00:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:56 --> Input Class Initialized
INFO - 2023-02-06 09:00:56 --> Language Class Initialized
INFO - 2023-02-06 09:00:56 --> Loader Class Initialized
INFO - 2023-02-06 09:00:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:56 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:56 --> Total execution time: 0.0112
INFO - 2023-02-06 09:00:59 --> Config Class Initialized
INFO - 2023-02-06 09:00:59 --> Config Class Initialized
INFO - 2023-02-06 09:00:59 --> Hooks Class Initialized
INFO - 2023-02-06 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:59 --> URI Class Initialized
INFO - 2023-02-06 09:00:59 --> URI Class Initialized
INFO - 2023-02-06 09:00:59 --> Router Class Initialized
INFO - 2023-02-06 09:00:59 --> Router Class Initialized
INFO - 2023-02-06 09:00:59 --> Output Class Initialized
INFO - 2023-02-06 09:00:59 --> Output Class Initialized
INFO - 2023-02-06 09:00:59 --> Security Class Initialized
INFO - 2023-02-06 09:00:59 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:59 --> Input Class Initialized
INFO - 2023-02-06 09:00:59 --> Language Class Initialized
INFO - 2023-02-06 09:00:59 --> Input Class Initialized
INFO - 2023-02-06 09:00:59 --> Loader Class Initialized
INFO - 2023-02-06 09:00:59 --> Language Class Initialized
INFO - 2023-02-06 09:00:59 --> Controller Class Initialized
INFO - 2023-02-06 09:00:59 --> Loader Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:59 --> Controller Class Initialized
INFO - 2023-02-06 09:00:59 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 09:00:59 --> Total execution time: 0.0040
INFO - 2023-02-06 09:00:59 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:59 --> Config Class Initialized
INFO - 2023-02-06 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:59 --> URI Class Initialized
INFO - 2023-02-06 09:00:59 --> Router Class Initialized
INFO - 2023-02-06 09:00:59 --> Output Class Initialized
INFO - 2023-02-06 09:00:59 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:59 --> Input Class Initialized
INFO - 2023-02-06 09:00:59 --> Language Class Initialized
INFO - 2023-02-06 09:00:59 --> Loader Class Initialized
INFO - 2023-02-06 09:00:59 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:59 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:59 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:59 --> Total execution time: 0.0160
INFO - 2023-02-06 09:00:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:59 --> Config Class Initialized
INFO - 2023-02-06 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:00:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:00:59 --> URI Class Initialized
INFO - 2023-02-06 09:00:59 --> Final output sent to browser
INFO - 2023-02-06 09:00:59 --> Router Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Total execution time: 0.0127
INFO - 2023-02-06 09:00:59 --> Output Class Initialized
INFO - 2023-02-06 09:00:59 --> Security Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:00:59 --> Input Class Initialized
INFO - 2023-02-06 09:00:59 --> Language Class Initialized
INFO - 2023-02-06 09:00:59 --> Loader Class Initialized
INFO - 2023-02-06 09:00:59 --> Controller Class Initialized
DEBUG - 2023-02-06 09:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:00:59 --> Database Driver Class Initialized
INFO - 2023-02-06 09:00:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:00:59 --> Final output sent to browser
DEBUG - 2023-02-06 09:00:59 --> Total execution time: 0.0130
INFO - 2023-02-06 09:01:02 --> Config Class Initialized
INFO - 2023-02-06 09:01:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:02 --> URI Class Initialized
INFO - 2023-02-06 09:01:02 --> Router Class Initialized
INFO - 2023-02-06 09:01:02 --> Output Class Initialized
INFO - 2023-02-06 09:01:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:02 --> Input Class Initialized
INFO - 2023-02-06 09:01:02 --> Language Class Initialized
INFO - 2023-02-06 09:01:02 --> Loader Class Initialized
INFO - 2023-02-06 09:01:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:02 --> Total execution time: 0.0551
INFO - 2023-02-06 09:01:02 --> Config Class Initialized
INFO - 2023-02-06 09:01:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:02 --> URI Class Initialized
INFO - 2023-02-06 09:01:02 --> Router Class Initialized
INFO - 2023-02-06 09:01:02 --> Output Class Initialized
INFO - 2023-02-06 09:01:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:02 --> Input Class Initialized
INFO - 2023-02-06 09:01:02 --> Language Class Initialized
INFO - 2023-02-06 09:01:02 --> Loader Class Initialized
INFO - 2023-02-06 09:01:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:02 --> Total execution time: 0.0185
INFO - 2023-02-06 09:01:09 --> Config Class Initialized
INFO - 2023-02-06 09:01:09 --> Config Class Initialized
INFO - 2023-02-06 09:01:09 --> Hooks Class Initialized
INFO - 2023-02-06 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:09 --> URI Class Initialized
INFO - 2023-02-06 09:01:09 --> Router Class Initialized
INFO - 2023-02-06 09:01:09 --> Output Class Initialized
INFO - 2023-02-06 09:01:09 --> URI Class Initialized
INFO - 2023-02-06 09:01:09 --> Security Class Initialized
INFO - 2023-02-06 09:01:09 --> Router Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:09 --> Output Class Initialized
INFO - 2023-02-06 09:01:09 --> Input Class Initialized
INFO - 2023-02-06 09:01:09 --> Security Class Initialized
INFO - 2023-02-06 09:01:09 --> Language Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:09 --> Loader Class Initialized
INFO - 2023-02-06 09:01:09 --> Input Class Initialized
INFO - 2023-02-06 09:01:09 --> Controller Class Initialized
INFO - 2023-02-06 09:01:09 --> Language Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:09 --> Loader Class Initialized
INFO - 2023-02-06 09:01:09 --> Final output sent to browser
INFO - 2023-02-06 09:01:09 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Total execution time: 0.0027
DEBUG - 2023-02-06 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:09 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:09 --> Config Class Initialized
INFO - 2023-02-06 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:09 --> URI Class Initialized
INFO - 2023-02-06 09:01:09 --> Router Class Initialized
INFO - 2023-02-06 09:01:09 --> Output Class Initialized
INFO - 2023-02-06 09:01:09 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:09 --> Input Class Initialized
INFO - 2023-02-06 09:01:09 --> Language Class Initialized
INFO - 2023-02-06 09:01:09 --> Loader Class Initialized
INFO - 2023-02-06 09:01:09 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:09 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:09 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:09 --> Total execution time: 0.0157
INFO - 2023-02-06 09:01:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:09 --> Config Class Initialized
INFO - 2023-02-06 09:01:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:09 --> URI Class Initialized
INFO - 2023-02-06 09:01:09 --> Router Class Initialized
INFO - 2023-02-06 09:01:09 --> Output Class Initialized
INFO - 2023-02-06 09:01:09 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:09 --> Input Class Initialized
INFO - 2023-02-06 09:01:09 --> Language Class Initialized
INFO - 2023-02-06 09:01:09 --> Loader Class Initialized
INFO - 2023-02-06 09:01:09 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:09 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:09 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:09 --> Total execution time: 0.0155
INFO - 2023-02-06 09:01:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:09 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:09 --> Total execution time: 0.0094
INFO - 2023-02-06 09:01:13 --> Config Class Initialized
INFO - 2023-02-06 09:01:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:13 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:13 --> URI Class Initialized
INFO - 2023-02-06 09:01:13 --> Router Class Initialized
INFO - 2023-02-06 09:01:13 --> Output Class Initialized
INFO - 2023-02-06 09:01:13 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:13 --> Input Class Initialized
INFO - 2023-02-06 09:01:13 --> Language Class Initialized
INFO - 2023-02-06 09:01:13 --> Loader Class Initialized
INFO - 2023-02-06 09:01:13 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:13 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:13 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:13 --> Total execution time: 0.0148
INFO - 2023-02-06 09:01:13 --> Config Class Initialized
INFO - 2023-02-06 09:01:13 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:13 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:13 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:13 --> URI Class Initialized
INFO - 2023-02-06 09:01:13 --> Router Class Initialized
INFO - 2023-02-06 09:01:13 --> Output Class Initialized
INFO - 2023-02-06 09:01:13 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:13 --> Input Class Initialized
INFO - 2023-02-06 09:01:13 --> Language Class Initialized
INFO - 2023-02-06 09:01:13 --> Loader Class Initialized
INFO - 2023-02-06 09:01:13 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:13 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:13 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:13 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:13 --> Total execution time: 0.0135
INFO - 2023-02-06 09:01:15 --> Config Class Initialized
INFO - 2023-02-06 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:15 --> URI Class Initialized
INFO - 2023-02-06 09:01:15 --> Router Class Initialized
INFO - 2023-02-06 09:01:15 --> Output Class Initialized
INFO - 2023-02-06 09:01:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:15 --> Input Class Initialized
INFO - 2023-02-06 09:01:15 --> Language Class Initialized
INFO - 2023-02-06 09:01:15 --> Loader Class Initialized
INFO - 2023-02-06 09:01:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:15 --> Total execution time: 0.0036
INFO - 2023-02-06 09:01:15 --> Config Class Initialized
INFO - 2023-02-06 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:15 --> URI Class Initialized
INFO - 2023-02-06 09:01:15 --> Router Class Initialized
INFO - 2023-02-06 09:01:15 --> Output Class Initialized
INFO - 2023-02-06 09:01:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:15 --> Input Class Initialized
INFO - 2023-02-06 09:01:15 --> Language Class Initialized
INFO - 2023-02-06 09:01:15 --> Loader Class Initialized
INFO - 2023-02-06 09:01:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:15 --> Model "Login_model" initialized
INFO - 2023-02-06 09:01:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:15 --> Total execution time: 0.0287
INFO - 2023-02-06 09:01:15 --> Config Class Initialized
INFO - 2023-02-06 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:15 --> URI Class Initialized
INFO - 2023-02-06 09:01:15 --> Router Class Initialized
INFO - 2023-02-06 09:01:15 --> Output Class Initialized
INFO - 2023-02-06 09:01:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:15 --> Input Class Initialized
INFO - 2023-02-06 09:01:15 --> Language Class Initialized
INFO - 2023-02-06 09:01:15 --> Loader Class Initialized
INFO - 2023-02-06 09:01:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:15 --> Total execution time: 0.0471
INFO - 2023-02-06 09:01:15 --> Config Class Initialized
INFO - 2023-02-06 09:01:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:15 --> URI Class Initialized
INFO - 2023-02-06 09:01:15 --> Router Class Initialized
INFO - 2023-02-06 09:01:15 --> Output Class Initialized
INFO - 2023-02-06 09:01:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:15 --> Input Class Initialized
INFO - 2023-02-06 09:01:15 --> Language Class Initialized
INFO - 2023-02-06 09:01:15 --> Loader Class Initialized
INFO - 2023-02-06 09:01:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:15 --> Model "Login_model" initialized
INFO - 2023-02-06 09:01:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:15 --> Total execution time: 0.0297
INFO - 2023-02-06 09:01:18 --> Config Class Initialized
INFO - 2023-02-06 09:01:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:18 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:18 --> URI Class Initialized
INFO - 2023-02-06 09:01:18 --> Router Class Initialized
INFO - 2023-02-06 09:01:18 --> Output Class Initialized
INFO - 2023-02-06 09:01:18 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:18 --> Input Class Initialized
INFO - 2023-02-06 09:01:18 --> Language Class Initialized
INFO - 2023-02-06 09:01:18 --> Loader Class Initialized
INFO - 2023-02-06 09:01:18 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:18 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:18 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:18 --> Model "Login_model" initialized
INFO - 2023-02-06 09:01:18 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:18 --> Total execution time: 0.0417
INFO - 2023-02-06 09:01:18 --> Config Class Initialized
INFO - 2023-02-06 09:01:18 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:01:18 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:01:18 --> Utf8 Class Initialized
INFO - 2023-02-06 09:01:18 --> URI Class Initialized
INFO - 2023-02-06 09:01:18 --> Router Class Initialized
INFO - 2023-02-06 09:01:18 --> Output Class Initialized
INFO - 2023-02-06 09:01:18 --> Security Class Initialized
DEBUG - 2023-02-06 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:01:18 --> Input Class Initialized
INFO - 2023-02-06 09:01:18 --> Language Class Initialized
INFO - 2023-02-06 09:01:18 --> Loader Class Initialized
INFO - 2023-02-06 09:01:18 --> Controller Class Initialized
DEBUG - 2023-02-06 09:01:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:01:18 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:18 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:01:18 --> Database Driver Class Initialized
INFO - 2023-02-06 09:01:18 --> Model "Login_model" initialized
INFO - 2023-02-06 09:01:18 --> Final output sent to browser
DEBUG - 2023-02-06 09:01:18 --> Total execution time: 0.0424
INFO - 2023-02-06 09:05:43 --> Config Class Initialized
INFO - 2023-02-06 09:05:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:05:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:43 --> Utf8 Class Initialized
INFO - 2023-02-06 09:05:43 --> URI Class Initialized
INFO - 2023-02-06 09:05:43 --> Router Class Initialized
INFO - 2023-02-06 09:05:43 --> Output Class Initialized
INFO - 2023-02-06 09:05:43 --> Security Class Initialized
DEBUG - 2023-02-06 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:05:43 --> Input Class Initialized
INFO - 2023-02-06 09:05:43 --> Language Class Initialized
INFO - 2023-02-06 09:05:43 --> Loader Class Initialized
INFO - 2023-02-06 09:05:43 --> Controller Class Initialized
DEBUG - 2023-02-06 09:05:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:05:43 --> Database Driver Class Initialized
INFO - 2023-02-06 09:05:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:05:43 --> Final output sent to browser
DEBUG - 2023-02-06 09:05:43 --> Total execution time: 0.0177
INFO - 2023-02-06 09:05:43 --> Config Class Initialized
INFO - 2023-02-06 09:05:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:05:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:43 --> Utf8 Class Initialized
INFO - 2023-02-06 09:05:43 --> URI Class Initialized
INFO - 2023-02-06 09:05:43 --> Router Class Initialized
INFO - 2023-02-06 09:05:43 --> Output Class Initialized
INFO - 2023-02-06 09:05:43 --> Security Class Initialized
DEBUG - 2023-02-06 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:05:43 --> Input Class Initialized
INFO - 2023-02-06 09:05:43 --> Language Class Initialized
INFO - 2023-02-06 09:05:43 --> Loader Class Initialized
INFO - 2023-02-06 09:05:43 --> Controller Class Initialized
DEBUG - 2023-02-06 09:05:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:05:43 --> Database Driver Class Initialized
INFO - 2023-02-06 09:05:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:05:43 --> Final output sent to browser
DEBUG - 2023-02-06 09:05:43 --> Total execution time: 0.0182
INFO - 2023-02-06 09:05:46 --> Config Class Initialized
INFO - 2023-02-06 09:05:46 --> Hooks Class Initialized
INFO - 2023-02-06 09:05:46 --> Config Class Initialized
DEBUG - 2023-02-06 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:46 --> Hooks Class Initialized
INFO - 2023-02-06 09:05:46 --> Utf8 Class Initialized
DEBUG - 2023-02-06 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:05:46 --> URI Class Initialized
INFO - 2023-02-06 09:05:46 --> URI Class Initialized
INFO - 2023-02-06 09:05:46 --> Router Class Initialized
INFO - 2023-02-06 09:05:46 --> Router Class Initialized
INFO - 2023-02-06 09:05:46 --> Output Class Initialized
INFO - 2023-02-06 09:05:46 --> Output Class Initialized
INFO - 2023-02-06 09:05:46 --> Security Class Initialized
INFO - 2023-02-06 09:05:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:05:46 --> Input Class Initialized
INFO - 2023-02-06 09:05:46 --> Input Class Initialized
INFO - 2023-02-06 09:05:46 --> Language Class Initialized
INFO - 2023-02-06 09:05:46 --> Language Class Initialized
INFO - 2023-02-06 09:05:46 --> Loader Class Initialized
INFO - 2023-02-06 09:05:46 --> Loader Class Initialized
INFO - 2023-02-06 09:05:46 --> Controller Class Initialized
INFO - 2023-02-06 09:05:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:05:46 --> Final output sent to browser
INFO - 2023-02-06 09:05:46 --> Database Driver Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Total execution time: 0.0048
INFO - 2023-02-06 09:05:46 --> Config Class Initialized
INFO - 2023-02-06 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:05:46 --> URI Class Initialized
INFO - 2023-02-06 09:05:46 --> Router Class Initialized
INFO - 2023-02-06 09:05:46 --> Output Class Initialized
INFO - 2023-02-06 09:05:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:05:46 --> Input Class Initialized
INFO - 2023-02-06 09:05:46 --> Language Class Initialized
INFO - 2023-02-06 09:05:46 --> Loader Class Initialized
INFO - 2023-02-06 09:05:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:05:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:05:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:05:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:05:46 --> Total execution time: 0.0183
INFO - 2023-02-06 09:05:46 --> Model "Login_model" initialized
INFO - 2023-02-06 09:05:46 --> Config Class Initialized
INFO - 2023-02-06 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:05:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:05:46 --> URI Class Initialized
INFO - 2023-02-06 09:05:46 --> Router Class Initialized
INFO - 2023-02-06 09:05:46 --> Output Class Initialized
INFO - 2023-02-06 09:05:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:05:46 --> Input Class Initialized
INFO - 2023-02-06 09:05:46 --> Language Class Initialized
INFO - 2023-02-06 09:05:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:05:46 --> Loader Class Initialized
INFO - 2023-02-06 09:05:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:05:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:05:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:05:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:05:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:05:46 --> Total execution time: 0.0282
INFO - 2023-02-06 09:05:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:05:47 --> Total execution time: 0.0194
INFO - 2023-02-06 09:07:24 --> Config Class Initialized
INFO - 2023-02-06 09:07:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:07:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:07:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:07:24 --> URI Class Initialized
INFO - 2023-02-06 09:07:24 --> Router Class Initialized
INFO - 2023-02-06 09:07:24 --> Output Class Initialized
INFO - 2023-02-06 09:07:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:07:24 --> Input Class Initialized
INFO - 2023-02-06 09:07:24 --> Language Class Initialized
INFO - 2023-02-06 09:07:24 --> Loader Class Initialized
INFO - 2023-02-06 09:07:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:07:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:07:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:07:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:07:24 --> Total execution time: 0.0147
INFO - 2023-02-06 09:07:24 --> Config Class Initialized
INFO - 2023-02-06 09:07:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:07:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:07:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:07:24 --> URI Class Initialized
INFO - 2023-02-06 09:07:24 --> Router Class Initialized
INFO - 2023-02-06 09:07:24 --> Output Class Initialized
INFO - 2023-02-06 09:07:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:07:24 --> Input Class Initialized
INFO - 2023-02-06 09:07:24 --> Language Class Initialized
INFO - 2023-02-06 09:07:24 --> Loader Class Initialized
INFO - 2023-02-06 09:07:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:07:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:07:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:07:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:07:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:07:24 --> Total execution time: 0.0110
INFO - 2023-02-06 09:07:26 --> Config Class Initialized
INFO - 2023-02-06 09:07:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:07:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:07:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:07:26 --> URI Class Initialized
INFO - 2023-02-06 09:07:26 --> Router Class Initialized
INFO - 2023-02-06 09:07:26 --> Output Class Initialized
INFO - 2023-02-06 09:07:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:07:26 --> Input Class Initialized
INFO - 2023-02-06 09:07:26 --> Language Class Initialized
INFO - 2023-02-06 09:07:26 --> Loader Class Initialized
INFO - 2023-02-06 09:07:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:07:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:07:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:07:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:07:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:07:26 --> Total execution time: 0.0514
INFO - 2023-02-06 09:07:26 --> Config Class Initialized
INFO - 2023-02-06 09:07:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:07:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:07:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:07:26 --> URI Class Initialized
INFO - 2023-02-06 09:07:26 --> Router Class Initialized
INFO - 2023-02-06 09:07:26 --> Output Class Initialized
INFO - 2023-02-06 09:07:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:07:26 --> Input Class Initialized
INFO - 2023-02-06 09:07:26 --> Language Class Initialized
INFO - 2023-02-06 09:07:26 --> Loader Class Initialized
INFO - 2023-02-06 09:07:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:07:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:07:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:07:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:07:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:07:26 --> Total execution time: 0.0151
INFO - 2023-02-06 09:37:02 --> Config Class Initialized
INFO - 2023-02-06 09:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:02 --> URI Class Initialized
INFO - 2023-02-06 09:37:02 --> Router Class Initialized
INFO - 2023-02-06 09:37:02 --> Output Class Initialized
INFO - 2023-02-06 09:37:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:02 --> Input Class Initialized
INFO - 2023-02-06 09:37:02 --> Language Class Initialized
INFO - 2023-02-06 09:37:02 --> Loader Class Initialized
INFO - 2023-02-06 09:37:02 --> Controller Class Initialized
INFO - 2023-02-06 09:37:02 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:02 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:02 --> Model "Change_model" initialized
INFO - 2023-02-06 09:37:02 --> Model "Grafana_model" initialized
INFO - 2023-02-06 09:37:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:02 --> Total execution time: 0.2283
INFO - 2023-02-06 09:37:02 --> Config Class Initialized
INFO - 2023-02-06 09:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:02 --> URI Class Initialized
INFO - 2023-02-06 09:37:02 --> Router Class Initialized
INFO - 2023-02-06 09:37:02 --> Output Class Initialized
INFO - 2023-02-06 09:37:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:02 --> Input Class Initialized
INFO - 2023-02-06 09:37:02 --> Language Class Initialized
INFO - 2023-02-06 09:37:02 --> Loader Class Initialized
INFO - 2023-02-06 09:37:02 --> Controller Class Initialized
INFO - 2023-02-06 09:37:02 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:02 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:02 --> Total execution time: 0.0042
INFO - 2023-02-06 09:37:02 --> Config Class Initialized
INFO - 2023-02-06 09:37:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:02 --> URI Class Initialized
INFO - 2023-02-06 09:37:02 --> Router Class Initialized
INFO - 2023-02-06 09:37:02 --> Output Class Initialized
INFO - 2023-02-06 09:37:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:02 --> Input Class Initialized
INFO - 2023-02-06 09:37:02 --> Language Class Initialized
INFO - 2023-02-06 09:37:02 --> Loader Class Initialized
INFO - 2023-02-06 09:37:02 --> Controller Class Initialized
INFO - 2023-02-06 09:37:02 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:02 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:04 --> Model "Login_model" initialized
INFO - 2023-02-06 09:37:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:04 --> Total execution time: 1.1157
INFO - 2023-02-06 09:37:16 --> Config Class Initialized
INFO - 2023-02-06 09:37:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:16 --> URI Class Initialized
INFO - 2023-02-06 09:37:16 --> Router Class Initialized
INFO - 2023-02-06 09:37:16 --> Output Class Initialized
INFO - 2023-02-06 09:37:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:16 --> Input Class Initialized
INFO - 2023-02-06 09:37:16 --> Language Class Initialized
INFO - 2023-02-06 09:37:16 --> Loader Class Initialized
INFO - 2023-02-06 09:37:16 --> Controller Class Initialized
INFO - 2023-02-06 09:37:16 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:16 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:16 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:16 --> Total execution time: 0.0043
INFO - 2023-02-06 09:37:16 --> Config Class Initialized
INFO - 2023-02-06 09:37:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:16 --> URI Class Initialized
INFO - 2023-02-06 09:37:16 --> Router Class Initialized
INFO - 2023-02-06 09:37:16 --> Output Class Initialized
INFO - 2023-02-06 09:37:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:16 --> Input Class Initialized
INFO - 2023-02-06 09:37:16 --> Language Class Initialized
INFO - 2023-02-06 09:37:16 --> Loader Class Initialized
INFO - 2023-02-06 09:37:16 --> Controller Class Initialized
INFO - 2023-02-06 09:37:16 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:16 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:16 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:17 --> Model "Login_model" initialized
INFO - 2023-02-06 09:37:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:17 --> Total execution time: 0.1559
INFO - 2023-02-06 09:37:17 --> Config Class Initialized
INFO - 2023-02-06 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:17 --> URI Class Initialized
INFO - 2023-02-06 09:37:17 --> Router Class Initialized
INFO - 2023-02-06 09:37:17 --> Output Class Initialized
INFO - 2023-02-06 09:37:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:17 --> Input Class Initialized
INFO - 2023-02-06 09:37:17 --> Language Class Initialized
INFO - 2023-02-06 09:37:17 --> Loader Class Initialized
INFO - 2023-02-06 09:37:17 --> Controller Class Initialized
INFO - 2023-02-06 09:37:17 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:17 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:17 --> Total execution time: 0.0476
INFO - 2023-02-06 09:37:17 --> Config Class Initialized
INFO - 2023-02-06 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:17 --> URI Class Initialized
INFO - 2023-02-06 09:37:17 --> Router Class Initialized
INFO - 2023-02-06 09:37:17 --> Output Class Initialized
INFO - 2023-02-06 09:37:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:17 --> Input Class Initialized
INFO - 2023-02-06 09:37:17 --> Language Class Initialized
INFO - 2023-02-06 09:37:17 --> Loader Class Initialized
INFO - 2023-02-06 09:37:17 --> Controller Class Initialized
INFO - 2023-02-06 09:37:17 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:17 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:17 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:18 --> Model "Login_model" initialized
INFO - 2023-02-06 09:37:18 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:18 --> Total execution time: 0.1316
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
INFO - 2023-02-06 09:37:24 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:24 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Model "Change_model" initialized
INFO - 2023-02-06 09:37:24 --> Model "Grafana_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0266
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
INFO - 2023-02-06 09:37:24 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:24 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0019
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
INFO - 2023-02-06 09:37:24 --> Helper loaded: form_helper
INFO - 2023-02-06 09:37:24 --> Helper loaded: url_helper
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:24 --> Model "Login_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0144
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0518
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0126
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0606
INFO - 2023-02-06 09:37:24 --> Config Class Initialized
INFO - 2023-02-06 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:24 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:24 --> URI Class Initialized
INFO - 2023-02-06 09:37:24 --> Router Class Initialized
INFO - 2023-02-06 09:37:24 --> Output Class Initialized
INFO - 2023-02-06 09:37:24 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:24 --> Input Class Initialized
INFO - 2023-02-06 09:37:24 --> Language Class Initialized
INFO - 2023-02-06 09:37:24 --> Loader Class Initialized
INFO - 2023-02-06 09:37:24 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:24 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:24 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:24 --> Total execution time: 0.0581
INFO - 2023-02-06 09:37:29 --> Config Class Initialized
INFO - 2023-02-06 09:37:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:29 --> URI Class Initialized
INFO - 2023-02-06 09:37:29 --> Router Class Initialized
INFO - 2023-02-06 09:37:29 --> Output Class Initialized
INFO - 2023-02-06 09:37:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:29 --> Input Class Initialized
INFO - 2023-02-06 09:37:29 --> Language Class Initialized
INFO - 2023-02-06 09:37:29 --> Loader Class Initialized
INFO - 2023-02-06 09:37:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:29 --> Total execution time: 0.0038
INFO - 2023-02-06 09:37:29 --> Config Class Initialized
INFO - 2023-02-06 09:37:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:29 --> URI Class Initialized
INFO - 2023-02-06 09:37:29 --> Router Class Initialized
INFO - 2023-02-06 09:37:29 --> Output Class Initialized
INFO - 2023-02-06 09:37:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:29 --> Input Class Initialized
INFO - 2023-02-06 09:37:29 --> Language Class Initialized
INFO - 2023-02-06 09:37:29 --> Loader Class Initialized
INFO - 2023-02-06 09:37:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:29 --> Total execution time: 0.0583
INFO - 2023-02-06 09:37:29 --> Config Class Initialized
INFO - 2023-02-06 09:37:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:29 --> URI Class Initialized
INFO - 2023-02-06 09:37:29 --> Router Class Initialized
INFO - 2023-02-06 09:37:29 --> Output Class Initialized
INFO - 2023-02-06 09:37:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:29 --> Input Class Initialized
INFO - 2023-02-06 09:37:29 --> Language Class Initialized
INFO - 2023-02-06 09:37:29 --> Loader Class Initialized
INFO - 2023-02-06 09:37:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:29 --> Total execution time: 0.0454
INFO - 2023-02-06 09:37:29 --> Config Class Initialized
INFO - 2023-02-06 09:37:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:29 --> URI Class Initialized
INFO - 2023-02-06 09:37:29 --> Router Class Initialized
INFO - 2023-02-06 09:37:29 --> Output Class Initialized
INFO - 2023-02-06 09:37:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:29 --> Input Class Initialized
INFO - 2023-02-06 09:37:29 --> Language Class Initialized
INFO - 2023-02-06 09:37:29 --> Loader Class Initialized
INFO - 2023-02-06 09:37:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:29 --> Total execution time: 0.0543
INFO - 2023-02-06 09:37:41 --> Config Class Initialized
INFO - 2023-02-06 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:41 --> URI Class Initialized
INFO - 2023-02-06 09:37:41 --> Router Class Initialized
INFO - 2023-02-06 09:37:41 --> Output Class Initialized
INFO - 2023-02-06 09:37:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:41 --> Input Class Initialized
INFO - 2023-02-06 09:37:41 --> Language Class Initialized
INFO - 2023-02-06 09:37:41 --> Loader Class Initialized
INFO - 2023-02-06 09:37:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:41 --> Total execution time: 0.0044
INFO - 2023-02-06 09:37:41 --> Config Class Initialized
INFO - 2023-02-06 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:41 --> URI Class Initialized
INFO - 2023-02-06 09:37:41 --> Router Class Initialized
INFO - 2023-02-06 09:37:41 --> Output Class Initialized
INFO - 2023-02-06 09:37:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:41 --> Input Class Initialized
INFO - 2023-02-06 09:37:41 --> Language Class Initialized
INFO - 2023-02-06 09:37:41 --> Loader Class Initialized
INFO - 2023-02-06 09:37:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:41 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:41 --> Model "Login_model" initialized
INFO - 2023-02-06 09:37:41 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:41 --> Total execution time: 0.0289
INFO - 2023-02-06 09:37:41 --> Config Class Initialized
INFO - 2023-02-06 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:41 --> URI Class Initialized
INFO - 2023-02-06 09:37:41 --> Router Class Initialized
INFO - 2023-02-06 09:37:41 --> Output Class Initialized
INFO - 2023-02-06 09:37:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:41 --> Input Class Initialized
INFO - 2023-02-06 09:37:41 --> Language Class Initialized
INFO - 2023-02-06 09:37:41 --> Loader Class Initialized
INFO - 2023-02-06 09:37:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:41 --> Total execution time: 0.0041
INFO - 2023-02-06 09:37:41 --> Config Class Initialized
INFO - 2023-02-06 09:37:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:41 --> URI Class Initialized
INFO - 2023-02-06 09:37:41 --> Router Class Initialized
INFO - 2023-02-06 09:37:41 --> Output Class Initialized
INFO - 2023-02-06 09:37:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:41 --> Input Class Initialized
INFO - 2023-02-06 09:37:41 --> Language Class Initialized
INFO - 2023-02-06 09:37:41 --> Loader Class Initialized
INFO - 2023-02-06 09:37:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:41 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:41 --> Total execution time: 0.1543
INFO - 2023-02-06 09:37:46 --> Config Class Initialized
INFO - 2023-02-06 09:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:46 --> URI Class Initialized
INFO - 2023-02-06 09:37:46 --> Router Class Initialized
INFO - 2023-02-06 09:37:46 --> Output Class Initialized
INFO - 2023-02-06 09:37:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:46 --> Input Class Initialized
INFO - 2023-02-06 09:37:46 --> Language Class Initialized
INFO - 2023-02-06 09:37:46 --> Loader Class Initialized
INFO - 2023-02-06 09:37:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:46 --> Total execution time: 0.0045
INFO - 2023-02-06 09:37:46 --> Config Class Initialized
INFO - 2023-02-06 09:37:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:46 --> URI Class Initialized
INFO - 2023-02-06 09:37:46 --> Router Class Initialized
INFO - 2023-02-06 09:37:46 --> Output Class Initialized
INFO - 2023-02-06 09:37:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:46 --> Input Class Initialized
INFO - 2023-02-06 09:37:46 --> Language Class Initialized
INFO - 2023-02-06 09:37:46 --> Loader Class Initialized
INFO - 2023-02-06 09:37:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:46 --> Total execution time: 0.0187
INFO - 2023-02-06 09:37:51 --> Config Class Initialized
INFO - 2023-02-06 09:37:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:51 --> URI Class Initialized
INFO - 2023-02-06 09:37:51 --> Router Class Initialized
INFO - 2023-02-06 09:37:51 --> Output Class Initialized
INFO - 2023-02-06 09:37:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:51 --> Input Class Initialized
INFO - 2023-02-06 09:37:51 --> Language Class Initialized
INFO - 2023-02-06 09:37:51 --> Loader Class Initialized
INFO - 2023-02-06 09:37:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:51 --> Total execution time: 0.0043
INFO - 2023-02-06 09:37:51 --> Config Class Initialized
INFO - 2023-02-06 09:37:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:51 --> URI Class Initialized
INFO - 2023-02-06 09:37:51 --> Router Class Initialized
INFO - 2023-02-06 09:37:51 --> Output Class Initialized
INFO - 2023-02-06 09:37:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:51 --> Input Class Initialized
INFO - 2023-02-06 09:37:51 --> Language Class Initialized
INFO - 2023-02-06 09:37:51 --> Loader Class Initialized
INFO - 2023-02-06 09:37:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:51 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:51 --> Total execution time: 0.0411
INFO - 2023-02-06 09:37:56 --> Config Class Initialized
INFO - 2023-02-06 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:56 --> URI Class Initialized
INFO - 2023-02-06 09:37:56 --> Router Class Initialized
INFO - 2023-02-06 09:37:56 --> Output Class Initialized
INFO - 2023-02-06 09:37:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:56 --> Input Class Initialized
INFO - 2023-02-06 09:37:56 --> Language Class Initialized
INFO - 2023-02-06 09:37:56 --> Loader Class Initialized
INFO - 2023-02-06 09:37:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:56 --> Total execution time: 0.0044
INFO - 2023-02-06 09:37:56 --> Config Class Initialized
INFO - 2023-02-06 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:37:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:37:56 --> URI Class Initialized
INFO - 2023-02-06 09:37:56 --> Router Class Initialized
INFO - 2023-02-06 09:37:56 --> Output Class Initialized
INFO - 2023-02-06 09:37:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:37:56 --> Input Class Initialized
INFO - 2023-02-06 09:37:56 --> Language Class Initialized
INFO - 2023-02-06 09:37:56 --> Loader Class Initialized
INFO - 2023-02-06 09:37:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:37:56 --> Database Driver Class Initialized
INFO - 2023-02-06 09:37:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:37:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:37:56 --> Total execution time: 0.0169
INFO - 2023-02-06 09:38:01 --> Config Class Initialized
INFO - 2023-02-06 09:38:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:01 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:01 --> URI Class Initialized
INFO - 2023-02-06 09:38:01 --> Router Class Initialized
INFO - 2023-02-06 09:38:01 --> Output Class Initialized
INFO - 2023-02-06 09:38:01 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:01 --> Input Class Initialized
INFO - 2023-02-06 09:38:01 --> Language Class Initialized
INFO - 2023-02-06 09:38:01 --> Loader Class Initialized
INFO - 2023-02-06 09:38:01 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:01 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:01 --> Total execution time: 0.0040
INFO - 2023-02-06 09:38:01 --> Config Class Initialized
INFO - 2023-02-06 09:38:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:01 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:01 --> URI Class Initialized
INFO - 2023-02-06 09:38:01 --> Router Class Initialized
INFO - 2023-02-06 09:38:01 --> Output Class Initialized
INFO - 2023-02-06 09:38:01 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:01 --> Input Class Initialized
INFO - 2023-02-06 09:38:01 --> Language Class Initialized
INFO - 2023-02-06 09:38:01 --> Loader Class Initialized
INFO - 2023-02-06 09:38:01 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:01 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:01 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:01 --> Total execution time: 0.0133
INFO - 2023-02-06 09:38:06 --> Config Class Initialized
INFO - 2023-02-06 09:38:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:06 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:06 --> URI Class Initialized
INFO - 2023-02-06 09:38:06 --> Router Class Initialized
INFO - 2023-02-06 09:38:06 --> Output Class Initialized
INFO - 2023-02-06 09:38:06 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:06 --> Input Class Initialized
INFO - 2023-02-06 09:38:06 --> Language Class Initialized
INFO - 2023-02-06 09:38:06 --> Loader Class Initialized
INFO - 2023-02-06 09:38:06 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:06 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:06 --> Total execution time: 0.0040
INFO - 2023-02-06 09:38:06 --> Config Class Initialized
INFO - 2023-02-06 09:38:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:06 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:06 --> URI Class Initialized
INFO - 2023-02-06 09:38:06 --> Router Class Initialized
INFO - 2023-02-06 09:38:06 --> Output Class Initialized
INFO - 2023-02-06 09:38:06 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:06 --> Input Class Initialized
INFO - 2023-02-06 09:38:06 --> Language Class Initialized
INFO - 2023-02-06 09:38:06 --> Loader Class Initialized
INFO - 2023-02-06 09:38:06 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:06 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:06 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:06 --> Total execution time: 0.0203
INFO - 2023-02-06 09:38:11 --> Config Class Initialized
INFO - 2023-02-06 09:38:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:11 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:11 --> URI Class Initialized
INFO - 2023-02-06 09:38:11 --> Router Class Initialized
INFO - 2023-02-06 09:38:11 --> Output Class Initialized
INFO - 2023-02-06 09:38:11 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:11 --> Input Class Initialized
INFO - 2023-02-06 09:38:11 --> Language Class Initialized
INFO - 2023-02-06 09:38:11 --> Loader Class Initialized
INFO - 2023-02-06 09:38:11 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:11 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:11 --> Total execution time: 0.0046
INFO - 2023-02-06 09:38:11 --> Config Class Initialized
INFO - 2023-02-06 09:38:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:11 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:11 --> URI Class Initialized
INFO - 2023-02-06 09:38:11 --> Router Class Initialized
INFO - 2023-02-06 09:38:11 --> Output Class Initialized
INFO - 2023-02-06 09:38:11 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:11 --> Input Class Initialized
INFO - 2023-02-06 09:38:11 --> Language Class Initialized
INFO - 2023-02-06 09:38:11 --> Loader Class Initialized
INFO - 2023-02-06 09:38:11 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:11 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:11 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:11 --> Total execution time: 0.3735
INFO - 2023-02-06 09:38:16 --> Config Class Initialized
INFO - 2023-02-06 09:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:16 --> URI Class Initialized
INFO - 2023-02-06 09:38:16 --> Router Class Initialized
INFO - 2023-02-06 09:38:16 --> Output Class Initialized
INFO - 2023-02-06 09:38:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:16 --> Input Class Initialized
INFO - 2023-02-06 09:38:16 --> Language Class Initialized
INFO - 2023-02-06 09:38:16 --> Loader Class Initialized
INFO - 2023-02-06 09:38:16 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:16 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:16 --> Total execution time: 0.0039
INFO - 2023-02-06 09:38:16 --> Config Class Initialized
INFO - 2023-02-06 09:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:16 --> URI Class Initialized
INFO - 2023-02-06 09:38:16 --> Router Class Initialized
INFO - 2023-02-06 09:38:16 --> Output Class Initialized
INFO - 2023-02-06 09:38:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:16 --> Input Class Initialized
INFO - 2023-02-06 09:38:16 --> Language Class Initialized
INFO - 2023-02-06 09:38:16 --> Loader Class Initialized
INFO - 2023-02-06 09:38:16 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:16 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:16 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:16 --> Total execution time: 0.0137
INFO - 2023-02-06 09:38:21 --> Config Class Initialized
INFO - 2023-02-06 09:38:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:21 --> URI Class Initialized
INFO - 2023-02-06 09:38:21 --> Router Class Initialized
INFO - 2023-02-06 09:38:21 --> Output Class Initialized
INFO - 2023-02-06 09:38:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:21 --> Input Class Initialized
INFO - 2023-02-06 09:38:21 --> Language Class Initialized
INFO - 2023-02-06 09:38:21 --> Loader Class Initialized
INFO - 2023-02-06 09:38:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:21 --> Total execution time: 0.0041
INFO - 2023-02-06 09:38:21 --> Config Class Initialized
INFO - 2023-02-06 09:38:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:21 --> URI Class Initialized
INFO - 2023-02-06 09:38:21 --> Router Class Initialized
INFO - 2023-02-06 09:38:21 --> Output Class Initialized
INFO - 2023-02-06 09:38:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:21 --> Input Class Initialized
INFO - 2023-02-06 09:38:21 --> Language Class Initialized
INFO - 2023-02-06 09:38:21 --> Loader Class Initialized
INFO - 2023-02-06 09:38:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:21 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:21 --> Total execution time: 0.0180
INFO - 2023-02-06 09:38:26 --> Config Class Initialized
INFO - 2023-02-06 09:38:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:26 --> URI Class Initialized
INFO - 2023-02-06 09:38:26 --> Router Class Initialized
INFO - 2023-02-06 09:38:26 --> Output Class Initialized
INFO - 2023-02-06 09:38:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:26 --> Input Class Initialized
INFO - 2023-02-06 09:38:26 --> Language Class Initialized
INFO - 2023-02-06 09:38:26 --> Loader Class Initialized
INFO - 2023-02-06 09:38:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:26 --> Total execution time: 0.0046
INFO - 2023-02-06 09:38:26 --> Config Class Initialized
INFO - 2023-02-06 09:38:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:26 --> URI Class Initialized
INFO - 2023-02-06 09:38:26 --> Router Class Initialized
INFO - 2023-02-06 09:38:26 --> Output Class Initialized
INFO - 2023-02-06 09:38:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:26 --> Input Class Initialized
INFO - 2023-02-06 09:38:26 --> Language Class Initialized
INFO - 2023-02-06 09:38:26 --> Loader Class Initialized
INFO - 2023-02-06 09:38:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:26 --> Total execution time: 0.0152
INFO - 2023-02-06 09:38:44 --> Config Class Initialized
INFO - 2023-02-06 09:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:44 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:44 --> URI Class Initialized
INFO - 2023-02-06 09:38:44 --> Router Class Initialized
INFO - 2023-02-06 09:38:44 --> Output Class Initialized
INFO - 2023-02-06 09:38:44 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:44 --> Input Class Initialized
INFO - 2023-02-06 09:38:44 --> Language Class Initialized
INFO - 2023-02-06 09:38:44 --> Loader Class Initialized
INFO - 2023-02-06 09:38:44 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:44 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:44 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:44 --> Total execution time: 0.1027
INFO - 2023-02-06 09:38:44 --> Config Class Initialized
INFO - 2023-02-06 09:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:44 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:44 --> URI Class Initialized
INFO - 2023-02-06 09:38:44 --> Router Class Initialized
INFO - 2023-02-06 09:38:44 --> Output Class Initialized
INFO - 2023-02-06 09:38:44 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:44 --> Input Class Initialized
INFO - 2023-02-06 09:38:44 --> Language Class Initialized
INFO - 2023-02-06 09:38:44 --> Loader Class Initialized
INFO - 2023-02-06 09:38:44 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:44 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:44 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:44 --> Total execution time: 0.0178
INFO - 2023-02-06 09:38:47 --> Config Class Initialized
INFO - 2023-02-06 09:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:47 --> URI Class Initialized
INFO - 2023-02-06 09:38:47 --> Router Class Initialized
INFO - 2023-02-06 09:38:47 --> Output Class Initialized
INFO - 2023-02-06 09:38:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:47 --> Input Class Initialized
INFO - 2023-02-06 09:38:47 --> Language Class Initialized
INFO - 2023-02-06 09:38:47 --> Loader Class Initialized
INFO - 2023-02-06 09:38:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:47 --> Total execution time: 0.0049
INFO - 2023-02-06 09:38:47 --> Config Class Initialized
INFO - 2023-02-06 09:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:47 --> URI Class Initialized
INFO - 2023-02-06 09:38:47 --> Router Class Initialized
INFO - 2023-02-06 09:38:47 --> Output Class Initialized
INFO - 2023-02-06 09:38:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:47 --> Input Class Initialized
INFO - 2023-02-06 09:38:47 --> Language Class Initialized
INFO - 2023-02-06 09:38:47 --> Loader Class Initialized
INFO - 2023-02-06 09:38:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:47 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:47 --> Total execution time: 0.0124
INFO - 2023-02-06 09:38:47 --> Config Class Initialized
INFO - 2023-02-06 09:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:47 --> URI Class Initialized
INFO - 2023-02-06 09:38:47 --> Router Class Initialized
INFO - 2023-02-06 09:38:47 --> Output Class Initialized
INFO - 2023-02-06 09:38:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:47 --> Input Class Initialized
INFO - 2023-02-06 09:38:47 --> Language Class Initialized
INFO - 2023-02-06 09:38:47 --> Loader Class Initialized
INFO - 2023-02-06 09:38:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:47 --> Total execution time: 0.0449
INFO - 2023-02-06 09:38:47 --> Config Class Initialized
INFO - 2023-02-06 09:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:47 --> URI Class Initialized
INFO - 2023-02-06 09:38:47 --> Router Class Initialized
INFO - 2023-02-06 09:38:47 --> Output Class Initialized
INFO - 2023-02-06 09:38:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:47 --> Input Class Initialized
INFO - 2023-02-06 09:38:47 --> Language Class Initialized
INFO - 2023-02-06 09:38:47 --> Loader Class Initialized
INFO - 2023-02-06 09:38:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:47 --> Database Driver Class Initialized
INFO - 2023-02-06 09:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:38:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:47 --> Total execution time: 0.0112
INFO - 2023-02-06 09:38:59 --> Config Class Initialized
INFO - 2023-02-06 09:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:59 --> URI Class Initialized
INFO - 2023-02-06 09:38:59 --> Router Class Initialized
INFO - 2023-02-06 09:38:59 --> Output Class Initialized
INFO - 2023-02-06 09:38:59 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:59 --> Input Class Initialized
INFO - 2023-02-06 09:38:59 --> Language Class Initialized
INFO - 2023-02-06 09:38:59 --> Loader Class Initialized
INFO - 2023-02-06 09:38:59 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:59 --> Final output sent to browser
DEBUG - 2023-02-06 09:38:59 --> Total execution time: 0.0057
INFO - 2023-02-06 09:38:59 --> Config Class Initialized
INFO - 2023-02-06 09:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:38:59 --> Utf8 Class Initialized
INFO - 2023-02-06 09:38:59 --> URI Class Initialized
INFO - 2023-02-06 09:38:59 --> Router Class Initialized
INFO - 2023-02-06 09:38:59 --> Output Class Initialized
INFO - 2023-02-06 09:38:59 --> Security Class Initialized
DEBUG - 2023-02-06 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:38:59 --> Input Class Initialized
INFO - 2023-02-06 09:38:59 --> Language Class Initialized
INFO - 2023-02-06 09:38:59 --> Loader Class Initialized
INFO - 2023-02-06 09:38:59 --> Controller Class Initialized
DEBUG - 2023-02-06 09:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:38:59 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:00 --> Model "Login_model" initialized
INFO - 2023-02-06 09:39:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:00 --> Total execution time: 0.0395
INFO - 2023-02-06 09:39:00 --> Config Class Initialized
INFO - 2023-02-06 09:39:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:00 --> URI Class Initialized
INFO - 2023-02-06 09:39:00 --> Router Class Initialized
INFO - 2023-02-06 09:39:00 --> Output Class Initialized
INFO - 2023-02-06 09:39:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:00 --> Input Class Initialized
INFO - 2023-02-06 09:39:00 --> Language Class Initialized
INFO - 2023-02-06 09:39:00 --> Loader Class Initialized
INFO - 2023-02-06 09:39:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:00 --> Total execution time: 0.0044
INFO - 2023-02-06 09:39:00 --> Config Class Initialized
INFO - 2023-02-06 09:39:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:00 --> URI Class Initialized
INFO - 2023-02-06 09:39:00 --> Router Class Initialized
INFO - 2023-02-06 09:39:00 --> Output Class Initialized
INFO - 2023-02-06 09:39:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:00 --> Input Class Initialized
INFO - 2023-02-06 09:39:00 --> Language Class Initialized
INFO - 2023-02-06 09:39:00 --> Loader Class Initialized
INFO - 2023-02-06 09:39:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:00 --> Total execution time: 0.1441
INFO - 2023-02-06 09:39:05 --> Config Class Initialized
INFO - 2023-02-06 09:39:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:05 --> URI Class Initialized
INFO - 2023-02-06 09:39:05 --> Router Class Initialized
INFO - 2023-02-06 09:39:05 --> Output Class Initialized
INFO - 2023-02-06 09:39:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:05 --> Input Class Initialized
INFO - 2023-02-06 09:39:05 --> Language Class Initialized
INFO - 2023-02-06 09:39:05 --> Loader Class Initialized
INFO - 2023-02-06 09:39:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:05 --> Total execution time: 0.0047
INFO - 2023-02-06 09:39:05 --> Config Class Initialized
INFO - 2023-02-06 09:39:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:05 --> URI Class Initialized
INFO - 2023-02-06 09:39:05 --> Router Class Initialized
INFO - 2023-02-06 09:39:05 --> Output Class Initialized
INFO - 2023-02-06 09:39:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:05 --> Input Class Initialized
INFO - 2023-02-06 09:39:05 --> Language Class Initialized
INFO - 2023-02-06 09:39:05 --> Loader Class Initialized
INFO - 2023-02-06 09:39:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:05 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:05 --> Total execution time: 0.0150
INFO - 2023-02-06 09:39:10 --> Config Class Initialized
INFO - 2023-02-06 09:39:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:10 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:10 --> URI Class Initialized
INFO - 2023-02-06 09:39:10 --> Router Class Initialized
INFO - 2023-02-06 09:39:10 --> Output Class Initialized
INFO - 2023-02-06 09:39:10 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:10 --> Input Class Initialized
INFO - 2023-02-06 09:39:10 --> Language Class Initialized
INFO - 2023-02-06 09:39:10 --> Loader Class Initialized
INFO - 2023-02-06 09:39:10 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:10 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:10 --> Total execution time: 0.0040
INFO - 2023-02-06 09:39:10 --> Config Class Initialized
INFO - 2023-02-06 09:39:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:10 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:10 --> URI Class Initialized
INFO - 2023-02-06 09:39:10 --> Router Class Initialized
INFO - 2023-02-06 09:39:10 --> Output Class Initialized
INFO - 2023-02-06 09:39:10 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:10 --> Input Class Initialized
INFO - 2023-02-06 09:39:10 --> Language Class Initialized
INFO - 2023-02-06 09:39:10 --> Loader Class Initialized
INFO - 2023-02-06 09:39:10 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:10 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:10 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:10 --> Total execution time: 0.0230
INFO - 2023-02-06 09:39:15 --> Config Class Initialized
INFO - 2023-02-06 09:39:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:15 --> URI Class Initialized
INFO - 2023-02-06 09:39:15 --> Router Class Initialized
INFO - 2023-02-06 09:39:15 --> Output Class Initialized
INFO - 2023-02-06 09:39:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:15 --> Input Class Initialized
INFO - 2023-02-06 09:39:15 --> Language Class Initialized
INFO - 2023-02-06 09:39:15 --> Loader Class Initialized
INFO - 2023-02-06 09:39:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:15 --> Total execution time: 0.0044
INFO - 2023-02-06 09:39:15 --> Config Class Initialized
INFO - 2023-02-06 09:39:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:15 --> URI Class Initialized
INFO - 2023-02-06 09:39:15 --> Router Class Initialized
INFO - 2023-02-06 09:39:15 --> Output Class Initialized
INFO - 2023-02-06 09:39:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:15 --> Input Class Initialized
INFO - 2023-02-06 09:39:15 --> Language Class Initialized
INFO - 2023-02-06 09:39:15 --> Loader Class Initialized
INFO - 2023-02-06 09:39:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:15 --> Total execution time: 0.0178
INFO - 2023-02-06 09:39:20 --> Config Class Initialized
INFO - 2023-02-06 09:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:20 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:20 --> URI Class Initialized
INFO - 2023-02-06 09:39:20 --> Router Class Initialized
INFO - 2023-02-06 09:39:20 --> Output Class Initialized
INFO - 2023-02-06 09:39:20 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:20 --> Input Class Initialized
INFO - 2023-02-06 09:39:20 --> Language Class Initialized
INFO - 2023-02-06 09:39:20 --> Loader Class Initialized
INFO - 2023-02-06 09:39:20 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:20 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:20 --> Total execution time: 0.0043
INFO - 2023-02-06 09:39:20 --> Config Class Initialized
INFO - 2023-02-06 09:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:20 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:20 --> URI Class Initialized
INFO - 2023-02-06 09:39:20 --> Router Class Initialized
INFO - 2023-02-06 09:39:20 --> Output Class Initialized
INFO - 2023-02-06 09:39:20 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:20 --> Input Class Initialized
INFO - 2023-02-06 09:39:20 --> Language Class Initialized
INFO - 2023-02-06 09:39:20 --> Loader Class Initialized
INFO - 2023-02-06 09:39:20 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:20 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:20 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:20 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:20 --> Total execution time: 0.0598
INFO - 2023-02-06 09:39:25 --> Config Class Initialized
INFO - 2023-02-06 09:39:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:25 --> URI Class Initialized
INFO - 2023-02-06 09:39:25 --> Router Class Initialized
INFO - 2023-02-06 09:39:25 --> Output Class Initialized
INFO - 2023-02-06 09:39:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:25 --> Input Class Initialized
INFO - 2023-02-06 09:39:25 --> Language Class Initialized
INFO - 2023-02-06 09:39:25 --> Loader Class Initialized
INFO - 2023-02-06 09:39:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:25 --> Total execution time: 0.0459
INFO - 2023-02-06 09:39:25 --> Config Class Initialized
INFO - 2023-02-06 09:39:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:25 --> URI Class Initialized
INFO - 2023-02-06 09:39:25 --> Router Class Initialized
INFO - 2023-02-06 09:39:25 --> Output Class Initialized
INFO - 2023-02-06 09:39:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:25 --> Input Class Initialized
INFO - 2023-02-06 09:39:25 --> Language Class Initialized
INFO - 2023-02-06 09:39:25 --> Loader Class Initialized
INFO - 2023-02-06 09:39:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:25 --> Total execution time: 0.0123
INFO - 2023-02-06 09:39:30 --> Config Class Initialized
INFO - 2023-02-06 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:30 --> URI Class Initialized
INFO - 2023-02-06 09:39:30 --> Router Class Initialized
INFO - 2023-02-06 09:39:30 --> Output Class Initialized
INFO - 2023-02-06 09:39:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:30 --> Input Class Initialized
INFO - 2023-02-06 09:39:30 --> Language Class Initialized
INFO - 2023-02-06 09:39:30 --> Loader Class Initialized
INFO - 2023-02-06 09:39:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:30 --> Total execution time: 0.0041
INFO - 2023-02-06 09:39:30 --> Config Class Initialized
INFO - 2023-02-06 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:30 --> URI Class Initialized
INFO - 2023-02-06 09:39:30 --> Router Class Initialized
INFO - 2023-02-06 09:39:30 --> Output Class Initialized
INFO - 2023-02-06 09:39:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:30 --> Input Class Initialized
INFO - 2023-02-06 09:39:30 --> Language Class Initialized
INFO - 2023-02-06 09:39:30 --> Loader Class Initialized
INFO - 2023-02-06 09:39:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:30 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:30 --> Total execution time: 0.0147
INFO - 2023-02-06 09:39:35 --> Config Class Initialized
INFO - 2023-02-06 09:39:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:35 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:35 --> URI Class Initialized
INFO - 2023-02-06 09:39:35 --> Router Class Initialized
INFO - 2023-02-06 09:39:35 --> Output Class Initialized
INFO - 2023-02-06 09:39:35 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:35 --> Input Class Initialized
INFO - 2023-02-06 09:39:35 --> Language Class Initialized
INFO - 2023-02-06 09:39:35 --> Loader Class Initialized
INFO - 2023-02-06 09:39:35 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:35 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:35 --> Total execution time: 0.0043
INFO - 2023-02-06 09:39:35 --> Config Class Initialized
INFO - 2023-02-06 09:39:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:35 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:35 --> URI Class Initialized
INFO - 2023-02-06 09:39:35 --> Router Class Initialized
INFO - 2023-02-06 09:39:35 --> Output Class Initialized
INFO - 2023-02-06 09:39:35 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:35 --> Input Class Initialized
INFO - 2023-02-06 09:39:35 --> Language Class Initialized
INFO - 2023-02-06 09:39:35 --> Loader Class Initialized
INFO - 2023-02-06 09:39:35 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:35 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:35 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:35 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:35 --> Total execution time: 0.0149
INFO - 2023-02-06 09:39:40 --> Config Class Initialized
INFO - 2023-02-06 09:39:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:40 --> URI Class Initialized
INFO - 2023-02-06 09:39:40 --> Router Class Initialized
INFO - 2023-02-06 09:39:40 --> Output Class Initialized
INFO - 2023-02-06 09:39:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:40 --> Input Class Initialized
INFO - 2023-02-06 09:39:40 --> Language Class Initialized
INFO - 2023-02-06 09:39:40 --> Loader Class Initialized
INFO - 2023-02-06 09:39:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:40 --> Total execution time: 0.0027
INFO - 2023-02-06 09:39:40 --> Config Class Initialized
INFO - 2023-02-06 09:39:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:40 --> URI Class Initialized
INFO - 2023-02-06 09:39:40 --> Router Class Initialized
INFO - 2023-02-06 09:39:40 --> Output Class Initialized
INFO - 2023-02-06 09:39:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:40 --> Input Class Initialized
INFO - 2023-02-06 09:39:40 --> Language Class Initialized
INFO - 2023-02-06 09:39:40 --> Loader Class Initialized
INFO - 2023-02-06 09:39:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:40 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:40 --> Total execution time: 0.0207
INFO - 2023-02-06 09:39:45 --> Config Class Initialized
INFO - 2023-02-06 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:45 --> URI Class Initialized
INFO - 2023-02-06 09:39:45 --> Router Class Initialized
INFO - 2023-02-06 09:39:45 --> Output Class Initialized
INFO - 2023-02-06 09:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:45 --> Input Class Initialized
INFO - 2023-02-06 09:39:45 --> Language Class Initialized
INFO - 2023-02-06 09:39:45 --> Loader Class Initialized
INFO - 2023-02-06 09:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:45 --> Total execution time: 0.0041
INFO - 2023-02-06 09:39:45 --> Config Class Initialized
INFO - 2023-02-06 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:45 --> URI Class Initialized
INFO - 2023-02-06 09:39:45 --> Router Class Initialized
INFO - 2023-02-06 09:39:45 --> Output Class Initialized
INFO - 2023-02-06 09:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:45 --> Input Class Initialized
INFO - 2023-02-06 09:39:45 --> Language Class Initialized
INFO - 2023-02-06 09:39:45 --> Loader Class Initialized
INFO - 2023-02-06 09:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:45 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:45 --> Total execution time: 0.0153
INFO - 2023-02-06 09:39:50 --> Config Class Initialized
INFO - 2023-02-06 09:39:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:50 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:50 --> URI Class Initialized
INFO - 2023-02-06 09:39:50 --> Router Class Initialized
INFO - 2023-02-06 09:39:50 --> Output Class Initialized
INFO - 2023-02-06 09:39:50 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:50 --> Input Class Initialized
INFO - 2023-02-06 09:39:50 --> Language Class Initialized
INFO - 2023-02-06 09:39:50 --> Loader Class Initialized
INFO - 2023-02-06 09:39:50 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:50 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:50 --> Total execution time: 0.0048
INFO - 2023-02-06 09:39:50 --> Config Class Initialized
INFO - 2023-02-06 09:39:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:50 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:50 --> URI Class Initialized
INFO - 2023-02-06 09:39:50 --> Router Class Initialized
INFO - 2023-02-06 09:39:50 --> Output Class Initialized
INFO - 2023-02-06 09:39:50 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:50 --> Input Class Initialized
INFO - 2023-02-06 09:39:50 --> Language Class Initialized
INFO - 2023-02-06 09:39:50 --> Loader Class Initialized
INFO - 2023-02-06 09:39:50 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:50 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:50 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:50 --> Total execution time: 0.0160
INFO - 2023-02-06 09:39:55 --> Config Class Initialized
INFO - 2023-02-06 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:55 --> URI Class Initialized
INFO - 2023-02-06 09:39:55 --> Router Class Initialized
INFO - 2023-02-06 09:39:55 --> Output Class Initialized
INFO - 2023-02-06 09:39:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:55 --> Input Class Initialized
INFO - 2023-02-06 09:39:55 --> Language Class Initialized
INFO - 2023-02-06 09:39:55 --> Loader Class Initialized
INFO - 2023-02-06 09:39:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:55 --> Total execution time: 0.0041
INFO - 2023-02-06 09:39:55 --> Config Class Initialized
INFO - 2023-02-06 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:39:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:39:55 --> URI Class Initialized
INFO - 2023-02-06 09:39:55 --> Router Class Initialized
INFO - 2023-02-06 09:39:55 --> Output Class Initialized
INFO - 2023-02-06 09:39:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:39:55 --> Input Class Initialized
INFO - 2023-02-06 09:39:55 --> Language Class Initialized
INFO - 2023-02-06 09:39:55 --> Loader Class Initialized
INFO - 2023-02-06 09:39:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:39:55 --> Database Driver Class Initialized
INFO - 2023-02-06 09:39:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:39:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:39:55 --> Total execution time: 0.0150
INFO - 2023-02-06 09:40:00 --> Config Class Initialized
INFO - 2023-02-06 09:40:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:00 --> URI Class Initialized
INFO - 2023-02-06 09:40:00 --> Router Class Initialized
INFO - 2023-02-06 09:40:00 --> Output Class Initialized
INFO - 2023-02-06 09:40:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:00 --> Input Class Initialized
INFO - 2023-02-06 09:40:00 --> Language Class Initialized
INFO - 2023-02-06 09:40:00 --> Loader Class Initialized
INFO - 2023-02-06 09:40:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:00 --> Total execution time: 0.0043
INFO - 2023-02-06 09:40:00 --> Config Class Initialized
INFO - 2023-02-06 09:40:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:00 --> URI Class Initialized
INFO - 2023-02-06 09:40:00 --> Router Class Initialized
INFO - 2023-02-06 09:40:00 --> Output Class Initialized
INFO - 2023-02-06 09:40:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:00 --> Input Class Initialized
INFO - 2023-02-06 09:40:00 --> Language Class Initialized
INFO - 2023-02-06 09:40:00 --> Loader Class Initialized
INFO - 2023-02-06 09:40:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:00 --> Total execution time: 0.0165
INFO - 2023-02-06 09:40:05 --> Config Class Initialized
INFO - 2023-02-06 09:40:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:05 --> URI Class Initialized
INFO - 2023-02-06 09:40:05 --> Router Class Initialized
INFO - 2023-02-06 09:40:05 --> Output Class Initialized
INFO - 2023-02-06 09:40:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:05 --> Input Class Initialized
INFO - 2023-02-06 09:40:05 --> Language Class Initialized
INFO - 2023-02-06 09:40:05 --> Loader Class Initialized
INFO - 2023-02-06 09:40:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:05 --> Total execution time: 0.0041
INFO - 2023-02-06 09:40:05 --> Config Class Initialized
INFO - 2023-02-06 09:40:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:05 --> URI Class Initialized
INFO - 2023-02-06 09:40:05 --> Router Class Initialized
INFO - 2023-02-06 09:40:05 --> Output Class Initialized
INFO - 2023-02-06 09:40:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:05 --> Input Class Initialized
INFO - 2023-02-06 09:40:05 --> Language Class Initialized
INFO - 2023-02-06 09:40:05 --> Loader Class Initialized
INFO - 2023-02-06 09:40:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:05 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:05 --> Total execution time: 0.0137
INFO - 2023-02-06 09:40:43 --> Config Class Initialized
INFO - 2023-02-06 09:40:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:43 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:43 --> URI Class Initialized
INFO - 2023-02-06 09:40:43 --> Router Class Initialized
INFO - 2023-02-06 09:40:43 --> Output Class Initialized
INFO - 2023-02-06 09:40:43 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:43 --> Input Class Initialized
INFO - 2023-02-06 09:40:43 --> Language Class Initialized
INFO - 2023-02-06 09:40:43 --> Loader Class Initialized
INFO - 2023-02-06 09:40:43 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:43 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:43 --> Total execution time: 0.2860
INFO - 2023-02-06 09:40:43 --> Config Class Initialized
INFO - 2023-02-06 09:40:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:43 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:43 --> URI Class Initialized
INFO - 2023-02-06 09:40:43 --> Router Class Initialized
INFO - 2023-02-06 09:40:43 --> Output Class Initialized
INFO - 2023-02-06 09:40:43 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:43 --> Input Class Initialized
INFO - 2023-02-06 09:40:43 --> Language Class Initialized
INFO - 2023-02-06 09:40:43 --> Loader Class Initialized
INFO - 2023-02-06 09:40:43 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:44 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:44 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:44 --> Total execution time: 0.0985
INFO - 2023-02-06 09:40:44 --> Config Class Initialized
INFO - 2023-02-06 09:40:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:44 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:44 --> URI Class Initialized
INFO - 2023-02-06 09:40:44 --> Router Class Initialized
INFO - 2023-02-06 09:40:44 --> Output Class Initialized
INFO - 2023-02-06 09:40:44 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:44 --> Input Class Initialized
INFO - 2023-02-06 09:40:44 --> Language Class Initialized
INFO - 2023-02-06 09:40:44 --> Loader Class Initialized
INFO - 2023-02-06 09:40:44 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:44 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:44 --> Total execution time: 0.0830
INFO - 2023-02-06 09:40:44 --> Config Class Initialized
INFO - 2023-02-06 09:40:44 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:44 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:44 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:44 --> URI Class Initialized
INFO - 2023-02-06 09:40:44 --> Router Class Initialized
INFO - 2023-02-06 09:40:44 --> Output Class Initialized
INFO - 2023-02-06 09:40:44 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:44 --> Input Class Initialized
INFO - 2023-02-06 09:40:44 --> Language Class Initialized
INFO - 2023-02-06 09:40:44 --> Loader Class Initialized
INFO - 2023-02-06 09:40:44 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:44 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:44 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:44 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:44 --> Total execution time: 0.0114
INFO - 2023-02-06 09:40:48 --> Config Class Initialized
INFO - 2023-02-06 09:40:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:48 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:48 --> URI Class Initialized
INFO - 2023-02-06 09:40:48 --> Router Class Initialized
INFO - 2023-02-06 09:40:48 --> Output Class Initialized
INFO - 2023-02-06 09:40:48 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:48 --> Input Class Initialized
INFO - 2023-02-06 09:40:48 --> Language Class Initialized
INFO - 2023-02-06 09:40:48 --> Loader Class Initialized
INFO - 2023-02-06 09:40:48 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:48 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:48 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:48 --> Total execution time: 0.1040
INFO - 2023-02-06 09:40:48 --> Config Class Initialized
INFO - 2023-02-06 09:40:48 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:48 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:48 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:48 --> URI Class Initialized
INFO - 2023-02-06 09:40:48 --> Router Class Initialized
INFO - 2023-02-06 09:40:48 --> Output Class Initialized
INFO - 2023-02-06 09:40:48 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:48 --> Input Class Initialized
INFO - 2023-02-06 09:40:48 --> Language Class Initialized
INFO - 2023-02-06 09:40:48 --> Loader Class Initialized
INFO - 2023-02-06 09:40:48 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:48 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:48 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:48 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:48 --> Total execution time: 0.0176
INFO - 2023-02-06 09:40:51 --> Config Class Initialized
INFO - 2023-02-06 09:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:51 --> URI Class Initialized
INFO - 2023-02-06 09:40:51 --> Router Class Initialized
INFO - 2023-02-06 09:40:51 --> Output Class Initialized
INFO - 2023-02-06 09:40:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:51 --> Input Class Initialized
INFO - 2023-02-06 09:40:51 --> Language Class Initialized
INFO - 2023-02-06 09:40:51 --> Loader Class Initialized
INFO - 2023-02-06 09:40:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:51 --> Total execution time: 0.0052
INFO - 2023-02-06 09:40:51 --> Config Class Initialized
INFO - 2023-02-06 09:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:51 --> URI Class Initialized
INFO - 2023-02-06 09:40:51 --> Router Class Initialized
INFO - 2023-02-06 09:40:51 --> Output Class Initialized
INFO - 2023-02-06 09:40:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:51 --> Input Class Initialized
INFO - 2023-02-06 09:40:51 --> Language Class Initialized
INFO - 2023-02-06 09:40:51 --> Loader Class Initialized
INFO - 2023-02-06 09:40:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:51 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:51 --> Total execution time: 0.0676
INFO - 2023-02-06 09:40:51 --> Config Class Initialized
INFO - 2023-02-06 09:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:51 --> URI Class Initialized
INFO - 2023-02-06 09:40:51 --> Router Class Initialized
INFO - 2023-02-06 09:40:51 --> Output Class Initialized
INFO - 2023-02-06 09:40:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:51 --> Input Class Initialized
INFO - 2023-02-06 09:40:51 --> Language Class Initialized
INFO - 2023-02-06 09:40:51 --> Loader Class Initialized
INFO - 2023-02-06 09:40:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:51 --> Total execution time: 0.0415
INFO - 2023-02-06 09:40:51 --> Config Class Initialized
INFO - 2023-02-06 09:40:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:40:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:40:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:40:51 --> URI Class Initialized
INFO - 2023-02-06 09:40:51 --> Router Class Initialized
INFO - 2023-02-06 09:40:51 --> Output Class Initialized
INFO - 2023-02-06 09:40:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:40:51 --> Input Class Initialized
INFO - 2023-02-06 09:40:51 --> Language Class Initialized
INFO - 2023-02-06 09:40:51 --> Loader Class Initialized
INFO - 2023-02-06 09:40:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:40:51 --> Database Driver Class Initialized
INFO - 2023-02-06 09:40:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:40:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:40:52 --> Total execution time: 0.1207
INFO - 2023-02-06 09:41:02 --> Config Class Initialized
INFO - 2023-02-06 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:02 --> URI Class Initialized
INFO - 2023-02-06 09:41:02 --> Router Class Initialized
INFO - 2023-02-06 09:41:02 --> Output Class Initialized
INFO - 2023-02-06 09:41:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:02 --> Input Class Initialized
INFO - 2023-02-06 09:41:02 --> Language Class Initialized
INFO - 2023-02-06 09:41:02 --> Loader Class Initialized
INFO - 2023-02-06 09:41:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:02 --> Total execution time: 0.0047
INFO - 2023-02-06 09:41:02 --> Config Class Initialized
INFO - 2023-02-06 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:02 --> URI Class Initialized
INFO - 2023-02-06 09:41:02 --> Router Class Initialized
INFO - 2023-02-06 09:41:02 --> Output Class Initialized
INFO - 2023-02-06 09:41:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:02 --> Input Class Initialized
INFO - 2023-02-06 09:41:02 --> Language Class Initialized
INFO - 2023-02-06 09:41:02 --> Loader Class Initialized
INFO - 2023-02-06 09:41:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:02 --> Model "Login_model" initialized
INFO - 2023-02-06 09:41:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:02 --> Total execution time: 0.0294
INFO - 2023-02-06 09:41:02 --> Config Class Initialized
INFO - 2023-02-06 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:02 --> URI Class Initialized
INFO - 2023-02-06 09:41:02 --> Router Class Initialized
INFO - 2023-02-06 09:41:02 --> Output Class Initialized
INFO - 2023-02-06 09:41:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:02 --> Input Class Initialized
INFO - 2023-02-06 09:41:02 --> Language Class Initialized
INFO - 2023-02-06 09:41:02 --> Loader Class Initialized
INFO - 2023-02-06 09:41:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:02 --> Total execution time: 0.0186
INFO - 2023-02-06 09:41:02 --> Config Class Initialized
INFO - 2023-02-06 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:02 --> URI Class Initialized
INFO - 2023-02-06 09:41:02 --> Router Class Initialized
INFO - 2023-02-06 09:41:02 --> Output Class Initialized
INFO - 2023-02-06 09:41:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:02 --> Input Class Initialized
INFO - 2023-02-06 09:41:02 --> Language Class Initialized
INFO - 2023-02-06 09:41:02 --> Loader Class Initialized
INFO - 2023-02-06 09:41:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:02 --> Total execution time: 0.1154
INFO - 2023-02-06 09:41:07 --> Config Class Initialized
INFO - 2023-02-06 09:41:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:07 --> URI Class Initialized
INFO - 2023-02-06 09:41:07 --> Router Class Initialized
INFO - 2023-02-06 09:41:07 --> Output Class Initialized
INFO - 2023-02-06 09:41:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:07 --> Input Class Initialized
INFO - 2023-02-06 09:41:07 --> Language Class Initialized
INFO - 2023-02-06 09:41:07 --> Loader Class Initialized
INFO - 2023-02-06 09:41:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:07 --> Total execution time: 0.0093
INFO - 2023-02-06 09:41:07 --> Config Class Initialized
INFO - 2023-02-06 09:41:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:07 --> URI Class Initialized
INFO - 2023-02-06 09:41:07 --> Router Class Initialized
INFO - 2023-02-06 09:41:07 --> Output Class Initialized
INFO - 2023-02-06 09:41:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:07 --> Input Class Initialized
INFO - 2023-02-06 09:41:07 --> Language Class Initialized
INFO - 2023-02-06 09:41:07 --> Loader Class Initialized
INFO - 2023-02-06 09:41:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:07 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:07 --> Total execution time: 0.0153
INFO - 2023-02-06 09:41:12 --> Config Class Initialized
INFO - 2023-02-06 09:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:12 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:12 --> URI Class Initialized
INFO - 2023-02-06 09:41:12 --> Router Class Initialized
INFO - 2023-02-06 09:41:12 --> Output Class Initialized
INFO - 2023-02-06 09:41:12 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:12 --> Input Class Initialized
INFO - 2023-02-06 09:41:12 --> Language Class Initialized
INFO - 2023-02-06 09:41:12 --> Loader Class Initialized
INFO - 2023-02-06 09:41:12 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:12 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:12 --> Total execution time: 0.0046
INFO - 2023-02-06 09:41:12 --> Config Class Initialized
INFO - 2023-02-06 09:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:12 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:12 --> URI Class Initialized
INFO - 2023-02-06 09:41:12 --> Router Class Initialized
INFO - 2023-02-06 09:41:12 --> Output Class Initialized
INFO - 2023-02-06 09:41:12 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:12 --> Input Class Initialized
INFO - 2023-02-06 09:41:12 --> Language Class Initialized
INFO - 2023-02-06 09:41:12 --> Loader Class Initialized
INFO - 2023-02-06 09:41:12 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:12 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:12 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:12 --> Total execution time: 0.0156
INFO - 2023-02-06 09:41:17 --> Config Class Initialized
INFO - 2023-02-06 09:41:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:17 --> URI Class Initialized
INFO - 2023-02-06 09:41:17 --> Router Class Initialized
INFO - 2023-02-06 09:41:17 --> Output Class Initialized
INFO - 2023-02-06 09:41:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:17 --> Input Class Initialized
INFO - 2023-02-06 09:41:17 --> Language Class Initialized
INFO - 2023-02-06 09:41:17 --> Loader Class Initialized
INFO - 2023-02-06 09:41:17 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:17 --> Total execution time: 0.0042
INFO - 2023-02-06 09:41:17 --> Config Class Initialized
INFO - 2023-02-06 09:41:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:17 --> URI Class Initialized
INFO - 2023-02-06 09:41:17 --> Router Class Initialized
INFO - 2023-02-06 09:41:17 --> Output Class Initialized
INFO - 2023-02-06 09:41:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:17 --> Input Class Initialized
INFO - 2023-02-06 09:41:17 --> Language Class Initialized
INFO - 2023-02-06 09:41:17 --> Loader Class Initialized
INFO - 2023-02-06 09:41:17 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:17 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:17 --> Total execution time: 0.0151
INFO - 2023-02-06 09:41:22 --> Config Class Initialized
INFO - 2023-02-06 09:41:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:22 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:22 --> URI Class Initialized
INFO - 2023-02-06 09:41:22 --> Router Class Initialized
INFO - 2023-02-06 09:41:22 --> Output Class Initialized
INFO - 2023-02-06 09:41:22 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:22 --> Input Class Initialized
INFO - 2023-02-06 09:41:22 --> Language Class Initialized
INFO - 2023-02-06 09:41:22 --> Loader Class Initialized
INFO - 2023-02-06 09:41:22 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:22 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:22 --> Total execution time: 0.0041
INFO - 2023-02-06 09:41:22 --> Config Class Initialized
INFO - 2023-02-06 09:41:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:22 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:22 --> URI Class Initialized
INFO - 2023-02-06 09:41:22 --> Router Class Initialized
INFO - 2023-02-06 09:41:22 --> Output Class Initialized
INFO - 2023-02-06 09:41:22 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:22 --> Input Class Initialized
INFO - 2023-02-06 09:41:22 --> Language Class Initialized
INFO - 2023-02-06 09:41:22 --> Loader Class Initialized
INFO - 2023-02-06 09:41:22 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:22 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:22 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:22 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:22 --> Total execution time: 0.0178
INFO - 2023-02-06 09:41:27 --> Config Class Initialized
INFO - 2023-02-06 09:41:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:27 --> URI Class Initialized
INFO - 2023-02-06 09:41:27 --> Router Class Initialized
INFO - 2023-02-06 09:41:27 --> Output Class Initialized
INFO - 2023-02-06 09:41:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:27 --> Input Class Initialized
INFO - 2023-02-06 09:41:27 --> Language Class Initialized
INFO - 2023-02-06 09:41:27 --> Loader Class Initialized
INFO - 2023-02-06 09:41:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:27 --> Total execution time: 0.0040
INFO - 2023-02-06 09:41:27 --> Config Class Initialized
INFO - 2023-02-06 09:41:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:27 --> URI Class Initialized
INFO - 2023-02-06 09:41:27 --> Router Class Initialized
INFO - 2023-02-06 09:41:27 --> Output Class Initialized
INFO - 2023-02-06 09:41:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:27 --> Input Class Initialized
INFO - 2023-02-06 09:41:27 --> Language Class Initialized
INFO - 2023-02-06 09:41:27 --> Loader Class Initialized
INFO - 2023-02-06 09:41:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:27 --> Total execution time: 0.0146
INFO - 2023-02-06 09:41:32 --> Config Class Initialized
INFO - 2023-02-06 09:41:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:32 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:32 --> URI Class Initialized
INFO - 2023-02-06 09:41:32 --> Router Class Initialized
INFO - 2023-02-06 09:41:32 --> Output Class Initialized
INFO - 2023-02-06 09:41:32 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:32 --> Input Class Initialized
INFO - 2023-02-06 09:41:32 --> Language Class Initialized
INFO - 2023-02-06 09:41:32 --> Loader Class Initialized
INFO - 2023-02-06 09:41:32 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:32 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:32 --> Total execution time: 0.0041
INFO - 2023-02-06 09:41:32 --> Config Class Initialized
INFO - 2023-02-06 09:41:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:32 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:32 --> URI Class Initialized
INFO - 2023-02-06 09:41:32 --> Router Class Initialized
INFO - 2023-02-06 09:41:32 --> Output Class Initialized
INFO - 2023-02-06 09:41:32 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:32 --> Input Class Initialized
INFO - 2023-02-06 09:41:32 --> Language Class Initialized
INFO - 2023-02-06 09:41:32 --> Loader Class Initialized
INFO - 2023-02-06 09:41:32 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:32 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:32 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:32 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:32 --> Total execution time: 0.0191
INFO - 2023-02-06 09:41:37 --> Config Class Initialized
INFO - 2023-02-06 09:41:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:37 --> URI Class Initialized
INFO - 2023-02-06 09:41:37 --> Router Class Initialized
INFO - 2023-02-06 09:41:37 --> Output Class Initialized
INFO - 2023-02-06 09:41:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:37 --> Input Class Initialized
INFO - 2023-02-06 09:41:37 --> Language Class Initialized
INFO - 2023-02-06 09:41:37 --> Loader Class Initialized
INFO - 2023-02-06 09:41:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:37 --> Total execution time: 0.0109
INFO - 2023-02-06 09:41:37 --> Config Class Initialized
INFO - 2023-02-06 09:41:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:37 --> URI Class Initialized
INFO - 2023-02-06 09:41:37 --> Router Class Initialized
INFO - 2023-02-06 09:41:37 --> Output Class Initialized
INFO - 2023-02-06 09:41:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:37 --> Input Class Initialized
INFO - 2023-02-06 09:41:37 --> Language Class Initialized
INFO - 2023-02-06 09:41:37 --> Loader Class Initialized
INFO - 2023-02-06 09:41:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:37 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:37 --> Total execution time: 0.0167
INFO - 2023-02-06 09:41:42 --> Config Class Initialized
INFO - 2023-02-06 09:41:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:42 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:42 --> URI Class Initialized
INFO - 2023-02-06 09:41:42 --> Router Class Initialized
INFO - 2023-02-06 09:41:42 --> Output Class Initialized
INFO - 2023-02-06 09:41:42 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:42 --> Input Class Initialized
INFO - 2023-02-06 09:41:42 --> Language Class Initialized
INFO - 2023-02-06 09:41:42 --> Loader Class Initialized
INFO - 2023-02-06 09:41:42 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:42 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:42 --> Total execution time: 0.0040
INFO - 2023-02-06 09:41:42 --> Config Class Initialized
INFO - 2023-02-06 09:41:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:42 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:42 --> URI Class Initialized
INFO - 2023-02-06 09:41:42 --> Router Class Initialized
INFO - 2023-02-06 09:41:42 --> Output Class Initialized
INFO - 2023-02-06 09:41:42 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:42 --> Input Class Initialized
INFO - 2023-02-06 09:41:42 --> Language Class Initialized
INFO - 2023-02-06 09:41:42 --> Loader Class Initialized
INFO - 2023-02-06 09:41:42 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:42 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:42 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:42 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:42 --> Total execution time: 0.0158
INFO - 2023-02-06 09:41:47 --> Config Class Initialized
INFO - 2023-02-06 09:41:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:47 --> URI Class Initialized
INFO - 2023-02-06 09:41:47 --> Router Class Initialized
INFO - 2023-02-06 09:41:47 --> Output Class Initialized
INFO - 2023-02-06 09:41:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:47 --> Input Class Initialized
INFO - 2023-02-06 09:41:47 --> Language Class Initialized
INFO - 2023-02-06 09:41:47 --> Loader Class Initialized
INFO - 2023-02-06 09:41:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:47 --> Total execution time: 0.0042
INFO - 2023-02-06 09:41:47 --> Config Class Initialized
INFO - 2023-02-06 09:41:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:47 --> URI Class Initialized
INFO - 2023-02-06 09:41:47 --> Router Class Initialized
INFO - 2023-02-06 09:41:47 --> Output Class Initialized
INFO - 2023-02-06 09:41:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:47 --> Input Class Initialized
INFO - 2023-02-06 09:41:47 --> Language Class Initialized
INFO - 2023-02-06 09:41:47 --> Loader Class Initialized
INFO - 2023-02-06 09:41:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:47 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:47 --> Total execution time: 0.0151
INFO - 2023-02-06 09:41:52 --> Config Class Initialized
INFO - 2023-02-06 09:41:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:52 --> URI Class Initialized
INFO - 2023-02-06 09:41:52 --> Router Class Initialized
INFO - 2023-02-06 09:41:52 --> Output Class Initialized
INFO - 2023-02-06 09:41:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:52 --> Input Class Initialized
INFO - 2023-02-06 09:41:52 --> Language Class Initialized
INFO - 2023-02-06 09:41:52 --> Loader Class Initialized
INFO - 2023-02-06 09:41:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:52 --> Total execution time: 0.0037
INFO - 2023-02-06 09:41:52 --> Config Class Initialized
INFO - 2023-02-06 09:41:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:52 --> URI Class Initialized
INFO - 2023-02-06 09:41:52 --> Router Class Initialized
INFO - 2023-02-06 09:41:52 --> Output Class Initialized
INFO - 2023-02-06 09:41:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:52 --> Input Class Initialized
INFO - 2023-02-06 09:41:52 --> Language Class Initialized
INFO - 2023-02-06 09:41:52 --> Loader Class Initialized
INFO - 2023-02-06 09:41:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:52 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:52 --> Total execution time: 0.0308
INFO - 2023-02-06 09:41:57 --> Config Class Initialized
INFO - 2023-02-06 09:41:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:57 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:57 --> URI Class Initialized
INFO - 2023-02-06 09:41:57 --> Router Class Initialized
INFO - 2023-02-06 09:41:57 --> Output Class Initialized
INFO - 2023-02-06 09:41:57 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:57 --> Input Class Initialized
INFO - 2023-02-06 09:41:57 --> Language Class Initialized
INFO - 2023-02-06 09:41:57 --> Loader Class Initialized
INFO - 2023-02-06 09:41:57 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:57 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:57 --> Total execution time: 0.0047
INFO - 2023-02-06 09:41:57 --> Config Class Initialized
INFO - 2023-02-06 09:41:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:41:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:41:57 --> Utf8 Class Initialized
INFO - 2023-02-06 09:41:57 --> URI Class Initialized
INFO - 2023-02-06 09:41:57 --> Router Class Initialized
INFO - 2023-02-06 09:41:57 --> Output Class Initialized
INFO - 2023-02-06 09:41:57 --> Security Class Initialized
DEBUG - 2023-02-06 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:41:57 --> Input Class Initialized
INFO - 2023-02-06 09:41:57 --> Language Class Initialized
INFO - 2023-02-06 09:41:57 --> Loader Class Initialized
INFO - 2023-02-06 09:41:57 --> Controller Class Initialized
DEBUG - 2023-02-06 09:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:41:57 --> Database Driver Class Initialized
INFO - 2023-02-06 09:41:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:41:57 --> Final output sent to browser
DEBUG - 2023-02-06 09:41:57 --> Total execution time: 0.0131
INFO - 2023-02-06 09:42:02 --> Config Class Initialized
INFO - 2023-02-06 09:42:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:02 --> URI Class Initialized
INFO - 2023-02-06 09:42:02 --> Router Class Initialized
INFO - 2023-02-06 09:42:02 --> Output Class Initialized
INFO - 2023-02-06 09:42:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:02 --> Input Class Initialized
INFO - 2023-02-06 09:42:02 --> Language Class Initialized
INFO - 2023-02-06 09:42:02 --> Loader Class Initialized
INFO - 2023-02-06 09:42:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:02 --> Total execution time: 0.0039
INFO - 2023-02-06 09:42:02 --> Config Class Initialized
INFO - 2023-02-06 09:42:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:02 --> URI Class Initialized
INFO - 2023-02-06 09:42:02 --> Router Class Initialized
INFO - 2023-02-06 09:42:02 --> Output Class Initialized
INFO - 2023-02-06 09:42:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:02 --> Input Class Initialized
INFO - 2023-02-06 09:42:02 --> Language Class Initialized
INFO - 2023-02-06 09:42:02 --> Loader Class Initialized
INFO - 2023-02-06 09:42:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:02 --> Total execution time: 0.0133
INFO - 2023-02-06 09:42:07 --> Config Class Initialized
INFO - 2023-02-06 09:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:07 --> URI Class Initialized
INFO - 2023-02-06 09:42:07 --> Router Class Initialized
INFO - 2023-02-06 09:42:07 --> Output Class Initialized
INFO - 2023-02-06 09:42:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:07 --> Input Class Initialized
INFO - 2023-02-06 09:42:07 --> Language Class Initialized
INFO - 2023-02-06 09:42:07 --> Loader Class Initialized
INFO - 2023-02-06 09:42:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:07 --> Total execution time: 0.0092
INFO - 2023-02-06 09:42:07 --> Config Class Initialized
INFO - 2023-02-06 09:42:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:07 --> URI Class Initialized
INFO - 2023-02-06 09:42:07 --> Router Class Initialized
INFO - 2023-02-06 09:42:07 --> Output Class Initialized
INFO - 2023-02-06 09:42:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:07 --> Input Class Initialized
INFO - 2023-02-06 09:42:07 --> Language Class Initialized
INFO - 2023-02-06 09:42:07 --> Loader Class Initialized
INFO - 2023-02-06 09:42:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:07 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:07 --> Total execution time: 0.0146
INFO - 2023-02-06 09:42:12 --> Config Class Initialized
INFO - 2023-02-06 09:42:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:12 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:12 --> URI Class Initialized
INFO - 2023-02-06 09:42:12 --> Router Class Initialized
INFO - 2023-02-06 09:42:12 --> Output Class Initialized
INFO - 2023-02-06 09:42:12 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:12 --> Input Class Initialized
INFO - 2023-02-06 09:42:12 --> Language Class Initialized
INFO - 2023-02-06 09:42:12 --> Loader Class Initialized
INFO - 2023-02-06 09:42:12 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:12 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:12 --> Total execution time: 0.0039
INFO - 2023-02-06 09:42:12 --> Config Class Initialized
INFO - 2023-02-06 09:42:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:12 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:12 --> URI Class Initialized
INFO - 2023-02-06 09:42:12 --> Router Class Initialized
INFO - 2023-02-06 09:42:12 --> Output Class Initialized
INFO - 2023-02-06 09:42:12 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:12 --> Input Class Initialized
INFO - 2023-02-06 09:42:12 --> Language Class Initialized
INFO - 2023-02-06 09:42:12 --> Loader Class Initialized
INFO - 2023-02-06 09:42:12 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:12 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:12 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:12 --> Total execution time: 0.0131
INFO - 2023-02-06 09:42:17 --> Config Class Initialized
INFO - 2023-02-06 09:42:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:17 --> URI Class Initialized
INFO - 2023-02-06 09:42:17 --> Router Class Initialized
INFO - 2023-02-06 09:42:17 --> Output Class Initialized
INFO - 2023-02-06 09:42:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:17 --> Input Class Initialized
INFO - 2023-02-06 09:42:17 --> Language Class Initialized
INFO - 2023-02-06 09:42:17 --> Loader Class Initialized
INFO - 2023-02-06 09:42:17 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:17 --> Total execution time: 0.0039
INFO - 2023-02-06 09:42:17 --> Config Class Initialized
INFO - 2023-02-06 09:42:17 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:17 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:17 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:17 --> URI Class Initialized
INFO - 2023-02-06 09:42:17 --> Router Class Initialized
INFO - 2023-02-06 09:42:17 --> Output Class Initialized
INFO - 2023-02-06 09:42:17 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:17 --> Input Class Initialized
INFO - 2023-02-06 09:42:17 --> Language Class Initialized
INFO - 2023-02-06 09:42:17 --> Loader Class Initialized
INFO - 2023-02-06 09:42:17 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:17 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:17 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:17 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:17 --> Total execution time: 0.0170
INFO - 2023-02-06 09:42:22 --> Config Class Initialized
INFO - 2023-02-06 09:42:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:22 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:22 --> URI Class Initialized
INFO - 2023-02-06 09:42:22 --> Router Class Initialized
INFO - 2023-02-06 09:42:22 --> Output Class Initialized
INFO - 2023-02-06 09:42:22 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:22 --> Input Class Initialized
INFO - 2023-02-06 09:42:22 --> Language Class Initialized
INFO - 2023-02-06 09:42:22 --> Loader Class Initialized
INFO - 2023-02-06 09:42:22 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:22 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:22 --> Total execution time: 0.0038
INFO - 2023-02-06 09:42:22 --> Config Class Initialized
INFO - 2023-02-06 09:42:22 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:22 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:22 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:22 --> URI Class Initialized
INFO - 2023-02-06 09:42:22 --> Router Class Initialized
INFO - 2023-02-06 09:42:22 --> Output Class Initialized
INFO - 2023-02-06 09:42:22 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:22 --> Input Class Initialized
INFO - 2023-02-06 09:42:22 --> Language Class Initialized
INFO - 2023-02-06 09:42:22 --> Loader Class Initialized
INFO - 2023-02-06 09:42:22 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:22 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:22 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:22 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:22 --> Total execution time: 0.0141
INFO - 2023-02-06 09:42:27 --> Config Class Initialized
INFO - 2023-02-06 09:42:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:27 --> URI Class Initialized
INFO - 2023-02-06 09:42:27 --> Router Class Initialized
INFO - 2023-02-06 09:42:27 --> Output Class Initialized
INFO - 2023-02-06 09:42:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:27 --> Input Class Initialized
INFO - 2023-02-06 09:42:27 --> Language Class Initialized
INFO - 2023-02-06 09:42:27 --> Loader Class Initialized
INFO - 2023-02-06 09:42:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:27 --> Total execution time: 0.0040
INFO - 2023-02-06 09:42:27 --> Config Class Initialized
INFO - 2023-02-06 09:42:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:27 --> URI Class Initialized
INFO - 2023-02-06 09:42:27 --> Router Class Initialized
INFO - 2023-02-06 09:42:27 --> Output Class Initialized
INFO - 2023-02-06 09:42:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:27 --> Input Class Initialized
INFO - 2023-02-06 09:42:27 --> Language Class Initialized
INFO - 2023-02-06 09:42:27 --> Loader Class Initialized
INFO - 2023-02-06 09:42:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:27 --> Total execution time: 0.0154
INFO - 2023-02-06 09:42:32 --> Config Class Initialized
INFO - 2023-02-06 09:42:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:32 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:32 --> URI Class Initialized
INFO - 2023-02-06 09:42:32 --> Router Class Initialized
INFO - 2023-02-06 09:42:32 --> Output Class Initialized
INFO - 2023-02-06 09:42:32 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:32 --> Input Class Initialized
INFO - 2023-02-06 09:42:32 --> Language Class Initialized
INFO - 2023-02-06 09:42:32 --> Loader Class Initialized
INFO - 2023-02-06 09:42:32 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:32 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:32 --> Total execution time: 0.0041
INFO - 2023-02-06 09:42:32 --> Config Class Initialized
INFO - 2023-02-06 09:42:32 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:32 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:32 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:32 --> URI Class Initialized
INFO - 2023-02-06 09:42:32 --> Router Class Initialized
INFO - 2023-02-06 09:42:32 --> Output Class Initialized
INFO - 2023-02-06 09:42:32 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:32 --> Input Class Initialized
INFO - 2023-02-06 09:42:32 --> Language Class Initialized
INFO - 2023-02-06 09:42:32 --> Loader Class Initialized
INFO - 2023-02-06 09:42:32 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:32 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:32 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:32 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:32 --> Total execution time: 0.0154
INFO - 2023-02-06 09:42:37 --> Config Class Initialized
INFO - 2023-02-06 09:42:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:37 --> URI Class Initialized
INFO - 2023-02-06 09:42:37 --> Router Class Initialized
INFO - 2023-02-06 09:42:37 --> Output Class Initialized
INFO - 2023-02-06 09:42:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:37 --> Input Class Initialized
INFO - 2023-02-06 09:42:37 --> Language Class Initialized
INFO - 2023-02-06 09:42:37 --> Loader Class Initialized
INFO - 2023-02-06 09:42:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:37 --> Total execution time: 0.0044
INFO - 2023-02-06 09:42:37 --> Config Class Initialized
INFO - 2023-02-06 09:42:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:37 --> URI Class Initialized
INFO - 2023-02-06 09:42:37 --> Router Class Initialized
INFO - 2023-02-06 09:42:37 --> Output Class Initialized
INFO - 2023-02-06 09:42:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:37 --> Input Class Initialized
INFO - 2023-02-06 09:42:37 --> Language Class Initialized
INFO - 2023-02-06 09:42:37 --> Loader Class Initialized
INFO - 2023-02-06 09:42:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:37 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:37 --> Total execution time: 0.0147
INFO - 2023-02-06 09:42:42 --> Config Class Initialized
INFO - 2023-02-06 09:42:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:42 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:42 --> URI Class Initialized
INFO - 2023-02-06 09:42:42 --> Router Class Initialized
INFO - 2023-02-06 09:42:42 --> Output Class Initialized
INFO - 2023-02-06 09:42:42 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:42 --> Input Class Initialized
INFO - 2023-02-06 09:42:42 --> Language Class Initialized
INFO - 2023-02-06 09:42:42 --> Loader Class Initialized
INFO - 2023-02-06 09:42:42 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:42 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:42 --> Total execution time: 0.0041
INFO - 2023-02-06 09:42:42 --> Config Class Initialized
INFO - 2023-02-06 09:42:42 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:42 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:42 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:42 --> URI Class Initialized
INFO - 2023-02-06 09:42:42 --> Router Class Initialized
INFO - 2023-02-06 09:42:42 --> Output Class Initialized
INFO - 2023-02-06 09:42:42 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:42 --> Input Class Initialized
INFO - 2023-02-06 09:42:42 --> Language Class Initialized
INFO - 2023-02-06 09:42:42 --> Loader Class Initialized
INFO - 2023-02-06 09:42:42 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:42 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:42 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:42 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:42 --> Total execution time: 0.0182
INFO - 2023-02-06 09:42:47 --> Config Class Initialized
INFO - 2023-02-06 09:42:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:47 --> URI Class Initialized
INFO - 2023-02-06 09:42:47 --> Router Class Initialized
INFO - 2023-02-06 09:42:47 --> Output Class Initialized
INFO - 2023-02-06 09:42:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:47 --> Input Class Initialized
INFO - 2023-02-06 09:42:47 --> Language Class Initialized
INFO - 2023-02-06 09:42:47 --> Loader Class Initialized
INFO - 2023-02-06 09:42:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:47 --> Total execution time: 0.0038
INFO - 2023-02-06 09:42:47 --> Config Class Initialized
INFO - 2023-02-06 09:42:47 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:47 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:47 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:47 --> URI Class Initialized
INFO - 2023-02-06 09:42:47 --> Router Class Initialized
INFO - 2023-02-06 09:42:47 --> Output Class Initialized
INFO - 2023-02-06 09:42:47 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:47 --> Input Class Initialized
INFO - 2023-02-06 09:42:47 --> Language Class Initialized
INFO - 2023-02-06 09:42:47 --> Loader Class Initialized
INFO - 2023-02-06 09:42:47 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:47 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:47 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:47 --> Total execution time: 0.0599
INFO - 2023-02-06 09:42:52 --> Config Class Initialized
INFO - 2023-02-06 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:52 --> URI Class Initialized
INFO - 2023-02-06 09:42:52 --> Router Class Initialized
INFO - 2023-02-06 09:42:52 --> Output Class Initialized
INFO - 2023-02-06 09:42:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:52 --> Input Class Initialized
INFO - 2023-02-06 09:42:52 --> Language Class Initialized
INFO - 2023-02-06 09:42:52 --> Loader Class Initialized
INFO - 2023-02-06 09:42:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:52 --> Total execution time: 0.0039
INFO - 2023-02-06 09:42:52 --> Config Class Initialized
INFO - 2023-02-06 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:52 --> URI Class Initialized
INFO - 2023-02-06 09:42:52 --> Router Class Initialized
INFO - 2023-02-06 09:42:52 --> Output Class Initialized
INFO - 2023-02-06 09:42:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:52 --> Input Class Initialized
INFO - 2023-02-06 09:42:52 --> Language Class Initialized
INFO - 2023-02-06 09:42:52 --> Loader Class Initialized
INFO - 2023-02-06 09:42:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:52 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:52 --> Total execution time: 0.0154
INFO - 2023-02-06 09:42:57 --> Config Class Initialized
INFO - 2023-02-06 09:42:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:57 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:57 --> URI Class Initialized
INFO - 2023-02-06 09:42:57 --> Router Class Initialized
INFO - 2023-02-06 09:42:57 --> Output Class Initialized
INFO - 2023-02-06 09:42:57 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:57 --> Input Class Initialized
INFO - 2023-02-06 09:42:57 --> Language Class Initialized
INFO - 2023-02-06 09:42:57 --> Loader Class Initialized
INFO - 2023-02-06 09:42:57 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:57 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:57 --> Total execution time: 0.0041
INFO - 2023-02-06 09:42:57 --> Config Class Initialized
INFO - 2023-02-06 09:42:57 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:42:57 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:42:57 --> Utf8 Class Initialized
INFO - 2023-02-06 09:42:57 --> URI Class Initialized
INFO - 2023-02-06 09:42:57 --> Router Class Initialized
INFO - 2023-02-06 09:42:57 --> Output Class Initialized
INFO - 2023-02-06 09:42:57 --> Security Class Initialized
DEBUG - 2023-02-06 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:42:57 --> Input Class Initialized
INFO - 2023-02-06 09:42:57 --> Language Class Initialized
INFO - 2023-02-06 09:42:57 --> Loader Class Initialized
INFO - 2023-02-06 09:42:57 --> Controller Class Initialized
DEBUG - 2023-02-06 09:42:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:42:57 --> Database Driver Class Initialized
INFO - 2023-02-06 09:42:57 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:42:57 --> Final output sent to browser
DEBUG - 2023-02-06 09:42:57 --> Total execution time: 0.0126
INFO - 2023-02-06 09:43:02 --> Config Class Initialized
INFO - 2023-02-06 09:43:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:02 --> URI Class Initialized
INFO - 2023-02-06 09:43:02 --> Router Class Initialized
INFO - 2023-02-06 09:43:02 --> Output Class Initialized
INFO - 2023-02-06 09:43:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:02 --> Input Class Initialized
INFO - 2023-02-06 09:43:02 --> Language Class Initialized
INFO - 2023-02-06 09:43:02 --> Loader Class Initialized
INFO - 2023-02-06 09:43:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:02 --> Total execution time: 0.0039
INFO - 2023-02-06 09:43:02 --> Config Class Initialized
INFO - 2023-02-06 09:43:02 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:02 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:02 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:02 --> URI Class Initialized
INFO - 2023-02-06 09:43:02 --> Router Class Initialized
INFO - 2023-02-06 09:43:02 --> Output Class Initialized
INFO - 2023-02-06 09:43:02 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:02 --> Input Class Initialized
INFO - 2023-02-06 09:43:02 --> Language Class Initialized
INFO - 2023-02-06 09:43:02 --> Loader Class Initialized
INFO - 2023-02-06 09:43:02 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:02 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:03 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:03 --> Total execution time: 0.8857
INFO - 2023-02-06 09:43:07 --> Config Class Initialized
INFO - 2023-02-06 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:07 --> URI Class Initialized
INFO - 2023-02-06 09:43:07 --> Router Class Initialized
INFO - 2023-02-06 09:43:07 --> Output Class Initialized
INFO - 2023-02-06 09:43:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:07 --> Input Class Initialized
INFO - 2023-02-06 09:43:07 --> Language Class Initialized
INFO - 2023-02-06 09:43:07 --> Loader Class Initialized
INFO - 2023-02-06 09:43:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:07 --> Total execution time: 0.0043
INFO - 2023-02-06 09:43:07 --> Config Class Initialized
INFO - 2023-02-06 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:07 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:07 --> URI Class Initialized
INFO - 2023-02-06 09:43:07 --> Router Class Initialized
INFO - 2023-02-06 09:43:07 --> Output Class Initialized
INFO - 2023-02-06 09:43:07 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:07 --> Input Class Initialized
INFO - 2023-02-06 09:43:07 --> Language Class Initialized
INFO - 2023-02-06 09:43:07 --> Loader Class Initialized
INFO - 2023-02-06 09:43:07 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:07 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:07 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:07 --> Total execution time: 0.0189
INFO - 2023-02-06 09:43:45 --> Config Class Initialized
INFO - 2023-02-06 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:45 --> URI Class Initialized
INFO - 2023-02-06 09:43:45 --> Router Class Initialized
INFO - 2023-02-06 09:43:45 --> Output Class Initialized
INFO - 2023-02-06 09:43:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:45 --> Input Class Initialized
INFO - 2023-02-06 09:43:45 --> Language Class Initialized
INFO - 2023-02-06 09:43:45 --> Loader Class Initialized
INFO - 2023-02-06 09:43:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:45 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:45 --> Total execution time: 0.0137
INFO - 2023-02-06 09:43:45 --> Config Class Initialized
INFO - 2023-02-06 09:43:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:45 --> URI Class Initialized
INFO - 2023-02-06 09:43:45 --> Router Class Initialized
INFO - 2023-02-06 09:43:45 --> Output Class Initialized
INFO - 2023-02-06 09:43:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:45 --> Input Class Initialized
INFO - 2023-02-06 09:43:45 --> Language Class Initialized
INFO - 2023-02-06 09:43:45 --> Loader Class Initialized
INFO - 2023-02-06 09:43:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:45 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:45 --> Total execution time: 0.0110
INFO - 2023-02-06 09:43:52 --> Config Class Initialized
INFO - 2023-02-06 09:43:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:52 --> URI Class Initialized
INFO - 2023-02-06 09:43:52 --> Router Class Initialized
INFO - 2023-02-06 09:43:52 --> Output Class Initialized
INFO - 2023-02-06 09:43:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:52 --> Input Class Initialized
INFO - 2023-02-06 09:43:52 --> Language Class Initialized
INFO - 2023-02-06 09:43:52 --> Loader Class Initialized
INFO - 2023-02-06 09:43:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:52 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:52 --> Total execution time: 0.1016
INFO - 2023-02-06 09:43:52 --> Config Class Initialized
INFO - 2023-02-06 09:43:52 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:52 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:52 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:52 --> URI Class Initialized
INFO - 2023-02-06 09:43:52 --> Router Class Initialized
INFO - 2023-02-06 09:43:52 --> Output Class Initialized
INFO - 2023-02-06 09:43:52 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:52 --> Input Class Initialized
INFO - 2023-02-06 09:43:52 --> Language Class Initialized
INFO - 2023-02-06 09:43:52 --> Loader Class Initialized
INFO - 2023-02-06 09:43:52 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:52 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:52 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:52 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:52 --> Total execution time: 0.0127
INFO - 2023-02-06 09:43:53 --> Config Class Initialized
INFO - 2023-02-06 09:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:53 --> URI Class Initialized
INFO - 2023-02-06 09:43:53 --> Router Class Initialized
INFO - 2023-02-06 09:43:53 --> Output Class Initialized
INFO - 2023-02-06 09:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:53 --> Input Class Initialized
INFO - 2023-02-06 09:43:53 --> Language Class Initialized
INFO - 2023-02-06 09:43:53 --> Loader Class Initialized
INFO - 2023-02-06 09:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:53 --> Total execution time: 0.0035
INFO - 2023-02-06 09:43:53 --> Config Class Initialized
INFO - 2023-02-06 09:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:53 --> URI Class Initialized
INFO - 2023-02-06 09:43:53 --> Router Class Initialized
INFO - 2023-02-06 09:43:53 --> Output Class Initialized
INFO - 2023-02-06 09:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:53 --> Input Class Initialized
INFO - 2023-02-06 09:43:53 --> Language Class Initialized
INFO - 2023-02-06 09:43:53 --> Loader Class Initialized
INFO - 2023-02-06 09:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:53 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:53 --> Total execution time: 0.0150
INFO - 2023-02-06 09:43:53 --> Config Class Initialized
INFO - 2023-02-06 09:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:53 --> URI Class Initialized
INFO - 2023-02-06 09:43:53 --> Router Class Initialized
INFO - 2023-02-06 09:43:53 --> Output Class Initialized
INFO - 2023-02-06 09:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:53 --> Input Class Initialized
INFO - 2023-02-06 09:43:53 --> Language Class Initialized
INFO - 2023-02-06 09:43:53 --> Loader Class Initialized
INFO - 2023-02-06 09:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:53 --> Total execution time: 0.0415
INFO - 2023-02-06 09:43:53 --> Config Class Initialized
INFO - 2023-02-06 09:43:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:43:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:43:53 --> Utf8 Class Initialized
INFO - 2023-02-06 09:43:53 --> URI Class Initialized
INFO - 2023-02-06 09:43:53 --> Router Class Initialized
INFO - 2023-02-06 09:43:53 --> Output Class Initialized
INFO - 2023-02-06 09:43:53 --> Security Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:43:53 --> Input Class Initialized
INFO - 2023-02-06 09:43:53 --> Language Class Initialized
INFO - 2023-02-06 09:43:53 --> Loader Class Initialized
INFO - 2023-02-06 09:43:53 --> Controller Class Initialized
DEBUG - 2023-02-06 09:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:43:53 --> Database Driver Class Initialized
INFO - 2023-02-06 09:43:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:43:53 --> Final output sent to browser
DEBUG - 2023-02-06 09:43:53 --> Total execution time: 0.0103
INFO - 2023-02-06 09:44:04 --> Config Class Initialized
INFO - 2023-02-06 09:44:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:04 --> URI Class Initialized
INFO - 2023-02-06 09:44:04 --> Router Class Initialized
INFO - 2023-02-06 09:44:04 --> Output Class Initialized
INFO - 2023-02-06 09:44:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:04 --> Input Class Initialized
INFO - 2023-02-06 09:44:04 --> Language Class Initialized
INFO - 2023-02-06 09:44:04 --> Loader Class Initialized
INFO - 2023-02-06 09:44:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:04 --> Total execution time: 0.0036
INFO - 2023-02-06 09:44:04 --> Config Class Initialized
INFO - 2023-02-06 09:44:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:04 --> URI Class Initialized
INFO - 2023-02-06 09:44:04 --> Router Class Initialized
INFO - 2023-02-06 09:44:04 --> Output Class Initialized
INFO - 2023-02-06 09:44:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:04 --> Input Class Initialized
INFO - 2023-02-06 09:44:04 --> Language Class Initialized
INFO - 2023-02-06 09:44:04 --> Loader Class Initialized
INFO - 2023-02-06 09:44:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:04 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:04 --> Model "Login_model" initialized
INFO - 2023-02-06 09:44:04 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:04 --> Total execution time: 0.0328
INFO - 2023-02-06 09:44:04 --> Config Class Initialized
INFO - 2023-02-06 09:44:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:04 --> URI Class Initialized
INFO - 2023-02-06 09:44:04 --> Router Class Initialized
INFO - 2023-02-06 09:44:04 --> Output Class Initialized
INFO - 2023-02-06 09:44:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:04 --> Input Class Initialized
INFO - 2023-02-06 09:44:04 --> Language Class Initialized
INFO - 2023-02-06 09:44:04 --> Loader Class Initialized
INFO - 2023-02-06 09:44:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:04 --> Total execution time: 0.0057
INFO - 2023-02-06 09:44:04 --> Config Class Initialized
INFO - 2023-02-06 09:44:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:04 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:04 --> URI Class Initialized
INFO - 2023-02-06 09:44:04 --> Router Class Initialized
INFO - 2023-02-06 09:44:04 --> Output Class Initialized
INFO - 2023-02-06 09:44:04 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:04 --> Input Class Initialized
INFO - 2023-02-06 09:44:04 --> Language Class Initialized
INFO - 2023-02-06 09:44:04 --> Loader Class Initialized
INFO - 2023-02-06 09:44:04 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:04 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:04 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:04 --> Total execution time: 0.1435
INFO - 2023-02-06 09:44:09 --> Config Class Initialized
INFO - 2023-02-06 09:44:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:09 --> URI Class Initialized
INFO - 2023-02-06 09:44:09 --> Router Class Initialized
INFO - 2023-02-06 09:44:09 --> Output Class Initialized
INFO - 2023-02-06 09:44:09 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:09 --> Input Class Initialized
INFO - 2023-02-06 09:44:09 --> Language Class Initialized
INFO - 2023-02-06 09:44:09 --> Loader Class Initialized
INFO - 2023-02-06 09:44:09 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:09 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:09 --> Total execution time: 0.0040
INFO - 2023-02-06 09:44:09 --> Config Class Initialized
INFO - 2023-02-06 09:44:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:09 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:09 --> URI Class Initialized
INFO - 2023-02-06 09:44:09 --> Router Class Initialized
INFO - 2023-02-06 09:44:09 --> Output Class Initialized
INFO - 2023-02-06 09:44:09 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:09 --> Input Class Initialized
INFO - 2023-02-06 09:44:09 --> Language Class Initialized
INFO - 2023-02-06 09:44:09 --> Loader Class Initialized
INFO - 2023-02-06 09:44:09 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:09 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:09 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:09 --> Total execution time: 0.0144
INFO - 2023-02-06 09:44:14 --> Config Class Initialized
INFO - 2023-02-06 09:44:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:14 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:14 --> URI Class Initialized
INFO - 2023-02-06 09:44:14 --> Router Class Initialized
INFO - 2023-02-06 09:44:14 --> Output Class Initialized
INFO - 2023-02-06 09:44:14 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:14 --> Input Class Initialized
INFO - 2023-02-06 09:44:14 --> Language Class Initialized
INFO - 2023-02-06 09:44:14 --> Loader Class Initialized
INFO - 2023-02-06 09:44:14 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:14 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:14 --> Total execution time: 0.0037
INFO - 2023-02-06 09:44:14 --> Config Class Initialized
INFO - 2023-02-06 09:44:14 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:14 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:14 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:14 --> URI Class Initialized
INFO - 2023-02-06 09:44:14 --> Router Class Initialized
INFO - 2023-02-06 09:44:14 --> Output Class Initialized
INFO - 2023-02-06 09:44:14 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:14 --> Input Class Initialized
INFO - 2023-02-06 09:44:14 --> Language Class Initialized
INFO - 2023-02-06 09:44:14 --> Loader Class Initialized
INFO - 2023-02-06 09:44:14 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:14 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:14 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:14 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:14 --> Total execution time: 0.0148
INFO - 2023-02-06 09:44:27 --> Config Class Initialized
INFO - 2023-02-06 09:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:27 --> URI Class Initialized
INFO - 2023-02-06 09:44:27 --> Router Class Initialized
INFO - 2023-02-06 09:44:27 --> Output Class Initialized
INFO - 2023-02-06 09:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:27 --> Input Class Initialized
INFO - 2023-02-06 09:44:27 --> Language Class Initialized
INFO - 2023-02-06 09:44:27 --> Loader Class Initialized
INFO - 2023-02-06 09:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:27 --> Total execution time: 0.0060
INFO - 2023-02-06 09:44:27 --> Config Class Initialized
INFO - 2023-02-06 09:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:27 --> URI Class Initialized
INFO - 2023-02-06 09:44:27 --> Router Class Initialized
INFO - 2023-02-06 09:44:27 --> Output Class Initialized
INFO - 2023-02-06 09:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:27 --> Input Class Initialized
INFO - 2023-02-06 09:44:27 --> Language Class Initialized
INFO - 2023-02-06 09:44:27 --> Loader Class Initialized
INFO - 2023-02-06 09:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:27 --> Model "Login_model" initialized
INFO - 2023-02-06 09:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:27 --> Total execution time: 0.0258
INFO - 2023-02-06 09:44:27 --> Config Class Initialized
INFO - 2023-02-06 09:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:27 --> URI Class Initialized
INFO - 2023-02-06 09:44:27 --> Router Class Initialized
INFO - 2023-02-06 09:44:27 --> Output Class Initialized
INFO - 2023-02-06 09:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:27 --> Input Class Initialized
INFO - 2023-02-06 09:44:27 --> Language Class Initialized
INFO - 2023-02-06 09:44:27 --> Loader Class Initialized
INFO - 2023-02-06 09:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:27 --> Total execution time: 0.0143
INFO - 2023-02-06 09:44:27 --> Config Class Initialized
INFO - 2023-02-06 09:44:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:27 --> URI Class Initialized
INFO - 2023-02-06 09:44:27 --> Router Class Initialized
INFO - 2023-02-06 09:44:27 --> Output Class Initialized
INFO - 2023-02-06 09:44:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:27 --> Input Class Initialized
INFO - 2023-02-06 09:44:27 --> Language Class Initialized
INFO - 2023-02-06 09:44:27 --> Loader Class Initialized
INFO - 2023-02-06 09:44:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:27 --> Total execution time: 0.0598
INFO - 2023-02-06 09:44:28 --> Config Class Initialized
INFO - 2023-02-06 09:44:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:28 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:28 --> URI Class Initialized
INFO - 2023-02-06 09:44:28 --> Router Class Initialized
INFO - 2023-02-06 09:44:28 --> Output Class Initialized
INFO - 2023-02-06 09:44:28 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:28 --> Input Class Initialized
INFO - 2023-02-06 09:44:28 --> Language Class Initialized
INFO - 2023-02-06 09:44:28 --> Loader Class Initialized
INFO - 2023-02-06 09:44:28 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:28 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:28 --> Total execution time: 0.0096
INFO - 2023-02-06 09:44:28 --> Config Class Initialized
INFO - 2023-02-06 09:44:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:28 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:28 --> URI Class Initialized
INFO - 2023-02-06 09:44:28 --> Router Class Initialized
INFO - 2023-02-06 09:44:28 --> Output Class Initialized
INFO - 2023-02-06 09:44:28 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:28 --> Input Class Initialized
INFO - 2023-02-06 09:44:28 --> Language Class Initialized
INFO - 2023-02-06 09:44:28 --> Loader Class Initialized
INFO - 2023-02-06 09:44:28 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:28 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:28 --> Model "Login_model" initialized
INFO - 2023-02-06 09:44:28 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:28 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:28 --> Total execution time: 0.0184
INFO - 2023-02-06 09:44:28 --> Config Class Initialized
INFO - 2023-02-06 09:44:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:28 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:28 --> URI Class Initialized
INFO - 2023-02-06 09:44:28 --> Router Class Initialized
INFO - 2023-02-06 09:44:28 --> Output Class Initialized
INFO - 2023-02-06 09:44:28 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:28 --> Input Class Initialized
INFO - 2023-02-06 09:44:28 --> Language Class Initialized
INFO - 2023-02-06 09:44:28 --> Loader Class Initialized
INFO - 2023-02-06 09:44:28 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:28 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:28 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:28 --> Total execution time: 0.0191
INFO - 2023-02-06 09:44:28 --> Config Class Initialized
INFO - 2023-02-06 09:44:28 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:28 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:28 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:28 --> URI Class Initialized
INFO - 2023-02-06 09:44:28 --> Router Class Initialized
INFO - 2023-02-06 09:44:28 --> Output Class Initialized
INFO - 2023-02-06 09:44:28 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:28 --> Input Class Initialized
INFO - 2023-02-06 09:44:28 --> Language Class Initialized
INFO - 2023-02-06 09:44:28 --> Loader Class Initialized
INFO - 2023-02-06 09:44:28 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:28 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:28 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:28 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:28 --> Total execution time: 0.0137
INFO - 2023-02-06 09:44:29 --> Config Class Initialized
INFO - 2023-02-06 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:29 --> URI Class Initialized
INFO - 2023-02-06 09:44:29 --> Router Class Initialized
INFO - 2023-02-06 09:44:29 --> Output Class Initialized
INFO - 2023-02-06 09:44:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:29 --> Input Class Initialized
INFO - 2023-02-06 09:44:29 --> Language Class Initialized
INFO - 2023-02-06 09:44:29 --> Loader Class Initialized
INFO - 2023-02-06 09:44:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:29 --> Total execution time: 0.0169
INFO - 2023-02-06 09:44:29 --> Config Class Initialized
INFO - 2023-02-06 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:29 --> URI Class Initialized
INFO - 2023-02-06 09:44:29 --> Router Class Initialized
INFO - 2023-02-06 09:44:29 --> Output Class Initialized
INFO - 2023-02-06 09:44:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:29 --> Input Class Initialized
INFO - 2023-02-06 09:44:29 --> Language Class Initialized
INFO - 2023-02-06 09:44:29 --> Loader Class Initialized
INFO - 2023-02-06 09:44:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:29 --> Total execution time: 0.0120
INFO - 2023-02-06 09:44:34 --> Config Class Initialized
INFO - 2023-02-06 09:44:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:34 --> URI Class Initialized
INFO - 2023-02-06 09:44:34 --> Router Class Initialized
INFO - 2023-02-06 09:44:34 --> Output Class Initialized
INFO - 2023-02-06 09:44:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:34 --> Input Class Initialized
INFO - 2023-02-06 09:44:34 --> Language Class Initialized
INFO - 2023-02-06 09:44:34 --> Loader Class Initialized
INFO - 2023-02-06 09:44:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:34 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:34 --> Total execution time: 0.0167
INFO - 2023-02-06 09:44:34 --> Config Class Initialized
INFO - 2023-02-06 09:44:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:34 --> URI Class Initialized
INFO - 2023-02-06 09:44:34 --> Router Class Initialized
INFO - 2023-02-06 09:44:34 --> Output Class Initialized
INFO - 2023-02-06 09:44:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:34 --> Input Class Initialized
INFO - 2023-02-06 09:44:34 --> Language Class Initialized
INFO - 2023-02-06 09:44:34 --> Loader Class Initialized
INFO - 2023-02-06 09:44:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:34 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:34 --> Total execution time: 0.0114
INFO - 2023-02-06 09:44:35 --> Config Class Initialized
INFO - 2023-02-06 09:44:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:35 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:35 --> URI Class Initialized
INFO - 2023-02-06 09:44:35 --> Router Class Initialized
INFO - 2023-02-06 09:44:35 --> Output Class Initialized
INFO - 2023-02-06 09:44:35 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:35 --> Input Class Initialized
INFO - 2023-02-06 09:44:35 --> Language Class Initialized
INFO - 2023-02-06 09:44:35 --> Loader Class Initialized
INFO - 2023-02-06 09:44:35 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:35 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:35 --> Total execution time: 0.0037
INFO - 2023-02-06 09:44:35 --> Config Class Initialized
INFO - 2023-02-06 09:44:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:35 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:35 --> URI Class Initialized
INFO - 2023-02-06 09:44:35 --> Router Class Initialized
INFO - 2023-02-06 09:44:35 --> Output Class Initialized
INFO - 2023-02-06 09:44:35 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:35 --> Input Class Initialized
INFO - 2023-02-06 09:44:35 --> Language Class Initialized
INFO - 2023-02-06 09:44:35 --> Loader Class Initialized
INFO - 2023-02-06 09:44:35 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:35 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:35 --> Model "Login_model" initialized
INFO - 2023-02-06 09:44:35 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:35 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:35 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:35 --> Total execution time: 0.0189
INFO - 2023-02-06 09:44:36 --> Config Class Initialized
INFO - 2023-02-06 09:44:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:36 --> URI Class Initialized
INFO - 2023-02-06 09:44:36 --> Router Class Initialized
INFO - 2023-02-06 09:44:36 --> Output Class Initialized
INFO - 2023-02-06 09:44:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:36 --> Input Class Initialized
INFO - 2023-02-06 09:44:36 --> Language Class Initialized
INFO - 2023-02-06 09:44:36 --> Loader Class Initialized
INFO - 2023-02-06 09:44:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:36 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:36 --> Total execution time: 0.0193
INFO - 2023-02-06 09:44:36 --> Config Class Initialized
INFO - 2023-02-06 09:44:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:44:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:44:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:44:36 --> URI Class Initialized
INFO - 2023-02-06 09:44:36 --> Router Class Initialized
INFO - 2023-02-06 09:44:36 --> Output Class Initialized
INFO - 2023-02-06 09:44:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:44:36 --> Input Class Initialized
INFO - 2023-02-06 09:44:36 --> Language Class Initialized
INFO - 2023-02-06 09:44:36 --> Loader Class Initialized
INFO - 2023-02-06 09:44:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:44:36 --> Database Driver Class Initialized
INFO - 2023-02-06 09:44:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:44:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:44:36 --> Total execution time: 0.0165
INFO - 2023-02-06 09:45:25 --> Config Class Initialized
INFO - 2023-02-06 09:45:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:25 --> URI Class Initialized
INFO - 2023-02-06 09:45:25 --> Router Class Initialized
INFO - 2023-02-06 09:45:25 --> Output Class Initialized
INFO - 2023-02-06 09:45:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:25 --> Input Class Initialized
INFO - 2023-02-06 09:45:25 --> Language Class Initialized
INFO - 2023-02-06 09:45:25 --> Loader Class Initialized
INFO - 2023-02-06 09:45:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:25 --> Total execution time: 0.0196
INFO - 2023-02-06 09:45:25 --> Config Class Initialized
INFO - 2023-02-06 09:45:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:25 --> URI Class Initialized
INFO - 2023-02-06 09:45:25 --> Router Class Initialized
INFO - 2023-02-06 09:45:25 --> Output Class Initialized
INFO - 2023-02-06 09:45:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:25 --> Input Class Initialized
INFO - 2023-02-06 09:45:25 --> Language Class Initialized
INFO - 2023-02-06 09:45:25 --> Loader Class Initialized
INFO - 2023-02-06 09:45:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:25 --> Total execution time: 0.0553
INFO - 2023-02-06 09:45:26 --> Config Class Initialized
INFO - 2023-02-06 09:45:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:26 --> URI Class Initialized
INFO - 2023-02-06 09:45:26 --> Router Class Initialized
INFO - 2023-02-06 09:45:26 --> Output Class Initialized
INFO - 2023-02-06 09:45:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:26 --> Input Class Initialized
INFO - 2023-02-06 09:45:26 --> Language Class Initialized
INFO - 2023-02-06 09:45:26 --> Loader Class Initialized
INFO - 2023-02-06 09:45:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:26 --> Total execution time: 0.0163
INFO - 2023-02-06 09:45:26 --> Config Class Initialized
INFO - 2023-02-06 09:45:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:26 --> URI Class Initialized
INFO - 2023-02-06 09:45:26 --> Router Class Initialized
INFO - 2023-02-06 09:45:26 --> Output Class Initialized
INFO - 2023-02-06 09:45:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:26 --> Input Class Initialized
INFO - 2023-02-06 09:45:26 --> Language Class Initialized
INFO - 2023-02-06 09:45:26 --> Loader Class Initialized
INFO - 2023-02-06 09:45:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:26 --> Total execution time: 0.0144
INFO - 2023-02-06 09:45:27 --> Config Class Initialized
INFO - 2023-02-06 09:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:27 --> URI Class Initialized
INFO - 2023-02-06 09:45:27 --> Router Class Initialized
INFO - 2023-02-06 09:45:27 --> Output Class Initialized
INFO - 2023-02-06 09:45:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:27 --> Input Class Initialized
INFO - 2023-02-06 09:45:27 --> Language Class Initialized
INFO - 2023-02-06 09:45:27 --> Loader Class Initialized
INFO - 2023-02-06 09:45:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:27 --> Total execution time: 0.0042
INFO - 2023-02-06 09:45:27 --> Config Class Initialized
INFO - 2023-02-06 09:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:27 --> URI Class Initialized
INFO - 2023-02-06 09:45:27 --> Router Class Initialized
INFO - 2023-02-06 09:45:27 --> Output Class Initialized
INFO - 2023-02-06 09:45:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:27 --> Input Class Initialized
INFO - 2023-02-06 09:45:27 --> Language Class Initialized
INFO - 2023-02-06 09:45:27 --> Loader Class Initialized
INFO - 2023-02-06 09:45:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:27 --> Total execution time: 0.0146
INFO - 2023-02-06 09:45:27 --> Config Class Initialized
INFO - 2023-02-06 09:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:27 --> URI Class Initialized
INFO - 2023-02-06 09:45:27 --> Router Class Initialized
INFO - 2023-02-06 09:45:27 --> Output Class Initialized
INFO - 2023-02-06 09:45:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:27 --> Input Class Initialized
INFO - 2023-02-06 09:45:27 --> Language Class Initialized
INFO - 2023-02-06 09:45:27 --> Loader Class Initialized
INFO - 2023-02-06 09:45:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:27 --> Total execution time: 0.0436
INFO - 2023-02-06 09:45:27 --> Config Class Initialized
INFO - 2023-02-06 09:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:27 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:27 --> URI Class Initialized
INFO - 2023-02-06 09:45:27 --> Router Class Initialized
INFO - 2023-02-06 09:45:27 --> Output Class Initialized
INFO - 2023-02-06 09:45:27 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:27 --> Input Class Initialized
INFO - 2023-02-06 09:45:27 --> Language Class Initialized
INFO - 2023-02-06 09:45:27 --> Loader Class Initialized
INFO - 2023-02-06 09:45:27 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:27 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:27 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:27 --> Total execution time: 0.0120
INFO - 2023-02-06 09:45:40 --> Config Class Initialized
INFO - 2023-02-06 09:45:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:40 --> URI Class Initialized
INFO - 2023-02-06 09:45:40 --> Router Class Initialized
INFO - 2023-02-06 09:45:40 --> Output Class Initialized
INFO - 2023-02-06 09:45:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:40 --> Input Class Initialized
INFO - 2023-02-06 09:45:40 --> Language Class Initialized
INFO - 2023-02-06 09:45:40 --> Loader Class Initialized
INFO - 2023-02-06 09:45:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:40 --> Total execution time: 0.0038
INFO - 2023-02-06 09:45:40 --> Config Class Initialized
INFO - 2023-02-06 09:45:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:40 --> URI Class Initialized
INFO - 2023-02-06 09:45:40 --> Router Class Initialized
INFO - 2023-02-06 09:45:40 --> Output Class Initialized
INFO - 2023-02-06 09:45:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:40 --> Input Class Initialized
INFO - 2023-02-06 09:45:40 --> Language Class Initialized
INFO - 2023-02-06 09:45:40 --> Loader Class Initialized
INFO - 2023-02-06 09:45:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:40 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:40 --> Model "Login_model" initialized
INFO - 2023-02-06 09:45:40 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:40 --> Total execution time: 0.0412
INFO - 2023-02-06 09:45:40 --> Config Class Initialized
INFO - 2023-02-06 09:45:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:40 --> URI Class Initialized
INFO - 2023-02-06 09:45:40 --> Router Class Initialized
INFO - 2023-02-06 09:45:40 --> Output Class Initialized
INFO - 2023-02-06 09:45:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:40 --> Input Class Initialized
INFO - 2023-02-06 09:45:40 --> Language Class Initialized
INFO - 2023-02-06 09:45:40 --> Loader Class Initialized
INFO - 2023-02-06 09:45:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:40 --> Total execution time: 0.0044
INFO - 2023-02-06 09:45:40 --> Config Class Initialized
INFO - 2023-02-06 09:45:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:40 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:40 --> URI Class Initialized
INFO - 2023-02-06 09:45:40 --> Router Class Initialized
INFO - 2023-02-06 09:45:40 --> Output Class Initialized
INFO - 2023-02-06 09:45:40 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:40 --> Input Class Initialized
INFO - 2023-02-06 09:45:40 --> Language Class Initialized
INFO - 2023-02-06 09:45:40 --> Loader Class Initialized
INFO - 2023-02-06 09:45:40 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:40 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:40 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:40 --> Total execution time: 0.1661
INFO - 2023-02-06 09:45:45 --> Config Class Initialized
INFO - 2023-02-06 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:45 --> URI Class Initialized
INFO - 2023-02-06 09:45:45 --> Router Class Initialized
INFO - 2023-02-06 09:45:45 --> Output Class Initialized
INFO - 2023-02-06 09:45:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:45 --> Input Class Initialized
INFO - 2023-02-06 09:45:45 --> Language Class Initialized
INFO - 2023-02-06 09:45:45 --> Loader Class Initialized
INFO - 2023-02-06 09:45:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:45 --> Total execution time: 0.0042
INFO - 2023-02-06 09:45:45 --> Config Class Initialized
INFO - 2023-02-06 09:45:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:45 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:45 --> URI Class Initialized
INFO - 2023-02-06 09:45:45 --> Router Class Initialized
INFO - 2023-02-06 09:45:45 --> Output Class Initialized
INFO - 2023-02-06 09:45:45 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:45 --> Input Class Initialized
INFO - 2023-02-06 09:45:45 --> Language Class Initialized
INFO - 2023-02-06 09:45:45 --> Loader Class Initialized
INFO - 2023-02-06 09:45:45 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:45 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:45 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:45 --> Total execution time: 0.0146
INFO - 2023-02-06 09:45:50 --> Config Class Initialized
INFO - 2023-02-06 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:50 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:50 --> URI Class Initialized
INFO - 2023-02-06 09:45:50 --> Router Class Initialized
INFO - 2023-02-06 09:45:50 --> Output Class Initialized
INFO - 2023-02-06 09:45:50 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:50 --> Input Class Initialized
INFO - 2023-02-06 09:45:50 --> Language Class Initialized
INFO - 2023-02-06 09:45:50 --> Loader Class Initialized
INFO - 2023-02-06 09:45:50 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:50 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:50 --> Total execution time: 0.0041
INFO - 2023-02-06 09:45:50 --> Config Class Initialized
INFO - 2023-02-06 09:45:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:50 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:50 --> URI Class Initialized
INFO - 2023-02-06 09:45:50 --> Router Class Initialized
INFO - 2023-02-06 09:45:50 --> Output Class Initialized
INFO - 2023-02-06 09:45:50 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:50 --> Input Class Initialized
INFO - 2023-02-06 09:45:50 --> Language Class Initialized
INFO - 2023-02-06 09:45:50 --> Loader Class Initialized
INFO - 2023-02-06 09:45:50 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:50 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:50 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:50 --> Total execution time: 0.0140
INFO - 2023-02-06 09:45:55 --> Config Class Initialized
INFO - 2023-02-06 09:45:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:55 --> URI Class Initialized
INFO - 2023-02-06 09:45:55 --> Router Class Initialized
INFO - 2023-02-06 09:45:55 --> Output Class Initialized
INFO - 2023-02-06 09:45:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:55 --> Input Class Initialized
INFO - 2023-02-06 09:45:55 --> Language Class Initialized
INFO - 2023-02-06 09:45:55 --> Loader Class Initialized
INFO - 2023-02-06 09:45:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:55 --> Total execution time: 0.0043
INFO - 2023-02-06 09:45:55 --> Config Class Initialized
INFO - 2023-02-06 09:45:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:45:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:45:55 --> Utf8 Class Initialized
INFO - 2023-02-06 09:45:55 --> URI Class Initialized
INFO - 2023-02-06 09:45:55 --> Router Class Initialized
INFO - 2023-02-06 09:45:55 --> Output Class Initialized
INFO - 2023-02-06 09:45:55 --> Security Class Initialized
DEBUG - 2023-02-06 09:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:45:55 --> Input Class Initialized
INFO - 2023-02-06 09:45:55 --> Language Class Initialized
INFO - 2023-02-06 09:45:55 --> Loader Class Initialized
INFO - 2023-02-06 09:45:55 --> Controller Class Initialized
DEBUG - 2023-02-06 09:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:45:55 --> Database Driver Class Initialized
INFO - 2023-02-06 09:45:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:45:55 --> Final output sent to browser
DEBUG - 2023-02-06 09:45:55 --> Total execution time: 0.0194
INFO - 2023-02-06 09:46:00 --> Config Class Initialized
INFO - 2023-02-06 09:46:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:00 --> URI Class Initialized
INFO - 2023-02-06 09:46:00 --> Router Class Initialized
INFO - 2023-02-06 09:46:00 --> Output Class Initialized
INFO - 2023-02-06 09:46:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:00 --> Input Class Initialized
INFO - 2023-02-06 09:46:00 --> Language Class Initialized
INFO - 2023-02-06 09:46:00 --> Loader Class Initialized
INFO - 2023-02-06 09:46:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:00 --> Total execution time: 0.0041
INFO - 2023-02-06 09:46:00 --> Config Class Initialized
INFO - 2023-02-06 09:46:00 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:00 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:00 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:00 --> URI Class Initialized
INFO - 2023-02-06 09:46:00 --> Router Class Initialized
INFO - 2023-02-06 09:46:00 --> Output Class Initialized
INFO - 2023-02-06 09:46:00 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:00 --> Input Class Initialized
INFO - 2023-02-06 09:46:00 --> Language Class Initialized
INFO - 2023-02-06 09:46:00 --> Loader Class Initialized
INFO - 2023-02-06 09:46:00 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:00 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:00 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:00 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:00 --> Total execution time: 0.0169
INFO - 2023-02-06 09:46:05 --> Config Class Initialized
INFO - 2023-02-06 09:46:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:05 --> URI Class Initialized
INFO - 2023-02-06 09:46:05 --> Router Class Initialized
INFO - 2023-02-06 09:46:05 --> Output Class Initialized
INFO - 2023-02-06 09:46:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:05 --> Input Class Initialized
INFO - 2023-02-06 09:46:05 --> Language Class Initialized
INFO - 2023-02-06 09:46:05 --> Loader Class Initialized
INFO - 2023-02-06 09:46:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:05 --> Total execution time: 0.0040
INFO - 2023-02-06 09:46:05 --> Config Class Initialized
INFO - 2023-02-06 09:46:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:05 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:05 --> URI Class Initialized
INFO - 2023-02-06 09:46:05 --> Router Class Initialized
INFO - 2023-02-06 09:46:05 --> Output Class Initialized
INFO - 2023-02-06 09:46:05 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:05 --> Input Class Initialized
INFO - 2023-02-06 09:46:05 --> Language Class Initialized
INFO - 2023-02-06 09:46:05 --> Loader Class Initialized
INFO - 2023-02-06 09:46:05 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:05 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:05 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:05 --> Total execution time: 0.0143
INFO - 2023-02-06 09:46:10 --> Config Class Initialized
INFO - 2023-02-06 09:46:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:10 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:10 --> URI Class Initialized
INFO - 2023-02-06 09:46:10 --> Router Class Initialized
INFO - 2023-02-06 09:46:10 --> Output Class Initialized
INFO - 2023-02-06 09:46:10 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:10 --> Input Class Initialized
INFO - 2023-02-06 09:46:10 --> Language Class Initialized
INFO - 2023-02-06 09:46:10 --> Loader Class Initialized
INFO - 2023-02-06 09:46:10 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:10 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:10 --> Total execution time: 0.0040
INFO - 2023-02-06 09:46:10 --> Config Class Initialized
INFO - 2023-02-06 09:46:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:10 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:10 --> URI Class Initialized
INFO - 2023-02-06 09:46:10 --> Router Class Initialized
INFO - 2023-02-06 09:46:10 --> Output Class Initialized
INFO - 2023-02-06 09:46:10 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:10 --> Input Class Initialized
INFO - 2023-02-06 09:46:10 --> Language Class Initialized
INFO - 2023-02-06 09:46:10 --> Loader Class Initialized
INFO - 2023-02-06 09:46:10 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:10 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:10 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:10 --> Total execution time: 0.0125
INFO - 2023-02-06 09:46:15 --> Config Class Initialized
INFO - 2023-02-06 09:46:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:15 --> URI Class Initialized
INFO - 2023-02-06 09:46:15 --> Router Class Initialized
INFO - 2023-02-06 09:46:15 --> Output Class Initialized
INFO - 2023-02-06 09:46:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:15 --> Input Class Initialized
INFO - 2023-02-06 09:46:15 --> Language Class Initialized
INFO - 2023-02-06 09:46:15 --> Loader Class Initialized
INFO - 2023-02-06 09:46:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:15 --> Total execution time: 0.0040
INFO - 2023-02-06 09:46:15 --> Config Class Initialized
INFO - 2023-02-06 09:46:15 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:15 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:15 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:15 --> URI Class Initialized
INFO - 2023-02-06 09:46:15 --> Router Class Initialized
INFO - 2023-02-06 09:46:15 --> Output Class Initialized
INFO - 2023-02-06 09:46:15 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:15 --> Input Class Initialized
INFO - 2023-02-06 09:46:15 --> Language Class Initialized
INFO - 2023-02-06 09:46:15 --> Loader Class Initialized
INFO - 2023-02-06 09:46:15 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:15 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:15 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:15 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:15 --> Total execution time: 0.0448
INFO - 2023-02-06 09:46:20 --> Config Class Initialized
INFO - 2023-02-06 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:20 --> URI Class Initialized
INFO - 2023-02-06 09:46:20 --> Router Class Initialized
INFO - 2023-02-06 09:46:20 --> Output Class Initialized
INFO - 2023-02-06 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:20 --> Input Class Initialized
INFO - 2023-02-06 09:46:20 --> Language Class Initialized
INFO - 2023-02-06 09:46:20 --> Loader Class Initialized
INFO - 2023-02-06 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:20 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:20 --> Total execution time: 0.0039
INFO - 2023-02-06 09:46:20 --> Config Class Initialized
INFO - 2023-02-06 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:20 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:20 --> URI Class Initialized
INFO - 2023-02-06 09:46:20 --> Router Class Initialized
INFO - 2023-02-06 09:46:20 --> Output Class Initialized
INFO - 2023-02-06 09:46:20 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:20 --> Input Class Initialized
INFO - 2023-02-06 09:46:20 --> Language Class Initialized
INFO - 2023-02-06 09:46:20 --> Loader Class Initialized
INFO - 2023-02-06 09:46:20 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:20 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:20 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:25 --> Config Class Initialized
INFO - 2023-02-06 09:46:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:25 --> URI Class Initialized
INFO - 2023-02-06 09:46:25 --> Router Class Initialized
INFO - 2023-02-06 09:46:25 --> Output Class Initialized
INFO - 2023-02-06 09:46:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:25 --> Input Class Initialized
INFO - 2023-02-06 09:46:25 --> Language Class Initialized
INFO - 2023-02-06 09:46:25 --> Loader Class Initialized
INFO - 2023-02-06 09:46:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:25 --> Total execution time: 0.0041
INFO - 2023-02-06 09:46:25 --> Config Class Initialized
INFO - 2023-02-06 09:46:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:25 --> URI Class Initialized
INFO - 2023-02-06 09:46:25 --> Router Class Initialized
INFO - 2023-02-06 09:46:25 --> Output Class Initialized
INFO - 2023-02-06 09:46:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:25 --> Input Class Initialized
INFO - 2023-02-06 09:46:25 --> Language Class Initialized
INFO - 2023-02-06 09:46:25 --> Loader Class Initialized
INFO - 2023-02-06 09:46:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:28 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:28 --> Total execution time: 8.0253
INFO - 2023-02-06 09:46:30 --> Config Class Initialized
INFO - 2023-02-06 09:46:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:30 --> URI Class Initialized
INFO - 2023-02-06 09:46:30 --> Router Class Initialized
INFO - 2023-02-06 09:46:30 --> Output Class Initialized
INFO - 2023-02-06 09:46:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:30 --> Input Class Initialized
INFO - 2023-02-06 09:46:30 --> Language Class Initialized
INFO - 2023-02-06 09:46:30 --> Loader Class Initialized
INFO - 2023-02-06 09:46:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:30 --> Total execution time: 0.0052
INFO - 2023-02-06 09:46:30 --> Config Class Initialized
INFO - 2023-02-06 09:46:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:46:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:46:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:46:30 --> URI Class Initialized
INFO - 2023-02-06 09:46:30 --> Router Class Initialized
INFO - 2023-02-06 09:46:30 --> Output Class Initialized
INFO - 2023-02-06 09:46:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:46:30 --> Input Class Initialized
INFO - 2023-02-06 09:46:30 --> Language Class Initialized
INFO - 2023-02-06 09:46:30 --> Loader Class Initialized
INFO - 2023-02-06 09:46:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:46:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:46:30 --> Database Driver Class Initialized
INFO - 2023-02-06 09:46:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:46:30 --> Final output sent to browser
INFO - 2023-02-06 09:46:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:46:30 --> Total execution time: 5.0187
DEBUG - 2023-02-06 09:46:30 --> Total execution time: 0.0182
INFO - 2023-02-06 09:47:21 --> Config Class Initialized
INFO - 2023-02-06 09:47:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:21 --> URI Class Initialized
INFO - 2023-02-06 09:47:21 --> Router Class Initialized
INFO - 2023-02-06 09:47:21 --> Output Class Initialized
INFO - 2023-02-06 09:47:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:21 --> Input Class Initialized
INFO - 2023-02-06 09:47:21 --> Language Class Initialized
INFO - 2023-02-06 09:47:21 --> Loader Class Initialized
INFO - 2023-02-06 09:47:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:21 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:21 --> Total execution time: 0.1111
INFO - 2023-02-06 09:47:21 --> Config Class Initialized
INFO - 2023-02-06 09:47:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:21 --> URI Class Initialized
INFO - 2023-02-06 09:47:21 --> Router Class Initialized
INFO - 2023-02-06 09:47:21 --> Output Class Initialized
INFO - 2023-02-06 09:47:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:21 --> Input Class Initialized
INFO - 2023-02-06 09:47:21 --> Language Class Initialized
INFO - 2023-02-06 09:47:21 --> Loader Class Initialized
INFO - 2023-02-06 09:47:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:21 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:21 --> Total execution time: 0.0163
INFO - 2023-02-06 09:47:25 --> Config Class Initialized
INFO - 2023-02-06 09:47:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:25 --> URI Class Initialized
INFO - 2023-02-06 09:47:25 --> Router Class Initialized
INFO - 2023-02-06 09:47:25 --> Output Class Initialized
INFO - 2023-02-06 09:47:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:25 --> Input Class Initialized
INFO - 2023-02-06 09:47:25 --> Language Class Initialized
INFO - 2023-02-06 09:47:25 --> Loader Class Initialized
INFO - 2023-02-06 09:47:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:25 --> Total execution time: 0.0187
INFO - 2023-02-06 09:47:25 --> Config Class Initialized
INFO - 2023-02-06 09:47:25 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:25 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:25 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:25 --> URI Class Initialized
INFO - 2023-02-06 09:47:25 --> Router Class Initialized
INFO - 2023-02-06 09:47:25 --> Output Class Initialized
INFO - 2023-02-06 09:47:25 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:25 --> Input Class Initialized
INFO - 2023-02-06 09:47:25 --> Language Class Initialized
INFO - 2023-02-06 09:47:25 --> Loader Class Initialized
INFO - 2023-02-06 09:47:25 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:25 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:25 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:25 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:25 --> Total execution time: 0.0120
INFO - 2023-02-06 09:47:26 --> Config Class Initialized
INFO - 2023-02-06 09:47:26 --> Config Class Initialized
INFO - 2023-02-06 09:47:26 --> Hooks Class Initialized
INFO - 2023-02-06 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:26 --> URI Class Initialized
INFO - 2023-02-06 09:47:26 --> URI Class Initialized
INFO - 2023-02-06 09:47:26 --> Router Class Initialized
INFO - 2023-02-06 09:47:26 --> Output Class Initialized
INFO - 2023-02-06 09:47:26 --> Router Class Initialized
INFO - 2023-02-06 09:47:26 --> Security Class Initialized
INFO - 2023-02-06 09:47:26 --> Output Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:26 --> Security Class Initialized
INFO - 2023-02-06 09:47:26 --> Input Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:26 --> Language Class Initialized
INFO - 2023-02-06 09:47:26 --> Input Class Initialized
INFO - 2023-02-06 09:47:26 --> Language Class Initialized
INFO - 2023-02-06 09:47:26 --> Loader Class Initialized
INFO - 2023-02-06 09:47:26 --> Loader Class Initialized
INFO - 2023-02-06 09:47:26 --> Controller Class Initialized
INFO - 2023-02-06 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:26 --> Final output sent to browser
INFO - 2023-02-06 09:47:26 --> Database Driver Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Total execution time: 0.0070
INFO - 2023-02-06 09:47:26 --> Config Class Initialized
INFO - 2023-02-06 09:47:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:26 --> URI Class Initialized
INFO - 2023-02-06 09:47:26 --> Router Class Initialized
INFO - 2023-02-06 09:47:26 --> Output Class Initialized
INFO - 2023-02-06 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:26 --> Final output sent to browser
INFO - 2023-02-06 09:47:26 --> Input Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Total execution time: 0.0538
INFO - 2023-02-06 09:47:26 --> Language Class Initialized
INFO - 2023-02-06 09:47:26 --> Loader Class Initialized
INFO - 2023-02-06 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:26 --> Config Class Initialized
INFO - 2023-02-06 09:47:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:26 --> URI Class Initialized
INFO - 2023-02-06 09:47:26 --> Router Class Initialized
INFO - 2023-02-06 09:47:26 --> Output Class Initialized
INFO - 2023-02-06 09:47:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:26 --> Input Class Initialized
INFO - 2023-02-06 09:47:26 --> Language Class Initialized
INFO - 2023-02-06 09:47:26 --> Loader Class Initialized
INFO - 2023-02-06 09:47:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:26 --> Model "Login_model" initialized
INFO - 2023-02-06 09:47:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:26 --> Total execution time: 0.0171
INFO - 2023-02-06 09:47:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:26 --> Total execution time: 0.0660
INFO - 2023-02-06 09:47:29 --> Config Class Initialized
INFO - 2023-02-06 09:47:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:29 --> URI Class Initialized
INFO - 2023-02-06 09:47:29 --> Router Class Initialized
INFO - 2023-02-06 09:47:29 --> Output Class Initialized
INFO - 2023-02-06 09:47:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:29 --> Input Class Initialized
INFO - 2023-02-06 09:47:29 --> Language Class Initialized
INFO - 2023-02-06 09:47:29 --> Loader Class Initialized
INFO - 2023-02-06 09:47:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:29 --> Total execution time: 0.0151
INFO - 2023-02-06 09:47:29 --> Config Class Initialized
INFO - 2023-02-06 09:47:29 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:29 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:29 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:29 --> URI Class Initialized
INFO - 2023-02-06 09:47:29 --> Router Class Initialized
INFO - 2023-02-06 09:47:29 --> Output Class Initialized
INFO - 2023-02-06 09:47:29 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:29 --> Input Class Initialized
INFO - 2023-02-06 09:47:29 --> Language Class Initialized
INFO - 2023-02-06 09:47:29 --> Loader Class Initialized
INFO - 2023-02-06 09:47:29 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:29 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:29 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:29 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:29 --> Total execution time: 0.0551
INFO - 2023-02-06 09:47:30 --> Config Class Initialized
INFO - 2023-02-06 09:47:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:30 --> URI Class Initialized
INFO - 2023-02-06 09:47:30 --> Router Class Initialized
INFO - 2023-02-06 09:47:30 --> Output Class Initialized
INFO - 2023-02-06 09:47:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:30 --> Input Class Initialized
INFO - 2023-02-06 09:47:30 --> Language Class Initialized
INFO - 2023-02-06 09:47:30 --> Loader Class Initialized
INFO - 2023-02-06 09:47:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:30 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:30 --> Total execution time: 0.0159
INFO - 2023-02-06 09:47:30 --> Config Class Initialized
INFO - 2023-02-06 09:47:30 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:30 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:30 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:30 --> URI Class Initialized
INFO - 2023-02-06 09:47:30 --> Router Class Initialized
INFO - 2023-02-06 09:47:30 --> Output Class Initialized
INFO - 2023-02-06 09:47:30 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:30 --> Input Class Initialized
INFO - 2023-02-06 09:47:30 --> Language Class Initialized
INFO - 2023-02-06 09:47:30 --> Loader Class Initialized
INFO - 2023-02-06 09:47:30 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:30 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:30 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:30 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:30 --> Total execution time: 0.0136
INFO - 2023-02-06 09:47:31 --> Config Class Initialized
INFO - 2023-02-06 09:47:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:31 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:31 --> URI Class Initialized
INFO - 2023-02-06 09:47:31 --> Router Class Initialized
INFO - 2023-02-06 09:47:31 --> Output Class Initialized
INFO - 2023-02-06 09:47:31 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:31 --> Input Class Initialized
INFO - 2023-02-06 09:47:31 --> Language Class Initialized
INFO - 2023-02-06 09:47:31 --> Loader Class Initialized
INFO - 2023-02-06 09:47:31 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:31 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:31 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:31 --> Total execution time: 0.0158
INFO - 2023-02-06 09:47:31 --> Config Class Initialized
INFO - 2023-02-06 09:47:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:31 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:31 --> URI Class Initialized
INFO - 2023-02-06 09:47:31 --> Router Class Initialized
INFO - 2023-02-06 09:47:31 --> Output Class Initialized
INFO - 2023-02-06 09:47:31 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:31 --> Input Class Initialized
INFO - 2023-02-06 09:47:31 --> Language Class Initialized
INFO - 2023-02-06 09:47:31 --> Loader Class Initialized
INFO - 2023-02-06 09:47:31 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:31 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:31 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:31 --> Total execution time: 0.0160
INFO - 2023-02-06 09:47:34 --> Config Class Initialized
INFO - 2023-02-06 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:34 --> URI Class Initialized
INFO - 2023-02-06 09:47:34 --> Router Class Initialized
INFO - 2023-02-06 09:47:34 --> Output Class Initialized
INFO - 2023-02-06 09:47:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:34 --> Input Class Initialized
INFO - 2023-02-06 09:47:34 --> Language Class Initialized
INFO - 2023-02-06 09:47:34 --> Loader Class Initialized
INFO - 2023-02-06 09:47:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:34 --> Total execution time: 0.0289
INFO - 2023-02-06 09:47:34 --> Config Class Initialized
INFO - 2023-02-06 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:34 --> URI Class Initialized
INFO - 2023-02-06 09:47:34 --> Router Class Initialized
INFO - 2023-02-06 09:47:34 --> Output Class Initialized
INFO - 2023-02-06 09:47:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:34 --> Input Class Initialized
INFO - 2023-02-06 09:47:34 --> Language Class Initialized
INFO - 2023-02-06 09:47:34 --> Loader Class Initialized
INFO - 2023-02-06 09:47:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:34 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:34 --> Total execution time: 0.0120
INFO - 2023-02-06 09:47:34 --> Config Class Initialized
INFO - 2023-02-06 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:34 --> URI Class Initialized
INFO - 2023-02-06 09:47:34 --> Router Class Initialized
INFO - 2023-02-06 09:47:34 --> Output Class Initialized
INFO - 2023-02-06 09:47:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:34 --> Input Class Initialized
INFO - 2023-02-06 09:47:34 --> Language Class Initialized
INFO - 2023-02-06 09:47:34 --> Loader Class Initialized
INFO - 2023-02-06 09:47:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:34 --> Total execution time: 0.0468
INFO - 2023-02-06 09:47:34 --> Config Class Initialized
INFO - 2023-02-06 09:47:34 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:47:34 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:47:34 --> Utf8 Class Initialized
INFO - 2023-02-06 09:47:34 --> URI Class Initialized
INFO - 2023-02-06 09:47:34 --> Router Class Initialized
INFO - 2023-02-06 09:47:34 --> Output Class Initialized
INFO - 2023-02-06 09:47:34 --> Security Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:47:34 --> Input Class Initialized
INFO - 2023-02-06 09:47:34 --> Language Class Initialized
INFO - 2023-02-06 09:47:34 --> Loader Class Initialized
INFO - 2023-02-06 09:47:34 --> Controller Class Initialized
DEBUG - 2023-02-06 09:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:47:34 --> Database Driver Class Initialized
INFO - 2023-02-06 09:47:34 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:47:34 --> Final output sent to browser
DEBUG - 2023-02-06 09:47:34 --> Total execution time: 0.0136
INFO - 2023-02-06 09:49:36 --> Config Class Initialized
INFO - 2023-02-06 09:49:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:36 --> URI Class Initialized
INFO - 2023-02-06 09:49:36 --> Router Class Initialized
INFO - 2023-02-06 09:49:36 --> Output Class Initialized
INFO - 2023-02-06 09:49:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:36 --> Input Class Initialized
INFO - 2023-02-06 09:49:36 --> Language Class Initialized
INFO - 2023-02-06 09:49:36 --> Loader Class Initialized
INFO - 2023-02-06 09:49:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:36 --> Total execution time: 0.0044
INFO - 2023-02-06 09:49:36 --> Config Class Initialized
INFO - 2023-02-06 09:49:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:36 --> URI Class Initialized
INFO - 2023-02-06 09:49:36 --> Router Class Initialized
INFO - 2023-02-06 09:49:36 --> Output Class Initialized
INFO - 2023-02-06 09:49:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:36 --> Input Class Initialized
INFO - 2023-02-06 09:49:36 --> Language Class Initialized
INFO - 2023-02-06 09:49:36 --> Loader Class Initialized
INFO - 2023-02-06 09:49:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:36 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:36 --> Model "Login_model" initialized
INFO - 2023-02-06 09:49:36 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:36 --> Total execution time: 0.0484
INFO - 2023-02-06 09:49:37 --> Config Class Initialized
INFO - 2023-02-06 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:37 --> URI Class Initialized
INFO - 2023-02-06 09:49:37 --> Router Class Initialized
INFO - 2023-02-06 09:49:37 --> Output Class Initialized
INFO - 2023-02-06 09:49:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:37 --> Input Class Initialized
INFO - 2023-02-06 09:49:37 --> Language Class Initialized
INFO - 2023-02-06 09:49:37 --> Loader Class Initialized
INFO - 2023-02-06 09:49:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:37 --> Total execution time: 0.0044
INFO - 2023-02-06 09:49:37 --> Config Class Initialized
INFO - 2023-02-06 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:37 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:37 --> URI Class Initialized
INFO - 2023-02-06 09:49:37 --> Router Class Initialized
INFO - 2023-02-06 09:49:37 --> Output Class Initialized
INFO - 2023-02-06 09:49:37 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:37 --> Input Class Initialized
INFO - 2023-02-06 09:49:37 --> Language Class Initialized
INFO - 2023-02-06 09:49:37 --> Loader Class Initialized
INFO - 2023-02-06 09:49:37 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:37 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:37 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:37 --> Total execution time: 0.1625
INFO - 2023-02-06 09:49:41 --> Config Class Initialized
INFO - 2023-02-06 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:41 --> URI Class Initialized
INFO - 2023-02-06 09:49:41 --> Router Class Initialized
INFO - 2023-02-06 09:49:41 --> Output Class Initialized
INFO - 2023-02-06 09:49:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:41 --> Input Class Initialized
INFO - 2023-02-06 09:49:41 --> Language Class Initialized
INFO - 2023-02-06 09:49:41 --> Loader Class Initialized
INFO - 2023-02-06 09:49:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:41 --> Total execution time: 0.0051
INFO - 2023-02-06 09:49:41 --> Config Class Initialized
INFO - 2023-02-06 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:41 --> URI Class Initialized
INFO - 2023-02-06 09:49:41 --> Router Class Initialized
INFO - 2023-02-06 09:49:41 --> Output Class Initialized
INFO - 2023-02-06 09:49:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:41 --> Input Class Initialized
INFO - 2023-02-06 09:49:41 --> Language Class Initialized
INFO - 2023-02-06 09:49:41 --> Loader Class Initialized
INFO - 2023-02-06 09:49:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:41 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:41 --> Total execution time: 0.0151
INFO - 2023-02-06 09:49:46 --> Config Class Initialized
INFO - 2023-02-06 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:46 --> URI Class Initialized
INFO - 2023-02-06 09:49:46 --> Router Class Initialized
INFO - 2023-02-06 09:49:46 --> Output Class Initialized
INFO - 2023-02-06 09:49:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:46 --> Input Class Initialized
INFO - 2023-02-06 09:49:46 --> Language Class Initialized
INFO - 2023-02-06 09:49:46 --> Loader Class Initialized
INFO - 2023-02-06 09:49:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:46 --> Total execution time: 0.0043
INFO - 2023-02-06 09:49:46 --> Config Class Initialized
INFO - 2023-02-06 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:46 --> URI Class Initialized
INFO - 2023-02-06 09:49:46 --> Router Class Initialized
INFO - 2023-02-06 09:49:46 --> Output Class Initialized
INFO - 2023-02-06 09:49:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:46 --> Input Class Initialized
INFO - 2023-02-06 09:49:46 --> Language Class Initialized
INFO - 2023-02-06 09:49:46 --> Loader Class Initialized
INFO - 2023-02-06 09:49:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:47 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:47 --> Total execution time: 0.0214
INFO - 2023-02-06 09:49:51 --> Config Class Initialized
INFO - 2023-02-06 09:49:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:51 --> URI Class Initialized
INFO - 2023-02-06 09:49:51 --> Router Class Initialized
INFO - 2023-02-06 09:49:51 --> Output Class Initialized
INFO - 2023-02-06 09:49:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:51 --> Input Class Initialized
INFO - 2023-02-06 09:49:51 --> Language Class Initialized
INFO - 2023-02-06 09:49:51 --> Loader Class Initialized
INFO - 2023-02-06 09:49:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:51 --> Total execution time: 0.0044
INFO - 2023-02-06 09:49:51 --> Config Class Initialized
INFO - 2023-02-06 09:49:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:51 --> URI Class Initialized
INFO - 2023-02-06 09:49:51 --> Router Class Initialized
INFO - 2023-02-06 09:49:51 --> Output Class Initialized
INFO - 2023-02-06 09:49:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:51 --> Input Class Initialized
INFO - 2023-02-06 09:49:51 --> Language Class Initialized
INFO - 2023-02-06 09:49:51 --> Loader Class Initialized
INFO - 2023-02-06 09:49:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:51 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:51 --> Total execution time: 0.0140
INFO - 2023-02-06 09:49:56 --> Config Class Initialized
INFO - 2023-02-06 09:49:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:56 --> URI Class Initialized
INFO - 2023-02-06 09:49:56 --> Router Class Initialized
INFO - 2023-02-06 09:49:56 --> Output Class Initialized
INFO - 2023-02-06 09:49:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:56 --> Input Class Initialized
INFO - 2023-02-06 09:49:56 --> Language Class Initialized
INFO - 2023-02-06 09:49:56 --> Loader Class Initialized
INFO - 2023-02-06 09:49:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:56 --> Total execution time: 0.0040
INFO - 2023-02-06 09:49:56 --> Config Class Initialized
INFO - 2023-02-06 09:49:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:49:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:49:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:49:56 --> URI Class Initialized
INFO - 2023-02-06 09:49:56 --> Router Class Initialized
INFO - 2023-02-06 09:49:56 --> Output Class Initialized
INFO - 2023-02-06 09:49:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:49:56 --> Input Class Initialized
INFO - 2023-02-06 09:49:56 --> Language Class Initialized
INFO - 2023-02-06 09:49:56 --> Loader Class Initialized
INFO - 2023-02-06 09:49:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:49:56 --> Database Driver Class Initialized
INFO - 2023-02-06 09:49:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:49:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:49:56 --> Total execution time: 0.0138
INFO - 2023-02-06 09:50:01 --> Config Class Initialized
INFO - 2023-02-06 09:50:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:01 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:01 --> URI Class Initialized
INFO - 2023-02-06 09:50:01 --> Router Class Initialized
INFO - 2023-02-06 09:50:01 --> Output Class Initialized
INFO - 2023-02-06 09:50:01 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:01 --> Input Class Initialized
INFO - 2023-02-06 09:50:01 --> Language Class Initialized
INFO - 2023-02-06 09:50:01 --> Loader Class Initialized
INFO - 2023-02-06 09:50:01 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:01 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:01 --> Total execution time: 0.0039
INFO - 2023-02-06 09:50:01 --> Config Class Initialized
INFO - 2023-02-06 09:50:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:01 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:01 --> URI Class Initialized
INFO - 2023-02-06 09:50:01 --> Router Class Initialized
INFO - 2023-02-06 09:50:01 --> Output Class Initialized
INFO - 2023-02-06 09:50:01 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:01 --> Input Class Initialized
INFO - 2023-02-06 09:50:01 --> Language Class Initialized
INFO - 2023-02-06 09:50:01 --> Loader Class Initialized
INFO - 2023-02-06 09:50:01 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:01 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:02 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:02 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:02 --> Total execution time: 0.0184
INFO - 2023-02-06 09:50:06 --> Config Class Initialized
INFO - 2023-02-06 09:50:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:06 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:06 --> URI Class Initialized
INFO - 2023-02-06 09:50:06 --> Router Class Initialized
INFO - 2023-02-06 09:50:06 --> Output Class Initialized
INFO - 2023-02-06 09:50:06 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:06 --> Input Class Initialized
INFO - 2023-02-06 09:50:06 --> Language Class Initialized
INFO - 2023-02-06 09:50:06 --> Loader Class Initialized
INFO - 2023-02-06 09:50:06 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:06 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:06 --> Total execution time: 0.0040
INFO - 2023-02-06 09:50:06 --> Config Class Initialized
INFO - 2023-02-06 09:50:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:06 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:06 --> URI Class Initialized
INFO - 2023-02-06 09:50:06 --> Router Class Initialized
INFO - 2023-02-06 09:50:06 --> Output Class Initialized
INFO - 2023-02-06 09:50:06 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:06 --> Input Class Initialized
INFO - 2023-02-06 09:50:06 --> Language Class Initialized
INFO - 2023-02-06 09:50:06 --> Loader Class Initialized
INFO - 2023-02-06 09:50:06 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:06 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:07 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:07 --> Total execution time: 0.0205
INFO - 2023-02-06 09:50:11 --> Config Class Initialized
INFO - 2023-02-06 09:50:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:11 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:11 --> URI Class Initialized
INFO - 2023-02-06 09:50:11 --> Router Class Initialized
INFO - 2023-02-06 09:50:11 --> Output Class Initialized
INFO - 2023-02-06 09:50:11 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:11 --> Input Class Initialized
INFO - 2023-02-06 09:50:11 --> Language Class Initialized
INFO - 2023-02-06 09:50:11 --> Loader Class Initialized
INFO - 2023-02-06 09:50:11 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:11 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:11 --> Total execution time: 0.0056
INFO - 2023-02-06 09:50:11 --> Config Class Initialized
INFO - 2023-02-06 09:50:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:11 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:11 --> URI Class Initialized
INFO - 2023-02-06 09:50:11 --> Router Class Initialized
INFO - 2023-02-06 09:50:11 --> Output Class Initialized
INFO - 2023-02-06 09:50:11 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:11 --> Input Class Initialized
INFO - 2023-02-06 09:50:11 --> Language Class Initialized
INFO - 2023-02-06 09:50:11 --> Loader Class Initialized
INFO - 2023-02-06 09:50:11 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:11 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:11 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:11 --> Total execution time: 0.0142
INFO - 2023-02-06 09:50:16 --> Config Class Initialized
INFO - 2023-02-06 09:50:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:16 --> URI Class Initialized
INFO - 2023-02-06 09:50:16 --> Router Class Initialized
INFO - 2023-02-06 09:50:16 --> Output Class Initialized
INFO - 2023-02-06 09:50:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:16 --> Input Class Initialized
INFO - 2023-02-06 09:50:16 --> Language Class Initialized
INFO - 2023-02-06 09:50:16 --> Loader Class Initialized
INFO - 2023-02-06 09:50:16 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:16 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:16 --> Total execution time: 0.0039
INFO - 2023-02-06 09:50:16 --> Config Class Initialized
INFO - 2023-02-06 09:50:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:16 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:16 --> URI Class Initialized
INFO - 2023-02-06 09:50:16 --> Router Class Initialized
INFO - 2023-02-06 09:50:16 --> Output Class Initialized
INFO - 2023-02-06 09:50:16 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:16 --> Input Class Initialized
INFO - 2023-02-06 09:50:16 --> Language Class Initialized
INFO - 2023-02-06 09:50:16 --> Loader Class Initialized
INFO - 2023-02-06 09:50:16 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:16 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:16 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:16 --> Total execution time: 0.0178
INFO - 2023-02-06 09:50:21 --> Config Class Initialized
INFO - 2023-02-06 09:50:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:21 --> URI Class Initialized
INFO - 2023-02-06 09:50:21 --> Router Class Initialized
INFO - 2023-02-06 09:50:21 --> Output Class Initialized
INFO - 2023-02-06 09:50:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:21 --> Input Class Initialized
INFO - 2023-02-06 09:50:21 --> Language Class Initialized
INFO - 2023-02-06 09:50:21 --> Loader Class Initialized
INFO - 2023-02-06 09:50:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:21 --> Total execution time: 0.0040
INFO - 2023-02-06 09:50:21 --> Config Class Initialized
INFO - 2023-02-06 09:50:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:21 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:21 --> URI Class Initialized
INFO - 2023-02-06 09:50:21 --> Router Class Initialized
INFO - 2023-02-06 09:50:21 --> Output Class Initialized
INFO - 2023-02-06 09:50:21 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:21 --> Input Class Initialized
INFO - 2023-02-06 09:50:21 --> Language Class Initialized
INFO - 2023-02-06 09:50:21 --> Loader Class Initialized
INFO - 2023-02-06 09:50:21 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:21 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:21 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:21 --> Total execution time: 0.0159
INFO - 2023-02-06 09:50:26 --> Config Class Initialized
INFO - 2023-02-06 09:50:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:26 --> URI Class Initialized
INFO - 2023-02-06 09:50:26 --> Router Class Initialized
INFO - 2023-02-06 09:50:26 --> Output Class Initialized
INFO - 2023-02-06 09:50:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:26 --> Input Class Initialized
INFO - 2023-02-06 09:50:26 --> Language Class Initialized
INFO - 2023-02-06 09:50:26 --> Loader Class Initialized
INFO - 2023-02-06 09:50:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:26 --> Total execution time: 0.0039
INFO - 2023-02-06 09:50:26 --> Config Class Initialized
INFO - 2023-02-06 09:50:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:26 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:26 --> URI Class Initialized
INFO - 2023-02-06 09:50:26 --> Router Class Initialized
INFO - 2023-02-06 09:50:26 --> Output Class Initialized
INFO - 2023-02-06 09:50:26 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:26 --> Input Class Initialized
INFO - 2023-02-06 09:50:26 --> Language Class Initialized
INFO - 2023-02-06 09:50:26 --> Loader Class Initialized
INFO - 2023-02-06 09:50:26 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:26 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:26 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:26 --> Total execution time: 0.0128
INFO - 2023-02-06 09:50:31 --> Config Class Initialized
INFO - 2023-02-06 09:50:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:31 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:31 --> URI Class Initialized
INFO - 2023-02-06 09:50:31 --> Router Class Initialized
INFO - 2023-02-06 09:50:31 --> Output Class Initialized
INFO - 2023-02-06 09:50:31 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:31 --> Input Class Initialized
INFO - 2023-02-06 09:50:31 --> Language Class Initialized
INFO - 2023-02-06 09:50:31 --> Loader Class Initialized
INFO - 2023-02-06 09:50:31 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:31 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:31 --> Total execution time: 0.0040
INFO - 2023-02-06 09:50:31 --> Config Class Initialized
INFO - 2023-02-06 09:50:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:31 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:31 --> URI Class Initialized
INFO - 2023-02-06 09:50:31 --> Router Class Initialized
INFO - 2023-02-06 09:50:31 --> Output Class Initialized
INFO - 2023-02-06 09:50:31 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:31 --> Input Class Initialized
INFO - 2023-02-06 09:50:31 --> Language Class Initialized
INFO - 2023-02-06 09:50:31 --> Loader Class Initialized
INFO - 2023-02-06 09:50:31 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:31 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:32 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:32 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:32 --> Total execution time: 0.0494
INFO - 2023-02-06 09:50:36 --> Config Class Initialized
INFO - 2023-02-06 09:50:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:36 --> URI Class Initialized
INFO - 2023-02-06 09:50:36 --> Router Class Initialized
INFO - 2023-02-06 09:50:36 --> Output Class Initialized
INFO - 2023-02-06 09:50:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:36 --> Input Class Initialized
INFO - 2023-02-06 09:50:36 --> Language Class Initialized
INFO - 2023-02-06 09:50:36 --> Loader Class Initialized
INFO - 2023-02-06 09:50:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:36 --> Total execution time: 0.0045
INFO - 2023-02-06 09:50:36 --> Config Class Initialized
INFO - 2023-02-06 09:50:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:36 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:36 --> URI Class Initialized
INFO - 2023-02-06 09:50:36 --> Router Class Initialized
INFO - 2023-02-06 09:50:36 --> Output Class Initialized
INFO - 2023-02-06 09:50:36 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:36 --> Input Class Initialized
INFO - 2023-02-06 09:50:36 --> Language Class Initialized
INFO - 2023-02-06 09:50:36 --> Loader Class Initialized
INFO - 2023-02-06 09:50:36 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:36 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:36 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:36 --> Total execution time: 0.0130
INFO - 2023-02-06 09:50:41 --> Config Class Initialized
INFO - 2023-02-06 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:41 --> URI Class Initialized
INFO - 2023-02-06 09:50:41 --> Router Class Initialized
INFO - 2023-02-06 09:50:41 --> Output Class Initialized
INFO - 2023-02-06 09:50:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:41 --> Input Class Initialized
INFO - 2023-02-06 09:50:41 --> Language Class Initialized
INFO - 2023-02-06 09:50:41 --> Loader Class Initialized
INFO - 2023-02-06 09:50:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:41 --> Total execution time: 0.0046
INFO - 2023-02-06 09:50:41 --> Config Class Initialized
INFO - 2023-02-06 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:41 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:41 --> URI Class Initialized
INFO - 2023-02-06 09:50:41 --> Router Class Initialized
INFO - 2023-02-06 09:50:41 --> Output Class Initialized
INFO - 2023-02-06 09:50:41 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:41 --> Input Class Initialized
INFO - 2023-02-06 09:50:41 --> Language Class Initialized
INFO - 2023-02-06 09:50:41 --> Loader Class Initialized
INFO - 2023-02-06 09:50:41 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:41 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:41 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:41 --> Total execution time: 0.0145
INFO - 2023-02-06 09:50:46 --> Config Class Initialized
INFO - 2023-02-06 09:50:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:46 --> URI Class Initialized
INFO - 2023-02-06 09:50:46 --> Router Class Initialized
INFO - 2023-02-06 09:50:46 --> Output Class Initialized
INFO - 2023-02-06 09:50:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:46 --> Input Class Initialized
INFO - 2023-02-06 09:50:46 --> Language Class Initialized
INFO - 2023-02-06 09:50:46 --> Loader Class Initialized
INFO - 2023-02-06 09:50:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:46 --> Total execution time: 0.0048
INFO - 2023-02-06 09:50:46 --> Config Class Initialized
INFO - 2023-02-06 09:50:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:46 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:46 --> URI Class Initialized
INFO - 2023-02-06 09:50:46 --> Router Class Initialized
INFO - 2023-02-06 09:50:46 --> Output Class Initialized
INFO - 2023-02-06 09:50:46 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:46 --> Input Class Initialized
INFO - 2023-02-06 09:50:46 --> Language Class Initialized
INFO - 2023-02-06 09:50:46 --> Loader Class Initialized
INFO - 2023-02-06 09:50:46 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:46 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:46 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:46 --> Total execution time: 0.0187
INFO - 2023-02-06 09:50:51 --> Config Class Initialized
INFO - 2023-02-06 09:50:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:51 --> URI Class Initialized
INFO - 2023-02-06 09:50:51 --> Router Class Initialized
INFO - 2023-02-06 09:50:51 --> Output Class Initialized
INFO - 2023-02-06 09:50:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:51 --> Input Class Initialized
INFO - 2023-02-06 09:50:51 --> Language Class Initialized
INFO - 2023-02-06 09:50:51 --> Loader Class Initialized
INFO - 2023-02-06 09:50:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:51 --> Total execution time: 0.0041
INFO - 2023-02-06 09:50:51 --> Config Class Initialized
INFO - 2023-02-06 09:50:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:51 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:51 --> URI Class Initialized
INFO - 2023-02-06 09:50:51 --> Router Class Initialized
INFO - 2023-02-06 09:50:51 --> Output Class Initialized
INFO - 2023-02-06 09:50:51 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:51 --> Input Class Initialized
INFO - 2023-02-06 09:50:51 --> Language Class Initialized
INFO - 2023-02-06 09:50:51 --> Loader Class Initialized
INFO - 2023-02-06 09:50:51 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:51 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:51 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:51 --> Total execution time: 0.0143
INFO - 2023-02-06 09:50:56 --> Config Class Initialized
INFO - 2023-02-06 09:50:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:56 --> URI Class Initialized
INFO - 2023-02-06 09:50:56 --> Router Class Initialized
INFO - 2023-02-06 09:50:56 --> Output Class Initialized
INFO - 2023-02-06 09:50:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:56 --> Input Class Initialized
INFO - 2023-02-06 09:50:56 --> Language Class Initialized
INFO - 2023-02-06 09:50:56 --> Loader Class Initialized
INFO - 2023-02-06 09:50:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:56 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:56 --> Total execution time: 0.0041
INFO - 2023-02-06 09:50:56 --> Config Class Initialized
INFO - 2023-02-06 09:50:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 09:50:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 09:50:56 --> Utf8 Class Initialized
INFO - 2023-02-06 09:50:56 --> URI Class Initialized
INFO - 2023-02-06 09:50:56 --> Router Class Initialized
INFO - 2023-02-06 09:50:56 --> Output Class Initialized
INFO - 2023-02-06 09:50:56 --> Security Class Initialized
DEBUG - 2023-02-06 09:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 09:50:56 --> Input Class Initialized
INFO - 2023-02-06 09:50:56 --> Language Class Initialized
INFO - 2023-02-06 09:50:56 --> Loader Class Initialized
INFO - 2023-02-06 09:50:56 --> Controller Class Initialized
DEBUG - 2023-02-06 09:50:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 09:50:56 --> Database Driver Class Initialized
INFO - 2023-02-06 09:50:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 09:50:57 --> Final output sent to browser
DEBUG - 2023-02-06 09:50:57 --> Total execution time: 0.0176
INFO - 2023-02-06 10:10:35 --> Config Class Initialized
INFO - 2023-02-06 10:10:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:35 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:35 --> URI Class Initialized
INFO - 2023-02-06 10:10:35 --> Router Class Initialized
INFO - 2023-02-06 10:10:35 --> Output Class Initialized
INFO - 2023-02-06 10:10:35 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:35 --> Input Class Initialized
INFO - 2023-02-06 10:10:35 --> Language Class Initialized
INFO - 2023-02-06 10:10:35 --> Loader Class Initialized
INFO - 2023-02-06 10:10:35 --> Controller Class Initialized
INFO - 2023-02-06 10:10:35 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:35 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:35 --> Model "Change_model" initialized
INFO - 2023-02-06 10:10:35 --> Model "Grafana_model" initialized
INFO - 2023-02-06 10:10:35 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:35 --> Total execution time: 0.2301
INFO - 2023-02-06 10:10:35 --> Config Class Initialized
INFO - 2023-02-06 10:10:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:35 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:35 --> URI Class Initialized
INFO - 2023-02-06 10:10:35 --> Router Class Initialized
INFO - 2023-02-06 10:10:35 --> Output Class Initialized
INFO - 2023-02-06 10:10:35 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:35 --> Input Class Initialized
INFO - 2023-02-06 10:10:35 --> Language Class Initialized
INFO - 2023-02-06 10:10:35 --> Loader Class Initialized
INFO - 2023-02-06 10:10:35 --> Controller Class Initialized
INFO - 2023-02-06 10:10:35 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:35 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:35 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:35 --> Total execution time: 0.0025
INFO - 2023-02-06 10:10:35 --> Config Class Initialized
INFO - 2023-02-06 10:10:35 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:35 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:35 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:35 --> URI Class Initialized
INFO - 2023-02-06 10:10:35 --> Router Class Initialized
INFO - 2023-02-06 10:10:35 --> Output Class Initialized
INFO - 2023-02-06 10:10:35 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:35 --> Input Class Initialized
INFO - 2023-02-06 10:10:35 --> Language Class Initialized
INFO - 2023-02-06 10:10:35 --> Loader Class Initialized
INFO - 2023-02-06 10:10:35 --> Controller Class Initialized
INFO - 2023-02-06 10:10:35 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:35 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:35 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:35 --> Model "Login_model" initialized
INFO - 2023-02-06 10:10:35 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:35 --> Total execution time: 0.1086
INFO - 2023-02-06 10:10:46 --> Config Class Initialized
INFO - 2023-02-06 10:10:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:46 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:46 --> URI Class Initialized
INFO - 2023-02-06 10:10:46 --> Router Class Initialized
INFO - 2023-02-06 10:10:46 --> Output Class Initialized
INFO - 2023-02-06 10:10:46 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:46 --> Input Class Initialized
INFO - 2023-02-06 10:10:46 --> Language Class Initialized
INFO - 2023-02-06 10:10:46 --> Loader Class Initialized
INFO - 2023-02-06 10:10:46 --> Controller Class Initialized
INFO - 2023-02-06 10:10:46 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:46 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:46 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:46 --> Total execution time: 0.0039
INFO - 2023-02-06 10:10:46 --> Config Class Initialized
INFO - 2023-02-06 10:10:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:46 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:46 --> URI Class Initialized
INFO - 2023-02-06 10:10:46 --> Router Class Initialized
INFO - 2023-02-06 10:10:46 --> Output Class Initialized
INFO - 2023-02-06 10:10:46 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:46 --> Input Class Initialized
INFO - 2023-02-06 10:10:46 --> Language Class Initialized
INFO - 2023-02-06 10:10:46 --> Loader Class Initialized
INFO - 2023-02-06 10:10:46 --> Controller Class Initialized
INFO - 2023-02-06 10:10:46 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:46 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:46 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:46 --> Model "Login_model" initialized
INFO - 2023-02-06 10:10:47 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:47 --> Total execution time: 0.9927
INFO - 2023-02-06 10:10:53 --> Config Class Initialized
INFO - 2023-02-06 10:10:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:53 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:53 --> URI Class Initialized
INFO - 2023-02-06 10:10:53 --> Router Class Initialized
INFO - 2023-02-06 10:10:53 --> Output Class Initialized
INFO - 2023-02-06 10:10:53 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:53 --> Input Class Initialized
INFO - 2023-02-06 10:10:53 --> Language Class Initialized
INFO - 2023-02-06 10:10:53 --> Loader Class Initialized
INFO - 2023-02-06 10:10:53 --> Controller Class Initialized
INFO - 2023-02-06 10:10:53 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:53 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:53 --> Model "Change_model" initialized
INFO - 2023-02-06 10:10:53 --> Model "Grafana_model" initialized
INFO - 2023-02-06 10:10:53 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:53 --> Total execution time: 0.2301
INFO - 2023-02-06 10:10:53 --> Config Class Initialized
INFO - 2023-02-06 10:10:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:53 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:53 --> URI Class Initialized
INFO - 2023-02-06 10:10:53 --> Router Class Initialized
INFO - 2023-02-06 10:10:53 --> Output Class Initialized
INFO - 2023-02-06 10:10:53 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:53 --> Input Class Initialized
INFO - 2023-02-06 10:10:53 --> Language Class Initialized
INFO - 2023-02-06 10:10:53 --> Loader Class Initialized
INFO - 2023-02-06 10:10:53 --> Controller Class Initialized
INFO - 2023-02-06 10:10:53 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:53 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:53 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:53 --> Total execution time: 0.0050
INFO - 2023-02-06 10:10:53 --> Config Class Initialized
INFO - 2023-02-06 10:10:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:53 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:53 --> URI Class Initialized
INFO - 2023-02-06 10:10:53 --> Router Class Initialized
INFO - 2023-02-06 10:10:53 --> Output Class Initialized
INFO - 2023-02-06 10:10:53 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:53 --> Input Class Initialized
INFO - 2023-02-06 10:10:53 --> Language Class Initialized
INFO - 2023-02-06 10:10:53 --> Loader Class Initialized
INFO - 2023-02-06 10:10:53 --> Controller Class Initialized
INFO - 2023-02-06 10:10:53 --> Helper loaded: form_helper
INFO - 2023-02-06 10:10:53 --> Helper loaded: url_helper
DEBUG - 2023-02-06 10:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:53 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:53 --> Model "Login_model" initialized
INFO - 2023-02-06 10:10:53 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:53 --> Total execution time: 0.1925
INFO - 2023-02-06 10:10:53 --> Config Class Initialized
INFO - 2023-02-06 10:10:53 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:53 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:53 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:53 --> URI Class Initialized
INFO - 2023-02-06 10:10:53 --> Router Class Initialized
INFO - 2023-02-06 10:10:53 --> Output Class Initialized
INFO - 2023-02-06 10:10:53 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:53 --> Input Class Initialized
INFO - 2023-02-06 10:10:53 --> Language Class Initialized
INFO - 2023-02-06 10:10:53 --> Loader Class Initialized
INFO - 2023-02-06 10:10:53 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:53 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:53 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:54 --> Total execution time: 0.1347
INFO - 2023-02-06 10:10:54 --> Config Class Initialized
INFO - 2023-02-06 10:10:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:54 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:54 --> URI Class Initialized
INFO - 2023-02-06 10:10:54 --> Router Class Initialized
INFO - 2023-02-06 10:10:54 --> Output Class Initialized
INFO - 2023-02-06 10:10:54 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:54 --> Input Class Initialized
INFO - 2023-02-06 10:10:54 --> Language Class Initialized
INFO - 2023-02-06 10:10:54 --> Loader Class Initialized
INFO - 2023-02-06 10:10:54 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:54 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:54 --> Total execution time: 0.1332
INFO - 2023-02-06 10:10:54 --> Config Class Initialized
INFO - 2023-02-06 10:10:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:54 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:54 --> URI Class Initialized
INFO - 2023-02-06 10:10:54 --> Router Class Initialized
INFO - 2023-02-06 10:10:54 --> Output Class Initialized
INFO - 2023-02-06 10:10:54 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:54 --> Input Class Initialized
INFO - 2023-02-06 10:10:54 --> Language Class Initialized
INFO - 2023-02-06 10:10:54 --> Loader Class Initialized
INFO - 2023-02-06 10:10:54 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:54 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:54 --> Total execution time: 0.1616
INFO - 2023-02-06 10:10:54 --> Config Class Initialized
INFO - 2023-02-06 10:10:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:54 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:54 --> URI Class Initialized
INFO - 2023-02-06 10:10:54 --> Router Class Initialized
INFO - 2023-02-06 10:10:54 --> Output Class Initialized
INFO - 2023-02-06 10:10:54 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:54 --> Input Class Initialized
INFO - 2023-02-06 10:10:54 --> Language Class Initialized
INFO - 2023-02-06 10:10:54 --> Loader Class Initialized
INFO - 2023-02-06 10:10:54 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:54 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:54 --> Total execution time: 0.1337
INFO - 2023-02-06 10:10:58 --> Config Class Initialized
INFO - 2023-02-06 10:10:58 --> Config Class Initialized
INFO - 2023-02-06 10:10:58 --> Hooks Class Initialized
INFO - 2023-02-06 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:58 --> URI Class Initialized
INFO - 2023-02-06 10:10:58 --> URI Class Initialized
INFO - 2023-02-06 10:10:58 --> Router Class Initialized
INFO - 2023-02-06 10:10:58 --> Router Class Initialized
INFO - 2023-02-06 10:10:58 --> Output Class Initialized
INFO - 2023-02-06 10:10:58 --> Output Class Initialized
INFO - 2023-02-06 10:10:58 --> Security Class Initialized
INFO - 2023-02-06 10:10:58 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:58 --> Input Class Initialized
INFO - 2023-02-06 10:10:58 --> Input Class Initialized
INFO - 2023-02-06 10:10:58 --> Language Class Initialized
INFO - 2023-02-06 10:10:58 --> Language Class Initialized
INFO - 2023-02-06 10:10:58 --> Loader Class Initialized
INFO - 2023-02-06 10:10:58 --> Loader Class Initialized
INFO - 2023-02-06 10:10:58 --> Controller Class Initialized
INFO - 2023-02-06 10:10:58 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:58 --> Total execution time: 0.0049
INFO - 2023-02-06 10:10:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:58 --> Config Class Initialized
INFO - 2023-02-06 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:58 --> URI Class Initialized
INFO - 2023-02-06 10:10:58 --> Router Class Initialized
INFO - 2023-02-06 10:10:58 --> Output Class Initialized
INFO - 2023-02-06 10:10:58 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:58 --> Input Class Initialized
INFO - 2023-02-06 10:10:58 --> Language Class Initialized
INFO - 2023-02-06 10:10:58 --> Loader Class Initialized
INFO - 2023-02-06 10:10:58 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:58 --> Model "Login_model" initialized
INFO - 2023-02-06 10:10:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:58 --> Total execution time: 0.1359
INFO - 2023-02-06 10:10:58 --> Config Class Initialized
INFO - 2023-02-06 10:10:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:10:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:10:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:10:58 --> URI Class Initialized
INFO - 2023-02-06 10:10:58 --> Router Class Initialized
INFO - 2023-02-06 10:10:58 --> Output Class Initialized
INFO - 2023-02-06 10:10:58 --> Security Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:10:58 --> Input Class Initialized
INFO - 2023-02-06 10:10:58 --> Language Class Initialized
INFO - 2023-02-06 10:10:58 --> Loader Class Initialized
INFO - 2023-02-06 10:10:58 --> Controller Class Initialized
DEBUG - 2023-02-06 10:10:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:10:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:10:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:58 --> Total execution time: 0.2247
INFO - 2023-02-06 10:10:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:10:58 --> Total execution time: 0.1347
INFO - 2023-02-06 10:11:01 --> Config Class Initialized
INFO - 2023-02-06 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:01 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:01 --> URI Class Initialized
INFO - 2023-02-06 10:11:01 --> Router Class Initialized
INFO - 2023-02-06 10:11:01 --> Output Class Initialized
INFO - 2023-02-06 10:11:01 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:01 --> Input Class Initialized
INFO - 2023-02-06 10:11:01 --> Language Class Initialized
INFO - 2023-02-06 10:11:01 --> Loader Class Initialized
INFO - 2023-02-06 10:11:01 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:01 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:01 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:01 --> Total execution time: 0.1167
INFO - 2023-02-06 10:11:01 --> Config Class Initialized
INFO - 2023-02-06 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:01 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:01 --> URI Class Initialized
INFO - 2023-02-06 10:11:01 --> Router Class Initialized
INFO - 2023-02-06 10:11:01 --> Output Class Initialized
INFO - 2023-02-06 10:11:01 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:01 --> Input Class Initialized
INFO - 2023-02-06 10:11:01 --> Language Class Initialized
INFO - 2023-02-06 10:11:01 --> Loader Class Initialized
INFO - 2023-02-06 10:11:01 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:01 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:01 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:01 --> Total execution time: 0.1133
INFO - 2023-02-06 10:11:03 --> Config Class Initialized
INFO - 2023-02-06 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:03 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:03 --> URI Class Initialized
INFO - 2023-02-06 10:11:03 --> Router Class Initialized
INFO - 2023-02-06 10:11:03 --> Output Class Initialized
INFO - 2023-02-06 10:11:03 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:03 --> Input Class Initialized
INFO - 2023-02-06 10:11:03 --> Language Class Initialized
INFO - 2023-02-06 10:11:03 --> Loader Class Initialized
INFO - 2023-02-06 10:11:03 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:03 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:03 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:03 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:03 --> Total execution time: 0.1754
INFO - 2023-02-06 10:11:03 --> Config Class Initialized
INFO - 2023-02-06 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:03 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:03 --> URI Class Initialized
INFO - 2023-02-06 10:11:03 --> Router Class Initialized
INFO - 2023-02-06 10:11:03 --> Output Class Initialized
INFO - 2023-02-06 10:11:03 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:03 --> Input Class Initialized
INFO - 2023-02-06 10:11:03 --> Language Class Initialized
INFO - 2023-02-06 10:11:03 --> Loader Class Initialized
INFO - 2023-02-06 10:11:03 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:03 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:04 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:04 --> Total execution time: 0.1277
INFO - 2023-02-06 10:11:05 --> Config Class Initialized
INFO - 2023-02-06 10:11:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:05 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:05 --> URI Class Initialized
INFO - 2023-02-06 10:11:05 --> Router Class Initialized
INFO - 2023-02-06 10:11:05 --> Output Class Initialized
INFO - 2023-02-06 10:11:05 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:05 --> Input Class Initialized
INFO - 2023-02-06 10:11:05 --> Language Class Initialized
INFO - 2023-02-06 10:11:05 --> Loader Class Initialized
INFO - 2023-02-06 10:11:05 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:05 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:05 --> Total execution time: 0.0037
INFO - 2023-02-06 10:11:05 --> Config Class Initialized
INFO - 2023-02-06 10:11:05 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:05 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:05 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:05 --> URI Class Initialized
INFO - 2023-02-06 10:11:05 --> Router Class Initialized
INFO - 2023-02-06 10:11:05 --> Output Class Initialized
INFO - 2023-02-06 10:11:05 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:05 --> Input Class Initialized
INFO - 2023-02-06 10:11:05 --> Language Class Initialized
INFO - 2023-02-06 10:11:05 --> Loader Class Initialized
INFO - 2023-02-06 10:11:05 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:05 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:05 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:06 --> Total execution time: 0.1147
INFO - 2023-02-06 10:11:06 --> Config Class Initialized
INFO - 2023-02-06 10:11:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:06 --> URI Class Initialized
INFO - 2023-02-06 10:11:06 --> Router Class Initialized
INFO - 2023-02-06 10:11:06 --> Output Class Initialized
INFO - 2023-02-06 10:11:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:06 --> Input Class Initialized
INFO - 2023-02-06 10:11:06 --> Language Class Initialized
INFO - 2023-02-06 10:11:06 --> Loader Class Initialized
INFO - 2023-02-06 10:11:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:06 --> Total execution time: 0.0466
INFO - 2023-02-06 10:11:06 --> Config Class Initialized
INFO - 2023-02-06 10:11:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:06 --> URI Class Initialized
INFO - 2023-02-06 10:11:06 --> Router Class Initialized
INFO - 2023-02-06 10:11:06 --> Output Class Initialized
INFO - 2023-02-06 10:11:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:06 --> Input Class Initialized
INFO - 2023-02-06 10:11:06 --> Language Class Initialized
INFO - 2023-02-06 10:11:06 --> Loader Class Initialized
INFO - 2023-02-06 10:11:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:06 --> Total execution time: 0.1153
INFO - 2023-02-06 10:11:16 --> Config Class Initialized
INFO - 2023-02-06 10:11:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:16 --> URI Class Initialized
INFO - 2023-02-06 10:11:16 --> Router Class Initialized
INFO - 2023-02-06 10:11:16 --> Output Class Initialized
INFO - 2023-02-06 10:11:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:16 --> Input Class Initialized
INFO - 2023-02-06 10:11:16 --> Language Class Initialized
INFO - 2023-02-06 10:11:16 --> Loader Class Initialized
INFO - 2023-02-06 10:11:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:16 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:16 --> Total execution time: 0.0039
INFO - 2023-02-06 10:11:16 --> Config Class Initialized
INFO - 2023-02-06 10:11:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:16 --> URI Class Initialized
INFO - 2023-02-06 10:11:16 --> Router Class Initialized
INFO - 2023-02-06 10:11:16 --> Output Class Initialized
INFO - 2023-02-06 10:11:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:16 --> Input Class Initialized
INFO - 2023-02-06 10:11:16 --> Language Class Initialized
INFO - 2023-02-06 10:11:16 --> Loader Class Initialized
INFO - 2023-02-06 10:11:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:16 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:16 --> Model "Login_model" initialized
INFO - 2023-02-06 10:11:16 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:16 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:16 --> Total execution time: 0.3169
INFO - 2023-02-06 10:11:16 --> Config Class Initialized
INFO - 2023-02-06 10:11:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:16 --> URI Class Initialized
INFO - 2023-02-06 10:11:16 --> Router Class Initialized
INFO - 2023-02-06 10:11:16 --> Output Class Initialized
INFO - 2023-02-06 10:11:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:16 --> Input Class Initialized
INFO - 2023-02-06 10:11:16 --> Language Class Initialized
INFO - 2023-02-06 10:11:16 --> Loader Class Initialized
INFO - 2023-02-06 10:11:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:16 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:16 --> Total execution time: 0.0075
INFO - 2023-02-06 10:11:16 --> Config Class Initialized
INFO - 2023-02-06 10:11:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:16 --> URI Class Initialized
INFO - 2023-02-06 10:11:16 --> Router Class Initialized
INFO - 2023-02-06 10:11:16 --> Output Class Initialized
INFO - 2023-02-06 10:11:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:16 --> Input Class Initialized
INFO - 2023-02-06 10:11:16 --> Language Class Initialized
INFO - 2023-02-06 10:11:16 --> Loader Class Initialized
INFO - 2023-02-06 10:11:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:16 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:17 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:17 --> Total execution time: 0.4376
INFO - 2023-02-06 10:11:21 --> Config Class Initialized
INFO - 2023-02-06 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:21 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:21 --> URI Class Initialized
INFO - 2023-02-06 10:11:21 --> Router Class Initialized
INFO - 2023-02-06 10:11:21 --> Output Class Initialized
INFO - 2023-02-06 10:11:21 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:21 --> Input Class Initialized
INFO - 2023-02-06 10:11:21 --> Language Class Initialized
INFO - 2023-02-06 10:11:21 --> Loader Class Initialized
INFO - 2023-02-06 10:11:21 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:21 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:21 --> Total execution time: 0.0084
INFO - 2023-02-06 10:11:21 --> Config Class Initialized
INFO - 2023-02-06 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:21 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:21 --> URI Class Initialized
INFO - 2023-02-06 10:11:21 --> Router Class Initialized
INFO - 2023-02-06 10:11:21 --> Output Class Initialized
INFO - 2023-02-06 10:11:21 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:21 --> Input Class Initialized
INFO - 2023-02-06 10:11:21 --> Language Class Initialized
INFO - 2023-02-06 10:11:21 --> Loader Class Initialized
INFO - 2023-02-06 10:11:21 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:21 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:24 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:24 --> Total execution time: 2.7858
INFO - 2023-02-06 10:11:26 --> Config Class Initialized
INFO - 2023-02-06 10:11:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:26 --> URI Class Initialized
INFO - 2023-02-06 10:11:26 --> Router Class Initialized
INFO - 2023-02-06 10:11:26 --> Output Class Initialized
INFO - 2023-02-06 10:11:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:26 --> Input Class Initialized
INFO - 2023-02-06 10:11:26 --> Language Class Initialized
INFO - 2023-02-06 10:11:26 --> Loader Class Initialized
INFO - 2023-02-06 10:11:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:26 --> Total execution time: 0.0280
INFO - 2023-02-06 10:11:26 --> Config Class Initialized
INFO - 2023-02-06 10:11:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:26 --> URI Class Initialized
INFO - 2023-02-06 10:11:26 --> Router Class Initialized
INFO - 2023-02-06 10:11:26 --> Output Class Initialized
INFO - 2023-02-06 10:11:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:26 --> Input Class Initialized
INFO - 2023-02-06 10:11:26 --> Language Class Initialized
INFO - 2023-02-06 10:11:26 --> Loader Class Initialized
INFO - 2023-02-06 10:11:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:26 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:26 --> Total execution time: 0.1380
INFO - 2023-02-06 10:11:31 --> Config Class Initialized
INFO - 2023-02-06 10:11:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:31 --> URI Class Initialized
INFO - 2023-02-06 10:11:31 --> Router Class Initialized
INFO - 2023-02-06 10:11:31 --> Output Class Initialized
INFO - 2023-02-06 10:11:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:31 --> Input Class Initialized
INFO - 2023-02-06 10:11:31 --> Language Class Initialized
INFO - 2023-02-06 10:11:31 --> Loader Class Initialized
INFO - 2023-02-06 10:11:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:31 --> Total execution time: 0.0085
INFO - 2023-02-06 10:11:31 --> Config Class Initialized
INFO - 2023-02-06 10:11:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:31 --> URI Class Initialized
INFO - 2023-02-06 10:11:31 --> Router Class Initialized
INFO - 2023-02-06 10:11:31 --> Output Class Initialized
INFO - 2023-02-06 10:11:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:31 --> Input Class Initialized
INFO - 2023-02-06 10:11:31 --> Language Class Initialized
INFO - 2023-02-06 10:11:31 --> Loader Class Initialized
INFO - 2023-02-06 10:11:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:31 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:31 --> Total execution time: 0.1289
INFO - 2023-02-06 10:11:36 --> Config Class Initialized
INFO - 2023-02-06 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:36 --> URI Class Initialized
INFO - 2023-02-06 10:11:36 --> Router Class Initialized
INFO - 2023-02-06 10:11:36 --> Output Class Initialized
INFO - 2023-02-06 10:11:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:36 --> Input Class Initialized
INFO - 2023-02-06 10:11:36 --> Language Class Initialized
INFO - 2023-02-06 10:11:36 --> Loader Class Initialized
INFO - 2023-02-06 10:11:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:36 --> Total execution time: 0.0047
INFO - 2023-02-06 10:11:36 --> Config Class Initialized
INFO - 2023-02-06 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:36 --> URI Class Initialized
INFO - 2023-02-06 10:11:36 --> Router Class Initialized
INFO - 2023-02-06 10:11:36 --> Output Class Initialized
INFO - 2023-02-06 10:11:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:36 --> Input Class Initialized
INFO - 2023-02-06 10:11:36 --> Language Class Initialized
INFO - 2023-02-06 10:11:36 --> Loader Class Initialized
INFO - 2023-02-06 10:11:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:36 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:36 --> Total execution time: 0.1288
INFO - 2023-02-06 10:11:41 --> Config Class Initialized
INFO - 2023-02-06 10:11:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:41 --> URI Class Initialized
INFO - 2023-02-06 10:11:41 --> Router Class Initialized
INFO - 2023-02-06 10:11:41 --> Output Class Initialized
INFO - 2023-02-06 10:11:41 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:41 --> Input Class Initialized
INFO - 2023-02-06 10:11:41 --> Language Class Initialized
INFO - 2023-02-06 10:11:41 --> Loader Class Initialized
INFO - 2023-02-06 10:11:41 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:41 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:41 --> Total execution time: 0.0045
INFO - 2023-02-06 10:11:41 --> Config Class Initialized
INFO - 2023-02-06 10:11:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:41 --> URI Class Initialized
INFO - 2023-02-06 10:11:41 --> Router Class Initialized
INFO - 2023-02-06 10:11:41 --> Output Class Initialized
INFO - 2023-02-06 10:11:41 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:41 --> Input Class Initialized
INFO - 2023-02-06 10:11:41 --> Language Class Initialized
INFO - 2023-02-06 10:11:41 --> Loader Class Initialized
INFO - 2023-02-06 10:11:41 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:41 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:41 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:41 --> Total execution time: 0.1453
INFO - 2023-02-06 10:11:46 --> Config Class Initialized
INFO - 2023-02-06 10:11:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:46 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:46 --> URI Class Initialized
INFO - 2023-02-06 10:11:46 --> Router Class Initialized
INFO - 2023-02-06 10:11:46 --> Output Class Initialized
INFO - 2023-02-06 10:11:46 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:46 --> Input Class Initialized
INFO - 2023-02-06 10:11:46 --> Language Class Initialized
INFO - 2023-02-06 10:11:46 --> Loader Class Initialized
INFO - 2023-02-06 10:11:46 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:46 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:46 --> Total execution time: 0.0043
INFO - 2023-02-06 10:11:46 --> Config Class Initialized
INFO - 2023-02-06 10:11:46 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:46 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:46 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:46 --> URI Class Initialized
INFO - 2023-02-06 10:11:46 --> Router Class Initialized
INFO - 2023-02-06 10:11:46 --> Output Class Initialized
INFO - 2023-02-06 10:11:46 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:46 --> Input Class Initialized
INFO - 2023-02-06 10:11:46 --> Language Class Initialized
INFO - 2023-02-06 10:11:46 --> Loader Class Initialized
INFO - 2023-02-06 10:11:46 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:46 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:46 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:46 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:46 --> Total execution time: 0.1302
INFO - 2023-02-06 10:11:51 --> Config Class Initialized
INFO - 2023-02-06 10:11:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:51 --> URI Class Initialized
INFO - 2023-02-06 10:11:51 --> Router Class Initialized
INFO - 2023-02-06 10:11:51 --> Output Class Initialized
INFO - 2023-02-06 10:11:51 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:51 --> Input Class Initialized
INFO - 2023-02-06 10:11:51 --> Language Class Initialized
INFO - 2023-02-06 10:11:51 --> Loader Class Initialized
INFO - 2023-02-06 10:11:51 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:51 --> Total execution time: 0.0046
INFO - 2023-02-06 10:11:51 --> Config Class Initialized
INFO - 2023-02-06 10:11:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:51 --> URI Class Initialized
INFO - 2023-02-06 10:11:51 --> Router Class Initialized
INFO - 2023-02-06 10:11:51 --> Output Class Initialized
INFO - 2023-02-06 10:11:51 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:51 --> Input Class Initialized
INFO - 2023-02-06 10:11:51 --> Language Class Initialized
INFO - 2023-02-06 10:11:51 --> Loader Class Initialized
INFO - 2023-02-06 10:11:51 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:51 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:51 --> Total execution time: 0.0149
INFO - 2023-02-06 10:11:56 --> Config Class Initialized
INFO - 2023-02-06 10:11:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:56 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:56 --> URI Class Initialized
INFO - 2023-02-06 10:11:56 --> Router Class Initialized
INFO - 2023-02-06 10:11:56 --> Output Class Initialized
INFO - 2023-02-06 10:11:56 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:56 --> Input Class Initialized
INFO - 2023-02-06 10:11:56 --> Language Class Initialized
INFO - 2023-02-06 10:11:56 --> Loader Class Initialized
INFO - 2023-02-06 10:11:56 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:56 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:56 --> Total execution time: 0.0052
INFO - 2023-02-06 10:11:56 --> Config Class Initialized
INFO - 2023-02-06 10:11:56 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:11:56 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:11:56 --> Utf8 Class Initialized
INFO - 2023-02-06 10:11:56 --> URI Class Initialized
INFO - 2023-02-06 10:11:56 --> Router Class Initialized
INFO - 2023-02-06 10:11:56 --> Output Class Initialized
INFO - 2023-02-06 10:11:56 --> Security Class Initialized
DEBUG - 2023-02-06 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:11:56 --> Input Class Initialized
INFO - 2023-02-06 10:11:56 --> Language Class Initialized
INFO - 2023-02-06 10:11:56 --> Loader Class Initialized
INFO - 2023-02-06 10:11:56 --> Controller Class Initialized
DEBUG - 2023-02-06 10:11:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:11:56 --> Database Driver Class Initialized
INFO - 2023-02-06 10:11:56 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:11:56 --> Final output sent to browser
DEBUG - 2023-02-06 10:11:56 --> Total execution time: 0.0150
INFO - 2023-02-06 10:12:01 --> Config Class Initialized
INFO - 2023-02-06 10:12:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:01 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:01 --> URI Class Initialized
INFO - 2023-02-06 10:12:01 --> Router Class Initialized
INFO - 2023-02-06 10:12:01 --> Output Class Initialized
INFO - 2023-02-06 10:12:01 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:01 --> Input Class Initialized
INFO - 2023-02-06 10:12:01 --> Language Class Initialized
INFO - 2023-02-06 10:12:01 --> Loader Class Initialized
INFO - 2023-02-06 10:12:01 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:01 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:01 --> Total execution time: 0.0048
INFO - 2023-02-06 10:12:01 --> Config Class Initialized
INFO - 2023-02-06 10:12:01 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:01 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:01 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:01 --> URI Class Initialized
INFO - 2023-02-06 10:12:01 --> Router Class Initialized
INFO - 2023-02-06 10:12:01 --> Output Class Initialized
INFO - 2023-02-06 10:12:01 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:01 --> Input Class Initialized
INFO - 2023-02-06 10:12:01 --> Language Class Initialized
INFO - 2023-02-06 10:12:01 --> Loader Class Initialized
INFO - 2023-02-06 10:12:01 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:01 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:01 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:01 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:01 --> Total execution time: 0.0145
INFO - 2023-02-06 10:12:06 --> Config Class Initialized
INFO - 2023-02-06 10:12:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:06 --> URI Class Initialized
INFO - 2023-02-06 10:12:06 --> Router Class Initialized
INFO - 2023-02-06 10:12:06 --> Output Class Initialized
INFO - 2023-02-06 10:12:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:06 --> Input Class Initialized
INFO - 2023-02-06 10:12:06 --> Language Class Initialized
INFO - 2023-02-06 10:12:06 --> Loader Class Initialized
INFO - 2023-02-06 10:12:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:06 --> Total execution time: 0.0040
INFO - 2023-02-06 10:12:06 --> Config Class Initialized
INFO - 2023-02-06 10:12:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:06 --> URI Class Initialized
INFO - 2023-02-06 10:12:06 --> Router Class Initialized
INFO - 2023-02-06 10:12:06 --> Output Class Initialized
INFO - 2023-02-06 10:12:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:06 --> Input Class Initialized
INFO - 2023-02-06 10:12:06 --> Language Class Initialized
INFO - 2023-02-06 10:12:06 --> Loader Class Initialized
INFO - 2023-02-06 10:12:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:06 --> Total execution time: 0.0152
INFO - 2023-02-06 10:12:11 --> Config Class Initialized
INFO - 2023-02-06 10:12:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:11 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:11 --> URI Class Initialized
INFO - 2023-02-06 10:12:11 --> Router Class Initialized
INFO - 2023-02-06 10:12:11 --> Output Class Initialized
INFO - 2023-02-06 10:12:11 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:11 --> Input Class Initialized
INFO - 2023-02-06 10:12:11 --> Language Class Initialized
INFO - 2023-02-06 10:12:11 --> Loader Class Initialized
INFO - 2023-02-06 10:12:11 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:11 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:11 --> Total execution time: 0.0041
INFO - 2023-02-06 10:12:11 --> Config Class Initialized
INFO - 2023-02-06 10:12:11 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:11 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:11 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:11 --> URI Class Initialized
INFO - 2023-02-06 10:12:11 --> Router Class Initialized
INFO - 2023-02-06 10:12:11 --> Output Class Initialized
INFO - 2023-02-06 10:12:11 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:11 --> Input Class Initialized
INFO - 2023-02-06 10:12:11 --> Language Class Initialized
INFO - 2023-02-06 10:12:11 --> Loader Class Initialized
INFO - 2023-02-06 10:12:11 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:11 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:11 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:11 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:11 --> Total execution time: 0.0136
INFO - 2023-02-06 10:12:16 --> Config Class Initialized
INFO - 2023-02-06 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:16 --> URI Class Initialized
INFO - 2023-02-06 10:12:16 --> Router Class Initialized
INFO - 2023-02-06 10:12:16 --> Output Class Initialized
INFO - 2023-02-06 10:12:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:16 --> Input Class Initialized
INFO - 2023-02-06 10:12:16 --> Language Class Initialized
INFO - 2023-02-06 10:12:16 --> Loader Class Initialized
INFO - 2023-02-06 10:12:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:16 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:16 --> Total execution time: 0.0081
INFO - 2023-02-06 10:12:16 --> Config Class Initialized
INFO - 2023-02-06 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:16 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:16 --> URI Class Initialized
INFO - 2023-02-06 10:12:16 --> Router Class Initialized
INFO - 2023-02-06 10:12:16 --> Output Class Initialized
INFO - 2023-02-06 10:12:16 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:16 --> Input Class Initialized
INFO - 2023-02-06 10:12:16 --> Language Class Initialized
INFO - 2023-02-06 10:12:16 --> Loader Class Initialized
INFO - 2023-02-06 10:12:16 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:16 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:16 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:16 --> Total execution time: 0.1027
INFO - 2023-02-06 10:12:21 --> Config Class Initialized
INFO - 2023-02-06 10:12:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:21 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:21 --> URI Class Initialized
INFO - 2023-02-06 10:12:21 --> Router Class Initialized
INFO - 2023-02-06 10:12:21 --> Output Class Initialized
INFO - 2023-02-06 10:12:21 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:21 --> Input Class Initialized
INFO - 2023-02-06 10:12:21 --> Language Class Initialized
INFO - 2023-02-06 10:12:21 --> Loader Class Initialized
INFO - 2023-02-06 10:12:21 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:21 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:21 --> Total execution time: 0.0039
INFO - 2023-02-06 10:12:21 --> Config Class Initialized
INFO - 2023-02-06 10:12:21 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:21 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:21 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:21 --> URI Class Initialized
INFO - 2023-02-06 10:12:21 --> Router Class Initialized
INFO - 2023-02-06 10:12:21 --> Output Class Initialized
INFO - 2023-02-06 10:12:21 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:21 --> Input Class Initialized
INFO - 2023-02-06 10:12:21 --> Language Class Initialized
INFO - 2023-02-06 10:12:21 --> Loader Class Initialized
INFO - 2023-02-06 10:12:21 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:21 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:21 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:21 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:21 --> Total execution time: 0.0215
INFO - 2023-02-06 10:12:26 --> Config Class Initialized
INFO - 2023-02-06 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:26 --> URI Class Initialized
INFO - 2023-02-06 10:12:26 --> Router Class Initialized
INFO - 2023-02-06 10:12:26 --> Output Class Initialized
INFO - 2023-02-06 10:12:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:26 --> Input Class Initialized
INFO - 2023-02-06 10:12:26 --> Language Class Initialized
INFO - 2023-02-06 10:12:26 --> Loader Class Initialized
INFO - 2023-02-06 10:12:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:26 --> Total execution time: 0.0043
INFO - 2023-02-06 10:12:26 --> Config Class Initialized
INFO - 2023-02-06 10:12:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:26 --> URI Class Initialized
INFO - 2023-02-06 10:12:26 --> Router Class Initialized
INFO - 2023-02-06 10:12:26 --> Output Class Initialized
INFO - 2023-02-06 10:12:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:26 --> Input Class Initialized
INFO - 2023-02-06 10:12:26 --> Language Class Initialized
INFO - 2023-02-06 10:12:26 --> Loader Class Initialized
INFO - 2023-02-06 10:12:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:26 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:26 --> Total execution time: 0.0203
INFO - 2023-02-06 10:12:31 --> Config Class Initialized
INFO - 2023-02-06 10:12:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:31 --> URI Class Initialized
INFO - 2023-02-06 10:12:31 --> Router Class Initialized
INFO - 2023-02-06 10:12:31 --> Output Class Initialized
INFO - 2023-02-06 10:12:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:31 --> Input Class Initialized
INFO - 2023-02-06 10:12:31 --> Language Class Initialized
INFO - 2023-02-06 10:12:31 --> Loader Class Initialized
INFO - 2023-02-06 10:12:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:31 --> Total execution time: 0.0041
INFO - 2023-02-06 10:12:31 --> Config Class Initialized
INFO - 2023-02-06 10:12:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:31 --> URI Class Initialized
INFO - 2023-02-06 10:12:31 --> Router Class Initialized
INFO - 2023-02-06 10:12:31 --> Output Class Initialized
INFO - 2023-02-06 10:12:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:31 --> Input Class Initialized
INFO - 2023-02-06 10:12:31 --> Language Class Initialized
INFO - 2023-02-06 10:12:31 --> Loader Class Initialized
INFO - 2023-02-06 10:12:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:31 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:31 --> Total execution time: 0.0147
INFO - 2023-02-06 10:12:36 --> Config Class Initialized
INFO - 2023-02-06 10:12:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:36 --> URI Class Initialized
INFO - 2023-02-06 10:12:36 --> Router Class Initialized
INFO - 2023-02-06 10:12:36 --> Output Class Initialized
INFO - 2023-02-06 10:12:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:36 --> Input Class Initialized
INFO - 2023-02-06 10:12:36 --> Language Class Initialized
INFO - 2023-02-06 10:12:36 --> Loader Class Initialized
INFO - 2023-02-06 10:12:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:36 --> Total execution time: 0.0039
INFO - 2023-02-06 10:12:36 --> Config Class Initialized
INFO - 2023-02-06 10:12:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:12:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:12:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:12:36 --> URI Class Initialized
INFO - 2023-02-06 10:12:36 --> Router Class Initialized
INFO - 2023-02-06 10:12:36 --> Output Class Initialized
INFO - 2023-02-06 10:12:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:12:36 --> Input Class Initialized
INFO - 2023-02-06 10:12:36 --> Language Class Initialized
INFO - 2023-02-06 10:12:36 --> Loader Class Initialized
INFO - 2023-02-06 10:12:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:12:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:12:36 --> Database Driver Class Initialized
INFO - 2023-02-06 10:12:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:12:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:12:36 --> Total execution time: 0.0254
INFO - 2023-02-06 10:13:24 --> Config Class Initialized
INFO - 2023-02-06 10:13:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:13:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:13:24 --> Utf8 Class Initialized
INFO - 2023-02-06 10:13:24 --> URI Class Initialized
INFO - 2023-02-06 10:13:24 --> Router Class Initialized
INFO - 2023-02-06 10:13:24 --> Output Class Initialized
INFO - 2023-02-06 10:13:24 --> Security Class Initialized
DEBUG - 2023-02-06 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:13:24 --> Input Class Initialized
INFO - 2023-02-06 10:13:24 --> Language Class Initialized
INFO - 2023-02-06 10:13:24 --> Loader Class Initialized
INFO - 2023-02-06 10:13:24 --> Controller Class Initialized
DEBUG - 2023-02-06 10:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:13:24 --> Database Driver Class Initialized
INFO - 2023-02-06 10:13:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:13:24 --> Final output sent to browser
DEBUG - 2023-02-06 10:13:24 --> Total execution time: 0.0233
INFO - 2023-02-06 10:13:24 --> Config Class Initialized
INFO - 2023-02-06 10:13:24 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:13:24 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:13:24 --> Utf8 Class Initialized
INFO - 2023-02-06 10:13:24 --> URI Class Initialized
INFO - 2023-02-06 10:13:24 --> Router Class Initialized
INFO - 2023-02-06 10:13:24 --> Output Class Initialized
INFO - 2023-02-06 10:13:24 --> Security Class Initialized
DEBUG - 2023-02-06 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:13:24 --> Input Class Initialized
INFO - 2023-02-06 10:13:24 --> Language Class Initialized
INFO - 2023-02-06 10:13:24 --> Loader Class Initialized
INFO - 2023-02-06 10:13:24 --> Controller Class Initialized
DEBUG - 2023-02-06 10:13:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:13:24 --> Database Driver Class Initialized
INFO - 2023-02-06 10:13:24 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:13:24 --> Final output sent to browser
DEBUG - 2023-02-06 10:13:24 --> Total execution time: 0.0186
INFO - 2023-02-06 10:13:55 --> Config Class Initialized
INFO - 2023-02-06 10:13:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:13:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:13:55 --> Utf8 Class Initialized
INFO - 2023-02-06 10:13:55 --> URI Class Initialized
INFO - 2023-02-06 10:13:55 --> Router Class Initialized
INFO - 2023-02-06 10:13:55 --> Output Class Initialized
INFO - 2023-02-06 10:13:55 --> Security Class Initialized
DEBUG - 2023-02-06 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:13:55 --> Input Class Initialized
INFO - 2023-02-06 10:13:55 --> Language Class Initialized
INFO - 2023-02-06 10:13:55 --> Loader Class Initialized
INFO - 2023-02-06 10:13:55 --> Controller Class Initialized
DEBUG - 2023-02-06 10:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:13:55 --> Database Driver Class Initialized
INFO - 2023-02-06 10:13:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:13:55 --> Final output sent to browser
DEBUG - 2023-02-06 10:13:55 --> Total execution time: 0.0224
INFO - 2023-02-06 10:13:55 --> Config Class Initialized
INFO - 2023-02-06 10:13:55 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:13:55 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:13:55 --> Utf8 Class Initialized
INFO - 2023-02-06 10:13:55 --> URI Class Initialized
INFO - 2023-02-06 10:13:55 --> Router Class Initialized
INFO - 2023-02-06 10:13:55 --> Output Class Initialized
INFO - 2023-02-06 10:13:55 --> Security Class Initialized
DEBUG - 2023-02-06 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:13:55 --> Input Class Initialized
INFO - 2023-02-06 10:13:55 --> Language Class Initialized
INFO - 2023-02-06 10:13:55 --> Loader Class Initialized
INFO - 2023-02-06 10:13:55 --> Controller Class Initialized
DEBUG - 2023-02-06 10:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:13:55 --> Database Driver Class Initialized
INFO - 2023-02-06 10:13:55 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:13:55 --> Final output sent to browser
DEBUG - 2023-02-06 10:13:55 --> Total execution time: 0.0145
INFO - 2023-02-06 10:14:06 --> Config Class Initialized
INFO - 2023-02-06 10:14:06 --> Config Class Initialized
INFO - 2023-02-06 10:14:06 --> Hooks Class Initialized
INFO - 2023-02-06 10:14:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 10:14:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:06 --> URI Class Initialized
INFO - 2023-02-06 10:14:06 --> URI Class Initialized
INFO - 2023-02-06 10:14:06 --> Router Class Initialized
INFO - 2023-02-06 10:14:06 --> Router Class Initialized
INFO - 2023-02-06 10:14:06 --> Output Class Initialized
INFO - 2023-02-06 10:14:06 --> Output Class Initialized
INFO - 2023-02-06 10:14:06 --> Security Class Initialized
INFO - 2023-02-06 10:14:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:06 --> Input Class Initialized
INFO - 2023-02-06 10:14:06 --> Input Class Initialized
INFO - 2023-02-06 10:14:06 --> Language Class Initialized
INFO - 2023-02-06 10:14:06 --> Language Class Initialized
INFO - 2023-02-06 10:14:06 --> Loader Class Initialized
INFO - 2023-02-06 10:14:06 --> Loader Class Initialized
INFO - 2023-02-06 10:14:06 --> Controller Class Initialized
INFO - 2023-02-06 10:14:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 10:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:06 --> Total execution time: 0.0323
INFO - 2023-02-06 10:14:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:06 --> Config Class Initialized
INFO - 2023-02-06 10:14:06 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:06 --> URI Class Initialized
INFO - 2023-02-06 10:14:06 --> Router Class Initialized
INFO - 2023-02-06 10:14:06 --> Output Class Initialized
INFO - 2023-02-06 10:14:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:06 --> Input Class Initialized
INFO - 2023-02-06 10:14:06 --> Language Class Initialized
INFO - 2023-02-06 10:14:06 --> Loader Class Initialized
INFO - 2023-02-06 10:14:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:06 --> Total execution time: 0.0453
INFO - 2023-02-06 10:14:06 --> Config Class Initialized
INFO - 2023-02-06 10:14:06 --> Hooks Class Initialized
INFO - 2023-02-06 10:14:06 --> Model "Login_model" initialized
DEBUG - 2023-02-06 10:14:06 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:06 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:06 --> URI Class Initialized
INFO - 2023-02-06 10:14:06 --> Router Class Initialized
INFO - 2023-02-06 10:14:06 --> Output Class Initialized
INFO - 2023-02-06 10:14:06 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:06 --> Input Class Initialized
INFO - 2023-02-06 10:14:06 --> Language Class Initialized
INFO - 2023-02-06 10:14:06 --> Loader Class Initialized
INFO - 2023-02-06 10:14:06 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:06 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:06 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:06 --> Total execution time: 0.0247
INFO - 2023-02-06 10:14:06 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:06 --> Total execution time: 0.0130
INFO - 2023-02-06 10:14:08 --> Config Class Initialized
INFO - 2023-02-06 10:14:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:08 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:08 --> URI Class Initialized
INFO - 2023-02-06 10:14:08 --> Router Class Initialized
INFO - 2023-02-06 10:14:08 --> Output Class Initialized
INFO - 2023-02-06 10:14:08 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:08 --> Input Class Initialized
INFO - 2023-02-06 10:14:08 --> Language Class Initialized
INFO - 2023-02-06 10:14:08 --> Loader Class Initialized
INFO - 2023-02-06 10:14:08 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:08 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:08 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:08 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:08 --> Total execution time: 0.0413
INFO - 2023-02-06 10:14:08 --> Config Class Initialized
INFO - 2023-02-06 10:14:08 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:08 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:08 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:08 --> URI Class Initialized
INFO - 2023-02-06 10:14:08 --> Router Class Initialized
INFO - 2023-02-06 10:14:08 --> Output Class Initialized
INFO - 2023-02-06 10:14:08 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:08 --> Input Class Initialized
INFO - 2023-02-06 10:14:08 --> Language Class Initialized
INFO - 2023-02-06 10:14:08 --> Loader Class Initialized
INFO - 2023-02-06 10:14:08 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:08 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:08 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:08 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:08 --> Total execution time: 0.0506
INFO - 2023-02-06 10:14:10 --> Config Class Initialized
INFO - 2023-02-06 10:14:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:10 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:10 --> URI Class Initialized
INFO - 2023-02-06 10:14:10 --> Router Class Initialized
INFO - 2023-02-06 10:14:10 --> Output Class Initialized
INFO - 2023-02-06 10:14:10 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:10 --> Input Class Initialized
INFO - 2023-02-06 10:14:10 --> Language Class Initialized
INFO - 2023-02-06 10:14:10 --> Loader Class Initialized
INFO - 2023-02-06 10:14:10 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:10 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:10 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:10 --> Total execution time: 0.0467
INFO - 2023-02-06 10:14:10 --> Config Class Initialized
INFO - 2023-02-06 10:14:10 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:10 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:10 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:10 --> URI Class Initialized
INFO - 2023-02-06 10:14:10 --> Router Class Initialized
INFO - 2023-02-06 10:14:10 --> Output Class Initialized
INFO - 2023-02-06 10:14:10 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:10 --> Input Class Initialized
INFO - 2023-02-06 10:14:10 --> Language Class Initialized
INFO - 2023-02-06 10:14:10 --> Loader Class Initialized
INFO - 2023-02-06 10:14:10 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:10 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:10 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:10 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:10 --> Total execution time: 0.0164
INFO - 2023-02-06 10:14:12 --> Config Class Initialized
INFO - 2023-02-06 10:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:12 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:12 --> URI Class Initialized
INFO - 2023-02-06 10:14:12 --> Router Class Initialized
INFO - 2023-02-06 10:14:12 --> Output Class Initialized
INFO - 2023-02-06 10:14:12 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:12 --> Input Class Initialized
INFO - 2023-02-06 10:14:12 --> Language Class Initialized
INFO - 2023-02-06 10:14:12 --> Loader Class Initialized
INFO - 2023-02-06 10:14:12 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:12 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:12 --> Total execution time: 0.0268
INFO - 2023-02-06 10:14:12 --> Config Class Initialized
INFO - 2023-02-06 10:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:12 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:12 --> URI Class Initialized
INFO - 2023-02-06 10:14:12 --> Router Class Initialized
INFO - 2023-02-06 10:14:12 --> Output Class Initialized
INFO - 2023-02-06 10:14:12 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:12 --> Input Class Initialized
INFO - 2023-02-06 10:14:12 --> Language Class Initialized
INFO - 2023-02-06 10:14:12 --> Loader Class Initialized
INFO - 2023-02-06 10:14:12 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:12 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:12 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:12 --> Total execution time: 0.0147
INFO - 2023-02-06 10:14:12 --> Config Class Initialized
INFO - 2023-02-06 10:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:12 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:12 --> URI Class Initialized
INFO - 2023-02-06 10:14:12 --> Router Class Initialized
INFO - 2023-02-06 10:14:12 --> Output Class Initialized
INFO - 2023-02-06 10:14:12 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:12 --> Input Class Initialized
INFO - 2023-02-06 10:14:12 --> Language Class Initialized
INFO - 2023-02-06 10:14:12 --> Loader Class Initialized
INFO - 2023-02-06 10:14:12 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:12 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:12 --> Total execution time: 0.0301
INFO - 2023-02-06 10:14:12 --> Config Class Initialized
INFO - 2023-02-06 10:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:12 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:12 --> URI Class Initialized
INFO - 2023-02-06 10:14:12 --> Router Class Initialized
INFO - 2023-02-06 10:14:12 --> Output Class Initialized
INFO - 2023-02-06 10:14:12 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:12 --> Input Class Initialized
INFO - 2023-02-06 10:14:12 --> Language Class Initialized
INFO - 2023-02-06 10:14:12 --> Loader Class Initialized
INFO - 2023-02-06 10:14:12 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:12 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:12 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:12 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:12 --> Total execution time: 0.0473
INFO - 2023-02-06 10:14:26 --> Config Class Initialized
INFO - 2023-02-06 10:14:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:26 --> URI Class Initialized
INFO - 2023-02-06 10:14:26 --> Router Class Initialized
INFO - 2023-02-06 10:14:26 --> Output Class Initialized
INFO - 2023-02-06 10:14:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:26 --> Input Class Initialized
INFO - 2023-02-06 10:14:26 --> Language Class Initialized
INFO - 2023-02-06 10:14:26 --> Loader Class Initialized
INFO - 2023-02-06 10:14:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:26 --> Total execution time: 0.0038
INFO - 2023-02-06 10:14:26 --> Config Class Initialized
INFO - 2023-02-06 10:14:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:26 --> URI Class Initialized
INFO - 2023-02-06 10:14:26 --> Router Class Initialized
INFO - 2023-02-06 10:14:26 --> Output Class Initialized
INFO - 2023-02-06 10:14:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:26 --> Input Class Initialized
INFO - 2023-02-06 10:14:26 --> Language Class Initialized
INFO - 2023-02-06 10:14:26 --> Loader Class Initialized
INFO - 2023-02-06 10:14:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:26 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:26 --> Model "Login_model" initialized
INFO - 2023-02-06 10:14:26 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:26 --> Total execution time: 0.0303
INFO - 2023-02-06 10:14:26 --> Config Class Initialized
INFO - 2023-02-06 10:14:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:26 --> URI Class Initialized
INFO - 2023-02-06 10:14:26 --> Router Class Initialized
INFO - 2023-02-06 10:14:26 --> Output Class Initialized
INFO - 2023-02-06 10:14:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:26 --> Input Class Initialized
INFO - 2023-02-06 10:14:26 --> Language Class Initialized
INFO - 2023-02-06 10:14:26 --> Loader Class Initialized
INFO - 2023-02-06 10:14:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:26 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:26 --> Total execution time: 0.0060
INFO - 2023-02-06 10:14:26 --> Config Class Initialized
INFO - 2023-02-06 10:14:26 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:26 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:26 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:26 --> URI Class Initialized
INFO - 2023-02-06 10:14:26 --> Router Class Initialized
INFO - 2023-02-06 10:14:26 --> Output Class Initialized
INFO - 2023-02-06 10:14:26 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:26 --> Input Class Initialized
INFO - 2023-02-06 10:14:26 --> Language Class Initialized
INFO - 2023-02-06 10:14:26 --> Loader Class Initialized
INFO - 2023-02-06 10:14:26 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:26 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:26 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:27 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:27 --> Total execution time: 0.1805
INFO - 2023-02-06 10:14:31 --> Config Class Initialized
INFO - 2023-02-06 10:14:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:31 --> URI Class Initialized
INFO - 2023-02-06 10:14:31 --> Router Class Initialized
INFO - 2023-02-06 10:14:31 --> Output Class Initialized
INFO - 2023-02-06 10:14:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:31 --> Input Class Initialized
INFO - 2023-02-06 10:14:31 --> Language Class Initialized
INFO - 2023-02-06 10:14:31 --> Loader Class Initialized
INFO - 2023-02-06 10:14:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:31 --> Total execution time: 0.0041
INFO - 2023-02-06 10:14:31 --> Config Class Initialized
INFO - 2023-02-06 10:14:31 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:31 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:31 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:31 --> URI Class Initialized
INFO - 2023-02-06 10:14:31 --> Router Class Initialized
INFO - 2023-02-06 10:14:31 --> Output Class Initialized
INFO - 2023-02-06 10:14:31 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:31 --> Input Class Initialized
INFO - 2023-02-06 10:14:31 --> Language Class Initialized
INFO - 2023-02-06 10:14:31 --> Loader Class Initialized
INFO - 2023-02-06 10:14:31 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:31 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:31 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:31 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:31 --> Total execution time: 0.0134
INFO - 2023-02-06 10:14:36 --> Config Class Initialized
INFO - 2023-02-06 10:14:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:36 --> URI Class Initialized
INFO - 2023-02-06 10:14:36 --> Router Class Initialized
INFO - 2023-02-06 10:14:36 --> Output Class Initialized
INFO - 2023-02-06 10:14:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:36 --> Input Class Initialized
INFO - 2023-02-06 10:14:36 --> Language Class Initialized
INFO - 2023-02-06 10:14:36 --> Loader Class Initialized
INFO - 2023-02-06 10:14:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:36 --> Total execution time: 0.0039
INFO - 2023-02-06 10:14:36 --> Config Class Initialized
INFO - 2023-02-06 10:14:36 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:14:36 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:14:36 --> Utf8 Class Initialized
INFO - 2023-02-06 10:14:36 --> URI Class Initialized
INFO - 2023-02-06 10:14:36 --> Router Class Initialized
INFO - 2023-02-06 10:14:36 --> Output Class Initialized
INFO - 2023-02-06 10:14:36 --> Security Class Initialized
DEBUG - 2023-02-06 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:14:36 --> Input Class Initialized
INFO - 2023-02-06 10:14:36 --> Language Class Initialized
INFO - 2023-02-06 10:14:36 --> Loader Class Initialized
INFO - 2023-02-06 10:14:36 --> Controller Class Initialized
DEBUG - 2023-02-06 10:14:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:14:36 --> Database Driver Class Initialized
INFO - 2023-02-06 10:14:36 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:14:36 --> Final output sent to browser
DEBUG - 2023-02-06 10:14:36 --> Total execution time: 0.0170
INFO - 2023-02-06 10:22:40 --> Config Class Initialized
INFO - 2023-02-06 10:22:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:40 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:40 --> URI Class Initialized
INFO - 2023-02-06 10:22:40 --> Router Class Initialized
INFO - 2023-02-06 10:22:40 --> Output Class Initialized
INFO - 2023-02-06 10:22:40 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:40 --> Input Class Initialized
INFO - 2023-02-06 10:22:40 --> Language Class Initialized
INFO - 2023-02-06 10:22:40 --> Loader Class Initialized
INFO - 2023-02-06 10:22:40 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:40 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:40 --> Total execution time: 0.0039
INFO - 2023-02-06 10:22:40 --> Config Class Initialized
INFO - 2023-02-06 10:22:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:40 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:40 --> URI Class Initialized
INFO - 2023-02-06 10:22:40 --> Router Class Initialized
INFO - 2023-02-06 10:22:40 --> Output Class Initialized
INFO - 2023-02-06 10:22:40 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:40 --> Input Class Initialized
INFO - 2023-02-06 10:22:40 --> Language Class Initialized
INFO - 2023-02-06 10:22:40 --> Loader Class Initialized
INFO - 2023-02-06 10:22:40 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:40 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:40 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:40 --> Total execution time: 0.0141
INFO - 2023-02-06 10:22:40 --> Config Class Initialized
INFO - 2023-02-06 10:22:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:40 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:40 --> URI Class Initialized
INFO - 2023-02-06 10:22:40 --> Router Class Initialized
INFO - 2023-02-06 10:22:40 --> Output Class Initialized
INFO - 2023-02-06 10:22:40 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:40 --> Input Class Initialized
INFO - 2023-02-06 10:22:40 --> Language Class Initialized
INFO - 2023-02-06 10:22:40 --> Loader Class Initialized
INFO - 2023-02-06 10:22:40 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:40 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:40 --> Total execution time: 0.0460
INFO - 2023-02-06 10:22:40 --> Config Class Initialized
INFO - 2023-02-06 10:22:40 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:40 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:40 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:40 --> URI Class Initialized
INFO - 2023-02-06 10:22:40 --> Router Class Initialized
INFO - 2023-02-06 10:22:40 --> Output Class Initialized
INFO - 2023-02-06 10:22:40 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:40 --> Input Class Initialized
INFO - 2023-02-06 10:22:40 --> Language Class Initialized
INFO - 2023-02-06 10:22:40 --> Loader Class Initialized
INFO - 2023-02-06 10:22:40 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:40 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:40 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:40 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:40 --> Total execution time: 0.0121
INFO - 2023-02-06 10:22:49 --> Config Class Initialized
INFO - 2023-02-06 10:22:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:49 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:49 --> URI Class Initialized
INFO - 2023-02-06 10:22:49 --> Router Class Initialized
INFO - 2023-02-06 10:22:49 --> Output Class Initialized
INFO - 2023-02-06 10:22:49 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:49 --> Input Class Initialized
INFO - 2023-02-06 10:22:49 --> Language Class Initialized
INFO - 2023-02-06 10:22:49 --> Loader Class Initialized
INFO - 2023-02-06 10:22:49 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:49 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:49 --> Total execution time: 0.0038
INFO - 2023-02-06 10:22:49 --> Config Class Initialized
INFO - 2023-02-06 10:22:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:49 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:49 --> URI Class Initialized
INFO - 2023-02-06 10:22:49 --> Router Class Initialized
INFO - 2023-02-06 10:22:49 --> Output Class Initialized
INFO - 2023-02-06 10:22:49 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:49 --> Input Class Initialized
INFO - 2023-02-06 10:22:49 --> Language Class Initialized
INFO - 2023-02-06 10:22:49 --> Loader Class Initialized
INFO - 2023-02-06 10:22:49 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:49 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:49 --> Model "Login_model" initialized
INFO - 2023-02-06 10:22:49 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:49 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:49 --> Total execution time: 0.0456
INFO - 2023-02-06 10:22:49 --> Config Class Initialized
INFO - 2023-02-06 10:22:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:49 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:49 --> URI Class Initialized
INFO - 2023-02-06 10:22:49 --> Router Class Initialized
INFO - 2023-02-06 10:22:49 --> Output Class Initialized
INFO - 2023-02-06 10:22:49 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:49 --> Input Class Initialized
INFO - 2023-02-06 10:22:49 --> Language Class Initialized
INFO - 2023-02-06 10:22:49 --> Loader Class Initialized
INFO - 2023-02-06 10:22:49 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:49 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:49 --> Total execution time: 0.0323
INFO - 2023-02-06 10:22:49 --> Config Class Initialized
INFO - 2023-02-06 10:22:49 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:49 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:49 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:49 --> URI Class Initialized
INFO - 2023-02-06 10:22:49 --> Router Class Initialized
INFO - 2023-02-06 10:22:49 --> Output Class Initialized
INFO - 2023-02-06 10:22:49 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:49 --> Input Class Initialized
INFO - 2023-02-06 10:22:49 --> Language Class Initialized
INFO - 2023-02-06 10:22:49 --> Loader Class Initialized
INFO - 2023-02-06 10:22:49 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:49 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:49 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:49 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:49 --> Total execution time: 0.1395
INFO - 2023-02-06 10:22:54 --> Config Class Initialized
INFO - 2023-02-06 10:22:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:54 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:54 --> URI Class Initialized
INFO - 2023-02-06 10:22:54 --> Router Class Initialized
INFO - 2023-02-06 10:22:54 --> Output Class Initialized
INFO - 2023-02-06 10:22:54 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:54 --> Input Class Initialized
INFO - 2023-02-06 10:22:54 --> Language Class Initialized
INFO - 2023-02-06 10:22:54 --> Loader Class Initialized
INFO - 2023-02-06 10:22:54 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:54 --> Total execution time: 0.0041
INFO - 2023-02-06 10:22:54 --> Config Class Initialized
INFO - 2023-02-06 10:22:54 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:54 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:54 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:54 --> URI Class Initialized
INFO - 2023-02-06 10:22:54 --> Router Class Initialized
INFO - 2023-02-06 10:22:54 --> Output Class Initialized
INFO - 2023-02-06 10:22:54 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:54 --> Input Class Initialized
INFO - 2023-02-06 10:22:54 --> Language Class Initialized
INFO - 2023-02-06 10:22:54 --> Loader Class Initialized
INFO - 2023-02-06 10:22:54 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:54 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:54 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:54 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:54 --> Total execution time: 0.0178
INFO - 2023-02-06 10:22:59 --> Config Class Initialized
INFO - 2023-02-06 10:22:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:59 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:59 --> URI Class Initialized
INFO - 2023-02-06 10:22:59 --> Router Class Initialized
INFO - 2023-02-06 10:22:59 --> Output Class Initialized
INFO - 2023-02-06 10:22:59 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:59 --> Input Class Initialized
INFO - 2023-02-06 10:22:59 --> Language Class Initialized
INFO - 2023-02-06 10:22:59 --> Loader Class Initialized
INFO - 2023-02-06 10:22:59 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:59 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:59 --> Total execution time: 0.0041
INFO - 2023-02-06 10:22:59 --> Config Class Initialized
INFO - 2023-02-06 10:22:59 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:22:59 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:22:59 --> Utf8 Class Initialized
INFO - 2023-02-06 10:22:59 --> URI Class Initialized
INFO - 2023-02-06 10:22:59 --> Router Class Initialized
INFO - 2023-02-06 10:22:59 --> Output Class Initialized
INFO - 2023-02-06 10:22:59 --> Security Class Initialized
DEBUG - 2023-02-06 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:22:59 --> Input Class Initialized
INFO - 2023-02-06 10:22:59 --> Language Class Initialized
INFO - 2023-02-06 10:22:59 --> Loader Class Initialized
INFO - 2023-02-06 10:22:59 --> Controller Class Initialized
DEBUG - 2023-02-06 10:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:22:59 --> Database Driver Class Initialized
INFO - 2023-02-06 10:22:59 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:22:59 --> Final output sent to browser
DEBUG - 2023-02-06 10:22:59 --> Total execution time: 0.0147
INFO - 2023-02-06 10:23:04 --> Config Class Initialized
INFO - 2023-02-06 10:23:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:23:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:23:04 --> Utf8 Class Initialized
INFO - 2023-02-06 10:23:04 --> URI Class Initialized
INFO - 2023-02-06 10:23:04 --> Router Class Initialized
INFO - 2023-02-06 10:23:04 --> Output Class Initialized
INFO - 2023-02-06 10:23:04 --> Security Class Initialized
DEBUG - 2023-02-06 10:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:23:04 --> Input Class Initialized
INFO - 2023-02-06 10:23:04 --> Language Class Initialized
INFO - 2023-02-06 10:23:04 --> Loader Class Initialized
INFO - 2023-02-06 10:23:04 --> Controller Class Initialized
DEBUG - 2023-02-06 10:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:23:04 --> Final output sent to browser
DEBUG - 2023-02-06 10:23:04 --> Total execution time: 0.0039
INFO - 2023-02-06 10:23:04 --> Config Class Initialized
INFO - 2023-02-06 10:23:04 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:23:04 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:23:04 --> Utf8 Class Initialized
INFO - 2023-02-06 10:23:04 --> URI Class Initialized
INFO - 2023-02-06 10:23:04 --> Router Class Initialized
INFO - 2023-02-06 10:23:04 --> Output Class Initialized
INFO - 2023-02-06 10:23:04 --> Security Class Initialized
DEBUG - 2023-02-06 10:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:23:04 --> Input Class Initialized
INFO - 2023-02-06 10:23:04 --> Language Class Initialized
INFO - 2023-02-06 10:23:04 --> Loader Class Initialized
INFO - 2023-02-06 10:23:04 --> Controller Class Initialized
DEBUG - 2023-02-06 10:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:23:04 --> Database Driver Class Initialized
INFO - 2023-02-06 10:23:04 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:23:04 --> Final output sent to browser
DEBUG - 2023-02-06 10:23:04 --> Total execution time: 0.0131
INFO - 2023-02-06 10:23:09 --> Config Class Initialized
INFO - 2023-02-06 10:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:23:09 --> Utf8 Class Initialized
INFO - 2023-02-06 10:23:09 --> URI Class Initialized
INFO - 2023-02-06 10:23:09 --> Router Class Initialized
INFO - 2023-02-06 10:23:09 --> Output Class Initialized
INFO - 2023-02-06 10:23:09 --> Security Class Initialized
DEBUG - 2023-02-06 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:23:09 --> Input Class Initialized
INFO - 2023-02-06 10:23:09 --> Language Class Initialized
INFO - 2023-02-06 10:23:09 --> Loader Class Initialized
INFO - 2023-02-06 10:23:09 --> Controller Class Initialized
DEBUG - 2023-02-06 10:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:23:09 --> Final output sent to browser
DEBUG - 2023-02-06 10:23:09 --> Total execution time: 0.0036
INFO - 2023-02-06 10:23:09 --> Config Class Initialized
INFO - 2023-02-06 10:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:23:09 --> Utf8 Class Initialized
INFO - 2023-02-06 10:23:09 --> URI Class Initialized
INFO - 2023-02-06 10:23:09 --> Router Class Initialized
INFO - 2023-02-06 10:23:09 --> Output Class Initialized
INFO - 2023-02-06 10:23:09 --> Security Class Initialized
DEBUG - 2023-02-06 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:23:09 --> Input Class Initialized
INFO - 2023-02-06 10:23:09 --> Language Class Initialized
INFO - 2023-02-06 10:23:09 --> Loader Class Initialized
INFO - 2023-02-06 10:23:09 --> Controller Class Initialized
DEBUG - 2023-02-06 10:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:23:09 --> Database Driver Class Initialized
INFO - 2023-02-06 10:23:09 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:23:09 --> Final output sent to browser
DEBUG - 2023-02-06 10:23:09 --> Total execution time: 0.0169
INFO - 2023-02-06 10:36:45 --> Config Class Initialized
INFO - 2023-02-06 10:36:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:45 --> URI Class Initialized
INFO - 2023-02-06 10:36:45 --> Router Class Initialized
INFO - 2023-02-06 10:36:45 --> Output Class Initialized
INFO - 2023-02-06 10:36:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:45 --> Input Class Initialized
INFO - 2023-02-06 10:36:45 --> Language Class Initialized
INFO - 2023-02-06 10:36:45 --> Loader Class Initialized
INFO - 2023-02-06 10:36:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:45 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:45 --> Total execution time: 0.0198
INFO - 2023-02-06 10:36:45 --> Config Class Initialized
INFO - 2023-02-06 10:36:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:45 --> URI Class Initialized
INFO - 2023-02-06 10:36:45 --> Router Class Initialized
INFO - 2023-02-06 10:36:45 --> Output Class Initialized
INFO - 2023-02-06 10:36:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:45 --> Input Class Initialized
INFO - 2023-02-06 10:36:45 --> Language Class Initialized
INFO - 2023-02-06 10:36:45 --> Loader Class Initialized
INFO - 2023-02-06 10:36:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:45 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:45 --> Total execution time: 0.0563
INFO - 2023-02-06 10:36:50 --> Config Class Initialized
INFO - 2023-02-06 10:36:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:50 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:50 --> URI Class Initialized
INFO - 2023-02-06 10:36:50 --> Router Class Initialized
INFO - 2023-02-06 10:36:50 --> Output Class Initialized
INFO - 2023-02-06 10:36:50 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:50 --> Input Class Initialized
INFO - 2023-02-06 10:36:50 --> Language Class Initialized
INFO - 2023-02-06 10:36:50 --> Loader Class Initialized
INFO - 2023-02-06 10:36:50 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:50 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:50 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:50 --> Total execution time: 0.0159
INFO - 2023-02-06 10:36:50 --> Config Class Initialized
INFO - 2023-02-06 10:36:50 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:50 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:50 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:50 --> URI Class Initialized
INFO - 2023-02-06 10:36:50 --> Router Class Initialized
INFO - 2023-02-06 10:36:50 --> Output Class Initialized
INFO - 2023-02-06 10:36:50 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:50 --> Input Class Initialized
INFO - 2023-02-06 10:36:50 --> Language Class Initialized
INFO - 2023-02-06 10:36:50 --> Loader Class Initialized
INFO - 2023-02-06 10:36:50 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:50 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:50 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:50 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:50 --> Total execution time: 0.0524
INFO - 2023-02-06 10:36:51 --> Config Class Initialized
INFO - 2023-02-06 10:36:51 --> Config Class Initialized
INFO - 2023-02-06 10:36:51 --> Hooks Class Initialized
INFO - 2023-02-06 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:51 --> URI Class Initialized
INFO - 2023-02-06 10:36:51 --> URI Class Initialized
INFO - 2023-02-06 10:36:51 --> Router Class Initialized
INFO - 2023-02-06 10:36:51 --> Router Class Initialized
INFO - 2023-02-06 10:36:51 --> Output Class Initialized
INFO - 2023-02-06 10:36:51 --> Output Class Initialized
INFO - 2023-02-06 10:36:51 --> Security Class Initialized
INFO - 2023-02-06 10:36:51 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:51 --> Input Class Initialized
INFO - 2023-02-06 10:36:51 --> Input Class Initialized
INFO - 2023-02-06 10:36:51 --> Language Class Initialized
INFO - 2023-02-06 10:36:51 --> Language Class Initialized
INFO - 2023-02-06 10:36:51 --> Loader Class Initialized
INFO - 2023-02-06 10:36:51 --> Loader Class Initialized
INFO - 2023-02-06 10:36:51 --> Controller Class Initialized
INFO - 2023-02-06 10:36:51 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:51 --> Total execution time: 0.0038
INFO - 2023-02-06 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:51 --> Config Class Initialized
INFO - 2023-02-06 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:51 --> URI Class Initialized
INFO - 2023-02-06 10:36:51 --> Router Class Initialized
INFO - 2023-02-06 10:36:51 --> Output Class Initialized
INFO - 2023-02-06 10:36:51 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:51 --> Input Class Initialized
INFO - 2023-02-06 10:36:51 --> Language Class Initialized
INFO - 2023-02-06 10:36:51 --> Loader Class Initialized
INFO - 2023-02-06 10:36:51 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:51 --> Total execution time: 0.0501
INFO - 2023-02-06 10:36:51 --> Config Class Initialized
INFO - 2023-02-06 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:51 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:51 --> URI Class Initialized
INFO - 2023-02-06 10:36:51 --> Router Class Initialized
INFO - 2023-02-06 10:36:51 --> Output Class Initialized
INFO - 2023-02-06 10:36:51 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:51 --> Input Class Initialized
INFO - 2023-02-06 10:36:51 --> Language Class Initialized
INFO - 2023-02-06 10:36:51 --> Loader Class Initialized
INFO - 2023-02-06 10:36:51 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:51 --> Model "Login_model" initialized
INFO - 2023-02-06 10:36:51 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:51 --> Total execution time: 0.0147
INFO - 2023-02-06 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:51 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:51 --> Total execution time: 0.0621
INFO - 2023-02-06 10:36:58 --> Config Class Initialized
INFO - 2023-02-06 10:36:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:58 --> URI Class Initialized
INFO - 2023-02-06 10:36:58 --> Router Class Initialized
INFO - 2023-02-06 10:36:58 --> Output Class Initialized
INFO - 2023-02-06 10:36:58 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:58 --> Input Class Initialized
INFO - 2023-02-06 10:36:58 --> Language Class Initialized
INFO - 2023-02-06 10:36:58 --> Loader Class Initialized
INFO - 2023-02-06 10:36:58 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:58 --> Total execution time: 0.0146
INFO - 2023-02-06 10:36:58 --> Config Class Initialized
INFO - 2023-02-06 10:36:58 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:36:58 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:36:58 --> Utf8 Class Initialized
INFO - 2023-02-06 10:36:58 --> URI Class Initialized
INFO - 2023-02-06 10:36:58 --> Router Class Initialized
INFO - 2023-02-06 10:36:58 --> Output Class Initialized
INFO - 2023-02-06 10:36:58 --> Security Class Initialized
DEBUG - 2023-02-06 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:36:58 --> Input Class Initialized
INFO - 2023-02-06 10:36:58 --> Language Class Initialized
INFO - 2023-02-06 10:36:58 --> Loader Class Initialized
INFO - 2023-02-06 10:36:58 --> Controller Class Initialized
DEBUG - 2023-02-06 10:36:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:36:58 --> Database Driver Class Initialized
INFO - 2023-02-06 10:36:58 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:36:58 --> Final output sent to browser
DEBUG - 2023-02-06 10:36:58 --> Total execution time: 0.0122
INFO - 2023-02-06 10:39:37 --> Config Class Initialized
INFO - 2023-02-06 10:39:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:37 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:37 --> URI Class Initialized
INFO - 2023-02-06 10:39:37 --> Router Class Initialized
INFO - 2023-02-06 10:39:37 --> Output Class Initialized
INFO - 2023-02-06 10:39:37 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:37 --> Input Class Initialized
INFO - 2023-02-06 10:39:37 --> Language Class Initialized
INFO - 2023-02-06 10:39:37 --> Loader Class Initialized
INFO - 2023-02-06 10:39:37 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:37 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:37 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:37 --> Total execution time: 0.0157
INFO - 2023-02-06 10:39:37 --> Config Class Initialized
INFO - 2023-02-06 10:39:37 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:37 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:37 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:37 --> URI Class Initialized
INFO - 2023-02-06 10:39:37 --> Router Class Initialized
INFO - 2023-02-06 10:39:37 --> Output Class Initialized
INFO - 2023-02-06 10:39:37 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:37 --> Input Class Initialized
INFO - 2023-02-06 10:39:37 --> Language Class Initialized
INFO - 2023-02-06 10:39:37 --> Loader Class Initialized
INFO - 2023-02-06 10:39:37 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:37 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:37 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:37 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:37 --> Total execution time: 0.0118
INFO - 2023-02-06 10:39:39 --> Config Class Initialized
INFO - 2023-02-06 10:39:39 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:39 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:39 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:39 --> URI Class Initialized
INFO - 2023-02-06 10:39:39 --> Router Class Initialized
INFO - 2023-02-06 10:39:39 --> Output Class Initialized
INFO - 2023-02-06 10:39:39 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:39 --> Input Class Initialized
INFO - 2023-02-06 10:39:39 --> Language Class Initialized
INFO - 2023-02-06 10:39:39 --> Loader Class Initialized
INFO - 2023-02-06 10:39:39 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:39 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:39 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:39 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:39 --> Total execution time: 0.0142
INFO - 2023-02-06 10:39:39 --> Config Class Initialized
INFO - 2023-02-06 10:39:39 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:39 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:39 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:39 --> URI Class Initialized
INFO - 2023-02-06 10:39:39 --> Router Class Initialized
INFO - 2023-02-06 10:39:39 --> Output Class Initialized
INFO - 2023-02-06 10:39:39 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:39 --> Input Class Initialized
INFO - 2023-02-06 10:39:39 --> Language Class Initialized
INFO - 2023-02-06 10:39:39 --> Loader Class Initialized
INFO - 2023-02-06 10:39:39 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:39 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:39 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:39 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:39 --> Total execution time: 0.0206
INFO - 2023-02-06 10:39:41 --> Config Class Initialized
INFO - 2023-02-06 10:39:41 --> Config Class Initialized
INFO - 2023-02-06 10:39:41 --> Hooks Class Initialized
INFO - 2023-02-06 10:39:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-02-06 10:39:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:41 --> URI Class Initialized
INFO - 2023-02-06 10:39:41 --> URI Class Initialized
INFO - 2023-02-06 10:39:41 --> Router Class Initialized
INFO - 2023-02-06 10:39:41 --> Router Class Initialized
INFO - 2023-02-06 10:39:41 --> Output Class Initialized
INFO - 2023-02-06 10:39:41 --> Output Class Initialized
INFO - 2023-02-06 10:39:41 --> Security Class Initialized
INFO - 2023-02-06 10:39:41 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-06 10:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:41 --> Input Class Initialized
INFO - 2023-02-06 10:39:41 --> Input Class Initialized
INFO - 2023-02-06 10:39:41 --> Language Class Initialized
INFO - 2023-02-06 10:39:41 --> Language Class Initialized
INFO - 2023-02-06 10:39:41 --> Loader Class Initialized
INFO - 2023-02-06 10:39:41 --> Loader Class Initialized
INFO - 2023-02-06 10:39:41 --> Controller Class Initialized
INFO - 2023-02-06 10:39:41 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-06 10:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:41 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:41 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:41 --> Total execution time: 0.0048
INFO - 2023-02-06 10:39:41 --> Config Class Initialized
INFO - 2023-02-06 10:39:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:41 --> URI Class Initialized
INFO - 2023-02-06 10:39:41 --> Router Class Initialized
INFO - 2023-02-06 10:39:41 --> Output Class Initialized
INFO - 2023-02-06 10:39:41 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:41 --> Input Class Initialized
INFO - 2023-02-06 10:39:41 --> Language Class Initialized
INFO - 2023-02-06 10:39:41 --> Loader Class Initialized
INFO - 2023-02-06 10:39:41 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:41 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:41 --> Final output sent to browser
INFO - 2023-02-06 10:39:41 --> Model "Login_model" initialized
DEBUG - 2023-02-06 10:39:41 --> Total execution time: 0.0184
INFO - 2023-02-06 10:39:41 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:41 --> Config Class Initialized
INFO - 2023-02-06 10:39:41 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:41 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:41 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:41 --> URI Class Initialized
INFO - 2023-02-06 10:39:41 --> Router Class Initialized
INFO - 2023-02-06 10:39:41 --> Output Class Initialized
INFO - 2023-02-06 10:39:41 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:41 --> Input Class Initialized
INFO - 2023-02-06 10:39:41 --> Language Class Initialized
INFO - 2023-02-06 10:39:41 --> Loader Class Initialized
INFO - 2023-02-06 10:39:41 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:41 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:41 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:41 --> Total execution time: 0.0183
INFO - 2023-02-06 10:39:41 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:41 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:41 --> Total execution time: 0.0542
INFO - 2023-02-06 10:39:43 --> Config Class Initialized
INFO - 2023-02-06 10:39:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:43 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:43 --> URI Class Initialized
INFO - 2023-02-06 10:39:43 --> Router Class Initialized
INFO - 2023-02-06 10:39:43 --> Output Class Initialized
INFO - 2023-02-06 10:39:43 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:43 --> Input Class Initialized
INFO - 2023-02-06 10:39:43 --> Language Class Initialized
INFO - 2023-02-06 10:39:43 --> Loader Class Initialized
INFO - 2023-02-06 10:39:43 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:43 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:43 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:43 --> Total execution time: 0.0206
INFO - 2023-02-06 10:39:43 --> Config Class Initialized
INFO - 2023-02-06 10:39:43 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:43 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:43 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:43 --> URI Class Initialized
INFO - 2023-02-06 10:39:43 --> Router Class Initialized
INFO - 2023-02-06 10:39:43 --> Output Class Initialized
INFO - 2023-02-06 10:39:43 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:43 --> Input Class Initialized
INFO - 2023-02-06 10:39:43 --> Language Class Initialized
INFO - 2023-02-06 10:39:43 --> Loader Class Initialized
INFO - 2023-02-06 10:39:43 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:43 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:43 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:43 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:43 --> Total execution time: 0.0115
INFO - 2023-02-06 10:39:45 --> Config Class Initialized
INFO - 2023-02-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:45 --> URI Class Initialized
INFO - 2023-02-06 10:39:45 --> Router Class Initialized
INFO - 2023-02-06 10:39:45 --> Output Class Initialized
INFO - 2023-02-06 10:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:45 --> Input Class Initialized
INFO - 2023-02-06 10:39:45 --> Language Class Initialized
INFO - 2023-02-06 10:39:45 --> Loader Class Initialized
INFO - 2023-02-06 10:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:45 --> Total execution time: 0.0042
INFO - 2023-02-06 10:39:45 --> Config Class Initialized
INFO - 2023-02-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:45 --> URI Class Initialized
INFO - 2023-02-06 10:39:45 --> Router Class Initialized
INFO - 2023-02-06 10:39:45 --> Output Class Initialized
INFO - 2023-02-06 10:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:45 --> Input Class Initialized
INFO - 2023-02-06 10:39:45 --> Language Class Initialized
INFO - 2023-02-06 10:39:45 --> Loader Class Initialized
INFO - 2023-02-06 10:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:45 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:45 --> Total execution time: 0.0548
INFO - 2023-02-06 10:39:45 --> Config Class Initialized
INFO - 2023-02-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:45 --> URI Class Initialized
INFO - 2023-02-06 10:39:45 --> Router Class Initialized
INFO - 2023-02-06 10:39:45 --> Output Class Initialized
INFO - 2023-02-06 10:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:45 --> Input Class Initialized
INFO - 2023-02-06 10:39:45 --> Language Class Initialized
INFO - 2023-02-06 10:39:45 --> Loader Class Initialized
INFO - 2023-02-06 10:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:45 --> Total execution time: 0.0531
INFO - 2023-02-06 10:39:45 --> Config Class Initialized
INFO - 2023-02-06 10:39:45 --> Hooks Class Initialized
DEBUG - 2023-02-06 10:39:45 --> UTF-8 Support Enabled
INFO - 2023-02-06 10:39:45 --> Utf8 Class Initialized
INFO - 2023-02-06 10:39:45 --> URI Class Initialized
INFO - 2023-02-06 10:39:45 --> Router Class Initialized
INFO - 2023-02-06 10:39:45 --> Output Class Initialized
INFO - 2023-02-06 10:39:45 --> Security Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-06 10:39:45 --> Input Class Initialized
INFO - 2023-02-06 10:39:45 --> Language Class Initialized
INFO - 2023-02-06 10:39:45 --> Loader Class Initialized
INFO - 2023-02-06 10:39:45 --> Controller Class Initialized
DEBUG - 2023-02-06 10:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-06 10:39:45 --> Database Driver Class Initialized
INFO - 2023-02-06 10:39:45 --> Model "Cluster_model" initialized
INFO - 2023-02-06 10:39:45 --> Final output sent to browser
DEBUG - 2023-02-06 10:39:45 --> Total execution time: 0.0572
