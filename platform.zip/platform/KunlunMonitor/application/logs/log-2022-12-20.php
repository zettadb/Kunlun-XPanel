<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-20 05:47:45 --> Config Class Initialized
INFO - 2022-12-20 05:47:45 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:45 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:45 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:45 --> URI Class Initialized
INFO - 2022-12-20 05:47:45 --> Router Class Initialized
INFO - 2022-12-20 05:47:45 --> Output Class Initialized
INFO - 2022-12-20 05:47:45 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:45 --> Input Class Initialized
INFO - 2022-12-20 05:47:45 --> Language Class Initialized
INFO - 2022-12-20 05:47:45 --> Loader Class Initialized
INFO - 2022-12-20 05:47:45 --> Controller Class Initialized
INFO - 2022-12-20 05:47:45 --> Helper loaded: form_helper
INFO - 2022-12-20 05:47:45 --> Helper loaded: url_helper
DEBUG - 2022-12-20 05:47:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:45 --> Model "Change_model" initialized
INFO - 2022-12-20 05:47:45 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:47:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:46 --> Total execution time: 0.3048
INFO - 2022-12-20 05:47:46 --> Config Class Initialized
INFO - 2022-12-20 05:47:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:46 --> URI Class Initialized
INFO - 2022-12-20 05:47:46 --> Router Class Initialized
INFO - 2022-12-20 05:47:46 --> Output Class Initialized
INFO - 2022-12-20 05:47:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:46 --> Input Class Initialized
INFO - 2022-12-20 05:47:46 --> Language Class Initialized
INFO - 2022-12-20 05:47:46 --> Loader Class Initialized
INFO - 2022-12-20 05:47:46 --> Controller Class Initialized
INFO - 2022-12-20 05:47:46 --> Helper loaded: form_helper
INFO - 2022-12-20 05:47:46 --> Helper loaded: url_helper
DEBUG - 2022-12-20 05:47:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:46 --> Total execution time: 0.1544
INFO - 2022-12-20 05:47:46 --> Config Class Initialized
INFO - 2022-12-20 05:47:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:46 --> URI Class Initialized
INFO - 2022-12-20 05:47:46 --> Router Class Initialized
INFO - 2022-12-20 05:47:46 --> Output Class Initialized
INFO - 2022-12-20 05:47:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:46 --> Input Class Initialized
INFO - 2022-12-20 05:47:46 --> Language Class Initialized
INFO - 2022-12-20 05:47:46 --> Loader Class Initialized
INFO - 2022-12-20 05:47:46 --> Controller Class Initialized
INFO - 2022-12-20 05:47:46 --> Helper loaded: form_helper
INFO - 2022-12-20 05:47:46 --> Helper loaded: url_helper
DEBUG - 2022-12-20 05:47:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:46 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:46 --> Model "Login_model" initialized
INFO - 2022-12-20 05:47:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:46 --> Total execution time: 0.2011
INFO - 2022-12-20 05:47:46 --> Config Class Initialized
INFO - 2022-12-20 05:47:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:46 --> URI Class Initialized
INFO - 2022-12-20 05:47:46 --> Router Class Initialized
INFO - 2022-12-20 05:47:46 --> Output Class Initialized
INFO - 2022-12-20 05:47:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:46 --> Input Class Initialized
INFO - 2022-12-20 05:47:46 --> Language Class Initialized
INFO - 2022-12-20 05:47:46 --> Loader Class Initialized
INFO - 2022-12-20 05:47:46 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:46 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:46 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:46 --> Total execution time: 0.1526
INFO - 2022-12-20 05:47:46 --> Config Class Initialized
INFO - 2022-12-20 05:47:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:46 --> URI Class Initialized
INFO - 2022-12-20 05:47:46 --> Router Class Initialized
INFO - 2022-12-20 05:47:46 --> Output Class Initialized
INFO - 2022-12-20 05:47:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:46 --> Input Class Initialized
INFO - 2022-12-20 05:47:46 --> Language Class Initialized
INFO - 2022-12-20 05:47:46 --> Loader Class Initialized
INFO - 2022-12-20 05:47:46 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:46 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:46 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:46 --> Total execution time: 0.1498
INFO - 2022-12-20 05:47:47 --> Config Class Initialized
INFO - 2022-12-20 05:47:47 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:47 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:47 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:47 --> URI Class Initialized
INFO - 2022-12-20 05:47:47 --> Router Class Initialized
INFO - 2022-12-20 05:47:47 --> Output Class Initialized
INFO - 2022-12-20 05:47:47 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:47 --> Input Class Initialized
INFO - 2022-12-20 05:47:47 --> Language Class Initialized
INFO - 2022-12-20 05:47:47 --> Loader Class Initialized
INFO - 2022-12-20 05:47:47 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:47 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:47 --> Model "Login_model" initialized
INFO - 2022-12-20 05:47:47 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:47 --> Total execution time: 0.2344
INFO - 2022-12-20 05:47:47 --> Config Class Initialized
INFO - 2022-12-20 05:47:47 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:47 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:47 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:47 --> URI Class Initialized
INFO - 2022-12-20 05:47:47 --> Router Class Initialized
INFO - 2022-12-20 05:47:47 --> Output Class Initialized
INFO - 2022-12-20 05:47:47 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:47 --> Input Class Initialized
INFO - 2022-12-20 05:47:47 --> Language Class Initialized
INFO - 2022-12-20 05:47:47 --> Loader Class Initialized
INFO - 2022-12-20 05:47:47 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:47 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:47 --> Model "Login_model" initialized
INFO - 2022-12-20 05:47:47 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:47 --> Total execution time: 0.2139
INFO - 2022-12-20 05:47:51 --> Config Class Initialized
INFO - 2022-12-20 05:47:51 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:51 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:51 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:52 --> URI Class Initialized
INFO - 2022-12-20 05:47:52 --> Router Class Initialized
INFO - 2022-12-20 05:47:52 --> Output Class Initialized
INFO - 2022-12-20 05:47:52 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:52 --> Input Class Initialized
INFO - 2022-12-20 05:47:52 --> Language Class Initialized
INFO - 2022-12-20 05:47:52 --> Loader Class Initialized
INFO - 2022-12-20 05:47:52 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:52 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:52 --> Total execution time: 0.0938
INFO - 2022-12-20 05:47:52 --> Config Class Initialized
INFO - 2022-12-20 05:47:52 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:52 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:52 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:52 --> URI Class Initialized
INFO - 2022-12-20 05:47:52 --> Router Class Initialized
INFO - 2022-12-20 05:47:52 --> Output Class Initialized
INFO - 2022-12-20 05:47:52 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:52 --> Input Class Initialized
INFO - 2022-12-20 05:47:52 --> Language Class Initialized
INFO - 2022-12-20 05:47:52 --> Loader Class Initialized
INFO - 2022-12-20 05:47:52 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:52 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:52 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:52 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:52 --> Total execution time: 0.1174
INFO - 2022-12-20 05:47:54 --> Config Class Initialized
INFO - 2022-12-20 05:47:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:54 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:54 --> URI Class Initialized
INFO - 2022-12-20 05:47:54 --> Router Class Initialized
INFO - 2022-12-20 05:47:54 --> Output Class Initialized
INFO - 2022-12-20 05:47:54 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:54 --> Input Class Initialized
INFO - 2022-12-20 05:47:54 --> Language Class Initialized
INFO - 2022-12-20 05:47:54 --> Loader Class Initialized
INFO - 2022-12-20 05:47:54 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:54 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:54 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:54 --> Total execution time: 0.1391
INFO - 2022-12-20 05:47:54 --> Config Class Initialized
INFO - 2022-12-20 05:47:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:54 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:54 --> URI Class Initialized
INFO - 2022-12-20 05:47:54 --> Router Class Initialized
INFO - 2022-12-20 05:47:54 --> Output Class Initialized
INFO - 2022-12-20 05:47:54 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:54 --> Input Class Initialized
INFO - 2022-12-20 05:47:54 --> Language Class Initialized
INFO - 2022-12-20 05:47:54 --> Loader Class Initialized
INFO - 2022-12-20 05:47:54 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:54 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:54 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:54 --> Total execution time: 0.1344
INFO - 2022-12-20 05:47:58 --> Config Class Initialized
INFO - 2022-12-20 05:47:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:58 --> URI Class Initialized
INFO - 2022-12-20 05:47:58 --> Router Class Initialized
INFO - 2022-12-20 05:47:58 --> Output Class Initialized
INFO - 2022-12-20 05:47:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:58 --> Input Class Initialized
INFO - 2022-12-20 05:47:58 --> Language Class Initialized
INFO - 2022-12-20 05:47:58 --> Loader Class Initialized
INFO - 2022-12-20 05:47:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:58 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:58 --> Total execution time: 0.1426
INFO - 2022-12-20 05:47:58 --> Config Class Initialized
INFO - 2022-12-20 05:47:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:47:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:47:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:47:58 --> URI Class Initialized
INFO - 2022-12-20 05:47:58 --> Router Class Initialized
INFO - 2022-12-20 05:47:58 --> Output Class Initialized
INFO - 2022-12-20 05:47:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:47:58 --> Input Class Initialized
INFO - 2022-12-20 05:47:58 --> Language Class Initialized
INFO - 2022-12-20 05:47:58 --> Loader Class Initialized
INFO - 2022-12-20 05:47:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:47:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:47:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:47:58 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:47:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:47:58 --> Total execution time: 0.1301
INFO - 2022-12-20 05:48:00 --> Config Class Initialized
INFO - 2022-12-20 05:48:00 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:01 --> URI Class Initialized
INFO - 2022-12-20 05:48:01 --> Router Class Initialized
INFO - 2022-12-20 05:48:01 --> Output Class Initialized
INFO - 2022-12-20 05:48:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:01 --> Input Class Initialized
INFO - 2022-12-20 05:48:01 --> Language Class Initialized
INFO - 2022-12-20 05:48:01 --> Loader Class Initialized
INFO - 2022-12-20 05:48:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:01 --> Total execution time: 0.0867
INFO - 2022-12-20 05:48:01 --> Config Class Initialized
INFO - 2022-12-20 05:48:01 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:01 --> URI Class Initialized
INFO - 2022-12-20 05:48:01 --> Router Class Initialized
INFO - 2022-12-20 05:48:01 --> Output Class Initialized
INFO - 2022-12-20 05:48:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:01 --> Input Class Initialized
INFO - 2022-12-20 05:48:01 --> Language Class Initialized
INFO - 2022-12-20 05:48:01 --> Loader Class Initialized
INFO - 2022-12-20 05:48:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:01 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:01 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:01 --> Total execution time: 0.1205
INFO - 2022-12-20 05:48:01 --> Config Class Initialized
INFO - 2022-12-20 05:48:01 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:01 --> URI Class Initialized
INFO - 2022-12-20 05:48:01 --> Router Class Initialized
INFO - 2022-12-20 05:48:01 --> Output Class Initialized
INFO - 2022-12-20 05:48:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:01 --> Input Class Initialized
INFO - 2022-12-20 05:48:01 --> Language Class Initialized
INFO - 2022-12-20 05:48:01 --> Loader Class Initialized
INFO - 2022-12-20 05:48:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:01 --> Total execution time: 0.0997
INFO - 2022-12-20 05:48:01 --> Config Class Initialized
INFO - 2022-12-20 05:48:01 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:01 --> URI Class Initialized
INFO - 2022-12-20 05:48:01 --> Router Class Initialized
INFO - 2022-12-20 05:48:01 --> Output Class Initialized
INFO - 2022-12-20 05:48:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:01 --> Input Class Initialized
INFO - 2022-12-20 05:48:01 --> Language Class Initialized
INFO - 2022-12-20 05:48:01 --> Loader Class Initialized
INFO - 2022-12-20 05:48:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:02 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:02 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:02 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:02 --> Total execution time: 0.1474
INFO - 2022-12-20 05:48:07 --> Config Class Initialized
INFO - 2022-12-20 05:48:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:07 --> URI Class Initialized
INFO - 2022-12-20 05:48:07 --> Router Class Initialized
INFO - 2022-12-20 05:48:07 --> Output Class Initialized
INFO - 2022-12-20 05:48:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:07 --> Input Class Initialized
INFO - 2022-12-20 05:48:07 --> Language Class Initialized
INFO - 2022-12-20 05:48:07 --> Loader Class Initialized
INFO - 2022-12-20 05:48:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:07 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:07 --> Total execution time: 0.1680
INFO - 2022-12-20 05:48:07 --> Config Class Initialized
INFO - 2022-12-20 05:48:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:07 --> URI Class Initialized
INFO - 2022-12-20 05:48:07 --> Router Class Initialized
INFO - 2022-12-20 05:48:07 --> Output Class Initialized
INFO - 2022-12-20 05:48:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:07 --> Input Class Initialized
INFO - 2022-12-20 05:48:07 --> Language Class Initialized
INFO - 2022-12-20 05:48:07 --> Loader Class Initialized
INFO - 2022-12-20 05:48:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:07 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:07 --> Total execution time: 0.1374
INFO - 2022-12-20 05:48:09 --> Config Class Initialized
INFO - 2022-12-20 05:48:09 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:09 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:09 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:09 --> URI Class Initialized
INFO - 2022-12-20 05:48:09 --> Router Class Initialized
INFO - 2022-12-20 05:48:09 --> Output Class Initialized
INFO - 2022-12-20 05:48:09 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:09 --> Input Class Initialized
INFO - 2022-12-20 05:48:09 --> Language Class Initialized
INFO - 2022-12-20 05:48:09 --> Loader Class Initialized
INFO - 2022-12-20 05:48:09 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:09 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:09 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:09 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:09 --> Total execution time: 0.1444
INFO - 2022-12-20 05:48:09 --> Config Class Initialized
INFO - 2022-12-20 05:48:09 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:09 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:09 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:09 --> URI Class Initialized
INFO - 2022-12-20 05:48:09 --> Router Class Initialized
INFO - 2022-12-20 05:48:10 --> Output Class Initialized
INFO - 2022-12-20 05:48:10 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:10 --> Input Class Initialized
INFO - 2022-12-20 05:48:10 --> Language Class Initialized
INFO - 2022-12-20 05:48:10 --> Loader Class Initialized
INFO - 2022-12-20 05:48:10 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:10 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:10 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:10 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:10 --> Total execution time: 0.1807
INFO - 2022-12-20 05:48:12 --> Config Class Initialized
INFO - 2022-12-20 05:48:12 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:12 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:12 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:12 --> URI Class Initialized
INFO - 2022-12-20 05:48:12 --> Router Class Initialized
INFO - 2022-12-20 05:48:12 --> Output Class Initialized
INFO - 2022-12-20 05:48:12 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:12 --> Input Class Initialized
INFO - 2022-12-20 05:48:12 --> Language Class Initialized
INFO - 2022-12-20 05:48:12 --> Loader Class Initialized
INFO - 2022-12-20 05:48:12 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:12 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:12 --> Total execution time: 0.0908
INFO - 2022-12-20 05:48:12 --> Config Class Initialized
INFO - 2022-12-20 05:48:12 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:12 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:12 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:12 --> URI Class Initialized
INFO - 2022-12-20 05:48:12 --> Router Class Initialized
INFO - 2022-12-20 05:48:12 --> Output Class Initialized
INFO - 2022-12-20 05:48:12 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:12 --> Input Class Initialized
INFO - 2022-12-20 05:48:12 --> Language Class Initialized
INFO - 2022-12-20 05:48:12 --> Loader Class Initialized
INFO - 2022-12-20 05:48:12 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:12 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:12 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:12 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:12 --> Total execution time: 0.1159
INFO - 2022-12-20 05:48:23 --> Config Class Initialized
INFO - 2022-12-20 05:48:24 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:24 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:24 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:24 --> URI Class Initialized
INFO - 2022-12-20 05:48:24 --> Router Class Initialized
INFO - 2022-12-20 05:48:24 --> Output Class Initialized
INFO - 2022-12-20 05:48:24 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:24 --> Input Class Initialized
INFO - 2022-12-20 05:48:24 --> Language Class Initialized
INFO - 2022-12-20 05:48:24 --> Loader Class Initialized
INFO - 2022-12-20 05:48:24 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:24 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:24 --> Total execution time: 0.0926
INFO - 2022-12-20 05:48:24 --> Config Class Initialized
INFO - 2022-12-20 05:48:24 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:24 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:24 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:24 --> URI Class Initialized
INFO - 2022-12-20 05:48:24 --> Router Class Initialized
INFO - 2022-12-20 05:48:24 --> Output Class Initialized
INFO - 2022-12-20 05:48:24 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:24 --> Input Class Initialized
INFO - 2022-12-20 05:48:24 --> Language Class Initialized
INFO - 2022-12-20 05:48:24 --> Loader Class Initialized
INFO - 2022-12-20 05:48:24 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:24 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:24 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:24 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:24 --> Total execution time: 0.1101
INFO - 2022-12-20 05:48:24 --> Config Class Initialized
INFO - 2022-12-20 05:48:24 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:24 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:24 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:24 --> URI Class Initialized
INFO - 2022-12-20 05:48:24 --> Router Class Initialized
INFO - 2022-12-20 05:48:24 --> Output Class Initialized
INFO - 2022-12-20 05:48:24 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:24 --> Input Class Initialized
INFO - 2022-12-20 05:48:24 --> Language Class Initialized
INFO - 2022-12-20 05:48:24 --> Loader Class Initialized
INFO - 2022-12-20 05:48:24 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:24 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:24 --> Total execution time: 0.0961
INFO - 2022-12-20 05:48:24 --> Config Class Initialized
INFO - 2022-12-20 05:48:24 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:24 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:24 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:24 --> URI Class Initialized
INFO - 2022-12-20 05:48:24 --> Router Class Initialized
INFO - 2022-12-20 05:48:24 --> Output Class Initialized
INFO - 2022-12-20 05:48:25 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:25 --> Input Class Initialized
INFO - 2022-12-20 05:48:25 --> Language Class Initialized
INFO - 2022-12-20 05:48:25 --> Loader Class Initialized
INFO - 2022-12-20 05:48:25 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:25 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:25 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:25 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:25 --> Total execution time: 0.1884
INFO - 2022-12-20 05:48:49 --> Config Class Initialized
INFO - 2022-12-20 05:48:49 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:49 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:49 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:50 --> URI Class Initialized
INFO - 2022-12-20 05:48:50 --> Router Class Initialized
INFO - 2022-12-20 05:48:50 --> Output Class Initialized
INFO - 2022-12-20 05:48:50 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:50 --> Input Class Initialized
INFO - 2022-12-20 05:48:50 --> Language Class Initialized
INFO - 2022-12-20 05:48:50 --> Loader Class Initialized
INFO - 2022-12-20 05:48:50 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:50 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:50 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:50 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:50 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:50 --> Total execution time: 0.1712
INFO - 2022-12-20 05:48:50 --> Config Class Initialized
INFO - 2022-12-20 05:48:50 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:50 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:50 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:50 --> URI Class Initialized
INFO - 2022-12-20 05:48:50 --> Router Class Initialized
INFO - 2022-12-20 05:48:50 --> Output Class Initialized
INFO - 2022-12-20 05:48:50 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:50 --> Input Class Initialized
INFO - 2022-12-20 05:48:50 --> Language Class Initialized
INFO - 2022-12-20 05:48:50 --> Loader Class Initialized
INFO - 2022-12-20 05:48:50 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:50 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:50 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:50 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:50 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:50 --> Total execution time: 0.1311
INFO - 2022-12-20 05:48:52 --> Config Class Initialized
INFO - 2022-12-20 05:48:52 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:52 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:52 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:52 --> URI Class Initialized
INFO - 2022-12-20 05:48:52 --> Router Class Initialized
INFO - 2022-12-20 05:48:52 --> Output Class Initialized
INFO - 2022-12-20 05:48:52 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:52 --> Input Class Initialized
INFO - 2022-12-20 05:48:52 --> Language Class Initialized
INFO - 2022-12-20 05:48:52 --> Loader Class Initialized
INFO - 2022-12-20 05:48:52 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:52 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:52 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:53 --> Total execution time: 0.9847
INFO - 2022-12-20 05:48:53 --> Config Class Initialized
INFO - 2022-12-20 05:48:53 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:53 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:53 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:53 --> URI Class Initialized
INFO - 2022-12-20 05:48:53 --> Router Class Initialized
INFO - 2022-12-20 05:48:53 --> Output Class Initialized
INFO - 2022-12-20 05:48:53 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:53 --> Input Class Initialized
INFO - 2022-12-20 05:48:53 --> Language Class Initialized
INFO - 2022-12-20 05:48:53 --> Loader Class Initialized
INFO - 2022-12-20 05:48:53 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:53 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:53 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:48:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:53 --> Total execution time: 0.1686
INFO - 2022-12-20 05:48:58 --> Config Class Initialized
INFO - 2022-12-20 05:48:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:58 --> URI Class Initialized
INFO - 2022-12-20 05:48:58 --> Router Class Initialized
INFO - 2022-12-20 05:48:58 --> Output Class Initialized
INFO - 2022-12-20 05:48:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:58 --> Input Class Initialized
INFO - 2022-12-20 05:48:58 --> Language Class Initialized
INFO - 2022-12-20 05:48:58 --> Loader Class Initialized
INFO - 2022-12-20 05:48:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:58 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:58 --> Total execution time: 0.1482
INFO - 2022-12-20 05:48:58 --> Config Class Initialized
INFO - 2022-12-20 05:48:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:48:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:48:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:48:58 --> URI Class Initialized
INFO - 2022-12-20 05:48:58 --> Router Class Initialized
INFO - 2022-12-20 05:48:58 --> Output Class Initialized
INFO - 2022-12-20 05:48:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:48:58 --> Input Class Initialized
INFO - 2022-12-20 05:48:58 --> Language Class Initialized
INFO - 2022-12-20 05:48:58 --> Loader Class Initialized
INFO - 2022-12-20 05:48:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:48:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:48:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:48:58 --> Model "Login_model" initialized
INFO - 2022-12-20 05:48:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:48:58 --> Total execution time: 0.1481
INFO - 2022-12-20 05:49:01 --> Config Class Initialized
INFO - 2022-12-20 05:49:01 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:01 --> URI Class Initialized
INFO - 2022-12-20 05:49:01 --> Router Class Initialized
INFO - 2022-12-20 05:49:01 --> Output Class Initialized
INFO - 2022-12-20 05:49:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:01 --> Input Class Initialized
INFO - 2022-12-20 05:49:01 --> Language Class Initialized
INFO - 2022-12-20 05:49:01 --> Loader Class Initialized
INFO - 2022-12-20 05:49:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:01 --> Total execution time: 0.0953
INFO - 2022-12-20 05:49:01 --> Config Class Initialized
INFO - 2022-12-20 05:49:01 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:01 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:01 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:01 --> URI Class Initialized
INFO - 2022-12-20 05:49:01 --> Router Class Initialized
INFO - 2022-12-20 05:49:01 --> Output Class Initialized
INFO - 2022-12-20 05:49:01 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:01 --> Input Class Initialized
INFO - 2022-12-20 05:49:01 --> Language Class Initialized
INFO - 2022-12-20 05:49:01 --> Loader Class Initialized
INFO - 2022-12-20 05:49:01 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:01 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:01 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:01 --> Total execution time: 0.1146
INFO - 2022-12-20 05:49:07 --> Config Class Initialized
INFO - 2022-12-20 05:49:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:07 --> URI Class Initialized
INFO - 2022-12-20 05:49:07 --> Router Class Initialized
INFO - 2022-12-20 05:49:07 --> Output Class Initialized
INFO - 2022-12-20 05:49:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:07 --> Input Class Initialized
INFO - 2022-12-20 05:49:07 --> Language Class Initialized
INFO - 2022-12-20 05:49:07 --> Loader Class Initialized
INFO - 2022-12-20 05:49:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:07 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:07 --> Total execution time: 0.1334
INFO - 2022-12-20 05:49:07 --> Config Class Initialized
INFO - 2022-12-20 05:49:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:07 --> URI Class Initialized
INFO - 2022-12-20 05:49:07 --> Router Class Initialized
INFO - 2022-12-20 05:49:07 --> Output Class Initialized
INFO - 2022-12-20 05:49:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:07 --> Input Class Initialized
INFO - 2022-12-20 05:49:07 --> Language Class Initialized
INFO - 2022-12-20 05:49:07 --> Loader Class Initialized
INFO - 2022-12-20 05:49:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:07 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:07 --> Total execution time: 0.1404
INFO - 2022-12-20 05:49:10 --> Config Class Initialized
INFO - 2022-12-20 05:49:10 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:10 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:10 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:10 --> URI Class Initialized
INFO - 2022-12-20 05:49:10 --> Router Class Initialized
INFO - 2022-12-20 05:49:10 --> Output Class Initialized
INFO - 2022-12-20 05:49:10 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:10 --> Input Class Initialized
INFO - 2022-12-20 05:49:10 --> Language Class Initialized
INFO - 2022-12-20 05:49:10 --> Loader Class Initialized
INFO - 2022-12-20 05:49:10 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:10 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:10 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:10 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:10 --> Total execution time: 0.1496
INFO - 2022-12-20 05:49:10 --> Config Class Initialized
INFO - 2022-12-20 05:49:10 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:10 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:10 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:10 --> URI Class Initialized
INFO - 2022-12-20 05:49:10 --> Router Class Initialized
INFO - 2022-12-20 05:49:10 --> Output Class Initialized
INFO - 2022-12-20 05:49:10 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:10 --> Input Class Initialized
INFO - 2022-12-20 05:49:10 --> Language Class Initialized
INFO - 2022-12-20 05:49:10 --> Loader Class Initialized
INFO - 2022-12-20 05:49:10 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:10 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:10 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:10 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:10 --> Total execution time: 0.1326
INFO - 2022-12-20 05:49:12 --> Config Class Initialized
INFO - 2022-12-20 05:49:12 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:12 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:12 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:12 --> URI Class Initialized
INFO - 2022-12-20 05:49:12 --> Router Class Initialized
INFO - 2022-12-20 05:49:12 --> Output Class Initialized
INFO - 2022-12-20 05:49:12 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:12 --> Input Class Initialized
INFO - 2022-12-20 05:49:12 --> Language Class Initialized
INFO - 2022-12-20 05:49:12 --> Loader Class Initialized
INFO - 2022-12-20 05:49:12 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:12 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:12 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:12 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:12 --> Total execution time: 0.1422
INFO - 2022-12-20 05:49:12 --> Config Class Initialized
INFO - 2022-12-20 05:49:12 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:12 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:12 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:12 --> URI Class Initialized
INFO - 2022-12-20 05:49:12 --> Router Class Initialized
INFO - 2022-12-20 05:49:12 --> Output Class Initialized
INFO - 2022-12-20 05:49:12 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:12 --> Input Class Initialized
INFO - 2022-12-20 05:49:12 --> Language Class Initialized
INFO - 2022-12-20 05:49:12 --> Loader Class Initialized
INFO - 2022-12-20 05:49:12 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:12 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:12 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:12 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:12 --> Total execution time: 0.1408
INFO - 2022-12-20 05:49:15 --> Config Class Initialized
INFO - 2022-12-20 05:49:15 --> Config Class Initialized
INFO - 2022-12-20 05:49:15 --> Hooks Class Initialized
INFO - 2022-12-20 05:49:15 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 05:49:15 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:15 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:15 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:15 --> URI Class Initialized
INFO - 2022-12-20 05:49:15 --> URI Class Initialized
INFO - 2022-12-20 05:49:15 --> Router Class Initialized
INFO - 2022-12-20 05:49:15 --> Router Class Initialized
INFO - 2022-12-20 05:49:15 --> Output Class Initialized
INFO - 2022-12-20 05:49:15 --> Output Class Initialized
INFO - 2022-12-20 05:49:15 --> Security Class Initialized
INFO - 2022-12-20 05:49:15 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:15 --> Input Class Initialized
INFO - 2022-12-20 05:49:15 --> Input Class Initialized
INFO - 2022-12-20 05:49:15 --> Language Class Initialized
INFO - 2022-12-20 05:49:15 --> Language Class Initialized
INFO - 2022-12-20 05:49:15 --> Loader Class Initialized
INFO - 2022-12-20 05:49:15 --> Loader Class Initialized
INFO - 2022-12-20 05:49:15 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:15 --> Final output sent to browser
INFO - 2022-12-20 05:49:15 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Total execution time: 0.1642
DEBUG - 2022-12-20 05:49:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:15 --> Config Class Initialized
INFO - 2022-12-20 05:49:15 --> Hooks Class Initialized
INFO - 2022-12-20 05:49:15 --> Database Driver Class Initialized
DEBUG - 2022-12-20 05:49:15 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:15 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:15 --> URI Class Initialized
INFO - 2022-12-20 05:49:15 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:15 --> Router Class Initialized
INFO - 2022-12-20 05:49:15 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:15 --> Total execution time: 0.2481
INFO - 2022-12-20 05:49:15 --> Output Class Initialized
INFO - 2022-12-20 05:49:15 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:15 --> Input Class Initialized
INFO - 2022-12-20 05:49:15 --> Config Class Initialized
INFO - 2022-12-20 05:49:15 --> Hooks Class Initialized
INFO - 2022-12-20 05:49:15 --> Language Class Initialized
DEBUG - 2022-12-20 05:49:15 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:15 --> Loader Class Initialized
INFO - 2022-12-20 05:49:15 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:15 --> Controller Class Initialized
INFO - 2022-12-20 05:49:15 --> URI Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:15 --> Router Class Initialized
INFO - 2022-12-20 05:49:15 --> Output Class Initialized
INFO - 2022-12-20 05:49:15 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:15 --> Security Class Initialized
INFO - 2022-12-20 05:49:15 --> Model "Login_model" initialized
DEBUG - 2022-12-20 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:15 --> Input Class Initialized
INFO - 2022-12-20 05:49:15 --> Language Class Initialized
INFO - 2022-12-20 05:49:15 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:15 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:15 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:15 --> Total execution time: 0.2424
INFO - 2022-12-20 05:49:15 --> Loader Class Initialized
INFO - 2022-12-20 05:49:15 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:15 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:15 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:15 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:16 --> Total execution time: 0.2186
INFO - 2022-12-20 05:49:18 --> Config Class Initialized
INFO - 2022-12-20 05:49:18 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:18 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:18 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:18 --> URI Class Initialized
INFO - 2022-12-20 05:49:18 --> Router Class Initialized
INFO - 2022-12-20 05:49:18 --> Output Class Initialized
INFO - 2022-12-20 05:49:18 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:18 --> Input Class Initialized
INFO - 2022-12-20 05:49:18 --> Language Class Initialized
INFO - 2022-12-20 05:49:18 --> Loader Class Initialized
INFO - 2022-12-20 05:49:18 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:18 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:18 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:18 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:18 --> Model "Login_model" initialized
INFO - 2022-12-20 05:49:18 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:18 --> Total execution time: 0.2161
INFO - 2022-12-20 05:49:18 --> Config Class Initialized
INFO - 2022-12-20 05:49:18 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:18 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:18 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:18 --> URI Class Initialized
INFO - 2022-12-20 05:49:18 --> Router Class Initialized
INFO - 2022-12-20 05:49:18 --> Output Class Initialized
INFO - 2022-12-20 05:49:18 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:18 --> Input Class Initialized
INFO - 2022-12-20 05:49:18 --> Language Class Initialized
INFO - 2022-12-20 05:49:18 --> Loader Class Initialized
INFO - 2022-12-20 05:49:18 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:18 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:18 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:18 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:18 --> Model "Login_model" initialized
INFO - 2022-12-20 05:49:18 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:18 --> Total execution time: 0.2206
INFO - 2022-12-20 05:49:21 --> Config Class Initialized
INFO - 2022-12-20 05:49:21 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:21 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:21 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:21 --> URI Class Initialized
INFO - 2022-12-20 05:49:21 --> Router Class Initialized
INFO - 2022-12-20 05:49:21 --> Output Class Initialized
INFO - 2022-12-20 05:49:21 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:21 --> Input Class Initialized
INFO - 2022-12-20 05:49:21 --> Language Class Initialized
INFO - 2022-12-20 05:49:21 --> Loader Class Initialized
INFO - 2022-12-20 05:49:21 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:21 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:21 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:21 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:21 --> Total execution time: 0.1501
INFO - 2022-12-20 05:49:21 --> Config Class Initialized
INFO - 2022-12-20 05:49:21 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:21 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:21 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:21 --> URI Class Initialized
INFO - 2022-12-20 05:49:21 --> Router Class Initialized
INFO - 2022-12-20 05:49:21 --> Output Class Initialized
INFO - 2022-12-20 05:49:21 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:21 --> Input Class Initialized
INFO - 2022-12-20 05:49:21 --> Language Class Initialized
INFO - 2022-12-20 05:49:21 --> Loader Class Initialized
INFO - 2022-12-20 05:49:21 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:21 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:21 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:21 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:21 --> Total execution time: 0.1400
INFO - 2022-12-20 05:49:23 --> Config Class Initialized
INFO - 2022-12-20 05:49:23 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:23 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:23 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:23 --> URI Class Initialized
INFO - 2022-12-20 05:49:23 --> Router Class Initialized
INFO - 2022-12-20 05:49:23 --> Output Class Initialized
INFO - 2022-12-20 05:49:23 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:23 --> Input Class Initialized
INFO - 2022-12-20 05:49:23 --> Language Class Initialized
INFO - 2022-12-20 05:49:23 --> Loader Class Initialized
INFO - 2022-12-20 05:49:23 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:23 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:23 --> Total execution time: 0.0943
INFO - 2022-12-20 05:49:23 --> Config Class Initialized
INFO - 2022-12-20 05:49:23 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:23 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:23 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:23 --> URI Class Initialized
INFO - 2022-12-20 05:49:23 --> Router Class Initialized
INFO - 2022-12-20 05:49:23 --> Output Class Initialized
INFO - 2022-12-20 05:49:23 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:23 --> Input Class Initialized
INFO - 2022-12-20 05:49:23 --> Language Class Initialized
INFO - 2022-12-20 05:49:23 --> Loader Class Initialized
INFO - 2022-12-20 05:49:23 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:23 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:23 --> Model "Login_model" initialized
INFO - 2022-12-20 05:49:23 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:23 --> Model "Cluster_model" initialized
ERROR - 2022-12-20 05:49:23 --> Query error:  - Invalid query: 
INFO - 2022-12-20 05:49:23 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-20 05:49:26 --> Config Class Initialized
INFO - 2022-12-20 05:49:26 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:26 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:26 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:26 --> URI Class Initialized
INFO - 2022-12-20 05:49:26 --> Router Class Initialized
INFO - 2022-12-20 05:49:26 --> Output Class Initialized
INFO - 2022-12-20 05:49:26 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:26 --> Input Class Initialized
INFO - 2022-12-20 05:49:26 --> Language Class Initialized
INFO - 2022-12-20 05:49:26 --> Loader Class Initialized
INFO - 2022-12-20 05:49:26 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:26 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:26 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:26 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:26 --> Model "Login_model" initialized
INFO - 2022-12-20 05:49:26 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:26 --> Total execution time: 0.2267
INFO - 2022-12-20 05:49:26 --> Config Class Initialized
INFO - 2022-12-20 05:49:26 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:26 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:26 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:26 --> URI Class Initialized
INFO - 2022-12-20 05:49:26 --> Router Class Initialized
INFO - 2022-12-20 05:49:26 --> Output Class Initialized
INFO - 2022-12-20 05:49:26 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:26 --> Input Class Initialized
INFO - 2022-12-20 05:49:26 --> Language Class Initialized
INFO - 2022-12-20 05:49:26 --> Loader Class Initialized
INFO - 2022-12-20 05:49:26 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:26 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:26 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:26 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:26 --> Model "Login_model" initialized
INFO - 2022-12-20 05:49:26 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:26 --> Total execution time: 0.2099
INFO - 2022-12-20 05:49:35 --> Config Class Initialized
INFO - 2022-12-20 05:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:35 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:35 --> URI Class Initialized
INFO - 2022-12-20 05:49:35 --> Router Class Initialized
INFO - 2022-12-20 05:49:35 --> Output Class Initialized
INFO - 2022-12-20 05:49:35 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:35 --> Input Class Initialized
INFO - 2022-12-20 05:49:35 --> Language Class Initialized
INFO - 2022-12-20 05:49:35 --> Loader Class Initialized
INFO - 2022-12-20 05:49:35 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:35 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:35 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:35 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:35 --> Total execution time: 0.1424
INFO - 2022-12-20 05:49:35 --> Config Class Initialized
INFO - 2022-12-20 05:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:35 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:35 --> URI Class Initialized
INFO - 2022-12-20 05:49:35 --> Router Class Initialized
INFO - 2022-12-20 05:49:35 --> Output Class Initialized
INFO - 2022-12-20 05:49:35 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:35 --> Input Class Initialized
INFO - 2022-12-20 05:49:35 --> Language Class Initialized
INFO - 2022-12-20 05:49:35 --> Loader Class Initialized
INFO - 2022-12-20 05:49:35 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:35 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:35 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:35 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:35 --> Total execution time: 0.1417
INFO - 2022-12-20 05:49:41 --> Config Class Initialized
INFO - 2022-12-20 05:49:41 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:41 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:41 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:41 --> URI Class Initialized
INFO - 2022-12-20 05:49:41 --> Router Class Initialized
INFO - 2022-12-20 05:49:41 --> Output Class Initialized
INFO - 2022-12-20 05:49:41 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:41 --> Input Class Initialized
INFO - 2022-12-20 05:49:41 --> Language Class Initialized
INFO - 2022-12-20 05:49:41 --> Loader Class Initialized
INFO - 2022-12-20 05:49:41 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:41 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:41 --> Total execution time: 0.1002
INFO - 2022-12-20 05:49:41 --> Config Class Initialized
INFO - 2022-12-20 05:49:41 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:41 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:41 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:41 --> URI Class Initialized
INFO - 2022-12-20 05:49:41 --> Router Class Initialized
INFO - 2022-12-20 05:49:41 --> Output Class Initialized
INFO - 2022-12-20 05:49:41 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:41 --> Input Class Initialized
INFO - 2022-12-20 05:49:41 --> Language Class Initialized
INFO - 2022-12-20 05:49:41 --> Loader Class Initialized
INFO - 2022-12-20 05:49:41 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:41 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:41 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:41 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:41 --> Total execution time: 0.1270
INFO - 2022-12-20 05:49:45 --> Config Class Initialized
INFO - 2022-12-20 05:49:45 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:45 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:45 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:45 --> URI Class Initialized
INFO - 2022-12-20 05:49:45 --> Router Class Initialized
INFO - 2022-12-20 05:49:45 --> Output Class Initialized
INFO - 2022-12-20 05:49:45 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:45 --> Input Class Initialized
INFO - 2022-12-20 05:49:45 --> Language Class Initialized
INFO - 2022-12-20 05:49:45 --> Loader Class Initialized
INFO - 2022-12-20 05:49:45 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:45 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:45 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:45 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:45 --> Total execution time: 0.1381
INFO - 2022-12-20 05:49:45 --> Config Class Initialized
INFO - 2022-12-20 05:49:45 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:49:45 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:49:45 --> Utf8 Class Initialized
INFO - 2022-12-20 05:49:45 --> URI Class Initialized
INFO - 2022-12-20 05:49:45 --> Router Class Initialized
INFO - 2022-12-20 05:49:45 --> Output Class Initialized
INFO - 2022-12-20 05:49:45 --> Security Class Initialized
DEBUG - 2022-12-20 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:49:45 --> Input Class Initialized
INFO - 2022-12-20 05:49:45 --> Language Class Initialized
INFO - 2022-12-20 05:49:45 --> Loader Class Initialized
INFO - 2022-12-20 05:49:45 --> Controller Class Initialized
DEBUG - 2022-12-20 05:49:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:49:45 --> Database Driver Class Initialized
INFO - 2022-12-20 05:49:45 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:49:45 --> Final output sent to browser
DEBUG - 2022-12-20 05:49:45 --> Total execution time: 0.1244
INFO - 2022-12-20 05:50:16 --> Config Class Initialized
INFO - 2022-12-20 05:50:16 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:16 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:16 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:16 --> URI Class Initialized
INFO - 2022-12-20 05:50:16 --> Router Class Initialized
INFO - 2022-12-20 05:50:16 --> Output Class Initialized
INFO - 2022-12-20 05:50:16 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:16 --> Input Class Initialized
INFO - 2022-12-20 05:50:16 --> Language Class Initialized
INFO - 2022-12-20 05:50:16 --> Loader Class Initialized
INFO - 2022-12-20 05:50:16 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:16 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:16 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:16 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:16 --> Model "Login_model" initialized
INFO - 2022-12-20 05:50:16 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:16 --> Total execution time: 0.2080
INFO - 2022-12-20 05:50:16 --> Config Class Initialized
INFO - 2022-12-20 05:50:16 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:16 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:16 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:16 --> URI Class Initialized
INFO - 2022-12-20 05:50:16 --> Router Class Initialized
INFO - 2022-12-20 05:50:16 --> Output Class Initialized
INFO - 2022-12-20 05:50:16 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:16 --> Input Class Initialized
INFO - 2022-12-20 05:50:16 --> Language Class Initialized
INFO - 2022-12-20 05:50:16 --> Loader Class Initialized
INFO - 2022-12-20 05:50:16 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:16 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:16 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:16 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:16 --> Model "Login_model" initialized
INFO - 2022-12-20 05:50:16 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:16 --> Total execution time: 0.2102
INFO - 2022-12-20 05:50:28 --> Config Class Initialized
INFO - 2022-12-20 05:50:28 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:28 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:28 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:28 --> URI Class Initialized
INFO - 2022-12-20 05:50:28 --> Router Class Initialized
INFO - 2022-12-20 05:50:28 --> Output Class Initialized
INFO - 2022-12-20 05:50:28 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:28 --> Input Class Initialized
INFO - 2022-12-20 05:50:28 --> Language Class Initialized
INFO - 2022-12-20 05:50:28 --> Loader Class Initialized
INFO - 2022-12-20 05:50:28 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:28 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:28 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:28 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:28 --> Total execution time: 0.1602
INFO - 2022-12-20 05:50:28 --> Config Class Initialized
INFO - 2022-12-20 05:50:28 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:28 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:28 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:28 --> URI Class Initialized
INFO - 2022-12-20 05:50:28 --> Router Class Initialized
INFO - 2022-12-20 05:50:28 --> Output Class Initialized
INFO - 2022-12-20 05:50:28 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:28 --> Input Class Initialized
INFO - 2022-12-20 05:50:28 --> Language Class Initialized
INFO - 2022-12-20 05:50:28 --> Loader Class Initialized
INFO - 2022-12-20 05:50:28 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:28 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:28 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:28 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:28 --> Total execution time: 0.1461
INFO - 2022-12-20 05:50:29 --> Config Class Initialized
INFO - 2022-12-20 05:50:29 --> Config Class Initialized
INFO - 2022-12-20 05:50:29 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:29 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 05:50:29 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:29 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:29 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:29 --> URI Class Initialized
INFO - 2022-12-20 05:50:29 --> URI Class Initialized
INFO - 2022-12-20 05:50:29 --> Router Class Initialized
INFO - 2022-12-20 05:50:29 --> Router Class Initialized
INFO - 2022-12-20 05:50:29 --> Output Class Initialized
INFO - 2022-12-20 05:50:29 --> Output Class Initialized
INFO - 2022-12-20 05:50:29 --> Security Class Initialized
INFO - 2022-12-20 05:50:29 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 05:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:30 --> Input Class Initialized
INFO - 2022-12-20 05:50:30 --> Input Class Initialized
INFO - 2022-12-20 05:50:30 --> Language Class Initialized
INFO - 2022-12-20 05:50:30 --> Language Class Initialized
INFO - 2022-12-20 05:50:30 --> Loader Class Initialized
INFO - 2022-12-20 05:50:30 --> Loader Class Initialized
INFO - 2022-12-20 05:50:30 --> Controller Class Initialized
INFO - 2022-12-20 05:50:30 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-20 05:50:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:30 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:30 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:30 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:30 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:30 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:30 --> Total execution time: 0.2853
INFO - 2022-12-20 05:50:30 --> Config Class Initialized
INFO - 2022-12-20 05:50:30 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:30 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:30 --> Config Class Initialized
INFO - 2022-12-20 05:50:30 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:30 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:30 --> URI Class Initialized
DEBUG - 2022-12-20 05:50:30 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:30 --> Router Class Initialized
INFO - 2022-12-20 05:50:30 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:30 --> URI Class Initialized
INFO - 2022-12-20 05:50:30 --> Output Class Initialized
INFO - 2022-12-20 05:50:30 --> Security Class Initialized
INFO - 2022-12-20 05:50:30 --> Router Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:30 --> Output Class Initialized
INFO - 2022-12-20 05:50:30 --> Input Class Initialized
INFO - 2022-12-20 05:50:30 --> Language Class Initialized
INFO - 2022-12-20 05:50:30 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:30 --> Loader Class Initialized
INFO - 2022-12-20 05:50:30 --> Input Class Initialized
INFO - 2022-12-20 05:50:30 --> Controller Class Initialized
INFO - 2022-12-20 05:50:30 --> Language Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:30 --> Loader Class Initialized
INFO - 2022-12-20 05:50:30 --> Controller Class Initialized
INFO - 2022-12-20 05:50:30 --> Database Driver Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:30 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:30 --> Final output sent to browser
INFO - 2022-12-20 05:50:30 --> Database Driver Class Initialized
DEBUG - 2022-12-20 05:50:30 --> Total execution time: 0.2032
INFO - 2022-12-20 05:50:30 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:40 --> Config Class Initialized
INFO - 2022-12-20 05:50:40 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:40 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:40 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:40 --> URI Class Initialized
INFO - 2022-12-20 05:50:40 --> Router Class Initialized
INFO - 2022-12-20 05:50:40 --> Output Class Initialized
INFO - 2022-12-20 05:50:40 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:40 --> Input Class Initialized
INFO - 2022-12-20 05:50:40 --> Language Class Initialized
INFO - 2022-12-20 05:50:40 --> Loader Class Initialized
INFO - 2022-12-20 05:50:40 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:40 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:40 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:40 --> Config Class Initialized
INFO - 2022-12-20 05:50:40 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:40 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:40 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:40 --> URI Class Initialized
INFO - 2022-12-20 05:50:40 --> Router Class Initialized
INFO - 2022-12-20 05:50:40 --> Output Class Initialized
INFO - 2022-12-20 05:50:40 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:40 --> Input Class Initialized
INFO - 2022-12-20 05:50:40 --> Language Class Initialized
INFO - 2022-12-20 05:50:40 --> Loader Class Initialized
INFO - 2022-12-20 05:50:40 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:40 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:40 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:41 --> Config Class Initialized
INFO - 2022-12-20 05:50:41 --> Config Class Initialized
INFO - 2022-12-20 05:50:41 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:41 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 05:50:41 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:41 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:41 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:41 --> URI Class Initialized
INFO - 2022-12-20 05:50:41 --> URI Class Initialized
INFO - 2022-12-20 05:50:41 --> Router Class Initialized
INFO - 2022-12-20 05:50:41 --> Router Class Initialized
INFO - 2022-12-20 05:50:41 --> Output Class Initialized
INFO - 2022-12-20 05:50:41 --> Output Class Initialized
INFO - 2022-12-20 05:50:41 --> Security Class Initialized
INFO - 2022-12-20 05:50:41 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:41 --> Input Class Initialized
INFO - 2022-12-20 05:50:41 --> Input Class Initialized
INFO - 2022-12-20 05:50:41 --> Language Class Initialized
INFO - 2022-12-20 05:50:41 --> Language Class Initialized
INFO - 2022-12-20 05:50:41 --> Loader Class Initialized
INFO - 2022-12-20 05:50:41 --> Loader Class Initialized
INFO - 2022-12-20 05:50:41 --> Controller Class Initialized
INFO - 2022-12-20 05:50:41 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-20 05:50:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:41 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:41 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:41 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:41 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:41 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:41 --> Total execution time: 0.2429
INFO - 2022-12-20 05:50:41 --> Config Class Initialized
INFO - 2022-12-20 05:50:41 --> Config Class Initialized
INFO - 2022-12-20 05:50:41 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:41 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:41 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:41 --> Utf8 Class Initialized
DEBUG - 2022-12-20 05:50:41 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:41 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:41 --> URI Class Initialized
INFO - 2022-12-20 05:50:41 --> URI Class Initialized
INFO - 2022-12-20 05:50:41 --> Router Class Initialized
INFO - 2022-12-20 05:50:41 --> Router Class Initialized
INFO - 2022-12-20 05:50:41 --> Output Class Initialized
INFO - 2022-12-20 05:50:41 --> Output Class Initialized
INFO - 2022-12-20 05:50:41 --> Security Class Initialized
INFO - 2022-12-20 05:50:41 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:41 --> Input Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:41 --> Language Class Initialized
INFO - 2022-12-20 05:50:41 --> Input Class Initialized
INFO - 2022-12-20 05:50:41 --> Language Class Initialized
INFO - 2022-12-20 05:50:41 --> Loader Class Initialized
INFO - 2022-12-20 05:50:41 --> Controller Class Initialized
INFO - 2022-12-20 05:50:41 --> Loader Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:41 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:41 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:41 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:41 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:41 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:41 --> Total execution time: 0.1988
INFO - 2022-12-20 05:50:41 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:42 --> Config Class Initialized
INFO - 2022-12-20 05:50:42 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:42 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:42 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:42 --> URI Class Initialized
INFO - 2022-12-20 05:50:42 --> Router Class Initialized
INFO - 2022-12-20 05:50:42 --> Output Class Initialized
INFO - 2022-12-20 05:50:42 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:42 --> Input Class Initialized
INFO - 2022-12-20 05:50:42 --> Language Class Initialized
INFO - 2022-12-20 05:50:42 --> Loader Class Initialized
INFO - 2022-12-20 05:50:42 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:42 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:42 --> Total execution time: 0.0989
INFO - 2022-12-20 05:50:42 --> Config Class Initialized
INFO - 2022-12-20 05:50:42 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:42 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:42 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:42 --> URI Class Initialized
INFO - 2022-12-20 05:50:42 --> Router Class Initialized
INFO - 2022-12-20 05:50:42 --> Output Class Initialized
INFO - 2022-12-20 05:50:42 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:42 --> Input Class Initialized
INFO - 2022-12-20 05:50:42 --> Language Class Initialized
INFO - 2022-12-20 05:50:42 --> Loader Class Initialized
INFO - 2022-12-20 05:50:42 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:42 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:42 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:42 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:42 --> Total execution time: 0.1480
INFO - 2022-12-20 05:50:43 --> Config Class Initialized
INFO - 2022-12-20 05:50:43 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:43 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:43 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:43 --> URI Class Initialized
INFO - 2022-12-20 05:50:43 --> Router Class Initialized
INFO - 2022-12-20 05:50:43 --> Output Class Initialized
INFO - 2022-12-20 05:50:43 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:43 --> Input Class Initialized
INFO - 2022-12-20 05:50:43 --> Language Class Initialized
INFO - 2022-12-20 05:50:43 --> Loader Class Initialized
INFO - 2022-12-20 05:50:43 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:43 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:43 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:43 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:43 --> Total execution time: 0.1366
INFO - 2022-12-20 05:50:45 --> Config Class Initialized
INFO - 2022-12-20 05:50:45 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:45 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:45 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:45 --> URI Class Initialized
INFO - 2022-12-20 05:50:45 --> Router Class Initialized
INFO - 2022-12-20 05:50:45 --> Output Class Initialized
INFO - 2022-12-20 05:50:45 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:45 --> Input Class Initialized
INFO - 2022-12-20 05:50:45 --> Language Class Initialized
INFO - 2022-12-20 05:50:45 --> Loader Class Initialized
INFO - 2022-12-20 05:50:45 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:45 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:45 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:45 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:45 --> Total execution time: 0.1366
INFO - 2022-12-20 05:50:46 --> Config Class Initialized
INFO - 2022-12-20 05:50:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:46 --> URI Class Initialized
INFO - 2022-12-20 05:50:46 --> Router Class Initialized
INFO - 2022-12-20 05:50:46 --> Output Class Initialized
INFO - 2022-12-20 05:50:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:46 --> Input Class Initialized
INFO - 2022-12-20 05:50:46 --> Language Class Initialized
INFO - 2022-12-20 05:50:46 --> Loader Class Initialized
INFO - 2022-12-20 05:50:46 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:46 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:46 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:46 --> Total execution time: 0.1494
INFO - 2022-12-20 05:50:46 --> Config Class Initialized
INFO - 2022-12-20 05:50:46 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:46 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:46 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:46 --> URI Class Initialized
INFO - 2022-12-20 05:50:46 --> Router Class Initialized
INFO - 2022-12-20 05:50:46 --> Output Class Initialized
INFO - 2022-12-20 05:50:46 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:46 --> Input Class Initialized
INFO - 2022-12-20 05:50:46 --> Language Class Initialized
INFO - 2022-12-20 05:50:46 --> Loader Class Initialized
INFO - 2022-12-20 05:50:46 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:46 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:46 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:46 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:46 --> Total execution time: 0.1498
INFO - 2022-12-20 05:50:47 --> Config Class Initialized
INFO - 2022-12-20 05:50:47 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:47 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:47 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:47 --> URI Class Initialized
INFO - 2022-12-20 05:50:47 --> Router Class Initialized
INFO - 2022-12-20 05:50:47 --> Output Class Initialized
INFO - 2022-12-20 05:50:47 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:47 --> Input Class Initialized
INFO - 2022-12-20 05:50:47 --> Language Class Initialized
INFO - 2022-12-20 05:50:47 --> Loader Class Initialized
INFO - 2022-12-20 05:50:47 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:47 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:47 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:47 --> Total execution time: 0.1579
INFO - 2022-12-20 05:50:47 --> Config Class Initialized
INFO - 2022-12-20 05:50:47 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:47 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:47 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:47 --> URI Class Initialized
INFO - 2022-12-20 05:50:47 --> Router Class Initialized
INFO - 2022-12-20 05:50:47 --> Output Class Initialized
INFO - 2022-12-20 05:50:47 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:47 --> Input Class Initialized
INFO - 2022-12-20 05:50:47 --> Language Class Initialized
INFO - 2022-12-20 05:50:47 --> Loader Class Initialized
INFO - 2022-12-20 05:50:47 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:47 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:47 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:47 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:47 --> Total execution time: 0.1534
INFO - 2022-12-20 05:50:52 --> Config Class Initialized
INFO - 2022-12-20 05:50:52 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:52 --> Config Class Initialized
INFO - 2022-12-20 05:50:52 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:52 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:52 --> Utf8 Class Initialized
DEBUG - 2022-12-20 05:50:52 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:52 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:52 --> URI Class Initialized
INFO - 2022-12-20 05:50:52 --> URI Class Initialized
INFO - 2022-12-20 05:50:52 --> Router Class Initialized
INFO - 2022-12-20 05:50:52 --> Router Class Initialized
INFO - 2022-12-20 05:50:52 --> Output Class Initialized
INFO - 2022-12-20 05:50:52 --> Output Class Initialized
INFO - 2022-12-20 05:50:52 --> Security Class Initialized
INFO - 2022-12-20 05:50:52 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 05:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:52 --> Input Class Initialized
INFO - 2022-12-20 05:50:52 --> Input Class Initialized
INFO - 2022-12-20 05:50:52 --> Language Class Initialized
INFO - 2022-12-20 05:50:52 --> Language Class Initialized
INFO - 2022-12-20 05:50:53 --> Loader Class Initialized
INFO - 2022-12-20 05:50:53 --> Loader Class Initialized
INFO - 2022-12-20 05:50:53 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:53 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:53 --> Total execution time: 0.1781
INFO - 2022-12-20 05:50:53 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:53 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:53 --> Total execution time: 0.2172
INFO - 2022-12-20 05:50:53 --> Config Class Initialized
INFO - 2022-12-20 05:50:53 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:53 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:53 --> Config Class Initialized
INFO - 2022-12-20 05:50:53 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:53 --> Hooks Class Initialized
INFO - 2022-12-20 05:50:53 --> URI Class Initialized
DEBUG - 2022-12-20 05:50:53 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:53 --> Router Class Initialized
INFO - 2022-12-20 05:50:53 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:53 --> Output Class Initialized
INFO - 2022-12-20 05:50:53 --> URI Class Initialized
INFO - 2022-12-20 05:50:53 --> Security Class Initialized
INFO - 2022-12-20 05:50:53 --> Router Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:53 --> Input Class Initialized
INFO - 2022-12-20 05:50:53 --> Output Class Initialized
INFO - 2022-12-20 05:50:53 --> Language Class Initialized
INFO - 2022-12-20 05:50:53 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:53 --> Input Class Initialized
INFO - 2022-12-20 05:50:53 --> Language Class Initialized
INFO - 2022-12-20 05:50:53 --> Loader Class Initialized
INFO - 2022-12-20 05:50:53 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:53 --> Loader Class Initialized
INFO - 2022-12-20 05:50:53 --> Controller Class Initialized
INFO - 2022-12-20 05:50:53 --> Database Driver Class Initialized
DEBUG - 2022-12-20 05:50:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:53 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:53 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:53 --> Total execution time: 0.2234
INFO - 2022-12-20 05:50:53 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:53 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:53 --> Total execution time: 0.2229
INFO - 2022-12-20 05:50:54 --> Config Class Initialized
INFO - 2022-12-20 05:50:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:54 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:54 --> URI Class Initialized
INFO - 2022-12-20 05:50:54 --> Router Class Initialized
INFO - 2022-12-20 05:50:54 --> Output Class Initialized
INFO - 2022-12-20 05:50:54 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:54 --> Input Class Initialized
INFO - 2022-12-20 05:50:54 --> Language Class Initialized
INFO - 2022-12-20 05:50:54 --> Loader Class Initialized
INFO - 2022-12-20 05:50:54 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:54 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:54 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:54 --> Total execution time: 0.1526
INFO - 2022-12-20 05:50:54 --> Config Class Initialized
INFO - 2022-12-20 05:50:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:54 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:54 --> URI Class Initialized
INFO - 2022-12-20 05:50:54 --> Router Class Initialized
INFO - 2022-12-20 05:50:54 --> Output Class Initialized
INFO - 2022-12-20 05:50:54 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:54 --> Input Class Initialized
INFO - 2022-12-20 05:50:54 --> Language Class Initialized
INFO - 2022-12-20 05:50:54 --> Loader Class Initialized
INFO - 2022-12-20 05:50:54 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:54 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:54 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:54 --> Total execution time: 0.1505
INFO - 2022-12-20 05:50:58 --> Config Class Initialized
INFO - 2022-12-20 05:50:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:58 --> URI Class Initialized
INFO - 2022-12-20 05:50:58 --> Router Class Initialized
INFO - 2022-12-20 05:50:58 --> Output Class Initialized
INFO - 2022-12-20 05:50:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:58 --> Input Class Initialized
INFO - 2022-12-20 05:50:58 --> Language Class Initialized
INFO - 2022-12-20 05:50:58 --> Loader Class Initialized
INFO - 2022-12-20 05:50:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:58 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:58 --> Total execution time: 0.1433
INFO - 2022-12-20 05:50:58 --> Config Class Initialized
INFO - 2022-12-20 05:50:58 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:50:58 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:50:58 --> Utf8 Class Initialized
INFO - 2022-12-20 05:50:58 --> URI Class Initialized
INFO - 2022-12-20 05:50:58 --> Router Class Initialized
INFO - 2022-12-20 05:50:58 --> Output Class Initialized
INFO - 2022-12-20 05:50:58 --> Security Class Initialized
DEBUG - 2022-12-20 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:50:58 --> Input Class Initialized
INFO - 2022-12-20 05:50:58 --> Language Class Initialized
INFO - 2022-12-20 05:50:58 --> Loader Class Initialized
INFO - 2022-12-20 05:50:58 --> Controller Class Initialized
DEBUG - 2022-12-20 05:50:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:50:58 --> Database Driver Class Initialized
INFO - 2022-12-20 05:50:58 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:50:58 --> Final output sent to browser
DEBUG - 2022-12-20 05:50:58 --> Total execution time: 0.1453
INFO - 2022-12-20 05:51:00 --> Config Class Initialized
INFO - 2022-12-20 05:51:00 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:00 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:00 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:00 --> URI Class Initialized
INFO - 2022-12-20 05:51:00 --> Router Class Initialized
INFO - 2022-12-20 05:51:00 --> Output Class Initialized
INFO - 2022-12-20 05:51:00 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:00 --> Input Class Initialized
INFO - 2022-12-20 05:51:00 --> Language Class Initialized
INFO - 2022-12-20 05:51:00 --> Loader Class Initialized
INFO - 2022-12-20 05:51:00 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:00 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:00 --> Total execution time: 0.0920
INFO - 2022-12-20 05:51:00 --> Config Class Initialized
INFO - 2022-12-20 05:51:00 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:00 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:00 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:00 --> URI Class Initialized
INFO - 2022-12-20 05:51:00 --> Router Class Initialized
INFO - 2022-12-20 05:51:00 --> Output Class Initialized
INFO - 2022-12-20 05:51:00 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:00 --> Input Class Initialized
INFO - 2022-12-20 05:51:00 --> Language Class Initialized
INFO - 2022-12-20 05:51:00 --> Loader Class Initialized
INFO - 2022-12-20 05:51:00 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:00 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:00 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:00 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:00 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:01 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:01 --> Total execution time: 0.1575
INFO - 2022-12-20 05:51:02 --> Config Class Initialized
INFO - 2022-12-20 05:51:02 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:02 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:02 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:02 --> URI Class Initialized
INFO - 2022-12-20 05:51:02 --> Router Class Initialized
INFO - 2022-12-20 05:51:02 --> Output Class Initialized
INFO - 2022-12-20 05:51:02 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:02 --> Input Class Initialized
INFO - 2022-12-20 05:51:02 --> Language Class Initialized
INFO - 2022-12-20 05:51:02 --> Loader Class Initialized
INFO - 2022-12-20 05:51:02 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:02 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:02 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:02 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:02 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:02 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:02 --> Total execution time: 0.1317
INFO - 2022-12-20 05:51:03 --> Config Class Initialized
INFO - 2022-12-20 05:51:03 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:03 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:03 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:03 --> URI Class Initialized
INFO - 2022-12-20 05:51:03 --> Router Class Initialized
INFO - 2022-12-20 05:51:03 --> Output Class Initialized
INFO - 2022-12-20 05:51:03 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:03 --> Input Class Initialized
INFO - 2022-12-20 05:51:03 --> Language Class Initialized
INFO - 2022-12-20 05:51:03 --> Loader Class Initialized
INFO - 2022-12-20 05:51:03 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:03 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:03 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:03 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:03 --> Total execution time: 0.1676
INFO - 2022-12-20 05:51:03 --> Config Class Initialized
INFO - 2022-12-20 05:51:03 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:03 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:03 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:03 --> URI Class Initialized
INFO - 2022-12-20 05:51:03 --> Router Class Initialized
INFO - 2022-12-20 05:51:03 --> Output Class Initialized
INFO - 2022-12-20 05:51:03 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:03 --> Input Class Initialized
INFO - 2022-12-20 05:51:03 --> Language Class Initialized
INFO - 2022-12-20 05:51:03 --> Loader Class Initialized
INFO - 2022-12-20 05:51:03 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:03 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:03 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:03 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:03 --> Total execution time: 0.1380
INFO - 2022-12-20 05:51:03 --> Config Class Initialized
INFO - 2022-12-20 05:51:03 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:03 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:03 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:03 --> URI Class Initialized
INFO - 2022-12-20 05:51:03 --> Router Class Initialized
INFO - 2022-12-20 05:51:03 --> Output Class Initialized
INFO - 2022-12-20 05:51:03 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:03 --> Input Class Initialized
INFO - 2022-12-20 05:51:03 --> Language Class Initialized
INFO - 2022-12-20 05:51:03 --> Loader Class Initialized
INFO - 2022-12-20 05:51:03 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:03 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:03 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:03 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:03 --> Total execution time: 0.1269
INFO - 2022-12-20 05:51:03 --> Config Class Initialized
INFO - 2022-12-20 05:51:03 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:03 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:03 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:03 --> URI Class Initialized
INFO - 2022-12-20 05:51:03 --> Router Class Initialized
INFO - 2022-12-20 05:51:03 --> Output Class Initialized
INFO - 2022-12-20 05:51:03 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:03 --> Input Class Initialized
INFO - 2022-12-20 05:51:03 --> Language Class Initialized
INFO - 2022-12-20 05:51:03 --> Loader Class Initialized
INFO - 2022-12-20 05:51:03 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:03 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:03 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "PGsql_model" initialized
INFO - 2022-12-20 05:51:03 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:03 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:03 --> Total execution time: 0.1328
INFO - 2022-12-20 05:51:05 --> Config Class Initialized
INFO - 2022-12-20 05:51:05 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:05 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:05 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:05 --> URI Class Initialized
INFO - 2022-12-20 05:51:05 --> Router Class Initialized
INFO - 2022-12-20 05:51:05 --> Output Class Initialized
INFO - 2022-12-20 05:51:05 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:05 --> Input Class Initialized
INFO - 2022-12-20 05:51:05 --> Language Class Initialized
INFO - 2022-12-20 05:51:05 --> Loader Class Initialized
INFO - 2022-12-20 05:51:05 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:05 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:05 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:05 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:05 --> Total execution time: 0.1565
INFO - 2022-12-20 05:51:05 --> Config Class Initialized
INFO - 2022-12-20 05:51:05 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:05 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:05 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:05 --> URI Class Initialized
INFO - 2022-12-20 05:51:05 --> Router Class Initialized
INFO - 2022-12-20 05:51:05 --> Output Class Initialized
INFO - 2022-12-20 05:51:05 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:05 --> Input Class Initialized
INFO - 2022-12-20 05:51:05 --> Language Class Initialized
INFO - 2022-12-20 05:51:05 --> Loader Class Initialized
INFO - 2022-12-20 05:51:05 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:05 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:05 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:05 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:05 --> Total execution time: 0.1446
INFO - 2022-12-20 05:51:07 --> Config Class Initialized
INFO - 2022-12-20 05:51:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:07 --> URI Class Initialized
INFO - 2022-12-20 05:51:07 --> Router Class Initialized
INFO - 2022-12-20 05:51:07 --> Output Class Initialized
INFO - 2022-12-20 05:51:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:07 --> Input Class Initialized
INFO - 2022-12-20 05:51:07 --> Language Class Initialized
INFO - 2022-12-20 05:51:07 --> Loader Class Initialized
INFO - 2022-12-20 05:51:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:07 --> Total execution time: 0.0881
INFO - 2022-12-20 05:51:07 --> Config Class Initialized
INFO - 2022-12-20 05:51:07 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:07 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:07 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:07 --> URI Class Initialized
INFO - 2022-12-20 05:51:07 --> Router Class Initialized
INFO - 2022-12-20 05:51:07 --> Output Class Initialized
INFO - 2022-12-20 05:51:07 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:07 --> Input Class Initialized
INFO - 2022-12-20 05:51:07 --> Language Class Initialized
INFO - 2022-12-20 05:51:07 --> Loader Class Initialized
INFO - 2022-12-20 05:51:07 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:07 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:07 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:07 --> Model "Mysql_model" initialized
INFO - 2022-12-20 05:51:07 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:07 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:07 --> Total execution time: 0.1412
INFO - 2022-12-20 05:51:08 --> Config Class Initialized
INFO - 2022-12-20 05:51:08 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:08 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:08 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:08 --> URI Class Initialized
INFO - 2022-12-20 05:51:08 --> Router Class Initialized
INFO - 2022-12-20 05:51:08 --> Output Class Initialized
INFO - 2022-12-20 05:51:08 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:08 --> Input Class Initialized
INFO - 2022-12-20 05:51:08 --> Language Class Initialized
INFO - 2022-12-20 05:51:08 --> Loader Class Initialized
INFO - 2022-12-20 05:51:08 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:08 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:08 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:08 --> Model "Mysql_model" initialized
INFO - 2022-12-20 05:51:08 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:08 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:08 --> Total execution time: 0.1331
INFO - 2022-12-20 05:51:09 --> Config Class Initialized
INFO - 2022-12-20 05:51:09 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:09 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:09 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:09 --> URI Class Initialized
INFO - 2022-12-20 05:51:09 --> Router Class Initialized
INFO - 2022-12-20 05:51:09 --> Output Class Initialized
INFO - 2022-12-20 05:51:09 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:09 --> Input Class Initialized
INFO - 2022-12-20 05:51:09 --> Language Class Initialized
INFO - 2022-12-20 05:51:09 --> Loader Class Initialized
INFO - 2022-12-20 05:51:09 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:09 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:09 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:09 --> Model "Mysql_model" initialized
INFO - 2022-12-20 05:51:09 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:09 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:09 --> Total execution time: 0.1383
INFO - 2022-12-20 05:51:10 --> Config Class Initialized
INFO - 2022-12-20 05:51:10 --> Hooks Class Initialized
DEBUG - 2022-12-20 05:51:10 --> UTF-8 Support Enabled
INFO - 2022-12-20 05:51:10 --> Utf8 Class Initialized
INFO - 2022-12-20 05:51:10 --> URI Class Initialized
INFO - 2022-12-20 05:51:10 --> Router Class Initialized
INFO - 2022-12-20 05:51:10 --> Output Class Initialized
INFO - 2022-12-20 05:51:10 --> Security Class Initialized
DEBUG - 2022-12-20 05:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 05:51:10 --> Input Class Initialized
INFO - 2022-12-20 05:51:10 --> Language Class Initialized
INFO - 2022-12-20 05:51:10 --> Loader Class Initialized
INFO - 2022-12-20 05:51:10 --> Controller Class Initialized
DEBUG - 2022-12-20 05:51:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 05:51:10 --> Database Driver Class Initialized
INFO - 2022-12-20 05:51:10 --> Model "Cluster_model" initialized
INFO - 2022-12-20 05:51:10 --> Model "Mysql_model" initialized
INFO - 2022-12-20 05:51:10 --> Model "Grafana_model" initialized
INFO - 2022-12-20 05:51:10 --> Final output sent to browser
DEBUG - 2022-12-20 05:51:10 --> Total execution time: 0.1326
INFO - 2022-12-20 08:05:36 --> Config Class Initialized
INFO - 2022-12-20 08:05:36 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:36 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:36 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:36 --> URI Class Initialized
INFO - 2022-12-20 08:05:36 --> Router Class Initialized
INFO - 2022-12-20 08:05:36 --> Output Class Initialized
INFO - 2022-12-20 08:05:36 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:36 --> Input Class Initialized
INFO - 2022-12-20 08:05:36 --> Language Class Initialized
INFO - 2022-12-20 08:05:36 --> Loader Class Initialized
INFO - 2022-12-20 08:05:36 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:36 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:36 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:36 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:36 --> Total execution time: 0.1904
INFO - 2022-12-20 08:05:36 --> Config Class Initialized
INFO - 2022-12-20 08:05:36 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:36 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:36 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:36 --> URI Class Initialized
INFO - 2022-12-20 08:05:36 --> Router Class Initialized
INFO - 2022-12-20 08:05:36 --> Output Class Initialized
INFO - 2022-12-20 08:05:36 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:36 --> Input Class Initialized
INFO - 2022-12-20 08:05:36 --> Language Class Initialized
INFO - 2022-12-20 08:05:36 --> Loader Class Initialized
INFO - 2022-12-20 08:05:36 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:36 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:36 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:36 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:36 --> Total execution time: 0.1595
INFO - 2022-12-20 08:05:38 --> Config Class Initialized
INFO - 2022-12-20 08:05:38 --> Config Class Initialized
INFO - 2022-12-20 08:05:38 --> Hooks Class Initialized
INFO - 2022-12-20 08:05:38 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 08:05:38 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:38 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:38 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:38 --> URI Class Initialized
INFO - 2022-12-20 08:05:38 --> URI Class Initialized
INFO - 2022-12-20 08:05:38 --> Router Class Initialized
INFO - 2022-12-20 08:05:38 --> Router Class Initialized
INFO - 2022-12-20 08:05:38 --> Output Class Initialized
INFO - 2022-12-20 08:05:38 --> Output Class Initialized
INFO - 2022-12-20 08:05:38 --> Security Class Initialized
INFO - 2022-12-20 08:05:38 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:38 --> Input Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:38 --> Input Class Initialized
INFO - 2022-12-20 08:05:38 --> Language Class Initialized
INFO - 2022-12-20 08:05:38 --> Language Class Initialized
INFO - 2022-12-20 08:05:38 --> Loader Class Initialized
INFO - 2022-12-20 08:05:38 --> Loader Class Initialized
INFO - 2022-12-20 08:05:38 --> Controller Class Initialized
INFO - 2022-12-20 08:05:38 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-20 08:05:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:38 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:38 --> Total execution time: 0.1751
INFO - 2022-12-20 08:05:38 --> Config Class Initialized
INFO - 2022-12-20 08:05:38 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:38 --> Hooks Class Initialized
INFO - 2022-12-20 08:05:38 --> Model "Cluster_model" initialized
DEBUG - 2022-12-20 08:05:38 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:38 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:38 --> Final output sent to browser
INFO - 2022-12-20 08:05:38 --> URI Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Total execution time: 0.2394
INFO - 2022-12-20 08:05:38 --> Router Class Initialized
INFO - 2022-12-20 08:05:38 --> Output Class Initialized
INFO - 2022-12-20 08:05:38 --> Config Class Initialized
INFO - 2022-12-20 08:05:38 --> Hooks Class Initialized
INFO - 2022-12-20 08:05:38 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 08:05:38 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:38 --> Input Class Initialized
INFO - 2022-12-20 08:05:38 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:38 --> URI Class Initialized
INFO - 2022-12-20 08:05:38 --> Language Class Initialized
INFO - 2022-12-20 08:05:38 --> Router Class Initialized
INFO - 2022-12-20 08:05:38 --> Loader Class Initialized
INFO - 2022-12-20 08:05:38 --> Output Class Initialized
INFO - 2022-12-20 08:05:38 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:38 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:38 --> Input Class Initialized
INFO - 2022-12-20 08:05:38 --> Language Class Initialized
INFO - 2022-12-20 08:05:38 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:38 --> Model "Login_model" initialized
INFO - 2022-12-20 08:05:38 --> Loader Class Initialized
INFO - 2022-12-20 08:05:38 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:38 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:38 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:38 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:38 --> Total execution time: 0.2307
INFO - 2022-12-20 08:05:38 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:38 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:38 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:38 --> Total execution time: 0.1980
INFO - 2022-12-20 08:05:42 --> Config Class Initialized
INFO - 2022-12-20 08:05:42 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:42 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:42 --> URI Class Initialized
INFO - 2022-12-20 08:05:42 --> Router Class Initialized
INFO - 2022-12-20 08:05:42 --> Output Class Initialized
INFO - 2022-12-20 08:05:42 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:42 --> Input Class Initialized
INFO - 2022-12-20 08:05:42 --> Language Class Initialized
INFO - 2022-12-20 08:05:42 --> Loader Class Initialized
INFO - 2022-12-20 08:05:42 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:42 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:42 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:42 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:42 --> Total execution time: 0.1377
INFO - 2022-12-20 08:05:42 --> Config Class Initialized
INFO - 2022-12-20 08:05:42 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:42 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:42 --> URI Class Initialized
INFO - 2022-12-20 08:05:42 --> Router Class Initialized
INFO - 2022-12-20 08:05:42 --> Output Class Initialized
INFO - 2022-12-20 08:05:42 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:42 --> Input Class Initialized
INFO - 2022-12-20 08:05:42 --> Language Class Initialized
INFO - 2022-12-20 08:05:43 --> Loader Class Initialized
INFO - 2022-12-20 08:05:43 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:43 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:43 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:43 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:43 --> Total execution time: 0.1410
INFO - 2022-12-20 08:05:44 --> Config Class Initialized
INFO - 2022-12-20 08:05:44 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:44 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:44 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:44 --> URI Class Initialized
INFO - 2022-12-20 08:05:44 --> Router Class Initialized
INFO - 2022-12-20 08:05:44 --> Output Class Initialized
INFO - 2022-12-20 08:05:44 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:44 --> Input Class Initialized
INFO - 2022-12-20 08:05:44 --> Language Class Initialized
INFO - 2022-12-20 08:05:44 --> Loader Class Initialized
INFO - 2022-12-20 08:05:44 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:44 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:44 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:44 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:44 --> Model "Login_model" initialized
INFO - 2022-12-20 08:05:44 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:44 --> Total execution time: 0.2257
INFO - 2022-12-20 08:05:44 --> Config Class Initialized
INFO - 2022-12-20 08:05:44 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:05:44 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:05:44 --> Utf8 Class Initialized
INFO - 2022-12-20 08:05:44 --> URI Class Initialized
INFO - 2022-12-20 08:05:44 --> Router Class Initialized
INFO - 2022-12-20 08:05:44 --> Output Class Initialized
INFO - 2022-12-20 08:05:44 --> Security Class Initialized
DEBUG - 2022-12-20 08:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:05:44 --> Input Class Initialized
INFO - 2022-12-20 08:05:44 --> Language Class Initialized
INFO - 2022-12-20 08:05:44 --> Loader Class Initialized
INFO - 2022-12-20 08:05:44 --> Controller Class Initialized
DEBUG - 2022-12-20 08:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:05:44 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:44 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:05:44 --> Database Driver Class Initialized
INFO - 2022-12-20 08:05:44 --> Model "Login_model" initialized
INFO - 2022-12-20 08:05:44 --> Final output sent to browser
DEBUG - 2022-12-20 08:05:44 --> Total execution time: 0.2391
INFO - 2022-12-20 08:07:53 --> Config Class Initialized
INFO - 2022-12-20 08:07:53 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:07:53 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:07:53 --> Utf8 Class Initialized
INFO - 2022-12-20 08:07:53 --> URI Class Initialized
INFO - 2022-12-20 08:07:53 --> Router Class Initialized
INFO - 2022-12-20 08:07:53 --> Output Class Initialized
INFO - 2022-12-20 08:07:53 --> Security Class Initialized
DEBUG - 2022-12-20 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:07:53 --> Input Class Initialized
INFO - 2022-12-20 08:07:53 --> Language Class Initialized
INFO - 2022-12-20 08:07:53 --> Loader Class Initialized
INFO - 2022-12-20 08:07:53 --> Controller Class Initialized
DEBUG - 2022-12-20 08:07:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:07:53 --> Final output sent to browser
DEBUG - 2022-12-20 08:07:53 --> Total execution time: 0.0826
INFO - 2022-12-20 08:07:53 --> Config Class Initialized
INFO - 2022-12-20 08:07:53 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:07:53 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:07:53 --> Utf8 Class Initialized
INFO - 2022-12-20 08:07:53 --> URI Class Initialized
INFO - 2022-12-20 08:07:53 --> Router Class Initialized
INFO - 2022-12-20 08:07:53 --> Output Class Initialized
INFO - 2022-12-20 08:07:53 --> Security Class Initialized
DEBUG - 2022-12-20 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:07:53 --> Input Class Initialized
INFO - 2022-12-20 08:07:53 --> Language Class Initialized
INFO - 2022-12-20 08:07:53 --> Loader Class Initialized
INFO - 2022-12-20 08:07:53 --> Controller Class Initialized
DEBUG - 2022-12-20 08:07:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:07:53 --> Database Driver Class Initialized
INFO - 2022-12-20 08:07:53 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:07:53 --> Model "Node_model" initialized
INFO - 2022-12-20 08:07:53 --> Model "Grafana_model" initialized
INFO - 2022-12-20 08:07:53 --> Final output sent to browser
DEBUG - 2022-12-20 08:07:53 --> Total execution time: 0.1269
INFO - 2022-12-20 08:07:54 --> Config Class Initialized
INFO - 2022-12-20 08:07:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:07:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:07:54 --> Utf8 Class Initialized
INFO - 2022-12-20 08:07:54 --> URI Class Initialized
INFO - 2022-12-20 08:07:54 --> Router Class Initialized
INFO - 2022-12-20 08:07:54 --> Output Class Initialized
INFO - 2022-12-20 08:07:54 --> Security Class Initialized
DEBUG - 2022-12-20 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:07:54 --> Input Class Initialized
INFO - 2022-12-20 08:07:54 --> Language Class Initialized
INFO - 2022-12-20 08:07:54 --> Loader Class Initialized
INFO - 2022-12-20 08:07:54 --> Controller Class Initialized
DEBUG - 2022-12-20 08:07:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:07:54 --> Database Driver Class Initialized
INFO - 2022-12-20 08:07:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:07:54 --> Model "Node_model" initialized
INFO - 2022-12-20 08:07:54 --> Model "Grafana_model" initialized
INFO - 2022-12-20 08:07:54 --> Final output sent to browser
DEBUG - 2022-12-20 08:07:54 --> Total execution time: 0.1204
INFO - 2022-12-20 08:07:54 --> Config Class Initialized
INFO - 2022-12-20 08:07:54 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:07:54 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:07:54 --> Utf8 Class Initialized
INFO - 2022-12-20 08:07:54 --> URI Class Initialized
INFO - 2022-12-20 08:07:54 --> Router Class Initialized
INFO - 2022-12-20 08:07:54 --> Output Class Initialized
INFO - 2022-12-20 08:07:54 --> Security Class Initialized
DEBUG - 2022-12-20 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:07:54 --> Input Class Initialized
INFO - 2022-12-20 08:07:54 --> Language Class Initialized
INFO - 2022-12-20 08:07:54 --> Loader Class Initialized
INFO - 2022-12-20 08:07:54 --> Controller Class Initialized
DEBUG - 2022-12-20 08:07:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:07:54 --> Database Driver Class Initialized
INFO - 2022-12-20 08:07:54 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:07:54 --> Model "Node_model" initialized
INFO - 2022-12-20 08:07:54 --> Model "Grafana_model" initialized
INFO - 2022-12-20 08:07:54 --> Final output sent to browser
DEBUG - 2022-12-20 08:07:54 --> Total execution time: 0.1946
INFO - 2022-12-20 08:46:15 --> Config Class Initialized
INFO - 2022-12-20 08:46:15 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:46:15 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:46:15 --> Utf8 Class Initialized
INFO - 2022-12-20 08:46:15 --> URI Class Initialized
INFO - 2022-12-20 08:46:15 --> Router Class Initialized
INFO - 2022-12-20 08:46:15 --> Output Class Initialized
INFO - 2022-12-20 08:46:15 --> Security Class Initialized
DEBUG - 2022-12-20 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:46:15 --> Input Class Initialized
INFO - 2022-12-20 08:46:15 --> Language Class Initialized
INFO - 2022-12-20 08:46:15 --> Loader Class Initialized
INFO - 2022-12-20 08:46:15 --> Controller Class Initialized
DEBUG - 2022-12-20 08:46:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:46:15 --> Database Driver Class Initialized
INFO - 2022-12-20 08:46:15 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:46:15 --> Database Driver Class Initialized
INFO - 2022-12-20 08:46:15 --> Model "Login_model" initialized
INFO - 2022-12-20 08:46:15 --> Final output sent to browser
DEBUG - 2022-12-20 08:46:15 --> Total execution time: 0.2662
INFO - 2022-12-20 08:46:15 --> Config Class Initialized
INFO - 2022-12-20 08:46:15 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:46:15 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:46:15 --> Utf8 Class Initialized
INFO - 2022-12-20 08:46:15 --> URI Class Initialized
INFO - 2022-12-20 08:46:15 --> Router Class Initialized
INFO - 2022-12-20 08:46:15 --> Output Class Initialized
INFO - 2022-12-20 08:46:15 --> Security Class Initialized
DEBUG - 2022-12-20 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:46:15 --> Input Class Initialized
INFO - 2022-12-20 08:46:15 --> Language Class Initialized
INFO - 2022-12-20 08:46:15 --> Loader Class Initialized
INFO - 2022-12-20 08:46:15 --> Controller Class Initialized
DEBUG - 2022-12-20 08:46:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:46:15 --> Database Driver Class Initialized
INFO - 2022-12-20 08:46:15 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:46:15 --> Database Driver Class Initialized
INFO - 2022-12-20 08:46:15 --> Model "Login_model" initialized
INFO - 2022-12-20 08:46:16 --> Final output sent to browser
DEBUG - 2022-12-20 08:46:16 --> Total execution time: 0.2468
INFO - 2022-12-20 08:52:26 --> Config Class Initialized
INFO - 2022-12-20 08:52:26 --> Config Class Initialized
INFO - 2022-12-20 08:52:26 --> Hooks Class Initialized
INFO - 2022-12-20 08:52:26 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 08:52:26 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:26 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:27 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:27 --> URI Class Initialized
INFO - 2022-12-20 08:52:27 --> URI Class Initialized
INFO - 2022-12-20 08:52:27 --> Router Class Initialized
INFO - 2022-12-20 08:52:27 --> Router Class Initialized
INFO - 2022-12-20 08:52:27 --> Output Class Initialized
INFO - 2022-12-20 08:52:27 --> Output Class Initialized
INFO - 2022-12-20 08:52:27 --> Security Class Initialized
INFO - 2022-12-20 08:52:27 --> Security Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:52:27 --> Input Class Initialized
INFO - 2022-12-20 08:52:27 --> Input Class Initialized
INFO - 2022-12-20 08:52:27 --> Language Class Initialized
INFO - 2022-12-20 08:52:27 --> Language Class Initialized
INFO - 2022-12-20 08:52:27 --> Loader Class Initialized
INFO - 2022-12-20 08:52:27 --> Loader Class Initialized
INFO - 2022-12-20 08:52:27 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:27 --> Controller Class Initialized
INFO - 2022-12-20 08:52:27 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-20 08:52:27 --> Total execution time: 0.2102
INFO - 2022-12-20 08:52:27 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:27 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:27 --> Config Class Initialized
INFO - 2022-12-20 08:52:27 --> Hooks Class Initialized
INFO - 2022-12-20 08:52:27 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:27 --> Total execution time: 0.2766
DEBUG - 2022-12-20 08:52:27 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:27 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:27 --> URI Class Initialized
INFO - 2022-12-20 08:52:27 --> Config Class Initialized
INFO - 2022-12-20 08:52:27 --> Router Class Initialized
INFO - 2022-12-20 08:52:27 --> Hooks Class Initialized
INFO - 2022-12-20 08:52:27 --> Output Class Initialized
DEBUG - 2022-12-20 08:52:27 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:27 --> Security Class Initialized
INFO - 2022-12-20 08:52:27 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:27 --> URI Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:52:27 --> Input Class Initialized
INFO - 2022-12-20 08:52:27 --> Router Class Initialized
INFO - 2022-12-20 08:52:27 --> Language Class Initialized
INFO - 2022-12-20 08:52:27 --> Output Class Initialized
INFO - 2022-12-20 08:52:27 --> Loader Class Initialized
INFO - 2022-12-20 08:52:27 --> Security Class Initialized
INFO - 2022-12-20 08:52:27 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:27 --> Input Class Initialized
INFO - 2022-12-20 08:52:27 --> Language Class Initialized
INFO - 2022-12-20 08:52:27 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:27 --> Model "Login_model" initialized
INFO - 2022-12-20 08:52:27 --> Loader Class Initialized
INFO - 2022-12-20 08:52:27 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:27 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:27 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:27 --> Final output sent to browser
INFO - 2022-12-20 08:52:27 --> Database Driver Class Initialized
DEBUG - 2022-12-20 08:52:27 --> Total execution time: 0.2623
INFO - 2022-12-20 08:52:27 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:27 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:27 --> Total execution time: 0.2519
INFO - 2022-12-20 08:52:30 --> Config Class Initialized
INFO - 2022-12-20 08:52:30 --> Config Class Initialized
INFO - 2022-12-20 08:52:30 --> Hooks Class Initialized
INFO - 2022-12-20 08:52:30 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 08:52:30 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:30 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:30 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:30 --> URI Class Initialized
INFO - 2022-12-20 08:52:30 --> URI Class Initialized
INFO - 2022-12-20 08:52:30 --> Router Class Initialized
INFO - 2022-12-20 08:52:30 --> Router Class Initialized
INFO - 2022-12-20 08:52:30 --> Output Class Initialized
INFO - 2022-12-20 08:52:30 --> Output Class Initialized
INFO - 2022-12-20 08:52:30 --> Security Class Initialized
INFO - 2022-12-20 08:52:30 --> Security Class Initialized
DEBUG - 2022-12-20 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:52:30 --> Input Class Initialized
INFO - 2022-12-20 08:52:30 --> Input Class Initialized
INFO - 2022-12-20 08:52:30 --> Language Class Initialized
INFO - 2022-12-20 08:52:30 --> Language Class Initialized
INFO - 2022-12-20 08:52:30 --> Loader Class Initialized
INFO - 2022-12-20 08:52:30 --> Controller Class Initialized
INFO - 2022-12-20 08:52:30 --> Loader Class Initialized
DEBUG - 2022-12-20 08:52:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:30 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:30 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:31 --> Model "Login_model" initialized
INFO - 2022-12-20 08:52:31 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:31 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:31 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:31 --> Final output sent to browser
INFO - 2022-12-20 08:52:31 --> Model "Cluster_model" initialized
DEBUG - 2022-12-20 08:52:31 --> Total execution time: 0.2710
INFO - 2022-12-20 08:52:31 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:31 --> Total execution time: 0.2846
INFO - 2022-12-20 08:52:33 --> Config Class Initialized
INFO - 2022-12-20 08:52:33 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:52:33 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:33 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:33 --> URI Class Initialized
INFO - 2022-12-20 08:52:33 --> Router Class Initialized
INFO - 2022-12-20 08:52:33 --> Output Class Initialized
INFO - 2022-12-20 08:52:33 --> Security Class Initialized
DEBUG - 2022-12-20 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:52:33 --> Input Class Initialized
INFO - 2022-12-20 08:52:33 --> Language Class Initialized
INFO - 2022-12-20 08:52:33 --> Loader Class Initialized
INFO - 2022-12-20 08:52:33 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:33 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:33 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:33 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:33 --> Model "Login_model" initialized
INFO - 2022-12-20 08:52:33 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:33 --> Total execution time: 0.2722
INFO - 2022-12-20 08:52:33 --> Config Class Initialized
INFO - 2022-12-20 08:52:33 --> Hooks Class Initialized
DEBUG - 2022-12-20 08:52:33 --> UTF-8 Support Enabled
INFO - 2022-12-20 08:52:33 --> Utf8 Class Initialized
INFO - 2022-12-20 08:52:33 --> URI Class Initialized
INFO - 2022-12-20 08:52:33 --> Router Class Initialized
INFO - 2022-12-20 08:52:33 --> Output Class Initialized
INFO - 2022-12-20 08:52:33 --> Security Class Initialized
DEBUG - 2022-12-20 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-20 08:52:33 --> Input Class Initialized
INFO - 2022-12-20 08:52:33 --> Language Class Initialized
INFO - 2022-12-20 08:52:33 --> Loader Class Initialized
INFO - 2022-12-20 08:52:33 --> Controller Class Initialized
DEBUG - 2022-12-20 08:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-20 08:52:33 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:33 --> Model "Cluster_model" initialized
INFO - 2022-12-20 08:52:33 --> Database Driver Class Initialized
INFO - 2022-12-20 08:52:33 --> Model "Login_model" initialized
INFO - 2022-12-20 08:52:33 --> Final output sent to browser
DEBUG - 2022-12-20 08:52:33 --> Total execution time: 0.2463
