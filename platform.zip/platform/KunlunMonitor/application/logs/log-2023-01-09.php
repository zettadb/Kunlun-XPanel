<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-09 02:18:58 --> Config Class Initialized
INFO - 2023-01-09 02:18:58 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:18:58 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:18:58 --> Utf8 Class Initialized
INFO - 2023-01-09 02:18:58 --> URI Class Initialized
INFO - 2023-01-09 02:18:58 --> Router Class Initialized
INFO - 2023-01-09 02:18:59 --> Output Class Initialized
INFO - 2023-01-09 02:18:59 --> Security Class Initialized
DEBUG - 2023-01-09 02:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:18:59 --> Input Class Initialized
INFO - 2023-01-09 02:18:59 --> Language Class Initialized
INFO - 2023-01-09 02:18:59 --> Loader Class Initialized
INFO - 2023-01-09 02:18:59 --> Controller Class Initialized
INFO - 2023-01-09 02:18:59 --> Helper loaded: form_helper
INFO - 2023-01-09 02:18:59 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:18:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:18:59 --> Model "Change_model" initialized
INFO - 2023-01-09 02:19:24 --> Config Class Initialized
INFO - 2023-01-09 02:19:24 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:19:24 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:19:24 --> Utf8 Class Initialized
INFO - 2023-01-09 02:19:24 --> URI Class Initialized
INFO - 2023-01-09 02:19:24 --> Router Class Initialized
INFO - 2023-01-09 02:19:24 --> Output Class Initialized
INFO - 2023-01-09 02:19:24 --> Security Class Initialized
DEBUG - 2023-01-09 02:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:19:24 --> Input Class Initialized
INFO - 2023-01-09 02:19:24 --> Language Class Initialized
INFO - 2023-01-09 02:19:24 --> Loader Class Initialized
INFO - 2023-01-09 02:19:24 --> Controller Class Initialized
INFO - 2023-01-09 02:19:24 --> Helper loaded: form_helper
INFO - 2023-01-09 02:19:24 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:19:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:19:24 --> Model "Change_model" initialized
INFO - 2023-01-09 02:20:06 --> Config Class Initialized
INFO - 2023-01-09 02:20:06 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:20:06 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:20:06 --> Utf8 Class Initialized
INFO - 2023-01-09 02:20:06 --> URI Class Initialized
INFO - 2023-01-09 02:20:06 --> Router Class Initialized
INFO - 2023-01-09 02:20:06 --> Output Class Initialized
INFO - 2023-01-09 02:20:06 --> Security Class Initialized
DEBUG - 2023-01-09 02:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:20:06 --> Input Class Initialized
INFO - 2023-01-09 02:20:06 --> Language Class Initialized
INFO - 2023-01-09 02:20:06 --> Loader Class Initialized
INFO - 2023-01-09 02:20:06 --> Controller Class Initialized
INFO - 2023-01-09 02:20:06 --> Helper loaded: form_helper
INFO - 2023-01-09 02:20:06 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:20:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:20:08 --> Config Class Initialized
INFO - 2023-01-09 02:20:08 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:20:08 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:20:08 --> Utf8 Class Initialized
INFO - 2023-01-09 02:20:08 --> URI Class Initialized
INFO - 2023-01-09 02:20:08 --> Router Class Initialized
INFO - 2023-01-09 02:20:08 --> Output Class Initialized
INFO - 2023-01-09 02:20:08 --> Security Class Initialized
DEBUG - 2023-01-09 02:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:20:08 --> Input Class Initialized
INFO - 2023-01-09 02:20:08 --> Language Class Initialized
INFO - 2023-01-09 02:20:08 --> Loader Class Initialized
INFO - 2023-01-09 02:20:08 --> Controller Class Initialized
INFO - 2023-01-09 02:20:08 --> Helper loaded: form_helper
INFO - 2023-01-09 02:20:08 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:20:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:21:31 --> Config Class Initialized
INFO - 2023-01-09 02:21:31 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:21:31 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:21:31 --> Utf8 Class Initialized
INFO - 2023-01-09 02:21:31 --> URI Class Initialized
INFO - 2023-01-09 02:21:31 --> Router Class Initialized
INFO - 2023-01-09 02:21:31 --> Output Class Initialized
INFO - 2023-01-09 02:21:31 --> Security Class Initialized
DEBUG - 2023-01-09 02:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:21:31 --> Input Class Initialized
INFO - 2023-01-09 02:21:31 --> Language Class Initialized
INFO - 2023-01-09 02:21:31 --> Loader Class Initialized
INFO - 2023-01-09 02:21:31 --> Controller Class Initialized
INFO - 2023-01-09 02:21:31 --> Helper loaded: form_helper
INFO - 2023-01-09 02:21:31 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:21:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:21:31 --> Model "Change_model" initialized
INFO - 2023-01-09 02:25:10 --> Config Class Initialized
INFO - 2023-01-09 02:25:10 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:25:10 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:25:10 --> Utf8 Class Initialized
INFO - 2023-01-09 02:25:10 --> URI Class Initialized
INFO - 2023-01-09 02:25:10 --> Router Class Initialized
INFO - 2023-01-09 02:25:10 --> Output Class Initialized
INFO - 2023-01-09 02:25:10 --> Security Class Initialized
DEBUG - 2023-01-09 02:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:25:10 --> Input Class Initialized
INFO - 2023-01-09 02:25:10 --> Language Class Initialized
INFO - 2023-01-09 02:25:10 --> Loader Class Initialized
INFO - 2023-01-09 02:25:10 --> Controller Class Initialized
INFO - 2023-01-09 02:25:10 --> Helper loaded: form_helper
INFO - 2023-01-09 02:25:10 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:25:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:25:48 --> Config Class Initialized
INFO - 2023-01-09 02:25:48 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:25:48 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:25:48 --> Utf8 Class Initialized
INFO - 2023-01-09 02:25:48 --> URI Class Initialized
INFO - 2023-01-09 02:25:48 --> Router Class Initialized
INFO - 2023-01-09 02:25:48 --> Output Class Initialized
INFO - 2023-01-09 02:25:48 --> Security Class Initialized
DEBUG - 2023-01-09 02:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:25:48 --> Input Class Initialized
INFO - 2023-01-09 02:25:48 --> Language Class Initialized
INFO - 2023-01-09 02:25:48 --> Loader Class Initialized
INFO - 2023-01-09 02:25:48 --> Controller Class Initialized
INFO - 2023-01-09 02:25:48 --> Helper loaded: form_helper
INFO - 2023-01-09 02:25:48 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:25:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:25:50 --> Config Class Initialized
INFO - 2023-01-09 02:25:50 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:25:50 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:25:50 --> Utf8 Class Initialized
INFO - 2023-01-09 02:25:50 --> URI Class Initialized
INFO - 2023-01-09 02:25:50 --> Router Class Initialized
INFO - 2023-01-09 02:25:50 --> Output Class Initialized
INFO - 2023-01-09 02:25:50 --> Security Class Initialized
DEBUG - 2023-01-09 02:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:25:50 --> Input Class Initialized
INFO - 2023-01-09 02:25:50 --> Language Class Initialized
INFO - 2023-01-09 02:25:50 --> Loader Class Initialized
INFO - 2023-01-09 02:25:50 --> Controller Class Initialized
INFO - 2023-01-09 02:25:50 --> Helper loaded: form_helper
INFO - 2023-01-09 02:25:50 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:25:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:25:51 --> Config Class Initialized
INFO - 2023-01-09 02:25:51 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:25:51 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:25:51 --> Utf8 Class Initialized
INFO - 2023-01-09 02:25:51 --> URI Class Initialized
INFO - 2023-01-09 02:25:51 --> Router Class Initialized
INFO - 2023-01-09 02:25:51 --> Output Class Initialized
INFO - 2023-01-09 02:25:51 --> Security Class Initialized
DEBUG - 2023-01-09 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:25:51 --> Input Class Initialized
INFO - 2023-01-09 02:25:51 --> Language Class Initialized
INFO - 2023-01-09 02:25:51 --> Loader Class Initialized
INFO - 2023-01-09 02:25:51 --> Controller Class Initialized
INFO - 2023-01-09 02:25:51 --> Helper loaded: form_helper
INFO - 2023-01-09 02:25:51 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:26:15 --> Config Class Initialized
INFO - 2023-01-09 02:26:15 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:26:15 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:26:15 --> Utf8 Class Initialized
INFO - 2023-01-09 02:26:15 --> URI Class Initialized
INFO - 2023-01-09 02:26:15 --> Router Class Initialized
INFO - 2023-01-09 02:26:15 --> Output Class Initialized
INFO - 2023-01-09 02:26:15 --> Security Class Initialized
DEBUG - 2023-01-09 02:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:26:15 --> Input Class Initialized
INFO - 2023-01-09 02:26:15 --> Language Class Initialized
INFO - 2023-01-09 02:26:15 --> Loader Class Initialized
INFO - 2023-01-09 02:26:15 --> Controller Class Initialized
INFO - 2023-01-09 02:26:15 --> Helper loaded: form_helper
INFO - 2023-01-09 02:26:15 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:26:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:27:02 --> Config Class Initialized
INFO - 2023-01-09 02:27:02 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:27:02 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:27:02 --> Utf8 Class Initialized
INFO - 2023-01-09 02:27:02 --> URI Class Initialized
INFO - 2023-01-09 02:27:02 --> Router Class Initialized
INFO - 2023-01-09 02:27:02 --> Output Class Initialized
INFO - 2023-01-09 02:27:02 --> Security Class Initialized
DEBUG - 2023-01-09 02:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:27:02 --> Input Class Initialized
INFO - 2023-01-09 02:27:02 --> Language Class Initialized
INFO - 2023-01-09 02:27:03 --> Loader Class Initialized
INFO - 2023-01-09 02:27:03 --> Controller Class Initialized
INFO - 2023-01-09 02:27:03 --> Helper loaded: form_helper
INFO - 2023-01-09 02:27:03 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:27:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 02:27:11 --> Config Class Initialized
INFO - 2023-01-09 02:27:11 --> Hooks Class Initialized
DEBUG - 2023-01-09 02:27:11 --> UTF-8 Support Enabled
INFO - 2023-01-09 02:27:11 --> Utf8 Class Initialized
INFO - 2023-01-09 02:27:11 --> URI Class Initialized
INFO - 2023-01-09 02:27:11 --> Router Class Initialized
INFO - 2023-01-09 02:27:11 --> Output Class Initialized
INFO - 2023-01-09 02:27:11 --> Security Class Initialized
DEBUG - 2023-01-09 02:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 02:27:11 --> Input Class Initialized
INFO - 2023-01-09 02:27:11 --> Language Class Initialized
INFO - 2023-01-09 02:27:11 --> Loader Class Initialized
INFO - 2023-01-09 02:27:11 --> Controller Class Initialized
INFO - 2023-01-09 02:27:11 --> Helper loaded: form_helper
INFO - 2023-01-09 02:27:11 --> Helper loaded: url_helper
DEBUG - 2023-01-09 02:27:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:13:31 --> Config Class Initialized
INFO - 2023-01-09 03:13:31 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:13:31 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:13:31 --> Utf8 Class Initialized
INFO - 2023-01-09 03:13:31 --> URI Class Initialized
INFO - 2023-01-09 03:13:31 --> Router Class Initialized
INFO - 2023-01-09 03:13:31 --> Output Class Initialized
INFO - 2023-01-09 03:13:31 --> Security Class Initialized
DEBUG - 2023-01-09 03:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:13:31 --> Input Class Initialized
INFO - 2023-01-09 03:13:31 --> Language Class Initialized
INFO - 2023-01-09 03:13:31 --> Loader Class Initialized
INFO - 2023-01-09 03:13:31 --> Controller Class Initialized
INFO - 2023-01-09 03:13:31 --> Helper loaded: form_helper
INFO - 2023-01-09 03:13:31 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:13:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:13:44 --> Config Class Initialized
INFO - 2023-01-09 03:13:44 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:13:44 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:13:44 --> Utf8 Class Initialized
INFO - 2023-01-09 03:13:44 --> URI Class Initialized
INFO - 2023-01-09 03:13:44 --> Router Class Initialized
INFO - 2023-01-09 03:13:44 --> Output Class Initialized
INFO - 2023-01-09 03:13:44 --> Security Class Initialized
DEBUG - 2023-01-09 03:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:13:44 --> Input Class Initialized
INFO - 2023-01-09 03:13:44 --> Language Class Initialized
INFO - 2023-01-09 03:13:44 --> Loader Class Initialized
INFO - 2023-01-09 03:13:44 --> Controller Class Initialized
INFO - 2023-01-09 03:13:44 --> Helper loaded: form_helper
INFO - 2023-01-09 03:13:44 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:13:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:14:00 --> Config Class Initialized
INFO - 2023-01-09 03:14:00 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:14:00 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:14:00 --> Utf8 Class Initialized
INFO - 2023-01-09 03:14:00 --> URI Class Initialized
INFO - 2023-01-09 03:14:00 --> Router Class Initialized
INFO - 2023-01-09 03:14:00 --> Output Class Initialized
INFO - 2023-01-09 03:14:00 --> Security Class Initialized
DEBUG - 2023-01-09 03:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:14:00 --> Input Class Initialized
INFO - 2023-01-09 03:14:00 --> Language Class Initialized
INFO - 2023-01-09 03:14:00 --> Loader Class Initialized
INFO - 2023-01-09 03:14:00 --> Controller Class Initialized
INFO - 2023-01-09 03:14:00 --> Helper loaded: form_helper
INFO - 2023-01-09 03:14:00 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:14:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:14:00 --> Model "Change_model" initialized
INFO - 2023-01-09 03:14:02 --> Config Class Initialized
INFO - 2023-01-09 03:14:02 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:14:02 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:14:02 --> Utf8 Class Initialized
INFO - 2023-01-09 03:14:02 --> URI Class Initialized
INFO - 2023-01-09 03:14:02 --> Router Class Initialized
INFO - 2023-01-09 03:14:02 --> Output Class Initialized
INFO - 2023-01-09 03:14:02 --> Security Class Initialized
DEBUG - 2023-01-09 03:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:14:02 --> Input Class Initialized
INFO - 2023-01-09 03:14:03 --> Language Class Initialized
INFO - 2023-01-09 03:14:03 --> Loader Class Initialized
INFO - 2023-01-09 03:14:03 --> Controller Class Initialized
INFO - 2023-01-09 03:14:03 --> Helper loaded: form_helper
INFO - 2023-01-09 03:14:03 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:14:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:14:03 --> Model "Change_model" initialized
INFO - 2023-01-09 03:14:03 --> Config Class Initialized
INFO - 2023-01-09 03:14:03 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:14:03 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:14:03 --> Utf8 Class Initialized
INFO - 2023-01-09 03:14:03 --> URI Class Initialized
INFO - 2023-01-09 03:14:03 --> Router Class Initialized
INFO - 2023-01-09 03:14:03 --> Output Class Initialized
INFO - 2023-01-09 03:14:03 --> Security Class Initialized
DEBUG - 2023-01-09 03:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:14:03 --> Input Class Initialized
INFO - 2023-01-09 03:14:03 --> Language Class Initialized
INFO - 2023-01-09 03:14:04 --> Loader Class Initialized
INFO - 2023-01-09 03:14:04 --> Controller Class Initialized
INFO - 2023-01-09 03:14:04 --> Helper loaded: form_helper
INFO - 2023-01-09 03:14:04 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:14:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:14:04 --> Model "Change_model" initialized
INFO - 2023-01-09 03:14:04 --> Config Class Initialized
INFO - 2023-01-09 03:14:04 --> Hooks Class Initialized
DEBUG - 2023-01-09 03:14:04 --> UTF-8 Support Enabled
INFO - 2023-01-09 03:14:04 --> Utf8 Class Initialized
INFO - 2023-01-09 03:14:04 --> URI Class Initialized
INFO - 2023-01-09 03:14:04 --> Router Class Initialized
INFO - 2023-01-09 03:14:04 --> Output Class Initialized
INFO - 2023-01-09 03:14:04 --> Security Class Initialized
DEBUG - 2023-01-09 03:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 03:14:04 --> Input Class Initialized
INFO - 2023-01-09 03:14:04 --> Language Class Initialized
INFO - 2023-01-09 03:14:04 --> Loader Class Initialized
INFO - 2023-01-09 03:14:04 --> Controller Class Initialized
INFO - 2023-01-09 03:14:04 --> Helper loaded: form_helper
INFO - 2023-01-09 03:14:04 --> Helper loaded: url_helper
DEBUG - 2023-01-09 03:14:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 03:14:04 --> Model "Change_model" initialized
INFO - 2023-01-09 05:49:46 --> Config Class Initialized
INFO - 2023-01-09 05:49:46 --> Hooks Class Initialized
DEBUG - 2023-01-09 05:49:46 --> UTF-8 Support Enabled
INFO - 2023-01-09 05:49:46 --> Utf8 Class Initialized
INFO - 2023-01-09 05:49:46 --> URI Class Initialized
INFO - 2023-01-09 05:49:46 --> Router Class Initialized
INFO - 2023-01-09 05:49:46 --> Output Class Initialized
INFO - 2023-01-09 05:49:46 --> Security Class Initialized
DEBUG - 2023-01-09 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 05:49:46 --> Input Class Initialized
INFO - 2023-01-09 05:49:46 --> Language Class Initialized
INFO - 2023-01-09 05:49:46 --> Loader Class Initialized
INFO - 2023-01-09 05:49:46 --> Controller Class Initialized
INFO - 2023-01-09 05:49:46 --> Helper loaded: form_helper
INFO - 2023-01-09 05:49:46 --> Helper loaded: url_helper
DEBUG - 2023-01-09 05:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 05:49:46 --> Model "Change_model" initialized
INFO - 2023-01-09 05:53:27 --> Config Class Initialized
INFO - 2023-01-09 05:53:27 --> Hooks Class Initialized
DEBUG - 2023-01-09 05:53:27 --> UTF-8 Support Enabled
INFO - 2023-01-09 05:53:27 --> Utf8 Class Initialized
INFO - 2023-01-09 05:53:27 --> URI Class Initialized
INFO - 2023-01-09 05:53:27 --> Router Class Initialized
INFO - 2023-01-09 05:53:27 --> Output Class Initialized
INFO - 2023-01-09 05:53:27 --> Security Class Initialized
DEBUG - 2023-01-09 05:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 05:53:27 --> Input Class Initialized
INFO - 2023-01-09 05:53:27 --> Language Class Initialized
INFO - 2023-01-09 05:53:27 --> Loader Class Initialized
INFO - 2023-01-09 05:53:27 --> Controller Class Initialized
INFO - 2023-01-09 05:53:27 --> Helper loaded: form_helper
INFO - 2023-01-09 05:53:27 --> Helper loaded: url_helper
DEBUG - 2023-01-09 05:53:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 05:53:27 --> Model "Change_model" initialized
INFO - 2023-01-09 05:53:31 --> Config Class Initialized
INFO - 2023-01-09 05:53:31 --> Hooks Class Initialized
DEBUG - 2023-01-09 05:53:31 --> UTF-8 Support Enabled
INFO - 2023-01-09 05:53:31 --> Utf8 Class Initialized
INFO - 2023-01-09 05:53:31 --> URI Class Initialized
INFO - 2023-01-09 05:53:31 --> Router Class Initialized
INFO - 2023-01-09 05:53:31 --> Output Class Initialized
INFO - 2023-01-09 05:53:31 --> Security Class Initialized
DEBUG - 2023-01-09 05:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 05:53:31 --> Input Class Initialized
INFO - 2023-01-09 05:53:31 --> Language Class Initialized
INFO - 2023-01-09 05:53:31 --> Loader Class Initialized
INFO - 2023-01-09 05:53:31 --> Controller Class Initialized
INFO - 2023-01-09 05:53:31 --> Helper loaded: form_helper
INFO - 2023-01-09 05:53:31 --> Helper loaded: url_helper
DEBUG - 2023-01-09 05:53:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 05:53:31 --> Model "Change_model" initialized
INFO - 2023-01-09 05:55:42 --> Config Class Initialized
INFO - 2023-01-09 05:55:42 --> Hooks Class Initialized
DEBUG - 2023-01-09 05:55:42 --> UTF-8 Support Enabled
INFO - 2023-01-09 05:55:42 --> Utf8 Class Initialized
INFO - 2023-01-09 05:55:42 --> URI Class Initialized
INFO - 2023-01-09 05:55:42 --> Router Class Initialized
INFO - 2023-01-09 05:55:42 --> Output Class Initialized
INFO - 2023-01-09 05:55:42 --> Security Class Initialized
DEBUG - 2023-01-09 05:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 05:55:42 --> Input Class Initialized
INFO - 2023-01-09 05:55:42 --> Language Class Initialized
INFO - 2023-01-09 05:55:42 --> Loader Class Initialized
INFO - 2023-01-09 05:55:42 --> Controller Class Initialized
INFO - 2023-01-09 05:55:42 --> Helper loaded: form_helper
INFO - 2023-01-09 05:55:42 --> Helper loaded: url_helper
DEBUG - 2023-01-09 05:55:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 05:55:42 --> Model "Change_model" initialized
INFO - 2023-01-09 06:01:52 --> Config Class Initialized
INFO - 2023-01-09 06:01:52 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:01:52 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:01:52 --> Utf8 Class Initialized
INFO - 2023-01-09 06:01:52 --> URI Class Initialized
INFO - 2023-01-09 06:01:52 --> Router Class Initialized
INFO - 2023-01-09 06:01:52 --> Output Class Initialized
INFO - 2023-01-09 06:01:52 --> Security Class Initialized
DEBUG - 2023-01-09 06:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:01:52 --> Input Class Initialized
INFO - 2023-01-09 06:01:52 --> Language Class Initialized
INFO - 2023-01-09 06:01:52 --> Loader Class Initialized
INFO - 2023-01-09 06:01:52 --> Controller Class Initialized
INFO - 2023-01-09 06:01:52 --> Helper loaded: form_helper
INFO - 2023-01-09 06:01:52 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:01:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:01:52 --> Model "Change_model" initialized
INFO - 2023-01-09 06:20:42 --> Config Class Initialized
INFO - 2023-01-09 06:20:42 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:20:42 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:20:42 --> Utf8 Class Initialized
INFO - 2023-01-09 06:20:42 --> URI Class Initialized
INFO - 2023-01-09 06:20:42 --> Router Class Initialized
INFO - 2023-01-09 06:20:42 --> Output Class Initialized
INFO - 2023-01-09 06:20:42 --> Security Class Initialized
DEBUG - 2023-01-09 06:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:20:42 --> Input Class Initialized
INFO - 2023-01-09 06:20:42 --> Language Class Initialized
INFO - 2023-01-09 06:20:42 --> Loader Class Initialized
INFO - 2023-01-09 06:20:42 --> Controller Class Initialized
INFO - 2023-01-09 06:20:42 --> Helper loaded: form_helper
INFO - 2023-01-09 06:20:43 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:20:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:20:43 --> Model "Change_model" initialized
INFO - 2023-01-09 06:28:53 --> Config Class Initialized
INFO - 2023-01-09 06:28:53 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:28:53 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:28:53 --> Utf8 Class Initialized
INFO - 2023-01-09 06:28:53 --> URI Class Initialized
INFO - 2023-01-09 06:28:53 --> Router Class Initialized
INFO - 2023-01-09 06:28:53 --> Output Class Initialized
INFO - 2023-01-09 06:28:53 --> Security Class Initialized
DEBUG - 2023-01-09 06:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:28:53 --> Input Class Initialized
INFO - 2023-01-09 06:28:53 --> Language Class Initialized
INFO - 2023-01-09 06:28:53 --> Loader Class Initialized
INFO - 2023-01-09 06:28:53 --> Controller Class Initialized
INFO - 2023-01-09 06:28:53 --> Helper loaded: form_helper
INFO - 2023-01-09 06:28:53 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:28:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:28:53 --> Model "Change_model" initialized
INFO - 2023-01-09 06:31:03 --> Config Class Initialized
INFO - 2023-01-09 06:31:03 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:31:03 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:31:03 --> Utf8 Class Initialized
INFO - 2023-01-09 06:31:03 --> URI Class Initialized
INFO - 2023-01-09 06:31:03 --> Router Class Initialized
INFO - 2023-01-09 06:31:03 --> Output Class Initialized
INFO - 2023-01-09 06:31:03 --> Security Class Initialized
DEBUG - 2023-01-09 06:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:31:03 --> Input Class Initialized
INFO - 2023-01-09 06:31:03 --> Language Class Initialized
INFO - 2023-01-09 06:31:03 --> Loader Class Initialized
INFO - 2023-01-09 06:31:03 --> Controller Class Initialized
INFO - 2023-01-09 06:31:03 --> Helper loaded: form_helper
INFO - 2023-01-09 06:31:03 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:31:03 --> Model "Change_model" initialized
INFO - 2023-01-09 06:43:25 --> Config Class Initialized
INFO - 2023-01-09 06:43:25 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:43:25 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:43:25 --> Utf8 Class Initialized
INFO - 2023-01-09 06:43:25 --> URI Class Initialized
INFO - 2023-01-09 06:43:25 --> Router Class Initialized
INFO - 2023-01-09 06:43:25 --> Output Class Initialized
INFO - 2023-01-09 06:43:25 --> Security Class Initialized
DEBUG - 2023-01-09 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:43:25 --> Input Class Initialized
INFO - 2023-01-09 06:43:25 --> Language Class Initialized
INFO - 2023-01-09 06:43:25 --> Loader Class Initialized
INFO - 2023-01-09 06:43:25 --> Controller Class Initialized
INFO - 2023-01-09 06:43:25 --> Helper loaded: form_helper
INFO - 2023-01-09 06:43:25 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:43:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:43:25 --> Model "Change_model" initialized
INFO - 2023-01-09 06:44:06 --> Config Class Initialized
INFO - 2023-01-09 06:44:06 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:44:06 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:44:06 --> Utf8 Class Initialized
INFO - 2023-01-09 06:44:06 --> URI Class Initialized
INFO - 2023-01-09 06:44:06 --> Router Class Initialized
INFO - 2023-01-09 06:44:06 --> Output Class Initialized
INFO - 2023-01-09 06:44:06 --> Security Class Initialized
DEBUG - 2023-01-09 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:44:06 --> Input Class Initialized
INFO - 2023-01-09 06:44:06 --> Language Class Initialized
INFO - 2023-01-09 06:44:06 --> Loader Class Initialized
INFO - 2023-01-09 06:44:06 --> Controller Class Initialized
INFO - 2023-01-09 06:44:06 --> Helper loaded: form_helper
INFO - 2023-01-09 06:44:06 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:44:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:44:06 --> Model "Change_model" initialized
INFO - 2023-01-09 06:44:25 --> Config Class Initialized
INFO - 2023-01-09 06:44:25 --> Hooks Class Initialized
DEBUG - 2023-01-09 06:44:25 --> UTF-8 Support Enabled
INFO - 2023-01-09 06:44:25 --> Utf8 Class Initialized
INFO - 2023-01-09 06:44:25 --> URI Class Initialized
INFO - 2023-01-09 06:44:25 --> Router Class Initialized
INFO - 2023-01-09 06:44:25 --> Output Class Initialized
INFO - 2023-01-09 06:44:25 --> Security Class Initialized
DEBUG - 2023-01-09 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 06:44:25 --> Input Class Initialized
INFO - 2023-01-09 06:44:25 --> Language Class Initialized
INFO - 2023-01-09 06:44:25 --> Loader Class Initialized
INFO - 2023-01-09 06:44:25 --> Controller Class Initialized
INFO - 2023-01-09 06:44:25 --> Helper loaded: form_helper
INFO - 2023-01-09 06:44:25 --> Helper loaded: url_helper
DEBUG - 2023-01-09 06:44:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 06:44:25 --> Model "Change_model" initialized
INFO - 2023-01-09 07:34:43 --> Config Class Initialized
INFO - 2023-01-09 07:34:43 --> Hooks Class Initialized
DEBUG - 2023-01-09 07:34:43 --> UTF-8 Support Enabled
INFO - 2023-01-09 07:34:43 --> Utf8 Class Initialized
INFO - 2023-01-09 07:34:43 --> URI Class Initialized
INFO - 2023-01-09 07:34:43 --> Router Class Initialized
INFO - 2023-01-09 07:34:43 --> Output Class Initialized
INFO - 2023-01-09 07:34:43 --> Security Class Initialized
DEBUG - 2023-01-09 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 07:34:43 --> Input Class Initialized
INFO - 2023-01-09 07:34:43 --> Language Class Initialized
INFO - 2023-01-09 07:34:43 --> Loader Class Initialized
INFO - 2023-01-09 07:34:43 --> Controller Class Initialized
INFO - 2023-01-09 07:34:43 --> Helper loaded: form_helper
INFO - 2023-01-09 07:34:43 --> Helper loaded: url_helper
DEBUG - 2023-01-09 07:34:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 07:34:43 --> Model "Change_model" initialized
INFO - 2023-01-09 07:34:45 --> Config Class Initialized
INFO - 2023-01-09 07:34:45 --> Hooks Class Initialized
DEBUG - 2023-01-09 07:34:45 --> UTF-8 Support Enabled
INFO - 2023-01-09 07:34:45 --> Utf8 Class Initialized
INFO - 2023-01-09 07:34:45 --> URI Class Initialized
INFO - 2023-01-09 07:34:45 --> Router Class Initialized
INFO - 2023-01-09 07:34:45 --> Output Class Initialized
INFO - 2023-01-09 07:34:45 --> Security Class Initialized
DEBUG - 2023-01-09 07:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 07:34:45 --> Input Class Initialized
INFO - 2023-01-09 07:34:45 --> Language Class Initialized
INFO - 2023-01-09 07:34:45 --> Loader Class Initialized
INFO - 2023-01-09 07:34:45 --> Controller Class Initialized
INFO - 2023-01-09 07:34:45 --> Helper loaded: form_helper
INFO - 2023-01-09 07:34:45 --> Helper loaded: url_helper
DEBUG - 2023-01-09 07:34:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 07:34:45 --> Model "Change_model" initialized
INFO - 2023-01-09 07:35:46 --> Config Class Initialized
INFO - 2023-01-09 07:35:46 --> Hooks Class Initialized
DEBUG - 2023-01-09 07:35:46 --> UTF-8 Support Enabled
INFO - 2023-01-09 07:35:46 --> Utf8 Class Initialized
INFO - 2023-01-09 07:35:46 --> URI Class Initialized
INFO - 2023-01-09 07:35:46 --> Router Class Initialized
INFO - 2023-01-09 07:35:46 --> Output Class Initialized
INFO - 2023-01-09 07:35:46 --> Security Class Initialized
DEBUG - 2023-01-09 07:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 07:35:46 --> Input Class Initialized
INFO - 2023-01-09 07:35:46 --> Language Class Initialized
INFO - 2023-01-09 07:35:46 --> Loader Class Initialized
INFO - 2023-01-09 07:35:46 --> Controller Class Initialized
INFO - 2023-01-09 07:35:46 --> Helper loaded: form_helper
INFO - 2023-01-09 07:35:46 --> Helper loaded: url_helper
DEBUG - 2023-01-09 07:35:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 07:36:57 --> Config Class Initialized
INFO - 2023-01-09 07:36:57 --> Hooks Class Initialized
DEBUG - 2023-01-09 07:36:57 --> UTF-8 Support Enabled
INFO - 2023-01-09 07:36:57 --> Utf8 Class Initialized
INFO - 2023-01-09 07:36:57 --> URI Class Initialized
INFO - 2023-01-09 07:36:57 --> Router Class Initialized
INFO - 2023-01-09 07:36:57 --> Output Class Initialized
INFO - 2023-01-09 07:36:57 --> Security Class Initialized
DEBUG - 2023-01-09 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 07:36:57 --> Input Class Initialized
INFO - 2023-01-09 07:36:57 --> Language Class Initialized
INFO - 2023-01-09 07:36:57 --> Loader Class Initialized
INFO - 2023-01-09 07:36:57 --> Controller Class Initialized
INFO - 2023-01-09 07:36:57 --> Helper loaded: form_helper
INFO - 2023-01-09 07:36:57 --> Helper loaded: url_helper
DEBUG - 2023-01-09 07:36:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:39:16 --> Config Class Initialized
INFO - 2023-01-09 08:39:16 --> Hooks Class Initialized
DEBUG - 2023-01-09 08:39:16 --> UTF-8 Support Enabled
INFO - 2023-01-09 08:39:16 --> Utf8 Class Initialized
INFO - 2023-01-09 08:39:16 --> URI Class Initialized
INFO - 2023-01-09 08:39:16 --> Router Class Initialized
INFO - 2023-01-09 08:39:16 --> Output Class Initialized
INFO - 2023-01-09 08:39:16 --> Security Class Initialized
DEBUG - 2023-01-09 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 08:39:16 --> Input Class Initialized
INFO - 2023-01-09 08:39:16 --> Language Class Initialized
INFO - 2023-01-09 08:39:16 --> Loader Class Initialized
INFO - 2023-01-09 08:39:16 --> Controller Class Initialized
INFO - 2023-01-09 08:39:16 --> Helper loaded: form_helper
INFO - 2023-01-09 08:39:16 --> Helper loaded: url_helper
DEBUG - 2023-01-09 08:39:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:56:54 --> Config Class Initialized
INFO - 2023-01-09 08:56:54 --> Hooks Class Initialized
DEBUG - 2023-01-09 08:56:54 --> UTF-8 Support Enabled
INFO - 2023-01-09 08:56:54 --> Utf8 Class Initialized
INFO - 2023-01-09 08:56:54 --> URI Class Initialized
INFO - 2023-01-09 08:56:55 --> Router Class Initialized
INFO - 2023-01-09 08:56:55 --> Output Class Initialized
INFO - 2023-01-09 08:56:55 --> Security Class Initialized
DEBUG - 2023-01-09 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 08:56:55 --> Input Class Initialized
INFO - 2023-01-09 08:56:55 --> Language Class Initialized
INFO - 2023-01-09 08:56:55 --> Loader Class Initialized
INFO - 2023-01-09 08:56:55 --> Controller Class Initialized
INFO - 2023-01-09 08:56:55 --> Helper loaded: form_helper
INFO - 2023-01-09 08:56:55 --> Helper loaded: url_helper
DEBUG - 2023-01-09 08:56:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:57:00 --> Config Class Initialized
INFO - 2023-01-09 08:57:00 --> Hooks Class Initialized
DEBUG - 2023-01-09 08:57:00 --> UTF-8 Support Enabled
INFO - 2023-01-09 08:57:00 --> Utf8 Class Initialized
INFO - 2023-01-09 08:57:00 --> URI Class Initialized
INFO - 2023-01-09 08:57:00 --> Router Class Initialized
INFO - 2023-01-09 08:57:00 --> Output Class Initialized
INFO - 2023-01-09 08:57:00 --> Security Class Initialized
DEBUG - 2023-01-09 08:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 08:57:00 --> Input Class Initialized
INFO - 2023-01-09 08:57:00 --> Language Class Initialized
INFO - 2023-01-09 08:57:00 --> Loader Class Initialized
INFO - 2023-01-09 08:57:00 --> Controller Class Initialized
INFO - 2023-01-09 08:57:00 --> Helper loaded: form_helper
INFO - 2023-01-09 08:57:00 --> Helper loaded: url_helper
DEBUG - 2023-01-09 08:57:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:57:12 --> Config Class Initialized
INFO - 2023-01-09 08:57:12 --> Hooks Class Initialized
DEBUG - 2023-01-09 08:57:12 --> UTF-8 Support Enabled
INFO - 2023-01-09 08:57:12 --> Utf8 Class Initialized
INFO - 2023-01-09 08:57:12 --> URI Class Initialized
INFO - 2023-01-09 08:57:13 --> Router Class Initialized
INFO - 2023-01-09 08:57:13 --> Output Class Initialized
INFO - 2023-01-09 08:57:13 --> Security Class Initialized
DEBUG - 2023-01-09 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 08:57:13 --> Input Class Initialized
INFO - 2023-01-09 08:57:13 --> Language Class Initialized
INFO - 2023-01-09 08:57:13 --> Loader Class Initialized
INFO - 2023-01-09 08:57:13 --> Controller Class Initialized
INFO - 2023-01-09 08:57:13 --> Helper loaded: form_helper
INFO - 2023-01-09 08:57:13 --> Helper loaded: url_helper
DEBUG - 2023-01-09 08:57:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:57:13 --> Model "Change_model" initialized
INFO - 2023-01-09 08:58:41 --> Config Class Initialized
INFO - 2023-01-09 08:58:41 --> Hooks Class Initialized
DEBUG - 2023-01-09 08:58:42 --> UTF-8 Support Enabled
INFO - 2023-01-09 08:58:42 --> Utf8 Class Initialized
INFO - 2023-01-09 08:58:42 --> URI Class Initialized
INFO - 2023-01-09 08:58:42 --> Router Class Initialized
INFO - 2023-01-09 08:58:43 --> Output Class Initialized
INFO - 2023-01-09 08:58:43 --> Security Class Initialized
DEBUG - 2023-01-09 08:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 08:58:43 --> Input Class Initialized
INFO - 2023-01-09 08:58:44 --> Language Class Initialized
INFO - 2023-01-09 08:58:44 --> Loader Class Initialized
INFO - 2023-01-09 08:58:44 --> Controller Class Initialized
INFO - 2023-01-09 08:58:44 --> Helper loaded: form_helper
INFO - 2023-01-09 08:58:44 --> Helper loaded: url_helper
DEBUG - 2023-01-09 08:58:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 08:58:45 --> Model "Change_model" initialized
INFO - 2023-01-09 09:01:28 --> Config Class Initialized
INFO - 2023-01-09 09:01:28 --> Hooks Class Initialized
DEBUG - 2023-01-09 09:01:28 --> UTF-8 Support Enabled
INFO - 2023-01-09 09:01:28 --> Utf8 Class Initialized
INFO - 2023-01-09 09:01:28 --> URI Class Initialized
INFO - 2023-01-09 09:01:28 --> Router Class Initialized
INFO - 2023-01-09 09:01:28 --> Output Class Initialized
INFO - 2023-01-09 09:01:28 --> Security Class Initialized
DEBUG - 2023-01-09 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 09:01:28 --> Input Class Initialized
INFO - 2023-01-09 09:01:28 --> Language Class Initialized
INFO - 2023-01-09 09:01:28 --> Loader Class Initialized
INFO - 2023-01-09 09:01:28 --> Controller Class Initialized
INFO - 2023-01-09 09:01:28 --> Helper loaded: form_helper
INFO - 2023-01-09 09:01:28 --> Helper loaded: url_helper
DEBUG - 2023-01-09 09:01:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 09:01:29 --> Model "Change_model" initialized
INFO - 2023-01-09 09:04:29 --> Final output sent to browser
DEBUG - 2023-01-09 09:04:29 --> Total execution time: 180.6886
INFO - 2023-01-09 09:20:41 --> Config Class Initialized
INFO - 2023-01-09 09:20:41 --> Hooks Class Initialized
DEBUG - 2023-01-09 09:20:42 --> UTF-8 Support Enabled
INFO - 2023-01-09 09:20:42 --> Utf8 Class Initialized
INFO - 2023-01-09 09:20:42 --> URI Class Initialized
INFO - 2023-01-09 09:20:42 --> Router Class Initialized
INFO - 2023-01-09 09:20:42 --> Output Class Initialized
INFO - 2023-01-09 09:20:42 --> Security Class Initialized
DEBUG - 2023-01-09 09:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-09 09:20:42 --> Input Class Initialized
INFO - 2023-01-09 09:20:42 --> Language Class Initialized
INFO - 2023-01-09 09:20:42 --> Loader Class Initialized
INFO - 2023-01-09 09:20:42 --> Controller Class Initialized
INFO - 2023-01-09 09:20:42 --> Helper loaded: form_helper
INFO - 2023-01-09 09:20:42 --> Helper loaded: url_helper
DEBUG - 2023-01-09 09:20:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-09 09:20:42 --> Model "Change_model" initialized
INFO - 2023-01-09 09:23:43 --> Final output sent to browser
DEBUG - 2023-01-09 09:23:43 --> Total execution time: 181.1834
