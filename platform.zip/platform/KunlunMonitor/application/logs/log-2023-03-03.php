<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-03 04:27:32 --> Config Class Initialized
INFO - 2023-03-03 04:27:32 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:32 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:32 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:32 --> URI Class Initialized
INFO - 2023-03-03 04:27:32 --> Router Class Initialized
INFO - 2023-03-03 04:27:32 --> Output Class Initialized
INFO - 2023-03-03 04:27:32 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:32 --> Input Class Initialized
INFO - 2023-03-03 04:27:32 --> Language Class Initialized
INFO - 2023-03-03 04:27:32 --> Loader Class Initialized
INFO - 2023-03-03 04:27:32 --> Controller Class Initialized
INFO - 2023-03-03 04:27:33 --> Helper loaded: form_helper
INFO - 2023-03-03 04:27:33 --> Helper loaded: url_helper
DEBUG - 2023-03-03 04:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:33 --> Model "Change_model" initialized
INFO - 2023-03-03 04:27:33 --> Model "Grafana_model" initialized
INFO - 2023-03-03 04:27:33 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:33 --> Total execution time: 0.2605
INFO - 2023-03-03 04:27:33 --> Config Class Initialized
INFO - 2023-03-03 04:27:33 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:33 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:33 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:33 --> URI Class Initialized
INFO - 2023-03-03 04:27:33 --> Router Class Initialized
INFO - 2023-03-03 04:27:33 --> Output Class Initialized
INFO - 2023-03-03 04:27:33 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:33 --> Input Class Initialized
INFO - 2023-03-03 04:27:33 --> Language Class Initialized
INFO - 2023-03-03 04:27:33 --> Loader Class Initialized
INFO - 2023-03-03 04:27:33 --> Controller Class Initialized
INFO - 2023-03-03 04:27:33 --> Helper loaded: form_helper
INFO - 2023-03-03 04:27:33 --> Helper loaded: url_helper
DEBUG - 2023-03-03 04:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:33 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:33 --> Model "Login_model" initialized
INFO - 2023-03-03 04:27:33 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:33 --> Total execution time: 0.1824
INFO - 2023-03-03 04:27:33 --> Config Class Initialized
INFO - 2023-03-03 04:27:33 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:33 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:33 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:33 --> URI Class Initialized
INFO - 2023-03-03 04:27:33 --> Router Class Initialized
INFO - 2023-03-03 04:27:33 --> Output Class Initialized
INFO - 2023-03-03 04:27:33 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:33 --> Input Class Initialized
INFO - 2023-03-03 04:27:33 --> Language Class Initialized
INFO - 2023-03-03 04:27:33 --> Loader Class Initialized
INFO - 2023-03-03 04:27:33 --> Controller Class Initialized
DEBUG - 2023-03-03 04:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:33 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:33 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:27:35 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:35 --> Total execution time: 2.0316
INFO - 2023-03-03 04:27:35 --> Config Class Initialized
INFO - 2023-03-03 04:27:35 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:35 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:35 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:35 --> URI Class Initialized
INFO - 2023-03-03 04:27:35 --> Router Class Initialized
INFO - 2023-03-03 04:27:35 --> Output Class Initialized
INFO - 2023-03-03 04:27:35 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:35 --> Input Class Initialized
INFO - 2023-03-03 04:27:35 --> Language Class Initialized
INFO - 2023-03-03 04:27:35 --> Loader Class Initialized
INFO - 2023-03-03 04:27:35 --> Controller Class Initialized
DEBUG - 2023-03-03 04:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:35 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:35 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:27:35 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:35 --> Model "Login_model" initialized
INFO - 2023-03-03 04:27:35 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:35 --> Total execution time: 0.2231
INFO - 2023-03-03 04:27:54 --> Config Class Initialized
INFO - 2023-03-03 04:27:54 --> Config Class Initialized
INFO - 2023-03-03 04:27:54 --> Hooks Class Initialized
INFO - 2023-03-03 04:27:54 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:54 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:54 --> Utf8 Class Initialized
DEBUG - 2023-03-03 04:27:54 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:54 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:54 --> URI Class Initialized
INFO - 2023-03-03 04:27:54 --> URI Class Initialized
INFO - 2023-03-03 04:27:54 --> Router Class Initialized
INFO - 2023-03-03 04:27:54 --> Router Class Initialized
INFO - 2023-03-03 04:27:54 --> Output Class Initialized
INFO - 2023-03-03 04:27:54 --> Output Class Initialized
INFO - 2023-03-03 04:27:54 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:54 --> Security Class Initialized
INFO - 2023-03-03 04:27:54 --> Input Class Initialized
DEBUG - 2023-03-03 04:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:54 --> Language Class Initialized
INFO - 2023-03-03 04:27:54 --> Input Class Initialized
INFO - 2023-03-03 04:27:54 --> Loader Class Initialized
INFO - 2023-03-03 04:27:54 --> Language Class Initialized
INFO - 2023-03-03 04:27:54 --> Controller Class Initialized
INFO - 2023-03-03 04:27:54 --> Loader Class Initialized
DEBUG - 2023-03-03 04:27:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:54 --> Controller Class Initialized
DEBUG - 2023-03-03 04:27:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:54 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:54 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:27:54 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:54 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:54 --> Total execution time: 0.2509
INFO - 2023-03-03 04:27:54 --> Model "Login_model" initialized
INFO - 2023-03-03 04:27:54 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:54 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:27:54 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:54 --> Total execution time: 0.3455
INFO - 2023-03-03 04:27:56 --> Config Class Initialized
INFO - 2023-03-03 04:27:56 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:27:56 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:27:56 --> Utf8 Class Initialized
INFO - 2023-03-03 04:27:56 --> URI Class Initialized
INFO - 2023-03-03 04:27:56 --> Router Class Initialized
INFO - 2023-03-03 04:27:56 --> Output Class Initialized
INFO - 2023-03-03 04:27:56 --> Security Class Initialized
DEBUG - 2023-03-03 04:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:27:56 --> Input Class Initialized
INFO - 2023-03-03 04:27:56 --> Language Class Initialized
INFO - 2023-03-03 04:27:56 --> Loader Class Initialized
INFO - 2023-03-03 04:27:57 --> Controller Class Initialized
DEBUG - 2023-03-03 04:27:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:27:57 --> Database Driver Class Initialized
INFO - 2023-03-03 04:27:57 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:27:57 --> Final output sent to browser
DEBUG - 2023-03-03 04:27:57 --> Total execution time: 0.2154
INFO - 2023-03-03 04:28:00 --> Config Class Initialized
INFO - 2023-03-03 04:28:00 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:00 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:00 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:00 --> URI Class Initialized
INFO - 2023-03-03 04:28:00 --> Router Class Initialized
INFO - 2023-03-03 04:28:00 --> Output Class Initialized
INFO - 2023-03-03 04:28:00 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:00 --> Input Class Initialized
INFO - 2023-03-03 04:28:00 --> Language Class Initialized
INFO - 2023-03-03 04:28:00 --> Loader Class Initialized
INFO - 2023-03-03 04:28:00 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:00 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:00 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:00 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:00 --> Total execution time: 0.1761
INFO - 2023-03-03 04:28:04 --> Config Class Initialized
INFO - 2023-03-03 04:28:04 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:04 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:04 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:04 --> URI Class Initialized
INFO - 2023-03-03 04:28:04 --> Router Class Initialized
INFO - 2023-03-03 04:28:04 --> Output Class Initialized
INFO - 2023-03-03 04:28:04 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:04 --> Input Class Initialized
INFO - 2023-03-03 04:28:04 --> Language Class Initialized
INFO - 2023-03-03 04:28:04 --> Loader Class Initialized
INFO - 2023-03-03 04:28:04 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:04 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:04 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:04 --> Model "Login_model" initialized
INFO - 2023-03-03 04:28:04 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:04 --> Total execution time: 0.1777
INFO - 2023-03-03 04:28:07 --> Config Class Initialized
INFO - 2023-03-03 04:28:07 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:07 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:07 --> URI Class Initialized
INFO - 2023-03-03 04:28:07 --> Router Class Initialized
INFO - 2023-03-03 04:28:07 --> Output Class Initialized
INFO - 2023-03-03 04:28:07 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:07 --> Input Class Initialized
INFO - 2023-03-03 04:28:07 --> Language Class Initialized
INFO - 2023-03-03 04:28:07 --> Loader Class Initialized
INFO - 2023-03-03 04:28:07 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:07 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:07 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:07 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:07 --> Total execution time: 0.1601
INFO - 2023-03-03 04:28:09 --> Config Class Initialized
INFO - 2023-03-03 04:28:09 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:09 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:09 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:09 --> URI Class Initialized
INFO - 2023-03-03 04:28:09 --> Router Class Initialized
INFO - 2023-03-03 04:28:09 --> Output Class Initialized
INFO - 2023-03-03 04:28:09 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:09 --> Input Class Initialized
INFO - 2023-03-03 04:28:09 --> Language Class Initialized
INFO - 2023-03-03 04:28:09 --> Loader Class Initialized
INFO - 2023-03-03 04:28:09 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:09 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:09 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:09 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:09 --> Model "Login_model" initialized
INFO - 2023-03-03 04:28:09 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:09 --> Total execution time: 0.2067
INFO - 2023-03-03 04:28:13 --> Config Class Initialized
INFO - 2023-03-03 04:28:13 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:13 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:13 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:13 --> URI Class Initialized
INFO - 2023-03-03 04:28:13 --> Router Class Initialized
INFO - 2023-03-03 04:28:13 --> Output Class Initialized
INFO - 2023-03-03 04:28:13 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:13 --> Input Class Initialized
INFO - 2023-03-03 04:28:13 --> Language Class Initialized
INFO - 2023-03-03 04:28:13 --> Loader Class Initialized
INFO - 2023-03-03 04:28:13 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:13 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:13 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:13 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:13 --> Total execution time: 0.1600
INFO - 2023-03-03 04:28:16 --> Config Class Initialized
INFO - 2023-03-03 04:28:16 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:16 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:16 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:16 --> URI Class Initialized
INFO - 2023-03-03 04:28:16 --> Router Class Initialized
INFO - 2023-03-03 04:28:16 --> Output Class Initialized
INFO - 2023-03-03 04:28:16 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:16 --> Input Class Initialized
INFO - 2023-03-03 04:28:16 --> Language Class Initialized
INFO - 2023-03-03 04:28:16 --> Loader Class Initialized
INFO - 2023-03-03 04:28:16 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:16 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:16 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:16 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:16 --> Total execution time: 0.2215
INFO - 2023-03-03 04:28:17 --> Config Class Initialized
INFO - 2023-03-03 04:28:17 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:17 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:17 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:17 --> URI Class Initialized
INFO - 2023-03-03 04:28:17 --> Router Class Initialized
INFO - 2023-03-03 04:28:17 --> Output Class Initialized
INFO - 2023-03-03 04:28:17 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:17 --> Input Class Initialized
INFO - 2023-03-03 04:28:17 --> Language Class Initialized
INFO - 2023-03-03 04:28:17 --> Loader Class Initialized
INFO - 2023-03-03 04:28:17 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:17 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:17 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:17 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:17 --> Total execution time: 0.1598
INFO - 2023-03-03 04:28:18 --> Config Class Initialized
INFO - 2023-03-03 04:28:18 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:18 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:18 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:18 --> URI Class Initialized
INFO - 2023-03-03 04:28:18 --> Router Class Initialized
INFO - 2023-03-03 04:28:18 --> Output Class Initialized
INFO - 2023-03-03 04:28:18 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:18 --> Input Class Initialized
INFO - 2023-03-03 04:28:18 --> Language Class Initialized
INFO - 2023-03-03 04:28:18 --> Loader Class Initialized
INFO - 2023-03-03 04:28:18 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:18 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:18 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:18 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:18 --> Total execution time: 0.1480
INFO - 2023-03-03 04:28:18 --> Config Class Initialized
INFO - 2023-03-03 04:28:18 --> Config Class Initialized
INFO - 2023-03-03 04:28:18 --> Hooks Class Initialized
INFO - 2023-03-03 04:28:18 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 04:28:18 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:18 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:18 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:18 --> URI Class Initialized
INFO - 2023-03-03 04:28:18 --> URI Class Initialized
INFO - 2023-03-03 04:28:18 --> Router Class Initialized
INFO - 2023-03-03 04:28:18 --> Router Class Initialized
INFO - 2023-03-03 04:28:18 --> Output Class Initialized
INFO - 2023-03-03 04:28:18 --> Output Class Initialized
INFO - 2023-03-03 04:28:18 --> Security Class Initialized
INFO - 2023-03-03 04:28:18 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 04:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:18 --> Input Class Initialized
INFO - 2023-03-03 04:28:18 --> Input Class Initialized
INFO - 2023-03-03 04:28:18 --> Language Class Initialized
INFO - 2023-03-03 04:28:18 --> Language Class Initialized
INFO - 2023-03-03 04:28:18 --> Loader Class Initialized
INFO - 2023-03-03 04:28:18 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:18 --> Loader Class Initialized
INFO - 2023-03-03 04:28:18 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:18 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:18 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:18 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:18 --> Final output sent to browser
INFO - 2023-03-03 04:28:18 --> Model "Cluster_model" initialized
DEBUG - 2023-03-03 04:28:18 --> Total execution time: 0.2349
INFO - 2023-03-03 04:28:18 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:18 --> Total execution time: 0.2507
INFO - 2023-03-03 04:28:19 --> Config Class Initialized
INFO - 2023-03-03 04:28:19 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:19 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:19 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:19 --> URI Class Initialized
INFO - 2023-03-03 04:28:19 --> Router Class Initialized
INFO - 2023-03-03 04:28:19 --> Output Class Initialized
INFO - 2023-03-03 04:28:19 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:19 --> Input Class Initialized
INFO - 2023-03-03 04:28:19 --> Language Class Initialized
INFO - 2023-03-03 04:28:19 --> Loader Class Initialized
INFO - 2023-03-03 04:28:19 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:19 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:19 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:19 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:19 --> Total execution time: 0.2020
INFO - 2023-03-03 04:28:19 --> Config Class Initialized
INFO - 2023-03-03 04:28:19 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:19 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:19 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:19 --> URI Class Initialized
INFO - 2023-03-03 04:28:19 --> Router Class Initialized
INFO - 2023-03-03 04:28:19 --> Output Class Initialized
INFO - 2023-03-03 04:28:19 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:19 --> Input Class Initialized
INFO - 2023-03-03 04:28:19 --> Language Class Initialized
INFO - 2023-03-03 04:28:19 --> Loader Class Initialized
INFO - 2023-03-03 04:28:19 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:19 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:19 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:19 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:19 --> Total execution time: 0.1424
INFO - 2023-03-03 04:28:20 --> Config Class Initialized
INFO - 2023-03-03 04:28:20 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:20 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:20 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:20 --> URI Class Initialized
INFO - 2023-03-03 04:28:20 --> Router Class Initialized
INFO - 2023-03-03 04:28:20 --> Output Class Initialized
INFO - 2023-03-03 04:28:20 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:20 --> Input Class Initialized
INFO - 2023-03-03 04:28:20 --> Language Class Initialized
INFO - 2023-03-03 04:28:20 --> Loader Class Initialized
INFO - 2023-03-03 04:28:20 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:20 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:20 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:20 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:20 --> Total execution time: 0.1393
INFO - 2023-03-03 04:28:20 --> Config Class Initialized
INFO - 2023-03-03 04:28:20 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:20 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:20 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:20 --> URI Class Initialized
INFO - 2023-03-03 04:28:20 --> Router Class Initialized
INFO - 2023-03-03 04:28:20 --> Output Class Initialized
INFO - 2023-03-03 04:28:20 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:20 --> Input Class Initialized
INFO - 2023-03-03 04:28:20 --> Language Class Initialized
INFO - 2023-03-03 04:28:20 --> Loader Class Initialized
INFO - 2023-03-03 04:28:20 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:20 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:20 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:20 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:20 --> Total execution time: 0.1429
INFO - 2023-03-03 04:28:21 --> Config Class Initialized
INFO - 2023-03-03 04:28:21 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:21 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:21 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:21 --> URI Class Initialized
INFO - 2023-03-03 04:28:21 --> Router Class Initialized
INFO - 2023-03-03 04:28:21 --> Output Class Initialized
INFO - 2023-03-03 04:28:21 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:21 --> Input Class Initialized
INFO - 2023-03-03 04:28:21 --> Language Class Initialized
INFO - 2023-03-03 04:28:21 --> Loader Class Initialized
INFO - 2023-03-03 04:28:21 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:21 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:21 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:21 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:21 --> Total execution time: 0.1466
INFO - 2023-03-03 04:28:22 --> Config Class Initialized
INFO - 2023-03-03 04:28:22 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:22 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:22 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:22 --> URI Class Initialized
INFO - 2023-03-03 04:28:22 --> Router Class Initialized
INFO - 2023-03-03 04:28:22 --> Output Class Initialized
INFO - 2023-03-03 04:28:22 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:22 --> Input Class Initialized
INFO - 2023-03-03 04:28:22 --> Language Class Initialized
INFO - 2023-03-03 04:28:22 --> Loader Class Initialized
INFO - 2023-03-03 04:28:22 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:22 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:22 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:22 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:22 --> Total execution time: 0.1514
INFO - 2023-03-03 04:28:22 --> Config Class Initialized
INFO - 2023-03-03 04:28:22 --> Config Class Initialized
INFO - 2023-03-03 04:28:22 --> Hooks Class Initialized
INFO - 2023-03-03 04:28:22 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 04:28:22 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:22 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:22 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:22 --> URI Class Initialized
INFO - 2023-03-03 04:28:22 --> URI Class Initialized
INFO - 2023-03-03 04:28:22 --> Router Class Initialized
INFO - 2023-03-03 04:28:22 --> Router Class Initialized
INFO - 2023-03-03 04:28:22 --> Output Class Initialized
INFO - 2023-03-03 04:28:22 --> Output Class Initialized
INFO - 2023-03-03 04:28:22 --> Security Class Initialized
INFO - 2023-03-03 04:28:22 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 04:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:22 --> Input Class Initialized
INFO - 2023-03-03 04:28:22 --> Input Class Initialized
INFO - 2023-03-03 04:28:22 --> Language Class Initialized
INFO - 2023-03-03 04:28:22 --> Language Class Initialized
INFO - 2023-03-03 04:28:22 --> Loader Class Initialized
INFO - 2023-03-03 04:28:22 --> Controller Class Initialized
INFO - 2023-03-03 04:28:22 --> Loader Class Initialized
DEBUG - 2023-03-03 04:28:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:22 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:22 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:22 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:22 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:22 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:22 --> Total execution time: 0.2368
INFO - 2023-03-03 04:28:22 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:22 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:22 --> Total execution time: 0.2575
INFO - 2023-03-03 04:28:25 --> Config Class Initialized
INFO - 2023-03-03 04:28:25 --> Config Class Initialized
INFO - 2023-03-03 04:28:25 --> Hooks Class Initialized
INFO - 2023-03-03 04:28:25 --> Hooks Class Initialized
DEBUG - 2023-03-03 04:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 04:28:25 --> UTF-8 Support Enabled
INFO - 2023-03-03 04:28:25 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:25 --> Utf8 Class Initialized
INFO - 2023-03-03 04:28:25 --> URI Class Initialized
INFO - 2023-03-03 04:28:25 --> URI Class Initialized
INFO - 2023-03-03 04:28:25 --> Router Class Initialized
INFO - 2023-03-03 04:28:25 --> Router Class Initialized
INFO - 2023-03-03 04:28:26 --> Output Class Initialized
INFO - 2023-03-03 04:28:26 --> Output Class Initialized
INFO - 2023-03-03 04:28:26 --> Security Class Initialized
INFO - 2023-03-03 04:28:26 --> Security Class Initialized
DEBUG - 2023-03-03 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 04:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 04:28:26 --> Input Class Initialized
INFO - 2023-03-03 04:28:26 --> Input Class Initialized
INFO - 2023-03-03 04:28:26 --> Language Class Initialized
INFO - 2023-03-03 04:28:26 --> Language Class Initialized
INFO - 2023-03-03 04:28:26 --> Loader Class Initialized
INFO - 2023-03-03 04:28:26 --> Loader Class Initialized
INFO - 2023-03-03 04:28:26 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:26 --> Controller Class Initialized
DEBUG - 2023-03-03 04:28:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 04:28:26 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:26 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:26 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:26 --> Total execution time: 0.2203
INFO - 2023-03-03 04:28:26 --> Database Driver Class Initialized
INFO - 2023-03-03 04:28:26 --> Model "Cluster_model" initialized
INFO - 2023-03-03 04:28:26 --> Final output sent to browser
DEBUG - 2023-03-03 04:28:26 --> Total execution time: 0.2620
INFO - 2023-03-03 05:35:30 --> Config Class Initialized
INFO - 2023-03-03 05:35:30 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:35:30 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:35:30 --> Utf8 Class Initialized
INFO - 2023-03-03 05:35:30 --> URI Class Initialized
INFO - 2023-03-03 05:35:30 --> Router Class Initialized
INFO - 2023-03-03 05:35:30 --> Output Class Initialized
INFO - 2023-03-03 05:35:30 --> Security Class Initialized
DEBUG - 2023-03-03 05:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:35:30 --> Input Class Initialized
INFO - 2023-03-03 05:35:30 --> Language Class Initialized
INFO - 2023-03-03 05:35:30 --> Loader Class Initialized
INFO - 2023-03-03 05:35:30 --> Controller Class Initialized
DEBUG - 2023-03-03 05:35:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:35:30 --> Database Driver Class Initialized
INFO - 2023-03-03 05:35:30 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:35:30 --> Database Driver Class Initialized
INFO - 2023-03-03 05:35:30 --> Model "Login_model" initialized
INFO - 2023-03-03 05:35:30 --> Final output sent to browser
DEBUG - 2023-03-03 05:35:30 --> Total execution time: 0.3833
INFO - 2023-03-03 05:36:24 --> Config Class Initialized
INFO - 2023-03-03 05:36:24 --> Hooks Class Initialized
INFO - 2023-03-03 05:36:24 --> Config Class Initialized
INFO - 2023-03-03 05:36:24 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:36:24 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:36:24 --> Utf8 Class Initialized
DEBUG - 2023-03-03 05:36:24 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:36:24 --> Utf8 Class Initialized
INFO - 2023-03-03 05:36:24 --> URI Class Initialized
INFO - 2023-03-03 05:36:24 --> URI Class Initialized
INFO - 2023-03-03 05:36:24 --> Router Class Initialized
INFO - 2023-03-03 05:36:24 --> Router Class Initialized
INFO - 2023-03-03 05:36:24 --> Output Class Initialized
INFO - 2023-03-03 05:36:24 --> Output Class Initialized
INFO - 2023-03-03 05:36:24 --> Security Class Initialized
INFO - 2023-03-03 05:36:24 --> Security Class Initialized
DEBUG - 2023-03-03 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:36:24 --> Input Class Initialized
DEBUG - 2023-03-03 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:36:24 --> Language Class Initialized
INFO - 2023-03-03 05:36:24 --> Input Class Initialized
INFO - 2023-03-03 05:36:24 --> Language Class Initialized
INFO - 2023-03-03 05:36:24 --> Loader Class Initialized
INFO - 2023-03-03 05:36:24 --> Loader Class Initialized
INFO - 2023-03-03 05:36:24 --> Controller Class Initialized
DEBUG - 2023-03-03 05:36:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:36:24 --> Controller Class Initialized
DEBUG - 2023-03-03 05:36:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:36:24 --> Database Driver Class Initialized
INFO - 2023-03-03 05:36:24 --> Database Driver Class Initialized
INFO - 2023-03-03 05:36:24 --> Model "Login_model" initialized
INFO - 2023-03-03 05:36:24 --> Database Driver Class Initialized
INFO - 2023-03-03 05:36:24 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:36:24 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:36:25 --> Final output sent to browser
DEBUG - 2023-03-03 05:36:25 --> Total execution time: 0.2848
INFO - 2023-03-03 05:36:25 --> Final output sent to browser
DEBUG - 2023-03-03 05:36:25 --> Total execution time: 0.3089
INFO - 2023-03-03 05:48:30 --> Config Class Initialized
INFO - 2023-03-03 05:48:30 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:48:30 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:48:30 --> Utf8 Class Initialized
INFO - 2023-03-03 05:48:30 --> URI Class Initialized
INFO - 2023-03-03 05:48:30 --> Router Class Initialized
INFO - 2023-03-03 05:48:30 --> Output Class Initialized
INFO - 2023-03-03 05:48:30 --> Security Class Initialized
DEBUG - 2023-03-03 05:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:48:30 --> Input Class Initialized
INFO - 2023-03-03 05:48:30 --> Language Class Initialized
INFO - 2023-03-03 05:48:30 --> Loader Class Initialized
INFO - 2023-03-03 05:48:30 --> Controller Class Initialized
DEBUG - 2023-03-03 05:48:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:48:30 --> Database Driver Class Initialized
INFO - 2023-03-03 05:48:30 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:48:30 --> Final output sent to browser
DEBUG - 2023-03-03 05:48:30 --> Total execution time: 0.1556
INFO - 2023-03-03 05:48:32 --> Config Class Initialized
INFO - 2023-03-03 05:48:32 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:48:32 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:48:32 --> Utf8 Class Initialized
INFO - 2023-03-03 05:48:32 --> URI Class Initialized
INFO - 2023-03-03 05:48:32 --> Router Class Initialized
INFO - 2023-03-03 05:48:32 --> Output Class Initialized
INFO - 2023-03-03 05:48:32 --> Security Class Initialized
DEBUG - 2023-03-03 05:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:48:32 --> Input Class Initialized
INFO - 2023-03-03 05:48:32 --> Language Class Initialized
INFO - 2023-03-03 05:48:32 --> Loader Class Initialized
INFO - 2023-03-03 05:48:32 --> Controller Class Initialized
DEBUG - 2023-03-03 05:48:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:48:32 --> Database Driver Class Initialized
INFO - 2023-03-03 05:48:33 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:48:33 --> Final output sent to browser
DEBUG - 2023-03-03 05:48:33 --> Total execution time: 0.2028
INFO - 2023-03-03 05:49:07 --> Config Class Initialized
INFO - 2023-03-03 05:49:07 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:49:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:49:07 --> Utf8 Class Initialized
INFO - 2023-03-03 05:49:07 --> URI Class Initialized
INFO - 2023-03-03 05:49:07 --> Router Class Initialized
INFO - 2023-03-03 05:49:07 --> Output Class Initialized
INFO - 2023-03-03 05:49:07 --> Security Class Initialized
DEBUG - 2023-03-03 05:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:49:07 --> Input Class Initialized
INFO - 2023-03-03 05:49:07 --> Language Class Initialized
INFO - 2023-03-03 05:49:07 --> Loader Class Initialized
INFO - 2023-03-03 05:49:07 --> Controller Class Initialized
DEBUG - 2023-03-03 05:49:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:49:07 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:07 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:49:07 --> Final output sent to browser
DEBUG - 2023-03-03 05:49:07 --> Total execution time: 0.2881
INFO - 2023-03-03 05:49:10 --> Config Class Initialized
INFO - 2023-03-03 05:49:10 --> Hooks Class Initialized
INFO - 2023-03-03 05:49:10 --> Config Class Initialized
INFO - 2023-03-03 05:49:10 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:49:10 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:49:10 --> Utf8 Class Initialized
DEBUG - 2023-03-03 05:49:10 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:49:10 --> Utf8 Class Initialized
INFO - 2023-03-03 05:49:10 --> URI Class Initialized
INFO - 2023-03-03 05:49:10 --> URI Class Initialized
INFO - 2023-03-03 05:49:10 --> Router Class Initialized
INFO - 2023-03-03 05:49:10 --> Router Class Initialized
INFO - 2023-03-03 05:49:10 --> Output Class Initialized
INFO - 2023-03-03 05:49:10 --> Output Class Initialized
INFO - 2023-03-03 05:49:10 --> Security Class Initialized
INFO - 2023-03-03 05:49:10 --> Security Class Initialized
DEBUG - 2023-03-03 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:49:10 --> Input Class Initialized
DEBUG - 2023-03-03 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:49:10 --> Input Class Initialized
INFO - 2023-03-03 05:49:10 --> Language Class Initialized
INFO - 2023-03-03 05:49:10 --> Language Class Initialized
INFO - 2023-03-03 05:49:10 --> Loader Class Initialized
INFO - 2023-03-03 05:49:10 --> Controller Class Initialized
DEBUG - 2023-03-03 05:49:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:49:10 --> Loader Class Initialized
INFO - 2023-03-03 05:49:10 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:10 --> Controller Class Initialized
DEBUG - 2023-03-03 05:49:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:49:10 --> Model "Login_model" initialized
INFO - 2023-03-03 05:49:10 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:10 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:10 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:49:10 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:49:10 --> Final output sent to browser
DEBUG - 2023-03-03 05:49:10 --> Total execution time: 0.3306
INFO - 2023-03-03 05:49:10 --> Final output sent to browser
DEBUG - 2023-03-03 05:49:10 --> Total execution time: 0.3314
INFO - 2023-03-03 05:49:13 --> Config Class Initialized
INFO - 2023-03-03 05:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:49:13 --> Utf8 Class Initialized
INFO - 2023-03-03 05:49:13 --> URI Class Initialized
INFO - 2023-03-03 05:49:13 --> Router Class Initialized
INFO - 2023-03-03 05:49:13 --> Output Class Initialized
INFO - 2023-03-03 05:49:13 --> Security Class Initialized
DEBUG - 2023-03-03 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:49:13 --> Input Class Initialized
INFO - 2023-03-03 05:49:13 --> Language Class Initialized
INFO - 2023-03-03 05:49:13 --> Loader Class Initialized
INFO - 2023-03-03 05:49:13 --> Controller Class Initialized
DEBUG - 2023-03-03 05:49:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:49:13 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:13 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:49:13 --> Database Driver Class Initialized
INFO - 2023-03-03 05:49:13 --> Model "Login_model" initialized
INFO - 2023-03-03 05:49:13 --> Final output sent to browser
DEBUG - 2023-03-03 05:49:13 --> Total execution time: 0.2126
INFO - 2023-03-03 05:52:36 --> Config Class Initialized
INFO - 2023-03-03 05:52:36 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:52:36 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:52:36 --> Utf8 Class Initialized
INFO - 2023-03-03 05:52:36 --> URI Class Initialized
INFO - 2023-03-03 05:52:36 --> Router Class Initialized
INFO - 2023-03-03 05:52:36 --> Output Class Initialized
INFO - 2023-03-03 05:52:36 --> Security Class Initialized
DEBUG - 2023-03-03 05:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:52:36 --> Input Class Initialized
INFO - 2023-03-03 05:52:36 --> Language Class Initialized
INFO - 2023-03-03 05:52:36 --> Loader Class Initialized
INFO - 2023-03-03 05:52:36 --> Controller Class Initialized
DEBUG - 2023-03-03 05:52:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:52:36 --> Database Driver Class Initialized
INFO - 2023-03-03 05:52:36 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:52:36 --> Final output sent to browser
DEBUG - 2023-03-03 05:52:36 --> Total execution time: 0.1557
INFO - 2023-03-03 05:54:42 --> Config Class Initialized
INFO - 2023-03-03 05:54:42 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:42 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:42 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:42 --> URI Class Initialized
INFO - 2023-03-03 05:54:42 --> Router Class Initialized
INFO - 2023-03-03 05:54:42 --> Output Class Initialized
INFO - 2023-03-03 05:54:42 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:42 --> Input Class Initialized
INFO - 2023-03-03 05:54:42 --> Language Class Initialized
INFO - 2023-03-03 05:54:42 --> Loader Class Initialized
INFO - 2023-03-03 05:54:42 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:42 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:42 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:42 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:42 --> Total execution time: 0.2158
INFO - 2023-03-03 05:54:44 --> Config Class Initialized
INFO - 2023-03-03 05:54:44 --> Config Class Initialized
INFO - 2023-03-03 05:54:44 --> Hooks Class Initialized
INFO - 2023-03-03 05:54:44 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 05:54:44 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:44 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:44 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:44 --> URI Class Initialized
INFO - 2023-03-03 05:54:44 --> URI Class Initialized
INFO - 2023-03-03 05:54:44 --> Router Class Initialized
INFO - 2023-03-03 05:54:44 --> Router Class Initialized
INFO - 2023-03-03 05:54:44 --> Output Class Initialized
INFO - 2023-03-03 05:54:44 --> Output Class Initialized
INFO - 2023-03-03 05:54:44 --> Security Class Initialized
INFO - 2023-03-03 05:54:44 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 05:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:44 --> Input Class Initialized
INFO - 2023-03-03 05:54:44 --> Input Class Initialized
INFO - 2023-03-03 05:54:44 --> Language Class Initialized
INFO - 2023-03-03 05:54:44 --> Language Class Initialized
INFO - 2023-03-03 05:54:44 --> Loader Class Initialized
INFO - 2023-03-03 05:54:44 --> Loader Class Initialized
INFO - 2023-03-03 05:54:44 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:44 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:44 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:44 --> Model "Login_model" initialized
INFO - 2023-03-03 05:54:44 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:44 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:44 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:44 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:44 --> Total execution time: 0.2733
INFO - 2023-03-03 05:54:44 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:44 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:44 --> Total execution time: 0.2874
INFO - 2023-03-03 05:54:46 --> Config Class Initialized
INFO - 2023-03-03 05:54:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:46 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:46 --> URI Class Initialized
INFO - 2023-03-03 05:54:46 --> Router Class Initialized
INFO - 2023-03-03 05:54:46 --> Output Class Initialized
INFO - 2023-03-03 05:54:46 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:46 --> Input Class Initialized
INFO - 2023-03-03 05:54:46 --> Language Class Initialized
INFO - 2023-03-03 05:54:46 --> Loader Class Initialized
INFO - 2023-03-03 05:54:46 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:46 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:46 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:46 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:46 --> Total execution time: 0.1909
INFO - 2023-03-03 05:54:49 --> Config Class Initialized
INFO - 2023-03-03 05:54:49 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:50 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:50 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:50 --> URI Class Initialized
INFO - 2023-03-03 05:54:50 --> Router Class Initialized
INFO - 2023-03-03 05:54:50 --> Output Class Initialized
INFO - 2023-03-03 05:54:50 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:50 --> Input Class Initialized
INFO - 2023-03-03 05:54:50 --> Language Class Initialized
INFO - 2023-03-03 05:54:50 --> Loader Class Initialized
INFO - 2023-03-03 05:54:50 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:50 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:50 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:50 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:50 --> Total execution time: 0.1464
INFO - 2023-03-03 05:54:56 --> Config Class Initialized
INFO - 2023-03-03 05:54:56 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:56 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:56 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:56 --> URI Class Initialized
INFO - 2023-03-03 05:54:56 --> Router Class Initialized
INFO - 2023-03-03 05:54:56 --> Output Class Initialized
INFO - 2023-03-03 05:54:56 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:56 --> Input Class Initialized
INFO - 2023-03-03 05:54:56 --> Language Class Initialized
INFO - 2023-03-03 05:54:56 --> Loader Class Initialized
INFO - 2023-03-03 05:54:56 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:56 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:56 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:56 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:56 --> Total execution time: 0.1990
INFO - 2023-03-03 05:54:59 --> Config Class Initialized
INFO - 2023-03-03 05:54:59 --> Config Class Initialized
INFO - 2023-03-03 05:54:59 --> Hooks Class Initialized
INFO - 2023-03-03 05:54:59 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:54:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 05:54:59 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:54:59 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:59 --> Utf8 Class Initialized
INFO - 2023-03-03 05:54:59 --> URI Class Initialized
INFO - 2023-03-03 05:54:59 --> URI Class Initialized
INFO - 2023-03-03 05:54:59 --> Router Class Initialized
INFO - 2023-03-03 05:54:59 --> Router Class Initialized
INFO - 2023-03-03 05:54:59 --> Output Class Initialized
INFO - 2023-03-03 05:54:59 --> Output Class Initialized
INFO - 2023-03-03 05:54:59 --> Security Class Initialized
INFO - 2023-03-03 05:54:59 --> Security Class Initialized
DEBUG - 2023-03-03 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:59 --> Input Class Initialized
DEBUG - 2023-03-03 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:54:59 --> Input Class Initialized
INFO - 2023-03-03 05:54:59 --> Language Class Initialized
INFO - 2023-03-03 05:54:59 --> Language Class Initialized
INFO - 2023-03-03 05:54:59 --> Loader Class Initialized
INFO - 2023-03-03 05:54:59 --> Controller Class Initialized
INFO - 2023-03-03 05:54:59 --> Loader Class Initialized
DEBUG - 2023-03-03 05:54:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:59 --> Controller Class Initialized
DEBUG - 2023-03-03 05:54:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:54:59 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:59 --> Model "Login_model" initialized
INFO - 2023-03-03 05:54:59 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:59 --> Database Driver Class Initialized
INFO - 2023-03-03 05:54:59 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:59 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:54:59 --> Final output sent to browser
INFO - 2023-03-03 05:54:59 --> Final output sent to browser
DEBUG - 2023-03-03 05:54:59 --> Total execution time: 0.2683
DEBUG - 2023-03-03 05:54:59 --> Total execution time: 0.2690
INFO - 2023-03-03 05:55:03 --> Config Class Initialized
INFO - 2023-03-03 05:55:03 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:03 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:03 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:03 --> URI Class Initialized
INFO - 2023-03-03 05:55:03 --> Router Class Initialized
INFO - 2023-03-03 05:55:03 --> Output Class Initialized
INFO - 2023-03-03 05:55:03 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:03 --> Input Class Initialized
INFO - 2023-03-03 05:55:03 --> Language Class Initialized
INFO - 2023-03-03 05:55:03 --> Loader Class Initialized
INFO - 2023-03-03 05:55:03 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:03 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:03 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:03 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:03 --> Total execution time: 0.2004
INFO - 2023-03-03 05:55:17 --> Config Class Initialized
INFO - 2023-03-03 05:55:17 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:17 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:17 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:17 --> URI Class Initialized
INFO - 2023-03-03 05:55:17 --> Router Class Initialized
INFO - 2023-03-03 05:55:17 --> Output Class Initialized
INFO - 2023-03-03 05:55:17 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:17 --> Input Class Initialized
INFO - 2023-03-03 05:55:17 --> Language Class Initialized
INFO - 2023-03-03 05:55:17 --> Loader Class Initialized
INFO - 2023-03-03 05:55:17 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:17 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:17 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:17 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:17 --> Total execution time: 0.1411
INFO - 2023-03-03 05:55:19 --> Config Class Initialized
INFO - 2023-03-03 05:55:19 --> Config Class Initialized
INFO - 2023-03-03 05:55:19 --> Hooks Class Initialized
INFO - 2023-03-03 05:55:19 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 05:55:19 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:19 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:19 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:19 --> URI Class Initialized
INFO - 2023-03-03 05:55:19 --> URI Class Initialized
INFO - 2023-03-03 05:55:19 --> Router Class Initialized
INFO - 2023-03-03 05:55:19 --> Router Class Initialized
INFO - 2023-03-03 05:55:19 --> Output Class Initialized
INFO - 2023-03-03 05:55:19 --> Output Class Initialized
INFO - 2023-03-03 05:55:19 --> Security Class Initialized
INFO - 2023-03-03 05:55:19 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 05:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:19 --> Input Class Initialized
INFO - 2023-03-03 05:55:19 --> Input Class Initialized
INFO - 2023-03-03 05:55:19 --> Language Class Initialized
INFO - 2023-03-03 05:55:19 --> Language Class Initialized
INFO - 2023-03-03 05:55:19 --> Loader Class Initialized
INFO - 2023-03-03 05:55:19 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:19 --> Loader Class Initialized
INFO - 2023-03-03 05:55:19 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:19 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:19 --> Model "Login_model" initialized
INFO - 2023-03-03 05:55:19 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:19 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:19 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:19 --> Final output sent to browser
INFO - 2023-03-03 05:55:19 --> Model "Cluster_model" initialized
DEBUG - 2023-03-03 05:55:19 --> Total execution time: 0.3862
INFO - 2023-03-03 05:55:19 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:19 --> Total execution time: 0.3976
INFO - 2023-03-03 05:55:44 --> Config Class Initialized
INFO - 2023-03-03 05:55:44 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:44 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:44 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:44 --> URI Class Initialized
INFO - 2023-03-03 05:55:44 --> Router Class Initialized
INFO - 2023-03-03 05:55:44 --> Output Class Initialized
INFO - 2023-03-03 05:55:44 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:44 --> Input Class Initialized
INFO - 2023-03-03 05:55:44 --> Language Class Initialized
INFO - 2023-03-03 05:55:44 --> Loader Class Initialized
INFO - 2023-03-03 05:55:44 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:44 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:44 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:44 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:44 --> Total execution time: 0.1751
INFO - 2023-03-03 05:55:44 --> Config Class Initialized
INFO - 2023-03-03 05:55:44 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:44 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:44 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:44 --> URI Class Initialized
INFO - 2023-03-03 05:55:44 --> Router Class Initialized
INFO - 2023-03-03 05:55:44 --> Output Class Initialized
INFO - 2023-03-03 05:55:44 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:44 --> Input Class Initialized
INFO - 2023-03-03 05:55:45 --> Language Class Initialized
INFO - 2023-03-03 05:55:45 --> Loader Class Initialized
INFO - 2023-03-03 05:55:45 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:45 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:45 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:45 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:45 --> Total execution time: 0.2046
INFO - 2023-03-03 05:55:46 --> Config Class Initialized
INFO - 2023-03-03 05:55:46 --> Config Class Initialized
INFO - 2023-03-03 05:55:46 --> Hooks Class Initialized
INFO - 2023-03-03 05:55:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:46 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 05:55:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:46 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:46 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:46 --> URI Class Initialized
INFO - 2023-03-03 05:55:46 --> URI Class Initialized
INFO - 2023-03-03 05:55:46 --> Router Class Initialized
INFO - 2023-03-03 05:55:46 --> Router Class Initialized
INFO - 2023-03-03 05:55:46 --> Output Class Initialized
INFO - 2023-03-03 05:55:46 --> Output Class Initialized
INFO - 2023-03-03 05:55:46 --> Security Class Initialized
INFO - 2023-03-03 05:55:46 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 05:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:46 --> Input Class Initialized
INFO - 2023-03-03 05:55:46 --> Input Class Initialized
INFO - 2023-03-03 05:55:46 --> Language Class Initialized
INFO - 2023-03-03 05:55:46 --> Language Class Initialized
INFO - 2023-03-03 05:55:46 --> Loader Class Initialized
INFO - 2023-03-03 05:55:46 --> Loader Class Initialized
INFO - 2023-03-03 05:55:47 --> Controller Class Initialized
INFO - 2023-03-03 05:55:47 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-03 05:55:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:47 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:47 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:47 --> Model "Login_model" initialized
INFO - 2023-03-03 05:55:47 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:47 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:47 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:47 --> Total execution time: 0.2666
INFO - 2023-03-03 05:55:47 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:47 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:47 --> Total execution time: 0.2882
INFO - 2023-03-03 05:55:53 --> Config Class Initialized
INFO - 2023-03-03 05:55:53 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:55:53 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:55:53 --> Utf8 Class Initialized
INFO - 2023-03-03 05:55:53 --> URI Class Initialized
INFO - 2023-03-03 05:55:53 --> Router Class Initialized
INFO - 2023-03-03 05:55:53 --> Output Class Initialized
INFO - 2023-03-03 05:55:53 --> Security Class Initialized
DEBUG - 2023-03-03 05:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:55:53 --> Input Class Initialized
INFO - 2023-03-03 05:55:53 --> Language Class Initialized
INFO - 2023-03-03 05:55:53 --> Loader Class Initialized
INFO - 2023-03-03 05:55:53 --> Controller Class Initialized
DEBUG - 2023-03-03 05:55:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:55:53 --> Database Driver Class Initialized
INFO - 2023-03-03 05:55:53 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:55:53 --> Final output sent to browser
DEBUG - 2023-03-03 05:55:53 --> Total execution time: 0.1878
INFO - 2023-03-03 05:56:01 --> Config Class Initialized
INFO - 2023-03-03 05:56:01 --> Hooks Class Initialized
INFO - 2023-03-03 05:56:01 --> Config Class Initialized
INFO - 2023-03-03 05:56:01 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:56:01 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:01 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:01 --> URI Class Initialized
DEBUG - 2023-03-03 05:56:01 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:01 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:01 --> Router Class Initialized
INFO - 2023-03-03 05:56:01 --> URI Class Initialized
INFO - 2023-03-03 05:56:01 --> Output Class Initialized
INFO - 2023-03-03 05:56:01 --> Router Class Initialized
INFO - 2023-03-03 05:56:01 --> Security Class Initialized
INFO - 2023-03-03 05:56:01 --> Output Class Initialized
DEBUG - 2023-03-03 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:01 --> Security Class Initialized
INFO - 2023-03-03 05:56:01 --> Input Class Initialized
DEBUG - 2023-03-03 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:01 --> Language Class Initialized
INFO - 2023-03-03 05:56:01 --> Input Class Initialized
INFO - 2023-03-03 05:56:01 --> Language Class Initialized
INFO - 2023-03-03 05:56:01 --> Loader Class Initialized
INFO - 2023-03-03 05:56:01 --> Controller Class Initialized
INFO - 2023-03-03 05:56:01 --> Loader Class Initialized
DEBUG - 2023-03-03 05:56:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:01 --> Controller Class Initialized
DEBUG - 2023-03-03 05:56:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:01 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:01 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:01 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:01 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:01 --> Total execution time: 0.2501
INFO - 2023-03-03 05:56:01 --> Model "Login_model" initialized
INFO - 2023-03-03 05:56:01 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:01 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:01 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:01 --> Total execution time: 0.2717
INFO - 2023-03-03 05:56:37 --> Config Class Initialized
INFO - 2023-03-03 05:56:37 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:56:37 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:37 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:37 --> URI Class Initialized
INFO - 2023-03-03 05:56:37 --> Router Class Initialized
INFO - 2023-03-03 05:56:37 --> Output Class Initialized
INFO - 2023-03-03 05:56:37 --> Security Class Initialized
DEBUG - 2023-03-03 05:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:37 --> Input Class Initialized
INFO - 2023-03-03 05:56:37 --> Language Class Initialized
INFO - 2023-03-03 05:56:37 --> Loader Class Initialized
INFO - 2023-03-03 05:56:37 --> Controller Class Initialized
DEBUG - 2023-03-03 05:56:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:37 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:37 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:37 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:37 --> Model "Login_model" initialized
INFO - 2023-03-03 05:56:37 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:37 --> Total execution time: 0.2404
INFO - 2023-03-03 05:56:48 --> Config Class Initialized
INFO - 2023-03-03 05:56:48 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:56:48 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:48 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:48 --> URI Class Initialized
INFO - 2023-03-03 05:56:48 --> Router Class Initialized
INFO - 2023-03-03 05:56:48 --> Output Class Initialized
INFO - 2023-03-03 05:56:48 --> Security Class Initialized
DEBUG - 2023-03-03 05:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:48 --> Input Class Initialized
INFO - 2023-03-03 05:56:48 --> Language Class Initialized
INFO - 2023-03-03 05:56:48 --> Loader Class Initialized
INFO - 2023-03-03 05:56:48 --> Controller Class Initialized
DEBUG - 2023-03-03 05:56:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:48 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:48 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:48 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:49 --> Model "Login_model" initialized
INFO - 2023-03-03 05:56:49 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:49 --> Total execution time: 0.2786
INFO - 2023-03-03 05:56:52 --> Config Class Initialized
INFO - 2023-03-03 05:56:52 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:56:52 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:52 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:52 --> URI Class Initialized
INFO - 2023-03-03 05:56:52 --> Router Class Initialized
INFO - 2023-03-03 05:56:52 --> Output Class Initialized
INFO - 2023-03-03 05:56:52 --> Security Class Initialized
DEBUG - 2023-03-03 05:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:52 --> Input Class Initialized
INFO - 2023-03-03 05:56:52 --> Language Class Initialized
INFO - 2023-03-03 05:56:52 --> Loader Class Initialized
INFO - 2023-03-03 05:56:52 --> Controller Class Initialized
DEBUG - 2023-03-03 05:56:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:52 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:52 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:52 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:53 --> Model "Login_model" initialized
INFO - 2023-03-03 05:56:53 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:53 --> Total execution time: 0.2491
INFO - 2023-03-03 05:56:56 --> Config Class Initialized
INFO - 2023-03-03 05:56:56 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:56:56 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:56:56 --> Utf8 Class Initialized
INFO - 2023-03-03 05:56:56 --> URI Class Initialized
INFO - 2023-03-03 05:56:56 --> Router Class Initialized
INFO - 2023-03-03 05:56:56 --> Output Class Initialized
INFO - 2023-03-03 05:56:56 --> Security Class Initialized
DEBUG - 2023-03-03 05:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:56:56 --> Input Class Initialized
INFO - 2023-03-03 05:56:56 --> Language Class Initialized
INFO - 2023-03-03 05:56:56 --> Loader Class Initialized
INFO - 2023-03-03 05:56:56 --> Controller Class Initialized
DEBUG - 2023-03-03 05:56:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:56:56 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:56 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:56:56 --> Database Driver Class Initialized
INFO - 2023-03-03 05:56:56 --> Model "Login_model" initialized
INFO - 2023-03-03 05:56:56 --> Final output sent to browser
DEBUG - 2023-03-03 05:56:56 --> Total execution time: 0.2407
INFO - 2023-03-03 05:57:00 --> Config Class Initialized
INFO - 2023-03-03 05:57:00 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:57:00 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:57:00 --> Utf8 Class Initialized
INFO - 2023-03-03 05:57:00 --> URI Class Initialized
INFO - 2023-03-03 05:57:00 --> Router Class Initialized
INFO - 2023-03-03 05:57:00 --> Output Class Initialized
INFO - 2023-03-03 05:57:00 --> Security Class Initialized
DEBUG - 2023-03-03 05:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:57:00 --> Input Class Initialized
INFO - 2023-03-03 05:57:00 --> Language Class Initialized
INFO - 2023-03-03 05:57:00 --> Loader Class Initialized
INFO - 2023-03-03 05:57:00 --> Controller Class Initialized
DEBUG - 2023-03-03 05:57:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:57:00 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:00 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:57:00 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:00 --> Model "Login_model" initialized
INFO - 2023-03-03 05:57:00 --> Final output sent to browser
DEBUG - 2023-03-03 05:57:00 --> Total execution time: 0.1859
INFO - 2023-03-03 05:57:04 --> Config Class Initialized
INFO - 2023-03-03 05:57:04 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:57:04 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:57:04 --> Utf8 Class Initialized
INFO - 2023-03-03 05:57:04 --> URI Class Initialized
INFO - 2023-03-03 05:57:04 --> Router Class Initialized
INFO - 2023-03-03 05:57:04 --> Output Class Initialized
INFO - 2023-03-03 05:57:04 --> Security Class Initialized
DEBUG - 2023-03-03 05:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:57:04 --> Input Class Initialized
INFO - 2023-03-03 05:57:04 --> Language Class Initialized
INFO - 2023-03-03 05:57:05 --> Loader Class Initialized
INFO - 2023-03-03 05:57:05 --> Controller Class Initialized
DEBUG - 2023-03-03 05:57:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:57:05 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:05 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:57:05 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:05 --> Model "Login_model" initialized
INFO - 2023-03-03 05:57:05 --> Final output sent to browser
DEBUG - 2023-03-03 05:57:05 --> Total execution time: 0.2515
INFO - 2023-03-03 05:57:07 --> Config Class Initialized
INFO - 2023-03-03 05:57:07 --> Hooks Class Initialized
DEBUG - 2023-03-03 05:57:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 05:57:07 --> Utf8 Class Initialized
INFO - 2023-03-03 05:57:07 --> URI Class Initialized
INFO - 2023-03-03 05:57:07 --> Router Class Initialized
INFO - 2023-03-03 05:57:07 --> Output Class Initialized
INFO - 2023-03-03 05:57:07 --> Security Class Initialized
DEBUG - 2023-03-03 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 05:57:07 --> Input Class Initialized
INFO - 2023-03-03 05:57:07 --> Language Class Initialized
INFO - 2023-03-03 05:57:07 --> Loader Class Initialized
INFO - 2023-03-03 05:57:08 --> Controller Class Initialized
DEBUG - 2023-03-03 05:57:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 05:57:08 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:08 --> Model "Cluster_model" initialized
INFO - 2023-03-03 05:57:08 --> Database Driver Class Initialized
INFO - 2023-03-03 05:57:08 --> Model "Login_model" initialized
INFO - 2023-03-03 05:57:08 --> Final output sent to browser
DEBUG - 2023-03-03 05:57:08 --> Total execution time: 0.2597
INFO - 2023-03-03 06:10:22 --> Config Class Initialized
INFO - 2023-03-03 06:10:22 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:10:22 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:10:22 --> Utf8 Class Initialized
INFO - 2023-03-03 06:10:22 --> URI Class Initialized
INFO - 2023-03-03 06:10:22 --> Router Class Initialized
INFO - 2023-03-03 06:10:22 --> Output Class Initialized
INFO - 2023-03-03 06:10:22 --> Security Class Initialized
DEBUG - 2023-03-03 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:10:22 --> Input Class Initialized
INFO - 2023-03-03 06:10:22 --> Language Class Initialized
INFO - 2023-03-03 06:10:22 --> Loader Class Initialized
INFO - 2023-03-03 06:10:22 --> Controller Class Initialized
DEBUG - 2023-03-03 06:10:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:10:22 --> Database Driver Class Initialized
INFO - 2023-03-03 06:10:22 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:10:22 --> Final output sent to browser
DEBUG - 2023-03-03 06:10:22 --> Total execution time: 0.1958
INFO - 2023-03-03 06:10:23 --> Config Class Initialized
INFO - 2023-03-03 06:10:23 --> Config Class Initialized
INFO - 2023-03-03 06:10:23 --> Hooks Class Initialized
INFO - 2023-03-03 06:10:23 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 06:10:23 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:10:23 --> Utf8 Class Initialized
INFO - 2023-03-03 06:10:23 --> Utf8 Class Initialized
INFO - 2023-03-03 06:10:23 --> URI Class Initialized
INFO - 2023-03-03 06:10:23 --> URI Class Initialized
INFO - 2023-03-03 06:10:23 --> Router Class Initialized
INFO - 2023-03-03 06:10:23 --> Router Class Initialized
INFO - 2023-03-03 06:10:23 --> Output Class Initialized
INFO - 2023-03-03 06:10:23 --> Output Class Initialized
INFO - 2023-03-03 06:10:23 --> Security Class Initialized
INFO - 2023-03-03 06:10:23 --> Security Class Initialized
DEBUG - 2023-03-03 06:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 06:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:10:23 --> Input Class Initialized
INFO - 2023-03-03 06:10:23 --> Input Class Initialized
INFO - 2023-03-03 06:10:23 --> Language Class Initialized
INFO - 2023-03-03 06:10:23 --> Language Class Initialized
INFO - 2023-03-03 06:10:23 --> Loader Class Initialized
INFO - 2023-03-03 06:10:23 --> Controller Class Initialized
INFO - 2023-03-03 06:10:23 --> Loader Class Initialized
DEBUG - 2023-03-03 06:10:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:10:23 --> Controller Class Initialized
DEBUG - 2023-03-03 06:10:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:10:23 --> Database Driver Class Initialized
INFO - 2023-03-03 06:10:23 --> Model "Login_model" initialized
INFO - 2023-03-03 06:10:23 --> Database Driver Class Initialized
INFO - 2023-03-03 06:10:23 --> Database Driver Class Initialized
INFO - 2023-03-03 06:10:23 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:10:23 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:10:23 --> Final output sent to browser
DEBUG - 2023-03-03 06:10:23 --> Total execution time: 0.2470
INFO - 2023-03-03 06:10:23 --> Final output sent to browser
DEBUG - 2023-03-03 06:10:23 --> Total execution time: 0.2630
INFO - 2023-03-03 06:15:37 --> Config Class Initialized
INFO - 2023-03-03 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:37 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:37 --> URI Class Initialized
INFO - 2023-03-03 06:15:37 --> Router Class Initialized
INFO - 2023-03-03 06:15:37 --> Output Class Initialized
INFO - 2023-03-03 06:15:37 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:37 --> Input Class Initialized
INFO - 2023-03-03 06:15:37 --> Language Class Initialized
INFO - 2023-03-03 06:15:37 --> Loader Class Initialized
INFO - 2023-03-03 06:15:37 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:37 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:37 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:38 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:38 --> Total execution time: 0.2568
INFO - 2023-03-03 06:15:42 --> Config Class Initialized
INFO - 2023-03-03 06:15:42 --> Config Class Initialized
INFO - 2023-03-03 06:15:42 --> Hooks Class Initialized
INFO - 2023-03-03 06:15:42 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:42 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 06:15:42 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:42 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:42 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:42 --> URI Class Initialized
INFO - 2023-03-03 06:15:42 --> URI Class Initialized
INFO - 2023-03-03 06:15:42 --> Router Class Initialized
INFO - 2023-03-03 06:15:42 --> Router Class Initialized
INFO - 2023-03-03 06:15:42 --> Output Class Initialized
INFO - 2023-03-03 06:15:42 --> Output Class Initialized
INFO - 2023-03-03 06:15:42 --> Security Class Initialized
INFO - 2023-03-03 06:15:42 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 06:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:42 --> Input Class Initialized
INFO - 2023-03-03 06:15:42 --> Input Class Initialized
INFO - 2023-03-03 06:15:42 --> Language Class Initialized
INFO - 2023-03-03 06:15:42 --> Language Class Initialized
INFO - 2023-03-03 06:15:42 --> Loader Class Initialized
INFO - 2023-03-03 06:15:42 --> Controller Class Initialized
INFO - 2023-03-03 06:15:42 --> Loader Class Initialized
DEBUG - 2023-03-03 06:15:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:42 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:42 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:42 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:42 --> Model "Login_model" initialized
INFO - 2023-03-03 06:15:42 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:42 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:42 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:42 --> Total execution time: 0.2697
INFO - 2023-03-03 06:15:42 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:42 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:42 --> Total execution time: 0.3201
INFO - 2023-03-03 06:15:44 --> Config Class Initialized
INFO - 2023-03-03 06:15:44 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:44 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:44 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:44 --> URI Class Initialized
INFO - 2023-03-03 06:15:44 --> Router Class Initialized
INFO - 2023-03-03 06:15:44 --> Output Class Initialized
INFO - 2023-03-03 06:15:44 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:45 --> Input Class Initialized
INFO - 2023-03-03 06:15:45 --> Language Class Initialized
INFO - 2023-03-03 06:15:45 --> Loader Class Initialized
INFO - 2023-03-03 06:15:45 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:45 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:45 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:45 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:45 --> Total execution time: 0.2998
INFO - 2023-03-03 06:15:46 --> Config Class Initialized
INFO - 2023-03-03 06:15:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:46 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:46 --> URI Class Initialized
INFO - 2023-03-03 06:15:46 --> Router Class Initialized
INFO - 2023-03-03 06:15:46 --> Output Class Initialized
INFO - 2023-03-03 06:15:46 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:46 --> Input Class Initialized
INFO - 2023-03-03 06:15:46 --> Language Class Initialized
INFO - 2023-03-03 06:15:46 --> Loader Class Initialized
INFO - 2023-03-03 06:15:46 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:46 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:46 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:46 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:46 --> Total execution time: 0.1629
INFO - 2023-03-03 06:15:49 --> Config Class Initialized
INFO - 2023-03-03 06:15:49 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:49 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:49 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:49 --> URI Class Initialized
INFO - 2023-03-03 06:15:49 --> Router Class Initialized
INFO - 2023-03-03 06:15:49 --> Output Class Initialized
INFO - 2023-03-03 06:15:49 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:49 --> Input Class Initialized
INFO - 2023-03-03 06:15:49 --> Language Class Initialized
INFO - 2023-03-03 06:15:49 --> Loader Class Initialized
INFO - 2023-03-03 06:15:49 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:49 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:49 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:49 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:49 --> Total execution time: 0.2690
INFO - 2023-03-03 06:15:50 --> Config Class Initialized
INFO - 2023-03-03 06:15:50 --> Config Class Initialized
INFO - 2023-03-03 06:15:50 --> Hooks Class Initialized
INFO - 2023-03-03 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:15:50 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:50 --> Utf8 Class Initialized
INFO - 2023-03-03 06:15:50 --> URI Class Initialized
INFO - 2023-03-03 06:15:50 --> URI Class Initialized
INFO - 2023-03-03 06:15:50 --> Router Class Initialized
INFO - 2023-03-03 06:15:50 --> Router Class Initialized
INFO - 2023-03-03 06:15:50 --> Output Class Initialized
INFO - 2023-03-03 06:15:50 --> Output Class Initialized
INFO - 2023-03-03 06:15:50 --> Security Class Initialized
INFO - 2023-03-03 06:15:50 --> Security Class Initialized
DEBUG - 2023-03-03 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:15:50 --> Input Class Initialized
INFO - 2023-03-03 06:15:50 --> Input Class Initialized
INFO - 2023-03-03 06:15:50 --> Language Class Initialized
INFO - 2023-03-03 06:15:50 --> Language Class Initialized
INFO - 2023-03-03 06:15:50 --> Loader Class Initialized
INFO - 2023-03-03 06:15:50 --> Controller Class Initialized
INFO - 2023-03-03 06:15:50 --> Loader Class Initialized
DEBUG - 2023-03-03 06:15:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:50 --> Controller Class Initialized
DEBUG - 2023-03-03 06:15:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:15:50 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:50 --> Model "Login_model" initialized
INFO - 2023-03-03 06:15:50 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:51 --> Database Driver Class Initialized
INFO - 2023-03-03 06:15:51 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:15:51 --> Final output sent to browser
INFO - 2023-03-03 06:15:51 --> Model "Cluster_model" initialized
DEBUG - 2023-03-03 06:15:51 --> Total execution time: 0.2881
INFO - 2023-03-03 06:15:51 --> Final output sent to browser
DEBUG - 2023-03-03 06:15:51 --> Total execution time: 0.3018
INFO - 2023-03-03 06:20:46 --> Config Class Initialized
INFO - 2023-03-03 06:20:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:20:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:20:46 --> Utf8 Class Initialized
INFO - 2023-03-03 06:20:46 --> URI Class Initialized
INFO - 2023-03-03 06:20:46 --> Router Class Initialized
INFO - 2023-03-03 06:20:46 --> Output Class Initialized
INFO - 2023-03-03 06:20:46 --> Security Class Initialized
DEBUG - 2023-03-03 06:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:20:46 --> Input Class Initialized
INFO - 2023-03-03 06:20:46 --> Language Class Initialized
INFO - 2023-03-03 06:20:46 --> Loader Class Initialized
INFO - 2023-03-03 06:20:46 --> Controller Class Initialized
DEBUG - 2023-03-03 06:20:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:20:46 --> Database Driver Class Initialized
INFO - 2023-03-03 06:20:46 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:20:46 --> Final output sent to browser
DEBUG - 2023-03-03 06:20:46 --> Total execution time: 0.1537
INFO - 2023-03-03 06:20:47 --> Config Class Initialized
INFO - 2023-03-03 06:20:47 --> Hooks Class Initialized
DEBUG - 2023-03-03 06:20:47 --> UTF-8 Support Enabled
INFO - 2023-03-03 06:20:47 --> Utf8 Class Initialized
INFO - 2023-03-03 06:20:47 --> URI Class Initialized
INFO - 2023-03-03 06:20:47 --> Router Class Initialized
INFO - 2023-03-03 06:20:47 --> Output Class Initialized
INFO - 2023-03-03 06:20:47 --> Security Class Initialized
DEBUG - 2023-03-03 06:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 06:20:47 --> Input Class Initialized
INFO - 2023-03-03 06:20:47 --> Language Class Initialized
INFO - 2023-03-03 06:20:47 --> Loader Class Initialized
INFO - 2023-03-03 06:20:47 --> Controller Class Initialized
DEBUG - 2023-03-03 06:20:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 06:20:47 --> Database Driver Class Initialized
INFO - 2023-03-03 06:20:47 --> Model "Cluster_model" initialized
INFO - 2023-03-03 06:20:48 --> Final output sent to browser
DEBUG - 2023-03-03 06:20:48 --> Total execution time: 0.2223
INFO - 2023-03-03 07:24:29 --> Config Class Initialized
INFO - 2023-03-03 07:24:29 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:24:29 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:24:29 --> Utf8 Class Initialized
INFO - 2023-03-03 07:24:29 --> URI Class Initialized
INFO - 2023-03-03 07:24:29 --> Router Class Initialized
INFO - 2023-03-03 07:24:29 --> Output Class Initialized
INFO - 2023-03-03 07:24:29 --> Security Class Initialized
DEBUG - 2023-03-03 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:24:29 --> Input Class Initialized
INFO - 2023-03-03 07:24:29 --> Language Class Initialized
INFO - 2023-03-03 07:24:29 --> Loader Class Initialized
INFO - 2023-03-03 07:24:29 --> Controller Class Initialized
INFO - 2023-03-03 07:24:29 --> Helper loaded: form_helper
INFO - 2023-03-03 07:24:29 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:24:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:24:29 --> Model "Change_model" initialized
INFO - 2023-03-03 07:24:29 --> Model "Grafana_model" initialized
INFO - 2023-03-03 07:24:29 --> Final output sent to browser
DEBUG - 2023-03-03 07:24:29 --> Total execution time: 0.2303
INFO - 2023-03-03 07:24:30 --> Config Class Initialized
INFO - 2023-03-03 07:24:30 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:24:30 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:24:30 --> Utf8 Class Initialized
INFO - 2023-03-03 07:24:30 --> URI Class Initialized
INFO - 2023-03-03 07:24:30 --> Router Class Initialized
INFO - 2023-03-03 07:24:30 --> Output Class Initialized
INFO - 2023-03-03 07:24:30 --> Security Class Initialized
DEBUG - 2023-03-03 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:24:30 --> Input Class Initialized
INFO - 2023-03-03 07:24:30 --> Language Class Initialized
INFO - 2023-03-03 07:24:30 --> Loader Class Initialized
INFO - 2023-03-03 07:24:30 --> Controller Class Initialized
INFO - 2023-03-03 07:24:30 --> Helper loaded: form_helper
INFO - 2023-03-03 07:24:30 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:24:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:24:30 --> Database Driver Class Initialized
INFO - 2023-03-03 07:24:30 --> Model "Login_model" initialized
INFO - 2023-03-03 07:24:30 --> Final output sent to browser
DEBUG - 2023-03-03 07:24:30 --> Total execution time: 0.1696
INFO - 2023-03-03 07:24:35 --> Config Class Initialized
INFO - 2023-03-03 07:24:35 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:24:35 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:24:35 --> Utf8 Class Initialized
INFO - 2023-03-03 07:24:35 --> URI Class Initialized
INFO - 2023-03-03 07:24:35 --> Router Class Initialized
INFO - 2023-03-03 07:24:35 --> Output Class Initialized
INFO - 2023-03-03 07:24:35 --> Security Class Initialized
DEBUG - 2023-03-03 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:24:35 --> Input Class Initialized
INFO - 2023-03-03 07:24:35 --> Language Class Initialized
INFO - 2023-03-03 07:24:35 --> Loader Class Initialized
INFO - 2023-03-03 07:24:35 --> Controller Class Initialized
INFO - 2023-03-03 07:24:35 --> Helper loaded: form_helper
INFO - 2023-03-03 07:24:35 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:24:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:24:35 --> Model "Change_model" initialized
INFO - 2023-03-03 07:24:35 --> Model "Grafana_model" initialized
INFO - 2023-03-03 07:24:35 --> Final output sent to browser
DEBUG - 2023-03-03 07:24:35 --> Total execution time: 0.1901
INFO - 2023-03-03 07:24:35 --> Config Class Initialized
INFO - 2023-03-03 07:24:35 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:24:35 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:24:35 --> Utf8 Class Initialized
INFO - 2023-03-03 07:24:35 --> URI Class Initialized
INFO - 2023-03-03 07:24:35 --> Router Class Initialized
INFO - 2023-03-03 07:24:35 --> Output Class Initialized
INFO - 2023-03-03 07:24:35 --> Security Class Initialized
DEBUG - 2023-03-03 07:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:24:35 --> Input Class Initialized
INFO - 2023-03-03 07:24:35 --> Language Class Initialized
INFO - 2023-03-03 07:24:35 --> Loader Class Initialized
INFO - 2023-03-03 07:24:35 --> Controller Class Initialized
INFO - 2023-03-03 07:24:35 --> Helper loaded: form_helper
INFO - 2023-03-03 07:24:35 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:24:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:24:35 --> Database Driver Class Initialized
INFO - 2023-03-03 07:24:35 --> Model "Login_model" initialized
INFO - 2023-03-03 07:24:35 --> Final output sent to browser
DEBUG - 2023-03-03 07:24:35 --> Total execution time: 0.1480
INFO - 2023-03-03 07:25:33 --> Config Class Initialized
INFO - 2023-03-03 07:25:33 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:33 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:33 --> URI Class Initialized
INFO - 2023-03-03 07:25:33 --> Router Class Initialized
INFO - 2023-03-03 07:25:33 --> Output Class Initialized
INFO - 2023-03-03 07:25:33 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:33 --> Input Class Initialized
INFO - 2023-03-03 07:25:33 --> Language Class Initialized
INFO - 2023-03-03 07:25:33 --> Loader Class Initialized
INFO - 2023-03-03 07:25:33 --> Controller Class Initialized
INFO - 2023-03-03 07:25:33 --> Helper loaded: form_helper
INFO - 2023-03-03 07:25:33 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:25:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:33 --> Model "Change_model" initialized
INFO - 2023-03-03 07:25:33 --> Model "Grafana_model" initialized
INFO - 2023-03-03 07:25:33 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:33 --> Total execution time: 0.1667
INFO - 2023-03-03 07:25:33 --> Config Class Initialized
INFO - 2023-03-03 07:25:33 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:33 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:33 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:33 --> URI Class Initialized
INFO - 2023-03-03 07:25:33 --> Router Class Initialized
INFO - 2023-03-03 07:25:33 --> Output Class Initialized
INFO - 2023-03-03 07:25:33 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:33 --> Input Class Initialized
INFO - 2023-03-03 07:25:33 --> Language Class Initialized
INFO - 2023-03-03 07:25:33 --> Loader Class Initialized
INFO - 2023-03-03 07:25:33 --> Controller Class Initialized
INFO - 2023-03-03 07:25:33 --> Helper loaded: form_helper
INFO - 2023-03-03 07:25:33 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:25:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:33 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:33 --> Model "Login_model" initialized
INFO - 2023-03-03 07:25:33 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:33 --> Total execution time: 0.1341
INFO - 2023-03-03 07:25:46 --> Config Class Initialized
INFO - 2023-03-03 07:25:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:46 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:46 --> URI Class Initialized
INFO - 2023-03-03 07:25:46 --> Router Class Initialized
INFO - 2023-03-03 07:25:46 --> Output Class Initialized
INFO - 2023-03-03 07:25:46 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:46 --> Input Class Initialized
INFO - 2023-03-03 07:25:46 --> Language Class Initialized
INFO - 2023-03-03 07:25:46 --> Loader Class Initialized
INFO - 2023-03-03 07:25:46 --> Controller Class Initialized
INFO - 2023-03-03 07:25:46 --> Helper loaded: form_helper
INFO - 2023-03-03 07:25:46 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:25:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:46 --> Model "Change_model" initialized
INFO - 2023-03-03 07:25:46 --> Model "Grafana_model" initialized
INFO - 2023-03-03 07:25:46 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:46 --> Total execution time: 0.1877
INFO - 2023-03-03 07:25:46 --> Config Class Initialized
INFO - 2023-03-03 07:25:46 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:46 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:46 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:46 --> URI Class Initialized
INFO - 2023-03-03 07:25:46 --> Router Class Initialized
INFO - 2023-03-03 07:25:46 --> Output Class Initialized
INFO - 2023-03-03 07:25:46 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:47 --> Input Class Initialized
INFO - 2023-03-03 07:25:47 --> Language Class Initialized
INFO - 2023-03-03 07:25:47 --> Loader Class Initialized
INFO - 2023-03-03 07:25:47 --> Controller Class Initialized
INFO - 2023-03-03 07:25:47 --> Helper loaded: form_helper
INFO - 2023-03-03 07:25:47 --> Helper loaded: url_helper
DEBUG - 2023-03-03 07:25:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:47 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:47 --> Model "Login_model" initialized
INFO - 2023-03-03 07:25:47 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:47 --> Total execution time: 0.1466
INFO - 2023-03-03 07:25:47 --> Config Class Initialized
INFO - 2023-03-03 07:25:47 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:47 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:47 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:47 --> URI Class Initialized
INFO - 2023-03-03 07:25:47 --> Router Class Initialized
INFO - 2023-03-03 07:25:47 --> Output Class Initialized
INFO - 2023-03-03 07:25:47 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:47 --> Input Class Initialized
INFO - 2023-03-03 07:25:47 --> Language Class Initialized
INFO - 2023-03-03 07:25:47 --> Loader Class Initialized
INFO - 2023-03-03 07:25:47 --> Controller Class Initialized
DEBUG - 2023-03-03 07:25:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:47 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:47 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:25:47 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:47 --> Total execution time: 0.1432
INFO - 2023-03-03 07:25:47 --> Config Class Initialized
INFO - 2023-03-03 07:25:47 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:47 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:47 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:47 --> URI Class Initialized
INFO - 2023-03-03 07:25:47 --> Router Class Initialized
INFO - 2023-03-03 07:25:47 --> Output Class Initialized
INFO - 2023-03-03 07:25:47 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:47 --> Input Class Initialized
INFO - 2023-03-03 07:25:47 --> Language Class Initialized
INFO - 2023-03-03 07:25:47 --> Loader Class Initialized
INFO - 2023-03-03 07:25:47 --> Controller Class Initialized
DEBUG - 2023-03-03 07:25:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:47 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:47 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:25:47 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:47 --> Model "Login_model" initialized
INFO - 2023-03-03 07:25:47 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:47 --> Total execution time: 0.2251
INFO - 2023-03-03 07:25:50 --> Config Class Initialized
INFO - 2023-03-03 07:25:50 --> Config Class Initialized
INFO - 2023-03-03 07:25:50 --> Hooks Class Initialized
INFO - 2023-03-03 07:25:50 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2023-03-03 07:25:51 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:51 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:51 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:51 --> URI Class Initialized
INFO - 2023-03-03 07:25:51 --> URI Class Initialized
INFO - 2023-03-03 07:25:51 --> Router Class Initialized
INFO - 2023-03-03 07:25:51 --> Router Class Initialized
INFO - 2023-03-03 07:25:51 --> Output Class Initialized
INFO - 2023-03-03 07:25:51 --> Output Class Initialized
INFO - 2023-03-03 07:25:51 --> Security Class Initialized
INFO - 2023-03-03 07:25:51 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-03 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:51 --> Input Class Initialized
INFO - 2023-03-03 07:25:51 --> Input Class Initialized
INFO - 2023-03-03 07:25:51 --> Language Class Initialized
INFO - 2023-03-03 07:25:51 --> Language Class Initialized
INFO - 2023-03-03 07:25:51 --> Loader Class Initialized
INFO - 2023-03-03 07:25:51 --> Loader Class Initialized
INFO - 2023-03-03 07:25:51 --> Controller Class Initialized
INFO - 2023-03-03 07:25:51 --> Controller Class Initialized
DEBUG - 2023-03-03 07:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-03 07:25:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:51 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:51 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:51 --> Model "Login_model" initialized
INFO - 2023-03-03 07:25:51 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:51 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:25:51 --> Final output sent to browser
INFO - 2023-03-03 07:25:51 --> Model "Cluster_model" initialized
DEBUG - 2023-03-03 07:25:51 --> Total execution time: 0.2598
INFO - 2023-03-03 07:25:51 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:51 --> Total execution time: 0.2691
INFO - 2023-03-03 07:25:54 --> Config Class Initialized
INFO - 2023-03-03 07:25:54 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:54 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:54 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:54 --> URI Class Initialized
INFO - 2023-03-03 07:25:54 --> Router Class Initialized
INFO - 2023-03-03 07:25:54 --> Output Class Initialized
INFO - 2023-03-03 07:25:54 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:54 --> Input Class Initialized
INFO - 2023-03-03 07:25:54 --> Language Class Initialized
INFO - 2023-03-03 07:25:55 --> Loader Class Initialized
INFO - 2023-03-03 07:25:55 --> Controller Class Initialized
DEBUG - 2023-03-03 07:25:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:55 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:55 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:25:55 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:55 --> Total execution time: 0.2183
INFO - 2023-03-03 07:25:58 --> Config Class Initialized
INFO - 2023-03-03 07:25:58 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:25:58 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:25:58 --> Utf8 Class Initialized
INFO - 2023-03-03 07:25:58 --> URI Class Initialized
INFO - 2023-03-03 07:25:58 --> Router Class Initialized
INFO - 2023-03-03 07:25:58 --> Output Class Initialized
INFO - 2023-03-03 07:25:58 --> Security Class Initialized
DEBUG - 2023-03-03 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:25:58 --> Input Class Initialized
INFO - 2023-03-03 07:25:58 --> Language Class Initialized
INFO - 2023-03-03 07:25:58 --> Loader Class Initialized
INFO - 2023-03-03 07:25:58 --> Controller Class Initialized
DEBUG - 2023-03-03 07:25:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:25:59 --> Database Driver Class Initialized
INFO - 2023-03-03 07:25:59 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:25:59 --> Final output sent to browser
DEBUG - 2023-03-03 07:25:59 --> Total execution time: 0.1625
INFO - 2023-03-03 07:26:03 --> Config Class Initialized
INFO - 2023-03-03 07:26:03 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:26:03 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:26:03 --> Utf8 Class Initialized
INFO - 2023-03-03 07:26:03 --> URI Class Initialized
INFO - 2023-03-03 07:26:03 --> Router Class Initialized
INFO - 2023-03-03 07:26:03 --> Output Class Initialized
INFO - 2023-03-03 07:26:03 --> Security Class Initialized
DEBUG - 2023-03-03 07:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:26:04 --> Input Class Initialized
INFO - 2023-03-03 07:26:04 --> Language Class Initialized
INFO - 2023-03-03 07:26:04 --> Loader Class Initialized
INFO - 2023-03-03 07:26:04 --> Controller Class Initialized
DEBUG - 2023-03-03 07:26:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:26:04 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:04 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:26:04 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:04 --> Model "Login_model" initialized
INFO - 2023-03-03 07:26:04 --> Final output sent to browser
DEBUG - 2023-03-03 07:26:04 --> Total execution time: 0.2156
INFO - 2023-03-03 07:26:05 --> Config Class Initialized
INFO - 2023-03-03 07:26:05 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:26:05 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:26:05 --> Utf8 Class Initialized
INFO - 2023-03-03 07:26:05 --> URI Class Initialized
INFO - 2023-03-03 07:26:05 --> Router Class Initialized
INFO - 2023-03-03 07:26:05 --> Output Class Initialized
INFO - 2023-03-03 07:26:05 --> Security Class Initialized
DEBUG - 2023-03-03 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:26:05 --> Input Class Initialized
INFO - 2023-03-03 07:26:05 --> Language Class Initialized
INFO - 2023-03-03 07:26:05 --> Loader Class Initialized
INFO - 2023-03-03 07:26:05 --> Controller Class Initialized
DEBUG - 2023-03-03 07:26:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:26:05 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:05 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:26:05 --> Final output sent to browser
DEBUG - 2023-03-03 07:26:05 --> Total execution time: 0.1277
INFO - 2023-03-03 07:26:07 --> Config Class Initialized
INFO - 2023-03-03 07:26:07 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:26:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:26:07 --> Utf8 Class Initialized
INFO - 2023-03-03 07:26:07 --> URI Class Initialized
INFO - 2023-03-03 07:26:08 --> Router Class Initialized
INFO - 2023-03-03 07:26:08 --> Output Class Initialized
INFO - 2023-03-03 07:26:08 --> Security Class Initialized
DEBUG - 2023-03-03 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:26:08 --> Input Class Initialized
INFO - 2023-03-03 07:26:08 --> Language Class Initialized
INFO - 2023-03-03 07:26:08 --> Loader Class Initialized
INFO - 2023-03-03 07:26:08 --> Controller Class Initialized
DEBUG - 2023-03-03 07:26:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:26:08 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:08 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:26:08 --> Final output sent to browser
DEBUG - 2023-03-03 07:26:08 --> Total execution time: 0.1629
INFO - 2023-03-03 07:26:11 --> Config Class Initialized
INFO - 2023-03-03 07:26:11 --> Hooks Class Initialized
DEBUG - 2023-03-03 07:26:11 --> UTF-8 Support Enabled
INFO - 2023-03-03 07:26:11 --> Utf8 Class Initialized
INFO - 2023-03-03 07:26:11 --> URI Class Initialized
INFO - 2023-03-03 07:26:11 --> Router Class Initialized
INFO - 2023-03-03 07:26:11 --> Output Class Initialized
INFO - 2023-03-03 07:26:11 --> Security Class Initialized
DEBUG - 2023-03-03 07:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 07:26:11 --> Input Class Initialized
INFO - 2023-03-03 07:26:11 --> Language Class Initialized
INFO - 2023-03-03 07:26:11 --> Loader Class Initialized
INFO - 2023-03-03 07:26:11 --> Controller Class Initialized
DEBUG - 2023-03-03 07:26:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 07:26:11 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:11 --> Model "Cluster_model" initialized
INFO - 2023-03-03 07:26:11 --> Database Driver Class Initialized
INFO - 2023-03-03 07:26:11 --> Model "Login_model" initialized
INFO - 2023-03-03 07:26:11 --> Final output sent to browser
DEBUG - 2023-03-03 07:26:11 --> Total execution time: 0.2249
INFO - 2023-03-03 08:27:33 --> Config Class Initialized
INFO - 2023-03-03 08:27:33 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:27:33 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:27:33 --> Utf8 Class Initialized
INFO - 2023-03-03 08:27:33 --> URI Class Initialized
INFO - 2023-03-03 08:27:33 --> Router Class Initialized
INFO - 2023-03-03 08:27:33 --> Output Class Initialized
INFO - 2023-03-03 08:27:33 --> Security Class Initialized
DEBUG - 2023-03-03 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:27:33 --> Input Class Initialized
INFO - 2023-03-03 08:27:33 --> Language Class Initialized
INFO - 2023-03-03 08:27:33 --> Loader Class Initialized
INFO - 2023-03-03 08:27:33 --> Controller Class Initialized
DEBUG - 2023-03-03 08:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:27:33 --> Database Driver Class Initialized
INFO - 2023-03-03 08:27:33 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:27:33 --> Final output sent to browser
DEBUG - 2023-03-03 08:27:33 --> Total execution time: 0.2134
INFO - 2023-03-03 08:27:36 --> Config Class Initialized
INFO - 2023-03-03 08:27:36 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:27:36 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:27:36 --> Utf8 Class Initialized
INFO - 2023-03-03 08:27:36 --> URI Class Initialized
INFO - 2023-03-03 08:27:36 --> Router Class Initialized
INFO - 2023-03-03 08:27:36 --> Output Class Initialized
INFO - 2023-03-03 08:27:36 --> Security Class Initialized
DEBUG - 2023-03-03 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:27:36 --> Input Class Initialized
INFO - 2023-03-03 08:27:36 --> Language Class Initialized
INFO - 2023-03-03 08:27:36 --> Loader Class Initialized
INFO - 2023-03-03 08:27:36 --> Controller Class Initialized
DEBUG - 2023-03-03 08:27:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:27:36 --> Database Driver Class Initialized
INFO - 2023-03-03 08:27:36 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:27:36 --> Final output sent to browser
DEBUG - 2023-03-03 08:27:36 --> Total execution time: 0.5830
INFO - 2023-03-03 08:37:37 --> Config Class Initialized
INFO - 2023-03-03 08:37:37 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:37:37 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:37:37 --> Utf8 Class Initialized
INFO - 2023-03-03 08:37:37 --> URI Class Initialized
INFO - 2023-03-03 08:37:37 --> Router Class Initialized
INFO - 2023-03-03 08:37:37 --> Output Class Initialized
INFO - 2023-03-03 08:37:37 --> Security Class Initialized
DEBUG - 2023-03-03 08:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:37:37 --> Input Class Initialized
INFO - 2023-03-03 08:37:37 --> Language Class Initialized
INFO - 2023-03-03 08:37:37 --> Loader Class Initialized
INFO - 2023-03-03 08:37:37 --> Controller Class Initialized
DEBUG - 2023-03-03 08:37:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:37:37 --> Database Driver Class Initialized
INFO - 2023-03-03 08:37:37 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:37:37 --> Final output sent to browser
DEBUG - 2023-03-03 08:37:37 --> Total execution time: 0.1924
INFO - 2023-03-03 08:37:40 --> Config Class Initialized
INFO - 2023-03-03 08:37:40 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:37:40 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:37:40 --> Utf8 Class Initialized
INFO - 2023-03-03 08:37:40 --> URI Class Initialized
INFO - 2023-03-03 08:37:40 --> Router Class Initialized
INFO - 2023-03-03 08:37:40 --> Output Class Initialized
INFO - 2023-03-03 08:37:40 --> Security Class Initialized
DEBUG - 2023-03-03 08:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:37:40 --> Input Class Initialized
INFO - 2023-03-03 08:37:40 --> Language Class Initialized
INFO - 2023-03-03 08:37:40 --> Loader Class Initialized
INFO - 2023-03-03 08:37:40 --> Controller Class Initialized
DEBUG - 2023-03-03 08:37:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:37:40 --> Database Driver Class Initialized
INFO - 2023-03-03 08:37:40 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:37:40 --> Final output sent to browser
DEBUG - 2023-03-03 08:37:40 --> Total execution time: 0.2288
INFO - 2023-03-03 08:38:41 --> Config Class Initialized
INFO - 2023-03-03 08:38:41 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:38:41 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:38:41 --> Utf8 Class Initialized
INFO - 2023-03-03 08:38:41 --> URI Class Initialized
INFO - 2023-03-03 08:38:41 --> Router Class Initialized
INFO - 2023-03-03 08:38:41 --> Output Class Initialized
INFO - 2023-03-03 08:38:41 --> Security Class Initialized
DEBUG - 2023-03-03 08:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:38:41 --> Input Class Initialized
INFO - 2023-03-03 08:38:41 --> Language Class Initialized
INFO - 2023-03-03 08:38:41 --> Loader Class Initialized
INFO - 2023-03-03 08:38:41 --> Controller Class Initialized
DEBUG - 2023-03-03 08:38:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:38:41 --> Database Driver Class Initialized
INFO - 2023-03-03 08:38:41 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:38:41 --> Final output sent to browser
DEBUG - 2023-03-03 08:38:41 --> Total execution time: 0.2132
INFO - 2023-03-03 08:39:20 --> Config Class Initialized
INFO - 2023-03-03 08:39:20 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:39:20 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:39:20 --> Utf8 Class Initialized
INFO - 2023-03-03 08:39:20 --> URI Class Initialized
INFO - 2023-03-03 08:39:20 --> Router Class Initialized
INFO - 2023-03-03 08:39:20 --> Output Class Initialized
INFO - 2023-03-03 08:39:20 --> Security Class Initialized
DEBUG - 2023-03-03 08:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:39:20 --> Input Class Initialized
INFO - 2023-03-03 08:39:20 --> Language Class Initialized
INFO - 2023-03-03 08:39:20 --> Loader Class Initialized
INFO - 2023-03-03 08:39:20 --> Controller Class Initialized
DEBUG - 2023-03-03 08:39:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:39:20 --> Database Driver Class Initialized
INFO - 2023-03-03 08:39:20 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:39:20 --> Final output sent to browser
DEBUG - 2023-03-03 08:39:20 --> Total execution time: 0.2278
INFO - 2023-03-03 08:41:40 --> Config Class Initialized
INFO - 2023-03-03 08:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:41:40 --> Utf8 Class Initialized
INFO - 2023-03-03 08:41:40 --> URI Class Initialized
INFO - 2023-03-03 08:41:40 --> Router Class Initialized
INFO - 2023-03-03 08:41:40 --> Output Class Initialized
INFO - 2023-03-03 08:41:40 --> Security Class Initialized
DEBUG - 2023-03-03 08:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:41:40 --> Input Class Initialized
INFO - 2023-03-03 08:41:40 --> Language Class Initialized
INFO - 2023-03-03 08:41:40 --> Loader Class Initialized
INFO - 2023-03-03 08:41:40 --> Controller Class Initialized
DEBUG - 2023-03-03 08:41:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:41:40 --> Database Driver Class Initialized
INFO - 2023-03-03 08:41:40 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:41:40 --> Final output sent to browser
DEBUG - 2023-03-03 08:41:40 --> Total execution time: 0.1559
INFO - 2023-03-03 08:41:42 --> Config Class Initialized
INFO - 2023-03-03 08:41:42 --> Hooks Class Initialized
DEBUG - 2023-03-03 08:41:42 --> UTF-8 Support Enabled
INFO - 2023-03-03 08:41:42 --> Utf8 Class Initialized
INFO - 2023-03-03 08:41:42 --> URI Class Initialized
INFO - 2023-03-03 08:41:42 --> Router Class Initialized
INFO - 2023-03-03 08:41:42 --> Output Class Initialized
INFO - 2023-03-03 08:41:42 --> Security Class Initialized
DEBUG - 2023-03-03 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 08:41:42 --> Input Class Initialized
INFO - 2023-03-03 08:41:42 --> Language Class Initialized
INFO - 2023-03-03 08:41:42 --> Loader Class Initialized
INFO - 2023-03-03 08:41:42 --> Controller Class Initialized
DEBUG - 2023-03-03 08:41:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 08:41:42 --> Database Driver Class Initialized
INFO - 2023-03-03 08:41:42 --> Model "Cluster_model" initialized
INFO - 2023-03-03 08:41:42 --> Final output sent to browser
DEBUG - 2023-03-03 08:41:42 --> Total execution time: 0.2563
INFO - 2023-03-03 09:17:21 --> Config Class Initialized
INFO - 2023-03-03 09:17:21 --> Hooks Class Initialized
DEBUG - 2023-03-03 09:17:21 --> UTF-8 Support Enabled
INFO - 2023-03-03 09:17:21 --> Utf8 Class Initialized
INFO - 2023-03-03 09:17:21 --> URI Class Initialized
INFO - 2023-03-03 09:17:21 --> Router Class Initialized
INFO - 2023-03-03 09:17:21 --> Output Class Initialized
INFO - 2023-03-03 09:17:21 --> Security Class Initialized
DEBUG - 2023-03-03 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 09:17:21 --> Input Class Initialized
INFO - 2023-03-03 09:17:21 --> Language Class Initialized
INFO - 2023-03-03 09:17:21 --> Loader Class Initialized
INFO - 2023-03-03 09:17:21 --> Controller Class Initialized
DEBUG - 2023-03-03 09:17:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 09:17:21 --> Database Driver Class Initialized
INFO - 2023-03-03 09:17:21 --> Model "Cluster_model" initialized
INFO - 2023-03-03 09:17:21 --> Final output sent to browser
DEBUG - 2023-03-03 09:17:21 --> Total execution time: 0.1477
INFO - 2023-03-03 09:43:48 --> Config Class Initialized
INFO - 2023-03-03 09:43:48 --> Hooks Class Initialized
DEBUG - 2023-03-03 09:43:48 --> UTF-8 Support Enabled
INFO - 2023-03-03 09:43:48 --> Utf8 Class Initialized
INFO - 2023-03-03 09:43:48 --> URI Class Initialized
INFO - 2023-03-03 09:43:48 --> Router Class Initialized
INFO - 2023-03-03 09:43:48 --> Output Class Initialized
INFO - 2023-03-03 09:43:48 --> Security Class Initialized
DEBUG - 2023-03-03 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 09:43:48 --> Input Class Initialized
INFO - 2023-03-03 09:43:48 --> Language Class Initialized
INFO - 2023-03-03 09:43:48 --> Loader Class Initialized
INFO - 2023-03-03 09:43:48 --> Controller Class Initialized
DEBUG - 2023-03-03 09:43:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 09:43:48 --> Database Driver Class Initialized
INFO - 2023-03-03 09:43:48 --> Model "Cluster_model" initialized
INFO - 2023-03-03 09:43:48 --> Final output sent to browser
DEBUG - 2023-03-03 09:43:48 --> Total execution time: 0.4972
INFO - 2023-03-03 10:09:07 --> Config Class Initialized
INFO - 2023-03-03 10:09:07 --> Hooks Class Initialized
INFO - 2023-03-03 10:09:07 --> Config Class Initialized
INFO - 2023-03-03 10:09:07 --> Hooks Class Initialized
DEBUG - 2023-03-03 10:09:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 10:09:07 --> Utf8 Class Initialized
DEBUG - 2023-03-03 10:09:07 --> UTF-8 Support Enabled
INFO - 2023-03-03 10:09:07 --> Utf8 Class Initialized
INFO - 2023-03-03 10:09:07 --> URI Class Initialized
INFO - 2023-03-03 10:09:07 --> URI Class Initialized
INFO - 2023-03-03 10:09:07 --> Router Class Initialized
INFO - 2023-03-03 10:09:07 --> Output Class Initialized
INFO - 2023-03-03 10:09:07 --> Router Class Initialized
INFO - 2023-03-03 10:09:07 --> Security Class Initialized
INFO - 2023-03-03 10:09:07 --> Output Class Initialized
DEBUG - 2023-03-03 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 10:09:07 --> Input Class Initialized
INFO - 2023-03-03 10:09:07 --> Language Class Initialized
INFO - 2023-03-03 10:09:07 --> Security Class Initialized
DEBUG - 2023-03-03 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-03 10:09:07 --> Input Class Initialized
INFO - 2023-03-03 10:09:07 --> Language Class Initialized
INFO - 2023-03-03 10:09:07 --> Loader Class Initialized
INFO - 2023-03-03 10:09:07 --> Controller Class Initialized
DEBUG - 2023-03-03 10:09:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 10:09:07 --> Loader Class Initialized
INFO - 2023-03-03 10:09:07 --> Controller Class Initialized
DEBUG - 2023-03-03 10:09:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-03 10:09:07 --> Database Driver Class Initialized
INFO - 2023-03-03 10:09:07 --> Model "Login_model" initialized
INFO - 2023-03-03 10:09:07 --> Database Driver Class Initialized
INFO - 2023-03-03 10:09:07 --> Database Driver Class Initialized
INFO - 2023-03-03 10:09:07 --> Model "Cluster_model" initialized
INFO - 2023-03-03 10:09:07 --> Model "Cluster_model" initialized
INFO - 2023-03-03 10:09:07 --> Final output sent to browser
INFO - 2023-03-03 10:09:07 --> Final output sent to browser
DEBUG - 2023-03-03 10:09:07 --> Total execution time: 0.6153
DEBUG - 2023-03-03 10:09:07 --> Total execution time: 0.6365
