<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-11 01:45:20 --> Config Class Initialized
INFO - 2023-01-11 01:45:20 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:20 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:20 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:20 --> URI Class Initialized
INFO - 2023-01-11 01:45:20 --> Router Class Initialized
INFO - 2023-01-11 01:45:20 --> Output Class Initialized
INFO - 2023-01-11 01:45:20 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:20 --> Input Class Initialized
INFO - 2023-01-11 01:45:20 --> Language Class Initialized
INFO - 2023-01-11 01:45:20 --> Loader Class Initialized
INFO - 2023-01-11 01:45:20 --> Controller Class Initialized
INFO - 2023-01-11 01:45:20 --> Helper loaded: form_helper
INFO - 2023-01-11 01:45:20 --> Helper loaded: url_helper
DEBUG - 2023-01-11 01:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:20 --> Model "Change_model" initialized
INFO - 2023-01-11 01:45:41 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:41 --> Total execution time: 21.2973
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
INFO - 2023-01-11 01:45:47 --> Helper loaded: form_helper
INFO - 2023-01-11 01:45:47 --> Helper loaded: url_helper
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Model "Change_model" initialized
INFO - 2023-01-11 01:45:47 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0280
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
INFO - 2023-01-11 01:45:47 --> Helper loaded: form_helper
INFO - 2023-01-11 01:45:47 --> Helper loaded: url_helper
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0061
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
INFO - 2023-01-11 01:45:47 --> Helper loaded: form_helper
INFO - 2023-01-11 01:45:47 --> Helper loaded: url_helper
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Login_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0187
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0519
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0147
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Login_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.1235
INFO - 2023-01-11 01:45:47 --> Config Class Initialized
INFO - 2023-01-11 01:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:47 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:47 --> URI Class Initialized
INFO - 2023-01-11 01:45:47 --> Router Class Initialized
INFO - 2023-01-11 01:45:47 --> Output Class Initialized
INFO - 2023-01-11 01:45:47 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:47 --> Input Class Initialized
INFO - 2023-01-11 01:45:47 --> Language Class Initialized
INFO - 2023-01-11 01:45:47 --> Loader Class Initialized
INFO - 2023-01-11 01:45:47 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:47 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:47 --> Model "Login_model" initialized
INFO - 2023-01-11 01:45:47 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:47 --> Total execution time: 0.0987
INFO - 2023-01-11 01:45:54 --> Config Class Initialized
INFO - 2023-01-11 01:45:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:54 --> URI Class Initialized
INFO - 2023-01-11 01:45:54 --> Router Class Initialized
INFO - 2023-01-11 01:45:54 --> Output Class Initialized
INFO - 2023-01-11 01:45:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:54 --> Input Class Initialized
INFO - 2023-01-11 01:45:54 --> Language Class Initialized
INFO - 2023-01-11 01:45:54 --> Loader Class Initialized
INFO - 2023-01-11 01:45:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:54 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:54 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:54 --> Total execution time: 0.0533
INFO - 2023-01-11 01:45:54 --> Config Class Initialized
INFO - 2023-01-11 01:45:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:45:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:45:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:45:54 --> URI Class Initialized
INFO - 2023-01-11 01:45:54 --> Router Class Initialized
INFO - 2023-01-11 01:45:54 --> Output Class Initialized
INFO - 2023-01-11 01:45:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:45:54 --> Input Class Initialized
INFO - 2023-01-11 01:45:54 --> Language Class Initialized
INFO - 2023-01-11 01:45:54 --> Loader Class Initialized
INFO - 2023-01-11 01:45:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:45:54 --> Database Driver Class Initialized
INFO - 2023-01-11 01:45:54 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:45:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:45:54 --> Total execution time: 0.0871
INFO - 2023-01-11 01:47:06 --> Config Class Initialized
INFO - 2023-01-11 01:47:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:47:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:47:06 --> Utf8 Class Initialized
INFO - 2023-01-11 01:47:06 --> URI Class Initialized
INFO - 2023-01-11 01:47:06 --> Router Class Initialized
INFO - 2023-01-11 01:47:06 --> Output Class Initialized
INFO - 2023-01-11 01:47:06 --> Security Class Initialized
DEBUG - 2023-01-11 01:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:47:06 --> Input Class Initialized
INFO - 2023-01-11 01:47:06 --> Language Class Initialized
INFO - 2023-01-11 01:47:06 --> Loader Class Initialized
INFO - 2023-01-11 01:47:06 --> Controller Class Initialized
DEBUG - 2023-01-11 01:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:47:06 --> Final output sent to browser
DEBUG - 2023-01-11 01:47:06 --> Total execution time: 0.0475
INFO - 2023-01-11 01:47:06 --> Config Class Initialized
INFO - 2023-01-11 01:47:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:47:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:47:06 --> Utf8 Class Initialized
INFO - 2023-01-11 01:47:06 --> URI Class Initialized
INFO - 2023-01-11 01:47:06 --> Router Class Initialized
INFO - 2023-01-11 01:47:06 --> Output Class Initialized
INFO - 2023-01-11 01:47:06 --> Security Class Initialized
DEBUG - 2023-01-11 01:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:47:06 --> Input Class Initialized
INFO - 2023-01-11 01:47:06 --> Language Class Initialized
INFO - 2023-01-11 01:47:06 --> Loader Class Initialized
INFO - 2023-01-11 01:47:06 --> Controller Class Initialized
DEBUG - 2023-01-11 01:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:47:06 --> Database Driver Class Initialized
INFO - 2023-01-11 01:47:06 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:47:06 --> Final output sent to browser
DEBUG - 2023-01-11 01:47:06 --> Total execution time: 0.0103
INFO - 2023-01-11 01:47:13 --> Config Class Initialized
INFO - 2023-01-11 01:47:13 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:47:13 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:47:13 --> Utf8 Class Initialized
INFO - 2023-01-11 01:47:13 --> URI Class Initialized
INFO - 2023-01-11 01:47:13 --> Router Class Initialized
INFO - 2023-01-11 01:47:13 --> Output Class Initialized
INFO - 2023-01-11 01:47:13 --> Security Class Initialized
DEBUG - 2023-01-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:47:13 --> Input Class Initialized
INFO - 2023-01-11 01:47:13 --> Language Class Initialized
INFO - 2023-01-11 01:47:13 --> Loader Class Initialized
INFO - 2023-01-11 01:47:13 --> Controller Class Initialized
DEBUG - 2023-01-11 01:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:47:13 --> Final output sent to browser
DEBUG - 2023-01-11 01:47:13 --> Total execution time: 0.0052
INFO - 2023-01-11 01:47:13 --> Config Class Initialized
INFO - 2023-01-11 01:47:13 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:47:13 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:47:13 --> Utf8 Class Initialized
INFO - 2023-01-11 01:47:13 --> URI Class Initialized
INFO - 2023-01-11 01:47:13 --> Router Class Initialized
INFO - 2023-01-11 01:47:13 --> Output Class Initialized
INFO - 2023-01-11 01:47:13 --> Security Class Initialized
DEBUG - 2023-01-11 01:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:47:13 --> Input Class Initialized
INFO - 2023-01-11 01:47:13 --> Language Class Initialized
INFO - 2023-01-11 01:47:13 --> Loader Class Initialized
INFO - 2023-01-11 01:47:13 --> Controller Class Initialized
DEBUG - 2023-01-11 01:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:47:13 --> Database Driver Class Initialized
INFO - 2023-01-11 01:47:13 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:47:13 --> Model "Node_model" initialized
INFO - 2023-01-11 01:47:13 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:48:23 --> Config Class Initialized
INFO - 2023-01-11 01:48:23 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:48:23 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:48:23 --> Utf8 Class Initialized
INFO - 2023-01-11 01:48:23 --> URI Class Initialized
INFO - 2023-01-11 01:48:23 --> Router Class Initialized
INFO - 2023-01-11 01:48:23 --> Output Class Initialized
INFO - 2023-01-11 01:48:23 --> Security Class Initialized
DEBUG - 2023-01-11 01:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:48:23 --> Input Class Initialized
INFO - 2023-01-11 01:48:23 --> Language Class Initialized
INFO - 2023-01-11 01:48:23 --> Loader Class Initialized
INFO - 2023-01-11 01:48:23 --> Controller Class Initialized
DEBUG - 2023-01-11 01:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:48:23 --> Final output sent to browser
DEBUG - 2023-01-11 01:48:23 --> Total execution time: 0.0057
INFO - 2023-01-11 01:48:23 --> Config Class Initialized
INFO - 2023-01-11 01:48:23 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:48:23 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:48:23 --> Utf8 Class Initialized
INFO - 2023-01-11 01:48:23 --> URI Class Initialized
INFO - 2023-01-11 01:48:23 --> Router Class Initialized
INFO - 2023-01-11 01:48:23 --> Output Class Initialized
INFO - 2023-01-11 01:48:23 --> Security Class Initialized
DEBUG - 2023-01-11 01:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:48:23 --> Input Class Initialized
INFO - 2023-01-11 01:48:23 --> Language Class Initialized
INFO - 2023-01-11 01:48:23 --> Loader Class Initialized
INFO - 2023-01-11 01:48:23 --> Controller Class Initialized
DEBUG - 2023-01-11 01:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:48:23 --> Database Driver Class Initialized
INFO - 2023-01-11 01:48:23 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:48:23 --> Model "Node_model" initialized
INFO - 2023-01-11 01:48:23 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:48:43 --> Config Class Initialized
INFO - 2023-01-11 01:48:43 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:48:43 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:48:43 --> Utf8 Class Initialized
INFO - 2023-01-11 01:48:43 --> URI Class Initialized
INFO - 2023-01-11 01:48:43 --> Router Class Initialized
INFO - 2023-01-11 01:48:43 --> Output Class Initialized
INFO - 2023-01-11 01:48:43 --> Security Class Initialized
DEBUG - 2023-01-11 01:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:48:43 --> Input Class Initialized
INFO - 2023-01-11 01:48:43 --> Language Class Initialized
INFO - 2023-01-11 01:48:43 --> Loader Class Initialized
INFO - 2023-01-11 01:48:43 --> Controller Class Initialized
DEBUG - 2023-01-11 01:48:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:48:43 --> Final output sent to browser
DEBUG - 2023-01-11 01:48:43 --> Total execution time: 0.0047
INFO - 2023-01-11 01:48:43 --> Config Class Initialized
INFO - 2023-01-11 01:48:43 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:48:43 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:48:43 --> Utf8 Class Initialized
INFO - 2023-01-11 01:48:43 --> URI Class Initialized
INFO - 2023-01-11 01:48:43 --> Router Class Initialized
INFO - 2023-01-11 01:48:43 --> Output Class Initialized
INFO - 2023-01-11 01:48:43 --> Security Class Initialized
DEBUG - 2023-01-11 01:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:48:43 --> Input Class Initialized
INFO - 2023-01-11 01:48:43 --> Language Class Initialized
INFO - 2023-01-11 01:48:43 --> Loader Class Initialized
INFO - 2023-01-11 01:48:43 --> Controller Class Initialized
DEBUG - 2023-01-11 01:48:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:48:43 --> Database Driver Class Initialized
INFO - 2023-01-11 01:48:43 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:48:43 --> Model "Node_model" initialized
INFO - 2023-01-11 01:48:43 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:49:06 --> Config Class Initialized
INFO - 2023-01-11 01:49:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:49:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:49:06 --> Utf8 Class Initialized
INFO - 2023-01-11 01:49:06 --> URI Class Initialized
INFO - 2023-01-11 01:49:06 --> Router Class Initialized
INFO - 2023-01-11 01:49:06 --> Output Class Initialized
INFO - 2023-01-11 01:49:06 --> Security Class Initialized
DEBUG - 2023-01-11 01:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:49:06 --> Input Class Initialized
INFO - 2023-01-11 01:49:06 --> Language Class Initialized
INFO - 2023-01-11 01:49:06 --> Loader Class Initialized
INFO - 2023-01-11 01:49:06 --> Controller Class Initialized
DEBUG - 2023-01-11 01:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:49:06 --> Final output sent to browser
DEBUG - 2023-01-11 01:49:06 --> Total execution time: 0.0439
INFO - 2023-01-11 01:49:06 --> Config Class Initialized
INFO - 2023-01-11 01:49:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:49:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:49:06 --> Utf8 Class Initialized
INFO - 2023-01-11 01:49:06 --> URI Class Initialized
INFO - 2023-01-11 01:49:06 --> Router Class Initialized
INFO - 2023-01-11 01:49:06 --> Output Class Initialized
INFO - 2023-01-11 01:49:06 --> Security Class Initialized
DEBUG - 2023-01-11 01:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:49:06 --> Input Class Initialized
INFO - 2023-01-11 01:49:06 --> Language Class Initialized
INFO - 2023-01-11 01:49:06 --> Loader Class Initialized
INFO - 2023-01-11 01:49:06 --> Controller Class Initialized
DEBUG - 2023-01-11 01:49:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:49:06 --> Database Driver Class Initialized
INFO - 2023-01-11 01:49:06 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:49:06 --> Model "Node_model" initialized
INFO - 2023-01-11 01:49:06 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:49:48 --> Config Class Initialized
INFO - 2023-01-11 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:49:48 --> Utf8 Class Initialized
INFO - 2023-01-11 01:49:48 --> URI Class Initialized
INFO - 2023-01-11 01:49:48 --> Router Class Initialized
INFO - 2023-01-11 01:49:48 --> Output Class Initialized
INFO - 2023-01-11 01:49:48 --> Security Class Initialized
DEBUG - 2023-01-11 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:49:48 --> Input Class Initialized
INFO - 2023-01-11 01:49:48 --> Language Class Initialized
INFO - 2023-01-11 01:49:48 --> Loader Class Initialized
INFO - 2023-01-11 01:49:48 --> Controller Class Initialized
DEBUG - 2023-01-11 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:49:48 --> Final output sent to browser
DEBUG - 2023-01-11 01:49:48 --> Total execution time: 0.0049
INFO - 2023-01-11 01:49:48 --> Config Class Initialized
INFO - 2023-01-11 01:49:48 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:49:48 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:49:48 --> Utf8 Class Initialized
INFO - 2023-01-11 01:49:48 --> URI Class Initialized
INFO - 2023-01-11 01:49:48 --> Router Class Initialized
INFO - 2023-01-11 01:49:48 --> Output Class Initialized
INFO - 2023-01-11 01:49:48 --> Security Class Initialized
DEBUG - 2023-01-11 01:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:49:48 --> Input Class Initialized
INFO - 2023-01-11 01:49:48 --> Language Class Initialized
INFO - 2023-01-11 01:49:48 --> Loader Class Initialized
INFO - 2023-01-11 01:49:48 --> Controller Class Initialized
DEBUG - 2023-01-11 01:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:49:48 --> Database Driver Class Initialized
INFO - 2023-01-11 01:49:48 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:49:48 --> Model "Node_model" initialized
INFO - 2023-01-11 01:49:48 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:49:48 --> Final output sent to browser
DEBUG - 2023-01-11 01:49:48 --> Total execution time: 0.0269
INFO - 2023-01-11 01:51:04 --> Config Class Initialized
INFO - 2023-01-11 01:51:04 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:04 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:04 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:04 --> URI Class Initialized
INFO - 2023-01-11 01:51:04 --> Router Class Initialized
INFO - 2023-01-11 01:51:04 --> Output Class Initialized
INFO - 2023-01-11 01:51:04 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:04 --> Input Class Initialized
INFO - 2023-01-11 01:51:04 --> Language Class Initialized
INFO - 2023-01-11 01:51:04 --> Loader Class Initialized
INFO - 2023-01-11 01:51:04 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:04 --> Final output sent to browser
DEBUG - 2023-01-11 01:51:04 --> Total execution time: 0.0052
INFO - 2023-01-11 01:51:04 --> Config Class Initialized
INFO - 2023-01-11 01:51:04 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:04 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:04 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:04 --> URI Class Initialized
INFO - 2023-01-11 01:51:04 --> Router Class Initialized
INFO - 2023-01-11 01:51:04 --> Output Class Initialized
INFO - 2023-01-11 01:51:04 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:04 --> Input Class Initialized
INFO - 2023-01-11 01:51:04 --> Language Class Initialized
INFO - 2023-01-11 01:51:04 --> Loader Class Initialized
INFO - 2023-01-11 01:51:04 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:04 --> Database Driver Class Initialized
INFO - 2023-01-11 01:51:04 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:51:04 --> Model "Node_model" initialized
INFO - 2023-01-11 01:51:04 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:51:42 --> Config Class Initialized
INFO - 2023-01-11 01:51:42 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:42 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:42 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:42 --> URI Class Initialized
INFO - 2023-01-11 01:51:42 --> Router Class Initialized
INFO - 2023-01-11 01:51:42 --> Output Class Initialized
INFO - 2023-01-11 01:51:42 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:42 --> Input Class Initialized
INFO - 2023-01-11 01:51:42 --> Language Class Initialized
INFO - 2023-01-11 01:51:42 --> Loader Class Initialized
INFO - 2023-01-11 01:51:42 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:42 --> Final output sent to browser
DEBUG - 2023-01-11 01:51:42 --> Total execution time: 0.0069
INFO - 2023-01-11 01:51:42 --> Config Class Initialized
INFO - 2023-01-11 01:51:42 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:42 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:42 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:42 --> URI Class Initialized
INFO - 2023-01-11 01:51:42 --> Router Class Initialized
INFO - 2023-01-11 01:51:42 --> Output Class Initialized
INFO - 2023-01-11 01:51:42 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:42 --> Input Class Initialized
INFO - 2023-01-11 01:51:42 --> Language Class Initialized
INFO - 2023-01-11 01:51:42 --> Loader Class Initialized
INFO - 2023-01-11 01:51:42 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:42 --> Database Driver Class Initialized
INFO - 2023-01-11 01:51:42 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:51:42 --> Model "Node_model" initialized
INFO - 2023-01-11 01:51:42 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:51:59 --> Config Class Initialized
INFO - 2023-01-11 01:51:59 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:59 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:59 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:59 --> URI Class Initialized
INFO - 2023-01-11 01:51:59 --> Router Class Initialized
INFO - 2023-01-11 01:51:59 --> Output Class Initialized
INFO - 2023-01-11 01:51:59 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:59 --> Input Class Initialized
INFO - 2023-01-11 01:51:59 --> Language Class Initialized
INFO - 2023-01-11 01:51:59 --> Loader Class Initialized
INFO - 2023-01-11 01:51:59 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:59 --> Final output sent to browser
DEBUG - 2023-01-11 01:51:59 --> Total execution time: 0.0060
INFO - 2023-01-11 01:51:59 --> Config Class Initialized
INFO - 2023-01-11 01:51:59 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:51:59 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:51:59 --> Utf8 Class Initialized
INFO - 2023-01-11 01:51:59 --> URI Class Initialized
INFO - 2023-01-11 01:51:59 --> Router Class Initialized
INFO - 2023-01-11 01:51:59 --> Output Class Initialized
INFO - 2023-01-11 01:51:59 --> Security Class Initialized
DEBUG - 2023-01-11 01:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:51:59 --> Input Class Initialized
INFO - 2023-01-11 01:51:59 --> Language Class Initialized
INFO - 2023-01-11 01:51:59 --> Loader Class Initialized
INFO - 2023-01-11 01:51:59 --> Controller Class Initialized
DEBUG - 2023-01-11 01:51:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:51:59 --> Database Driver Class Initialized
INFO - 2023-01-11 01:51:59 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:51:59 --> Model "Node_model" initialized
INFO - 2023-01-11 01:51:59 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:52:16 --> Config Class Initialized
INFO - 2023-01-11 01:52:16 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:52:16 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:52:16 --> Utf8 Class Initialized
INFO - 2023-01-11 01:52:16 --> URI Class Initialized
INFO - 2023-01-11 01:52:16 --> Router Class Initialized
INFO - 2023-01-11 01:52:16 --> Output Class Initialized
INFO - 2023-01-11 01:52:16 --> Security Class Initialized
DEBUG - 2023-01-11 01:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:52:16 --> Input Class Initialized
INFO - 2023-01-11 01:52:16 --> Language Class Initialized
INFO - 2023-01-11 01:52:16 --> Loader Class Initialized
INFO - 2023-01-11 01:52:16 --> Controller Class Initialized
DEBUG - 2023-01-11 01:52:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:52:16 --> Final output sent to browser
DEBUG - 2023-01-11 01:52:16 --> Total execution time: 0.0057
INFO - 2023-01-11 01:52:16 --> Config Class Initialized
INFO - 2023-01-11 01:52:16 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:52:16 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:52:16 --> Utf8 Class Initialized
INFO - 2023-01-11 01:52:16 --> URI Class Initialized
INFO - 2023-01-11 01:52:16 --> Router Class Initialized
INFO - 2023-01-11 01:52:16 --> Output Class Initialized
INFO - 2023-01-11 01:52:16 --> Security Class Initialized
DEBUG - 2023-01-11 01:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:52:16 --> Input Class Initialized
INFO - 2023-01-11 01:52:16 --> Language Class Initialized
INFO - 2023-01-11 01:52:16 --> Loader Class Initialized
INFO - 2023-01-11 01:52:16 --> Controller Class Initialized
DEBUG - 2023-01-11 01:52:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:52:16 --> Database Driver Class Initialized
INFO - 2023-01-11 01:52:16 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:52:16 --> Model "Node_model" initialized
INFO - 2023-01-11 01:52:16 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:52:54 --> Config Class Initialized
INFO - 2023-01-11 01:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:52:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:52:54 --> URI Class Initialized
INFO - 2023-01-11 01:52:54 --> Router Class Initialized
INFO - 2023-01-11 01:52:54 --> Output Class Initialized
INFO - 2023-01-11 01:52:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:52:54 --> Input Class Initialized
INFO - 2023-01-11 01:52:54 --> Language Class Initialized
INFO - 2023-01-11 01:52:54 --> Loader Class Initialized
INFO - 2023-01-11 01:52:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:52:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:52:54 --> Total execution time: 0.0051
INFO - 2023-01-11 01:52:54 --> Config Class Initialized
INFO - 2023-01-11 01:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:52:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:52:54 --> URI Class Initialized
INFO - 2023-01-11 01:52:54 --> Router Class Initialized
INFO - 2023-01-11 01:52:54 --> Output Class Initialized
INFO - 2023-01-11 01:52:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:52:54 --> Input Class Initialized
INFO - 2023-01-11 01:52:54 --> Language Class Initialized
INFO - 2023-01-11 01:52:54 --> Loader Class Initialized
INFO - 2023-01-11 01:52:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:52:54 --> Database Driver Class Initialized
INFO - 2023-01-11 01:52:54 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:52:54 --> Model "Node_model" initialized
INFO - 2023-01-11 01:52:54 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:52:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:52:54 --> Total execution time: 0.0634
INFO - 2023-01-11 01:53:29 --> Config Class Initialized
INFO - 2023-01-11 01:53:29 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:53:29 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:53:29 --> Utf8 Class Initialized
INFO - 2023-01-11 01:53:29 --> URI Class Initialized
INFO - 2023-01-11 01:53:29 --> Router Class Initialized
INFO - 2023-01-11 01:53:29 --> Output Class Initialized
INFO - 2023-01-11 01:53:29 --> Security Class Initialized
DEBUG - 2023-01-11 01:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:53:29 --> Input Class Initialized
INFO - 2023-01-11 01:53:29 --> Language Class Initialized
INFO - 2023-01-11 01:53:29 --> Loader Class Initialized
INFO - 2023-01-11 01:53:29 --> Controller Class Initialized
DEBUG - 2023-01-11 01:53:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:53:29 --> Final output sent to browser
DEBUG - 2023-01-11 01:53:29 --> Total execution time: 0.0056
INFO - 2023-01-11 01:53:29 --> Config Class Initialized
INFO - 2023-01-11 01:53:29 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:53:29 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:53:29 --> Utf8 Class Initialized
INFO - 2023-01-11 01:53:29 --> URI Class Initialized
INFO - 2023-01-11 01:53:29 --> Router Class Initialized
INFO - 2023-01-11 01:53:29 --> Output Class Initialized
INFO - 2023-01-11 01:53:29 --> Security Class Initialized
DEBUG - 2023-01-11 01:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:53:29 --> Input Class Initialized
INFO - 2023-01-11 01:53:29 --> Language Class Initialized
INFO - 2023-01-11 01:53:29 --> Loader Class Initialized
INFO - 2023-01-11 01:53:29 --> Controller Class Initialized
DEBUG - 2023-01-11 01:53:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:53:29 --> Database Driver Class Initialized
INFO - 2023-01-11 01:53:29 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:53:29 --> Model "Node_model" initialized
INFO - 2023-01-11 01:53:29 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:53:29 --> Final output sent to browser
DEBUG - 2023-01-11 01:53:29 --> Total execution time: 0.0309
INFO - 2023-01-11 01:53:49 --> Config Class Initialized
INFO - 2023-01-11 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:53:49 --> Utf8 Class Initialized
INFO - 2023-01-11 01:53:49 --> URI Class Initialized
INFO - 2023-01-11 01:53:49 --> Router Class Initialized
INFO - 2023-01-11 01:53:49 --> Output Class Initialized
INFO - 2023-01-11 01:53:49 --> Security Class Initialized
DEBUG - 2023-01-11 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:53:49 --> Input Class Initialized
INFO - 2023-01-11 01:53:49 --> Language Class Initialized
INFO - 2023-01-11 01:53:49 --> Loader Class Initialized
INFO - 2023-01-11 01:53:49 --> Controller Class Initialized
DEBUG - 2023-01-11 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:53:49 --> Final output sent to browser
DEBUG - 2023-01-11 01:53:49 --> Total execution time: 0.0050
INFO - 2023-01-11 01:53:49 --> Config Class Initialized
INFO - 2023-01-11 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:53:49 --> Utf8 Class Initialized
INFO - 2023-01-11 01:53:49 --> URI Class Initialized
INFO - 2023-01-11 01:53:49 --> Router Class Initialized
INFO - 2023-01-11 01:53:49 --> Output Class Initialized
INFO - 2023-01-11 01:53:49 --> Security Class Initialized
DEBUG - 2023-01-11 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:53:49 --> Input Class Initialized
INFO - 2023-01-11 01:53:49 --> Language Class Initialized
INFO - 2023-01-11 01:53:49 --> Loader Class Initialized
INFO - 2023-01-11 01:53:49 --> Controller Class Initialized
DEBUG - 2023-01-11 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:53:49 --> Database Driver Class Initialized
INFO - 2023-01-11 01:53:49 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:53:49 --> Model "Node_model" initialized
INFO - 2023-01-11 01:53:49 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:53:49 --> Final output sent to browser
DEBUG - 2023-01-11 01:53:49 --> Total execution time: 0.0259
INFO - 2023-01-11 01:54:27 --> Config Class Initialized
INFO - 2023-01-11 01:54:27 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:54:27 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:54:27 --> Utf8 Class Initialized
INFO - 2023-01-11 01:54:27 --> URI Class Initialized
INFO - 2023-01-11 01:54:27 --> Router Class Initialized
INFO - 2023-01-11 01:54:27 --> Output Class Initialized
INFO - 2023-01-11 01:54:27 --> Security Class Initialized
DEBUG - 2023-01-11 01:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:54:27 --> Input Class Initialized
INFO - 2023-01-11 01:54:27 --> Language Class Initialized
INFO - 2023-01-11 01:54:27 --> Loader Class Initialized
INFO - 2023-01-11 01:54:27 --> Controller Class Initialized
DEBUG - 2023-01-11 01:54:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:54:27 --> Final output sent to browser
DEBUG - 2023-01-11 01:54:27 --> Total execution time: 0.0097
INFO - 2023-01-11 01:54:27 --> Config Class Initialized
INFO - 2023-01-11 01:54:27 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:54:27 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:54:27 --> Utf8 Class Initialized
INFO - 2023-01-11 01:54:27 --> URI Class Initialized
INFO - 2023-01-11 01:54:27 --> Router Class Initialized
INFO - 2023-01-11 01:54:27 --> Output Class Initialized
INFO - 2023-01-11 01:54:27 --> Security Class Initialized
DEBUG - 2023-01-11 01:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:54:27 --> Input Class Initialized
INFO - 2023-01-11 01:54:27 --> Language Class Initialized
INFO - 2023-01-11 01:54:27 --> Loader Class Initialized
INFO - 2023-01-11 01:54:27 --> Controller Class Initialized
DEBUG - 2023-01-11 01:54:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:54:27 --> Database Driver Class Initialized
INFO - 2023-01-11 01:54:27 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:54:27 --> Model "Node_model" initialized
INFO - 2023-01-11 01:54:27 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:54:49 --> Config Class Initialized
INFO - 2023-01-11 01:54:50 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:54:50 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:54:50 --> Utf8 Class Initialized
INFO - 2023-01-11 01:54:50 --> URI Class Initialized
INFO - 2023-01-11 01:54:50 --> Router Class Initialized
INFO - 2023-01-11 01:54:50 --> Output Class Initialized
INFO - 2023-01-11 01:54:50 --> Security Class Initialized
DEBUG - 2023-01-11 01:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:54:50 --> Input Class Initialized
INFO - 2023-01-11 01:54:50 --> Language Class Initialized
INFO - 2023-01-11 01:54:50 --> Loader Class Initialized
INFO - 2023-01-11 01:54:50 --> Controller Class Initialized
DEBUG - 2023-01-11 01:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:54:50 --> Final output sent to browser
DEBUG - 2023-01-11 01:54:50 --> Total execution time: 0.0454
INFO - 2023-01-11 01:54:50 --> Config Class Initialized
INFO - 2023-01-11 01:54:50 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:54:50 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:54:50 --> Utf8 Class Initialized
INFO - 2023-01-11 01:54:50 --> URI Class Initialized
INFO - 2023-01-11 01:54:50 --> Router Class Initialized
INFO - 2023-01-11 01:54:50 --> Output Class Initialized
INFO - 2023-01-11 01:54:50 --> Security Class Initialized
DEBUG - 2023-01-11 01:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:54:50 --> Input Class Initialized
INFO - 2023-01-11 01:54:50 --> Language Class Initialized
INFO - 2023-01-11 01:54:50 --> Loader Class Initialized
INFO - 2023-01-11 01:54:50 --> Controller Class Initialized
DEBUG - 2023-01-11 01:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:54:50 --> Database Driver Class Initialized
INFO - 2023-01-11 01:54:50 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:54:50 --> Model "Node_model" initialized
INFO - 2023-01-11 01:54:50 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:55:49 --> Config Class Initialized
INFO - 2023-01-11 01:55:49 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:55:49 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:55:49 --> Utf8 Class Initialized
INFO - 2023-01-11 01:55:49 --> URI Class Initialized
INFO - 2023-01-11 01:55:49 --> Router Class Initialized
INFO - 2023-01-11 01:55:49 --> Output Class Initialized
INFO - 2023-01-11 01:55:49 --> Security Class Initialized
DEBUG - 2023-01-11 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:55:49 --> Input Class Initialized
INFO - 2023-01-11 01:55:49 --> Language Class Initialized
INFO - 2023-01-11 01:55:49 --> Loader Class Initialized
INFO - 2023-01-11 01:55:49 --> Controller Class Initialized
DEBUG - 2023-01-11 01:55:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:55:49 --> Final output sent to browser
DEBUG - 2023-01-11 01:55:49 --> Total execution time: 0.0054
INFO - 2023-01-11 01:55:49 --> Config Class Initialized
INFO - 2023-01-11 01:55:49 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:55:49 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:55:49 --> Utf8 Class Initialized
INFO - 2023-01-11 01:55:49 --> URI Class Initialized
INFO - 2023-01-11 01:55:49 --> Router Class Initialized
INFO - 2023-01-11 01:55:49 --> Output Class Initialized
INFO - 2023-01-11 01:55:49 --> Security Class Initialized
DEBUG - 2023-01-11 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:55:49 --> Input Class Initialized
INFO - 2023-01-11 01:55:49 --> Language Class Initialized
INFO - 2023-01-11 01:55:49 --> Loader Class Initialized
INFO - 2023-01-11 01:55:49 --> Controller Class Initialized
DEBUG - 2023-01-11 01:55:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:55:49 --> Database Driver Class Initialized
INFO - 2023-01-11 01:55:49 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:55:49 --> Model "Node_model" initialized
INFO - 2023-01-11 01:55:49 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:55:49 --> Final output sent to browser
DEBUG - 2023-01-11 01:55:49 --> Total execution time: 0.0244
INFO - 2023-01-11 01:56:19 --> Config Class Initialized
INFO - 2023-01-11 01:56:19 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:56:19 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:56:19 --> Utf8 Class Initialized
INFO - 2023-01-11 01:56:19 --> URI Class Initialized
INFO - 2023-01-11 01:56:19 --> Router Class Initialized
INFO - 2023-01-11 01:56:19 --> Output Class Initialized
INFO - 2023-01-11 01:56:19 --> Security Class Initialized
DEBUG - 2023-01-11 01:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:56:19 --> Input Class Initialized
INFO - 2023-01-11 01:56:19 --> Language Class Initialized
INFO - 2023-01-11 01:56:19 --> Loader Class Initialized
INFO - 2023-01-11 01:56:19 --> Controller Class Initialized
DEBUG - 2023-01-11 01:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:56:19 --> Final output sent to browser
DEBUG - 2023-01-11 01:56:19 --> Total execution time: 0.0068
INFO - 2023-01-11 01:56:19 --> Config Class Initialized
INFO - 2023-01-11 01:56:19 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:56:19 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:56:19 --> Utf8 Class Initialized
INFO - 2023-01-11 01:56:19 --> URI Class Initialized
INFO - 2023-01-11 01:56:19 --> Router Class Initialized
INFO - 2023-01-11 01:56:19 --> Output Class Initialized
INFO - 2023-01-11 01:56:19 --> Security Class Initialized
DEBUG - 2023-01-11 01:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:56:19 --> Input Class Initialized
INFO - 2023-01-11 01:56:19 --> Language Class Initialized
INFO - 2023-01-11 01:56:19 --> Loader Class Initialized
INFO - 2023-01-11 01:56:19 --> Controller Class Initialized
DEBUG - 2023-01-11 01:56:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:56:19 --> Database Driver Class Initialized
INFO - 2023-01-11 01:56:19 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:56:19 --> Model "Node_model" initialized
INFO - 2023-01-11 01:56:19 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:56:19 --> Final output sent to browser
DEBUG - 2023-01-11 01:56:19 --> Total execution time: 0.0260
INFO - 2023-01-11 01:57:59 --> Config Class Initialized
INFO - 2023-01-11 01:57:59 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:57:59 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:57:59 --> Utf8 Class Initialized
INFO - 2023-01-11 01:57:59 --> URI Class Initialized
INFO - 2023-01-11 01:57:59 --> Router Class Initialized
INFO - 2023-01-11 01:57:59 --> Output Class Initialized
INFO - 2023-01-11 01:57:59 --> Security Class Initialized
DEBUG - 2023-01-11 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:57:59 --> Input Class Initialized
INFO - 2023-01-11 01:57:59 --> Language Class Initialized
INFO - 2023-01-11 01:57:59 --> Loader Class Initialized
INFO - 2023-01-11 01:57:59 --> Controller Class Initialized
DEBUG - 2023-01-11 01:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:57:59 --> Final output sent to browser
DEBUG - 2023-01-11 01:57:59 --> Total execution time: 0.0054
INFO - 2023-01-11 01:57:59 --> Config Class Initialized
INFO - 2023-01-11 01:57:59 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:57:59 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:57:59 --> Utf8 Class Initialized
INFO - 2023-01-11 01:57:59 --> URI Class Initialized
INFO - 2023-01-11 01:57:59 --> Router Class Initialized
INFO - 2023-01-11 01:57:59 --> Output Class Initialized
INFO - 2023-01-11 01:57:59 --> Security Class Initialized
DEBUG - 2023-01-11 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:57:59 --> Input Class Initialized
INFO - 2023-01-11 01:57:59 --> Language Class Initialized
INFO - 2023-01-11 01:57:59 --> Loader Class Initialized
INFO - 2023-01-11 01:57:59 --> Controller Class Initialized
DEBUG - 2023-01-11 01:57:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:57:59 --> Database Driver Class Initialized
INFO - 2023-01-11 01:57:59 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:57:59 --> Model "Node_model" initialized
INFO - 2023-01-11 01:57:59 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:57:59 --> Final output sent to browser
DEBUG - 2023-01-11 01:57:59 --> Total execution time: 0.0257
INFO - 2023-01-11 01:58:54 --> Config Class Initialized
INFO - 2023-01-11 01:58:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:58:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:58:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:58:54 --> URI Class Initialized
INFO - 2023-01-11 01:58:54 --> Router Class Initialized
INFO - 2023-01-11 01:58:54 --> Output Class Initialized
INFO - 2023-01-11 01:58:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:58:54 --> Input Class Initialized
INFO - 2023-01-11 01:58:54 --> Language Class Initialized
INFO - 2023-01-11 01:58:54 --> Loader Class Initialized
INFO - 2023-01-11 01:58:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:58:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:58:54 --> Total execution time: 0.0059
INFO - 2023-01-11 01:58:54 --> Config Class Initialized
INFO - 2023-01-11 01:58:54 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:58:54 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:58:54 --> Utf8 Class Initialized
INFO - 2023-01-11 01:58:54 --> URI Class Initialized
INFO - 2023-01-11 01:58:54 --> Router Class Initialized
INFO - 2023-01-11 01:58:54 --> Output Class Initialized
INFO - 2023-01-11 01:58:54 --> Security Class Initialized
DEBUG - 2023-01-11 01:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:58:54 --> Input Class Initialized
INFO - 2023-01-11 01:58:54 --> Language Class Initialized
INFO - 2023-01-11 01:58:54 --> Loader Class Initialized
INFO - 2023-01-11 01:58:54 --> Controller Class Initialized
DEBUG - 2023-01-11 01:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:58:54 --> Database Driver Class Initialized
INFO - 2023-01-11 01:58:54 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:58:54 --> Model "Node_model" initialized
INFO - 2023-01-11 01:58:54 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:58:54 --> Final output sent to browser
DEBUG - 2023-01-11 01:58:54 --> Total execution time: 0.0271
INFO - 2023-01-11 01:59:38 --> Config Class Initialized
INFO - 2023-01-11 01:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:59:38 --> Utf8 Class Initialized
INFO - 2023-01-11 01:59:38 --> URI Class Initialized
INFO - 2023-01-11 01:59:38 --> Router Class Initialized
INFO - 2023-01-11 01:59:38 --> Output Class Initialized
INFO - 2023-01-11 01:59:38 --> Security Class Initialized
DEBUG - 2023-01-11 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:59:38 --> Input Class Initialized
INFO - 2023-01-11 01:59:38 --> Language Class Initialized
INFO - 2023-01-11 01:59:38 --> Loader Class Initialized
INFO - 2023-01-11 01:59:38 --> Controller Class Initialized
DEBUG - 2023-01-11 01:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:59:38 --> Final output sent to browser
DEBUG - 2023-01-11 01:59:38 --> Total execution time: 0.0059
INFO - 2023-01-11 01:59:38 --> Config Class Initialized
INFO - 2023-01-11 01:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-11 01:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-11 01:59:38 --> Utf8 Class Initialized
INFO - 2023-01-11 01:59:38 --> URI Class Initialized
INFO - 2023-01-11 01:59:38 --> Router Class Initialized
INFO - 2023-01-11 01:59:38 --> Output Class Initialized
INFO - 2023-01-11 01:59:38 --> Security Class Initialized
DEBUG - 2023-01-11 01:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 01:59:38 --> Input Class Initialized
INFO - 2023-01-11 01:59:38 --> Language Class Initialized
INFO - 2023-01-11 01:59:38 --> Loader Class Initialized
INFO - 2023-01-11 01:59:38 --> Controller Class Initialized
DEBUG - 2023-01-11 01:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 01:59:38 --> Database Driver Class Initialized
INFO - 2023-01-11 01:59:38 --> Model "Cluster_model" initialized
INFO - 2023-01-11 01:59:38 --> Model "Node_model" initialized
INFO - 2023-01-11 01:59:38 --> Model "Grafana_model" initialized
INFO - 2023-01-11 01:59:38 --> Final output sent to browser
DEBUG - 2023-01-11 01:59:38 --> Total execution time: 0.0251
INFO - 2023-01-11 02:00:00 --> Config Class Initialized
INFO - 2023-01-11 02:00:00 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:00:00 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:00:00 --> Utf8 Class Initialized
INFO - 2023-01-11 02:00:00 --> URI Class Initialized
INFO - 2023-01-11 02:00:00 --> Router Class Initialized
INFO - 2023-01-11 02:00:00 --> Output Class Initialized
INFO - 2023-01-11 02:00:00 --> Security Class Initialized
DEBUG - 2023-01-11 02:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:00:00 --> Input Class Initialized
INFO - 2023-01-11 02:00:00 --> Language Class Initialized
INFO - 2023-01-11 02:00:00 --> Loader Class Initialized
INFO - 2023-01-11 02:00:00 --> Controller Class Initialized
DEBUG - 2023-01-11 02:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:00:00 --> Final output sent to browser
DEBUG - 2023-01-11 02:00:00 --> Total execution time: 0.0099
INFO - 2023-01-11 02:00:00 --> Config Class Initialized
INFO - 2023-01-11 02:00:00 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:00:00 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:00:00 --> Utf8 Class Initialized
INFO - 2023-01-11 02:00:00 --> URI Class Initialized
INFO - 2023-01-11 02:00:00 --> Router Class Initialized
INFO - 2023-01-11 02:00:00 --> Output Class Initialized
INFO - 2023-01-11 02:00:00 --> Security Class Initialized
DEBUG - 2023-01-11 02:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:00:00 --> Input Class Initialized
INFO - 2023-01-11 02:00:00 --> Language Class Initialized
INFO - 2023-01-11 02:00:00 --> Loader Class Initialized
INFO - 2023-01-11 02:00:00 --> Controller Class Initialized
DEBUG - 2023-01-11 02:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:00:00 --> Database Driver Class Initialized
INFO - 2023-01-11 02:00:00 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:00:00 --> Model "Node_model" initialized
INFO - 2023-01-11 02:00:00 --> Model "Grafana_model" initialized
INFO - 2023-01-11 02:00:00 --> Final output sent to browser
DEBUG - 2023-01-11 02:00:00 --> Total execution time: 0.0386
INFO - 2023-01-11 02:07:52 --> Config Class Initialized
INFO - 2023-01-11 02:07:52 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:07:52 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:07:52 --> Utf8 Class Initialized
INFO - 2023-01-11 02:07:52 --> URI Class Initialized
INFO - 2023-01-11 02:07:52 --> Router Class Initialized
INFO - 2023-01-11 02:07:52 --> Output Class Initialized
INFO - 2023-01-11 02:07:52 --> Security Class Initialized
DEBUG - 2023-01-11 02:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:07:52 --> Input Class Initialized
INFO - 2023-01-11 02:07:52 --> Language Class Initialized
INFO - 2023-01-11 02:07:52 --> Loader Class Initialized
INFO - 2023-01-11 02:07:52 --> Controller Class Initialized
DEBUG - 2023-01-11 02:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:07:52 --> Final output sent to browser
DEBUG - 2023-01-11 02:07:52 --> Total execution time: 0.0054
INFO - 2023-01-11 02:07:52 --> Config Class Initialized
INFO - 2023-01-11 02:07:52 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:07:52 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:07:52 --> Utf8 Class Initialized
INFO - 2023-01-11 02:07:52 --> URI Class Initialized
INFO - 2023-01-11 02:07:52 --> Router Class Initialized
INFO - 2023-01-11 02:07:52 --> Output Class Initialized
INFO - 2023-01-11 02:07:52 --> Security Class Initialized
DEBUG - 2023-01-11 02:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:07:52 --> Input Class Initialized
INFO - 2023-01-11 02:07:52 --> Language Class Initialized
INFO - 2023-01-11 02:07:52 --> Loader Class Initialized
INFO - 2023-01-11 02:07:52 --> Controller Class Initialized
DEBUG - 2023-01-11 02:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:07:52 --> Database Driver Class Initialized
INFO - 2023-01-11 02:07:52 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:07:52 --> Model "Node_model" initialized
INFO - 2023-01-11 02:07:52 --> Model "Grafana_model" initialized
INFO - 2023-01-11 02:07:52 --> Final output sent to browser
DEBUG - 2023-01-11 02:07:52 --> Total execution time: 0.0422
INFO - 2023-01-11 02:10:14 --> Config Class Initialized
INFO - 2023-01-11 02:10:14 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:10:14 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:10:14 --> Utf8 Class Initialized
INFO - 2023-01-11 02:10:14 --> URI Class Initialized
INFO - 2023-01-11 02:10:14 --> Router Class Initialized
INFO - 2023-01-11 02:10:14 --> Output Class Initialized
INFO - 2023-01-11 02:10:14 --> Security Class Initialized
DEBUG - 2023-01-11 02:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:10:14 --> Input Class Initialized
INFO - 2023-01-11 02:10:14 --> Language Class Initialized
INFO - 2023-01-11 02:10:14 --> Loader Class Initialized
INFO - 2023-01-11 02:10:14 --> Controller Class Initialized
DEBUG - 2023-01-11 02:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:10:14 --> Final output sent to browser
DEBUG - 2023-01-11 02:10:14 --> Total execution time: 0.0128
INFO - 2023-01-11 02:10:14 --> Config Class Initialized
INFO - 2023-01-11 02:10:14 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:10:14 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:10:14 --> Utf8 Class Initialized
INFO - 2023-01-11 02:10:14 --> URI Class Initialized
INFO - 2023-01-11 02:10:14 --> Router Class Initialized
INFO - 2023-01-11 02:10:14 --> Output Class Initialized
INFO - 2023-01-11 02:10:14 --> Security Class Initialized
DEBUG - 2023-01-11 02:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:10:14 --> Input Class Initialized
INFO - 2023-01-11 02:10:14 --> Language Class Initialized
INFO - 2023-01-11 02:10:14 --> Loader Class Initialized
INFO - 2023-01-11 02:10:14 --> Controller Class Initialized
DEBUG - 2023-01-11 02:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:10:14 --> Database Driver Class Initialized
INFO - 2023-01-11 02:10:14 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:10:14 --> Model "Node_model" initialized
INFO - 2023-01-11 02:10:14 --> Model "Grafana_model" initialized
INFO - 2023-01-11 02:10:14 --> Final output sent to browser
DEBUG - 2023-01-11 02:10:14 --> Total execution time: 0.0405
INFO - 2023-01-11 02:33:06 --> Config Class Initialized
INFO - 2023-01-11 02:33:06 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:06 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:06 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:06 --> URI Class Initialized
INFO - 2023-01-11 02:33:06 --> Router Class Initialized
INFO - 2023-01-11 02:33:06 --> Output Class Initialized
INFO - 2023-01-11 02:33:06 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:06 --> Input Class Initialized
INFO - 2023-01-11 02:33:06 --> Language Class Initialized
INFO - 2023-01-11 02:33:06 --> Loader Class Initialized
INFO - 2023-01-11 02:33:06 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:06 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:06 --> Total execution time: 0.0835
INFO - 2023-01-11 02:33:06 --> Config Class Initialized
INFO - 2023-01-11 02:33:07 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:07 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:07 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:07 --> URI Class Initialized
INFO - 2023-01-11 02:33:07 --> Router Class Initialized
INFO - 2023-01-11 02:33:07 --> Output Class Initialized
INFO - 2023-01-11 02:33:07 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:07 --> Input Class Initialized
INFO - 2023-01-11 02:33:07 --> Language Class Initialized
INFO - 2023-01-11 02:33:07 --> Loader Class Initialized
INFO - 2023-01-11 02:33:07 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:07 --> Database Driver Class Initialized
ERROR - 2023-01-11 02:33:07 --> Unable to connect to the database
INFO - 2023-01-11 02:33:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-11 02:33:10 --> Config Class Initialized
INFO - 2023-01-11 02:33:10 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:10 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:10 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:10 --> URI Class Initialized
INFO - 2023-01-11 02:33:10 --> Router Class Initialized
INFO - 2023-01-11 02:33:10 --> Output Class Initialized
INFO - 2023-01-11 02:33:10 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:10 --> Input Class Initialized
INFO - 2023-01-11 02:33:10 --> Language Class Initialized
INFO - 2023-01-11 02:33:10 --> Loader Class Initialized
INFO - 2023-01-11 02:33:10 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:10 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:10 --> Total execution time: 0.0041
INFO - 2023-01-11 02:33:21 --> Config Class Initialized
INFO - 2023-01-11 02:33:21 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:21 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:21 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:21 --> URI Class Initialized
INFO - 2023-01-11 02:33:21 --> Router Class Initialized
INFO - 2023-01-11 02:33:21 --> Output Class Initialized
INFO - 2023-01-11 02:33:21 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:21 --> Input Class Initialized
INFO - 2023-01-11 02:33:21 --> Language Class Initialized
INFO - 2023-01-11 02:33:21 --> Loader Class Initialized
INFO - 2023-01-11 02:33:21 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:21 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:21 --> Total execution time: 0.0824
INFO - 2023-01-11 02:33:21 --> Config Class Initialized
INFO - 2023-01-11 02:33:21 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:21 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:21 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:21 --> URI Class Initialized
INFO - 2023-01-11 02:33:21 --> Router Class Initialized
INFO - 2023-01-11 02:33:21 --> Output Class Initialized
INFO - 2023-01-11 02:33:21 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:21 --> Input Class Initialized
INFO - 2023-01-11 02:33:21 --> Language Class Initialized
INFO - 2023-01-11 02:33:21 --> Loader Class Initialized
INFO - 2023-01-11 02:33:21 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:21 --> Database Driver Class Initialized
ERROR - 2023-01-11 02:33:21 --> Unable to connect to the database
INFO - 2023-01-11 02:33:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-11 02:33:31 --> Config Class Initialized
INFO - 2023-01-11 02:33:31 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:31 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:31 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:31 --> URI Class Initialized
INFO - 2023-01-11 02:33:31 --> Router Class Initialized
INFO - 2023-01-11 02:33:31 --> Output Class Initialized
INFO - 2023-01-11 02:33:31 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:31 --> Input Class Initialized
INFO - 2023-01-11 02:33:31 --> Language Class Initialized
INFO - 2023-01-11 02:33:31 --> Loader Class Initialized
INFO - 2023-01-11 02:33:31 --> Controller Class Initialized
INFO - 2023-01-11 02:33:31 --> Helper loaded: form_helper
INFO - 2023-01-11 02:33:31 --> Helper loaded: url_helper
DEBUG - 2023-01-11 02:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:31 --> Model "Change_model" initialized
INFO - 2023-01-11 02:33:31 --> Model "Grafana_model" initialized
INFO - 2023-01-11 02:33:31 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:31 --> Total execution time: 0.0311
INFO - 2023-01-11 02:33:31 --> Config Class Initialized
INFO - 2023-01-11 02:33:31 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:31 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:31 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:32 --> URI Class Initialized
INFO - 2023-01-11 02:33:32 --> Router Class Initialized
INFO - 2023-01-11 02:33:32 --> Output Class Initialized
INFO - 2023-01-11 02:33:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:32 --> Input Class Initialized
INFO - 2023-01-11 02:33:32 --> Language Class Initialized
INFO - 2023-01-11 02:33:32 --> Loader Class Initialized
INFO - 2023-01-11 02:33:32 --> Controller Class Initialized
INFO - 2023-01-11 02:33:32 --> Helper loaded: form_helper
INFO - 2023-01-11 02:33:32 --> Helper loaded: url_helper
DEBUG - 2023-01-11 02:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:32 --> Total execution time: 0.0422
INFO - 2023-01-11 02:33:32 --> Config Class Initialized
INFO - 2023-01-11 02:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:32 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:32 --> URI Class Initialized
INFO - 2023-01-11 02:33:32 --> Router Class Initialized
INFO - 2023-01-11 02:33:32 --> Output Class Initialized
INFO - 2023-01-11 02:33:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:32 --> Input Class Initialized
INFO - 2023-01-11 02:33:32 --> Language Class Initialized
INFO - 2023-01-11 02:33:32 --> Loader Class Initialized
INFO - 2023-01-11 02:33:32 --> Controller Class Initialized
INFO - 2023-01-11 02:33:32 --> Helper loaded: form_helper
INFO - 2023-01-11 02:33:32 --> Helper loaded: url_helper
DEBUG - 2023-01-11 02:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:32 --> Database Driver Class Initialized
INFO - 2023-01-11 02:33:32 --> Model "Login_model" initialized
INFO - 2023-01-11 02:33:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:32 --> Total execution time: 0.0167
INFO - 2023-01-11 02:33:32 --> Config Class Initialized
INFO - 2023-01-11 02:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:32 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:32 --> URI Class Initialized
INFO - 2023-01-11 02:33:32 --> Router Class Initialized
INFO - 2023-01-11 02:33:32 --> Output Class Initialized
INFO - 2023-01-11 02:33:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:32 --> Input Class Initialized
INFO - 2023-01-11 02:33:32 --> Language Class Initialized
INFO - 2023-01-11 02:33:32 --> Loader Class Initialized
INFO - 2023-01-11 02:33:32 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:32 --> Database Driver Class Initialized
INFO - 2023-01-11 02:33:32 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:33:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:32 --> Total execution time: 0.0843
INFO - 2023-01-11 02:33:32 --> Config Class Initialized
INFO - 2023-01-11 02:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:32 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:32 --> URI Class Initialized
INFO - 2023-01-11 02:33:32 --> Router Class Initialized
INFO - 2023-01-11 02:33:32 --> Output Class Initialized
INFO - 2023-01-11 02:33:32 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:32 --> Input Class Initialized
INFO - 2023-01-11 02:33:32 --> Language Class Initialized
INFO - 2023-01-11 02:33:32 --> Loader Class Initialized
INFO - 2023-01-11 02:33:32 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:32 --> Database Driver Class Initialized
INFO - 2023-01-11 02:33:32 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:33:32 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:32 --> Total execution time: 0.0180
INFO - 2023-01-11 02:33:33 --> Config Class Initialized
INFO - 2023-01-11 02:33:33 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:33 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:33 --> URI Class Initialized
INFO - 2023-01-11 02:33:33 --> Router Class Initialized
INFO - 2023-01-11 02:33:33 --> Output Class Initialized
INFO - 2023-01-11 02:33:33 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:33 --> Input Class Initialized
INFO - 2023-01-11 02:33:33 --> Language Class Initialized
INFO - 2023-01-11 02:33:33 --> Loader Class Initialized
INFO - 2023-01-11 02:33:33 --> Controller Class Initialized
INFO - 2023-01-11 02:33:33 --> Helper loaded: form_helper
INFO - 2023-01-11 02:33:33 --> Helper loaded: url_helper
DEBUG - 2023-01-11 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:33 --> Model "Change_model" initialized
INFO - 2023-01-11 02:33:33 --> Model "Grafana_model" initialized
INFO - 2023-01-11 02:33:33 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:33 --> Total execution time: 0.0254
INFO - 2023-01-11 02:33:33 --> Config Class Initialized
INFO - 2023-01-11 02:33:33 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:33 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:33 --> URI Class Initialized
INFO - 2023-01-11 02:33:33 --> Router Class Initialized
INFO - 2023-01-11 02:33:33 --> Output Class Initialized
INFO - 2023-01-11 02:33:33 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:33 --> Input Class Initialized
INFO - 2023-01-11 02:33:33 --> Language Class Initialized
INFO - 2023-01-11 02:33:33 --> Loader Class Initialized
INFO - 2023-01-11 02:33:33 --> Controller Class Initialized
INFO - 2023-01-11 02:33:33 --> Helper loaded: form_helper
INFO - 2023-01-11 02:33:33 --> Helper loaded: url_helper
DEBUG - 2023-01-11 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:33 --> Database Driver Class Initialized
INFO - 2023-01-11 02:33:33 --> Model "Login_model" initialized
INFO - 2023-01-11 02:33:33 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:33 --> Total execution time: 0.0192
INFO - 2023-01-11 02:33:33 --> Config Class Initialized
INFO - 2023-01-11 02:33:33 --> Hooks Class Initialized
DEBUG - 2023-01-11 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-01-11 02:33:33 --> Utf8 Class Initialized
INFO - 2023-01-11 02:33:33 --> URI Class Initialized
INFO - 2023-01-11 02:33:33 --> Router Class Initialized
INFO - 2023-01-11 02:33:33 --> Output Class Initialized
INFO - 2023-01-11 02:33:33 --> Security Class Initialized
DEBUG - 2023-01-11 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-11 02:33:33 --> Input Class Initialized
INFO - 2023-01-11 02:33:33 --> Language Class Initialized
INFO - 2023-01-11 02:33:33 --> Loader Class Initialized
INFO - 2023-01-11 02:33:33 --> Controller Class Initialized
DEBUG - 2023-01-11 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-11 02:33:33 --> Database Driver Class Initialized
INFO - 2023-01-11 02:33:33 --> Model "Cluster_model" initialized
INFO - 2023-01-11 02:33:33 --> Final output sent to browser
DEBUG - 2023-01-11 02:33:33 --> Total execution time: 0.0159
