<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
INFO - 2023-04-20 03:16:25 --> Helper loaded: form_helper
INFO - 2023-04-20 03:16:25 --> Helper loaded: url_helper
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Model "Change_model" initialized
INFO - 2023-04-20 03:16:25 --> Model "Grafana_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.1177
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
INFO - 2023-04-20 03:16:25 --> Helper loaded: form_helper
INFO - 2023-04-20 03:16:25 --> Helper loaded: url_helper
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.0451
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
INFO - 2023-04-20 03:16:25 --> Helper loaded: form_helper
INFO - 2023-04-20 03:16:25 --> Helper loaded: url_helper
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.0656
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.0395
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.0116
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.1904
INFO - 2023-04-20 03:16:25 --> Config Class Initialized
INFO - 2023-04-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:25 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:25 --> URI Class Initialized
INFO - 2023-04-20 03:16:25 --> Router Class Initialized
INFO - 2023-04-20 03:16:25 --> Output Class Initialized
INFO - 2023-04-20 03:16:25 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:25 --> Input Class Initialized
INFO - 2023-04-20 03:16:25 --> Language Class Initialized
INFO - 2023-04-20 03:16:25 --> Loader Class Initialized
INFO - 2023-04-20 03:16:25 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:25 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:25 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:25 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:25 --> Total execution time: 0.1044
INFO - 2023-04-20 03:16:31 --> Config Class Initialized
INFO - 2023-04-20 03:16:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:31 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:31 --> URI Class Initialized
INFO - 2023-04-20 03:16:31 --> Router Class Initialized
INFO - 2023-04-20 03:16:31 --> Output Class Initialized
INFO - 2023-04-20 03:16:31 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:31 --> Input Class Initialized
INFO - 2023-04-20 03:16:31 --> Language Class Initialized
INFO - 2023-04-20 03:16:31 --> Loader Class Initialized
INFO - 2023-04-20 03:16:31 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:31 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:31 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:31 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:31 --> Total execution time: 0.0509
INFO - 2023-04-20 03:16:31 --> Config Class Initialized
INFO - 2023-04-20 03:16:31 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:31 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:31 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:31 --> URI Class Initialized
INFO - 2023-04-20 03:16:31 --> Router Class Initialized
INFO - 2023-04-20 03:16:31 --> Output Class Initialized
INFO - 2023-04-20 03:16:31 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:31 --> Input Class Initialized
INFO - 2023-04-20 03:16:31 --> Language Class Initialized
INFO - 2023-04-20 03:16:31 --> Loader Class Initialized
INFO - 2023-04-20 03:16:31 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:31 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:31 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:31 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:31 --> Total execution time: 0.0826
INFO - 2023-04-20 03:16:33 --> Config Class Initialized
INFO - 2023-04-20 03:16:33 --> Config Class Initialized
INFO - 2023-04-20 03:16:33 --> Hooks Class Initialized
INFO - 2023-04-20 03:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 03:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:33 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:33 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:33 --> URI Class Initialized
INFO - 2023-04-20 03:16:33 --> URI Class Initialized
INFO - 2023-04-20 03:16:33 --> Router Class Initialized
INFO - 2023-04-20 03:16:33 --> Router Class Initialized
INFO - 2023-04-20 03:16:33 --> Output Class Initialized
INFO - 2023-04-20 03:16:33 --> Output Class Initialized
INFO - 2023-04-20 03:16:33 --> Security Class Initialized
INFO - 2023-04-20 03:16:33 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:33 --> Input Class Initialized
INFO - 2023-04-20 03:16:33 --> Input Class Initialized
INFO - 2023-04-20 03:16:33 --> Language Class Initialized
INFO - 2023-04-20 03:16:33 --> Language Class Initialized
INFO - 2023-04-20 03:16:33 --> Loader Class Initialized
INFO - 2023-04-20 03:16:33 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:33 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:33 --> Loader Class Initialized
INFO - 2023-04-20 03:16:33 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:33 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:33 --> Total execution time: 0.0117
INFO - 2023-04-20 03:16:33 --> Config Class Initialized
INFO - 2023-04-20 03:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:33 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:33 --> URI Class Initialized
INFO - 2023-04-20 03:16:33 --> Router Class Initialized
INFO - 2023-04-20 03:16:33 --> Output Class Initialized
INFO - 2023-04-20 03:16:33 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:33 --> Input Class Initialized
INFO - 2023-04-20 03:16:33 --> Language Class Initialized
INFO - 2023-04-20 03:16:33 --> Loader Class Initialized
INFO - 2023-04-20 03:16:33 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:33 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:33 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:33 --> Total execution time: 0.0202
INFO - 2023-04-20 03:16:33 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:33 --> Config Class Initialized
INFO - 2023-04-20 03:16:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:33 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:33 --> URI Class Initialized
INFO - 2023-04-20 03:16:33 --> Router Class Initialized
INFO - 2023-04-20 03:16:33 --> Output Class Initialized
INFO - 2023-04-20 03:16:33 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:33 --> Input Class Initialized
INFO - 2023-04-20 03:16:33 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:33 --> Language Class Initialized
INFO - 2023-04-20 03:16:33 --> Loader Class Initialized
INFO - 2023-04-20 03:16:33 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:33 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:33 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:33 --> Total execution time: 0.0217
INFO - 2023-04-20 03:16:33 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:33 --> Total execution time: 0.0163
INFO - 2023-04-20 03:16:36 --> Config Class Initialized
INFO - 2023-04-20 03:16:36 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:36 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:36 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:36 --> URI Class Initialized
INFO - 2023-04-20 03:16:36 --> Router Class Initialized
INFO - 2023-04-20 03:16:36 --> Output Class Initialized
INFO - 2023-04-20 03:16:36 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:36 --> Input Class Initialized
INFO - 2023-04-20 03:16:36 --> Language Class Initialized
INFO - 2023-04-20 03:16:36 --> Loader Class Initialized
INFO - 2023-04-20 03:16:36 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:36 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:36 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:36 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:36 --> Total execution time: 0.0441
INFO - 2023-04-20 03:16:39 --> Config Class Initialized
INFO - 2023-04-20 03:16:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:39 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:39 --> URI Class Initialized
INFO - 2023-04-20 03:16:39 --> Router Class Initialized
INFO - 2023-04-20 03:16:39 --> Output Class Initialized
INFO - 2023-04-20 03:16:39 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:39 --> Input Class Initialized
INFO - 2023-04-20 03:16:39 --> Language Class Initialized
INFO - 2023-04-20 03:16:39 --> Loader Class Initialized
INFO - 2023-04-20 03:16:39 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:39 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:39 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:39 --> Total execution time: 0.0552
INFO - 2023-04-20 03:16:39 --> Config Class Initialized
INFO - 2023-04-20 03:16:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:39 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:39 --> URI Class Initialized
INFO - 2023-04-20 03:16:39 --> Router Class Initialized
INFO - 2023-04-20 03:16:39 --> Output Class Initialized
INFO - 2023-04-20 03:16:39 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:39 --> Input Class Initialized
INFO - 2023-04-20 03:16:39 --> Language Class Initialized
INFO - 2023-04-20 03:16:39 --> Loader Class Initialized
INFO - 2023-04-20 03:16:39 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:39 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:39 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:39 --> Total execution time: 0.0497
INFO - 2023-04-20 03:16:42 --> Config Class Initialized
INFO - 2023-04-20 03:16:42 --> Config Class Initialized
INFO - 2023-04-20 03:16:42 --> Hooks Class Initialized
INFO - 2023-04-20 03:16:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:42 --> Utf8 Class Initialized
DEBUG - 2023-04-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:42 --> URI Class Initialized
INFO - 2023-04-20 03:16:42 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:42 --> Router Class Initialized
INFO - 2023-04-20 03:16:42 --> URI Class Initialized
INFO - 2023-04-20 03:16:42 --> Output Class Initialized
INFO - 2023-04-20 03:16:42 --> Router Class Initialized
INFO - 2023-04-20 03:16:42 --> Security Class Initialized
INFO - 2023-04-20 03:16:42 --> Output Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:42 --> Security Class Initialized
INFO - 2023-04-20 03:16:42 --> Input Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:42 --> Language Class Initialized
INFO - 2023-04-20 03:16:42 --> Input Class Initialized
INFO - 2023-04-20 03:16:42 --> Language Class Initialized
INFO - 2023-04-20 03:16:42 --> Loader Class Initialized
INFO - 2023-04-20 03:16:42 --> Loader Class Initialized
INFO - 2023-04-20 03:16:42 --> Controller Class Initialized
INFO - 2023-04-20 03:16:42 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:42 --> Final output sent to browser
INFO - 2023-04-20 03:16:42 --> Database Driver Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Total execution time: 0.0056
INFO - 2023-04-20 03:16:42 --> Config Class Initialized
INFO - 2023-04-20 03:16:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:42 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:42 --> URI Class Initialized
INFO - 2023-04-20 03:16:42 --> Router Class Initialized
INFO - 2023-04-20 03:16:42 --> Output Class Initialized
INFO - 2023-04-20 03:16:42 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:42 --> Input Class Initialized
INFO - 2023-04-20 03:16:42 --> Language Class Initialized
INFO - 2023-04-20 03:16:42 --> Loader Class Initialized
INFO - 2023-04-20 03:16:42 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:42 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:42 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:42 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:42 --> Total execution time: 0.0315
INFO - 2023-04-20 03:16:42 --> Config Class Initialized
INFO - 2023-04-20 03:16:42 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:42 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:42 --> URI Class Initialized
INFO - 2023-04-20 03:16:42 --> Router Class Initialized
INFO - 2023-04-20 03:16:42 --> Output Class Initialized
INFO - 2023-04-20 03:16:42 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:42 --> Input Class Initialized
INFO - 2023-04-20 03:16:42 --> Language Class Initialized
INFO - 2023-04-20 03:16:42 --> Loader Class Initialized
INFO - 2023-04-20 03:16:42 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:42 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:42 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:42 --> Total execution time: 0.0598
INFO - 2023-04-20 03:16:42 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:42 --> Total execution time: 0.0383
INFO - 2023-04-20 03:16:44 --> Config Class Initialized
INFO - 2023-04-20 03:16:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:44 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:44 --> URI Class Initialized
INFO - 2023-04-20 03:16:44 --> Router Class Initialized
INFO - 2023-04-20 03:16:44 --> Output Class Initialized
INFO - 2023-04-20 03:16:44 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:44 --> Input Class Initialized
INFO - 2023-04-20 03:16:44 --> Language Class Initialized
INFO - 2023-04-20 03:16:44 --> Loader Class Initialized
INFO - 2023-04-20 03:16:44 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:44 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:44 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:44 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:44 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:44 --> Total execution time: 0.1878
INFO - 2023-04-20 03:16:44 --> Config Class Initialized
INFO - 2023-04-20 03:16:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:44 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:44 --> URI Class Initialized
INFO - 2023-04-20 03:16:44 --> Router Class Initialized
INFO - 2023-04-20 03:16:44 --> Output Class Initialized
INFO - 2023-04-20 03:16:44 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:44 --> Input Class Initialized
INFO - 2023-04-20 03:16:44 --> Language Class Initialized
INFO - 2023-04-20 03:16:44 --> Loader Class Initialized
INFO - 2023-04-20 03:16:44 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:44 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:45 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:45 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:45 --> Model "Login_model" initialized
INFO - 2023-04-20 03:16:45 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:45 --> Total execution time: 0.0586
INFO - 2023-04-20 03:16:48 --> Config Class Initialized
INFO - 2023-04-20 03:16:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:48 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:48 --> URI Class Initialized
INFO - 2023-04-20 03:16:48 --> Router Class Initialized
INFO - 2023-04-20 03:16:48 --> Output Class Initialized
INFO - 2023-04-20 03:16:48 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:48 --> Input Class Initialized
INFO - 2023-04-20 03:16:48 --> Language Class Initialized
INFO - 2023-04-20 03:16:48 --> Loader Class Initialized
INFO - 2023-04-20 03:16:48 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:48 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:48 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:48 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:48 --> Total execution time: 0.0135
INFO - 2023-04-20 03:16:48 --> Config Class Initialized
INFO - 2023-04-20 03:16:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:48 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:48 --> URI Class Initialized
INFO - 2023-04-20 03:16:48 --> Router Class Initialized
INFO - 2023-04-20 03:16:48 --> Output Class Initialized
INFO - 2023-04-20 03:16:48 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:48 --> Input Class Initialized
INFO - 2023-04-20 03:16:48 --> Language Class Initialized
INFO - 2023-04-20 03:16:48 --> Loader Class Initialized
INFO - 2023-04-20 03:16:48 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:48 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:48 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:48 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:48 --> Total execution time: 0.0934
INFO - 2023-04-20 03:16:51 --> Config Class Initialized
INFO - 2023-04-20 03:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:51 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:51 --> URI Class Initialized
INFO - 2023-04-20 03:16:51 --> Router Class Initialized
INFO - 2023-04-20 03:16:51 --> Output Class Initialized
INFO - 2023-04-20 03:16:51 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:51 --> Input Class Initialized
INFO - 2023-04-20 03:16:51 --> Language Class Initialized
INFO - 2023-04-20 03:16:51 --> Loader Class Initialized
INFO - 2023-04-20 03:16:51 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:51 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:51 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:51 --> Total execution time: 0.0135
INFO - 2023-04-20 03:16:51 --> Config Class Initialized
INFO - 2023-04-20 03:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:51 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:51 --> URI Class Initialized
INFO - 2023-04-20 03:16:51 --> Router Class Initialized
INFO - 2023-04-20 03:16:51 --> Output Class Initialized
INFO - 2023-04-20 03:16:51 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:51 --> Input Class Initialized
INFO - 2023-04-20 03:16:51 --> Language Class Initialized
INFO - 2023-04-20 03:16:51 --> Loader Class Initialized
INFO - 2023-04-20 03:16:51 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:51 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:51 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:51 --> Total execution time: 0.0103
INFO - 2023-04-20 03:16:51 --> Config Class Initialized
INFO - 2023-04-20 03:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:51 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:51 --> URI Class Initialized
INFO - 2023-04-20 03:16:51 --> Router Class Initialized
INFO - 2023-04-20 03:16:51 --> Output Class Initialized
INFO - 2023-04-20 03:16:51 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:51 --> Input Class Initialized
INFO - 2023-04-20 03:16:51 --> Language Class Initialized
INFO - 2023-04-20 03:16:51 --> Loader Class Initialized
INFO - 2023-04-20 03:16:51 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:51 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:51 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:51 --> Total execution time: 0.0517
INFO - 2023-04-20 03:16:51 --> Config Class Initialized
INFO - 2023-04-20 03:16:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:16:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:16:51 --> Utf8 Class Initialized
INFO - 2023-04-20 03:16:51 --> URI Class Initialized
INFO - 2023-04-20 03:16:51 --> Router Class Initialized
INFO - 2023-04-20 03:16:51 --> Output Class Initialized
INFO - 2023-04-20 03:16:51 --> Security Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:16:51 --> Input Class Initialized
INFO - 2023-04-20 03:16:51 --> Language Class Initialized
INFO - 2023-04-20 03:16:51 --> Loader Class Initialized
INFO - 2023-04-20 03:16:51 --> Controller Class Initialized
DEBUG - 2023-04-20 03:16:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:16:51 --> Database Driver Class Initialized
INFO - 2023-04-20 03:16:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:16:51 --> Final output sent to browser
DEBUG - 2023-04-20 03:16:51 --> Total execution time: 0.0114
INFO - 2023-04-20 03:19:34 --> Config Class Initialized
INFO - 2023-04-20 03:19:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:19:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:19:34 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:34 --> URI Class Initialized
INFO - 2023-04-20 03:19:34 --> Router Class Initialized
INFO - 2023-04-20 03:19:34 --> Output Class Initialized
INFO - 2023-04-20 03:19:34 --> Security Class Initialized
DEBUG - 2023-04-20 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:34 --> Input Class Initialized
INFO - 2023-04-20 03:19:34 --> Language Class Initialized
INFO - 2023-04-20 03:19:34 --> Loader Class Initialized
INFO - 2023-04-20 03:19:34 --> Controller Class Initialized
DEBUG - 2023-04-20 03:19:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:19:34 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:34 --> Final output sent to browser
DEBUG - 2023-04-20 03:19:34 --> Total execution time: 0.0299
INFO - 2023-04-20 03:19:34 --> Config Class Initialized
INFO - 2023-04-20 03:19:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:19:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:19:34 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:34 --> URI Class Initialized
INFO - 2023-04-20 03:19:34 --> Router Class Initialized
INFO - 2023-04-20 03:19:34 --> Output Class Initialized
INFO - 2023-04-20 03:19:34 --> Security Class Initialized
DEBUG - 2023-04-20 03:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:34 --> Input Class Initialized
INFO - 2023-04-20 03:19:34 --> Language Class Initialized
INFO - 2023-04-20 03:19:34 --> Loader Class Initialized
INFO - 2023-04-20 03:19:34 --> Controller Class Initialized
DEBUG - 2023-04-20 03:19:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:19:34 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:34 --> Final output sent to browser
DEBUG - 2023-04-20 03:19:35 --> Total execution time: 0.0684
INFO - 2023-04-20 03:19:43 --> Config Class Initialized
INFO - 2023-04-20 03:19:43 --> Config Class Initialized
INFO - 2023-04-20 03:19:43 --> Hooks Class Initialized
INFO - 2023-04-20 03:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 03:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:19:43 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:43 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:43 --> URI Class Initialized
INFO - 2023-04-20 03:19:43 --> URI Class Initialized
INFO - 2023-04-20 03:19:43 --> Router Class Initialized
INFO - 2023-04-20 03:19:43 --> Router Class Initialized
INFO - 2023-04-20 03:19:43 --> Output Class Initialized
INFO - 2023-04-20 03:19:43 --> Output Class Initialized
INFO - 2023-04-20 03:19:43 --> Security Class Initialized
INFO - 2023-04-20 03:19:43 --> Security Class Initialized
DEBUG - 2023-04-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:43 --> Input Class Initialized
DEBUG - 2023-04-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:43 --> Language Class Initialized
INFO - 2023-04-20 03:19:43 --> Input Class Initialized
INFO - 2023-04-20 03:19:43 --> Language Class Initialized
INFO - 2023-04-20 03:19:43 --> Loader Class Initialized
INFO - 2023-04-20 03:19:43 --> Loader Class Initialized
INFO - 2023-04-20 03:19:43 --> Controller Class Initialized
INFO - 2023-04-20 03:19:43 --> Controller Class Initialized
DEBUG - 2023-04-20 03:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 03:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:19:43 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:43 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:43 --> Final output sent to browser
INFO - 2023-04-20 03:19:43 --> Final output sent to browser
DEBUG - 2023-04-20 03:19:43 --> Total execution time: 0.0159
DEBUG - 2023-04-20 03:19:43 --> Total execution time: 0.0161
INFO - 2023-04-20 03:19:43 --> Config Class Initialized
INFO - 2023-04-20 03:19:43 --> Config Class Initialized
INFO - 2023-04-20 03:19:43 --> Hooks Class Initialized
INFO - 2023-04-20 03:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 03:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:19:43 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:43 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:43 --> URI Class Initialized
INFO - 2023-04-20 03:19:43 --> URI Class Initialized
INFO - 2023-04-20 03:19:43 --> Router Class Initialized
INFO - 2023-04-20 03:19:43 --> Router Class Initialized
INFO - 2023-04-20 03:19:43 --> Output Class Initialized
INFO - 2023-04-20 03:19:43 --> Output Class Initialized
INFO - 2023-04-20 03:19:43 --> Security Class Initialized
INFO - 2023-04-20 03:19:43 --> Security Class Initialized
DEBUG - 2023-04-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:43 --> Input Class Initialized
INFO - 2023-04-20 03:19:43 --> Input Class Initialized
INFO - 2023-04-20 03:19:43 --> Language Class Initialized
INFO - 2023-04-20 03:19:43 --> Language Class Initialized
INFO - 2023-04-20 03:19:43 --> Loader Class Initialized
INFO - 2023-04-20 03:19:43 --> Loader Class Initialized
INFO - 2023-04-20 03:19:43 --> Controller Class Initialized
INFO - 2023-04-20 03:19:43 --> Controller Class Initialized
DEBUG - 2023-04-20 03:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 03:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:19:43 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:43 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:43 --> Final output sent to browser
INFO - 2023-04-20 03:19:43 --> Final output sent to browser
DEBUG - 2023-04-20 03:19:43 --> Total execution time: 0.0549
DEBUG - 2023-04-20 03:19:43 --> Total execution time: 0.0549
INFO - 2023-04-20 03:19:46 --> Config Class Initialized
INFO - 2023-04-20 03:19:46 --> Hooks Class Initialized
DEBUG - 2023-04-20 03:19:46 --> UTF-8 Support Enabled
INFO - 2023-04-20 03:19:46 --> Utf8 Class Initialized
INFO - 2023-04-20 03:19:46 --> URI Class Initialized
INFO - 2023-04-20 03:19:46 --> Router Class Initialized
INFO - 2023-04-20 03:19:46 --> Output Class Initialized
INFO - 2023-04-20 03:19:46 --> Security Class Initialized
DEBUG - 2023-04-20 03:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 03:19:46 --> Input Class Initialized
INFO - 2023-04-20 03:19:46 --> Language Class Initialized
INFO - 2023-04-20 03:19:46 --> Loader Class Initialized
INFO - 2023-04-20 03:19:46 --> Controller Class Initialized
DEBUG - 2023-04-20 03:19:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 03:19:46 --> Database Driver Class Initialized
INFO - 2023-04-20 03:19:46 --> Model "Cluster_model" initialized
INFO - 2023-04-20 03:19:46 --> Final output sent to browser
DEBUG - 2023-04-20 03:19:46 --> Total execution time: 0.0175
INFO - 2023-04-20 06:25:42 --> Config Class Initialized
INFO - 2023-04-20 06:25:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:42 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:42 --> URI Class Initialized
INFO - 2023-04-20 06:25:42 --> Router Class Initialized
INFO - 2023-04-20 06:25:42 --> Output Class Initialized
INFO - 2023-04-20 06:25:42 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:42 --> Input Class Initialized
INFO - 2023-04-20 06:25:42 --> Language Class Initialized
INFO - 2023-04-20 06:25:42 --> Loader Class Initialized
INFO - 2023-04-20 06:25:42 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:42 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:42 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:42 --> Total execution time: 0.0298
INFO - 2023-04-20 06:25:42 --> Config Class Initialized
INFO - 2023-04-20 06:25:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:42 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:42 --> URI Class Initialized
INFO - 2023-04-20 06:25:42 --> Router Class Initialized
INFO - 2023-04-20 06:25:42 --> Output Class Initialized
INFO - 2023-04-20 06:25:42 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:42 --> Input Class Initialized
INFO - 2023-04-20 06:25:42 --> Language Class Initialized
INFO - 2023-04-20 06:25:42 --> Loader Class Initialized
INFO - 2023-04-20 06:25:42 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:42 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:42 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:42 --> Total execution time: 0.0589
INFO - 2023-04-20 06:25:44 --> Config Class Initialized
INFO - 2023-04-20 06:25:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:44 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:44 --> URI Class Initialized
INFO - 2023-04-20 06:25:44 --> Router Class Initialized
INFO - 2023-04-20 06:25:44 --> Output Class Initialized
INFO - 2023-04-20 06:25:44 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:44 --> Input Class Initialized
INFO - 2023-04-20 06:25:44 --> Language Class Initialized
INFO - 2023-04-20 06:25:44 --> Loader Class Initialized
INFO - 2023-04-20 06:25:44 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:44 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:44 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:44 --> Total execution time: 0.0139
INFO - 2023-04-20 06:25:44 --> Config Class Initialized
INFO - 2023-04-20 06:25:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:44 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:44 --> URI Class Initialized
INFO - 2023-04-20 06:25:44 --> Router Class Initialized
INFO - 2023-04-20 06:25:44 --> Output Class Initialized
INFO - 2023-04-20 06:25:44 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:44 --> Input Class Initialized
INFO - 2023-04-20 06:25:44 --> Language Class Initialized
INFO - 2023-04-20 06:25:44 --> Loader Class Initialized
INFO - 2023-04-20 06:25:44 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:44 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:44 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:44 --> Total execution time: 0.0575
INFO - 2023-04-20 06:25:45 --> Config Class Initialized
INFO - 2023-04-20 06:25:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:45 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:45 --> URI Class Initialized
INFO - 2023-04-20 06:25:45 --> Router Class Initialized
INFO - 2023-04-20 06:25:45 --> Output Class Initialized
INFO - 2023-04-20 06:25:45 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:45 --> Input Class Initialized
INFO - 2023-04-20 06:25:45 --> Language Class Initialized
INFO - 2023-04-20 06:25:45 --> Loader Class Initialized
INFO - 2023-04-20 06:25:45 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:45 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:45 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:45 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:45 --> Total execution time: 0.0292
INFO - 2023-04-20 06:25:45 --> Config Class Initialized
INFO - 2023-04-20 06:25:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:25:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:25:45 --> Utf8 Class Initialized
INFO - 2023-04-20 06:25:45 --> URI Class Initialized
INFO - 2023-04-20 06:25:45 --> Router Class Initialized
INFO - 2023-04-20 06:25:45 --> Output Class Initialized
INFO - 2023-04-20 06:25:45 --> Security Class Initialized
DEBUG - 2023-04-20 06:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:25:45 --> Input Class Initialized
INFO - 2023-04-20 06:25:45 --> Language Class Initialized
INFO - 2023-04-20 06:25:45 --> Loader Class Initialized
INFO - 2023-04-20 06:25:45 --> Controller Class Initialized
DEBUG - 2023-04-20 06:25:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:25:45 --> Database Driver Class Initialized
INFO - 2023-04-20 06:25:45 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:25:45 --> Final output sent to browser
DEBUG - 2023-04-20 06:25:45 --> Total execution time: 0.0606
INFO - 2023-04-20 06:27:55 --> Config Class Initialized
INFO - 2023-04-20 06:27:55 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:55 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:55 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:55 --> URI Class Initialized
INFO - 2023-04-20 06:27:55 --> Router Class Initialized
INFO - 2023-04-20 06:27:55 --> Output Class Initialized
INFO - 2023-04-20 06:27:55 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:55 --> Input Class Initialized
INFO - 2023-04-20 06:27:55 --> Language Class Initialized
INFO - 2023-04-20 06:27:55 --> Loader Class Initialized
INFO - 2023-04-20 06:27:55 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:55 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:55 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:55 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:55 --> Total execution time: 0.0541
INFO - 2023-04-20 06:27:55 --> Config Class Initialized
INFO - 2023-04-20 06:27:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:56 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:56 --> URI Class Initialized
INFO - 2023-04-20 06:27:56 --> Router Class Initialized
INFO - 2023-04-20 06:27:56 --> Output Class Initialized
INFO - 2023-04-20 06:27:56 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:56 --> Input Class Initialized
INFO - 2023-04-20 06:27:56 --> Language Class Initialized
INFO - 2023-04-20 06:27:56 --> Loader Class Initialized
INFO - 2023-04-20 06:27:56 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:56 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:56 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:56 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:56 --> Total execution time: 0.0656
INFO - 2023-04-20 06:27:57 --> Config Class Initialized
INFO - 2023-04-20 06:27:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:57 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:57 --> URI Class Initialized
INFO - 2023-04-20 06:27:57 --> Router Class Initialized
INFO - 2023-04-20 06:27:57 --> Output Class Initialized
INFO - 2023-04-20 06:27:57 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:57 --> Input Class Initialized
INFO - 2023-04-20 06:27:57 --> Language Class Initialized
INFO - 2023-04-20 06:27:57 --> Loader Class Initialized
INFO - 2023-04-20 06:27:57 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:57 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:57 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:57 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:57 --> Total execution time: 0.0184
INFO - 2023-04-20 06:27:57 --> Config Class Initialized
INFO - 2023-04-20 06:27:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:57 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:57 --> URI Class Initialized
INFO - 2023-04-20 06:27:57 --> Router Class Initialized
INFO - 2023-04-20 06:27:57 --> Output Class Initialized
INFO - 2023-04-20 06:27:57 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:57 --> Input Class Initialized
INFO - 2023-04-20 06:27:57 --> Language Class Initialized
INFO - 2023-04-20 06:27:57 --> Loader Class Initialized
INFO - 2023-04-20 06:27:57 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:57 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:57 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:57 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:57 --> Total execution time: 0.0573
INFO - 2023-04-20 06:27:59 --> Config Class Initialized
INFO - 2023-04-20 06:27:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:59 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:59 --> URI Class Initialized
INFO - 2023-04-20 06:27:59 --> Router Class Initialized
INFO - 2023-04-20 06:27:59 --> Output Class Initialized
INFO - 2023-04-20 06:27:59 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:59 --> Input Class Initialized
INFO - 2023-04-20 06:27:59 --> Language Class Initialized
INFO - 2023-04-20 06:27:59 --> Loader Class Initialized
INFO - 2023-04-20 06:27:59 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:59 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:59 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:59 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:59 --> Total execution time: 0.0183
INFO - 2023-04-20 06:27:59 --> Config Class Initialized
INFO - 2023-04-20 06:27:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:27:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:27:59 --> Utf8 Class Initialized
INFO - 2023-04-20 06:27:59 --> URI Class Initialized
INFO - 2023-04-20 06:27:59 --> Router Class Initialized
INFO - 2023-04-20 06:27:59 --> Output Class Initialized
INFO - 2023-04-20 06:27:59 --> Security Class Initialized
DEBUG - 2023-04-20 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:27:59 --> Input Class Initialized
INFO - 2023-04-20 06:27:59 --> Language Class Initialized
INFO - 2023-04-20 06:27:59 --> Loader Class Initialized
INFO - 2023-04-20 06:27:59 --> Controller Class Initialized
DEBUG - 2023-04-20 06:27:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:27:59 --> Database Driver Class Initialized
INFO - 2023-04-20 06:27:59 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:27:59 --> Final output sent to browser
DEBUG - 2023-04-20 06:27:59 --> Total execution time: 0.0529
INFO - 2023-04-20 06:28:02 --> Config Class Initialized
INFO - 2023-04-20 06:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:28:02 --> Utf8 Class Initialized
INFO - 2023-04-20 06:28:02 --> URI Class Initialized
INFO - 2023-04-20 06:28:02 --> Router Class Initialized
INFO - 2023-04-20 06:28:02 --> Output Class Initialized
INFO - 2023-04-20 06:28:02 --> Security Class Initialized
DEBUG - 2023-04-20 06:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:28:02 --> Input Class Initialized
INFO - 2023-04-20 06:28:02 --> Language Class Initialized
INFO - 2023-04-20 06:28:02 --> Loader Class Initialized
INFO - 2023-04-20 06:28:02 --> Controller Class Initialized
DEBUG - 2023-04-20 06:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:28:02 --> Database Driver Class Initialized
INFO - 2023-04-20 06:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:28:02 --> Final output sent to browser
DEBUG - 2023-04-20 06:28:02 --> Total execution time: 0.0294
INFO - 2023-04-20 06:28:02 --> Config Class Initialized
INFO - 2023-04-20 06:28:02 --> Hooks Class Initialized
DEBUG - 2023-04-20 06:28:02 --> UTF-8 Support Enabled
INFO - 2023-04-20 06:28:02 --> Utf8 Class Initialized
INFO - 2023-04-20 06:28:02 --> URI Class Initialized
INFO - 2023-04-20 06:28:02 --> Router Class Initialized
INFO - 2023-04-20 06:28:02 --> Output Class Initialized
INFO - 2023-04-20 06:28:02 --> Security Class Initialized
DEBUG - 2023-04-20 06:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 06:28:02 --> Input Class Initialized
INFO - 2023-04-20 06:28:02 --> Language Class Initialized
INFO - 2023-04-20 06:28:02 --> Loader Class Initialized
INFO - 2023-04-20 06:28:02 --> Controller Class Initialized
DEBUG - 2023-04-20 06:28:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 06:28:02 --> Database Driver Class Initialized
INFO - 2023-04-20 06:28:02 --> Model "Cluster_model" initialized
INFO - 2023-04-20 06:28:02 --> Final output sent to browser
DEBUG - 2023-04-20 06:28:02 --> Total execution time: 0.0238
INFO - 2023-04-20 07:34:12 --> Config Class Initialized
INFO - 2023-04-20 07:34:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:12 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:12 --> URI Class Initialized
INFO - 2023-04-20 07:34:12 --> Router Class Initialized
INFO - 2023-04-20 07:34:12 --> Output Class Initialized
INFO - 2023-04-20 07:34:12 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:12 --> Input Class Initialized
INFO - 2023-04-20 07:34:12 --> Language Class Initialized
INFO - 2023-04-20 07:34:12 --> Loader Class Initialized
INFO - 2023-04-20 07:34:12 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:12 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:12 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:12 --> Total execution time: 0.0298
INFO - 2023-04-20 07:34:12 --> Config Class Initialized
INFO - 2023-04-20 07:34:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:12 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:12 --> URI Class Initialized
INFO - 2023-04-20 07:34:12 --> Router Class Initialized
INFO - 2023-04-20 07:34:12 --> Output Class Initialized
INFO - 2023-04-20 07:34:12 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:12 --> Input Class Initialized
INFO - 2023-04-20 07:34:12 --> Language Class Initialized
INFO - 2023-04-20 07:34:12 --> Loader Class Initialized
INFO - 2023-04-20 07:34:12 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:12 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:12 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:12 --> Total execution time: 0.0556
INFO - 2023-04-20 07:34:14 --> Config Class Initialized
INFO - 2023-04-20 07:34:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:14 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:14 --> URI Class Initialized
INFO - 2023-04-20 07:34:14 --> Router Class Initialized
INFO - 2023-04-20 07:34:14 --> Output Class Initialized
INFO - 2023-04-20 07:34:14 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:14 --> Input Class Initialized
INFO - 2023-04-20 07:34:14 --> Language Class Initialized
INFO - 2023-04-20 07:34:14 --> Loader Class Initialized
INFO - 2023-04-20 07:34:14 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:14 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:14 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:14 --> Total execution time: 0.0138
INFO - 2023-04-20 07:34:14 --> Config Class Initialized
INFO - 2023-04-20 07:34:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:14 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:14 --> URI Class Initialized
INFO - 2023-04-20 07:34:14 --> Router Class Initialized
INFO - 2023-04-20 07:34:14 --> Output Class Initialized
INFO - 2023-04-20 07:34:14 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:14 --> Input Class Initialized
INFO - 2023-04-20 07:34:14 --> Language Class Initialized
INFO - 2023-04-20 07:34:14 --> Loader Class Initialized
INFO - 2023-04-20 07:34:14 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:14 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:14 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:14 --> Total execution time: 0.0138
INFO - 2023-04-20 07:34:14 --> Config Class Initialized
INFO - 2023-04-20 07:34:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:14 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:14 --> URI Class Initialized
INFO - 2023-04-20 07:34:14 --> Router Class Initialized
INFO - 2023-04-20 07:34:14 --> Output Class Initialized
INFO - 2023-04-20 07:34:14 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:14 --> Input Class Initialized
INFO - 2023-04-20 07:34:14 --> Language Class Initialized
INFO - 2023-04-20 07:34:14 --> Loader Class Initialized
INFO - 2023-04-20 07:34:14 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:14 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:14 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:14 --> Total execution time: 0.0604
INFO - 2023-04-20 07:34:14 --> Config Class Initialized
INFO - 2023-04-20 07:34:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:14 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:14 --> URI Class Initialized
INFO - 2023-04-20 07:34:14 --> Router Class Initialized
INFO - 2023-04-20 07:34:14 --> Output Class Initialized
INFO - 2023-04-20 07:34:14 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:14 --> Input Class Initialized
INFO - 2023-04-20 07:34:14 --> Language Class Initialized
INFO - 2023-04-20 07:34:14 --> Loader Class Initialized
INFO - 2023-04-20 07:34:14 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:14 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:15 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:15 --> Total execution time: 0.0722
INFO - 2023-04-20 07:34:16 --> Config Class Initialized
INFO - 2023-04-20 07:34:16 --> Config Class Initialized
INFO - 2023-04-20 07:34:16 --> Hooks Class Initialized
INFO - 2023-04-20 07:34:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:16 --> Utf8 Class Initialized
DEBUG - 2023-04-20 07:34:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:16 --> URI Class Initialized
INFO - 2023-04-20 07:34:16 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:16 --> Router Class Initialized
INFO - 2023-04-20 07:34:16 --> URI Class Initialized
INFO - 2023-04-20 07:34:16 --> Output Class Initialized
INFO - 2023-04-20 07:34:16 --> Router Class Initialized
INFO - 2023-04-20 07:34:16 --> Security Class Initialized
INFO - 2023-04-20 07:34:16 --> Output Class Initialized
DEBUG - 2023-04-20 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:16 --> Security Class Initialized
INFO - 2023-04-20 07:34:16 --> Input Class Initialized
DEBUG - 2023-04-20 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:16 --> Input Class Initialized
INFO - 2023-04-20 07:34:16 --> Language Class Initialized
INFO - 2023-04-20 07:34:16 --> Language Class Initialized
INFO - 2023-04-20 07:34:16 --> Loader Class Initialized
INFO - 2023-04-20 07:34:16 --> Loader Class Initialized
INFO - 2023-04-20 07:34:16 --> Controller Class Initialized
INFO - 2023-04-20 07:34:16 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 07:34:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:16 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:16 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:16 --> Final output sent to browser
INFO - 2023-04-20 07:34:16 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:16 --> Total execution time: 0.0606
DEBUG - 2023-04-20 07:34:16 --> Total execution time: 0.0606
INFO - 2023-04-20 07:34:16 --> Config Class Initialized
INFO - 2023-04-20 07:34:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:16 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:16 --> URI Class Initialized
INFO - 2023-04-20 07:34:16 --> Router Class Initialized
INFO - 2023-04-20 07:34:16 --> Output Class Initialized
INFO - 2023-04-20 07:34:16 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:16 --> Input Class Initialized
INFO - 2023-04-20 07:34:16 --> Language Class Initialized
INFO - 2023-04-20 07:34:16 --> Loader Class Initialized
INFO - 2023-04-20 07:34:16 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:16 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:16 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:16 --> Total execution time: 0.0441
INFO - 2023-04-20 07:34:19 --> Config Class Initialized
INFO - 2023-04-20 07:34:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:19 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:19 --> URI Class Initialized
INFO - 2023-04-20 07:34:19 --> Router Class Initialized
INFO - 2023-04-20 07:34:19 --> Output Class Initialized
INFO - 2023-04-20 07:34:19 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:19 --> Input Class Initialized
INFO - 2023-04-20 07:34:19 --> Language Class Initialized
INFO - 2023-04-20 07:34:19 --> Loader Class Initialized
INFO - 2023-04-20 07:34:19 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:19 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:19 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:19 --> Total execution time: 0.1719
INFO - 2023-04-20 07:34:19 --> Config Class Initialized
INFO - 2023-04-20 07:34:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:34:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:34:19 --> Utf8 Class Initialized
INFO - 2023-04-20 07:34:19 --> URI Class Initialized
INFO - 2023-04-20 07:34:19 --> Router Class Initialized
INFO - 2023-04-20 07:34:19 --> Output Class Initialized
INFO - 2023-04-20 07:34:19 --> Security Class Initialized
DEBUG - 2023-04-20 07:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:34:19 --> Input Class Initialized
INFO - 2023-04-20 07:34:19 --> Language Class Initialized
INFO - 2023-04-20 07:34:19 --> Loader Class Initialized
INFO - 2023-04-20 07:34:19 --> Controller Class Initialized
DEBUG - 2023-04-20 07:34:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:34:19 --> Database Driver Class Initialized
INFO - 2023-04-20 07:34:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:34:19 --> Final output sent to browser
DEBUG - 2023-04-20 07:34:19 --> Total execution time: 0.0649
INFO - 2023-04-20 07:35:26 --> Config Class Initialized
INFO - 2023-04-20 07:35:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:35:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:35:26 --> Utf8 Class Initialized
INFO - 2023-04-20 07:35:26 --> URI Class Initialized
INFO - 2023-04-20 07:35:26 --> Router Class Initialized
INFO - 2023-04-20 07:35:26 --> Output Class Initialized
INFO - 2023-04-20 07:35:26 --> Security Class Initialized
DEBUG - 2023-04-20 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:35:26 --> Input Class Initialized
INFO - 2023-04-20 07:35:26 --> Language Class Initialized
INFO - 2023-04-20 07:35:26 --> Loader Class Initialized
INFO - 2023-04-20 07:35:26 --> Controller Class Initialized
DEBUG - 2023-04-20 07:35:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:35:26 --> Database Driver Class Initialized
INFO - 2023-04-20 07:35:26 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:35:26 --> Final output sent to browser
DEBUG - 2023-04-20 07:35:26 --> Total execution time: 0.0300
INFO - 2023-04-20 07:35:26 --> Config Class Initialized
INFO - 2023-04-20 07:35:26 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:35:26 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:35:26 --> Utf8 Class Initialized
INFO - 2023-04-20 07:35:26 --> URI Class Initialized
INFO - 2023-04-20 07:35:26 --> Router Class Initialized
INFO - 2023-04-20 07:35:26 --> Output Class Initialized
INFO - 2023-04-20 07:35:26 --> Security Class Initialized
DEBUG - 2023-04-20 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:35:26 --> Input Class Initialized
INFO - 2023-04-20 07:35:26 --> Language Class Initialized
INFO - 2023-04-20 07:35:26 --> Loader Class Initialized
INFO - 2023-04-20 07:35:26 --> Controller Class Initialized
DEBUG - 2023-04-20 07:35:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:35:26 --> Database Driver Class Initialized
INFO - 2023-04-20 07:35:26 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:35:26 --> Final output sent to browser
DEBUG - 2023-04-20 07:35:26 --> Total execution time: 0.0558
INFO - 2023-04-20 07:35:27 --> Config Class Initialized
INFO - 2023-04-20 07:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:35:27 --> Utf8 Class Initialized
INFO - 2023-04-20 07:35:27 --> URI Class Initialized
INFO - 2023-04-20 07:35:27 --> Router Class Initialized
INFO - 2023-04-20 07:35:27 --> Output Class Initialized
INFO - 2023-04-20 07:35:27 --> Security Class Initialized
DEBUG - 2023-04-20 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:35:27 --> Input Class Initialized
INFO - 2023-04-20 07:35:27 --> Language Class Initialized
INFO - 2023-04-20 07:35:27 --> Loader Class Initialized
INFO - 2023-04-20 07:35:27 --> Controller Class Initialized
DEBUG - 2023-04-20 07:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:35:27 --> Database Driver Class Initialized
INFO - 2023-04-20 07:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:35:27 --> Final output sent to browser
DEBUG - 2023-04-20 07:35:27 --> Total execution time: 0.0574
INFO - 2023-04-20 07:35:27 --> Config Class Initialized
INFO - 2023-04-20 07:35:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:35:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:35:27 --> Utf8 Class Initialized
INFO - 2023-04-20 07:35:27 --> URI Class Initialized
INFO - 2023-04-20 07:35:27 --> Router Class Initialized
INFO - 2023-04-20 07:35:27 --> Output Class Initialized
INFO - 2023-04-20 07:35:27 --> Security Class Initialized
DEBUG - 2023-04-20 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:35:27 --> Input Class Initialized
INFO - 2023-04-20 07:35:27 --> Language Class Initialized
INFO - 2023-04-20 07:35:27 --> Loader Class Initialized
INFO - 2023-04-20 07:35:27 --> Controller Class Initialized
DEBUG - 2023-04-20 07:35:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:35:27 --> Database Driver Class Initialized
INFO - 2023-04-20 07:35:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:35:28 --> Final output sent to browser
DEBUG - 2023-04-20 07:35:28 --> Total execution time: 0.0863
INFO - 2023-04-20 07:48:20 --> Config Class Initialized
INFO - 2023-04-20 07:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:20 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:20 --> URI Class Initialized
INFO - 2023-04-20 07:48:20 --> Router Class Initialized
INFO - 2023-04-20 07:48:20 --> Output Class Initialized
INFO - 2023-04-20 07:48:20 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:20 --> Input Class Initialized
INFO - 2023-04-20 07:48:20 --> Language Class Initialized
INFO - 2023-04-20 07:48:20 --> Loader Class Initialized
INFO - 2023-04-20 07:48:20 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:20 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:20 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:20 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:20 --> Total execution time: 0.0143
INFO - 2023-04-20 07:48:20 --> Config Class Initialized
INFO - 2023-04-20 07:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:20 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:20 --> URI Class Initialized
INFO - 2023-04-20 07:48:20 --> Router Class Initialized
INFO - 2023-04-20 07:48:20 --> Output Class Initialized
INFO - 2023-04-20 07:48:20 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:20 --> Input Class Initialized
INFO - 2023-04-20 07:48:20 --> Language Class Initialized
INFO - 2023-04-20 07:48:20 --> Loader Class Initialized
INFO - 2023-04-20 07:48:20 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:20 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:20 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:20 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:20 --> Total execution time: 0.0517
INFO - 2023-04-20 07:48:24 --> Config Class Initialized
INFO - 2023-04-20 07:48:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:24 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:24 --> URI Class Initialized
INFO - 2023-04-20 07:48:24 --> Router Class Initialized
INFO - 2023-04-20 07:48:24 --> Output Class Initialized
INFO - 2023-04-20 07:48:24 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:24 --> Input Class Initialized
INFO - 2023-04-20 07:48:24 --> Language Class Initialized
INFO - 2023-04-20 07:48:24 --> Loader Class Initialized
INFO - 2023-04-20 07:48:24 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:24 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:24 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:24 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:24 --> Total execution time: 0.0144
INFO - 2023-04-20 07:48:24 --> Config Class Initialized
INFO - 2023-04-20 07:48:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:24 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:24 --> URI Class Initialized
INFO - 2023-04-20 07:48:24 --> Router Class Initialized
INFO - 2023-04-20 07:48:24 --> Output Class Initialized
INFO - 2023-04-20 07:48:24 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:24 --> Input Class Initialized
INFO - 2023-04-20 07:48:24 --> Language Class Initialized
INFO - 2023-04-20 07:48:24 --> Loader Class Initialized
INFO - 2023-04-20 07:48:24 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:24 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:24 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:24 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:24 --> Total execution time: 0.0530
INFO - 2023-04-20 07:48:39 --> Config Class Initialized
INFO - 2023-04-20 07:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:39 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:39 --> URI Class Initialized
INFO - 2023-04-20 07:48:39 --> Router Class Initialized
INFO - 2023-04-20 07:48:39 --> Output Class Initialized
INFO - 2023-04-20 07:48:39 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:39 --> Input Class Initialized
INFO - 2023-04-20 07:48:39 --> Language Class Initialized
INFO - 2023-04-20 07:48:39 --> Loader Class Initialized
INFO - 2023-04-20 07:48:39 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:39 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:39 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:39 --> Total execution time: 0.0126
INFO - 2023-04-20 07:48:39 --> Config Class Initialized
INFO - 2023-04-20 07:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:39 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:39 --> URI Class Initialized
INFO - 2023-04-20 07:48:39 --> Router Class Initialized
INFO - 2023-04-20 07:48:39 --> Output Class Initialized
INFO - 2023-04-20 07:48:39 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:39 --> Input Class Initialized
INFO - 2023-04-20 07:48:39 --> Language Class Initialized
INFO - 2023-04-20 07:48:39 --> Loader Class Initialized
INFO - 2023-04-20 07:48:39 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:39 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:39 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:39 --> Total execution time: 0.0103
INFO - 2023-04-20 07:48:42 --> Config Class Initialized
INFO - 2023-04-20 07:48:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:42 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:42 --> URI Class Initialized
INFO - 2023-04-20 07:48:42 --> Router Class Initialized
INFO - 2023-04-20 07:48:42 --> Output Class Initialized
INFO - 2023-04-20 07:48:42 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:42 --> Input Class Initialized
INFO - 2023-04-20 07:48:42 --> Language Class Initialized
INFO - 2023-04-20 07:48:42 --> Loader Class Initialized
INFO - 2023-04-20 07:48:42 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:42 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:42 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:42 --> Total execution time: 0.0308
INFO - 2023-04-20 07:48:42 --> Config Class Initialized
INFO - 2023-04-20 07:48:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:42 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:42 --> URI Class Initialized
INFO - 2023-04-20 07:48:42 --> Router Class Initialized
INFO - 2023-04-20 07:48:42 --> Output Class Initialized
INFO - 2023-04-20 07:48:42 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:42 --> Input Class Initialized
INFO - 2023-04-20 07:48:42 --> Language Class Initialized
INFO - 2023-04-20 07:48:42 --> Loader Class Initialized
INFO - 2023-04-20 07:48:42 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:42 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:42 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:42 --> Total execution time: 0.0702
INFO - 2023-04-20 07:48:43 --> Config Class Initialized
INFO - 2023-04-20 07:48:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:43 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:43 --> URI Class Initialized
INFO - 2023-04-20 07:48:43 --> Router Class Initialized
INFO - 2023-04-20 07:48:43 --> Output Class Initialized
INFO - 2023-04-20 07:48:43 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:43 --> Input Class Initialized
INFO - 2023-04-20 07:48:43 --> Language Class Initialized
INFO - 2023-04-20 07:48:43 --> Loader Class Initialized
INFO - 2023-04-20 07:48:43 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:43 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:43 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:43 --> Total execution time: 0.0221
INFO - 2023-04-20 07:48:43 --> Config Class Initialized
INFO - 2023-04-20 07:48:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 07:48:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 07:48:43 --> Utf8 Class Initialized
INFO - 2023-04-20 07:48:43 --> URI Class Initialized
INFO - 2023-04-20 07:48:43 --> Router Class Initialized
INFO - 2023-04-20 07:48:43 --> Output Class Initialized
INFO - 2023-04-20 07:48:43 --> Security Class Initialized
DEBUG - 2023-04-20 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 07:48:43 --> Input Class Initialized
INFO - 2023-04-20 07:48:43 --> Language Class Initialized
INFO - 2023-04-20 07:48:43 --> Loader Class Initialized
INFO - 2023-04-20 07:48:43 --> Controller Class Initialized
DEBUG - 2023-04-20 07:48:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 07:48:43 --> Database Driver Class Initialized
INFO - 2023-04-20 07:48:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 07:48:43 --> Final output sent to browser
DEBUG - 2023-04-20 07:48:43 --> Total execution time: 0.0591
INFO - 2023-04-20 08:00:51 --> Config Class Initialized
INFO - 2023-04-20 08:00:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:00:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:00:51 --> Utf8 Class Initialized
INFO - 2023-04-20 08:00:51 --> URI Class Initialized
INFO - 2023-04-20 08:00:51 --> Router Class Initialized
INFO - 2023-04-20 08:00:51 --> Output Class Initialized
INFO - 2023-04-20 08:00:51 --> Security Class Initialized
DEBUG - 2023-04-20 08:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:00:51 --> Input Class Initialized
INFO - 2023-04-20 08:00:51 --> Language Class Initialized
INFO - 2023-04-20 08:00:51 --> Loader Class Initialized
INFO - 2023-04-20 08:00:51 --> Controller Class Initialized
DEBUG - 2023-04-20 08:00:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:00:51 --> Database Driver Class Initialized
INFO - 2023-04-20 08:00:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:00:51 --> Final output sent to browser
DEBUG - 2023-04-20 08:00:51 --> Total execution time: 0.0457
INFO - 2023-04-20 08:00:51 --> Config Class Initialized
INFO - 2023-04-20 08:00:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:00:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:00:51 --> Utf8 Class Initialized
INFO - 2023-04-20 08:00:51 --> URI Class Initialized
INFO - 2023-04-20 08:00:51 --> Router Class Initialized
INFO - 2023-04-20 08:00:51 --> Output Class Initialized
INFO - 2023-04-20 08:00:51 --> Security Class Initialized
DEBUG - 2023-04-20 08:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:00:51 --> Input Class Initialized
INFO - 2023-04-20 08:00:51 --> Language Class Initialized
INFO - 2023-04-20 08:00:51 --> Loader Class Initialized
INFO - 2023-04-20 08:00:51 --> Controller Class Initialized
DEBUG - 2023-04-20 08:00:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:00:51 --> Database Driver Class Initialized
INFO - 2023-04-20 08:00:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:00:51 --> Final output sent to browser
DEBUG - 2023-04-20 08:00:51 --> Total execution time: 0.0863
INFO - 2023-04-20 08:00:58 --> Config Class Initialized
INFO - 2023-04-20 08:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 08:00:58 --> URI Class Initialized
INFO - 2023-04-20 08:00:58 --> Router Class Initialized
INFO - 2023-04-20 08:00:58 --> Output Class Initialized
INFO - 2023-04-20 08:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:00:58 --> Input Class Initialized
INFO - 2023-04-20 08:00:58 --> Language Class Initialized
INFO - 2023-04-20 08:00:58 --> Loader Class Initialized
INFO - 2023-04-20 08:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 08:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 08:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 08:00:58 --> Total execution time: 0.0146
INFO - 2023-04-20 08:00:58 --> Config Class Initialized
INFO - 2023-04-20 08:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 08:00:58 --> URI Class Initialized
INFO - 2023-04-20 08:00:58 --> Router Class Initialized
INFO - 2023-04-20 08:00:58 --> Output Class Initialized
INFO - 2023-04-20 08:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:00:58 --> Input Class Initialized
INFO - 2023-04-20 08:00:58 --> Language Class Initialized
INFO - 2023-04-20 08:00:58 --> Loader Class Initialized
INFO - 2023-04-20 08:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 08:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 08:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 08:00:58 --> Total execution time: 0.0121
INFO - 2023-04-20 08:01:00 --> Config Class Initialized
INFO - 2023-04-20 08:01:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:01:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:01:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:01:00 --> URI Class Initialized
INFO - 2023-04-20 08:01:00 --> Router Class Initialized
INFO - 2023-04-20 08:01:00 --> Output Class Initialized
INFO - 2023-04-20 08:01:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:01:00 --> Input Class Initialized
INFO - 2023-04-20 08:01:00 --> Language Class Initialized
INFO - 2023-04-20 08:01:00 --> Loader Class Initialized
INFO - 2023-04-20 08:01:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:01:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:01:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:01:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:01:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:01:00 --> Total execution time: 0.0283
INFO - 2023-04-20 08:01:00 --> Config Class Initialized
INFO - 2023-04-20 08:01:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:01:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:01:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:01:00 --> URI Class Initialized
INFO - 2023-04-20 08:01:00 --> Router Class Initialized
INFO - 2023-04-20 08:01:00 --> Output Class Initialized
INFO - 2023-04-20 08:01:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:01:00 --> Input Class Initialized
INFO - 2023-04-20 08:01:00 --> Language Class Initialized
INFO - 2023-04-20 08:01:00 --> Loader Class Initialized
INFO - 2023-04-20 08:01:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:01:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:01:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:01:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:01:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:01:00 --> Total execution time: 0.0686
INFO - 2023-04-20 08:02:42 --> Config Class Initialized
INFO - 2023-04-20 08:02:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:42 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:42 --> URI Class Initialized
INFO - 2023-04-20 08:02:42 --> Router Class Initialized
INFO - 2023-04-20 08:02:42 --> Output Class Initialized
INFO - 2023-04-20 08:02:42 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:42 --> Input Class Initialized
INFO - 2023-04-20 08:02:42 --> Language Class Initialized
INFO - 2023-04-20 08:02:42 --> Loader Class Initialized
INFO - 2023-04-20 08:02:42 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:42 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:42 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:42 --> Total execution time: 0.0274
INFO - 2023-04-20 08:02:42 --> Config Class Initialized
INFO - 2023-04-20 08:02:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:42 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:42 --> URI Class Initialized
INFO - 2023-04-20 08:02:42 --> Router Class Initialized
INFO - 2023-04-20 08:02:42 --> Output Class Initialized
INFO - 2023-04-20 08:02:42 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:42 --> Input Class Initialized
INFO - 2023-04-20 08:02:42 --> Language Class Initialized
INFO - 2023-04-20 08:02:42 --> Loader Class Initialized
INFO - 2023-04-20 08:02:42 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:42 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:42 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:42 --> Total execution time: 0.0661
INFO - 2023-04-20 08:02:44 --> Config Class Initialized
INFO - 2023-04-20 08:02:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:44 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:44 --> URI Class Initialized
INFO - 2023-04-20 08:02:44 --> Router Class Initialized
INFO - 2023-04-20 08:02:44 --> Output Class Initialized
INFO - 2023-04-20 08:02:44 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:44 --> Input Class Initialized
INFO - 2023-04-20 08:02:44 --> Language Class Initialized
INFO - 2023-04-20 08:02:44 --> Loader Class Initialized
INFO - 2023-04-20 08:02:44 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:44 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:44 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:44 --> Total execution time: 0.0144
INFO - 2023-04-20 08:02:44 --> Config Class Initialized
INFO - 2023-04-20 08:02:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:44 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:44 --> URI Class Initialized
INFO - 2023-04-20 08:02:44 --> Router Class Initialized
INFO - 2023-04-20 08:02:44 --> Output Class Initialized
INFO - 2023-04-20 08:02:44 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:44 --> Input Class Initialized
INFO - 2023-04-20 08:02:44 --> Language Class Initialized
INFO - 2023-04-20 08:02:44 --> Loader Class Initialized
INFO - 2023-04-20 08:02:44 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:44 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:44 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:44 --> Total execution time: 0.0547
INFO - 2023-04-20 08:02:47 --> Config Class Initialized
INFO - 2023-04-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:47 --> URI Class Initialized
INFO - 2023-04-20 08:02:47 --> Router Class Initialized
INFO - 2023-04-20 08:02:47 --> Output Class Initialized
INFO - 2023-04-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:47 --> Input Class Initialized
INFO - 2023-04-20 08:02:47 --> Language Class Initialized
INFO - 2023-04-20 08:02:47 --> Loader Class Initialized
INFO - 2023-04-20 08:02:47 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:47 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:47 --> Total execution time: 0.0111
INFO - 2023-04-20 08:02:47 --> Config Class Initialized
INFO - 2023-04-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:47 --> URI Class Initialized
INFO - 2023-04-20 08:02:47 --> Router Class Initialized
INFO - 2023-04-20 08:02:47 --> Output Class Initialized
INFO - 2023-04-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:47 --> Input Class Initialized
INFO - 2023-04-20 08:02:47 --> Language Class Initialized
INFO - 2023-04-20 08:02:47 --> Loader Class Initialized
INFO - 2023-04-20 08:02:47 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Login_model" initialized
INFO - 2023-04-20 08:02:47 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:47 --> Total execution time: 0.0641
INFO - 2023-04-20 08:02:47 --> Config Class Initialized
INFO - 2023-04-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:47 --> URI Class Initialized
INFO - 2023-04-20 08:02:47 --> Router Class Initialized
INFO - 2023-04-20 08:02:47 --> Output Class Initialized
INFO - 2023-04-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:47 --> Input Class Initialized
INFO - 2023-04-20 08:02:47 --> Language Class Initialized
INFO - 2023-04-20 08:02:47 --> Loader Class Initialized
INFO - 2023-04-20 08:02:47 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:47 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:47 --> Total execution time: 0.0889
INFO - 2023-04-20 08:02:47 --> Config Class Initialized
INFO - 2023-04-20 08:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:47 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:47 --> URI Class Initialized
INFO - 2023-04-20 08:02:47 --> Router Class Initialized
INFO - 2023-04-20 08:02:47 --> Output Class Initialized
INFO - 2023-04-20 08:02:47 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:47 --> Input Class Initialized
INFO - 2023-04-20 08:02:47 --> Language Class Initialized
INFO - 2023-04-20 08:02:47 --> Loader Class Initialized
INFO - 2023-04-20 08:02:47 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:47 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:47 --> Model "Login_model" initialized
INFO - 2023-04-20 08:02:47 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:47 --> Total execution time: 0.0221
INFO - 2023-04-20 08:02:48 --> Config Class Initialized
INFO - 2023-04-20 08:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:48 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:48 --> URI Class Initialized
INFO - 2023-04-20 08:02:48 --> Router Class Initialized
INFO - 2023-04-20 08:02:48 --> Output Class Initialized
INFO - 2023-04-20 08:02:48 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:48 --> Input Class Initialized
INFO - 2023-04-20 08:02:48 --> Language Class Initialized
INFO - 2023-04-20 08:02:48 --> Loader Class Initialized
INFO - 2023-04-20 08:02:48 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:48 --> Model "Login_model" initialized
INFO - 2023-04-20 08:02:48 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:48 --> Total execution time: 0.0981
INFO - 2023-04-20 08:02:48 --> Config Class Initialized
INFO - 2023-04-20 08:02:48 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:48 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:48 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:48 --> URI Class Initialized
INFO - 2023-04-20 08:02:48 --> Router Class Initialized
INFO - 2023-04-20 08:02:48 --> Output Class Initialized
INFO - 2023-04-20 08:02:48 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:48 --> Input Class Initialized
INFO - 2023-04-20 08:02:48 --> Language Class Initialized
INFO - 2023-04-20 08:02:48 --> Loader Class Initialized
INFO - 2023-04-20 08:02:48 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:48 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:48 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:48 --> Model "Login_model" initialized
INFO - 2023-04-20 08:02:48 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:48 --> Total execution time: 0.1035
INFO - 2023-04-20 08:02:54 --> Config Class Initialized
INFO - 2023-04-20 08:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:54 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:54 --> URI Class Initialized
INFO - 2023-04-20 08:02:54 --> Router Class Initialized
INFO - 2023-04-20 08:02:54 --> Output Class Initialized
INFO - 2023-04-20 08:02:54 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:54 --> Input Class Initialized
INFO - 2023-04-20 08:02:54 --> Language Class Initialized
INFO - 2023-04-20 08:02:54 --> Loader Class Initialized
INFO - 2023-04-20 08:02:54 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:54 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:54 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:54 --> Total execution time: 0.0454
INFO - 2023-04-20 08:02:54 --> Config Class Initialized
INFO - 2023-04-20 08:02:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:54 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:54 --> URI Class Initialized
INFO - 2023-04-20 08:02:54 --> Router Class Initialized
INFO - 2023-04-20 08:02:54 --> Output Class Initialized
INFO - 2023-04-20 08:02:54 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:54 --> Input Class Initialized
INFO - 2023-04-20 08:02:54 --> Language Class Initialized
INFO - 2023-04-20 08:02:54 --> Loader Class Initialized
INFO - 2023-04-20 08:02:54 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:54 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:54 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:54 --> Total execution time: 0.0882
INFO - 2023-04-20 08:02:58 --> Config Class Initialized
INFO - 2023-04-20 08:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:58 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:58 --> URI Class Initialized
INFO - 2023-04-20 08:02:58 --> Router Class Initialized
INFO - 2023-04-20 08:02:58 --> Output Class Initialized
INFO - 2023-04-20 08:02:58 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:58 --> Input Class Initialized
INFO - 2023-04-20 08:02:58 --> Language Class Initialized
INFO - 2023-04-20 08:02:58 --> Loader Class Initialized
INFO - 2023-04-20 08:02:58 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:58 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:58 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:58 --> Total execution time: 0.0265
INFO - 2023-04-20 08:02:58 --> Config Class Initialized
INFO - 2023-04-20 08:02:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:02:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:02:58 --> Utf8 Class Initialized
INFO - 2023-04-20 08:02:58 --> URI Class Initialized
INFO - 2023-04-20 08:02:58 --> Router Class Initialized
INFO - 2023-04-20 08:02:58 --> Output Class Initialized
INFO - 2023-04-20 08:02:58 --> Security Class Initialized
DEBUG - 2023-04-20 08:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:02:58 --> Input Class Initialized
INFO - 2023-04-20 08:02:58 --> Language Class Initialized
INFO - 2023-04-20 08:02:58 --> Loader Class Initialized
INFO - 2023-04-20 08:02:58 --> Controller Class Initialized
DEBUG - 2023-04-20 08:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:02:58 --> Database Driver Class Initialized
INFO - 2023-04-20 08:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:02:58 --> Final output sent to browser
DEBUG - 2023-04-20 08:02:58 --> Total execution time: 0.0595
INFO - 2023-04-20 08:03:00 --> Config Class Initialized
INFO - 2023-04-20 08:03:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:03:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:03:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:03:00 --> URI Class Initialized
INFO - 2023-04-20 08:03:00 --> Router Class Initialized
INFO - 2023-04-20 08:03:00 --> Output Class Initialized
INFO - 2023-04-20 08:03:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:03:00 --> Input Class Initialized
INFO - 2023-04-20 08:03:00 --> Language Class Initialized
INFO - 2023-04-20 08:03:00 --> Loader Class Initialized
INFO - 2023-04-20 08:03:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:03:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:03:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:03:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:03:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:03:00 --> Total execution time: 0.0506
INFO - 2023-04-20 08:03:00 --> Config Class Initialized
INFO - 2023-04-20 08:03:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:03:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:03:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:03:00 --> URI Class Initialized
INFO - 2023-04-20 08:03:00 --> Router Class Initialized
INFO - 2023-04-20 08:03:00 --> Output Class Initialized
INFO - 2023-04-20 08:03:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:03:00 --> Input Class Initialized
INFO - 2023-04-20 08:03:00 --> Language Class Initialized
INFO - 2023-04-20 08:03:00 --> Loader Class Initialized
INFO - 2023-04-20 08:03:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:03:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:03:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:03:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:03:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:03:00 --> Total execution time: 0.0393
INFO - 2023-04-20 08:10:15 --> Config Class Initialized
INFO - 2023-04-20 08:10:15 --> Config Class Initialized
INFO - 2023-04-20 08:10:15 --> Hooks Class Initialized
INFO - 2023-04-20 08:10:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 08:10:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:15 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:15 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:15 --> URI Class Initialized
INFO - 2023-04-20 08:10:15 --> URI Class Initialized
INFO - 2023-04-20 08:10:15 --> Router Class Initialized
INFO - 2023-04-20 08:10:15 --> Router Class Initialized
INFO - 2023-04-20 08:10:15 --> Output Class Initialized
INFO - 2023-04-20 08:10:15 --> Output Class Initialized
INFO - 2023-04-20 08:10:15 --> Security Class Initialized
INFO - 2023-04-20 08:10:15 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:15 --> Input Class Initialized
INFO - 2023-04-20 08:10:15 --> Input Class Initialized
INFO - 2023-04-20 08:10:15 --> Language Class Initialized
INFO - 2023-04-20 08:10:15 --> Language Class Initialized
INFO - 2023-04-20 08:10:15 --> Loader Class Initialized
INFO - 2023-04-20 08:10:15 --> Loader Class Initialized
INFO - 2023-04-20 08:10:15 --> Controller Class Initialized
INFO - 2023-04-20 08:10:15 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 08:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:15 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:15 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:15 --> Total execution time: 0.0045
INFO - 2023-04-20 08:10:15 --> Config Class Initialized
INFO - 2023-04-20 08:10:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:15 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:15 --> URI Class Initialized
INFO - 2023-04-20 08:10:15 --> Router Class Initialized
INFO - 2023-04-20 08:10:15 --> Output Class Initialized
INFO - 2023-04-20 08:10:15 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:15 --> Input Class Initialized
INFO - 2023-04-20 08:10:15 --> Language Class Initialized
INFO - 2023-04-20 08:10:15 --> Loader Class Initialized
INFO - 2023-04-20 08:10:15 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:15 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:15 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:15 --> Total execution time: 0.0503
INFO - 2023-04-20 08:10:15 --> Config Class Initialized
INFO - 2023-04-20 08:10:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:15 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:15 --> URI Class Initialized
INFO - 2023-04-20 08:10:15 --> Router Class Initialized
INFO - 2023-04-20 08:10:15 --> Output Class Initialized
INFO - 2023-04-20 08:10:15 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:15 --> Input Class Initialized
INFO - 2023-04-20 08:10:15 --> Language Class Initialized
INFO - 2023-04-20 08:10:15 --> Loader Class Initialized
INFO - 2023-04-20 08:10:15 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:15 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:15 --> Model "Login_model" initialized
INFO - 2023-04-20 08:10:15 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:15 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:15 --> Total execution time: 0.0184
INFO - 2023-04-20 08:10:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:15 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:15 --> Total execution time: 0.0697
INFO - 2023-04-20 08:10:18 --> Config Class Initialized
INFO - 2023-04-20 08:10:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:18 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:18 --> URI Class Initialized
INFO - 2023-04-20 08:10:18 --> Router Class Initialized
INFO - 2023-04-20 08:10:18 --> Output Class Initialized
INFO - 2023-04-20 08:10:18 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:18 --> Input Class Initialized
INFO - 2023-04-20 08:10:18 --> Language Class Initialized
INFO - 2023-04-20 08:10:18 --> Loader Class Initialized
INFO - 2023-04-20 08:10:18 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:18 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:18 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:18 --> Total execution time: 0.0145
INFO - 2023-04-20 08:10:18 --> Config Class Initialized
INFO - 2023-04-20 08:10:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:18 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:18 --> URI Class Initialized
INFO - 2023-04-20 08:10:18 --> Router Class Initialized
INFO - 2023-04-20 08:10:18 --> Output Class Initialized
INFO - 2023-04-20 08:10:18 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:18 --> Input Class Initialized
INFO - 2023-04-20 08:10:18 --> Language Class Initialized
INFO - 2023-04-20 08:10:18 --> Loader Class Initialized
INFO - 2023-04-20 08:10:18 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:18 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:18 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:18 --> Total execution time: 0.0517
INFO - 2023-04-20 08:10:21 --> Config Class Initialized
INFO - 2023-04-20 08:10:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:21 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:21 --> URI Class Initialized
INFO - 2023-04-20 08:10:21 --> Router Class Initialized
INFO - 2023-04-20 08:10:21 --> Output Class Initialized
INFO - 2023-04-20 08:10:21 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:21 --> Input Class Initialized
INFO - 2023-04-20 08:10:21 --> Language Class Initialized
INFO - 2023-04-20 08:10:21 --> Loader Class Initialized
INFO - 2023-04-20 08:10:21 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:21 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:21 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:21 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:21 --> Total execution time: 0.0715
INFO - 2023-04-20 08:10:21 --> Config Class Initialized
INFO - 2023-04-20 08:10:21 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:10:21 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:10:21 --> Utf8 Class Initialized
INFO - 2023-04-20 08:10:21 --> URI Class Initialized
INFO - 2023-04-20 08:10:21 --> Router Class Initialized
INFO - 2023-04-20 08:10:21 --> Output Class Initialized
INFO - 2023-04-20 08:10:21 --> Security Class Initialized
DEBUG - 2023-04-20 08:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:10:21 --> Input Class Initialized
INFO - 2023-04-20 08:10:21 --> Language Class Initialized
INFO - 2023-04-20 08:10:21 --> Loader Class Initialized
INFO - 2023-04-20 08:10:21 --> Controller Class Initialized
DEBUG - 2023-04-20 08:10:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:10:21 --> Database Driver Class Initialized
INFO - 2023-04-20 08:10:21 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:10:21 --> Final output sent to browser
DEBUG - 2023-04-20 08:10:21 --> Total execution time: 0.0859
INFO - 2023-04-20 08:21:27 --> Config Class Initialized
INFO - 2023-04-20 08:21:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:27 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:27 --> URI Class Initialized
INFO - 2023-04-20 08:21:27 --> Router Class Initialized
INFO - 2023-04-20 08:21:27 --> Output Class Initialized
INFO - 2023-04-20 08:21:27 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:27 --> Input Class Initialized
INFO - 2023-04-20 08:21:27 --> Language Class Initialized
INFO - 2023-04-20 08:21:27 --> Loader Class Initialized
INFO - 2023-04-20 08:21:27 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:27 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:27 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:27 --> Total execution time: 0.0158
INFO - 2023-04-20 08:21:27 --> Config Class Initialized
INFO - 2023-04-20 08:21:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:28 --> URI Class Initialized
INFO - 2023-04-20 08:21:28 --> Router Class Initialized
INFO - 2023-04-20 08:21:28 --> Output Class Initialized
INFO - 2023-04-20 08:21:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:28 --> Input Class Initialized
INFO - 2023-04-20 08:21:28 --> Language Class Initialized
INFO - 2023-04-20 08:21:28 --> Loader Class Initialized
INFO - 2023-04-20 08:21:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:28 --> Total execution time: 0.0539
INFO - 2023-04-20 08:21:30 --> Config Class Initialized
INFO - 2023-04-20 08:21:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:30 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:30 --> URI Class Initialized
INFO - 2023-04-20 08:21:30 --> Router Class Initialized
INFO - 2023-04-20 08:21:30 --> Output Class Initialized
INFO - 2023-04-20 08:21:30 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:30 --> Input Class Initialized
INFO - 2023-04-20 08:21:30 --> Language Class Initialized
INFO - 2023-04-20 08:21:30 --> Loader Class Initialized
INFO - 2023-04-20 08:21:30 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:30 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:30 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:30 --> Final output sent to browser
INFO - 2023-04-20 08:21:30 --> Config Class Initialized
DEBUG - 2023-04-20 08:21:30 --> Total execution time: 0.0524
INFO - 2023-04-20 08:21:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:30 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:30 --> URI Class Initialized
INFO - 2023-04-20 08:21:30 --> Router Class Initialized
INFO - 2023-04-20 08:21:30 --> Output Class Initialized
INFO - 2023-04-20 08:21:30 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:30 --> Input Class Initialized
INFO - 2023-04-20 08:21:30 --> Language Class Initialized
INFO - 2023-04-20 08:21:30 --> Loader Class Initialized
INFO - 2023-04-20 08:21:30 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:30 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:30 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:30 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:30 --> Total execution time: 0.0841
INFO - 2023-04-20 08:21:34 --> Config Class Initialized
INFO - 2023-04-20 08:21:34 --> Config Class Initialized
INFO - 2023-04-20 08:21:34 --> Hooks Class Initialized
INFO - 2023-04-20 08:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 08:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:34 --> URI Class Initialized
INFO - 2023-04-20 08:21:34 --> URI Class Initialized
INFO - 2023-04-20 08:21:34 --> Router Class Initialized
INFO - 2023-04-20 08:21:34 --> Router Class Initialized
INFO - 2023-04-20 08:21:34 --> Output Class Initialized
INFO - 2023-04-20 08:21:34 --> Output Class Initialized
INFO - 2023-04-20 08:21:34 --> Security Class Initialized
INFO - 2023-04-20 08:21:34 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 08:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:34 --> Input Class Initialized
INFO - 2023-04-20 08:21:34 --> Language Class Initialized
INFO - 2023-04-20 08:21:34 --> Input Class Initialized
INFO - 2023-04-20 08:21:34 --> Language Class Initialized
INFO - 2023-04-20 08:21:34 --> Loader Class Initialized
INFO - 2023-04-20 08:21:34 --> Loader Class Initialized
INFO - 2023-04-20 08:21:34 --> Controller Class Initialized
INFO - 2023-04-20 08:21:34 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 08:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:34 --> Total execution time: 0.0047
INFO - 2023-04-20 08:21:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:34 --> Config Class Initialized
INFO - 2023-04-20 08:21:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:34 --> URI Class Initialized
INFO - 2023-04-20 08:21:34 --> Router Class Initialized
INFO - 2023-04-20 08:21:34 --> Output Class Initialized
INFO - 2023-04-20 08:21:34 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:34 --> Input Class Initialized
INFO - 2023-04-20 08:21:34 --> Language Class Initialized
INFO - 2023-04-20 08:21:34 --> Loader Class Initialized
INFO - 2023-04-20 08:21:34 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:34 --> Total execution time: 0.0515
INFO - 2023-04-20 08:21:34 --> Config Class Initialized
INFO - 2023-04-20 08:21:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:34 --> URI Class Initialized
INFO - 2023-04-20 08:21:34 --> Router Class Initialized
INFO - 2023-04-20 08:21:34 --> Output Class Initialized
INFO - 2023-04-20 08:21:34 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:34 --> Input Class Initialized
INFO - 2023-04-20 08:21:34 --> Language Class Initialized
INFO - 2023-04-20 08:21:34 --> Loader Class Initialized
INFO - 2023-04-20 08:21:34 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:34 --> Model "Login_model" initialized
INFO - 2023-04-20 08:21:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:34 --> Total execution time: 0.0637
INFO - 2023-04-20 08:21:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:34 --> Total execution time: 0.0169
INFO - 2023-04-20 08:21:38 --> Config Class Initialized
INFO - 2023-04-20 08:21:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:38 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:38 --> URI Class Initialized
INFO - 2023-04-20 08:21:38 --> Router Class Initialized
INFO - 2023-04-20 08:21:38 --> Output Class Initialized
INFO - 2023-04-20 08:21:38 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:38 --> Input Class Initialized
INFO - 2023-04-20 08:21:38 --> Language Class Initialized
INFO - 2023-04-20 08:21:38 --> Loader Class Initialized
INFO - 2023-04-20 08:21:38 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:38 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:38 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:38 --> Model "Login_model" initialized
INFO - 2023-04-20 08:21:38 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:38 --> Total execution time: 0.0825
INFO - 2023-04-20 08:21:38 --> Config Class Initialized
INFO - 2023-04-20 08:21:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:38 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:38 --> URI Class Initialized
INFO - 2023-04-20 08:21:38 --> Router Class Initialized
INFO - 2023-04-20 08:21:38 --> Output Class Initialized
INFO - 2023-04-20 08:21:38 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:38 --> Input Class Initialized
INFO - 2023-04-20 08:21:38 --> Language Class Initialized
INFO - 2023-04-20 08:21:38 --> Loader Class Initialized
INFO - 2023-04-20 08:21:38 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:38 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:38 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:38 --> Model "Login_model" initialized
INFO - 2023-04-20 08:21:38 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:38 --> Total execution time: 0.1258
INFO - 2023-04-20 08:21:41 --> Config Class Initialized
INFO - 2023-04-20 08:21:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:41 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:41 --> URI Class Initialized
INFO - 2023-04-20 08:21:41 --> Router Class Initialized
INFO - 2023-04-20 08:21:41 --> Output Class Initialized
INFO - 2023-04-20 08:21:41 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:41 --> Input Class Initialized
INFO - 2023-04-20 08:21:41 --> Language Class Initialized
INFO - 2023-04-20 08:21:41 --> Loader Class Initialized
INFO - 2023-04-20 08:21:41 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:41 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:41 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:41 --> Total execution time: 0.0459
INFO - 2023-04-20 08:21:41 --> Config Class Initialized
INFO - 2023-04-20 08:21:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:21:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:21:41 --> Utf8 Class Initialized
INFO - 2023-04-20 08:21:41 --> URI Class Initialized
INFO - 2023-04-20 08:21:41 --> Router Class Initialized
INFO - 2023-04-20 08:21:41 --> Output Class Initialized
INFO - 2023-04-20 08:21:41 --> Security Class Initialized
DEBUG - 2023-04-20 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:21:41 --> Input Class Initialized
INFO - 2023-04-20 08:21:41 --> Language Class Initialized
INFO - 2023-04-20 08:21:41 --> Loader Class Initialized
INFO - 2023-04-20 08:21:41 --> Controller Class Initialized
DEBUG - 2023-04-20 08:21:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:21:41 --> Database Driver Class Initialized
INFO - 2023-04-20 08:21:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:21:41 --> Final output sent to browser
DEBUG - 2023-04-20 08:21:41 --> Total execution time: 0.0931
INFO - 2023-04-20 08:37:28 --> Config Class Initialized
INFO - 2023-04-20 08:37:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:28 --> URI Class Initialized
INFO - 2023-04-20 08:37:28 --> Router Class Initialized
INFO - 2023-04-20 08:37:28 --> Output Class Initialized
INFO - 2023-04-20 08:37:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:28 --> Input Class Initialized
INFO - 2023-04-20 08:37:28 --> Language Class Initialized
INFO - 2023-04-20 08:37:28 --> Loader Class Initialized
INFO - 2023-04-20 08:37:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:28 --> Model "Login_model" initialized
INFO - 2023-04-20 08:37:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:28 --> Total execution time: 0.0847
INFO - 2023-04-20 08:37:28 --> Config Class Initialized
INFO - 2023-04-20 08:37:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:28 --> URI Class Initialized
INFO - 2023-04-20 08:37:28 --> Router Class Initialized
INFO - 2023-04-20 08:37:28 --> Output Class Initialized
INFO - 2023-04-20 08:37:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:28 --> Input Class Initialized
INFO - 2023-04-20 08:37:28 --> Language Class Initialized
INFO - 2023-04-20 08:37:28 --> Loader Class Initialized
INFO - 2023-04-20 08:37:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:28 --> Model "Login_model" initialized
INFO - 2023-04-20 08:37:29 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:29 --> Total execution time: 0.1196
INFO - 2023-04-20 08:37:32 --> Config Class Initialized
INFO - 2023-04-20 08:37:32 --> Config Class Initialized
INFO - 2023-04-20 08:37:32 --> Hooks Class Initialized
INFO - 2023-04-20 08:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 08:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:32 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:32 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:32 --> URI Class Initialized
INFO - 2023-04-20 08:37:32 --> URI Class Initialized
INFO - 2023-04-20 08:37:32 --> Router Class Initialized
INFO - 2023-04-20 08:37:32 --> Router Class Initialized
INFO - 2023-04-20 08:37:32 --> Output Class Initialized
INFO - 2023-04-20 08:37:32 --> Output Class Initialized
INFO - 2023-04-20 08:37:32 --> Security Class Initialized
INFO - 2023-04-20 08:37:32 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:32 --> Input Class Initialized
INFO - 2023-04-20 08:37:32 --> Input Class Initialized
INFO - 2023-04-20 08:37:32 --> Language Class Initialized
INFO - 2023-04-20 08:37:32 --> Language Class Initialized
INFO - 2023-04-20 08:37:32 --> Loader Class Initialized
INFO - 2023-04-20 08:37:32 --> Loader Class Initialized
INFO - 2023-04-20 08:37:32 --> Controller Class Initialized
INFO - 2023-04-20 08:37:32 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 08:37:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:32 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:32 --> Total execution time: 0.0055
INFO - 2023-04-20 08:37:32 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:32 --> Config Class Initialized
INFO - 2023-04-20 08:37:32 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:32 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:32 --> URI Class Initialized
INFO - 2023-04-20 08:37:32 --> Router Class Initialized
INFO - 2023-04-20 08:37:32 --> Output Class Initialized
INFO - 2023-04-20 08:37:32 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:32 --> Input Class Initialized
INFO - 2023-04-20 08:37:32 --> Language Class Initialized
INFO - 2023-04-20 08:37:32 --> Loader Class Initialized
INFO - 2023-04-20 08:37:32 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:32 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:32 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:32 --> Total execution time: 0.0516
INFO - 2023-04-20 08:37:32 --> Config Class Initialized
INFO - 2023-04-20 08:37:32 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:32 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:32 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:32 --> URI Class Initialized
INFO - 2023-04-20 08:37:32 --> Router Class Initialized
INFO - 2023-04-20 08:37:32 --> Output Class Initialized
INFO - 2023-04-20 08:37:32 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:32 --> Input Class Initialized
INFO - 2023-04-20 08:37:32 --> Language Class Initialized
INFO - 2023-04-20 08:37:32 --> Loader Class Initialized
INFO - 2023-04-20 08:37:32 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:32 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:32 --> Model "Login_model" initialized
INFO - 2023-04-20 08:37:32 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:32 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:32 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:32 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:32 --> Total execution time: 0.0195
INFO - 2023-04-20 08:37:32 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:32 --> Total execution time: 0.0678
INFO - 2023-04-20 08:37:34 --> Config Class Initialized
INFO - 2023-04-20 08:37:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:34 --> URI Class Initialized
INFO - 2023-04-20 08:37:34 --> Router Class Initialized
INFO - 2023-04-20 08:37:34 --> Output Class Initialized
INFO - 2023-04-20 08:37:34 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:34 --> Input Class Initialized
INFO - 2023-04-20 08:37:34 --> Language Class Initialized
INFO - 2023-04-20 08:37:34 --> Loader Class Initialized
INFO - 2023-04-20 08:37:34 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:34 --> Total execution time: 0.1050
INFO - 2023-04-20 08:37:34 --> Config Class Initialized
INFO - 2023-04-20 08:37:34 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:37:34 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:37:34 --> Utf8 Class Initialized
INFO - 2023-04-20 08:37:34 --> URI Class Initialized
INFO - 2023-04-20 08:37:34 --> Router Class Initialized
INFO - 2023-04-20 08:37:34 --> Output Class Initialized
INFO - 2023-04-20 08:37:34 --> Security Class Initialized
DEBUG - 2023-04-20 08:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:37:34 --> Input Class Initialized
INFO - 2023-04-20 08:37:34 --> Language Class Initialized
INFO - 2023-04-20 08:37:34 --> Loader Class Initialized
INFO - 2023-04-20 08:37:34 --> Controller Class Initialized
DEBUG - 2023-04-20 08:37:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:37:34 --> Database Driver Class Initialized
INFO - 2023-04-20 08:37:34 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:37:34 --> Final output sent to browser
DEBUG - 2023-04-20 08:37:34 --> Total execution time: 0.1424
INFO - 2023-04-20 08:39:57 --> Config Class Initialized
INFO - 2023-04-20 08:39:57 --> Config Class Initialized
INFO - 2023-04-20 08:39:57 --> Hooks Class Initialized
INFO - 2023-04-20 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:39:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:39:57 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:57 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:57 --> URI Class Initialized
INFO - 2023-04-20 08:39:57 --> URI Class Initialized
INFO - 2023-04-20 08:39:57 --> Router Class Initialized
INFO - 2023-04-20 08:39:57 --> Router Class Initialized
INFO - 2023-04-20 08:39:57 --> Output Class Initialized
INFO - 2023-04-20 08:39:57 --> Output Class Initialized
INFO - 2023-04-20 08:39:57 --> Security Class Initialized
INFO - 2023-04-20 08:39:57 --> Security Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:39:57 --> Input Class Initialized
INFO - 2023-04-20 08:39:57 --> Input Class Initialized
INFO - 2023-04-20 08:39:57 --> Language Class Initialized
INFO - 2023-04-20 08:39:57 --> Language Class Initialized
INFO - 2023-04-20 08:39:57 --> Loader Class Initialized
INFO - 2023-04-20 08:39:57 --> Loader Class Initialized
INFO - 2023-04-20 08:39:57 --> Controller Class Initialized
INFO - 2023-04-20 08:39:57 --> Controller Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:39:57 --> Final output sent to browser
DEBUG - 2023-04-20 08:39:57 --> Total execution time: 0.0044
INFO - 2023-04-20 08:39:57 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:57 --> Config Class Initialized
INFO - 2023-04-20 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:39:57 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:57 --> URI Class Initialized
INFO - 2023-04-20 08:39:57 --> Router Class Initialized
INFO - 2023-04-20 08:39:57 --> Output Class Initialized
INFO - 2023-04-20 08:39:57 --> Security Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:39:57 --> Input Class Initialized
INFO - 2023-04-20 08:39:57 --> Language Class Initialized
INFO - 2023-04-20 08:39:57 --> Loader Class Initialized
INFO - 2023-04-20 08:39:57 --> Controller Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:39:57 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:57 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:39:57 --> Model "Login_model" initialized
INFO - 2023-04-20 08:39:57 --> Final output sent to browser
DEBUG - 2023-04-20 08:39:57 --> Total execution time: 0.0238
INFO - 2023-04-20 08:39:57 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:57 --> Config Class Initialized
INFO - 2023-04-20 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:39:57 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:57 --> URI Class Initialized
INFO - 2023-04-20 08:39:57 --> Router Class Initialized
INFO - 2023-04-20 08:39:57 --> Output Class Initialized
INFO - 2023-04-20 08:39:57 --> Security Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:39:57 --> Input Class Initialized
INFO - 2023-04-20 08:39:57 --> Language Class Initialized
INFO - 2023-04-20 08:39:57 --> Loader Class Initialized
INFO - 2023-04-20 08:39:57 --> Controller Class Initialized
DEBUG - 2023-04-20 08:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:39:57 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:57 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:39:57 --> Final output sent to browser
DEBUG - 2023-04-20 08:39:57 --> Total execution time: 0.0273
INFO - 2023-04-20 08:39:57 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:39:57 --> Final output sent to browser
DEBUG - 2023-04-20 08:39:57 --> Total execution time: 0.0532
INFO - 2023-04-20 08:39:59 --> Config Class Initialized
INFO - 2023-04-20 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:39:59 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:59 --> URI Class Initialized
INFO - 2023-04-20 08:39:59 --> Router Class Initialized
INFO - 2023-04-20 08:39:59 --> Output Class Initialized
INFO - 2023-04-20 08:39:59 --> Security Class Initialized
DEBUG - 2023-04-20 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:39:59 --> Input Class Initialized
INFO - 2023-04-20 08:39:59 --> Language Class Initialized
INFO - 2023-04-20 08:39:59 --> Loader Class Initialized
INFO - 2023-04-20 08:39:59 --> Controller Class Initialized
DEBUG - 2023-04-20 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:39:59 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:59 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:39:59 --> Database Driver Class Initialized
INFO - 2023-04-20 08:39:59 --> Model "Login_model" initialized
INFO - 2023-04-20 08:39:59 --> Final output sent to browser
DEBUG - 2023-04-20 08:39:59 --> Total execution time: 0.0828
INFO - 2023-04-20 08:39:59 --> Config Class Initialized
INFO - 2023-04-20 08:39:59 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:39:59 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:39:59 --> Utf8 Class Initialized
INFO - 2023-04-20 08:39:59 --> URI Class Initialized
INFO - 2023-04-20 08:39:59 --> Router Class Initialized
INFO - 2023-04-20 08:39:59 --> Output Class Initialized
INFO - 2023-04-20 08:39:59 --> Security Class Initialized
DEBUG - 2023-04-20 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:39:59 --> Input Class Initialized
INFO - 2023-04-20 08:39:59 --> Language Class Initialized
INFO - 2023-04-20 08:39:59 --> Loader Class Initialized
INFO - 2023-04-20 08:39:59 --> Controller Class Initialized
DEBUG - 2023-04-20 08:39:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:39:59 --> Database Driver Class Initialized
INFO - 2023-04-20 08:40:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:40:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:40:00 --> Model "Login_model" initialized
INFO - 2023-04-20 08:40:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:40:00 --> Total execution time: 0.0731
INFO - 2023-04-20 08:41:00 --> Config Class Initialized
INFO - 2023-04-20 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:41:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:41:00 --> URI Class Initialized
INFO - 2023-04-20 08:41:00 --> Router Class Initialized
INFO - 2023-04-20 08:41:00 --> Output Class Initialized
INFO - 2023-04-20 08:41:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:41:00 --> Input Class Initialized
INFO - 2023-04-20 08:41:00 --> Language Class Initialized
INFO - 2023-04-20 08:41:00 --> Loader Class Initialized
INFO - 2023-04-20 08:41:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:41:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:41:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:41:00 --> Total execution time: 0.0121
INFO - 2023-04-20 08:41:00 --> Config Class Initialized
INFO - 2023-04-20 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:41:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:41:00 --> URI Class Initialized
INFO - 2023-04-20 08:41:00 --> Router Class Initialized
INFO - 2023-04-20 08:41:00 --> Output Class Initialized
INFO - 2023-04-20 08:41:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:41:00 --> Input Class Initialized
INFO - 2023-04-20 08:41:00 --> Language Class Initialized
INFO - 2023-04-20 08:41:00 --> Loader Class Initialized
INFO - 2023-04-20 08:41:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:41:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:41:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:41:00 --> Total execution time: 0.0514
INFO - 2023-04-20 08:41:00 --> Config Class Initialized
INFO - 2023-04-20 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:41:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:41:00 --> URI Class Initialized
INFO - 2023-04-20 08:41:00 --> Router Class Initialized
INFO - 2023-04-20 08:41:00 --> Output Class Initialized
INFO - 2023-04-20 08:41:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:41:00 --> Input Class Initialized
INFO - 2023-04-20 08:41:00 --> Language Class Initialized
INFO - 2023-04-20 08:41:00 --> Loader Class Initialized
INFO - 2023-04-20 08:41:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:41:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:41:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:41:00 --> Total execution time: 0.0538
INFO - 2023-04-20 08:41:00 --> Config Class Initialized
INFO - 2023-04-20 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:41:00 --> Utf8 Class Initialized
INFO - 2023-04-20 08:41:00 --> URI Class Initialized
INFO - 2023-04-20 08:41:00 --> Router Class Initialized
INFO - 2023-04-20 08:41:00 --> Output Class Initialized
INFO - 2023-04-20 08:41:00 --> Security Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:41:00 --> Input Class Initialized
INFO - 2023-04-20 08:41:00 --> Language Class Initialized
INFO - 2023-04-20 08:41:00 --> Loader Class Initialized
INFO - 2023-04-20 08:41:00 --> Controller Class Initialized
DEBUG - 2023-04-20 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:41:00 --> Database Driver Class Initialized
INFO - 2023-04-20 08:41:00 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:41:00 --> Final output sent to browser
DEBUG - 2023-04-20 08:41:00 --> Total execution time: 0.0502
INFO - 2023-04-20 08:45:50 --> Config Class Initialized
INFO - 2023-04-20 08:45:50 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:45:50 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:45:50 --> Utf8 Class Initialized
INFO - 2023-04-20 08:45:50 --> URI Class Initialized
INFO - 2023-04-20 08:45:50 --> Router Class Initialized
INFO - 2023-04-20 08:45:50 --> Output Class Initialized
INFO - 2023-04-20 08:45:50 --> Security Class Initialized
DEBUG - 2023-04-20 08:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:45:50 --> Input Class Initialized
INFO - 2023-04-20 08:45:50 --> Language Class Initialized
INFO - 2023-04-20 08:45:50 --> Loader Class Initialized
INFO - 2023-04-20 08:45:50 --> Controller Class Initialized
DEBUG - 2023-04-20 08:45:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:45:50 --> Database Driver Class Initialized
INFO - 2023-04-20 08:45:50 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:45:50 --> Final output sent to browser
DEBUG - 2023-04-20 08:45:50 --> Total execution time: 0.0810
INFO - 2023-04-20 08:45:50 --> Config Class Initialized
INFO - 2023-04-20 08:45:50 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:45:50 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:45:50 --> Utf8 Class Initialized
INFO - 2023-04-20 08:45:50 --> URI Class Initialized
INFO - 2023-04-20 08:45:50 --> Router Class Initialized
INFO - 2023-04-20 08:45:50 --> Output Class Initialized
INFO - 2023-04-20 08:45:50 --> Security Class Initialized
DEBUG - 2023-04-20 08:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:45:50 --> Input Class Initialized
INFO - 2023-04-20 08:45:50 --> Language Class Initialized
INFO - 2023-04-20 08:45:50 --> Loader Class Initialized
INFO - 2023-04-20 08:45:50 --> Controller Class Initialized
DEBUG - 2023-04-20 08:45:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:45:50 --> Database Driver Class Initialized
INFO - 2023-04-20 08:45:50 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:45:50 --> Final output sent to browser
DEBUG - 2023-04-20 08:45:50 --> Total execution time: 0.0883
INFO - 2023-04-20 08:54:24 --> Config Class Initialized
INFO - 2023-04-20 08:54:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:24 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:24 --> URI Class Initialized
INFO - 2023-04-20 08:54:24 --> Router Class Initialized
INFO - 2023-04-20 08:54:24 --> Output Class Initialized
INFO - 2023-04-20 08:54:24 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:24 --> Input Class Initialized
INFO - 2023-04-20 08:54:24 --> Language Class Initialized
INFO - 2023-04-20 08:54:24 --> Loader Class Initialized
INFO - 2023-04-20 08:54:24 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:24 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:24 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:24 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:24 --> Model "Login_model" initialized
INFO - 2023-04-20 08:54:24 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:24 --> Total execution time: 0.0671
INFO - 2023-04-20 08:54:24 --> Config Class Initialized
INFO - 2023-04-20 08:54:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:24 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:24 --> URI Class Initialized
INFO - 2023-04-20 08:54:24 --> Router Class Initialized
INFO - 2023-04-20 08:54:24 --> Output Class Initialized
INFO - 2023-04-20 08:54:24 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:24 --> Input Class Initialized
INFO - 2023-04-20 08:54:24 --> Language Class Initialized
INFO - 2023-04-20 08:54:24 --> Loader Class Initialized
INFO - 2023-04-20 08:54:24 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:24 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:25 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:25 --> Model "Login_model" initialized
INFO - 2023-04-20 08:54:25 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:25 --> Total execution time: 0.1006
INFO - 2023-04-20 08:54:28 --> Config Class Initialized
INFO - 2023-04-20 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:28 --> URI Class Initialized
INFO - 2023-04-20 08:54:28 --> Router Class Initialized
INFO - 2023-04-20 08:54:28 --> Output Class Initialized
INFO - 2023-04-20 08:54:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:28 --> Input Class Initialized
INFO - 2023-04-20 08:54:28 --> Language Class Initialized
INFO - 2023-04-20 08:54:28 --> Loader Class Initialized
INFO - 2023-04-20 08:54:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:28 --> Total execution time: 0.0128
INFO - 2023-04-20 08:54:28 --> Config Class Initialized
INFO - 2023-04-20 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:28 --> URI Class Initialized
INFO - 2023-04-20 08:54:28 --> Router Class Initialized
INFO - 2023-04-20 08:54:28 --> Output Class Initialized
INFO - 2023-04-20 08:54:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:28 --> Input Class Initialized
INFO - 2023-04-20 08:54:28 --> Language Class Initialized
INFO - 2023-04-20 08:54:28 --> Loader Class Initialized
INFO - 2023-04-20 08:54:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:28 --> Total execution time: 0.0118
INFO - 2023-04-20 08:54:28 --> Config Class Initialized
INFO - 2023-04-20 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:28 --> URI Class Initialized
INFO - 2023-04-20 08:54:28 --> Router Class Initialized
INFO - 2023-04-20 08:54:28 --> Output Class Initialized
INFO - 2023-04-20 08:54:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:28 --> Input Class Initialized
INFO - 2023-04-20 08:54:28 --> Language Class Initialized
INFO - 2023-04-20 08:54:28 --> Loader Class Initialized
INFO - 2023-04-20 08:54:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:28 --> Total execution time: 0.0563
INFO - 2023-04-20 08:54:28 --> Config Class Initialized
INFO - 2023-04-20 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:54:28 --> Utf8 Class Initialized
INFO - 2023-04-20 08:54:28 --> URI Class Initialized
INFO - 2023-04-20 08:54:28 --> Router Class Initialized
INFO - 2023-04-20 08:54:28 --> Output Class Initialized
INFO - 2023-04-20 08:54:28 --> Security Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:54:28 --> Input Class Initialized
INFO - 2023-04-20 08:54:28 --> Language Class Initialized
INFO - 2023-04-20 08:54:28 --> Loader Class Initialized
INFO - 2023-04-20 08:54:28 --> Controller Class Initialized
DEBUG - 2023-04-20 08:54:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:54:28 --> Database Driver Class Initialized
INFO - 2023-04-20 08:54:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:54:28 --> Final output sent to browser
DEBUG - 2023-04-20 08:54:28 --> Total execution time: 0.0539
INFO - 2023-04-20 08:59:10 --> Config Class Initialized
INFO - 2023-04-20 08:59:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:10 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:10 --> URI Class Initialized
INFO - 2023-04-20 08:59:10 --> Router Class Initialized
INFO - 2023-04-20 08:59:10 --> Output Class Initialized
INFO - 2023-04-20 08:59:10 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:10 --> Input Class Initialized
INFO - 2023-04-20 08:59:10 --> Language Class Initialized
INFO - 2023-04-20 08:59:10 --> Loader Class Initialized
INFO - 2023-04-20 08:59:10 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:10 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:10 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:10 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:10 --> Model "Login_model" initialized
INFO - 2023-04-20 08:59:10 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:10 --> Total execution time: 0.0692
INFO - 2023-04-20 08:59:10 --> Config Class Initialized
INFO - 2023-04-20 08:59:10 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:10 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:10 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:10 --> URI Class Initialized
INFO - 2023-04-20 08:59:10 --> Router Class Initialized
INFO - 2023-04-20 08:59:10 --> Output Class Initialized
INFO - 2023-04-20 08:59:10 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:10 --> Input Class Initialized
INFO - 2023-04-20 08:59:10 --> Language Class Initialized
INFO - 2023-04-20 08:59:10 --> Loader Class Initialized
INFO - 2023-04-20 08:59:10 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:10 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:10 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:10 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:10 --> Model "Login_model" initialized
INFO - 2023-04-20 08:59:10 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:10 --> Total execution time: 0.1061
INFO - 2023-04-20 08:59:12 --> Config Class Initialized
INFO - 2023-04-20 08:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:12 --> URI Class Initialized
INFO - 2023-04-20 08:59:12 --> Router Class Initialized
INFO - 2023-04-20 08:59:12 --> Output Class Initialized
INFO - 2023-04-20 08:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:12 --> Input Class Initialized
INFO - 2023-04-20 08:59:12 --> Language Class Initialized
INFO - 2023-04-20 08:59:12 --> Loader Class Initialized
INFO - 2023-04-20 08:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:12 --> Total execution time: 0.0099
INFO - 2023-04-20 08:59:12 --> Config Class Initialized
INFO - 2023-04-20 08:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:12 --> URI Class Initialized
INFO - 2023-04-20 08:59:12 --> Router Class Initialized
INFO - 2023-04-20 08:59:12 --> Output Class Initialized
INFO - 2023-04-20 08:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:12 --> Input Class Initialized
INFO - 2023-04-20 08:59:12 --> Language Class Initialized
INFO - 2023-04-20 08:59:12 --> Loader Class Initialized
INFO - 2023-04-20 08:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:12 --> Total execution time: 0.0513
INFO - 2023-04-20 08:59:12 --> Config Class Initialized
INFO - 2023-04-20 08:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:12 --> URI Class Initialized
INFO - 2023-04-20 08:59:12 --> Router Class Initialized
INFO - 2023-04-20 08:59:12 --> Output Class Initialized
INFO - 2023-04-20 08:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:12 --> Input Class Initialized
INFO - 2023-04-20 08:59:12 --> Language Class Initialized
INFO - 2023-04-20 08:59:12 --> Loader Class Initialized
INFO - 2023-04-20 08:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:12 --> Total execution time: 0.0545
INFO - 2023-04-20 08:59:12 --> Config Class Initialized
INFO - 2023-04-20 08:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 08:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 08:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 08:59:12 --> URI Class Initialized
INFO - 2023-04-20 08:59:12 --> Router Class Initialized
INFO - 2023-04-20 08:59:12 --> Output Class Initialized
INFO - 2023-04-20 08:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 08:59:12 --> Input Class Initialized
INFO - 2023-04-20 08:59:12 --> Language Class Initialized
INFO - 2023-04-20 08:59:12 --> Loader Class Initialized
INFO - 2023-04-20 08:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 08:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 08:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 08:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 08:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 08:59:12 --> Total execution time: 0.0384
INFO - 2023-04-20 09:00:13 --> Config Class Initialized
INFO - 2023-04-20 09:00:13 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:13 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:13 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:13 --> URI Class Initialized
INFO - 2023-04-20 09:00:13 --> Router Class Initialized
INFO - 2023-04-20 09:00:13 --> Output Class Initialized
INFO - 2023-04-20 09:00:13 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:13 --> Input Class Initialized
INFO - 2023-04-20 09:00:13 --> Language Class Initialized
INFO - 2023-04-20 09:00:13 --> Loader Class Initialized
INFO - 2023-04-20 09:00:13 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:13 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:13 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:13 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:13 --> Model "Login_model" initialized
INFO - 2023-04-20 09:00:13 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:13 --> Total execution time: 0.1195
INFO - 2023-04-20 09:00:13 --> Config Class Initialized
INFO - 2023-04-20 09:00:13 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:13 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:13 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:13 --> URI Class Initialized
INFO - 2023-04-20 09:00:13 --> Router Class Initialized
INFO - 2023-04-20 09:00:13 --> Output Class Initialized
INFO - 2023-04-20 09:00:13 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:13 --> Input Class Initialized
INFO - 2023-04-20 09:00:13 --> Language Class Initialized
INFO - 2023-04-20 09:00:13 --> Loader Class Initialized
INFO - 2023-04-20 09:00:13 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:13 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:13 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:13 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:13 --> Model "Login_model" initialized
INFO - 2023-04-20 09:00:13 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:13 --> Total execution time: 0.0775
INFO - 2023-04-20 09:00:25 --> Config Class Initialized
INFO - 2023-04-20 09:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:25 --> URI Class Initialized
INFO - 2023-04-20 09:00:25 --> Router Class Initialized
INFO - 2023-04-20 09:00:25 --> Output Class Initialized
INFO - 2023-04-20 09:00:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:25 --> Input Class Initialized
INFO - 2023-04-20 09:00:25 --> Language Class Initialized
INFO - 2023-04-20 09:00:25 --> Loader Class Initialized
INFO - 2023-04-20 09:00:25 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:25 --> Total execution time: 0.0371
INFO - 2023-04-20 09:00:25 --> Config Class Initialized
INFO - 2023-04-20 09:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:25 --> URI Class Initialized
INFO - 2023-04-20 09:00:25 --> Router Class Initialized
INFO - 2023-04-20 09:00:25 --> Output Class Initialized
INFO - 2023-04-20 09:00:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:25 --> Input Class Initialized
INFO - 2023-04-20 09:00:25 --> Language Class Initialized
INFO - 2023-04-20 09:00:25 --> Loader Class Initialized
INFO - 2023-04-20 09:00:25 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:25 --> Total execution time: 0.0474
INFO - 2023-04-20 09:00:25 --> Config Class Initialized
INFO - 2023-04-20 09:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:25 --> URI Class Initialized
INFO - 2023-04-20 09:00:25 --> Router Class Initialized
INFO - 2023-04-20 09:00:25 --> Output Class Initialized
INFO - 2023-04-20 09:00:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:25 --> Input Class Initialized
INFO - 2023-04-20 09:00:25 --> Language Class Initialized
INFO - 2023-04-20 09:00:25 --> Loader Class Initialized
INFO - 2023-04-20 09:00:25 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:25 --> Total execution time: 0.0658
INFO - 2023-04-20 09:00:25 --> Config Class Initialized
INFO - 2023-04-20 09:00:25 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:00:25 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:00:25 --> Utf8 Class Initialized
INFO - 2023-04-20 09:00:25 --> URI Class Initialized
INFO - 2023-04-20 09:00:25 --> Router Class Initialized
INFO - 2023-04-20 09:00:25 --> Output Class Initialized
INFO - 2023-04-20 09:00:25 --> Security Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:00:25 --> Input Class Initialized
INFO - 2023-04-20 09:00:25 --> Language Class Initialized
INFO - 2023-04-20 09:00:25 --> Loader Class Initialized
INFO - 2023-04-20 09:00:25 --> Controller Class Initialized
DEBUG - 2023-04-20 09:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:00:25 --> Database Driver Class Initialized
INFO - 2023-04-20 09:00:25 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:00:25 --> Final output sent to browser
DEBUG - 2023-04-20 09:00:25 --> Total execution time: 0.0324
INFO - 2023-04-20 09:04:12 --> Config Class Initialized
INFO - 2023-04-20 09:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:12 --> URI Class Initialized
INFO - 2023-04-20 09:04:12 --> Router Class Initialized
INFO - 2023-04-20 09:04:12 --> Output Class Initialized
INFO - 2023-04-20 09:04:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:12 --> Input Class Initialized
INFO - 2023-04-20 09:04:12 --> Language Class Initialized
INFO - 2023-04-20 09:04:12 --> Loader Class Initialized
INFO - 2023-04-20 09:04:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:12 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:12 --> Total execution time: 0.0752
INFO - 2023-04-20 09:04:12 --> Config Class Initialized
INFO - 2023-04-20 09:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:12 --> URI Class Initialized
INFO - 2023-04-20 09:04:12 --> Router Class Initialized
INFO - 2023-04-20 09:04:12 --> Output Class Initialized
INFO - 2023-04-20 09:04:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:12 --> Input Class Initialized
INFO - 2023-04-20 09:04:12 --> Language Class Initialized
INFO - 2023-04-20 09:04:12 --> Loader Class Initialized
INFO - 2023-04-20 09:04:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:12 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:12 --> Total execution time: 0.0650
INFO - 2023-04-20 09:04:15 --> Config Class Initialized
INFO - 2023-04-20 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:15 --> URI Class Initialized
INFO - 2023-04-20 09:04:15 --> Router Class Initialized
INFO - 2023-04-20 09:04:15 --> Output Class Initialized
INFO - 2023-04-20 09:04:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:15 --> Input Class Initialized
INFO - 2023-04-20 09:04:15 --> Language Class Initialized
INFO - 2023-04-20 09:04:15 --> Loader Class Initialized
INFO - 2023-04-20 09:04:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:15 --> Total execution time: 0.0133
INFO - 2023-04-20 09:04:15 --> Config Class Initialized
INFO - 2023-04-20 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:15 --> URI Class Initialized
INFO - 2023-04-20 09:04:15 --> Router Class Initialized
INFO - 2023-04-20 09:04:15 --> Output Class Initialized
INFO - 2023-04-20 09:04:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:15 --> Input Class Initialized
INFO - 2023-04-20 09:04:15 --> Language Class Initialized
INFO - 2023-04-20 09:04:15 --> Loader Class Initialized
INFO - 2023-04-20 09:04:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:15 --> Total execution time: 0.0109
INFO - 2023-04-20 09:04:15 --> Config Class Initialized
INFO - 2023-04-20 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:15 --> URI Class Initialized
INFO - 2023-04-20 09:04:15 --> Router Class Initialized
INFO - 2023-04-20 09:04:15 --> Output Class Initialized
INFO - 2023-04-20 09:04:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:15 --> Input Class Initialized
INFO - 2023-04-20 09:04:15 --> Language Class Initialized
INFO - 2023-04-20 09:04:15 --> Loader Class Initialized
INFO - 2023-04-20 09:04:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:15 --> Total execution time: 0.0539
INFO - 2023-04-20 09:04:15 --> Config Class Initialized
INFO - 2023-04-20 09:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:15 --> URI Class Initialized
INFO - 2023-04-20 09:04:15 --> Router Class Initialized
INFO - 2023-04-20 09:04:15 --> Output Class Initialized
INFO - 2023-04-20 09:04:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:15 --> Input Class Initialized
INFO - 2023-04-20 09:04:15 --> Language Class Initialized
INFO - 2023-04-20 09:04:15 --> Loader Class Initialized
INFO - 2023-04-20 09:04:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:15 --> Total execution time: 0.0129
INFO - 2023-04-20 09:04:33 --> Config Class Initialized
INFO - 2023-04-20 09:04:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:33 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:33 --> URI Class Initialized
INFO - 2023-04-20 09:04:33 --> Router Class Initialized
INFO - 2023-04-20 09:04:33 --> Output Class Initialized
INFO - 2023-04-20 09:04:33 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:33 --> Input Class Initialized
INFO - 2023-04-20 09:04:33 --> Language Class Initialized
INFO - 2023-04-20 09:04:33 --> Loader Class Initialized
INFO - 2023-04-20 09:04:33 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:33 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:33 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:33 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:33 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:33 --> Total execution time: 0.1009
INFO - 2023-04-20 09:04:33 --> Config Class Initialized
INFO - 2023-04-20 09:04:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:33 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:33 --> URI Class Initialized
INFO - 2023-04-20 09:04:33 --> Router Class Initialized
INFO - 2023-04-20 09:04:33 --> Output Class Initialized
INFO - 2023-04-20 09:04:33 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:33 --> Input Class Initialized
INFO - 2023-04-20 09:04:33 --> Language Class Initialized
INFO - 2023-04-20 09:04:33 --> Loader Class Initialized
INFO - 2023-04-20 09:04:33 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:33 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:33 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:33 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:33 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:33 --> Total execution time: 0.0606
INFO - 2023-04-20 09:04:39 --> Config Class Initialized
INFO - 2023-04-20 09:04:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:39 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:39 --> URI Class Initialized
INFO - 2023-04-20 09:04:39 --> Router Class Initialized
INFO - 2023-04-20 09:04:39 --> Output Class Initialized
INFO - 2023-04-20 09:04:39 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:39 --> Input Class Initialized
INFO - 2023-04-20 09:04:39 --> Language Class Initialized
INFO - 2023-04-20 09:04:39 --> Loader Class Initialized
INFO - 2023-04-20 09:04:39 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:39 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:39 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:39 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:39 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:39 --> Total execution time: 0.1474
INFO - 2023-04-20 09:04:39 --> Config Class Initialized
INFO - 2023-04-20 09:04:39 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:39 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:39 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:39 --> URI Class Initialized
INFO - 2023-04-20 09:04:39 --> Router Class Initialized
INFO - 2023-04-20 09:04:39 --> Output Class Initialized
INFO - 2023-04-20 09:04:39 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:39 --> Input Class Initialized
INFO - 2023-04-20 09:04:39 --> Language Class Initialized
INFO - 2023-04-20 09:04:39 --> Loader Class Initialized
INFO - 2023-04-20 09:04:39 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:39 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:39 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:39 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:39 --> Model "Login_model" initialized
INFO - 2023-04-20 09:04:39 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:39 --> Total execution time: 0.0693
INFO - 2023-04-20 09:04:42 --> Config Class Initialized
INFO - 2023-04-20 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:42 --> URI Class Initialized
INFO - 2023-04-20 09:04:42 --> Router Class Initialized
INFO - 2023-04-20 09:04:42 --> Output Class Initialized
INFO - 2023-04-20 09:04:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:42 --> Input Class Initialized
INFO - 2023-04-20 09:04:42 --> Language Class Initialized
INFO - 2023-04-20 09:04:42 --> Loader Class Initialized
INFO - 2023-04-20 09:04:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:42 --> Total execution time: 0.0509
INFO - 2023-04-20 09:04:42 --> Config Class Initialized
INFO - 2023-04-20 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:42 --> URI Class Initialized
INFO - 2023-04-20 09:04:42 --> Router Class Initialized
INFO - 2023-04-20 09:04:42 --> Output Class Initialized
INFO - 2023-04-20 09:04:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:42 --> Input Class Initialized
INFO - 2023-04-20 09:04:42 --> Language Class Initialized
INFO - 2023-04-20 09:04:42 --> Loader Class Initialized
INFO - 2023-04-20 09:04:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:42 --> Total execution time: 0.0099
INFO - 2023-04-20 09:04:42 --> Config Class Initialized
INFO - 2023-04-20 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:42 --> URI Class Initialized
INFO - 2023-04-20 09:04:42 --> Router Class Initialized
INFO - 2023-04-20 09:04:42 --> Output Class Initialized
INFO - 2023-04-20 09:04:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:42 --> Input Class Initialized
INFO - 2023-04-20 09:04:42 --> Language Class Initialized
INFO - 2023-04-20 09:04:42 --> Loader Class Initialized
INFO - 2023-04-20 09:04:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:42 --> Total execution time: 0.0523
INFO - 2023-04-20 09:04:42 --> Config Class Initialized
INFO - 2023-04-20 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:04:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:04:42 --> URI Class Initialized
INFO - 2023-04-20 09:04:42 --> Router Class Initialized
INFO - 2023-04-20 09:04:42 --> Output Class Initialized
INFO - 2023-04-20 09:04:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:04:42 --> Input Class Initialized
INFO - 2023-04-20 09:04:42 --> Language Class Initialized
INFO - 2023-04-20 09:04:42 --> Loader Class Initialized
INFO - 2023-04-20 09:04:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:04:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:04:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:04:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:04:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:04:42 --> Total execution time: 0.0108
INFO - 2023-04-20 09:08:41 --> Config Class Initialized
INFO - 2023-04-20 09:08:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:08:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:08:41 --> Utf8 Class Initialized
INFO - 2023-04-20 09:08:41 --> URI Class Initialized
INFO - 2023-04-20 09:08:41 --> Router Class Initialized
INFO - 2023-04-20 09:08:41 --> Output Class Initialized
INFO - 2023-04-20 09:08:41 --> Security Class Initialized
DEBUG - 2023-04-20 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:08:41 --> Input Class Initialized
INFO - 2023-04-20 09:08:41 --> Language Class Initialized
INFO - 2023-04-20 09:08:41 --> Loader Class Initialized
INFO - 2023-04-20 09:08:41 --> Controller Class Initialized
DEBUG - 2023-04-20 09:08:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:08:41 --> Database Driver Class Initialized
INFO - 2023-04-20 09:08:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:08:41 --> Database Driver Class Initialized
INFO - 2023-04-20 09:08:41 --> Model "Login_model" initialized
INFO - 2023-04-20 09:08:41 --> Final output sent to browser
DEBUG - 2023-04-20 09:08:41 --> Total execution time: 0.1151
INFO - 2023-04-20 09:08:41 --> Config Class Initialized
INFO - 2023-04-20 09:08:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:08:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:08:41 --> Utf8 Class Initialized
INFO - 2023-04-20 09:08:41 --> URI Class Initialized
INFO - 2023-04-20 09:08:41 --> Router Class Initialized
INFO - 2023-04-20 09:08:41 --> Output Class Initialized
INFO - 2023-04-20 09:08:41 --> Security Class Initialized
DEBUG - 2023-04-20 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:08:41 --> Input Class Initialized
INFO - 2023-04-20 09:08:41 --> Language Class Initialized
INFO - 2023-04-20 09:08:41 --> Loader Class Initialized
INFO - 2023-04-20 09:08:41 --> Controller Class Initialized
DEBUG - 2023-04-20 09:08:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:08:41 --> Database Driver Class Initialized
INFO - 2023-04-20 09:08:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:08:41 --> Database Driver Class Initialized
INFO - 2023-04-20 09:08:41 --> Model "Login_model" initialized
INFO - 2023-04-20 09:08:41 --> Final output sent to browser
DEBUG - 2023-04-20 09:08:41 --> Total execution time: 0.0807
INFO - 2023-04-20 09:31:23 --> Config Class Initialized
INFO - 2023-04-20 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:31:23 --> Utf8 Class Initialized
INFO - 2023-04-20 09:31:23 --> URI Class Initialized
INFO - 2023-04-20 09:31:23 --> Router Class Initialized
INFO - 2023-04-20 09:31:23 --> Output Class Initialized
INFO - 2023-04-20 09:31:23 --> Security Class Initialized
DEBUG - 2023-04-20 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:31:23 --> Input Class Initialized
INFO - 2023-04-20 09:31:23 --> Language Class Initialized
INFO - 2023-04-20 09:31:23 --> Loader Class Initialized
INFO - 2023-04-20 09:31:23 --> Controller Class Initialized
DEBUG - 2023-04-20 09:31:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:31:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:31:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:23 --> Model "Login_model" initialized
INFO - 2023-04-20 09:31:23 --> Final output sent to browser
DEBUG - 2023-04-20 09:31:23 --> Total execution time: 0.1082
INFO - 2023-04-20 09:31:23 --> Config Class Initialized
INFO - 2023-04-20 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:31:23 --> Utf8 Class Initialized
INFO - 2023-04-20 09:31:23 --> URI Class Initialized
INFO - 2023-04-20 09:31:23 --> Router Class Initialized
INFO - 2023-04-20 09:31:23 --> Output Class Initialized
INFO - 2023-04-20 09:31:23 --> Security Class Initialized
DEBUG - 2023-04-20 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:31:23 --> Input Class Initialized
INFO - 2023-04-20 09:31:23 --> Language Class Initialized
INFO - 2023-04-20 09:31:23 --> Loader Class Initialized
INFO - 2023-04-20 09:31:23 --> Controller Class Initialized
DEBUG - 2023-04-20 09:31:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:31:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:31:23 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:23 --> Model "Login_model" initialized
INFO - 2023-04-20 09:31:23 --> Final output sent to browser
DEBUG - 2023-04-20 09:31:23 --> Total execution time: 0.1017
INFO - 2023-04-20 09:31:44 --> Config Class Initialized
INFO - 2023-04-20 09:31:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:31:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:31:44 --> Utf8 Class Initialized
INFO - 2023-04-20 09:31:44 --> URI Class Initialized
INFO - 2023-04-20 09:31:44 --> Router Class Initialized
INFO - 2023-04-20 09:31:44 --> Output Class Initialized
INFO - 2023-04-20 09:31:44 --> Security Class Initialized
DEBUG - 2023-04-20 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:31:44 --> Input Class Initialized
INFO - 2023-04-20 09:31:44 --> Language Class Initialized
INFO - 2023-04-20 09:31:44 --> Loader Class Initialized
INFO - 2023-04-20 09:31:44 --> Controller Class Initialized
DEBUG - 2023-04-20 09:31:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:31:44 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:31:44 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:44 --> Model "Login_model" initialized
INFO - 2023-04-20 09:31:44 --> Final output sent to browser
DEBUG - 2023-04-20 09:31:44 --> Total execution time: 0.1032
INFO - 2023-04-20 09:31:44 --> Config Class Initialized
INFO - 2023-04-20 09:31:45 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:31:45 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:31:45 --> Utf8 Class Initialized
INFO - 2023-04-20 09:31:45 --> URI Class Initialized
INFO - 2023-04-20 09:31:45 --> Router Class Initialized
INFO - 2023-04-20 09:31:45 --> Output Class Initialized
INFO - 2023-04-20 09:31:45 --> Security Class Initialized
DEBUG - 2023-04-20 09:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:31:45 --> Input Class Initialized
INFO - 2023-04-20 09:31:45 --> Language Class Initialized
INFO - 2023-04-20 09:31:45 --> Loader Class Initialized
INFO - 2023-04-20 09:31:45 --> Controller Class Initialized
DEBUG - 2023-04-20 09:31:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:31:45 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:45 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:31:45 --> Database Driver Class Initialized
INFO - 2023-04-20 09:31:45 --> Model "Login_model" initialized
INFO - 2023-04-20 09:31:45 --> Final output sent to browser
DEBUG - 2023-04-20 09:31:45 --> Total execution time: 0.0859
INFO - 2023-04-20 09:32:51 --> Config Class Initialized
INFO - 2023-04-20 09:32:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:32:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:32:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:32:51 --> URI Class Initialized
INFO - 2023-04-20 09:32:51 --> Router Class Initialized
INFO - 2023-04-20 09:32:51 --> Output Class Initialized
INFO - 2023-04-20 09:32:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:32:51 --> Input Class Initialized
INFO - 2023-04-20 09:32:51 --> Language Class Initialized
INFO - 2023-04-20 09:32:51 --> Loader Class Initialized
INFO - 2023-04-20 09:32:51 --> Controller Class Initialized
DEBUG - 2023-04-20 09:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:32:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:32:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:32:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:32:51 --> Model "Login_model" initialized
INFO - 2023-04-20 09:32:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:32:51 --> Total execution time: 0.1402
INFO - 2023-04-20 09:32:51 --> Config Class Initialized
INFO - 2023-04-20 09:32:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:32:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:32:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:32:51 --> URI Class Initialized
INFO - 2023-04-20 09:32:51 --> Router Class Initialized
INFO - 2023-04-20 09:32:51 --> Output Class Initialized
INFO - 2023-04-20 09:32:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:32:51 --> Input Class Initialized
INFO - 2023-04-20 09:32:51 --> Language Class Initialized
INFO - 2023-04-20 09:32:51 --> Loader Class Initialized
INFO - 2023-04-20 09:32:51 --> Controller Class Initialized
DEBUG - 2023-04-20 09:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:32:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:32:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:32:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:32:51 --> Model "Login_model" initialized
INFO - 2023-04-20 09:32:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:32:51 --> Total execution time: 0.0733
INFO - 2023-04-20 09:33:14 --> Config Class Initialized
INFO - 2023-04-20 09:33:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:14 --> URI Class Initialized
INFO - 2023-04-20 09:33:14 --> Router Class Initialized
INFO - 2023-04-20 09:33:14 --> Output Class Initialized
INFO - 2023-04-20 09:33:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:14 --> Input Class Initialized
INFO - 2023-04-20 09:33:14 --> Language Class Initialized
INFO - 2023-04-20 09:33:14 --> Loader Class Initialized
INFO - 2023-04-20 09:33:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:14 --> Model "Login_model" initialized
INFO - 2023-04-20 09:33:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:14 --> Total execution time: 0.1193
INFO - 2023-04-20 09:33:14 --> Config Class Initialized
INFO - 2023-04-20 09:33:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:14 --> URI Class Initialized
INFO - 2023-04-20 09:33:14 --> Router Class Initialized
INFO - 2023-04-20 09:33:14 --> Output Class Initialized
INFO - 2023-04-20 09:33:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:14 --> Input Class Initialized
INFO - 2023-04-20 09:33:14 --> Language Class Initialized
INFO - 2023-04-20 09:33:14 --> Loader Class Initialized
INFO - 2023-04-20 09:33:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:14 --> Model "Login_model" initialized
INFO - 2023-04-20 09:33:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:15 --> Total execution time: 0.0997
INFO - 2023-04-20 09:33:35 --> Config Class Initialized
INFO - 2023-04-20 09:33:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:35 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:35 --> URI Class Initialized
INFO - 2023-04-20 09:33:35 --> Router Class Initialized
INFO - 2023-04-20 09:33:35 --> Output Class Initialized
INFO - 2023-04-20 09:33:35 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:35 --> Input Class Initialized
INFO - 2023-04-20 09:33:35 --> Language Class Initialized
INFO - 2023-04-20 09:33:35 --> Loader Class Initialized
INFO - 2023-04-20 09:33:35 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:35 --> Model "Login_model" initialized
INFO - 2023-04-20 09:33:35 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:35 --> Total execution time: 0.1122
INFO - 2023-04-20 09:33:35 --> Config Class Initialized
INFO - 2023-04-20 09:33:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:35 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:35 --> URI Class Initialized
INFO - 2023-04-20 09:33:35 --> Router Class Initialized
INFO - 2023-04-20 09:33:35 --> Output Class Initialized
INFO - 2023-04-20 09:33:35 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:35 --> Input Class Initialized
INFO - 2023-04-20 09:33:35 --> Language Class Initialized
INFO - 2023-04-20 09:33:35 --> Loader Class Initialized
INFO - 2023-04-20 09:33:35 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:35 --> Model "Login_model" initialized
INFO - 2023-04-20 09:33:35 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:35 --> Total execution time: 0.0742
INFO - 2023-04-20 09:33:47 --> Config Class Initialized
INFO - 2023-04-20 09:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:47 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:47 --> URI Class Initialized
INFO - 2023-04-20 09:33:47 --> Router Class Initialized
INFO - 2023-04-20 09:33:47 --> Output Class Initialized
INFO - 2023-04-20 09:33:47 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:47 --> Input Class Initialized
INFO - 2023-04-20 09:33:47 --> Language Class Initialized
INFO - 2023-04-20 09:33:47 --> Loader Class Initialized
INFO - 2023-04-20 09:33:47 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:47 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:47 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:47 --> Total execution time: 0.0152
INFO - 2023-04-20 09:33:47 --> Config Class Initialized
INFO - 2023-04-20 09:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:47 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:47 --> URI Class Initialized
INFO - 2023-04-20 09:33:47 --> Router Class Initialized
INFO - 2023-04-20 09:33:47 --> Output Class Initialized
INFO - 2023-04-20 09:33:47 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:47 --> Input Class Initialized
INFO - 2023-04-20 09:33:47 --> Language Class Initialized
INFO - 2023-04-20 09:33:47 --> Loader Class Initialized
INFO - 2023-04-20 09:33:47 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:47 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:47 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:47 --> Total execution time: 0.0516
INFO - 2023-04-20 09:33:47 --> Config Class Initialized
INFO - 2023-04-20 09:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:47 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:47 --> URI Class Initialized
INFO - 2023-04-20 09:33:47 --> Router Class Initialized
INFO - 2023-04-20 09:33:47 --> Output Class Initialized
INFO - 2023-04-20 09:33:47 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:47 --> Input Class Initialized
INFO - 2023-04-20 09:33:47 --> Language Class Initialized
INFO - 2023-04-20 09:33:47 --> Loader Class Initialized
INFO - 2023-04-20 09:33:47 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:47 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:47 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:47 --> Total execution time: 0.0574
INFO - 2023-04-20 09:33:47 --> Config Class Initialized
INFO - 2023-04-20 09:33:47 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:33:47 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:33:47 --> Utf8 Class Initialized
INFO - 2023-04-20 09:33:47 --> URI Class Initialized
INFO - 2023-04-20 09:33:47 --> Router Class Initialized
INFO - 2023-04-20 09:33:47 --> Output Class Initialized
INFO - 2023-04-20 09:33:47 --> Security Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:33:47 --> Input Class Initialized
INFO - 2023-04-20 09:33:47 --> Language Class Initialized
INFO - 2023-04-20 09:33:47 --> Loader Class Initialized
INFO - 2023-04-20 09:33:47 --> Controller Class Initialized
DEBUG - 2023-04-20 09:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:33:47 --> Database Driver Class Initialized
INFO - 2023-04-20 09:33:47 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:33:47 --> Final output sent to browser
DEBUG - 2023-04-20 09:33:47 --> Total execution time: 0.0544
INFO - 2023-04-20 09:36:08 --> Config Class Initialized
INFO - 2023-04-20 09:36:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:09 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:09 --> URI Class Initialized
INFO - 2023-04-20 09:36:09 --> Router Class Initialized
INFO - 2023-04-20 09:36:09 --> Output Class Initialized
INFO - 2023-04-20 09:36:09 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:09 --> Input Class Initialized
INFO - 2023-04-20 09:36:09 --> Language Class Initialized
INFO - 2023-04-20 09:36:09 --> Loader Class Initialized
INFO - 2023-04-20 09:36:09 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:09 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:09 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:09 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:09 --> Model "Login_model" initialized
INFO - 2023-04-20 09:36:09 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:09 --> Total execution time: 0.1106
INFO - 2023-04-20 09:36:09 --> Config Class Initialized
INFO - 2023-04-20 09:36:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:09 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:09 --> URI Class Initialized
INFO - 2023-04-20 09:36:09 --> Router Class Initialized
INFO - 2023-04-20 09:36:09 --> Output Class Initialized
INFO - 2023-04-20 09:36:09 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:09 --> Input Class Initialized
INFO - 2023-04-20 09:36:09 --> Language Class Initialized
INFO - 2023-04-20 09:36:09 --> Loader Class Initialized
INFO - 2023-04-20 09:36:09 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:09 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:09 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:09 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:09 --> Model "Login_model" initialized
INFO - 2023-04-20 09:36:09 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:09 --> Total execution time: 0.0597
INFO - 2023-04-20 09:36:12 --> Config Class Initialized
INFO - 2023-04-20 09:36:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:12 --> URI Class Initialized
INFO - 2023-04-20 09:36:12 --> Router Class Initialized
INFO - 2023-04-20 09:36:12 --> Output Class Initialized
INFO - 2023-04-20 09:36:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:12 --> Input Class Initialized
INFO - 2023-04-20 09:36:12 --> Language Class Initialized
INFO - 2023-04-20 09:36:12 --> Loader Class Initialized
INFO - 2023-04-20 09:36:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:12 --> Total execution time: 0.0204
INFO - 2023-04-20 09:36:12 --> Config Class Initialized
INFO - 2023-04-20 09:36:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:12 --> URI Class Initialized
INFO - 2023-04-20 09:36:12 --> Router Class Initialized
INFO - 2023-04-20 09:36:12 --> Output Class Initialized
INFO - 2023-04-20 09:36:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:12 --> Input Class Initialized
INFO - 2023-04-20 09:36:12 --> Language Class Initialized
INFO - 2023-04-20 09:36:12 --> Loader Class Initialized
INFO - 2023-04-20 09:36:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:12 --> Total execution time: 0.0111
INFO - 2023-04-20 09:36:12 --> Config Class Initialized
INFO - 2023-04-20 09:36:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:12 --> URI Class Initialized
INFO - 2023-04-20 09:36:12 --> Router Class Initialized
INFO - 2023-04-20 09:36:12 --> Output Class Initialized
INFO - 2023-04-20 09:36:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:12 --> Input Class Initialized
INFO - 2023-04-20 09:36:12 --> Language Class Initialized
INFO - 2023-04-20 09:36:12 --> Loader Class Initialized
INFO - 2023-04-20 09:36:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:12 --> Total execution time: 0.0493
INFO - 2023-04-20 09:36:12 --> Config Class Initialized
INFO - 2023-04-20 09:36:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:36:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:36:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:36:12 --> URI Class Initialized
INFO - 2023-04-20 09:36:12 --> Router Class Initialized
INFO - 2023-04-20 09:36:12 --> Output Class Initialized
INFO - 2023-04-20 09:36:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:36:12 --> Input Class Initialized
INFO - 2023-04-20 09:36:12 --> Language Class Initialized
INFO - 2023-04-20 09:36:12 --> Loader Class Initialized
INFO - 2023-04-20 09:36:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:36:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:36:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:36:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:36:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:36:12 --> Total execution time: 0.0113
INFO - 2023-04-20 09:37:56 --> Config Class Initialized
INFO - 2023-04-20 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:56 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:56 --> URI Class Initialized
INFO - 2023-04-20 09:37:56 --> Router Class Initialized
INFO - 2023-04-20 09:37:56 --> Output Class Initialized
INFO - 2023-04-20 09:37:56 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:56 --> Input Class Initialized
INFO - 2023-04-20 09:37:56 --> Language Class Initialized
INFO - 2023-04-20 09:37:56 --> Loader Class Initialized
INFO - 2023-04-20 09:37:56 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:56 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:56 --> Model "Login_model" initialized
INFO - 2023-04-20 09:37:56 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:56 --> Total execution time: 0.1228
INFO - 2023-04-20 09:37:56 --> Config Class Initialized
INFO - 2023-04-20 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:56 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:56 --> URI Class Initialized
INFO - 2023-04-20 09:37:56 --> Router Class Initialized
INFO - 2023-04-20 09:37:56 --> Output Class Initialized
INFO - 2023-04-20 09:37:56 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:56 --> Input Class Initialized
INFO - 2023-04-20 09:37:56 --> Language Class Initialized
INFO - 2023-04-20 09:37:56 --> Loader Class Initialized
INFO - 2023-04-20 09:37:56 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:56 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:56 --> Model "Login_model" initialized
INFO - 2023-04-20 09:37:56 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:56 --> Total execution time: 0.0693
INFO - 2023-04-20 09:37:58 --> Config Class Initialized
INFO - 2023-04-20 09:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:58 --> URI Class Initialized
INFO - 2023-04-20 09:37:58 --> Router Class Initialized
INFO - 2023-04-20 09:37:58 --> Output Class Initialized
INFO - 2023-04-20 09:37:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:58 --> Input Class Initialized
INFO - 2023-04-20 09:37:58 --> Language Class Initialized
INFO - 2023-04-20 09:37:58 --> Loader Class Initialized
INFO - 2023-04-20 09:37:58 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:58 --> Total execution time: 0.0139
INFO - 2023-04-20 09:37:58 --> Config Class Initialized
INFO - 2023-04-20 09:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:58 --> URI Class Initialized
INFO - 2023-04-20 09:37:58 --> Router Class Initialized
INFO - 2023-04-20 09:37:58 --> Output Class Initialized
INFO - 2023-04-20 09:37:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:58 --> Input Class Initialized
INFO - 2023-04-20 09:37:58 --> Language Class Initialized
INFO - 2023-04-20 09:37:58 --> Loader Class Initialized
INFO - 2023-04-20 09:37:58 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:58 --> Total execution time: 0.0108
INFO - 2023-04-20 09:37:58 --> Config Class Initialized
INFO - 2023-04-20 09:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:58 --> URI Class Initialized
INFO - 2023-04-20 09:37:58 --> Router Class Initialized
INFO - 2023-04-20 09:37:58 --> Output Class Initialized
INFO - 2023-04-20 09:37:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:58 --> Input Class Initialized
INFO - 2023-04-20 09:37:58 --> Language Class Initialized
INFO - 2023-04-20 09:37:58 --> Loader Class Initialized
INFO - 2023-04-20 09:37:58 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:58 --> Total execution time: 0.0520
INFO - 2023-04-20 09:37:58 --> Config Class Initialized
INFO - 2023-04-20 09:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:37:58 --> Utf8 Class Initialized
INFO - 2023-04-20 09:37:58 --> URI Class Initialized
INFO - 2023-04-20 09:37:58 --> Router Class Initialized
INFO - 2023-04-20 09:37:58 --> Output Class Initialized
INFO - 2023-04-20 09:37:58 --> Security Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:37:58 --> Input Class Initialized
INFO - 2023-04-20 09:37:58 --> Language Class Initialized
INFO - 2023-04-20 09:37:58 --> Loader Class Initialized
INFO - 2023-04-20 09:37:58 --> Controller Class Initialized
DEBUG - 2023-04-20 09:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:37:58 --> Database Driver Class Initialized
INFO - 2023-04-20 09:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:37:58 --> Final output sent to browser
DEBUG - 2023-04-20 09:37:58 --> Total execution time: 0.0100
INFO - 2023-04-20 09:38:56 --> Config Class Initialized
INFO - 2023-04-20 09:38:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:56 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:56 --> URI Class Initialized
INFO - 2023-04-20 09:38:56 --> Router Class Initialized
INFO - 2023-04-20 09:38:56 --> Output Class Initialized
INFO - 2023-04-20 09:38:56 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:56 --> Input Class Initialized
INFO - 2023-04-20 09:38:56 --> Language Class Initialized
INFO - 2023-04-20 09:38:56 --> Loader Class Initialized
INFO - 2023-04-20 09:38:56 --> Controller Class Initialized
DEBUG - 2023-04-20 09:38:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:38:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:56 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:38:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:56 --> Model "Login_model" initialized
INFO - 2023-04-20 09:38:56 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:56 --> Total execution time: 0.1031
INFO - 2023-04-20 09:38:56 --> Config Class Initialized
INFO - 2023-04-20 09:38:56 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:38:56 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:38:56 --> Utf8 Class Initialized
INFO - 2023-04-20 09:38:56 --> URI Class Initialized
INFO - 2023-04-20 09:38:56 --> Router Class Initialized
INFO - 2023-04-20 09:38:56 --> Output Class Initialized
INFO - 2023-04-20 09:38:56 --> Security Class Initialized
DEBUG - 2023-04-20 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:38:56 --> Input Class Initialized
INFO - 2023-04-20 09:38:56 --> Language Class Initialized
INFO - 2023-04-20 09:38:56 --> Loader Class Initialized
INFO - 2023-04-20 09:38:56 --> Controller Class Initialized
DEBUG - 2023-04-20 09:38:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:38:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:56 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:38:56 --> Database Driver Class Initialized
INFO - 2023-04-20 09:38:56 --> Model "Login_model" initialized
INFO - 2023-04-20 09:38:56 --> Final output sent to browser
DEBUG - 2023-04-20 09:38:56 --> Total execution time: 0.0611
INFO - 2023-04-20 09:40:35 --> Config Class Initialized
INFO - 2023-04-20 09:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:35 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:35 --> URI Class Initialized
INFO - 2023-04-20 09:40:35 --> Router Class Initialized
INFO - 2023-04-20 09:40:35 --> Output Class Initialized
INFO - 2023-04-20 09:40:35 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:35 --> Input Class Initialized
INFO - 2023-04-20 09:40:35 --> Language Class Initialized
INFO - 2023-04-20 09:40:35 --> Loader Class Initialized
INFO - 2023-04-20 09:40:35 --> Controller Class Initialized
DEBUG - 2023-04-20 09:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:40:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:40:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:35 --> Model "Login_model" initialized
INFO - 2023-04-20 09:40:35 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:35 --> Total execution time: 0.1155
INFO - 2023-04-20 09:40:35 --> Config Class Initialized
INFO - 2023-04-20 09:40:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:40:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:40:35 --> Utf8 Class Initialized
INFO - 2023-04-20 09:40:35 --> URI Class Initialized
INFO - 2023-04-20 09:40:35 --> Router Class Initialized
INFO - 2023-04-20 09:40:35 --> Output Class Initialized
INFO - 2023-04-20 09:40:35 --> Security Class Initialized
DEBUG - 2023-04-20 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:40:35 --> Input Class Initialized
INFO - 2023-04-20 09:40:35 --> Language Class Initialized
INFO - 2023-04-20 09:40:35 --> Loader Class Initialized
INFO - 2023-04-20 09:40:35 --> Controller Class Initialized
DEBUG - 2023-04-20 09:40:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:40:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:40:35 --> Database Driver Class Initialized
INFO - 2023-04-20 09:40:35 --> Model "Login_model" initialized
INFO - 2023-04-20 09:40:35 --> Final output sent to browser
DEBUG - 2023-04-20 09:40:35 --> Total execution time: 0.0860
INFO - 2023-04-20 09:42:03 --> Config Class Initialized
INFO - 2023-04-20 09:42:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:42:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:42:03 --> Utf8 Class Initialized
INFO - 2023-04-20 09:42:03 --> URI Class Initialized
INFO - 2023-04-20 09:42:03 --> Router Class Initialized
INFO - 2023-04-20 09:42:03 --> Output Class Initialized
INFO - 2023-04-20 09:42:03 --> Security Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:42:03 --> Input Class Initialized
INFO - 2023-04-20 09:42:03 --> Language Class Initialized
INFO - 2023-04-20 09:42:03 --> Loader Class Initialized
INFO - 2023-04-20 09:42:03 --> Controller Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:42:03 --> Database Driver Class Initialized
INFO - 2023-04-20 09:42:03 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:42:03 --> Final output sent to browser
DEBUG - 2023-04-20 09:42:03 --> Total execution time: 0.0140
INFO - 2023-04-20 09:42:03 --> Config Class Initialized
INFO - 2023-04-20 09:42:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:42:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:42:03 --> Utf8 Class Initialized
INFO - 2023-04-20 09:42:03 --> URI Class Initialized
INFO - 2023-04-20 09:42:03 --> Router Class Initialized
INFO - 2023-04-20 09:42:03 --> Output Class Initialized
INFO - 2023-04-20 09:42:03 --> Security Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:42:03 --> Input Class Initialized
INFO - 2023-04-20 09:42:03 --> Language Class Initialized
INFO - 2023-04-20 09:42:03 --> Loader Class Initialized
INFO - 2023-04-20 09:42:03 --> Controller Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:42:03 --> Database Driver Class Initialized
INFO - 2023-04-20 09:42:03 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:42:03 --> Final output sent to browser
DEBUG - 2023-04-20 09:42:03 --> Total execution time: 0.0563
INFO - 2023-04-20 09:42:03 --> Config Class Initialized
INFO - 2023-04-20 09:42:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:42:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:42:03 --> Utf8 Class Initialized
INFO - 2023-04-20 09:42:03 --> URI Class Initialized
INFO - 2023-04-20 09:42:03 --> Router Class Initialized
INFO - 2023-04-20 09:42:03 --> Output Class Initialized
INFO - 2023-04-20 09:42:03 --> Security Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:42:03 --> Input Class Initialized
INFO - 2023-04-20 09:42:03 --> Language Class Initialized
INFO - 2023-04-20 09:42:03 --> Loader Class Initialized
INFO - 2023-04-20 09:42:03 --> Controller Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:42:03 --> Database Driver Class Initialized
INFO - 2023-04-20 09:42:03 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:42:03 --> Final output sent to browser
DEBUG - 2023-04-20 09:42:03 --> Total execution time: 0.0541
INFO - 2023-04-20 09:42:03 --> Config Class Initialized
INFO - 2023-04-20 09:42:03 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:42:03 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:42:03 --> Utf8 Class Initialized
INFO - 2023-04-20 09:42:03 --> URI Class Initialized
INFO - 2023-04-20 09:42:03 --> Router Class Initialized
INFO - 2023-04-20 09:42:03 --> Output Class Initialized
INFO - 2023-04-20 09:42:03 --> Security Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:42:03 --> Input Class Initialized
INFO - 2023-04-20 09:42:03 --> Language Class Initialized
INFO - 2023-04-20 09:42:03 --> Loader Class Initialized
INFO - 2023-04-20 09:42:03 --> Controller Class Initialized
DEBUG - 2023-04-20 09:42:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:42:03 --> Database Driver Class Initialized
INFO - 2023-04-20 09:42:03 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:42:03 --> Final output sent to browser
DEBUG - 2023-04-20 09:42:03 --> Total execution time: 0.0131
INFO - 2023-04-20 09:43:16 --> Config Class Initialized
INFO - 2023-04-20 09:43:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:16 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:16 --> URI Class Initialized
INFO - 2023-04-20 09:43:16 --> Router Class Initialized
INFO - 2023-04-20 09:43:16 --> Output Class Initialized
INFO - 2023-04-20 09:43:16 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:16 --> Input Class Initialized
INFO - 2023-04-20 09:43:16 --> Language Class Initialized
INFO - 2023-04-20 09:43:16 --> Loader Class Initialized
INFO - 2023-04-20 09:43:16 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:16 --> Model "Login_model" initialized
INFO - 2023-04-20 09:43:16 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:16 --> Total execution time: 0.1048
INFO - 2023-04-20 09:43:16 --> Config Class Initialized
INFO - 2023-04-20 09:43:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:16 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:16 --> URI Class Initialized
INFO - 2023-04-20 09:43:16 --> Router Class Initialized
INFO - 2023-04-20 09:43:16 --> Output Class Initialized
INFO - 2023-04-20 09:43:16 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:16 --> Input Class Initialized
INFO - 2023-04-20 09:43:16 --> Language Class Initialized
INFO - 2023-04-20 09:43:16 --> Loader Class Initialized
INFO - 2023-04-20 09:43:16 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:16 --> Model "Login_model" initialized
INFO - 2023-04-20 09:43:16 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:16 --> Total execution time: 0.0973
INFO - 2023-04-20 09:43:18 --> Config Class Initialized
INFO - 2023-04-20 09:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:18 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:18 --> URI Class Initialized
INFO - 2023-04-20 09:43:18 --> Router Class Initialized
INFO - 2023-04-20 09:43:18 --> Output Class Initialized
INFO - 2023-04-20 09:43:18 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:18 --> Input Class Initialized
INFO - 2023-04-20 09:43:18 --> Language Class Initialized
INFO - 2023-04-20 09:43:18 --> Loader Class Initialized
INFO - 2023-04-20 09:43:18 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:18 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:18 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:18 --> Total execution time: 0.0144
INFO - 2023-04-20 09:43:18 --> Config Class Initialized
INFO - 2023-04-20 09:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:18 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:18 --> URI Class Initialized
INFO - 2023-04-20 09:43:18 --> Router Class Initialized
INFO - 2023-04-20 09:43:18 --> Output Class Initialized
INFO - 2023-04-20 09:43:18 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:18 --> Input Class Initialized
INFO - 2023-04-20 09:43:18 --> Language Class Initialized
INFO - 2023-04-20 09:43:18 --> Loader Class Initialized
INFO - 2023-04-20 09:43:18 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:18 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:18 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:18 --> Total execution time: 0.1105
INFO - 2023-04-20 09:43:18 --> Config Class Initialized
INFO - 2023-04-20 09:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:18 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:18 --> URI Class Initialized
INFO - 2023-04-20 09:43:18 --> Router Class Initialized
INFO - 2023-04-20 09:43:18 --> Output Class Initialized
INFO - 2023-04-20 09:43:18 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:18 --> Input Class Initialized
INFO - 2023-04-20 09:43:18 --> Language Class Initialized
INFO - 2023-04-20 09:43:18 --> Loader Class Initialized
INFO - 2023-04-20 09:43:18 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:18 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:18 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:18 --> Total execution time: 0.0534
INFO - 2023-04-20 09:43:18 --> Config Class Initialized
INFO - 2023-04-20 09:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:43:18 --> Utf8 Class Initialized
INFO - 2023-04-20 09:43:18 --> URI Class Initialized
INFO - 2023-04-20 09:43:18 --> Router Class Initialized
INFO - 2023-04-20 09:43:18 --> Output Class Initialized
INFO - 2023-04-20 09:43:18 --> Security Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:43:18 --> Input Class Initialized
INFO - 2023-04-20 09:43:18 --> Language Class Initialized
INFO - 2023-04-20 09:43:18 --> Loader Class Initialized
INFO - 2023-04-20 09:43:18 --> Controller Class Initialized
DEBUG - 2023-04-20 09:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:43:18 --> Database Driver Class Initialized
INFO - 2023-04-20 09:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:43:18 --> Final output sent to browser
DEBUG - 2023-04-20 09:43:18 --> Total execution time: 0.0525
INFO - 2023-04-20 09:44:19 --> Config Class Initialized
INFO - 2023-04-20 09:44:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:19 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:19 --> URI Class Initialized
INFO - 2023-04-20 09:44:19 --> Router Class Initialized
INFO - 2023-04-20 09:44:19 --> Output Class Initialized
INFO - 2023-04-20 09:44:19 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:19 --> Input Class Initialized
INFO - 2023-04-20 09:44:19 --> Language Class Initialized
INFO - 2023-04-20 09:44:19 --> Loader Class Initialized
INFO - 2023-04-20 09:44:19 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:19 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:19 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:19 --> Model "Login_model" initialized
INFO - 2023-04-20 09:44:20 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:20 --> Total execution time: 0.2920
INFO - 2023-04-20 09:44:20 --> Config Class Initialized
INFO - 2023-04-20 09:44:20 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:20 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:20 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:20 --> URI Class Initialized
INFO - 2023-04-20 09:44:20 --> Router Class Initialized
INFO - 2023-04-20 09:44:20 --> Output Class Initialized
INFO - 2023-04-20 09:44:20 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:20 --> Input Class Initialized
INFO - 2023-04-20 09:44:20 --> Language Class Initialized
INFO - 2023-04-20 09:44:20 --> Loader Class Initialized
INFO - 2023-04-20 09:44:20 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:20 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:20 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:20 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:20 --> Model "Login_model" initialized
INFO - 2023-04-20 09:44:20 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:20 --> Total execution time: 0.1029
INFO - 2023-04-20 09:44:24 --> Config Class Initialized
INFO - 2023-04-20 09:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:24 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:24 --> URI Class Initialized
INFO - 2023-04-20 09:44:24 --> Router Class Initialized
INFO - 2023-04-20 09:44:24 --> Output Class Initialized
INFO - 2023-04-20 09:44:24 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:24 --> Input Class Initialized
INFO - 2023-04-20 09:44:24 --> Language Class Initialized
INFO - 2023-04-20 09:44:24 --> Loader Class Initialized
INFO - 2023-04-20 09:44:24 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:24 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:24 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:24 --> Model "Login_model" initialized
INFO - 2023-04-20 09:44:24 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:24 --> Total execution time: 0.1315
INFO - 2023-04-20 09:44:29 --> Config Class Initialized
INFO - 2023-04-20 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:29 --> URI Class Initialized
INFO - 2023-04-20 09:44:29 --> Router Class Initialized
INFO - 2023-04-20 09:44:29 --> Output Class Initialized
INFO - 2023-04-20 09:44:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:29 --> Input Class Initialized
INFO - 2023-04-20 09:44:29 --> Language Class Initialized
INFO - 2023-04-20 09:44:29 --> Loader Class Initialized
INFO - 2023-04-20 09:44:29 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:29 --> Total execution time: 0.0126
INFO - 2023-04-20 09:44:29 --> Config Class Initialized
INFO - 2023-04-20 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:29 --> URI Class Initialized
INFO - 2023-04-20 09:44:29 --> Router Class Initialized
INFO - 2023-04-20 09:44:29 --> Output Class Initialized
INFO - 2023-04-20 09:44:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:29 --> Input Class Initialized
INFO - 2023-04-20 09:44:29 --> Language Class Initialized
INFO - 2023-04-20 09:44:29 --> Loader Class Initialized
INFO - 2023-04-20 09:44:29 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:29 --> Total execution time: 0.0516
INFO - 2023-04-20 09:44:29 --> Config Class Initialized
INFO - 2023-04-20 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:29 --> URI Class Initialized
INFO - 2023-04-20 09:44:29 --> Router Class Initialized
INFO - 2023-04-20 09:44:29 --> Output Class Initialized
INFO - 2023-04-20 09:44:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:29 --> Input Class Initialized
INFO - 2023-04-20 09:44:29 --> Language Class Initialized
INFO - 2023-04-20 09:44:29 --> Loader Class Initialized
INFO - 2023-04-20 09:44:29 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:29 --> Total execution time: 0.0501
INFO - 2023-04-20 09:44:29 --> Config Class Initialized
INFO - 2023-04-20 09:44:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:44:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:44:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:44:29 --> URI Class Initialized
INFO - 2023-04-20 09:44:29 --> Router Class Initialized
INFO - 2023-04-20 09:44:29 --> Output Class Initialized
INFO - 2023-04-20 09:44:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:44:29 --> Input Class Initialized
INFO - 2023-04-20 09:44:29 --> Language Class Initialized
INFO - 2023-04-20 09:44:29 --> Loader Class Initialized
INFO - 2023-04-20 09:44:29 --> Controller Class Initialized
DEBUG - 2023-04-20 09:44:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:44:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:44:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:44:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:44:29 --> Total execution time: 0.0131
INFO - 2023-04-20 09:47:08 --> Config Class Initialized
INFO - 2023-04-20 09:47:08 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:08 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:08 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:08 --> URI Class Initialized
INFO - 2023-04-20 09:47:08 --> Router Class Initialized
INFO - 2023-04-20 09:47:08 --> Output Class Initialized
INFO - 2023-04-20 09:47:08 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:08 --> Input Class Initialized
INFO - 2023-04-20 09:47:08 --> Language Class Initialized
INFO - 2023-04-20 09:47:08 --> Loader Class Initialized
INFO - 2023-04-20 09:47:08 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:47:08 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:08 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:47:08 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:08 --> Model "Login_model" initialized
INFO - 2023-04-20 09:47:08 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:08 --> Total execution time: 0.1088
INFO - 2023-04-20 09:47:08 --> Config Class Initialized
INFO - 2023-04-20 09:47:08 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:08 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:08 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:08 --> URI Class Initialized
INFO - 2023-04-20 09:47:08 --> Router Class Initialized
INFO - 2023-04-20 09:47:08 --> Output Class Initialized
INFO - 2023-04-20 09:47:08 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:08 --> Input Class Initialized
INFO - 2023-04-20 09:47:08 --> Language Class Initialized
INFO - 2023-04-20 09:47:08 --> Loader Class Initialized
INFO - 2023-04-20 09:47:08 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:47:08 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:08 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:47:08 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:08 --> Model "Login_model" initialized
INFO - 2023-04-20 09:47:08 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:08 --> Total execution time: 0.0642
INFO - 2023-04-20 09:47:15 --> Config Class Initialized
INFO - 2023-04-20 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:15 --> URI Class Initialized
INFO - 2023-04-20 09:47:15 --> Router Class Initialized
INFO - 2023-04-20 09:47:15 --> Output Class Initialized
INFO - 2023-04-20 09:47:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:15 --> Input Class Initialized
INFO - 2023-04-20 09:47:15 --> Language Class Initialized
INFO - 2023-04-20 09:47:15 --> Loader Class Initialized
INFO - 2023-04-20 09:47:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:47:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:47:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:15 --> Model "Login_model" initialized
INFO - 2023-04-20 09:47:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:15 --> Total execution time: 0.1012
INFO - 2023-04-20 09:47:15 --> Config Class Initialized
INFO - 2023-04-20 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:47:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:47:15 --> URI Class Initialized
INFO - 2023-04-20 09:47:15 --> Router Class Initialized
INFO - 2023-04-20 09:47:15 --> Output Class Initialized
INFO - 2023-04-20 09:47:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:47:15 --> Input Class Initialized
INFO - 2023-04-20 09:47:15 --> Language Class Initialized
INFO - 2023-04-20 09:47:15 --> Loader Class Initialized
INFO - 2023-04-20 09:47:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:47:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:47:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:47:15 --> Model "Login_model" initialized
INFO - 2023-04-20 09:47:15 --> Final output sent to browser
DEBUG - 2023-04-20 09:47:15 --> Total execution time: 0.0570
INFO - 2023-04-20 09:48:05 --> Config Class Initialized
INFO - 2023-04-20 09:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:05 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:05 --> URI Class Initialized
INFO - 2023-04-20 09:48:05 --> Router Class Initialized
INFO - 2023-04-20 09:48:05 --> Output Class Initialized
INFO - 2023-04-20 09:48:05 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:05 --> Input Class Initialized
INFO - 2023-04-20 09:48:05 --> Language Class Initialized
INFO - 2023-04-20 09:48:05 --> Loader Class Initialized
INFO - 2023-04-20 09:48:05 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:48:05 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:48:05 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:05 --> Total execution time: 0.0119
INFO - 2023-04-20 09:48:05 --> Config Class Initialized
INFO - 2023-04-20 09:48:05 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:05 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:05 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:05 --> URI Class Initialized
INFO - 2023-04-20 09:48:05 --> Router Class Initialized
INFO - 2023-04-20 09:48:05 --> Output Class Initialized
INFO - 2023-04-20 09:48:05 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:05 --> Input Class Initialized
INFO - 2023-04-20 09:48:05 --> Language Class Initialized
INFO - 2023-04-20 09:48:05 --> Loader Class Initialized
INFO - 2023-04-20 09:48:05 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:48:05 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:05 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:48:05 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:05 --> Total execution time: 0.0131
INFO - 2023-04-20 09:48:05 --> Config Class Initialized
INFO - 2023-04-20 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:06 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:06 --> URI Class Initialized
INFO - 2023-04-20 09:48:06 --> Router Class Initialized
INFO - 2023-04-20 09:48:06 --> Output Class Initialized
INFO - 2023-04-20 09:48:06 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:06 --> Input Class Initialized
INFO - 2023-04-20 09:48:06 --> Language Class Initialized
INFO - 2023-04-20 09:48:06 --> Loader Class Initialized
INFO - 2023-04-20 09:48:06 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:48:06 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:06 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:48:06 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:06 --> Total execution time: 0.0507
INFO - 2023-04-20 09:48:06 --> Config Class Initialized
INFO - 2023-04-20 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:48:06 --> Utf8 Class Initialized
INFO - 2023-04-20 09:48:06 --> URI Class Initialized
INFO - 2023-04-20 09:48:06 --> Router Class Initialized
INFO - 2023-04-20 09:48:06 --> Output Class Initialized
INFO - 2023-04-20 09:48:06 --> Security Class Initialized
DEBUG - 2023-04-20 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:48:06 --> Input Class Initialized
INFO - 2023-04-20 09:48:06 --> Language Class Initialized
INFO - 2023-04-20 09:48:06 --> Loader Class Initialized
INFO - 2023-04-20 09:48:06 --> Controller Class Initialized
DEBUG - 2023-04-20 09:48:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:48:06 --> Database Driver Class Initialized
INFO - 2023-04-20 09:48:06 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:48:06 --> Final output sent to browser
DEBUG - 2023-04-20 09:48:06 --> Total execution time: 0.0110
INFO - 2023-04-20 09:51:21 --> Config Class Initialized
INFO - 2023-04-20 09:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:22 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:22 --> URI Class Initialized
INFO - 2023-04-20 09:51:22 --> Router Class Initialized
INFO - 2023-04-20 09:51:22 --> Output Class Initialized
INFO - 2023-04-20 09:51:22 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:22 --> Input Class Initialized
INFO - 2023-04-20 09:51:22 --> Language Class Initialized
INFO - 2023-04-20 09:51:22 --> Loader Class Initialized
INFO - 2023-04-20 09:51:22 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:22 --> Model "Login_model" initialized
INFO - 2023-04-20 09:51:22 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:22 --> Total execution time: 0.1561
INFO - 2023-04-20 09:51:22 --> Config Class Initialized
INFO - 2023-04-20 09:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:22 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:22 --> URI Class Initialized
INFO - 2023-04-20 09:51:22 --> Router Class Initialized
INFO - 2023-04-20 09:51:22 --> Output Class Initialized
INFO - 2023-04-20 09:51:22 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:22 --> Input Class Initialized
INFO - 2023-04-20 09:51:22 --> Language Class Initialized
INFO - 2023-04-20 09:51:22 --> Loader Class Initialized
INFO - 2023-04-20 09:51:22 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:22 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:22 --> Model "Login_model" initialized
INFO - 2023-04-20 09:51:22 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:22 --> Total execution time: 0.0709
INFO - 2023-04-20 09:51:27 --> Config Class Initialized
INFO - 2023-04-20 09:51:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:27 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:27 --> URI Class Initialized
INFO - 2023-04-20 09:51:27 --> Router Class Initialized
INFO - 2023-04-20 09:51:27 --> Output Class Initialized
INFO - 2023-04-20 09:51:27 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:27 --> Input Class Initialized
INFO - 2023-04-20 09:51:27 --> Language Class Initialized
INFO - 2023-04-20 09:51:27 --> Loader Class Initialized
INFO - 2023-04-20 09:51:27 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:27 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:27 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:27 --> Total execution time: 0.0124
INFO - 2023-04-20 09:51:27 --> Config Class Initialized
INFO - 2023-04-20 09:51:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:27 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:27 --> URI Class Initialized
INFO - 2023-04-20 09:51:27 --> Router Class Initialized
INFO - 2023-04-20 09:51:27 --> Output Class Initialized
INFO - 2023-04-20 09:51:27 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:27 --> Input Class Initialized
INFO - 2023-04-20 09:51:27 --> Language Class Initialized
INFO - 2023-04-20 09:51:27 --> Loader Class Initialized
INFO - 2023-04-20 09:51:27 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:27 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:27 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:27 --> Total execution time: 0.0116
INFO - 2023-04-20 09:51:27 --> Config Class Initialized
INFO - 2023-04-20 09:51:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:27 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:27 --> URI Class Initialized
INFO - 2023-04-20 09:51:27 --> Router Class Initialized
INFO - 2023-04-20 09:51:27 --> Output Class Initialized
INFO - 2023-04-20 09:51:27 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:27 --> Input Class Initialized
INFO - 2023-04-20 09:51:27 --> Language Class Initialized
INFO - 2023-04-20 09:51:27 --> Loader Class Initialized
INFO - 2023-04-20 09:51:27 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:27 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:27 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:27 --> Total execution time: 0.0560
INFO - 2023-04-20 09:51:27 --> Config Class Initialized
INFO - 2023-04-20 09:51:27 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:51:27 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:51:27 --> Utf8 Class Initialized
INFO - 2023-04-20 09:51:27 --> URI Class Initialized
INFO - 2023-04-20 09:51:27 --> Router Class Initialized
INFO - 2023-04-20 09:51:27 --> Output Class Initialized
INFO - 2023-04-20 09:51:27 --> Security Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:51:27 --> Input Class Initialized
INFO - 2023-04-20 09:51:27 --> Language Class Initialized
INFO - 2023-04-20 09:51:27 --> Loader Class Initialized
INFO - 2023-04-20 09:51:27 --> Controller Class Initialized
DEBUG - 2023-04-20 09:51:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:51:27 --> Database Driver Class Initialized
INFO - 2023-04-20 09:51:27 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:51:27 --> Final output sent to browser
DEBUG - 2023-04-20 09:51:27 --> Total execution time: 0.0113
INFO - 2023-04-20 09:56:15 --> Config Class Initialized
INFO - 2023-04-20 09:56:15 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:15 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:15 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:15 --> URI Class Initialized
INFO - 2023-04-20 09:56:15 --> Router Class Initialized
INFO - 2023-04-20 09:56:15 --> Output Class Initialized
INFO - 2023-04-20 09:56:15 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:15 --> Input Class Initialized
INFO - 2023-04-20 09:56:15 --> Language Class Initialized
INFO - 2023-04-20 09:56:15 --> Loader Class Initialized
INFO - 2023-04-20 09:56:15 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:15 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:15 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:15 --> Model "Login_model" initialized
INFO - 2023-04-20 09:56:16 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:16 --> Total execution time: 0.1349
INFO - 2023-04-20 09:56:16 --> Config Class Initialized
INFO - 2023-04-20 09:56:16 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:16 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:16 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:16 --> URI Class Initialized
INFO - 2023-04-20 09:56:16 --> Router Class Initialized
INFO - 2023-04-20 09:56:16 --> Output Class Initialized
INFO - 2023-04-20 09:56:16 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:16 --> Input Class Initialized
INFO - 2023-04-20 09:56:16 --> Language Class Initialized
INFO - 2023-04-20 09:56:16 --> Loader Class Initialized
INFO - 2023-04-20 09:56:16 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:16 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:16 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:16 --> Model "Login_model" initialized
INFO - 2023-04-20 09:56:16 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:16 --> Total execution time: 0.1062
INFO - 2023-04-20 09:56:28 --> Config Class Initialized
INFO - 2023-04-20 09:56:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:28 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:28 --> URI Class Initialized
INFO - 2023-04-20 09:56:28 --> Router Class Initialized
INFO - 2023-04-20 09:56:28 --> Output Class Initialized
INFO - 2023-04-20 09:56:28 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:28 --> Input Class Initialized
INFO - 2023-04-20 09:56:28 --> Language Class Initialized
INFO - 2023-04-20 09:56:28 --> Loader Class Initialized
INFO - 2023-04-20 09:56:28 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:28 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:28 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:28 --> Total execution time: 0.0146
INFO - 2023-04-20 09:56:28 --> Config Class Initialized
INFO - 2023-04-20 09:56:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:28 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:28 --> URI Class Initialized
INFO - 2023-04-20 09:56:28 --> Router Class Initialized
INFO - 2023-04-20 09:56:28 --> Output Class Initialized
INFO - 2023-04-20 09:56:28 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:28 --> Input Class Initialized
INFO - 2023-04-20 09:56:28 --> Language Class Initialized
INFO - 2023-04-20 09:56:28 --> Loader Class Initialized
INFO - 2023-04-20 09:56:28 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:28 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:28 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:28 --> Total execution time: 0.0545
INFO - 2023-04-20 09:56:28 --> Config Class Initialized
INFO - 2023-04-20 09:56:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:28 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:28 --> URI Class Initialized
INFO - 2023-04-20 09:56:28 --> Router Class Initialized
INFO - 2023-04-20 09:56:28 --> Output Class Initialized
INFO - 2023-04-20 09:56:28 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:28 --> Input Class Initialized
INFO - 2023-04-20 09:56:28 --> Language Class Initialized
INFO - 2023-04-20 09:56:28 --> Loader Class Initialized
INFO - 2023-04-20 09:56:28 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:28 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:28 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:28 --> Total execution time: 0.0516
INFO - 2023-04-20 09:56:28 --> Config Class Initialized
INFO - 2023-04-20 09:56:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:56:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:56:29 --> Utf8 Class Initialized
INFO - 2023-04-20 09:56:29 --> URI Class Initialized
INFO - 2023-04-20 09:56:29 --> Router Class Initialized
INFO - 2023-04-20 09:56:29 --> Output Class Initialized
INFO - 2023-04-20 09:56:29 --> Security Class Initialized
DEBUG - 2023-04-20 09:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:56:29 --> Input Class Initialized
INFO - 2023-04-20 09:56:29 --> Language Class Initialized
INFO - 2023-04-20 09:56:29 --> Loader Class Initialized
INFO - 2023-04-20 09:56:29 --> Controller Class Initialized
DEBUG - 2023-04-20 09:56:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:56:29 --> Database Driver Class Initialized
INFO - 2023-04-20 09:56:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:56:29 --> Final output sent to browser
DEBUG - 2023-04-20 09:56:29 --> Total execution time: 0.0509
INFO - 2023-04-20 09:57:42 --> Config Class Initialized
INFO - 2023-04-20 09:57:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:42 --> URI Class Initialized
INFO - 2023-04-20 09:57:42 --> Router Class Initialized
INFO - 2023-04-20 09:57:42 --> Output Class Initialized
INFO - 2023-04-20 09:57:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:42 --> Input Class Initialized
INFO - 2023-04-20 09:57:42 --> Language Class Initialized
INFO - 2023-04-20 09:57:42 --> Loader Class Initialized
INFO - 2023-04-20 09:57:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:42 --> Model "Login_model" initialized
INFO - 2023-04-20 09:57:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:42 --> Total execution time: 0.1126
INFO - 2023-04-20 09:57:42 --> Config Class Initialized
INFO - 2023-04-20 09:57:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:42 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:42 --> URI Class Initialized
INFO - 2023-04-20 09:57:42 --> Router Class Initialized
INFO - 2023-04-20 09:57:42 --> Output Class Initialized
INFO - 2023-04-20 09:57:42 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:42 --> Input Class Initialized
INFO - 2023-04-20 09:57:42 --> Language Class Initialized
INFO - 2023-04-20 09:57:42 --> Loader Class Initialized
INFO - 2023-04-20 09:57:42 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:42 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:42 --> Model "Login_model" initialized
INFO - 2023-04-20 09:57:42 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:42 --> Total execution time: 0.0682
INFO - 2023-04-20 09:57:54 --> Config Class Initialized
INFO - 2023-04-20 09:57:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:54 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:54 --> URI Class Initialized
INFO - 2023-04-20 09:57:54 --> Router Class Initialized
INFO - 2023-04-20 09:57:54 --> Output Class Initialized
INFO - 2023-04-20 09:57:54 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:54 --> Input Class Initialized
INFO - 2023-04-20 09:57:54 --> Language Class Initialized
INFO - 2023-04-20 09:57:54 --> Loader Class Initialized
INFO - 2023-04-20 09:57:54 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:54 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:54 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:54 --> Total execution time: 0.0229
INFO - 2023-04-20 09:57:54 --> Config Class Initialized
INFO - 2023-04-20 09:57:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:54 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:54 --> URI Class Initialized
INFO - 2023-04-20 09:57:54 --> Router Class Initialized
INFO - 2023-04-20 09:57:54 --> Output Class Initialized
INFO - 2023-04-20 09:57:54 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:54 --> Input Class Initialized
INFO - 2023-04-20 09:57:54 --> Language Class Initialized
INFO - 2023-04-20 09:57:54 --> Loader Class Initialized
INFO - 2023-04-20 09:57:54 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:54 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:54 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:54 --> Total execution time: 0.0129
INFO - 2023-04-20 09:57:54 --> Config Class Initialized
INFO - 2023-04-20 09:57:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:54 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:54 --> URI Class Initialized
INFO - 2023-04-20 09:57:54 --> Router Class Initialized
INFO - 2023-04-20 09:57:54 --> Output Class Initialized
INFO - 2023-04-20 09:57:54 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:54 --> Input Class Initialized
INFO - 2023-04-20 09:57:54 --> Language Class Initialized
INFO - 2023-04-20 09:57:54 --> Loader Class Initialized
INFO - 2023-04-20 09:57:54 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:54 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:54 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:54 --> Total execution time: 0.0492
INFO - 2023-04-20 09:57:54 --> Config Class Initialized
INFO - 2023-04-20 09:57:54 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:57:54 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:57:54 --> Utf8 Class Initialized
INFO - 2023-04-20 09:57:54 --> URI Class Initialized
INFO - 2023-04-20 09:57:54 --> Router Class Initialized
INFO - 2023-04-20 09:57:54 --> Output Class Initialized
INFO - 2023-04-20 09:57:54 --> Security Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:57:54 --> Input Class Initialized
INFO - 2023-04-20 09:57:54 --> Language Class Initialized
INFO - 2023-04-20 09:57:54 --> Loader Class Initialized
INFO - 2023-04-20 09:57:54 --> Controller Class Initialized
DEBUG - 2023-04-20 09:57:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:57:54 --> Database Driver Class Initialized
INFO - 2023-04-20 09:57:54 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:57:54 --> Final output sent to browser
DEBUG - 2023-04-20 09:57:54 --> Total execution time: 0.0171
INFO - 2023-04-20 09:58:51 --> Config Class Initialized
INFO - 2023-04-20 09:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:58:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:58:51 --> URI Class Initialized
INFO - 2023-04-20 09:58:51 --> Router Class Initialized
INFO - 2023-04-20 09:58:51 --> Output Class Initialized
INFO - 2023-04-20 09:58:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:58:51 --> Input Class Initialized
INFO - 2023-04-20 09:58:51 --> Language Class Initialized
INFO - 2023-04-20 09:58:51 --> Loader Class Initialized
INFO - 2023-04-20 09:58:51 --> Controller Class Initialized
DEBUG - 2023-04-20 09:58:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:58:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:58:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:58:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:58:51 --> Model "Login_model" initialized
INFO - 2023-04-20 09:58:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:58:51 --> Total execution time: 0.1064
INFO - 2023-04-20 09:58:51 --> Config Class Initialized
INFO - 2023-04-20 09:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:58:51 --> Utf8 Class Initialized
INFO - 2023-04-20 09:58:51 --> URI Class Initialized
INFO - 2023-04-20 09:58:51 --> Router Class Initialized
INFO - 2023-04-20 09:58:51 --> Output Class Initialized
INFO - 2023-04-20 09:58:51 --> Security Class Initialized
DEBUG - 2023-04-20 09:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:58:51 --> Input Class Initialized
INFO - 2023-04-20 09:58:51 --> Language Class Initialized
INFO - 2023-04-20 09:58:51 --> Loader Class Initialized
INFO - 2023-04-20 09:58:51 --> Controller Class Initialized
DEBUG - 2023-04-20 09:58:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:58:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:58:51 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:58:51 --> Database Driver Class Initialized
INFO - 2023-04-20 09:58:51 --> Model "Login_model" initialized
INFO - 2023-04-20 09:58:51 --> Final output sent to browser
DEBUG - 2023-04-20 09:58:51 --> Total execution time: 0.0682
INFO - 2023-04-20 09:59:12 --> Config Class Initialized
INFO - 2023-04-20 09:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:12 --> URI Class Initialized
INFO - 2023-04-20 09:59:12 --> Router Class Initialized
INFO - 2023-04-20 09:59:12 --> Output Class Initialized
INFO - 2023-04-20 09:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:12 --> Input Class Initialized
INFO - 2023-04-20 09:59:12 --> Language Class Initialized
INFO - 2023-04-20 09:59:12 --> Loader Class Initialized
INFO - 2023-04-20 09:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:12 --> Model "Login_model" initialized
INFO - 2023-04-20 09:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:12 --> Total execution time: 0.1157
INFO - 2023-04-20 09:59:12 --> Config Class Initialized
INFO - 2023-04-20 09:59:12 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:12 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:12 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:12 --> URI Class Initialized
INFO - 2023-04-20 09:59:12 --> Router Class Initialized
INFO - 2023-04-20 09:59:12 --> Output Class Initialized
INFO - 2023-04-20 09:59:12 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:12 --> Input Class Initialized
INFO - 2023-04-20 09:59:12 --> Language Class Initialized
INFO - 2023-04-20 09:59:12 --> Loader Class Initialized
INFO - 2023-04-20 09:59:12 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:12 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:12 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:12 --> Model "Login_model" initialized
INFO - 2023-04-20 09:59:12 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:12 --> Total execution time: 0.0758
INFO - 2023-04-20 09:59:14 --> Config Class Initialized
INFO - 2023-04-20 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:14 --> URI Class Initialized
INFO - 2023-04-20 09:59:14 --> Router Class Initialized
INFO - 2023-04-20 09:59:14 --> Output Class Initialized
INFO - 2023-04-20 09:59:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:14 --> Input Class Initialized
INFO - 2023-04-20 09:59:14 --> Language Class Initialized
INFO - 2023-04-20 09:59:14 --> Loader Class Initialized
INFO - 2023-04-20 09:59:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:14 --> Total execution time: 0.0230
INFO - 2023-04-20 09:59:14 --> Config Class Initialized
INFO - 2023-04-20 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:14 --> URI Class Initialized
INFO - 2023-04-20 09:59:14 --> Router Class Initialized
INFO - 2023-04-20 09:59:14 --> Output Class Initialized
INFO - 2023-04-20 09:59:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:14 --> Input Class Initialized
INFO - 2023-04-20 09:59:14 --> Language Class Initialized
INFO - 2023-04-20 09:59:14 --> Loader Class Initialized
INFO - 2023-04-20 09:59:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:14 --> Total execution time: 0.0396
INFO - 2023-04-20 09:59:14 --> Config Class Initialized
INFO - 2023-04-20 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:14 --> URI Class Initialized
INFO - 2023-04-20 09:59:14 --> Router Class Initialized
INFO - 2023-04-20 09:59:14 --> Output Class Initialized
INFO - 2023-04-20 09:59:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:14 --> Input Class Initialized
INFO - 2023-04-20 09:59:14 --> Language Class Initialized
INFO - 2023-04-20 09:59:14 --> Loader Class Initialized
INFO - 2023-04-20 09:59:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:14 --> Total execution time: 0.0550
INFO - 2023-04-20 09:59:14 --> Config Class Initialized
INFO - 2023-04-20 09:59:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 09:59:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 09:59:14 --> Utf8 Class Initialized
INFO - 2023-04-20 09:59:14 --> URI Class Initialized
INFO - 2023-04-20 09:59:14 --> Router Class Initialized
INFO - 2023-04-20 09:59:14 --> Output Class Initialized
INFO - 2023-04-20 09:59:14 --> Security Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 09:59:14 --> Input Class Initialized
INFO - 2023-04-20 09:59:14 --> Language Class Initialized
INFO - 2023-04-20 09:59:14 --> Loader Class Initialized
INFO - 2023-04-20 09:59:14 --> Controller Class Initialized
DEBUG - 2023-04-20 09:59:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 09:59:14 --> Database Driver Class Initialized
INFO - 2023-04-20 09:59:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 09:59:14 --> Final output sent to browser
DEBUG - 2023-04-20 09:59:14 --> Total execution time: 0.0101
INFO - 2023-04-20 10:00:58 --> Config Class Initialized
INFO - 2023-04-20 10:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 10:00:58 --> URI Class Initialized
INFO - 2023-04-20 10:00:58 --> Router Class Initialized
INFO - 2023-04-20 10:00:58 --> Output Class Initialized
INFO - 2023-04-20 10:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:00:58 --> Input Class Initialized
INFO - 2023-04-20 10:00:58 --> Language Class Initialized
INFO - 2023-04-20 10:00:58 --> Loader Class Initialized
INFO - 2023-04-20 10:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 10:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 10:00:58 --> Total execution time: 0.0114
INFO - 2023-04-20 10:00:58 --> Config Class Initialized
INFO - 2023-04-20 10:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 10:00:58 --> URI Class Initialized
INFO - 2023-04-20 10:00:58 --> Router Class Initialized
INFO - 2023-04-20 10:00:58 --> Output Class Initialized
INFO - 2023-04-20 10:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:00:58 --> Input Class Initialized
INFO - 2023-04-20 10:00:58 --> Language Class Initialized
INFO - 2023-04-20 10:00:58 --> Loader Class Initialized
INFO - 2023-04-20 10:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 10:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 10:00:58 --> Total execution time: 0.0124
INFO - 2023-04-20 10:00:58 --> Config Class Initialized
INFO - 2023-04-20 10:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 10:00:58 --> URI Class Initialized
INFO - 2023-04-20 10:00:58 --> Router Class Initialized
INFO - 2023-04-20 10:00:58 --> Output Class Initialized
INFO - 2023-04-20 10:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:00:58 --> Input Class Initialized
INFO - 2023-04-20 10:00:58 --> Language Class Initialized
INFO - 2023-04-20 10:00:58 --> Loader Class Initialized
INFO - 2023-04-20 10:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 10:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 10:00:58 --> Total execution time: 0.0099
INFO - 2023-04-20 10:00:58 --> Config Class Initialized
INFO - 2023-04-20 10:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:00:58 --> Utf8 Class Initialized
INFO - 2023-04-20 10:00:58 --> URI Class Initialized
INFO - 2023-04-20 10:00:58 --> Router Class Initialized
INFO - 2023-04-20 10:00:58 --> Output Class Initialized
INFO - 2023-04-20 10:00:58 --> Security Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:00:58 --> Input Class Initialized
INFO - 2023-04-20 10:00:58 --> Language Class Initialized
INFO - 2023-04-20 10:00:58 --> Loader Class Initialized
INFO - 2023-04-20 10:00:58 --> Controller Class Initialized
DEBUG - 2023-04-20 10:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:00:58 --> Database Driver Class Initialized
INFO - 2023-04-20 10:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:00:58 --> Final output sent to browser
DEBUG - 2023-04-20 10:00:58 --> Total execution time: 0.0103
INFO - 2023-04-20 10:04:38 --> Config Class Initialized
INFO - 2023-04-20 10:04:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:04:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:04:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:04:38 --> URI Class Initialized
INFO - 2023-04-20 10:04:38 --> Router Class Initialized
INFO - 2023-04-20 10:04:38 --> Output Class Initialized
INFO - 2023-04-20 10:04:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:04:38 --> Input Class Initialized
INFO - 2023-04-20 10:04:38 --> Language Class Initialized
INFO - 2023-04-20 10:04:38 --> Loader Class Initialized
INFO - 2023-04-20 10:04:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:04:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:04:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:04:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:04:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:04:38 --> Model "Login_model" initialized
INFO - 2023-04-20 10:04:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:04:38 --> Total execution time: 0.0726
INFO - 2023-04-20 10:04:38 --> Config Class Initialized
INFO - 2023-04-20 10:04:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:04:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:04:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:04:38 --> URI Class Initialized
INFO - 2023-04-20 10:04:38 --> Router Class Initialized
INFO - 2023-04-20 10:04:38 --> Output Class Initialized
INFO - 2023-04-20 10:04:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:04:38 --> Input Class Initialized
INFO - 2023-04-20 10:04:38 --> Language Class Initialized
INFO - 2023-04-20 10:04:38 --> Loader Class Initialized
INFO - 2023-04-20 10:04:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:04:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:04:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:04:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:04:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:04:38 --> Model "Login_model" initialized
INFO - 2023-04-20 10:04:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:04:38 --> Total execution time: 0.0727
INFO - 2023-04-20 10:05:14 --> Config Class Initialized
INFO - 2023-04-20 10:05:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:05:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:05:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:05:14 --> URI Class Initialized
INFO - 2023-04-20 10:05:14 --> Router Class Initialized
INFO - 2023-04-20 10:05:14 --> Output Class Initialized
INFO - 2023-04-20 10:05:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:05:14 --> Input Class Initialized
INFO - 2023-04-20 10:05:14 --> Language Class Initialized
INFO - 2023-04-20 10:05:14 --> Loader Class Initialized
INFO - 2023-04-20 10:05:14 --> Controller Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:05:14 --> Database Driver Class Initialized
INFO - 2023-04-20 10:05:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:05:14 --> Final output sent to browser
DEBUG - 2023-04-20 10:05:14 --> Total execution time: 0.0150
INFO - 2023-04-20 10:05:14 --> Config Class Initialized
INFO - 2023-04-20 10:05:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:05:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:05:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:05:14 --> URI Class Initialized
INFO - 2023-04-20 10:05:14 --> Router Class Initialized
INFO - 2023-04-20 10:05:14 --> Output Class Initialized
INFO - 2023-04-20 10:05:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:05:14 --> Input Class Initialized
INFO - 2023-04-20 10:05:14 --> Language Class Initialized
INFO - 2023-04-20 10:05:14 --> Loader Class Initialized
INFO - 2023-04-20 10:05:14 --> Controller Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:05:14 --> Database Driver Class Initialized
INFO - 2023-04-20 10:05:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:05:14 --> Final output sent to browser
DEBUG - 2023-04-20 10:05:14 --> Total execution time: 0.0167
INFO - 2023-04-20 10:05:14 --> Config Class Initialized
INFO - 2023-04-20 10:05:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:05:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:05:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:05:14 --> URI Class Initialized
INFO - 2023-04-20 10:05:14 --> Router Class Initialized
INFO - 2023-04-20 10:05:14 --> Output Class Initialized
INFO - 2023-04-20 10:05:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:05:14 --> Input Class Initialized
INFO - 2023-04-20 10:05:14 --> Language Class Initialized
INFO - 2023-04-20 10:05:14 --> Loader Class Initialized
INFO - 2023-04-20 10:05:14 --> Controller Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:05:14 --> Database Driver Class Initialized
INFO - 2023-04-20 10:05:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:05:14 --> Final output sent to browser
DEBUG - 2023-04-20 10:05:14 --> Total execution time: 0.0570
INFO - 2023-04-20 10:05:14 --> Config Class Initialized
INFO - 2023-04-20 10:05:14 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:05:14 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:05:14 --> Utf8 Class Initialized
INFO - 2023-04-20 10:05:14 --> URI Class Initialized
INFO - 2023-04-20 10:05:14 --> Router Class Initialized
INFO - 2023-04-20 10:05:14 --> Output Class Initialized
INFO - 2023-04-20 10:05:14 --> Security Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:05:14 --> Input Class Initialized
INFO - 2023-04-20 10:05:14 --> Language Class Initialized
INFO - 2023-04-20 10:05:14 --> Loader Class Initialized
INFO - 2023-04-20 10:05:14 --> Controller Class Initialized
DEBUG - 2023-04-20 10:05:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:05:14 --> Database Driver Class Initialized
INFO - 2023-04-20 10:05:14 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:05:14 --> Final output sent to browser
DEBUG - 2023-04-20 10:05:14 --> Total execution time: 0.0124
INFO - 2023-04-20 10:07:19 --> Config Class Initialized
INFO - 2023-04-20 10:07:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:19 --> URI Class Initialized
INFO - 2023-04-20 10:07:19 --> Router Class Initialized
INFO - 2023-04-20 10:07:19 --> Output Class Initialized
INFO - 2023-04-20 10:07:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:19 --> Input Class Initialized
INFO - 2023-04-20 10:07:19 --> Language Class Initialized
INFO - 2023-04-20 10:07:19 --> Loader Class Initialized
INFO - 2023-04-20 10:07:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:19 --> Model "Login_model" initialized
INFO - 2023-04-20 10:07:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:19 --> Total execution time: 0.1437
INFO - 2023-04-20 10:07:19 --> Config Class Initialized
INFO - 2023-04-20 10:07:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:19 --> URI Class Initialized
INFO - 2023-04-20 10:07:19 --> Router Class Initialized
INFO - 2023-04-20 10:07:19 --> Output Class Initialized
INFO - 2023-04-20 10:07:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:19 --> Input Class Initialized
INFO - 2023-04-20 10:07:19 --> Language Class Initialized
INFO - 2023-04-20 10:07:19 --> Loader Class Initialized
INFO - 2023-04-20 10:07:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:19 --> Model "Login_model" initialized
INFO - 2023-04-20 10:07:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:19 --> Total execution time: 0.1022
INFO - 2023-04-20 10:07:22 --> Config Class Initialized
INFO - 2023-04-20 10:07:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:22 --> URI Class Initialized
INFO - 2023-04-20 10:07:22 --> Router Class Initialized
INFO - 2023-04-20 10:07:22 --> Output Class Initialized
INFO - 2023-04-20 10:07:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:22 --> Input Class Initialized
INFO - 2023-04-20 10:07:22 --> Language Class Initialized
INFO - 2023-04-20 10:07:22 --> Loader Class Initialized
INFO - 2023-04-20 10:07:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:22 --> Total execution time: 0.0124
INFO - 2023-04-20 10:07:22 --> Config Class Initialized
INFO - 2023-04-20 10:07:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:22 --> URI Class Initialized
INFO - 2023-04-20 10:07:22 --> Router Class Initialized
INFO - 2023-04-20 10:07:22 --> Output Class Initialized
INFO - 2023-04-20 10:07:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:22 --> Input Class Initialized
INFO - 2023-04-20 10:07:22 --> Language Class Initialized
INFO - 2023-04-20 10:07:22 --> Loader Class Initialized
INFO - 2023-04-20 10:07:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:22 --> Total execution time: 0.0520
INFO - 2023-04-20 10:07:22 --> Config Class Initialized
INFO - 2023-04-20 10:07:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:23 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:23 --> URI Class Initialized
INFO - 2023-04-20 10:07:23 --> Router Class Initialized
INFO - 2023-04-20 10:07:23 --> Output Class Initialized
INFO - 2023-04-20 10:07:23 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:23 --> Input Class Initialized
INFO - 2023-04-20 10:07:23 --> Language Class Initialized
INFO - 2023-04-20 10:07:23 --> Loader Class Initialized
INFO - 2023-04-20 10:07:23 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:23 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:23 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:23 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:23 --> Total execution time: 0.0508
INFO - 2023-04-20 10:07:23 --> Config Class Initialized
INFO - 2023-04-20 10:07:23 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:07:23 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:07:23 --> Utf8 Class Initialized
INFO - 2023-04-20 10:07:23 --> URI Class Initialized
INFO - 2023-04-20 10:07:23 --> Router Class Initialized
INFO - 2023-04-20 10:07:23 --> Output Class Initialized
INFO - 2023-04-20 10:07:23 --> Security Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:07:23 --> Input Class Initialized
INFO - 2023-04-20 10:07:23 --> Language Class Initialized
INFO - 2023-04-20 10:07:23 --> Loader Class Initialized
INFO - 2023-04-20 10:07:23 --> Controller Class Initialized
DEBUG - 2023-04-20 10:07:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:07:23 --> Database Driver Class Initialized
INFO - 2023-04-20 10:07:23 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:07:23 --> Final output sent to browser
DEBUG - 2023-04-20 10:07:23 --> Total execution time: 0.0511
INFO - 2023-04-20 10:32:35 --> Config Class Initialized
INFO - 2023-04-20 10:32:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:35 --> URI Class Initialized
INFO - 2023-04-20 10:32:35 --> Router Class Initialized
INFO - 2023-04-20 10:32:35 --> Output Class Initialized
INFO - 2023-04-20 10:32:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:35 --> Input Class Initialized
INFO - 2023-04-20 10:32:35 --> Language Class Initialized
INFO - 2023-04-20 10:32:35 --> Loader Class Initialized
INFO - 2023-04-20 10:32:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:32:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:35 --> Total execution time: 0.2176
INFO - 2023-04-20 10:32:35 --> Config Class Initialized
INFO - 2023-04-20 10:32:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:35 --> URI Class Initialized
INFO - 2023-04-20 10:32:35 --> Router Class Initialized
INFO - 2023-04-20 10:32:35 --> Output Class Initialized
INFO - 2023-04-20 10:32:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:35 --> Input Class Initialized
INFO - 2023-04-20 10:32:35 --> Language Class Initialized
INFO - 2023-04-20 10:32:35 --> Loader Class Initialized
INFO - 2023-04-20 10:32:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:32:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:35 --> Total execution time: 0.1110
INFO - 2023-04-20 10:32:38 --> Config Class Initialized
INFO - 2023-04-20 10:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:38 --> URI Class Initialized
INFO - 2023-04-20 10:32:38 --> Router Class Initialized
INFO - 2023-04-20 10:32:38 --> Output Class Initialized
INFO - 2023-04-20 10:32:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:38 --> Input Class Initialized
INFO - 2023-04-20 10:32:38 --> Language Class Initialized
INFO - 2023-04-20 10:32:38 --> Loader Class Initialized
INFO - 2023-04-20 10:32:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:38 --> Total execution time: 0.1320
INFO - 2023-04-20 10:32:38 --> Config Class Initialized
INFO - 2023-04-20 10:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:38 --> URI Class Initialized
INFO - 2023-04-20 10:32:38 --> Router Class Initialized
INFO - 2023-04-20 10:32:38 --> Output Class Initialized
INFO - 2023-04-20 10:32:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:38 --> Input Class Initialized
INFO - 2023-04-20 10:32:38 --> Language Class Initialized
INFO - 2023-04-20 10:32:38 --> Loader Class Initialized
INFO - 2023-04-20 10:32:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:38 --> Total execution time: 0.0560
INFO - 2023-04-20 10:32:38 --> Config Class Initialized
INFO - 2023-04-20 10:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:38 --> URI Class Initialized
INFO - 2023-04-20 10:32:38 --> Router Class Initialized
INFO - 2023-04-20 10:32:38 --> Output Class Initialized
INFO - 2023-04-20 10:32:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:38 --> Input Class Initialized
INFO - 2023-04-20 10:32:38 --> Language Class Initialized
INFO - 2023-04-20 10:32:38 --> Loader Class Initialized
INFO - 2023-04-20 10:32:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:38 --> Total execution time: 0.0531
INFO - 2023-04-20 10:32:38 --> Config Class Initialized
INFO - 2023-04-20 10:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:32:38 --> Utf8 Class Initialized
INFO - 2023-04-20 10:32:38 --> URI Class Initialized
INFO - 2023-04-20 10:32:38 --> Router Class Initialized
INFO - 2023-04-20 10:32:38 --> Output Class Initialized
INFO - 2023-04-20 10:32:38 --> Security Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:32:38 --> Input Class Initialized
INFO - 2023-04-20 10:32:38 --> Language Class Initialized
INFO - 2023-04-20 10:32:38 --> Loader Class Initialized
INFO - 2023-04-20 10:32:38 --> Controller Class Initialized
DEBUG - 2023-04-20 10:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:32:38 --> Database Driver Class Initialized
INFO - 2023-04-20 10:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:32:38 --> Final output sent to browser
DEBUG - 2023-04-20 10:32:38 --> Total execution time: 0.0102
INFO - 2023-04-20 10:34:35 --> Config Class Initialized
INFO - 2023-04-20 10:34:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:35 --> URI Class Initialized
INFO - 2023-04-20 10:34:35 --> Router Class Initialized
INFO - 2023-04-20 10:34:35 --> Output Class Initialized
INFO - 2023-04-20 10:34:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:35 --> Input Class Initialized
INFO - 2023-04-20 10:34:35 --> Language Class Initialized
INFO - 2023-04-20 10:34:35 --> Loader Class Initialized
INFO - 2023-04-20 10:34:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:34:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:35 --> Total execution time: 0.2583
INFO - 2023-04-20 10:34:35 --> Config Class Initialized
INFO - 2023-04-20 10:34:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:35 --> URI Class Initialized
INFO - 2023-04-20 10:34:35 --> Router Class Initialized
INFO - 2023-04-20 10:34:35 --> Output Class Initialized
INFO - 2023-04-20 10:34:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:35 --> Input Class Initialized
INFO - 2023-04-20 10:34:35 --> Language Class Initialized
INFO - 2023-04-20 10:34:35 --> Loader Class Initialized
INFO - 2023-04-20 10:34:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:34:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:35 --> Total execution time: 0.0728
INFO - 2023-04-20 10:34:41 --> Config Class Initialized
INFO - 2023-04-20 10:34:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:41 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:41 --> URI Class Initialized
INFO - 2023-04-20 10:34:41 --> Router Class Initialized
INFO - 2023-04-20 10:34:41 --> Output Class Initialized
INFO - 2023-04-20 10:34:41 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:41 --> Input Class Initialized
INFO - 2023-04-20 10:34:41 --> Language Class Initialized
INFO - 2023-04-20 10:34:41 --> Loader Class Initialized
INFO - 2023-04-20 10:34:41 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:41 --> Model "Login_model" initialized
INFO - 2023-04-20 10:34:41 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:41 --> Total execution time: 0.1824
INFO - 2023-04-20 10:34:41 --> Config Class Initialized
INFO - 2023-04-20 10:34:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:41 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:41 --> URI Class Initialized
INFO - 2023-04-20 10:34:41 --> Router Class Initialized
INFO - 2023-04-20 10:34:41 --> Output Class Initialized
INFO - 2023-04-20 10:34:41 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:41 --> Input Class Initialized
INFO - 2023-04-20 10:34:41 --> Language Class Initialized
INFO - 2023-04-20 10:34:41 --> Loader Class Initialized
INFO - 2023-04-20 10:34:41 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:41 --> Model "Login_model" initialized
INFO - 2023-04-20 10:34:41 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:41 --> Total execution time: 0.0805
INFO - 2023-04-20 10:34:43 --> Config Class Initialized
INFO - 2023-04-20 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:43 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:43 --> URI Class Initialized
INFO - 2023-04-20 10:34:43 --> Router Class Initialized
INFO - 2023-04-20 10:34:43 --> Output Class Initialized
INFO - 2023-04-20 10:34:43 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:43 --> Input Class Initialized
INFO - 2023-04-20 10:34:43 --> Language Class Initialized
INFO - 2023-04-20 10:34:43 --> Loader Class Initialized
INFO - 2023-04-20 10:34:43 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:43 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:43 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:43 --> Total execution time: 0.0143
INFO - 2023-04-20 10:34:43 --> Config Class Initialized
INFO - 2023-04-20 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:43 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:43 --> URI Class Initialized
INFO - 2023-04-20 10:34:43 --> Router Class Initialized
INFO - 2023-04-20 10:34:43 --> Output Class Initialized
INFO - 2023-04-20 10:34:43 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:43 --> Input Class Initialized
INFO - 2023-04-20 10:34:43 --> Language Class Initialized
INFO - 2023-04-20 10:34:43 --> Loader Class Initialized
INFO - 2023-04-20 10:34:43 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:43 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:43 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:43 --> Total execution time: 0.0103
INFO - 2023-04-20 10:34:43 --> Config Class Initialized
INFO - 2023-04-20 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:43 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:43 --> URI Class Initialized
INFO - 2023-04-20 10:34:43 --> Router Class Initialized
INFO - 2023-04-20 10:34:43 --> Output Class Initialized
INFO - 2023-04-20 10:34:43 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:43 --> Input Class Initialized
INFO - 2023-04-20 10:34:43 --> Language Class Initialized
INFO - 2023-04-20 10:34:43 --> Loader Class Initialized
INFO - 2023-04-20 10:34:43 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:43 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:43 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:43 --> Total execution time: 0.0547
INFO - 2023-04-20 10:34:43 --> Config Class Initialized
INFO - 2023-04-20 10:34:43 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:34:43 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:34:43 --> Utf8 Class Initialized
INFO - 2023-04-20 10:34:43 --> URI Class Initialized
INFO - 2023-04-20 10:34:43 --> Router Class Initialized
INFO - 2023-04-20 10:34:43 --> Output Class Initialized
INFO - 2023-04-20 10:34:43 --> Security Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:34:43 --> Input Class Initialized
INFO - 2023-04-20 10:34:43 --> Language Class Initialized
INFO - 2023-04-20 10:34:43 --> Loader Class Initialized
INFO - 2023-04-20 10:34:43 --> Controller Class Initialized
DEBUG - 2023-04-20 10:34:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:34:43 --> Database Driver Class Initialized
INFO - 2023-04-20 10:34:43 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:34:43 --> Final output sent to browser
DEBUG - 2023-04-20 10:34:43 --> Total execution time: 0.0107
INFO - 2023-04-20 10:35:41 --> Config Class Initialized
INFO - 2023-04-20 10:35:41 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:41 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:41 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:41 --> URI Class Initialized
INFO - 2023-04-20 10:35:41 --> Router Class Initialized
INFO - 2023-04-20 10:35:41 --> Output Class Initialized
INFO - 2023-04-20 10:35:41 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:41 --> Input Class Initialized
INFO - 2023-04-20 10:35:41 --> Language Class Initialized
INFO - 2023-04-20 10:35:41 --> Loader Class Initialized
INFO - 2023-04-20 10:35:41 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:41 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:41 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:41 --> Model "Login_model" initialized
INFO - 2023-04-20 10:35:42 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:42 --> Total execution time: 0.1277
INFO - 2023-04-20 10:35:42 --> Config Class Initialized
INFO - 2023-04-20 10:35:42 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:42 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:42 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:42 --> URI Class Initialized
INFO - 2023-04-20 10:35:42 --> Router Class Initialized
INFO - 2023-04-20 10:35:42 --> Output Class Initialized
INFO - 2023-04-20 10:35:42 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:42 --> Input Class Initialized
INFO - 2023-04-20 10:35:42 --> Language Class Initialized
INFO - 2023-04-20 10:35:42 --> Loader Class Initialized
INFO - 2023-04-20 10:35:42 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:42 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:42 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:42 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:42 --> Model "Login_model" initialized
INFO - 2023-04-20 10:35:42 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:42 --> Total execution time: 0.1255
INFO - 2023-04-20 10:35:44 --> Config Class Initialized
INFO - 2023-04-20 10:35:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:44 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:44 --> URI Class Initialized
INFO - 2023-04-20 10:35:44 --> Router Class Initialized
INFO - 2023-04-20 10:35:44 --> Output Class Initialized
INFO - 2023-04-20 10:35:44 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:44 --> Input Class Initialized
INFO - 2023-04-20 10:35:44 --> Language Class Initialized
INFO - 2023-04-20 10:35:44 --> Loader Class Initialized
INFO - 2023-04-20 10:35:44 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:44 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:44 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:44 --> Total execution time: 0.0117
INFO - 2023-04-20 10:35:44 --> Config Class Initialized
INFO - 2023-04-20 10:35:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:44 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:44 --> URI Class Initialized
INFO - 2023-04-20 10:35:44 --> Router Class Initialized
INFO - 2023-04-20 10:35:44 --> Output Class Initialized
INFO - 2023-04-20 10:35:44 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:44 --> Input Class Initialized
INFO - 2023-04-20 10:35:44 --> Language Class Initialized
INFO - 2023-04-20 10:35:44 --> Loader Class Initialized
INFO - 2023-04-20 10:35:44 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:44 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:44 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:44 --> Total execution time: 0.0105
INFO - 2023-04-20 10:35:44 --> Config Class Initialized
INFO - 2023-04-20 10:35:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:44 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:44 --> URI Class Initialized
INFO - 2023-04-20 10:35:44 --> Router Class Initialized
INFO - 2023-04-20 10:35:44 --> Output Class Initialized
INFO - 2023-04-20 10:35:44 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:44 --> Input Class Initialized
INFO - 2023-04-20 10:35:44 --> Language Class Initialized
INFO - 2023-04-20 10:35:44 --> Loader Class Initialized
INFO - 2023-04-20 10:35:44 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:44 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:44 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:44 --> Total execution time: 0.0996
INFO - 2023-04-20 10:35:44 --> Config Class Initialized
INFO - 2023-04-20 10:35:44 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:35:44 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:35:44 --> Utf8 Class Initialized
INFO - 2023-04-20 10:35:44 --> URI Class Initialized
INFO - 2023-04-20 10:35:44 --> Router Class Initialized
INFO - 2023-04-20 10:35:44 --> Output Class Initialized
INFO - 2023-04-20 10:35:44 --> Security Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:35:44 --> Input Class Initialized
INFO - 2023-04-20 10:35:44 --> Language Class Initialized
INFO - 2023-04-20 10:35:44 --> Loader Class Initialized
INFO - 2023-04-20 10:35:44 --> Controller Class Initialized
DEBUG - 2023-04-20 10:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:35:44 --> Database Driver Class Initialized
INFO - 2023-04-20 10:35:44 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:35:44 --> Final output sent to browser
DEBUG - 2023-04-20 10:35:44 --> Total execution time: 0.0503
INFO - 2023-04-20 10:38:09 --> Config Class Initialized
INFO - 2023-04-20 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:09 --> URI Class Initialized
INFO - 2023-04-20 10:38:09 --> Router Class Initialized
INFO - 2023-04-20 10:38:09 --> Output Class Initialized
INFO - 2023-04-20 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:09 --> Input Class Initialized
INFO - 2023-04-20 10:38:09 --> Language Class Initialized
INFO - 2023-04-20 10:38:09 --> Loader Class Initialized
INFO - 2023-04-20 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:09 --> Model "Login_model" initialized
INFO - 2023-04-20 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:09 --> Total execution time: 0.0704
INFO - 2023-04-20 10:38:09 --> Config Class Initialized
INFO - 2023-04-20 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:09 --> URI Class Initialized
INFO - 2023-04-20 10:38:09 --> Router Class Initialized
INFO - 2023-04-20 10:38:09 --> Output Class Initialized
INFO - 2023-04-20 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:09 --> Input Class Initialized
INFO - 2023-04-20 10:38:09 --> Language Class Initialized
INFO - 2023-04-20 10:38:09 --> Loader Class Initialized
INFO - 2023-04-20 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:09 --> Model "Login_model" initialized
INFO - 2023-04-20 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:09 --> Total execution time: 0.0586
INFO - 2023-04-20 10:38:19 --> Config Class Initialized
INFO - 2023-04-20 10:38:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:19 --> URI Class Initialized
INFO - 2023-04-20 10:38:19 --> Router Class Initialized
INFO - 2023-04-20 10:38:19 --> Output Class Initialized
INFO - 2023-04-20 10:38:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:19 --> Input Class Initialized
INFO - 2023-04-20 10:38:19 --> Language Class Initialized
INFO - 2023-04-20 10:38:19 --> Loader Class Initialized
INFO - 2023-04-20 10:38:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:19 --> Total execution time: 0.0171
INFO - 2023-04-20 10:38:19 --> Config Class Initialized
INFO - 2023-04-20 10:38:19 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:19 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:19 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:19 --> URI Class Initialized
INFO - 2023-04-20 10:38:19 --> Router Class Initialized
INFO - 2023-04-20 10:38:19 --> Output Class Initialized
INFO - 2023-04-20 10:38:19 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:19 --> Input Class Initialized
INFO - 2023-04-20 10:38:19 --> Language Class Initialized
INFO - 2023-04-20 10:38:19 --> Loader Class Initialized
INFO - 2023-04-20 10:38:19 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:19 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:19 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:19 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:19 --> Total execution time: 0.0522
INFO - 2023-04-20 10:38:22 --> Config Class Initialized
INFO - 2023-04-20 10:38:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:22 --> URI Class Initialized
INFO - 2023-04-20 10:38:22 --> Router Class Initialized
INFO - 2023-04-20 10:38:22 --> Output Class Initialized
INFO - 2023-04-20 10:38:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:22 --> Input Class Initialized
INFO - 2023-04-20 10:38:22 --> Language Class Initialized
INFO - 2023-04-20 10:38:22 --> Loader Class Initialized
INFO - 2023-04-20 10:38:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:22 --> Total execution time: 0.0474
INFO - 2023-04-20 10:38:22 --> Config Class Initialized
INFO - 2023-04-20 10:38:22 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:38:22 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:38:22 --> Utf8 Class Initialized
INFO - 2023-04-20 10:38:22 --> URI Class Initialized
INFO - 2023-04-20 10:38:22 --> Router Class Initialized
INFO - 2023-04-20 10:38:22 --> Output Class Initialized
INFO - 2023-04-20 10:38:22 --> Security Class Initialized
DEBUG - 2023-04-20 10:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:38:22 --> Input Class Initialized
INFO - 2023-04-20 10:38:22 --> Language Class Initialized
INFO - 2023-04-20 10:38:22 --> Loader Class Initialized
INFO - 2023-04-20 10:38:22 --> Controller Class Initialized
DEBUG - 2023-04-20 10:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:38:22 --> Database Driver Class Initialized
INFO - 2023-04-20 10:38:22 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:38:22 --> Final output sent to browser
DEBUG - 2023-04-20 10:38:22 --> Total execution time: 0.0846
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.0278
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.0789
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.0465
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.1807
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.2320
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.0980
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Config Class Initialized
INFO - 2023-04-20 10:41:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> URI Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Router Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Output Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
INFO - 2023-04-20 10:41:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:41:28 --> Input Class Initialized
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Language Class Initialized
INFO - 2023-04-20 10:41:28 --> Loader Class Initialized
INFO - 2023-04-20 10:41:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:41:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:41:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
INFO - 2023-04-20 10:41:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.1305
DEBUG - 2023-04-20 10:41:28 --> Total execution time: 0.0858
INFO - 2023-04-20 10:42:28 --> Config Class Initialized
INFO - 2023-04-20 10:42:28 --> Config Class Initialized
INFO - 2023-04-20 10:42:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:42:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:42:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:42:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:42:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:42:28 --> URI Class Initialized
INFO - 2023-04-20 10:42:28 --> URI Class Initialized
INFO - 2023-04-20 10:42:28 --> Router Class Initialized
INFO - 2023-04-20 10:42:28 --> Router Class Initialized
INFO - 2023-04-20 10:42:28 --> Output Class Initialized
INFO - 2023-04-20 10:42:28 --> Output Class Initialized
INFO - 2023-04-20 10:42:28 --> Security Class Initialized
INFO - 2023-04-20 10:42:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:42:28 --> Input Class Initialized
INFO - 2023-04-20 10:42:28 --> Input Class Initialized
INFO - 2023-04-20 10:42:28 --> Language Class Initialized
INFO - 2023-04-20 10:42:28 --> Language Class Initialized
INFO - 2023-04-20 10:42:28 --> Loader Class Initialized
INFO - 2023-04-20 10:42:28 --> Loader Class Initialized
INFO - 2023-04-20 10:42:28 --> Controller Class Initialized
INFO - 2023-04-20 10:42:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:42:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:42:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:42:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:42:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:42:28 --> Total execution time: 0.0336
INFO - 2023-04-20 10:42:28 --> Config Class Initialized
INFO - 2023-04-20 10:42:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:42:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:42:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:42:28 --> URI Class Initialized
INFO - 2023-04-20 10:42:28 --> Router Class Initialized
INFO - 2023-04-20 10:42:28 --> Output Class Initialized
INFO - 2023-04-20 10:42:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:42:28 --> Input Class Initialized
INFO - 2023-04-20 10:42:28 --> Language Class Initialized
INFO - 2023-04-20 10:42:28 --> Loader Class Initialized
INFO - 2023-04-20 10:42:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:42:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:42:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:42:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:42:28 --> Total execution time: 0.0948
INFO - 2023-04-20 10:42:30 --> Final output sent to browser
DEBUG - 2023-04-20 10:42:30 --> Total execution time: 2.1381
INFO - 2023-04-20 10:42:30 --> Config Class Initialized
INFO - 2023-04-20 10:42:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:42:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:42:30 --> Utf8 Class Initialized
INFO - 2023-04-20 10:42:30 --> URI Class Initialized
INFO - 2023-04-20 10:42:30 --> Router Class Initialized
INFO - 2023-04-20 10:42:30 --> Output Class Initialized
INFO - 2023-04-20 10:42:30 --> Security Class Initialized
DEBUG - 2023-04-20 10:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:42:30 --> Input Class Initialized
INFO - 2023-04-20 10:42:30 --> Language Class Initialized
INFO - 2023-04-20 10:42:30 --> Loader Class Initialized
INFO - 2023-04-20 10:42:30 --> Controller Class Initialized
DEBUG - 2023-04-20 10:42:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:42:30 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:30 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:42:30 --> Database Driver Class Initialized
INFO - 2023-04-20 10:42:30 --> Model "Login_model" initialized
INFO - 2023-04-20 10:42:31 --> Final output sent to browser
DEBUG - 2023-04-20 10:42:31 --> Total execution time: 0.4980
INFO - 2023-04-20 10:43:28 --> Config Class Initialized
INFO - 2023-04-20 10:43:28 --> Config Class Initialized
INFO - 2023-04-20 10:43:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:43:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:43:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:43:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:43:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:43:28 --> URI Class Initialized
INFO - 2023-04-20 10:43:28 --> URI Class Initialized
INFO - 2023-04-20 10:43:28 --> Router Class Initialized
INFO - 2023-04-20 10:43:28 --> Router Class Initialized
INFO - 2023-04-20 10:43:28 --> Output Class Initialized
INFO - 2023-04-20 10:43:28 --> Output Class Initialized
INFO - 2023-04-20 10:43:28 --> Security Class Initialized
INFO - 2023-04-20 10:43:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:43:28 --> Input Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:43:28 --> Input Class Initialized
INFO - 2023-04-20 10:43:28 --> Language Class Initialized
INFO - 2023-04-20 10:43:28 --> Language Class Initialized
INFO - 2023-04-20 10:43:28 --> Loader Class Initialized
INFO - 2023-04-20 10:43:28 --> Loader Class Initialized
INFO - 2023-04-20 10:43:28 --> Controller Class Initialized
INFO - 2023-04-20 10:43:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:43:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:43:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:43:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:43:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:43:28 --> Final output sent to browser
INFO - 2023-04-20 10:43:28 --> Config Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Total execution time: 0.3777
INFO - 2023-04-20 10:43:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:43:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:43:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:43:28 --> URI Class Initialized
INFO - 2023-04-20 10:43:28 --> Router Class Initialized
INFO - 2023-04-20 10:43:28 --> Output Class Initialized
INFO - 2023-04-20 10:43:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:43:28 --> Input Class Initialized
INFO - 2023-04-20 10:43:28 --> Language Class Initialized
INFO - 2023-04-20 10:43:28 --> Loader Class Initialized
INFO - 2023-04-20 10:43:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:43:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:43:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:43:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:43:28 --> Total execution time: 0.0730
INFO - 2023-04-20 10:43:29 --> Final output sent to browser
DEBUG - 2023-04-20 10:43:29 --> Total execution time: 0.8226
INFO - 2023-04-20 10:43:29 --> Config Class Initialized
INFO - 2023-04-20 10:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:43:29 --> Utf8 Class Initialized
INFO - 2023-04-20 10:43:29 --> URI Class Initialized
INFO - 2023-04-20 10:43:29 --> Router Class Initialized
INFO - 2023-04-20 10:43:29 --> Output Class Initialized
INFO - 2023-04-20 10:43:29 --> Security Class Initialized
DEBUG - 2023-04-20 10:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:43:29 --> Input Class Initialized
INFO - 2023-04-20 10:43:29 --> Language Class Initialized
INFO - 2023-04-20 10:43:29 --> Loader Class Initialized
INFO - 2023-04-20 10:43:29 --> Controller Class Initialized
DEBUG - 2023-04-20 10:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:43:29 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:43:29 --> Database Driver Class Initialized
INFO - 2023-04-20 10:43:29 --> Model "Login_model" initialized
INFO - 2023-04-20 10:43:29 --> Final output sent to browser
DEBUG - 2023-04-20 10:43:29 --> Total execution time: 0.5165
INFO - 2023-04-20 10:44:28 --> Config Class Initialized
INFO - 2023-04-20 10:44:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:44:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:44:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:44:28 --> URI Class Initialized
INFO - 2023-04-20 10:44:28 --> Router Class Initialized
INFO - 2023-04-20 10:44:28 --> Output Class Initialized
INFO - 2023-04-20 10:44:28 --> Config Class Initialized
INFO - 2023-04-20 10:44:28 --> Security Class Initialized
INFO - 2023-04-20 10:44:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:44:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:44:28 --> Input Class Initialized
INFO - 2023-04-20 10:44:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:44:28 --> Language Class Initialized
INFO - 2023-04-20 10:44:28 --> URI Class Initialized
INFO - 2023-04-20 10:44:28 --> Loader Class Initialized
INFO - 2023-04-20 10:44:28 --> Router Class Initialized
INFO - 2023-04-20 10:44:28 --> Controller Class Initialized
INFO - 2023-04-20 10:44:28 --> Output Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:44:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Input Class Initialized
INFO - 2023-04-20 10:44:28 --> Language Class Initialized
INFO - 2023-04-20 10:44:28 --> Loader Class Initialized
INFO - 2023-04-20 10:44:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:44:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:44:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:44:28 --> Total execution time: 0.0416
INFO - 2023-04-20 10:44:28 --> Config Class Initialized
INFO - 2023-04-20 10:44:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:44:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:44:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:44:28 --> URI Class Initialized
INFO - 2023-04-20 10:44:28 --> Router Class Initialized
INFO - 2023-04-20 10:44:28 --> Output Class Initialized
INFO - 2023-04-20 10:44:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:44:28 --> Input Class Initialized
INFO - 2023-04-20 10:44:28 --> Language Class Initialized
INFO - 2023-04-20 10:44:28 --> Loader Class Initialized
INFO - 2023-04-20 10:44:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:44:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:44:28 --> Total execution time: 0.0719
INFO - 2023-04-20 10:44:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:44:28 --> Total execution time: 0.4685
INFO - 2023-04-20 10:44:28 --> Config Class Initialized
INFO - 2023-04-20 10:44:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:44:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:44:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:44:28 --> URI Class Initialized
INFO - 2023-04-20 10:44:28 --> Router Class Initialized
INFO - 2023-04-20 10:44:28 --> Output Class Initialized
INFO - 2023-04-20 10:44:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:44:28 --> Input Class Initialized
INFO - 2023-04-20 10:44:28 --> Language Class Initialized
INFO - 2023-04-20 10:44:28 --> Loader Class Initialized
INFO - 2023-04-20 10:44:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:44:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:44:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:44:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:44:29 --> Final output sent to browser
DEBUG - 2023-04-20 10:44:29 --> Total execution time: 0.4381
INFO - 2023-04-20 10:45:28 --> Config Class Initialized
INFO - 2023-04-20 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:45:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:45:28 --> URI Class Initialized
INFO - 2023-04-20 10:45:28 --> Config Class Initialized
INFO - 2023-04-20 10:45:28 --> Router Class Initialized
INFO - 2023-04-20 10:45:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:45:28 --> Output Class Initialized
DEBUG - 2023-04-20 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:45:28 --> Security Class Initialized
INFO - 2023-04-20 10:45:28 --> Utf8 Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:45:28 --> URI Class Initialized
INFO - 2023-04-20 10:45:28 --> Input Class Initialized
INFO - 2023-04-20 10:45:28 --> Router Class Initialized
INFO - 2023-04-20 10:45:28 --> Language Class Initialized
INFO - 2023-04-20 10:45:28 --> Output Class Initialized
INFO - 2023-04-20 10:45:28 --> Loader Class Initialized
INFO - 2023-04-20 10:45:28 --> Security Class Initialized
INFO - 2023-04-20 10:45:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:45:28 --> Input Class Initialized
INFO - 2023-04-20 10:45:28 --> Language Class Initialized
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Loader Class Initialized
INFO - 2023-04-20 10:45:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:45:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:45:28 --> Total execution time: 0.0380
INFO - 2023-04-20 10:45:28 --> Config Class Initialized
INFO - 2023-04-20 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:45:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:45:28 --> URI Class Initialized
INFO - 2023-04-20 10:45:28 --> Router Class Initialized
INFO - 2023-04-20 10:45:28 --> Output Class Initialized
INFO - 2023-04-20 10:45:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:45:28 --> Input Class Initialized
INFO - 2023-04-20 10:45:28 --> Language Class Initialized
INFO - 2023-04-20 10:45:28 --> Loader Class Initialized
INFO - 2023-04-20 10:45:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:45:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:45:28 --> Total execution time: 0.0458
INFO - 2023-04-20 10:45:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:45:28 --> Total execution time: 0.4924
INFO - 2023-04-20 10:45:28 --> Config Class Initialized
INFO - 2023-04-20 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:45:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:45:28 --> URI Class Initialized
INFO - 2023-04-20 10:45:28 --> Router Class Initialized
INFO - 2023-04-20 10:45:28 --> Output Class Initialized
INFO - 2023-04-20 10:45:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:45:28 --> Input Class Initialized
INFO - 2023-04-20 10:45:28 --> Language Class Initialized
INFO - 2023-04-20 10:45:28 --> Loader Class Initialized
INFO - 2023-04-20 10:45:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:45:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:45:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:45:29 --> Final output sent to browser
DEBUG - 2023-04-20 10:45:29 --> Total execution time: 0.5058
INFO - 2023-04-20 10:46:28 --> Config Class Initialized
INFO - 2023-04-20 10:46:28 --> Config Class Initialized
INFO - 2023-04-20 10:46:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:46:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:46:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:46:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:46:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:46:28 --> URI Class Initialized
INFO - 2023-04-20 10:46:28 --> URI Class Initialized
INFO - 2023-04-20 10:46:28 --> Router Class Initialized
INFO - 2023-04-20 10:46:28 --> Router Class Initialized
INFO - 2023-04-20 10:46:28 --> Output Class Initialized
INFO - 2023-04-20 10:46:28 --> Output Class Initialized
INFO - 2023-04-20 10:46:28 --> Security Class Initialized
INFO - 2023-04-20 10:46:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:46:28 --> Input Class Initialized
INFO - 2023-04-20 10:46:28 --> Input Class Initialized
INFO - 2023-04-20 10:46:28 --> Language Class Initialized
INFO - 2023-04-20 10:46:28 --> Language Class Initialized
INFO - 2023-04-20 10:46:28 --> Loader Class Initialized
INFO - 2023-04-20 10:46:28 --> Loader Class Initialized
INFO - 2023-04-20 10:46:28 --> Controller Class Initialized
INFO - 2023-04-20 10:46:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:46:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:46:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:46:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:46:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:46:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:46:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:46:28 --> Total execution time: 0.1599
INFO - 2023-04-20 10:46:28 --> Config Class Initialized
INFO - 2023-04-20 10:46:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:46:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:46:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:46:28 --> URI Class Initialized
INFO - 2023-04-20 10:46:28 --> Router Class Initialized
INFO - 2023-04-20 10:46:28 --> Output Class Initialized
INFO - 2023-04-20 10:46:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:46:28 --> Input Class Initialized
INFO - 2023-04-20 10:46:28 --> Language Class Initialized
INFO - 2023-04-20 10:46:28 --> Loader Class Initialized
INFO - 2023-04-20 10:46:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:46:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:46:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:46:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:46:28 --> Total execution time: 0.1980
INFO - 2023-04-20 10:46:30 --> Final output sent to browser
DEBUG - 2023-04-20 10:46:30 --> Total execution time: 2.4945
INFO - 2023-04-20 10:46:30 --> Config Class Initialized
INFO - 2023-04-20 10:46:30 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:46:30 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:46:30 --> Utf8 Class Initialized
INFO - 2023-04-20 10:46:30 --> URI Class Initialized
INFO - 2023-04-20 10:46:30 --> Router Class Initialized
INFO - 2023-04-20 10:46:31 --> Output Class Initialized
INFO - 2023-04-20 10:46:31 --> Security Class Initialized
DEBUG - 2023-04-20 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:46:31 --> Input Class Initialized
INFO - 2023-04-20 10:46:31 --> Language Class Initialized
INFO - 2023-04-20 10:46:31 --> Loader Class Initialized
INFO - 2023-04-20 10:46:31 --> Controller Class Initialized
DEBUG - 2023-04-20 10:46:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:46:31 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:31 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:46:31 --> Database Driver Class Initialized
INFO - 2023-04-20 10:46:31 --> Model "Login_model" initialized
INFO - 2023-04-20 10:46:32 --> Final output sent to browser
DEBUG - 2023-04-20 10:46:32 --> Total execution time: 1.1209
INFO - 2023-04-20 10:47:28 --> Config Class Initialized
INFO - 2023-04-20 10:47:28 --> Config Class Initialized
INFO - 2023-04-20 10:47:28 --> Hooks Class Initialized
INFO - 2023-04-20 10:47:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:47:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:28 --> URI Class Initialized
INFO - 2023-04-20 10:47:28 --> URI Class Initialized
INFO - 2023-04-20 10:47:28 --> Router Class Initialized
INFO - 2023-04-20 10:47:28 --> Router Class Initialized
INFO - 2023-04-20 10:47:28 --> Output Class Initialized
INFO - 2023-04-20 10:47:28 --> Output Class Initialized
INFO - 2023-04-20 10:47:28 --> Security Class Initialized
INFO - 2023-04-20 10:47:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:28 --> Input Class Initialized
INFO - 2023-04-20 10:47:28 --> Input Class Initialized
INFO - 2023-04-20 10:47:28 --> Language Class Initialized
INFO - 2023-04-20 10:47:28 --> Language Class Initialized
INFO - 2023-04-20 10:47:28 --> Loader Class Initialized
INFO - 2023-04-20 10:47:28 --> Loader Class Initialized
INFO - 2023-04-20 10:47:28 --> Controller Class Initialized
INFO - 2023-04-20 10:47:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:28 --> Model "Login_model" initialized
INFO - 2023-04-20 10:47:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:28 --> Total execution time: 0.0934
INFO - 2023-04-20 10:47:28 --> Config Class Initialized
INFO - 2023-04-20 10:47:28 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:28 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:28 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:28 --> URI Class Initialized
INFO - 2023-04-20 10:47:28 --> Router Class Initialized
INFO - 2023-04-20 10:47:28 --> Output Class Initialized
INFO - 2023-04-20 10:47:28 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:28 --> Input Class Initialized
INFO - 2023-04-20 10:47:28 --> Language Class Initialized
INFO - 2023-04-20 10:47:28 --> Loader Class Initialized
INFO - 2023-04-20 10:47:28 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:28 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:28 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:28 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:28 --> Total execution time: 0.0937
INFO - 2023-04-20 10:47:29 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:29 --> Total execution time: 1.3229
INFO - 2023-04-20 10:47:29 --> Config Class Initialized
INFO - 2023-04-20 10:47:29 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:29 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:29 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:29 --> URI Class Initialized
INFO - 2023-04-20 10:47:29 --> Router Class Initialized
INFO - 2023-04-20 10:47:29 --> Output Class Initialized
INFO - 2023-04-20 10:47:29 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:29 --> Input Class Initialized
INFO - 2023-04-20 10:47:29 --> Language Class Initialized
INFO - 2023-04-20 10:47:29 --> Loader Class Initialized
INFO - 2023-04-20 10:47:29 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:29 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:29 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:29 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:29 --> Model "Login_model" initialized
INFO - 2023-04-20 10:47:31 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:31 --> Total execution time: 1.7898
INFO - 2023-04-20 10:47:33 --> Config Class Initialized
INFO - 2023-04-20 10:47:33 --> Config Class Initialized
INFO - 2023-04-20 10:47:33 --> Hooks Class Initialized
INFO - 2023-04-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:33 --> URI Class Initialized
INFO - 2023-04-20 10:47:33 --> URI Class Initialized
INFO - 2023-04-20 10:47:33 --> Router Class Initialized
INFO - 2023-04-20 10:47:33 --> Router Class Initialized
INFO - 2023-04-20 10:47:33 --> Output Class Initialized
INFO - 2023-04-20 10:47:33 --> Output Class Initialized
INFO - 2023-04-20 10:47:33 --> Security Class Initialized
INFO - 2023-04-20 10:47:33 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:33 --> Input Class Initialized
INFO - 2023-04-20 10:47:33 --> Input Class Initialized
INFO - 2023-04-20 10:47:33 --> Language Class Initialized
INFO - 2023-04-20 10:47:33 --> Language Class Initialized
INFO - 2023-04-20 10:47:33 --> Loader Class Initialized
INFO - 2023-04-20 10:47:33 --> Loader Class Initialized
INFO - 2023-04-20 10:47:33 --> Controller Class Initialized
INFO - 2023-04-20 10:47:33 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-20 10:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:33 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:33 --> Total execution time: 0.0044
INFO - 2023-04-20 10:47:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:33 --> Config Class Initialized
INFO - 2023-04-20 10:47:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:33 --> URI Class Initialized
INFO - 2023-04-20 10:47:33 --> Router Class Initialized
INFO - 2023-04-20 10:47:33 --> Output Class Initialized
INFO - 2023-04-20 10:47:33 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:33 --> Input Class Initialized
INFO - 2023-04-20 10:47:33 --> Language Class Initialized
INFO - 2023-04-20 10:47:33 --> Loader Class Initialized
INFO - 2023-04-20 10:47:33 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:33 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:33 --> Total execution time: 0.0586
INFO - 2023-04-20 10:47:33 --> Config Class Initialized
INFO - 2023-04-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:33 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:33 --> URI Class Initialized
INFO - 2023-04-20 10:47:33 --> Router Class Initialized
INFO - 2023-04-20 10:47:33 --> Output Class Initialized
INFO - 2023-04-20 10:47:33 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:33 --> Input Class Initialized
INFO - 2023-04-20 10:47:33 --> Language Class Initialized
INFO - 2023-04-20 10:47:33 --> Loader Class Initialized
INFO - 2023-04-20 10:47:33 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:33 --> Model "Login_model" initialized
INFO - 2023-04-20 10:47:33 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:33 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:33 --> Final output sent to browser
INFO - 2023-04-20 10:47:33 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:33 --> Total execution time: 0.0877
DEBUG - 2023-04-20 10:47:33 --> Total execution time: 0.0326
INFO - 2023-04-20 10:47:35 --> Config Class Initialized
INFO - 2023-04-20 10:47:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:35 --> URI Class Initialized
INFO - 2023-04-20 10:47:35 --> Router Class Initialized
INFO - 2023-04-20 10:47:35 --> Output Class Initialized
INFO - 2023-04-20 10:47:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:35 --> Input Class Initialized
INFO - 2023-04-20 10:47:35 --> Language Class Initialized
INFO - 2023-04-20 10:47:35 --> Loader Class Initialized
INFO - 2023-04-20 10:47:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:47:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:35 --> Total execution time: 0.3559
INFO - 2023-04-20 10:47:35 --> Config Class Initialized
INFO - 2023-04-20 10:47:35 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:35 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:35 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:35 --> URI Class Initialized
INFO - 2023-04-20 10:47:35 --> Router Class Initialized
INFO - 2023-04-20 10:47:35 --> Output Class Initialized
INFO - 2023-04-20 10:47:35 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:35 --> Input Class Initialized
INFO - 2023-04-20 10:47:35 --> Language Class Initialized
INFO - 2023-04-20 10:47:35 --> Loader Class Initialized
INFO - 2023-04-20 10:47:35 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:35 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:35 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:35 --> Model "Login_model" initialized
INFO - 2023-04-20 10:47:35 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:35 --> Total execution time: 0.2732
INFO - 2023-04-20 10:47:40 --> Config Class Initialized
INFO - 2023-04-20 10:47:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:40 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:40 --> URI Class Initialized
INFO - 2023-04-20 10:47:40 --> Router Class Initialized
INFO - 2023-04-20 10:47:40 --> Output Class Initialized
INFO - 2023-04-20 10:47:40 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:40 --> Input Class Initialized
INFO - 2023-04-20 10:47:40 --> Language Class Initialized
INFO - 2023-04-20 10:47:40 --> Loader Class Initialized
INFO - 2023-04-20 10:47:40 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:40 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:40 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:40 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:40 --> Total execution time: 0.0871
INFO - 2023-04-20 10:47:40 --> Config Class Initialized
INFO - 2023-04-20 10:47:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:40 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:40 --> URI Class Initialized
INFO - 2023-04-20 10:47:40 --> Router Class Initialized
INFO - 2023-04-20 10:47:40 --> Output Class Initialized
INFO - 2023-04-20 10:47:40 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:40 --> Input Class Initialized
INFO - 2023-04-20 10:47:40 --> Language Class Initialized
INFO - 2023-04-20 10:47:40 --> Loader Class Initialized
INFO - 2023-04-20 10:47:40 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:40 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:40 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:40 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:40 --> Total execution time: 0.1070
INFO - 2023-04-20 10:47:40 --> Config Class Initialized
INFO - 2023-04-20 10:47:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:40 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:40 --> URI Class Initialized
INFO - 2023-04-20 10:47:40 --> Router Class Initialized
INFO - 2023-04-20 10:47:40 --> Output Class Initialized
INFO - 2023-04-20 10:47:40 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:40 --> Input Class Initialized
INFO - 2023-04-20 10:47:40 --> Language Class Initialized
INFO - 2023-04-20 10:47:40 --> Loader Class Initialized
INFO - 2023-04-20 10:47:40 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:40 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:40 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:40 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:40 --> Total execution time: 0.0684
INFO - 2023-04-20 10:47:40 --> Config Class Initialized
INFO - 2023-04-20 10:47:40 --> Hooks Class Initialized
DEBUG - 2023-04-20 10:47:40 --> UTF-8 Support Enabled
INFO - 2023-04-20 10:47:40 --> Utf8 Class Initialized
INFO - 2023-04-20 10:47:40 --> URI Class Initialized
INFO - 2023-04-20 10:47:40 --> Router Class Initialized
INFO - 2023-04-20 10:47:40 --> Output Class Initialized
INFO - 2023-04-20 10:47:40 --> Security Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-20 10:47:40 --> Input Class Initialized
INFO - 2023-04-20 10:47:40 --> Language Class Initialized
INFO - 2023-04-20 10:47:40 --> Loader Class Initialized
INFO - 2023-04-20 10:47:40 --> Controller Class Initialized
DEBUG - 2023-04-20 10:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-20 10:47:40 --> Database Driver Class Initialized
INFO - 2023-04-20 10:47:40 --> Model "Cluster_model" initialized
INFO - 2023-04-20 10:47:40 --> Final output sent to browser
DEBUG - 2023-04-20 10:47:40 --> Total execution time: 0.0551
