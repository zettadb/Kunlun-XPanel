<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-13 01:40:54 --> Config Class Initialized
INFO - 2023-03-13 01:40:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:40:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:40:54 --> Utf8 Class Initialized
INFO - 2023-03-13 01:40:54 --> URI Class Initialized
INFO - 2023-03-13 01:40:54 --> Router Class Initialized
INFO - 2023-03-13 01:40:54 --> Output Class Initialized
INFO - 2023-03-13 01:40:54 --> Security Class Initialized
DEBUG - 2023-03-13 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:40:54 --> Input Class Initialized
INFO - 2023-03-13 01:40:54 --> Language Class Initialized
INFO - 2023-03-13 01:40:54 --> Loader Class Initialized
INFO - 2023-03-13 01:40:54 --> Controller Class Initialized
INFO - 2023-03-13 01:40:54 --> Helper loaded: form_helper
INFO - 2023-03-13 01:40:54 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:40:54 --> Model "Change_model" initialized
INFO - 2023-03-13 01:40:54 --> Model "Grafana_model" initialized
INFO - 2023-03-13 01:40:54 --> Final output sent to browser
DEBUG - 2023-03-13 01:40:54 --> Total execution time: 0.0887
INFO - 2023-03-13 01:40:54 --> Config Class Initialized
INFO - 2023-03-13 01:40:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:40:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:40:54 --> Utf8 Class Initialized
INFO - 2023-03-13 01:40:54 --> URI Class Initialized
INFO - 2023-03-13 01:40:54 --> Router Class Initialized
INFO - 2023-03-13 01:40:54 --> Output Class Initialized
INFO - 2023-03-13 01:40:54 --> Security Class Initialized
DEBUG - 2023-03-13 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:40:54 --> Input Class Initialized
INFO - 2023-03-13 01:40:54 --> Language Class Initialized
INFO - 2023-03-13 01:40:54 --> Loader Class Initialized
INFO - 2023-03-13 01:40:54 --> Controller Class Initialized
INFO - 2023-03-13 01:40:54 --> Helper loaded: form_helper
INFO - 2023-03-13 01:40:54 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:40:54 --> Final output sent to browser
DEBUG - 2023-03-13 01:40:54 --> Total execution time: 0.0023
INFO - 2023-03-13 01:40:54 --> Config Class Initialized
INFO - 2023-03-13 01:40:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:40:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:40:54 --> Utf8 Class Initialized
INFO - 2023-03-13 01:40:54 --> URI Class Initialized
INFO - 2023-03-13 01:40:54 --> Router Class Initialized
INFO - 2023-03-13 01:40:54 --> Output Class Initialized
INFO - 2023-03-13 01:40:54 --> Security Class Initialized
DEBUG - 2023-03-13 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:40:54 --> Input Class Initialized
INFO - 2023-03-13 01:40:54 --> Language Class Initialized
INFO - 2023-03-13 01:40:54 --> Loader Class Initialized
INFO - 2023-03-13 01:40:54 --> Controller Class Initialized
INFO - 2023-03-13 01:40:54 --> Helper loaded: form_helper
INFO - 2023-03-13 01:40:54 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:40:54 --> Database Driver Class Initialized
INFO - 2023-03-13 01:40:54 --> Model "Login_model" initialized
INFO - 2023-03-13 01:40:54 --> Final output sent to browser
DEBUG - 2023-03-13 01:40:54 --> Total execution time: 0.0629
INFO - 2023-03-13 01:40:54 --> Config Class Initialized
INFO - 2023-03-13 01:40:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:40:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:40:54 --> Utf8 Class Initialized
INFO - 2023-03-13 01:40:54 --> URI Class Initialized
INFO - 2023-03-13 01:40:54 --> Router Class Initialized
INFO - 2023-03-13 01:40:54 --> Output Class Initialized
INFO - 2023-03-13 01:40:54 --> Security Class Initialized
DEBUG - 2023-03-13 01:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:40:54 --> Input Class Initialized
INFO - 2023-03-13 01:40:54 --> Language Class Initialized
INFO - 2023-03-13 01:40:54 --> Loader Class Initialized
INFO - 2023-03-13 01:40:54 --> Controller Class Initialized
DEBUG - 2023-03-13 01:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:40:54 --> Database Driver Class Initialized
INFO - 2023-03-13 01:40:54 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:41:10 --> Config Class Initialized
INFO - 2023-03-13 01:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:10 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:10 --> URI Class Initialized
INFO - 2023-03-13 01:41:10 --> Router Class Initialized
INFO - 2023-03-13 01:41:10 --> Output Class Initialized
INFO - 2023-03-13 01:41:10 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:10 --> Input Class Initialized
INFO - 2023-03-13 01:41:10 --> Language Class Initialized
INFO - 2023-03-13 01:41:10 --> Loader Class Initialized
INFO - 2023-03-13 01:41:10 --> Controller Class Initialized
INFO - 2023-03-13 01:41:10 --> Helper loaded: form_helper
INFO - 2023-03-13 01:41:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:10 --> Model "Change_model" initialized
INFO - 2023-03-13 01:41:10 --> Model "Grafana_model" initialized
INFO - 2023-03-13 01:41:10 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:10 --> Total execution time: 0.0237
INFO - 2023-03-13 01:41:10 --> Config Class Initialized
INFO - 2023-03-13 01:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:10 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:10 --> URI Class Initialized
INFO - 2023-03-13 01:41:10 --> Router Class Initialized
INFO - 2023-03-13 01:41:10 --> Output Class Initialized
INFO - 2023-03-13 01:41:10 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:10 --> Input Class Initialized
INFO - 2023-03-13 01:41:10 --> Language Class Initialized
INFO - 2023-03-13 01:41:10 --> Loader Class Initialized
INFO - 2023-03-13 01:41:10 --> Controller Class Initialized
INFO - 2023-03-13 01:41:10 --> Helper loaded: form_helper
INFO - 2023-03-13 01:41:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:10 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:10 --> Total execution time: 0.0426
INFO - 2023-03-13 01:41:10 --> Config Class Initialized
INFO - 2023-03-13 01:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:10 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:10 --> URI Class Initialized
INFO - 2023-03-13 01:41:10 --> Router Class Initialized
INFO - 2023-03-13 01:41:10 --> Output Class Initialized
INFO - 2023-03-13 01:41:10 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:10 --> Input Class Initialized
INFO - 2023-03-13 01:41:10 --> Language Class Initialized
INFO - 2023-03-13 01:41:10 --> Loader Class Initialized
INFO - 2023-03-13 01:41:10 --> Controller Class Initialized
INFO - 2023-03-13 01:41:10 --> Helper loaded: form_helper
INFO - 2023-03-13 01:41:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 01:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:10 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:10 --> Model "Login_model" initialized
INFO - 2023-03-13 01:41:10 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:10 --> Total execution time: 0.0140
INFO - 2023-03-13 01:41:10 --> Config Class Initialized
INFO - 2023-03-13 01:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:10 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:10 --> URI Class Initialized
INFO - 2023-03-13 01:41:10 --> Router Class Initialized
INFO - 2023-03-13 01:41:10 --> Output Class Initialized
INFO - 2023-03-13 01:41:10 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:10 --> Input Class Initialized
INFO - 2023-03-13 01:41:10 --> Language Class Initialized
INFO - 2023-03-13 01:41:10 --> Loader Class Initialized
INFO - 2023-03-13 01:41:10 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:10 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:41:10 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:10 --> Total execution time: 0.0158
INFO - 2023-03-13 01:41:10 --> Config Class Initialized
INFO - 2023-03-13 01:41:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:10 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:10 --> URI Class Initialized
INFO - 2023-03-13 01:41:10 --> Router Class Initialized
INFO - 2023-03-13 01:41:10 --> Output Class Initialized
INFO - 2023-03-13 01:41:10 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:10 --> Input Class Initialized
INFO - 2023-03-13 01:41:10 --> Language Class Initialized
INFO - 2023-03-13 01:41:10 --> Loader Class Initialized
INFO - 2023-03-13 01:41:10 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:10 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:41:10 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:10 --> Total execution time: 0.0111
INFO - 2023-03-13 01:41:11 --> Config Class Initialized
INFO - 2023-03-13 01:41:11 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:11 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:11 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:11 --> URI Class Initialized
INFO - 2023-03-13 01:41:11 --> Router Class Initialized
INFO - 2023-03-13 01:41:11 --> Output Class Initialized
INFO - 2023-03-13 01:41:11 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:11 --> Input Class Initialized
INFO - 2023-03-13 01:41:11 --> Language Class Initialized
INFO - 2023-03-13 01:41:11 --> Loader Class Initialized
INFO - 2023-03-13 01:41:11 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:11 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:11 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:41:11 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:11 --> Model "Login_model" initialized
INFO - 2023-03-13 01:41:11 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:11 --> Total execution time: 0.1208
INFO - 2023-03-13 01:41:11 --> Config Class Initialized
INFO - 2023-03-13 01:41:11 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:11 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:11 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:11 --> URI Class Initialized
INFO - 2023-03-13 01:41:11 --> Router Class Initialized
INFO - 2023-03-13 01:41:11 --> Output Class Initialized
INFO - 2023-03-13 01:41:11 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:11 --> Input Class Initialized
INFO - 2023-03-13 01:41:11 --> Language Class Initialized
INFO - 2023-03-13 01:41:11 --> Loader Class Initialized
INFO - 2023-03-13 01:41:11 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:11 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:11 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:41:11 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:11 --> Model "Login_model" initialized
INFO - 2023-03-13 01:41:11 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:11 --> Total execution time: 0.1294
INFO - 2023-03-13 01:41:16 --> Config Class Initialized
INFO - 2023-03-13 01:41:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:16 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:16 --> URI Class Initialized
INFO - 2023-03-13 01:41:16 --> Router Class Initialized
INFO - 2023-03-13 01:41:16 --> Output Class Initialized
INFO - 2023-03-13 01:41:16 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:16 --> Input Class Initialized
INFO - 2023-03-13 01:41:16 --> Language Class Initialized
INFO - 2023-03-13 01:41:16 --> Loader Class Initialized
INFO - 2023-03-13 01:41:16 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:16 --> Model "Login_model" initialized
INFO - 2023-03-13 01:41:16 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:16 --> Total execution time: 0.0273
INFO - 2023-03-13 01:41:16 --> Config Class Initialized
INFO - 2023-03-13 01:41:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:41:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:41:16 --> Utf8 Class Initialized
INFO - 2023-03-13 01:41:16 --> URI Class Initialized
INFO - 2023-03-13 01:41:16 --> Router Class Initialized
INFO - 2023-03-13 01:41:16 --> Output Class Initialized
INFO - 2023-03-13 01:41:16 --> Security Class Initialized
DEBUG - 2023-03-13 01:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:41:16 --> Input Class Initialized
INFO - 2023-03-13 01:41:16 --> Language Class Initialized
INFO - 2023-03-13 01:41:16 --> Loader Class Initialized
INFO - 2023-03-13 01:41:16 --> Controller Class Initialized
DEBUG - 2023-03-13 01:41:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:41:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:41:16 --> Model "Login_model" initialized
INFO - 2023-03-13 01:41:16 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:16 --> Total execution time: 0.0215
INFO - 2023-03-13 01:41:24 --> Final output sent to browser
DEBUG - 2023-03-13 01:41:24 --> Total execution time: 30.0618
INFO - 2023-03-13 01:54:16 --> Config Class Initialized
INFO - 2023-03-13 01:54:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:54:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:54:16 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:16 --> URI Class Initialized
INFO - 2023-03-13 01:54:16 --> Router Class Initialized
INFO - 2023-03-13 01:54:16 --> Output Class Initialized
INFO - 2023-03-13 01:54:16 --> Security Class Initialized
DEBUG - 2023-03-13 01:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:54:16 --> Input Class Initialized
INFO - 2023-03-13 01:54:16 --> Language Class Initialized
INFO - 2023-03-13 01:54:16 --> Loader Class Initialized
INFO - 2023-03-13 01:54:16 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:54:16 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:16 --> Total execution time: 0.0544
INFO - 2023-03-13 01:54:16 --> Config Class Initialized
INFO - 2023-03-13 01:54:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:54:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:54:16 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:16 --> URI Class Initialized
INFO - 2023-03-13 01:54:16 --> Router Class Initialized
INFO - 2023-03-13 01:54:16 --> Output Class Initialized
INFO - 2023-03-13 01:54:16 --> Security Class Initialized
DEBUG - 2023-03-13 01:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:54:16 --> Input Class Initialized
INFO - 2023-03-13 01:54:16 --> Language Class Initialized
INFO - 2023-03-13 01:54:16 --> Loader Class Initialized
INFO - 2023-03-13 01:54:16 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:16 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:54:16 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:16 --> Total execution time: 0.0927
INFO - 2023-03-13 01:54:19 --> Config Class Initialized
INFO - 2023-03-13 01:54:19 --> Config Class Initialized
INFO - 2023-03-13 01:54:19 --> Hooks Class Initialized
INFO - 2023-03-13 01:54:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:54:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 01:54:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:54:19 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:19 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:19 --> URI Class Initialized
INFO - 2023-03-13 01:54:19 --> URI Class Initialized
INFO - 2023-03-13 01:54:19 --> Router Class Initialized
INFO - 2023-03-13 01:54:19 --> Router Class Initialized
INFO - 2023-03-13 01:54:19 --> Output Class Initialized
INFO - 2023-03-13 01:54:19 --> Output Class Initialized
INFO - 2023-03-13 01:54:19 --> Security Class Initialized
INFO - 2023-03-13 01:54:19 --> Security Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:54:19 --> Input Class Initialized
INFO - 2023-03-13 01:54:19 --> Input Class Initialized
INFO - 2023-03-13 01:54:19 --> Language Class Initialized
INFO - 2023-03-13 01:54:19 --> Language Class Initialized
INFO - 2023-03-13 01:54:19 --> Loader Class Initialized
INFO - 2023-03-13 01:54:19 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:19 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:19 --> Loader Class Initialized
INFO - 2023-03-13 01:54:19 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:19 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:19 --> Total execution time: 0.0077
INFO - 2023-03-13 01:54:19 --> Config Class Initialized
INFO - 2023-03-13 01:54:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:54:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:54:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:54:19 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:19 --> URI Class Initialized
INFO - 2023-03-13 01:54:19 --> Router Class Initialized
INFO - 2023-03-13 01:54:19 --> Output Class Initialized
INFO - 2023-03-13 01:54:19 --> Security Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:54:19 --> Input Class Initialized
INFO - 2023-03-13 01:54:19 --> Language Class Initialized
INFO - 2023-03-13 01:54:19 --> Loader Class Initialized
INFO - 2023-03-13 01:54:19 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:19 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:19 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:19 --> Total execution time: 0.0546
INFO - 2023-03-13 01:54:19 --> Config Class Initialized
INFO - 2023-03-13 01:54:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:54:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:54:19 --> Utf8 Class Initialized
INFO - 2023-03-13 01:54:19 --> URI Class Initialized
INFO - 2023-03-13 01:54:19 --> Router Class Initialized
INFO - 2023-03-13 01:54:19 --> Output Class Initialized
INFO - 2023-03-13 01:54:19 --> Security Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:54:19 --> Input Class Initialized
INFO - 2023-03-13 01:54:19 --> Language Class Initialized
INFO - 2023-03-13 01:54:19 --> Loader Class Initialized
INFO - 2023-03-13 01:54:19 --> Controller Class Initialized
DEBUG - 2023-03-13 01:54:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:54:19 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:19 --> Model "Login_model" initialized
INFO - 2023-03-13 01:54:19 --> Database Driver Class Initialized
INFO - 2023-03-13 01:54:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:54:19 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:19 --> Total execution time: 0.0137
INFO - 2023-03-13 01:54:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:54:19 --> Final output sent to browser
DEBUG - 2023-03-13 01:54:19 --> Total execution time: 0.1016
INFO - 2023-03-13 01:55:26 --> Config Class Initialized
INFO - 2023-03-13 01:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:55:26 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:26 --> URI Class Initialized
INFO - 2023-03-13 01:55:26 --> Router Class Initialized
INFO - 2023-03-13 01:55:26 --> Output Class Initialized
INFO - 2023-03-13 01:55:26 --> Security Class Initialized
DEBUG - 2023-03-13 01:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:55:26 --> Input Class Initialized
INFO - 2023-03-13 01:55:26 --> Language Class Initialized
INFO - 2023-03-13 01:55:26 --> Loader Class Initialized
INFO - 2023-03-13 01:55:26 --> Controller Class Initialized
DEBUG - 2023-03-13 01:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:55:26 --> Database Driver Class Initialized
INFO - 2023-03-13 01:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:55:26 --> Final output sent to browser
DEBUG - 2023-03-13 01:55:26 --> Total execution time: 0.0574
INFO - 2023-03-13 01:55:26 --> Config Class Initialized
INFO - 2023-03-13 01:55:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:55:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:55:26 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:26 --> URI Class Initialized
INFO - 2023-03-13 01:55:26 --> Router Class Initialized
INFO - 2023-03-13 01:55:26 --> Output Class Initialized
INFO - 2023-03-13 01:55:26 --> Security Class Initialized
DEBUG - 2023-03-13 01:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:55:26 --> Input Class Initialized
INFO - 2023-03-13 01:55:26 --> Language Class Initialized
INFO - 2023-03-13 01:55:26 --> Loader Class Initialized
INFO - 2023-03-13 01:55:26 --> Controller Class Initialized
DEBUG - 2023-03-13 01:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:55:26 --> Database Driver Class Initialized
INFO - 2023-03-13 01:55:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:55:26 --> Final output sent to browser
DEBUG - 2023-03-13 01:55:26 --> Total execution time: 0.0964
INFO - 2023-03-13 01:55:33 --> Config Class Initialized
INFO - 2023-03-13 01:55:33 --> Config Class Initialized
INFO - 2023-03-13 01:55:33 --> Hooks Class Initialized
INFO - 2023-03-13 01:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:55:33 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 01:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:55:33 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:33 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:33 --> URI Class Initialized
INFO - 2023-03-13 01:55:33 --> URI Class Initialized
INFO - 2023-03-13 01:55:33 --> Router Class Initialized
INFO - 2023-03-13 01:55:33 --> Router Class Initialized
INFO - 2023-03-13 01:55:33 --> Output Class Initialized
INFO - 2023-03-13 01:55:33 --> Output Class Initialized
INFO - 2023-03-13 01:55:33 --> Security Class Initialized
INFO - 2023-03-13 01:55:33 --> Security Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 01:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:55:33 --> Input Class Initialized
INFO - 2023-03-13 01:55:33 --> Input Class Initialized
INFO - 2023-03-13 01:55:33 --> Language Class Initialized
INFO - 2023-03-13 01:55:33 --> Language Class Initialized
INFO - 2023-03-13 01:55:33 --> Loader Class Initialized
INFO - 2023-03-13 01:55:33 --> Loader Class Initialized
INFO - 2023-03-13 01:55:33 --> Controller Class Initialized
INFO - 2023-03-13 01:55:33 --> Controller Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 01:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:55:33 --> Final output sent to browser
DEBUG - 2023-03-13 01:55:33 --> Total execution time: 0.0034
INFO - 2023-03-13 01:55:33 --> Database Driver Class Initialized
INFO - 2023-03-13 01:55:33 --> Config Class Initialized
INFO - 2023-03-13 01:55:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:55:33 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:33 --> URI Class Initialized
INFO - 2023-03-13 01:55:33 --> Router Class Initialized
INFO - 2023-03-13 01:55:33 --> Output Class Initialized
INFO - 2023-03-13 01:55:33 --> Security Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:55:33 --> Input Class Initialized
INFO - 2023-03-13 01:55:33 --> Language Class Initialized
INFO - 2023-03-13 01:55:33 --> Loader Class Initialized
INFO - 2023-03-13 01:55:33 --> Controller Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:55:33 --> Final output sent to browser
INFO - 2023-03-13 01:55:33 --> Database Driver Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Total execution time: 0.0503
INFO - 2023-03-13 01:55:33 --> Config Class Initialized
INFO - 2023-03-13 01:55:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:55:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:55:33 --> Utf8 Class Initialized
INFO - 2023-03-13 01:55:33 --> URI Class Initialized
INFO - 2023-03-13 01:55:33 --> Router Class Initialized
INFO - 2023-03-13 01:55:33 --> Output Class Initialized
INFO - 2023-03-13 01:55:33 --> Security Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:55:33 --> Input Class Initialized
INFO - 2023-03-13 01:55:33 --> Language Class Initialized
INFO - 2023-03-13 01:55:33 --> Loader Class Initialized
INFO - 2023-03-13 01:55:33 --> Controller Class Initialized
DEBUG - 2023-03-13 01:55:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:55:33 --> Database Driver Class Initialized
INFO - 2023-03-13 01:55:33 --> Model "Login_model" initialized
INFO - 2023-03-13 01:55:33 --> Database Driver Class Initialized
INFO - 2023-03-13 01:55:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:55:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:55:33 --> Final output sent to browser
DEBUG - 2023-03-13 01:55:33 --> Total execution time: 0.0629
INFO - 2023-03-13 01:55:33 --> Final output sent to browser
DEBUG - 2023-03-13 01:55:33 --> Total execution time: 0.0621
INFO - 2023-03-13 01:56:25 --> Config Class Initialized
INFO - 2023-03-13 01:56:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:56:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:56:25 --> Utf8 Class Initialized
INFO - 2023-03-13 01:56:25 --> URI Class Initialized
INFO - 2023-03-13 01:56:25 --> Router Class Initialized
INFO - 2023-03-13 01:56:25 --> Output Class Initialized
INFO - 2023-03-13 01:56:25 --> Security Class Initialized
DEBUG - 2023-03-13 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:56:25 --> Input Class Initialized
INFO - 2023-03-13 01:56:25 --> Language Class Initialized
INFO - 2023-03-13 01:56:25 --> Loader Class Initialized
INFO - 2023-03-13 01:56:25 --> Controller Class Initialized
DEBUG - 2023-03-13 01:56:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:56:25 --> Database Driver Class Initialized
INFO - 2023-03-13 01:56:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:56:25 --> Final output sent to browser
DEBUG - 2023-03-13 01:56:25 --> Total execution time: 0.0464
INFO - 2023-03-13 01:56:25 --> Config Class Initialized
INFO - 2023-03-13 01:56:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 01:56:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 01:56:25 --> Utf8 Class Initialized
INFO - 2023-03-13 01:56:25 --> URI Class Initialized
INFO - 2023-03-13 01:56:25 --> Router Class Initialized
INFO - 2023-03-13 01:56:25 --> Output Class Initialized
INFO - 2023-03-13 01:56:25 --> Security Class Initialized
DEBUG - 2023-03-13 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 01:56:25 --> Input Class Initialized
INFO - 2023-03-13 01:56:25 --> Language Class Initialized
INFO - 2023-03-13 01:56:25 --> Loader Class Initialized
INFO - 2023-03-13 01:56:25 --> Controller Class Initialized
DEBUG - 2023-03-13 01:56:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 01:56:25 --> Database Driver Class Initialized
INFO - 2023-03-13 01:56:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 01:56:25 --> Final output sent to browser
DEBUG - 2023-03-13 01:56:25 --> Total execution time: 0.0395
INFO - 2023-03-13 02:01:45 --> Config Class Initialized
INFO - 2023-03-13 02:01:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:45 --> URI Class Initialized
INFO - 2023-03-13 02:01:45 --> Router Class Initialized
INFO - 2023-03-13 02:01:45 --> Output Class Initialized
INFO - 2023-03-13 02:01:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:46 --> Input Class Initialized
INFO - 2023-03-13 02:01:46 --> Language Class Initialized
INFO - 2023-03-13 02:01:46 --> Loader Class Initialized
INFO - 2023-03-13 02:01:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:46 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:46 --> Total execution time: 0.0207
INFO - 2023-03-13 02:01:46 --> Config Class Initialized
INFO - 2023-03-13 02:01:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:46 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:46 --> URI Class Initialized
INFO - 2023-03-13 02:01:46 --> Router Class Initialized
INFO - 2023-03-13 02:01:46 --> Output Class Initialized
INFO - 2023-03-13 02:01:46 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:46 --> Input Class Initialized
INFO - 2023-03-13 02:01:46 --> Language Class Initialized
INFO - 2023-03-13 02:01:46 --> Loader Class Initialized
INFO - 2023-03-13 02:01:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:46 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:46 --> Total execution time: 0.0534
INFO - 2023-03-13 02:01:47 --> Config Class Initialized
INFO - 2023-03-13 02:01:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:47 --> URI Class Initialized
INFO - 2023-03-13 02:01:47 --> Config Class Initialized
INFO - 2023-03-13 02:01:47 --> Router Class Initialized
INFO - 2023-03-13 02:01:47 --> Output Class Initialized
INFO - 2023-03-13 02:01:47 --> Hooks Class Initialized
INFO - 2023-03-13 02:01:47 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:47 --> URI Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:47 --> Input Class Initialized
INFO - 2023-03-13 02:01:47 --> Router Class Initialized
INFO - 2023-03-13 02:01:47 --> Language Class Initialized
INFO - 2023-03-13 02:01:47 --> Output Class Initialized
INFO - 2023-03-13 02:01:47 --> Loader Class Initialized
INFO - 2023-03-13 02:01:47 --> Security Class Initialized
INFO - 2023-03-13 02:01:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 02:01:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:47 --> Input Class Initialized
INFO - 2023-03-13 02:01:47 --> Language Class Initialized
INFO - 2023-03-13 02:01:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:47 --> Loader Class Initialized
INFO - 2023-03-13 02:01:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:47 --> Total execution time: 0.0141
INFO - 2023-03-13 02:01:47 --> Config Class Initialized
INFO - 2023-03-13 02:01:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:47 --> URI Class Initialized
INFO - 2023-03-13 02:01:47 --> Router Class Initialized
INFO - 2023-03-13 02:01:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:47 --> Output Class Initialized
INFO - 2023-03-13 02:01:47 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:47 --> Input Class Initialized
INFO - 2023-03-13 02:01:47 --> Language Class Initialized
INFO - 2023-03-13 02:01:47 --> Loader Class Initialized
INFO - 2023-03-13 02:01:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:47 --> Total execution time: 0.0288
INFO - 2023-03-13 02:01:47 --> Config Class Initialized
INFO - 2023-03-13 02:01:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:47 --> URI Class Initialized
INFO - 2023-03-13 02:01:47 --> Router Class Initialized
INFO - 2023-03-13 02:01:47 --> Output Class Initialized
INFO - 2023-03-13 02:01:47 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:47 --> Input Class Initialized
INFO - 2023-03-13 02:01:47 --> Language Class Initialized
INFO - 2023-03-13 02:01:47 --> Loader Class Initialized
INFO - 2023-03-13 02:01:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:47 --> Model "Login_model" initialized
INFO - 2023-03-13 02:01:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:47 --> Total execution time: 0.0151
INFO - 2023-03-13 02:01:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:47 --> Total execution time: 0.0242
INFO - 2023-03-13 02:01:50 --> Config Class Initialized
INFO - 2023-03-13 02:01:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:50 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:50 --> URI Class Initialized
INFO - 2023-03-13 02:01:50 --> Router Class Initialized
INFO - 2023-03-13 02:01:50 --> Output Class Initialized
INFO - 2023-03-13 02:01:50 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:50 --> Input Class Initialized
INFO - 2023-03-13 02:01:50 --> Language Class Initialized
INFO - 2023-03-13 02:01:50 --> Loader Class Initialized
INFO - 2023-03-13 02:01:50 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:50 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:50 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:50 --> Model "Login_model" initialized
INFO - 2023-03-13 02:01:50 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:50 --> Total execution time: 0.0374
INFO - 2023-03-13 02:01:50 --> Config Class Initialized
INFO - 2023-03-13 02:01:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:01:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:01:50 --> Utf8 Class Initialized
INFO - 2023-03-13 02:01:50 --> URI Class Initialized
INFO - 2023-03-13 02:01:50 --> Router Class Initialized
INFO - 2023-03-13 02:01:50 --> Output Class Initialized
INFO - 2023-03-13 02:01:50 --> Security Class Initialized
DEBUG - 2023-03-13 02:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:01:50 --> Input Class Initialized
INFO - 2023-03-13 02:01:50 --> Language Class Initialized
INFO - 2023-03-13 02:01:50 --> Loader Class Initialized
INFO - 2023-03-13 02:01:50 --> Controller Class Initialized
DEBUG - 2023-03-13 02:01:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:01:50 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:01:50 --> Database Driver Class Initialized
INFO - 2023-03-13 02:01:50 --> Model "Login_model" initialized
INFO - 2023-03-13 02:01:50 --> Final output sent to browser
DEBUG - 2023-03-13 02:01:50 --> Total execution time: 0.0743
INFO - 2023-03-13 02:02:20 --> Config Class Initialized
INFO - 2023-03-13 02:02:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:20 --> URI Class Initialized
INFO - 2023-03-13 02:02:20 --> Router Class Initialized
INFO - 2023-03-13 02:02:20 --> Output Class Initialized
INFO - 2023-03-13 02:02:20 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:20 --> Input Class Initialized
INFO - 2023-03-13 02:02:20 --> Language Class Initialized
INFO - 2023-03-13 02:02:20 --> Loader Class Initialized
INFO - 2023-03-13 02:02:20 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:20 --> Total execution time: 0.0441
INFO - 2023-03-13 02:02:20 --> Config Class Initialized
INFO - 2023-03-13 02:02:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:20 --> URI Class Initialized
INFO - 2023-03-13 02:02:20 --> Router Class Initialized
INFO - 2023-03-13 02:02:20 --> Output Class Initialized
INFO - 2023-03-13 02:02:20 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:20 --> Input Class Initialized
INFO - 2023-03-13 02:02:20 --> Language Class Initialized
INFO - 2023-03-13 02:02:20 --> Loader Class Initialized
INFO - 2023-03-13 02:02:20 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:20 --> Total execution time: 0.0381
INFO - 2023-03-13 02:02:22 --> Config Class Initialized
INFO - 2023-03-13 02:02:22 --> Config Class Initialized
INFO - 2023-03-13 02:02:22 --> Hooks Class Initialized
INFO - 2023-03-13 02:02:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:22 --> Utf8 Class Initialized
DEBUG - 2023-03-13 02:02:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:22 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:22 --> URI Class Initialized
INFO - 2023-03-13 02:02:22 --> URI Class Initialized
INFO - 2023-03-13 02:02:22 --> Router Class Initialized
INFO - 2023-03-13 02:02:22 --> Router Class Initialized
INFO - 2023-03-13 02:02:22 --> Output Class Initialized
INFO - 2023-03-13 02:02:22 --> Output Class Initialized
INFO - 2023-03-13 02:02:22 --> Security Class Initialized
INFO - 2023-03-13 02:02:22 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:22 --> Input Class Initialized
INFO - 2023-03-13 02:02:22 --> Input Class Initialized
INFO - 2023-03-13 02:02:22 --> Language Class Initialized
INFO - 2023-03-13 02:02:22 --> Language Class Initialized
INFO - 2023-03-13 02:02:22 --> Loader Class Initialized
INFO - 2023-03-13 02:02:22 --> Loader Class Initialized
INFO - 2023-03-13 02:02:22 --> Controller Class Initialized
INFO - 2023-03-13 02:02:22 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 02:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:22 --> Final output sent to browser
INFO - 2023-03-13 02:02:22 --> Database Driver Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Total execution time: 0.0044
INFO - 2023-03-13 02:02:22 --> Config Class Initialized
INFO - 2023-03-13 02:02:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:22 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:22 --> URI Class Initialized
INFO - 2023-03-13 02:02:22 --> Router Class Initialized
INFO - 2023-03-13 02:02:22 --> Output Class Initialized
INFO - 2023-03-13 02:02:22 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:22 --> Input Class Initialized
INFO - 2023-03-13 02:02:22 --> Language Class Initialized
INFO - 2023-03-13 02:02:22 --> Loader Class Initialized
INFO - 2023-03-13 02:02:22 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:22 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:22 --> Final output sent to browser
INFO - 2023-03-13 02:02:22 --> Model "Login_model" initialized
DEBUG - 2023-03-13 02:02:22 --> Total execution time: 0.0184
INFO - 2023-03-13 02:02:22 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:22 --> Config Class Initialized
INFO - 2023-03-13 02:02:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:22 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:22 --> URI Class Initialized
INFO - 2023-03-13 02:02:22 --> Router Class Initialized
INFO - 2023-03-13 02:02:22 --> Output Class Initialized
INFO - 2023-03-13 02:02:22 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:22 --> Input Class Initialized
INFO - 2023-03-13 02:02:22 --> Language Class Initialized
INFO - 2023-03-13 02:02:22 --> Loader Class Initialized
INFO - 2023-03-13 02:02:22 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:22 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:23 --> Total execution time: 0.0215
INFO - 2023-03-13 02:02:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:23 --> Total execution time: 0.0536
INFO - 2023-03-13 02:02:23 --> Config Class Initialized
INFO - 2023-03-13 02:02:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:23 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:23 --> URI Class Initialized
INFO - 2023-03-13 02:02:23 --> Router Class Initialized
INFO - 2023-03-13 02:02:23 --> Output Class Initialized
INFO - 2023-03-13 02:02:23 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:23 --> Input Class Initialized
INFO - 2023-03-13 02:02:23 --> Language Class Initialized
INFO - 2023-03-13 02:02:23 --> Loader Class Initialized
INFO - 2023-03-13 02:02:23 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:23 --> Model "Login_model" initialized
INFO - 2023-03-13 02:02:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:23 --> Total execution time: 0.0441
INFO - 2023-03-13 02:02:23 --> Config Class Initialized
INFO - 2023-03-13 02:02:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:02:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:02:23 --> Utf8 Class Initialized
INFO - 2023-03-13 02:02:23 --> URI Class Initialized
INFO - 2023-03-13 02:02:23 --> Router Class Initialized
INFO - 2023-03-13 02:02:23 --> Output Class Initialized
INFO - 2023-03-13 02:02:23 --> Security Class Initialized
DEBUG - 2023-03-13 02:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:02:23 --> Input Class Initialized
INFO - 2023-03-13 02:02:23 --> Language Class Initialized
INFO - 2023-03-13 02:02:23 --> Loader Class Initialized
INFO - 2023-03-13 02:02:23 --> Controller Class Initialized
DEBUG - 2023-03-13 02:02:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:02:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:02:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:02:23 --> Model "Login_model" initialized
INFO - 2023-03-13 02:02:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:02:23 --> Total execution time: 0.0348
INFO - 2023-03-13 02:08:20 --> Config Class Initialized
INFO - 2023-03-13 02:08:20 --> Config Class Initialized
INFO - 2023-03-13 02:08:20 --> Hooks Class Initialized
INFO - 2023-03-13 02:08:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 02:08:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:20 --> URI Class Initialized
INFO - 2023-03-13 02:08:20 --> URI Class Initialized
INFO - 2023-03-13 02:08:20 --> Router Class Initialized
INFO - 2023-03-13 02:08:20 --> Router Class Initialized
INFO - 2023-03-13 02:08:20 --> Output Class Initialized
INFO - 2023-03-13 02:08:20 --> Security Class Initialized
INFO - 2023-03-13 02:08:20 --> Output Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:20 --> Security Class Initialized
INFO - 2023-03-13 02:08:20 --> Input Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:20 --> Language Class Initialized
INFO - 2023-03-13 02:08:20 --> Input Class Initialized
INFO - 2023-03-13 02:08:20 --> Loader Class Initialized
INFO - 2023-03-13 02:08:20 --> Language Class Initialized
INFO - 2023-03-13 02:08:20 --> Controller Class Initialized
INFO - 2023-03-13 02:08:20 --> Loader Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:20 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:20 --> Total execution time: 0.0052
INFO - 2023-03-13 02:08:20 --> Config Class Initialized
INFO - 2023-03-13 02:08:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:20 --> URI Class Initialized
INFO - 2023-03-13 02:08:20 --> Router Class Initialized
INFO - 2023-03-13 02:08:20 --> Output Class Initialized
INFO - 2023-03-13 02:08:20 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:20 --> Input Class Initialized
INFO - 2023-03-13 02:08:20 --> Language Class Initialized
INFO - 2023-03-13 02:08:20 --> Loader Class Initialized
INFO - 2023-03-13 02:08:20 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:20 --> Model "Login_model" initialized
INFO - 2023-03-13 02:08:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:20 --> Total execution time: 0.0166
INFO - 2023-03-13 02:08:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:20 --> Config Class Initialized
INFO - 2023-03-13 02:08:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:20 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:20 --> URI Class Initialized
INFO - 2023-03-13 02:08:20 --> Router Class Initialized
INFO - 2023-03-13 02:08:20 --> Output Class Initialized
INFO - 2023-03-13 02:08:20 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:20 --> Input Class Initialized
INFO - 2023-03-13 02:08:20 --> Language Class Initialized
INFO - 2023-03-13 02:08:20 --> Loader Class Initialized
INFO - 2023-03-13 02:08:20 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:20 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:20 --> Total execution time: 0.0192
INFO - 2023-03-13 02:08:20 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:20 --> Total execution time: 0.0122
INFO - 2023-03-13 02:08:23 --> Config Class Initialized
INFO - 2023-03-13 02:08:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:23 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:23 --> URI Class Initialized
INFO - 2023-03-13 02:08:23 --> Router Class Initialized
INFO - 2023-03-13 02:08:23 --> Output Class Initialized
INFO - 2023-03-13 02:08:23 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:23 --> Input Class Initialized
INFO - 2023-03-13 02:08:23 --> Language Class Initialized
INFO - 2023-03-13 02:08:23 --> Loader Class Initialized
INFO - 2023-03-13 02:08:23 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:23 --> Total execution time: 0.1199
INFO - 2023-03-13 02:08:23 --> Config Class Initialized
INFO - 2023-03-13 02:08:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:23 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:23 --> URI Class Initialized
INFO - 2023-03-13 02:08:23 --> Router Class Initialized
INFO - 2023-03-13 02:08:23 --> Output Class Initialized
INFO - 2023-03-13 02:08:23 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:23 --> Input Class Initialized
INFO - 2023-03-13 02:08:23 --> Language Class Initialized
INFO - 2023-03-13 02:08:23 --> Loader Class Initialized
INFO - 2023-03-13 02:08:23 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:23 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:23 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:23 --> Total execution time: 0.0400
INFO - 2023-03-13 02:08:25 --> Config Class Initialized
INFO - 2023-03-13 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:25 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:25 --> URI Class Initialized
INFO - 2023-03-13 02:08:25 --> Router Class Initialized
INFO - 2023-03-13 02:08:25 --> Output Class Initialized
INFO - 2023-03-13 02:08:25 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:25 --> Input Class Initialized
INFO - 2023-03-13 02:08:25 --> Language Class Initialized
INFO - 2023-03-13 02:08:25 --> Loader Class Initialized
INFO - 2023-03-13 02:08:25 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:25 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:25 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:25 --> Total execution time: 0.0182
INFO - 2023-03-13 02:08:25 --> Config Class Initialized
INFO - 2023-03-13 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:25 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:25 --> URI Class Initialized
INFO - 2023-03-13 02:08:25 --> Router Class Initialized
INFO - 2023-03-13 02:08:25 --> Output Class Initialized
INFO - 2023-03-13 02:08:25 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:25 --> Input Class Initialized
INFO - 2023-03-13 02:08:25 --> Language Class Initialized
INFO - 2023-03-13 02:08:25 --> Loader Class Initialized
INFO - 2023-03-13 02:08:25 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:25 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:25 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:25 --> Total execution time: 0.0528
INFO - 2023-03-13 02:08:27 --> Config Class Initialized
INFO - 2023-03-13 02:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:27 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:27 --> URI Class Initialized
INFO - 2023-03-13 02:08:27 --> Router Class Initialized
INFO - 2023-03-13 02:08:27 --> Output Class Initialized
INFO - 2023-03-13 02:08:27 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:27 --> Input Class Initialized
INFO - 2023-03-13 02:08:27 --> Language Class Initialized
INFO - 2023-03-13 02:08:27 --> Loader Class Initialized
INFO - 2023-03-13 02:08:27 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:27 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:27 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:27 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:27 --> Model "Login_model" initialized
INFO - 2023-03-13 02:08:27 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:27 --> Total execution time: 0.0394
INFO - 2023-03-13 02:08:27 --> Config Class Initialized
INFO - 2023-03-13 02:08:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:27 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:27 --> URI Class Initialized
INFO - 2023-03-13 02:08:27 --> Router Class Initialized
INFO - 2023-03-13 02:08:27 --> Output Class Initialized
INFO - 2023-03-13 02:08:27 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:27 --> Input Class Initialized
INFO - 2023-03-13 02:08:27 --> Language Class Initialized
INFO - 2023-03-13 02:08:27 --> Loader Class Initialized
INFO - 2023-03-13 02:08:27 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:27 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:27 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:27 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:27 --> Model "Login_model" initialized
INFO - 2023-03-13 02:08:27 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:27 --> Total execution time: 0.0356
INFO - 2023-03-13 02:08:45 --> Config Class Initialized
INFO - 2023-03-13 02:08:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:45 --> URI Class Initialized
INFO - 2023-03-13 02:08:45 --> Router Class Initialized
INFO - 2023-03-13 02:08:45 --> Output Class Initialized
INFO - 2023-03-13 02:08:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:45 --> Input Class Initialized
INFO - 2023-03-13 02:08:45 --> Language Class Initialized
INFO - 2023-03-13 02:08:45 --> Loader Class Initialized
INFO - 2023-03-13 02:08:45 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:45 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:45 --> Total execution time: 0.0164
INFO - 2023-03-13 02:08:45 --> Config Class Initialized
INFO - 2023-03-13 02:08:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:45 --> URI Class Initialized
INFO - 2023-03-13 02:08:45 --> Router Class Initialized
INFO - 2023-03-13 02:08:45 --> Output Class Initialized
INFO - 2023-03-13 02:08:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:45 --> Input Class Initialized
INFO - 2023-03-13 02:08:45 --> Language Class Initialized
INFO - 2023-03-13 02:08:45 --> Loader Class Initialized
INFO - 2023-03-13 02:08:45 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:45 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:45 --> Total execution time: 0.0111
INFO - 2023-03-13 02:08:47 --> Config Class Initialized
INFO - 2023-03-13 02:08:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:47 --> URI Class Initialized
INFO - 2023-03-13 02:08:47 --> Router Class Initialized
INFO - 2023-03-13 02:08:47 --> Output Class Initialized
INFO - 2023-03-13 02:08:47 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:47 --> Input Class Initialized
INFO - 2023-03-13 02:08:47 --> Language Class Initialized
INFO - 2023-03-13 02:08:47 --> Loader Class Initialized
INFO - 2023-03-13 02:08:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:47 --> Total execution time: 0.0698
INFO - 2023-03-13 02:08:47 --> Config Class Initialized
INFO - 2023-03-13 02:08:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:47 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:47 --> URI Class Initialized
INFO - 2023-03-13 02:08:47 --> Router Class Initialized
INFO - 2023-03-13 02:08:47 --> Output Class Initialized
INFO - 2023-03-13 02:08:47 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:47 --> Input Class Initialized
INFO - 2023-03-13 02:08:47 --> Language Class Initialized
INFO - 2023-03-13 02:08:47 --> Loader Class Initialized
INFO - 2023-03-13 02:08:47 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:47 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:47 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:47 --> Total execution time: 0.0410
INFO - 2023-03-13 02:08:49 --> Config Class Initialized
INFO - 2023-03-13 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:49 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:49 --> URI Class Initialized
INFO - 2023-03-13 02:08:49 --> Router Class Initialized
INFO - 2023-03-13 02:08:49 --> Output Class Initialized
INFO - 2023-03-13 02:08:49 --> Security Class Initialized
INFO - 2023-03-13 02:08:49 --> Config Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:49 --> Hooks Class Initialized
INFO - 2023-03-13 02:08:49 --> Input Class Initialized
DEBUG - 2023-03-13 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:49 --> Language Class Initialized
INFO - 2023-03-13 02:08:49 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:49 --> Loader Class Initialized
INFO - 2023-03-13 02:08:49 --> URI Class Initialized
INFO - 2023-03-13 02:08:49 --> Controller Class Initialized
INFO - 2023-03-13 02:08:49 --> Router Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:49 --> Output Class Initialized
INFO - 2023-03-13 02:08:49 --> Security Class Initialized
INFO - 2023-03-13 02:08:49 --> Database Driver Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:49 --> Input Class Initialized
INFO - 2023-03-13 02:08:49 --> Language Class Initialized
INFO - 2023-03-13 02:08:49 --> Loader Class Initialized
INFO - 2023-03-13 02:08:49 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:49 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:49 --> Total execution time: 0.0018
INFO - 2023-03-13 02:08:49 --> Config Class Initialized
INFO - 2023-03-13 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:49 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:49 --> URI Class Initialized
INFO - 2023-03-13 02:08:49 --> Router Class Initialized
INFO - 2023-03-13 02:08:49 --> Output Class Initialized
INFO - 2023-03-13 02:08:49 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:49 --> Input Class Initialized
INFO - 2023-03-13 02:08:49 --> Language Class Initialized
INFO - 2023-03-13 02:08:49 --> Loader Class Initialized
INFO - 2023-03-13 02:08:49 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:49 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:49 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:49 --> Total execution time: 0.0146
INFO - 2023-03-13 02:08:49 --> Config Class Initialized
INFO - 2023-03-13 02:08:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:08:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:08:49 --> Utf8 Class Initialized
INFO - 2023-03-13 02:08:49 --> URI Class Initialized
INFO - 2023-03-13 02:08:49 --> Model "Login_model" initialized
INFO - 2023-03-13 02:08:49 --> Router Class Initialized
INFO - 2023-03-13 02:08:49 --> Output Class Initialized
INFO - 2023-03-13 02:08:49 --> Security Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:08:49 --> Input Class Initialized
INFO - 2023-03-13 02:08:49 --> Language Class Initialized
INFO - 2023-03-13 02:08:49 --> Loader Class Initialized
INFO - 2023-03-13 02:08:49 --> Controller Class Initialized
DEBUG - 2023-03-13 02:08:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:08:49 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:49 --> Database Driver Class Initialized
INFO - 2023-03-13 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:08:49 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:49 --> Total execution time: 0.0197
INFO - 2023-03-13 02:08:49 --> Final output sent to browser
DEBUG - 2023-03-13 02:08:49 --> Total execution time: 0.0125
INFO - 2023-03-13 02:16:44 --> Config Class Initialized
INFO - 2023-03-13 02:16:44 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:44 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:44 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:44 --> URI Class Initialized
INFO - 2023-03-13 02:16:44 --> Router Class Initialized
INFO - 2023-03-13 02:16:44 --> Output Class Initialized
INFO - 2023-03-13 02:16:44 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:44 --> Input Class Initialized
INFO - 2023-03-13 02:16:44 --> Language Class Initialized
INFO - 2023-03-13 02:16:44 --> Loader Class Initialized
INFO - 2023-03-13 02:16:44 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:44 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:44 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:44 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:44 --> Total execution time: 0.0161
INFO - 2023-03-13 02:16:44 --> Config Class Initialized
INFO - 2023-03-13 02:16:44 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:44 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:44 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:44 --> URI Class Initialized
INFO - 2023-03-13 02:16:44 --> Router Class Initialized
INFO - 2023-03-13 02:16:44 --> Output Class Initialized
INFO - 2023-03-13 02:16:44 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:44 --> Input Class Initialized
INFO - 2023-03-13 02:16:44 --> Language Class Initialized
INFO - 2023-03-13 02:16:44 --> Loader Class Initialized
INFO - 2023-03-13 02:16:44 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:44 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:44 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:44 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:44 --> Total execution time: 0.0131
INFO - 2023-03-13 02:16:46 --> Config Class Initialized
INFO - 2023-03-13 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:46 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:46 --> URI Class Initialized
INFO - 2023-03-13 02:16:46 --> Router Class Initialized
INFO - 2023-03-13 02:16:46 --> Output Class Initialized
INFO - 2023-03-13 02:16:46 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:46 --> Input Class Initialized
INFO - 2023-03-13 02:16:46 --> Language Class Initialized
INFO - 2023-03-13 02:16:46 --> Loader Class Initialized
INFO - 2023-03-13 02:16:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:46 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:46 --> Total execution time: 0.0435
INFO - 2023-03-13 02:16:46 --> Config Class Initialized
INFO - 2023-03-13 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:46 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:46 --> URI Class Initialized
INFO - 2023-03-13 02:16:46 --> Router Class Initialized
INFO - 2023-03-13 02:16:46 --> Output Class Initialized
INFO - 2023-03-13 02:16:46 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:46 --> Input Class Initialized
INFO - 2023-03-13 02:16:46 --> Language Class Initialized
INFO - 2023-03-13 02:16:46 --> Loader Class Initialized
INFO - 2023-03-13 02:16:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:46 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:46 --> Total execution time: 0.0387
INFO - 2023-03-13 02:16:48 --> Config Class Initialized
INFO - 2023-03-13 02:16:48 --> Config Class Initialized
INFO - 2023-03-13 02:16:48 --> Hooks Class Initialized
INFO - 2023-03-13 02:16:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:48 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 02:16:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:48 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:48 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:48 --> URI Class Initialized
INFO - 2023-03-13 02:16:48 --> URI Class Initialized
INFO - 2023-03-13 02:16:48 --> Router Class Initialized
INFO - 2023-03-13 02:16:48 --> Router Class Initialized
INFO - 2023-03-13 02:16:48 --> Output Class Initialized
INFO - 2023-03-13 02:16:48 --> Output Class Initialized
INFO - 2023-03-13 02:16:48 --> Security Class Initialized
INFO - 2023-03-13 02:16:48 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 02:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:48 --> Input Class Initialized
INFO - 2023-03-13 02:16:48 --> Input Class Initialized
INFO - 2023-03-13 02:16:48 --> Language Class Initialized
INFO - 2023-03-13 02:16:48 --> Language Class Initialized
INFO - 2023-03-13 02:16:48 --> Loader Class Initialized
INFO - 2023-03-13 02:16:48 --> Controller Class Initialized
INFO - 2023-03-13 02:16:48 --> Loader Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:48 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:48 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:48 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:48 --> Total execution time: 0.0048
INFO - 2023-03-13 02:16:48 --> Config Class Initialized
INFO - 2023-03-13 02:16:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:16:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:48 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:48 --> URI Class Initialized
INFO - 2023-03-13 02:16:48 --> Router Class Initialized
INFO - 2023-03-13 02:16:48 --> Output Class Initialized
INFO - 2023-03-13 02:16:48 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:48 --> Input Class Initialized
INFO - 2023-03-13 02:16:48 --> Language Class Initialized
INFO - 2023-03-13 02:16:48 --> Loader Class Initialized
INFO - 2023-03-13 02:16:48 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:48 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:48 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:48 --> Total execution time: 0.0160
INFO - 2023-03-13 02:16:48 --> Model "Login_model" initialized
INFO - 2023-03-13 02:16:48 --> Config Class Initialized
INFO - 2023-03-13 02:16:48 --> Hooks Class Initialized
INFO - 2023-03-13 02:16:48 --> Database Driver Class Initialized
DEBUG - 2023-03-13 02:16:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:16:48 --> Utf8 Class Initialized
INFO - 2023-03-13 02:16:48 --> URI Class Initialized
INFO - 2023-03-13 02:16:48 --> Router Class Initialized
INFO - 2023-03-13 02:16:48 --> Output Class Initialized
INFO - 2023-03-13 02:16:48 --> Security Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:16:48 --> Input Class Initialized
INFO - 2023-03-13 02:16:48 --> Language Class Initialized
INFO - 2023-03-13 02:16:48 --> Loader Class Initialized
INFO - 2023-03-13 02:16:48 --> Controller Class Initialized
DEBUG - 2023-03-13 02:16:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:16:48 --> Database Driver Class Initialized
INFO - 2023-03-13 02:16:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:48 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:48 --> Total execution time: 0.0219
INFO - 2023-03-13 02:16:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:16:48 --> Final output sent to browser
DEBUG - 2023-03-13 02:16:48 --> Total execution time: 0.0208
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
INFO - 2023-03-13 02:45:34 --> Helper loaded: form_helper
INFO - 2023-03-13 02:45:34 --> Helper loaded: url_helper
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Model "Change_model" initialized
INFO - 2023-03-13 02:45:34 --> Model "Grafana_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0300
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
INFO - 2023-03-13 02:45:34 --> Helper loaded: form_helper
INFO - 2023-03-13 02:45:34 --> Helper loaded: url_helper
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0038
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
INFO - 2023-03-13 02:45:34 --> Helper loaded: form_helper
INFO - 2023-03-13 02:45:34 --> Helper loaded: url_helper
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Login_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0157
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0542
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0133
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Login_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0750
INFO - 2023-03-13 02:45:34 --> Config Class Initialized
INFO - 2023-03-13 02:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:34 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:34 --> URI Class Initialized
INFO - 2023-03-13 02:45:34 --> Router Class Initialized
INFO - 2023-03-13 02:45:34 --> Output Class Initialized
INFO - 2023-03-13 02:45:34 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:34 --> Input Class Initialized
INFO - 2023-03-13 02:45:34 --> Language Class Initialized
INFO - 2023-03-13 02:45:34 --> Loader Class Initialized
INFO - 2023-03-13 02:45:34 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:34 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:34 --> Model "Login_model" initialized
INFO - 2023-03-13 02:45:34 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:34 --> Total execution time: 0.0746
INFO - 2023-03-13 02:45:38 --> Config Class Initialized
INFO - 2023-03-13 02:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:38 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:38 --> URI Class Initialized
INFO - 2023-03-13 02:45:38 --> Router Class Initialized
INFO - 2023-03-13 02:45:38 --> Output Class Initialized
INFO - 2023-03-13 02:45:38 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:38 --> Input Class Initialized
INFO - 2023-03-13 02:45:38 --> Language Class Initialized
INFO - 2023-03-13 02:45:38 --> Loader Class Initialized
INFO - 2023-03-13 02:45:38 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:38 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:38 --> Total execution time: 0.0063
INFO - 2023-03-13 02:45:38 --> Config Class Initialized
INFO - 2023-03-13 02:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:38 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:38 --> URI Class Initialized
INFO - 2023-03-13 02:45:38 --> Router Class Initialized
INFO - 2023-03-13 02:45:38 --> Output Class Initialized
INFO - 2023-03-13 02:45:38 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:38 --> Input Class Initialized
INFO - 2023-03-13 02:45:38 --> Language Class Initialized
INFO - 2023-03-13 02:45:38 --> Loader Class Initialized
INFO - 2023-03-13 02:45:38 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:38 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:38 --> Total execution time: 0.0025
INFO - 2023-03-13 02:45:45 --> Config Class Initialized
INFO - 2023-03-13 02:45:45 --> Config Class Initialized
INFO - 2023-03-13 02:45:45 --> Hooks Class Initialized
INFO - 2023-03-13 02:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:45 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 02:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:45 --> URI Class Initialized
INFO - 2023-03-13 02:45:45 --> URI Class Initialized
INFO - 2023-03-13 02:45:45 --> Router Class Initialized
INFO - 2023-03-13 02:45:45 --> Router Class Initialized
INFO - 2023-03-13 02:45:45 --> Output Class Initialized
INFO - 2023-03-13 02:45:45 --> Output Class Initialized
INFO - 2023-03-13 02:45:45 --> Security Class Initialized
INFO - 2023-03-13 02:45:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 02:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:45 --> Input Class Initialized
INFO - 2023-03-13 02:45:45 --> Input Class Initialized
INFO - 2023-03-13 02:45:45 --> Language Class Initialized
INFO - 2023-03-13 02:45:45 --> Language Class Initialized
INFO - 2023-03-13 02:45:45 --> Loader Class Initialized
INFO - 2023-03-13 02:45:45 --> Loader Class Initialized
INFO - 2023-03-13 02:45:45 --> Controller Class Initialized
INFO - 2023-03-13 02:45:45 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 02:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:45 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:45 --> Total execution time: 0.0170
INFO - 2023-03-13 02:45:45 --> Config Class Initialized
INFO - 2023-03-13 02:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:45 --> URI Class Initialized
INFO - 2023-03-13 02:45:45 --> Router Class Initialized
INFO - 2023-03-13 02:45:45 --> Output Class Initialized
INFO - 2023-03-13 02:45:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:45 --> Input Class Initialized
INFO - 2023-03-13 02:45:45 --> Language Class Initialized
INFO - 2023-03-13 02:45:45 --> Loader Class Initialized
INFO - 2023-03-13 02:45:45 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:45 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:45 --> Total execution time: 0.0498
INFO - 2023-03-13 02:45:45 --> Config Class Initialized
INFO - 2023-03-13 02:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:45 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:45 --> URI Class Initialized
INFO - 2023-03-13 02:45:45 --> Router Class Initialized
INFO - 2023-03-13 02:45:45 --> Output Class Initialized
INFO - 2023-03-13 02:45:45 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:45 --> Input Class Initialized
INFO - 2023-03-13 02:45:45 --> Language Class Initialized
INFO - 2023-03-13 02:45:45 --> Loader Class Initialized
INFO - 2023-03-13 02:45:45 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:45 --> Database Driver Class Initialized
INFO - 2023-03-13 02:45:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:45:46 --> Config Class Initialized
INFO - 2023-03-13 02:45:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:46 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:46 --> URI Class Initialized
INFO - 2023-03-13 02:45:46 --> Router Class Initialized
INFO - 2023-03-13 02:45:46 --> Output Class Initialized
INFO - 2023-03-13 02:45:46 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:46 --> Input Class Initialized
INFO - 2023-03-13 02:45:46 --> Language Class Initialized
INFO - 2023-03-13 02:45:46 --> Loader Class Initialized
INFO - 2023-03-13 02:45:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:46 --> Total execution time: 0.0051
INFO - 2023-03-13 02:45:46 --> Config Class Initialized
INFO - 2023-03-13 02:45:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:45:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:45:46 --> Utf8 Class Initialized
INFO - 2023-03-13 02:45:46 --> URI Class Initialized
INFO - 2023-03-13 02:45:46 --> Router Class Initialized
INFO - 2023-03-13 02:45:46 --> Output Class Initialized
INFO - 2023-03-13 02:45:46 --> Security Class Initialized
DEBUG - 2023-03-13 02:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:45:46 --> Input Class Initialized
INFO - 2023-03-13 02:45:46 --> Language Class Initialized
INFO - 2023-03-13 02:45:46 --> Loader Class Initialized
INFO - 2023-03-13 02:45:46 --> Controller Class Initialized
DEBUG - 2023-03-13 02:45:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:45:46 --> Final output sent to browser
DEBUG - 2023-03-13 02:45:46 --> Total execution time: 0.0023
INFO - 2023-03-13 02:46:54 --> Config Class Initialized
INFO - 2023-03-13 02:46:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:46:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:46:54 --> Utf8 Class Initialized
INFO - 2023-03-13 02:46:54 --> URI Class Initialized
INFO - 2023-03-13 02:46:54 --> Router Class Initialized
INFO - 2023-03-13 02:46:54 --> Output Class Initialized
INFO - 2023-03-13 02:46:54 --> Security Class Initialized
DEBUG - 2023-03-13 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:46:54 --> Input Class Initialized
INFO - 2023-03-13 02:46:54 --> Language Class Initialized
INFO - 2023-03-13 02:46:54 --> Loader Class Initialized
INFO - 2023-03-13 02:46:54 --> Controller Class Initialized
DEBUG - 2023-03-13 02:46:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:46:54 --> Database Driver Class Initialized
INFO - 2023-03-13 02:46:54 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:46:54 --> Database Driver Class Initialized
INFO - 2023-03-13 02:46:54 --> Model "Login_model" initialized
INFO - 2023-03-13 02:46:54 --> Final output sent to browser
DEBUG - 2023-03-13 02:46:54 --> Total execution time: 0.1334
INFO - 2023-03-13 02:46:54 --> Config Class Initialized
INFO - 2023-03-13 02:46:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:46:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:46:54 --> Utf8 Class Initialized
INFO - 2023-03-13 02:46:54 --> URI Class Initialized
INFO - 2023-03-13 02:46:54 --> Router Class Initialized
INFO - 2023-03-13 02:46:54 --> Output Class Initialized
INFO - 2023-03-13 02:46:54 --> Security Class Initialized
DEBUG - 2023-03-13 02:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:46:54 --> Input Class Initialized
INFO - 2023-03-13 02:46:54 --> Language Class Initialized
INFO - 2023-03-13 02:46:54 --> Loader Class Initialized
INFO - 2023-03-13 02:46:54 --> Controller Class Initialized
DEBUG - 2023-03-13 02:46:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:46:54 --> Database Driver Class Initialized
INFO - 2023-03-13 02:46:55 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:46:55 --> Database Driver Class Initialized
INFO - 2023-03-13 02:46:55 --> Model "Login_model" initialized
INFO - 2023-03-13 02:46:55 --> Final output sent to browser
DEBUG - 2023-03-13 02:46:55 --> Total execution time: 0.1218
INFO - 2023-03-13 02:47:01 --> Config Class Initialized
INFO - 2023-03-13 02:47:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:47:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:47:01 --> Utf8 Class Initialized
INFO - 2023-03-13 02:47:01 --> URI Class Initialized
INFO - 2023-03-13 02:47:01 --> Router Class Initialized
INFO - 2023-03-13 02:47:01 --> Output Class Initialized
INFO - 2023-03-13 02:47:01 --> Security Class Initialized
DEBUG - 2023-03-13 02:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:47:01 --> Input Class Initialized
INFO - 2023-03-13 02:47:01 --> Language Class Initialized
INFO - 2023-03-13 02:47:01 --> Loader Class Initialized
INFO - 2023-03-13 02:47:01 --> Controller Class Initialized
DEBUG - 2023-03-13 02:47:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:47:01 --> Final output sent to browser
DEBUG - 2023-03-13 02:47:01 --> Total execution time: 0.0594
INFO - 2023-03-13 02:47:01 --> Config Class Initialized
INFO - 2023-03-13 02:47:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:47:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:47:01 --> Utf8 Class Initialized
INFO - 2023-03-13 02:47:01 --> URI Class Initialized
INFO - 2023-03-13 02:47:01 --> Router Class Initialized
INFO - 2023-03-13 02:47:01 --> Output Class Initialized
INFO - 2023-03-13 02:47:01 --> Security Class Initialized
DEBUG - 2023-03-13 02:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:47:01 --> Input Class Initialized
INFO - 2023-03-13 02:47:01 --> Language Class Initialized
INFO - 2023-03-13 02:47:01 --> Loader Class Initialized
INFO - 2023-03-13 02:47:01 --> Controller Class Initialized
DEBUG - 2023-03-13 02:47:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:47:01 --> Final output sent to browser
DEBUG - 2023-03-13 02:47:01 --> Total execution time: 0.0537
INFO - 2023-03-13 02:50:10 --> Config Class Initialized
INFO - 2023-03-13 02:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:10 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:10 --> URI Class Initialized
INFO - 2023-03-13 02:50:10 --> Router Class Initialized
INFO - 2023-03-13 02:50:10 --> Output Class Initialized
INFO - 2023-03-13 02:50:10 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:10 --> Input Class Initialized
INFO - 2023-03-13 02:50:10 --> Language Class Initialized
INFO - 2023-03-13 02:50:10 --> Loader Class Initialized
INFO - 2023-03-13 02:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:10 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:10 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:10 --> Total execution time: 0.0652
INFO - 2023-03-13 02:50:10 --> Config Class Initialized
INFO - 2023-03-13 02:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:10 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:10 --> URI Class Initialized
INFO - 2023-03-13 02:50:10 --> Router Class Initialized
INFO - 2023-03-13 02:50:10 --> Output Class Initialized
INFO - 2023-03-13 02:50:10 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:10 --> Input Class Initialized
INFO - 2023-03-13 02:50:10 --> Language Class Initialized
INFO - 2023-03-13 02:50:10 --> Loader Class Initialized
INFO - 2023-03-13 02:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:10 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:10 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:10 --> Total execution time: 0.1961
INFO - 2023-03-13 02:50:16 --> Config Class Initialized
INFO - 2023-03-13 02:50:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:16 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:16 --> URI Class Initialized
INFO - 2023-03-13 02:50:16 --> Router Class Initialized
INFO - 2023-03-13 02:50:16 --> Output Class Initialized
INFO - 2023-03-13 02:50:16 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:16 --> Input Class Initialized
INFO - 2023-03-13 02:50:16 --> Language Class Initialized
INFO - 2023-03-13 02:50:16 --> Loader Class Initialized
INFO - 2023-03-13 02:50:16 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:16 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:16 --> Total execution time: 0.0614
INFO - 2023-03-13 02:50:16 --> Config Class Initialized
INFO - 2023-03-13 02:50:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:16 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:16 --> URI Class Initialized
INFO - 2023-03-13 02:50:16 --> Router Class Initialized
INFO - 2023-03-13 02:50:16 --> Output Class Initialized
INFO - 2023-03-13 02:50:16 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:16 --> Input Class Initialized
INFO - 2023-03-13 02:50:16 --> Language Class Initialized
INFO - 2023-03-13 02:50:16 --> Loader Class Initialized
INFO - 2023-03-13 02:50:16 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:16 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:16 --> Total execution time: 0.0601
INFO - 2023-03-13 02:50:30 --> Config Class Initialized
INFO - 2023-03-13 02:50:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:30 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:30 --> URI Class Initialized
INFO - 2023-03-13 02:50:30 --> Router Class Initialized
INFO - 2023-03-13 02:50:30 --> Output Class Initialized
INFO - 2023-03-13 02:50:30 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:30 --> Input Class Initialized
INFO - 2023-03-13 02:50:30 --> Language Class Initialized
INFO - 2023-03-13 02:50:30 --> Loader Class Initialized
INFO - 2023-03-13 02:50:30 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:30 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:30 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:30 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:30 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:30 --> Total execution time: 0.0272
INFO - 2023-03-13 02:50:30 --> Config Class Initialized
INFO - 2023-03-13 02:50:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:30 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:30 --> URI Class Initialized
INFO - 2023-03-13 02:50:30 --> Router Class Initialized
INFO - 2023-03-13 02:50:30 --> Output Class Initialized
INFO - 2023-03-13 02:50:30 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:30 --> Input Class Initialized
INFO - 2023-03-13 02:50:30 --> Language Class Initialized
INFO - 2023-03-13 02:50:30 --> Loader Class Initialized
INFO - 2023-03-13 02:50:30 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:30 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:30 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:30 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:30 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:30 --> Total execution time: 0.0622
INFO - 2023-03-13 02:50:36 --> Config Class Initialized
INFO - 2023-03-13 02:50:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:36 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:36 --> URI Class Initialized
INFO - 2023-03-13 02:50:36 --> Router Class Initialized
INFO - 2023-03-13 02:50:36 --> Output Class Initialized
INFO - 2023-03-13 02:50:36 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:36 --> Input Class Initialized
INFO - 2023-03-13 02:50:36 --> Language Class Initialized
INFO - 2023-03-13 02:50:36 --> Loader Class Initialized
INFO - 2023-03-13 02:50:36 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:36 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:50:36 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:36 --> Total execution time: 0.0237
INFO - 2023-03-13 02:50:36 --> Config Class Initialized
INFO - 2023-03-13 02:50:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:36 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:36 --> URI Class Initialized
INFO - 2023-03-13 02:50:36 --> Router Class Initialized
INFO - 2023-03-13 02:50:36 --> Output Class Initialized
INFO - 2023-03-13 02:50:36 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:36 --> Input Class Initialized
INFO - 2023-03-13 02:50:36 --> Language Class Initialized
INFO - 2023-03-13 02:50:36 --> Loader Class Initialized
INFO - 2023-03-13 02:50:36 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:36 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 02:50:36 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:36 --> Total execution time: 0.0515
INFO - 2023-03-13 02:50:38 --> Config Class Initialized
INFO - 2023-03-13 02:50:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:38 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:38 --> URI Class Initialized
INFO - 2023-03-13 02:50:38 --> Router Class Initialized
INFO - 2023-03-13 02:50:38 --> Output Class Initialized
INFO - 2023-03-13 02:50:38 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:38 --> Input Class Initialized
INFO - 2023-03-13 02:50:38 --> Language Class Initialized
INFO - 2023-03-13 02:50:38 --> Loader Class Initialized
INFO - 2023-03-13 02:50:38 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:38 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:38 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:38 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:38 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:38 --> Total execution time: 0.0715
INFO - 2023-03-13 02:50:38 --> Config Class Initialized
INFO - 2023-03-13 02:50:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:50:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:50:38 --> Utf8 Class Initialized
INFO - 2023-03-13 02:50:38 --> URI Class Initialized
INFO - 2023-03-13 02:50:38 --> Router Class Initialized
INFO - 2023-03-13 02:50:38 --> Output Class Initialized
INFO - 2023-03-13 02:50:38 --> Security Class Initialized
DEBUG - 2023-03-13 02:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:50:38 --> Input Class Initialized
INFO - 2023-03-13 02:50:38 --> Language Class Initialized
INFO - 2023-03-13 02:50:38 --> Loader Class Initialized
INFO - 2023-03-13 02:50:38 --> Controller Class Initialized
DEBUG - 2023-03-13 02:50:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:50:38 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:38 --> Database Driver Class Initialized
INFO - 2023-03-13 02:50:38 --> Model "Login_model" initialized
INFO - 2023-03-13 02:50:38 --> Final output sent to browser
DEBUG - 2023-03-13 02:50:38 --> Total execution time: 0.0633
INFO - 2023-03-13 02:51:04 --> Config Class Initialized
INFO - 2023-03-13 02:51:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:51:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:51:04 --> Utf8 Class Initialized
INFO - 2023-03-13 02:51:04 --> URI Class Initialized
INFO - 2023-03-13 02:51:04 --> Router Class Initialized
INFO - 2023-03-13 02:51:04 --> Output Class Initialized
INFO - 2023-03-13 02:51:04 --> Security Class Initialized
DEBUG - 2023-03-13 02:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:51:04 --> Input Class Initialized
INFO - 2023-03-13 02:51:04 --> Language Class Initialized
INFO - 2023-03-13 02:51:04 --> Loader Class Initialized
INFO - 2023-03-13 02:51:04 --> Controller Class Initialized
DEBUG - 2023-03-13 02:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:51:04 --> Database Driver Class Initialized
INFO - 2023-03-13 02:51:04 --> Final output sent to browser
DEBUG - 2023-03-13 02:51:04 --> Total execution time: 0.0102
INFO - 2023-03-13 02:51:04 --> Config Class Initialized
INFO - 2023-03-13 02:51:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:51:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:51:04 --> Utf8 Class Initialized
INFO - 2023-03-13 02:51:04 --> URI Class Initialized
INFO - 2023-03-13 02:51:04 --> Router Class Initialized
INFO - 2023-03-13 02:51:04 --> Output Class Initialized
INFO - 2023-03-13 02:51:04 --> Security Class Initialized
DEBUG - 2023-03-13 02:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:51:04 --> Input Class Initialized
INFO - 2023-03-13 02:51:04 --> Language Class Initialized
INFO - 2023-03-13 02:51:04 --> Loader Class Initialized
INFO - 2023-03-13 02:51:04 --> Controller Class Initialized
DEBUG - 2023-03-13 02:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:51:04 --> Database Driver Class Initialized
INFO - 2023-03-13 02:51:04 --> Database Driver Class Initialized
INFO - 2023-03-13 02:51:04 --> Model "Login_model" initialized
INFO - 2023-03-13 02:51:04 --> Final output sent to browser
DEBUG - 2023-03-13 02:51:04 --> Total execution time: 0.0201
INFO - 2023-03-13 02:59:58 --> Config Class Initialized
INFO - 2023-03-13 02:59:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:59:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:59:58 --> Utf8 Class Initialized
INFO - 2023-03-13 02:59:58 --> URI Class Initialized
INFO - 2023-03-13 02:59:58 --> Router Class Initialized
INFO - 2023-03-13 02:59:58 --> Output Class Initialized
INFO - 2023-03-13 02:59:58 --> Security Class Initialized
DEBUG - 2023-03-13 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:59:58 --> Input Class Initialized
INFO - 2023-03-13 02:59:58 --> Language Class Initialized
INFO - 2023-03-13 02:59:58 --> Loader Class Initialized
INFO - 2023-03-13 02:59:58 --> Controller Class Initialized
DEBUG - 2023-03-13 02:59:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:59:58 --> Database Driver Class Initialized
INFO - 2023-03-13 02:59:58 --> Database Driver Class Initialized
INFO - 2023-03-13 02:59:58 --> Model "Login_model" initialized
INFO - 2023-03-13 02:59:58 --> Final output sent to browser
DEBUG - 2023-03-13 02:59:58 --> Total execution time: 0.1030
INFO - 2023-03-13 02:59:58 --> Config Class Initialized
INFO - 2023-03-13 02:59:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 02:59:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 02:59:58 --> Utf8 Class Initialized
INFO - 2023-03-13 02:59:58 --> URI Class Initialized
INFO - 2023-03-13 02:59:58 --> Router Class Initialized
INFO - 2023-03-13 02:59:58 --> Output Class Initialized
INFO - 2023-03-13 02:59:58 --> Security Class Initialized
DEBUG - 2023-03-13 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 02:59:58 --> Input Class Initialized
INFO - 2023-03-13 02:59:58 --> Language Class Initialized
INFO - 2023-03-13 02:59:58 --> Loader Class Initialized
INFO - 2023-03-13 02:59:58 --> Controller Class Initialized
DEBUG - 2023-03-13 02:59:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 02:59:58 --> Database Driver Class Initialized
INFO - 2023-03-13 02:59:58 --> Database Driver Class Initialized
INFO - 2023-03-13 02:59:58 --> Model "Login_model" initialized
INFO - 2023-03-13 02:59:58 --> Final output sent to browser
DEBUG - 2023-03-13 02:59:58 --> Total execution time: 0.0220
INFO - 2023-03-13 03:00:18 --> Config Class Initialized
INFO - 2023-03-13 03:00:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:18 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:18 --> URI Class Initialized
INFO - 2023-03-13 03:00:18 --> Router Class Initialized
INFO - 2023-03-13 03:00:18 --> Output Class Initialized
INFO - 2023-03-13 03:00:18 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:18 --> Input Class Initialized
INFO - 2023-03-13 03:00:18 --> Language Class Initialized
INFO - 2023-03-13 03:00:18 --> Loader Class Initialized
INFO - 2023-03-13 03:00:18 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:18 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:18 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:18 --> Total execution time: 0.0158
INFO - 2023-03-13 03:00:18 --> Config Class Initialized
INFO - 2023-03-13 03:00:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:18 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:18 --> URI Class Initialized
INFO - 2023-03-13 03:00:18 --> Router Class Initialized
INFO - 2023-03-13 03:00:18 --> Output Class Initialized
INFO - 2023-03-13 03:00:18 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:18 --> Input Class Initialized
INFO - 2023-03-13 03:00:18 --> Language Class Initialized
INFO - 2023-03-13 03:00:18 --> Loader Class Initialized
INFO - 2023-03-13 03:00:18 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:18 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:18 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:18 --> Total execution time: 0.0537
INFO - 2023-03-13 03:00:22 --> Config Class Initialized
INFO - 2023-03-13 03:00:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:22 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:22 --> URI Class Initialized
INFO - 2023-03-13 03:00:22 --> Router Class Initialized
INFO - 2023-03-13 03:00:22 --> Output Class Initialized
INFO - 2023-03-13 03:00:22 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:22 --> Input Class Initialized
INFO - 2023-03-13 03:00:22 --> Language Class Initialized
INFO - 2023-03-13 03:00:22 --> Loader Class Initialized
INFO - 2023-03-13 03:00:22 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:22 --> Model "Login_model" initialized
INFO - 2023-03-13 03:00:22 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:22 --> Total execution time: 0.0423
INFO - 2023-03-13 03:00:22 --> Config Class Initialized
INFO - 2023-03-13 03:00:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:22 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:22 --> URI Class Initialized
INFO - 2023-03-13 03:00:22 --> Router Class Initialized
INFO - 2023-03-13 03:00:22 --> Output Class Initialized
INFO - 2023-03-13 03:00:22 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:22 --> Input Class Initialized
INFO - 2023-03-13 03:00:22 --> Language Class Initialized
INFO - 2023-03-13 03:00:22 --> Loader Class Initialized
INFO - 2023-03-13 03:00:22 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:22 --> Model "Login_model" initialized
INFO - 2023-03-13 03:00:22 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:22 --> Total execution time: 0.0353
INFO - 2023-03-13 03:00:24 --> Config Class Initialized
INFO - 2023-03-13 03:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:24 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:24 --> URI Class Initialized
INFO - 2023-03-13 03:00:24 --> Router Class Initialized
INFO - 2023-03-13 03:00:24 --> Output Class Initialized
INFO - 2023-03-13 03:00:24 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:24 --> Input Class Initialized
INFO - 2023-03-13 03:00:24 --> Language Class Initialized
INFO - 2023-03-13 03:00:24 --> Loader Class Initialized
INFO - 2023-03-13 03:00:24 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:24 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:24 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:24 --> Total execution time: 0.0485
INFO - 2023-03-13 03:00:24 --> Config Class Initialized
INFO - 2023-03-13 03:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:24 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:24 --> URI Class Initialized
INFO - 2023-03-13 03:00:24 --> Router Class Initialized
INFO - 2023-03-13 03:00:24 --> Output Class Initialized
INFO - 2023-03-13 03:00:24 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:24 --> Input Class Initialized
INFO - 2023-03-13 03:00:24 --> Language Class Initialized
INFO - 2023-03-13 03:00:24 --> Loader Class Initialized
INFO - 2023-03-13 03:00:24 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:24 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:24 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:24 --> Total execution time: 0.0842
INFO - 2023-03-13 03:00:30 --> Config Class Initialized
INFO - 2023-03-13 03:00:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:30 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:30 --> URI Class Initialized
INFO - 2023-03-13 03:00:30 --> Router Class Initialized
INFO - 2023-03-13 03:00:30 --> Output Class Initialized
INFO - 2023-03-13 03:00:30 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:30 --> Input Class Initialized
INFO - 2023-03-13 03:00:30 --> Language Class Initialized
INFO - 2023-03-13 03:00:30 --> Loader Class Initialized
INFO - 2023-03-13 03:00:30 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:30 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:30 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:30 --> Total execution time: 0.0166
INFO - 2023-03-13 03:00:30 --> Config Class Initialized
INFO - 2023-03-13 03:00:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:30 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:30 --> URI Class Initialized
INFO - 2023-03-13 03:00:30 --> Router Class Initialized
INFO - 2023-03-13 03:00:30 --> Output Class Initialized
INFO - 2023-03-13 03:00:30 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:30 --> Input Class Initialized
INFO - 2023-03-13 03:00:30 --> Language Class Initialized
INFO - 2023-03-13 03:00:30 --> Loader Class Initialized
INFO - 2023-03-13 03:00:30 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:30 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:30 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:30 --> Total execution time: 0.0114
INFO - 2023-03-13 03:00:36 --> Config Class Initialized
INFO - 2023-03-13 03:00:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:36 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:36 --> URI Class Initialized
INFO - 2023-03-13 03:00:36 --> Router Class Initialized
INFO - 2023-03-13 03:00:36 --> Output Class Initialized
INFO - 2023-03-13 03:00:36 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:36 --> Input Class Initialized
INFO - 2023-03-13 03:00:36 --> Language Class Initialized
INFO - 2023-03-13 03:00:36 --> Loader Class Initialized
INFO - 2023-03-13 03:00:36 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:36 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:36 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:36 --> Model "Login_model" initialized
INFO - 2023-03-13 03:00:36 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:36 --> Total execution time: 0.0235
INFO - 2023-03-13 03:00:36 --> Config Class Initialized
INFO - 2023-03-13 03:00:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:36 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:36 --> URI Class Initialized
INFO - 2023-03-13 03:00:36 --> Router Class Initialized
INFO - 2023-03-13 03:00:36 --> Output Class Initialized
INFO - 2023-03-13 03:00:36 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:36 --> Input Class Initialized
INFO - 2023-03-13 03:00:36 --> Language Class Initialized
INFO - 2023-03-13 03:00:36 --> Loader Class Initialized
INFO - 2023-03-13 03:00:36 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:36 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:36 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:36 --> Model "Login_model" initialized
INFO - 2023-03-13 03:00:36 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:36 --> Total execution time: 0.0203
INFO - 2023-03-13 03:00:42 --> Config Class Initialized
INFO - 2023-03-13 03:00:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:42 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:42 --> URI Class Initialized
INFO - 2023-03-13 03:00:42 --> Router Class Initialized
INFO - 2023-03-13 03:00:42 --> Output Class Initialized
INFO - 2023-03-13 03:00:42 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:42 --> Input Class Initialized
INFO - 2023-03-13 03:00:42 --> Language Class Initialized
INFO - 2023-03-13 03:00:42 --> Loader Class Initialized
INFO - 2023-03-13 03:00:42 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:42 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:42 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:42 --> Total execution time: 0.0177
INFO - 2023-03-13 03:00:42 --> Config Class Initialized
INFO - 2023-03-13 03:00:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:00:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:00:42 --> Utf8 Class Initialized
INFO - 2023-03-13 03:00:42 --> URI Class Initialized
INFO - 2023-03-13 03:00:42 --> Router Class Initialized
INFO - 2023-03-13 03:00:42 --> Output Class Initialized
INFO - 2023-03-13 03:00:42 --> Security Class Initialized
DEBUG - 2023-03-13 03:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:00:42 --> Input Class Initialized
INFO - 2023-03-13 03:00:42 --> Language Class Initialized
INFO - 2023-03-13 03:00:42 --> Loader Class Initialized
INFO - 2023-03-13 03:00:42 --> Controller Class Initialized
DEBUG - 2023-03-13 03:00:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:00:42 --> Database Driver Class Initialized
INFO - 2023-03-13 03:00:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:00:42 --> Final output sent to browser
DEBUG - 2023-03-13 03:00:42 --> Total execution time: 0.0127
INFO - 2023-03-13 03:04:10 --> Config Class Initialized
INFO - 2023-03-13 03:04:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:10 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:10 --> URI Class Initialized
INFO - 2023-03-13 03:04:10 --> Router Class Initialized
INFO - 2023-03-13 03:04:10 --> Output Class Initialized
INFO - 2023-03-13 03:04:10 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:10 --> Input Class Initialized
INFO - 2023-03-13 03:04:10 --> Language Class Initialized
INFO - 2023-03-13 03:04:10 --> Loader Class Initialized
INFO - 2023-03-13 03:04:10 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:10 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:04:10 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:10 --> Total execution time: 0.0434
INFO - 2023-03-13 03:04:10 --> Config Class Initialized
INFO - 2023-03-13 03:04:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:10 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:10 --> URI Class Initialized
INFO - 2023-03-13 03:04:10 --> Router Class Initialized
INFO - 2023-03-13 03:04:10 --> Output Class Initialized
INFO - 2023-03-13 03:04:10 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:10 --> Input Class Initialized
INFO - 2023-03-13 03:04:10 --> Language Class Initialized
INFO - 2023-03-13 03:04:10 --> Loader Class Initialized
INFO - 2023-03-13 03:04:10 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:10 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:04:10 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:10 --> Total execution time: 0.0394
INFO - 2023-03-13 03:04:14 --> Config Class Initialized
INFO - 2023-03-13 03:04:14 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:14 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:14 --> URI Class Initialized
INFO - 2023-03-13 03:04:14 --> Router Class Initialized
INFO - 2023-03-13 03:04:14 --> Output Class Initialized
INFO - 2023-03-13 03:04:14 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:14 --> Input Class Initialized
INFO - 2023-03-13 03:04:14 --> Language Class Initialized
INFO - 2023-03-13 03:04:14 --> Loader Class Initialized
INFO - 2023-03-13 03:04:14 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:14 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:14 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:04:14 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:14 --> Model "Login_model" initialized
INFO - 2023-03-13 03:04:14 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:14 --> Total execution time: 0.0565
INFO - 2023-03-13 03:04:14 --> Config Class Initialized
INFO - 2023-03-13 03:04:14 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:14 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:14 --> URI Class Initialized
INFO - 2023-03-13 03:04:14 --> Router Class Initialized
INFO - 2023-03-13 03:04:14 --> Output Class Initialized
INFO - 2023-03-13 03:04:14 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:14 --> Input Class Initialized
INFO - 2023-03-13 03:04:14 --> Language Class Initialized
INFO - 2023-03-13 03:04:14 --> Loader Class Initialized
INFO - 2023-03-13 03:04:14 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:14 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:14 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:04:14 --> Database Driver Class Initialized
INFO - 2023-03-13 03:04:14 --> Model "Login_model" initialized
INFO - 2023-03-13 03:04:14 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:14 --> Total execution time: 0.0322
INFO - 2023-03-13 03:04:17 --> Config Class Initialized
INFO - 2023-03-13 03:04:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:17 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:17 --> URI Class Initialized
INFO - 2023-03-13 03:04:17 --> Router Class Initialized
INFO - 2023-03-13 03:04:17 --> Output Class Initialized
INFO - 2023-03-13 03:04:17 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:17 --> Input Class Initialized
INFO - 2023-03-13 03:04:17 --> Language Class Initialized
INFO - 2023-03-13 03:04:17 --> Loader Class Initialized
INFO - 2023-03-13 03:04:17 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:17 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:17 --> Total execution time: 0.0707
INFO - 2023-03-13 03:04:17 --> Config Class Initialized
INFO - 2023-03-13 03:04:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:04:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:04:17 --> Utf8 Class Initialized
INFO - 2023-03-13 03:04:17 --> URI Class Initialized
INFO - 2023-03-13 03:04:17 --> Router Class Initialized
INFO - 2023-03-13 03:04:17 --> Output Class Initialized
INFO - 2023-03-13 03:04:17 --> Security Class Initialized
DEBUG - 2023-03-13 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:04:17 --> Input Class Initialized
INFO - 2023-03-13 03:04:17 --> Language Class Initialized
INFO - 2023-03-13 03:04:17 --> Loader Class Initialized
INFO - 2023-03-13 03:04:17 --> Controller Class Initialized
DEBUG - 2023-03-13 03:04:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:04:17 --> Final output sent to browser
DEBUG - 2023-03-13 03:04:17 --> Total execution time: 0.0522
INFO - 2023-03-13 03:15:10 --> Config Class Initialized
INFO - 2023-03-13 03:15:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:15:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:15:10 --> Utf8 Class Initialized
INFO - 2023-03-13 03:15:10 --> URI Class Initialized
INFO - 2023-03-13 03:15:10 --> Router Class Initialized
INFO - 2023-03-13 03:15:10 --> Output Class Initialized
INFO - 2023-03-13 03:15:10 --> Security Class Initialized
DEBUG - 2023-03-13 03:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:15:10 --> Input Class Initialized
INFO - 2023-03-13 03:15:10 --> Language Class Initialized
INFO - 2023-03-13 03:15:10 --> Loader Class Initialized
INFO - 2023-03-13 03:15:10 --> Controller Class Initialized
DEBUG - 2023-03-13 03:15:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:15:10 --> Final output sent to browser
DEBUG - 2023-03-13 03:15:10 --> Total execution time: 0.0552
INFO - 2023-03-13 03:15:10 --> Config Class Initialized
INFO - 2023-03-13 03:15:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:15:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:15:10 --> Utf8 Class Initialized
INFO - 2023-03-13 03:15:10 --> URI Class Initialized
INFO - 2023-03-13 03:15:10 --> Router Class Initialized
INFO - 2023-03-13 03:15:10 --> Output Class Initialized
INFO - 2023-03-13 03:15:10 --> Security Class Initialized
DEBUG - 2023-03-13 03:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:15:10 --> Input Class Initialized
INFO - 2023-03-13 03:15:10 --> Language Class Initialized
INFO - 2023-03-13 03:15:10 --> Loader Class Initialized
INFO - 2023-03-13 03:15:10 --> Controller Class Initialized
DEBUG - 2023-03-13 03:15:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:15:10 --> Final output sent to browser
DEBUG - 2023-03-13 03:15:10 --> Total execution time: 0.0523
INFO - 2023-03-13 03:15:13 --> Config Class Initialized
INFO - 2023-03-13 03:15:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:15:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:15:13 --> Utf8 Class Initialized
INFO - 2023-03-13 03:15:13 --> URI Class Initialized
INFO - 2023-03-13 03:15:13 --> Router Class Initialized
INFO - 2023-03-13 03:15:13 --> Output Class Initialized
INFO - 2023-03-13 03:15:13 --> Security Class Initialized
DEBUG - 2023-03-13 03:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:15:13 --> Input Class Initialized
INFO - 2023-03-13 03:15:13 --> Language Class Initialized
INFO - 2023-03-13 03:15:13 --> Loader Class Initialized
INFO - 2023-03-13 03:15:13 --> Controller Class Initialized
DEBUG - 2023-03-13 03:15:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:15:13 --> Final output sent to browser
DEBUG - 2023-03-13 03:15:13 --> Total execution time: 0.0756
INFO - 2023-03-13 03:15:13 --> Config Class Initialized
INFO - 2023-03-13 03:15:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:15:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:15:13 --> Utf8 Class Initialized
INFO - 2023-03-13 03:15:13 --> URI Class Initialized
INFO - 2023-03-13 03:15:13 --> Router Class Initialized
INFO - 2023-03-13 03:15:13 --> Output Class Initialized
INFO - 2023-03-13 03:15:13 --> Security Class Initialized
DEBUG - 2023-03-13 03:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:15:13 --> Input Class Initialized
INFO - 2023-03-13 03:15:13 --> Language Class Initialized
INFO - 2023-03-13 03:15:13 --> Loader Class Initialized
INFO - 2023-03-13 03:15:13 --> Controller Class Initialized
DEBUG - 2023-03-13 03:15:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:15:13 --> Final output sent to browser
DEBUG - 2023-03-13 03:15:13 --> Total execution time: 0.0691
INFO - 2023-03-13 03:17:32 --> Config Class Initialized
INFO - 2023-03-13 03:17:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:17:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:17:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:17:32 --> URI Class Initialized
INFO - 2023-03-13 03:17:32 --> Router Class Initialized
INFO - 2023-03-13 03:17:32 --> Output Class Initialized
INFO - 2023-03-13 03:17:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:17:32 --> Input Class Initialized
INFO - 2023-03-13 03:17:32 --> Language Class Initialized
INFO - 2023-03-13 03:17:32 --> Loader Class Initialized
INFO - 2023-03-13 03:17:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:17:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:17:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:17:32 --> Final output sent to browser
DEBUG - 2023-03-13 03:17:32 --> Total execution time: 0.0407
INFO - 2023-03-13 03:17:32 --> Config Class Initialized
INFO - 2023-03-13 03:17:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:17:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:17:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:17:32 --> URI Class Initialized
INFO - 2023-03-13 03:17:32 --> Router Class Initialized
INFO - 2023-03-13 03:17:32 --> Output Class Initialized
INFO - 2023-03-13 03:17:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:17:32 --> Input Class Initialized
INFO - 2023-03-13 03:17:32 --> Language Class Initialized
INFO - 2023-03-13 03:17:32 --> Loader Class Initialized
INFO - 2023-03-13 03:17:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:17:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:17:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:17:32 --> Final output sent to browser
DEBUG - 2023-03-13 03:17:32 --> Total execution time: 0.0135
INFO - 2023-03-13 03:17:34 --> Config Class Initialized
INFO - 2023-03-13 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:17:34 --> Utf8 Class Initialized
INFO - 2023-03-13 03:17:34 --> URI Class Initialized
INFO - 2023-03-13 03:17:34 --> Router Class Initialized
INFO - 2023-03-13 03:17:34 --> Output Class Initialized
INFO - 2023-03-13 03:17:34 --> Security Class Initialized
DEBUG - 2023-03-13 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:17:34 --> Input Class Initialized
INFO - 2023-03-13 03:17:34 --> Language Class Initialized
INFO - 2023-03-13 03:17:34 --> Loader Class Initialized
INFO - 2023-03-13 03:17:34 --> Controller Class Initialized
DEBUG - 2023-03-13 03:17:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:17:34 --> Database Driver Class Initialized
INFO - 2023-03-13 03:17:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:17:34 --> Final output sent to browser
DEBUG - 2023-03-13 03:17:34 --> Total execution time: 0.0486
INFO - 2023-03-13 03:17:34 --> Config Class Initialized
INFO - 2023-03-13 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:17:34 --> Utf8 Class Initialized
INFO - 2023-03-13 03:17:34 --> URI Class Initialized
INFO - 2023-03-13 03:17:34 --> Router Class Initialized
INFO - 2023-03-13 03:17:34 --> Output Class Initialized
INFO - 2023-03-13 03:17:34 --> Security Class Initialized
DEBUG - 2023-03-13 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:17:34 --> Input Class Initialized
INFO - 2023-03-13 03:17:34 --> Language Class Initialized
INFO - 2023-03-13 03:17:34 --> Loader Class Initialized
INFO - 2023-03-13 03:17:34 --> Controller Class Initialized
DEBUG - 2023-03-13 03:17:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:17:34 --> Database Driver Class Initialized
INFO - 2023-03-13 03:17:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:17:34 --> Final output sent to browser
DEBUG - 2023-03-13 03:17:34 --> Total execution time: 0.0828
INFO - 2023-03-13 03:32:48 --> Config Class Initialized
INFO - 2023-03-13 03:32:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:32:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:32:48 --> Utf8 Class Initialized
INFO - 2023-03-13 03:32:48 --> URI Class Initialized
INFO - 2023-03-13 03:32:48 --> Router Class Initialized
INFO - 2023-03-13 03:32:48 --> Output Class Initialized
INFO - 2023-03-13 03:32:48 --> Security Class Initialized
DEBUG - 2023-03-13 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:32:48 --> Input Class Initialized
INFO - 2023-03-13 03:32:48 --> Language Class Initialized
INFO - 2023-03-13 03:32:48 --> Loader Class Initialized
INFO - 2023-03-13 03:32:48 --> Controller Class Initialized
DEBUG - 2023-03-13 03:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:32:48 --> Database Driver Class Initialized
INFO - 2023-03-13 03:32:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:32:48 --> Final output sent to browser
DEBUG - 2023-03-13 03:32:48 --> Total execution time: 0.0170
INFO - 2023-03-13 03:32:48 --> Config Class Initialized
INFO - 2023-03-13 03:32:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:32:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:32:48 --> Utf8 Class Initialized
INFO - 2023-03-13 03:32:48 --> URI Class Initialized
INFO - 2023-03-13 03:32:48 --> Router Class Initialized
INFO - 2023-03-13 03:32:48 --> Output Class Initialized
INFO - 2023-03-13 03:32:48 --> Security Class Initialized
DEBUG - 2023-03-13 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:32:48 --> Input Class Initialized
INFO - 2023-03-13 03:32:48 --> Language Class Initialized
INFO - 2023-03-13 03:32:48 --> Loader Class Initialized
INFO - 2023-03-13 03:32:48 --> Controller Class Initialized
DEBUG - 2023-03-13 03:32:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:32:48 --> Database Driver Class Initialized
INFO - 2023-03-13 03:32:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:32:48 --> Final output sent to browser
DEBUG - 2023-03-13 03:32:48 --> Total execution time: 0.0133
INFO - 2023-03-13 03:34:39 --> Config Class Initialized
INFO - 2023-03-13 03:34:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:34:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:34:39 --> Utf8 Class Initialized
INFO - 2023-03-13 03:34:39 --> URI Class Initialized
INFO - 2023-03-13 03:34:39 --> Router Class Initialized
INFO - 2023-03-13 03:34:39 --> Output Class Initialized
INFO - 2023-03-13 03:34:39 --> Security Class Initialized
DEBUG - 2023-03-13 03:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:34:39 --> Input Class Initialized
INFO - 2023-03-13 03:34:39 --> Language Class Initialized
INFO - 2023-03-13 03:34:39 --> Loader Class Initialized
INFO - 2023-03-13 03:34:39 --> Controller Class Initialized
DEBUG - 2023-03-13 03:34:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:34:39 --> Database Driver Class Initialized
INFO - 2023-03-13 03:34:39 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:34:39 --> Final output sent to browser
DEBUG - 2023-03-13 03:34:39 --> Total execution time: 0.1478
INFO - 2023-03-13 03:34:39 --> Config Class Initialized
INFO - 2023-03-13 03:34:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:34:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:34:39 --> Utf8 Class Initialized
INFO - 2023-03-13 03:34:39 --> URI Class Initialized
INFO - 2023-03-13 03:34:39 --> Router Class Initialized
INFO - 2023-03-13 03:34:39 --> Output Class Initialized
INFO - 2023-03-13 03:34:39 --> Security Class Initialized
DEBUG - 2023-03-13 03:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:34:39 --> Input Class Initialized
INFO - 2023-03-13 03:34:39 --> Language Class Initialized
INFO - 2023-03-13 03:34:39 --> Loader Class Initialized
INFO - 2023-03-13 03:34:39 --> Controller Class Initialized
DEBUG - 2023-03-13 03:34:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:34:39 --> Database Driver Class Initialized
INFO - 2023-03-13 03:34:39 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:34:39 --> Final output sent to browser
DEBUG - 2023-03-13 03:34:39 --> Total execution time: 0.0125
INFO - 2023-03-13 03:34:44 --> Config Class Initialized
INFO - 2023-03-13 03:34:44 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:34:44 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:34:44 --> Utf8 Class Initialized
INFO - 2023-03-13 03:34:44 --> URI Class Initialized
INFO - 2023-03-13 03:34:44 --> Router Class Initialized
INFO - 2023-03-13 03:34:44 --> Output Class Initialized
INFO - 2023-03-13 03:34:44 --> Security Class Initialized
DEBUG - 2023-03-13 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:34:44 --> Input Class Initialized
INFO - 2023-03-13 03:34:44 --> Language Class Initialized
INFO - 2023-03-13 03:34:44 --> Loader Class Initialized
INFO - 2023-03-13 03:34:44 --> Controller Class Initialized
DEBUG - 2023-03-13 03:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:34:44 --> Database Driver Class Initialized
INFO - 2023-03-13 03:34:44 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:34:44 --> Final output sent to browser
DEBUG - 2023-03-13 03:34:44 --> Total execution time: 0.0449
INFO - 2023-03-13 03:34:44 --> Config Class Initialized
INFO - 2023-03-13 03:34:44 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:34:44 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:34:44 --> Utf8 Class Initialized
INFO - 2023-03-13 03:34:44 --> URI Class Initialized
INFO - 2023-03-13 03:34:44 --> Router Class Initialized
INFO - 2023-03-13 03:34:44 --> Output Class Initialized
INFO - 2023-03-13 03:34:44 --> Security Class Initialized
DEBUG - 2023-03-13 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:34:44 --> Input Class Initialized
INFO - 2023-03-13 03:34:44 --> Language Class Initialized
INFO - 2023-03-13 03:34:44 --> Loader Class Initialized
INFO - 2023-03-13 03:34:44 --> Controller Class Initialized
DEBUG - 2023-03-13 03:34:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:34:44 --> Database Driver Class Initialized
INFO - 2023-03-13 03:34:44 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:34:44 --> Final output sent to browser
DEBUG - 2023-03-13 03:34:44 --> Total execution time: 0.0410
INFO - 2023-03-13 03:49:12 --> Config Class Initialized
INFO - 2023-03-13 03:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:12 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:12 --> URI Class Initialized
INFO - 2023-03-13 03:49:12 --> Router Class Initialized
INFO - 2023-03-13 03:49:12 --> Output Class Initialized
INFO - 2023-03-13 03:49:12 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:12 --> Input Class Initialized
INFO - 2023-03-13 03:49:12 --> Language Class Initialized
INFO - 2023-03-13 03:49:12 --> Loader Class Initialized
INFO - 2023-03-13 03:49:12 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:12 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:12 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:12 --> Total execution time: 0.0581
INFO - 2023-03-13 03:49:12 --> Config Class Initialized
INFO - 2023-03-13 03:49:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:12 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:12 --> URI Class Initialized
INFO - 2023-03-13 03:49:12 --> Router Class Initialized
INFO - 2023-03-13 03:49:12 --> Output Class Initialized
INFO - 2023-03-13 03:49:12 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:12 --> Input Class Initialized
INFO - 2023-03-13 03:49:12 --> Language Class Initialized
INFO - 2023-03-13 03:49:12 --> Loader Class Initialized
INFO - 2023-03-13 03:49:12 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:12 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:12 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:12 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:12 --> Total execution time: 0.0213
INFO - 2023-03-13 03:49:16 --> Config Class Initialized
INFO - 2023-03-13 03:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:16 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:16 --> URI Class Initialized
INFO - 2023-03-13 03:49:16 --> Router Class Initialized
INFO - 2023-03-13 03:49:16 --> Output Class Initialized
INFO - 2023-03-13 03:49:16 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:16 --> Input Class Initialized
INFO - 2023-03-13 03:49:16 --> Language Class Initialized
INFO - 2023-03-13 03:49:16 --> Loader Class Initialized
INFO - 2023-03-13 03:49:16 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:16 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:16 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:16 --> Total execution time: 0.0956
INFO - 2023-03-13 03:49:16 --> Config Class Initialized
INFO - 2023-03-13 03:49:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:16 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:16 --> URI Class Initialized
INFO - 2023-03-13 03:49:16 --> Router Class Initialized
INFO - 2023-03-13 03:49:16 --> Output Class Initialized
INFO - 2023-03-13 03:49:16 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:16 --> Input Class Initialized
INFO - 2023-03-13 03:49:16 --> Language Class Initialized
INFO - 2023-03-13 03:49:16 --> Loader Class Initialized
INFO - 2023-03-13 03:49:16 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:16 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:16 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:16 --> Total execution time: 0.1063
INFO - 2023-03-13 03:49:19 --> Config Class Initialized
INFO - 2023-03-13 03:49:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:19 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:19 --> URI Class Initialized
INFO - 2023-03-13 03:49:19 --> Router Class Initialized
INFO - 2023-03-13 03:49:19 --> Output Class Initialized
INFO - 2023-03-13 03:49:19 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:19 --> Input Class Initialized
INFO - 2023-03-13 03:49:19 --> Language Class Initialized
INFO - 2023-03-13 03:49:19 --> Loader Class Initialized
INFO - 2023-03-13 03:49:19 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:19 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:19 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:19 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:19 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:19 --> Total execution time: 0.1044
INFO - 2023-03-13 03:49:19 --> Config Class Initialized
INFO - 2023-03-13 03:49:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:19 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:19 --> URI Class Initialized
INFO - 2023-03-13 03:49:19 --> Router Class Initialized
INFO - 2023-03-13 03:49:19 --> Output Class Initialized
INFO - 2023-03-13 03:49:19 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:19 --> Input Class Initialized
INFO - 2023-03-13 03:49:19 --> Language Class Initialized
INFO - 2023-03-13 03:49:19 --> Loader Class Initialized
INFO - 2023-03-13 03:49:19 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:19 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:20 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:20 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:20 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:20 --> Total execution time: 0.2349
INFO - 2023-03-13 03:49:26 --> Config Class Initialized
INFO - 2023-03-13 03:49:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:26 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:26 --> URI Class Initialized
INFO - 2023-03-13 03:49:26 --> Router Class Initialized
INFO - 2023-03-13 03:49:26 --> Output Class Initialized
INFO - 2023-03-13 03:49:26 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:26 --> Input Class Initialized
INFO - 2023-03-13 03:49:26 --> Language Class Initialized
INFO - 2023-03-13 03:49:26 --> Loader Class Initialized
INFO - 2023-03-13 03:49:26 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:26 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:26 --> Total execution time: 0.0037
INFO - 2023-03-13 03:49:26 --> Config Class Initialized
INFO - 2023-03-13 03:49:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:26 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:26 --> URI Class Initialized
INFO - 2023-03-13 03:49:26 --> Router Class Initialized
INFO - 2023-03-13 03:49:26 --> Output Class Initialized
INFO - 2023-03-13 03:49:26 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:26 --> Input Class Initialized
INFO - 2023-03-13 03:49:26 --> Language Class Initialized
INFO - 2023-03-13 03:49:26 --> Loader Class Initialized
INFO - 2023-03-13 03:49:26 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:26 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:26 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:26 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:26 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:26 --> Total execution time: 0.3049
INFO - 2023-03-13 03:49:26 --> Config Class Initialized
INFO - 2023-03-13 03:49:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:26 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:26 --> URI Class Initialized
INFO - 2023-03-13 03:49:26 --> Router Class Initialized
INFO - 2023-03-13 03:49:26 --> Output Class Initialized
INFO - 2023-03-13 03:49:26 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:26 --> Input Class Initialized
INFO - 2023-03-13 03:49:26 --> Language Class Initialized
INFO - 2023-03-13 03:49:26 --> Loader Class Initialized
INFO - 2023-03-13 03:49:26 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:26 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:26 --> Total execution time: 0.0019
INFO - 2023-03-13 03:49:26 --> Config Class Initialized
INFO - 2023-03-13 03:49:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:26 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:26 --> URI Class Initialized
INFO - 2023-03-13 03:49:26 --> Router Class Initialized
INFO - 2023-03-13 03:49:26 --> Output Class Initialized
INFO - 2023-03-13 03:49:26 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:26 --> Input Class Initialized
INFO - 2023-03-13 03:49:26 --> Language Class Initialized
INFO - 2023-03-13 03:49:26 --> Loader Class Initialized
INFO - 2023-03-13 03:49:26 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:26 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:26 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:26 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:26 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:26 --> Total execution time: 0.0833
INFO - 2023-03-13 03:49:28 --> Config Class Initialized
INFO - 2023-03-13 03:49:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:28 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:28 --> URI Class Initialized
INFO - 2023-03-13 03:49:28 --> Router Class Initialized
INFO - 2023-03-13 03:49:28 --> Output Class Initialized
INFO - 2023-03-13 03:49:28 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:28 --> Input Class Initialized
INFO - 2023-03-13 03:49:28 --> Language Class Initialized
INFO - 2023-03-13 03:49:28 --> Loader Class Initialized
INFO - 2023-03-13 03:49:28 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:28 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:28 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:28 --> Total execution time: 0.0498
INFO - 2023-03-13 03:49:28 --> Config Class Initialized
INFO - 2023-03-13 03:49:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:28 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:28 --> URI Class Initialized
INFO - 2023-03-13 03:49:28 --> Router Class Initialized
INFO - 2023-03-13 03:49:28 --> Output Class Initialized
INFO - 2023-03-13 03:49:28 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:28 --> Input Class Initialized
INFO - 2023-03-13 03:49:28 --> Language Class Initialized
INFO - 2023-03-13 03:49:28 --> Loader Class Initialized
INFO - 2023-03-13 03:49:28 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:28 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:28 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:28 --> Total execution time: 0.0663
INFO - 2023-03-13 03:49:32 --> Config Class Initialized
INFO - 2023-03-13 03:49:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:32 --> URI Class Initialized
INFO - 2023-03-13 03:49:32 --> Router Class Initialized
INFO - 2023-03-13 03:49:32 --> Output Class Initialized
INFO - 2023-03-13 03:49:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:32 --> Input Class Initialized
INFO - 2023-03-13 03:49:32 --> Language Class Initialized
INFO - 2023-03-13 03:49:32 --> Loader Class Initialized
INFO - 2023-03-13 03:49:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:32 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:32 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:32 --> Total execution time: 0.0747
INFO - 2023-03-13 03:49:32 --> Config Class Initialized
INFO - 2023-03-13 03:49:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:32 --> URI Class Initialized
INFO - 2023-03-13 03:49:32 --> Router Class Initialized
INFO - 2023-03-13 03:49:32 --> Output Class Initialized
INFO - 2023-03-13 03:49:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:32 --> Input Class Initialized
INFO - 2023-03-13 03:49:32 --> Language Class Initialized
INFO - 2023-03-13 03:49:32 --> Loader Class Initialized
INFO - 2023-03-13 03:49:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:49:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:49:32 --> Model "Login_model" initialized
INFO - 2023-03-13 03:49:32 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:32 --> Total execution time: 0.3012
INFO - 2023-03-13 03:49:38 --> Config Class Initialized
INFO - 2023-03-13 03:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:38 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:38 --> URI Class Initialized
INFO - 2023-03-13 03:49:38 --> Router Class Initialized
INFO - 2023-03-13 03:49:38 --> Output Class Initialized
INFO - 2023-03-13 03:49:38 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:38 --> Input Class Initialized
INFO - 2023-03-13 03:49:38 --> Language Class Initialized
INFO - 2023-03-13 03:49:38 --> Loader Class Initialized
INFO - 2023-03-13 03:49:38 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:38 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:38 --> Total execution time: 0.3003
INFO - 2023-03-13 03:49:38 --> Config Class Initialized
INFO - 2023-03-13 03:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:49:38 --> Utf8 Class Initialized
INFO - 2023-03-13 03:49:38 --> URI Class Initialized
INFO - 2023-03-13 03:49:38 --> Router Class Initialized
INFO - 2023-03-13 03:49:38 --> Output Class Initialized
INFO - 2023-03-13 03:49:38 --> Security Class Initialized
DEBUG - 2023-03-13 03:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:49:38 --> Input Class Initialized
INFO - 2023-03-13 03:49:38 --> Language Class Initialized
INFO - 2023-03-13 03:49:38 --> Loader Class Initialized
INFO - 2023-03-13 03:49:38 --> Controller Class Initialized
DEBUG - 2023-03-13 03:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:49:39 --> Final output sent to browser
DEBUG - 2023-03-13 03:49:39 --> Total execution time: 0.5552
INFO - 2023-03-13 03:56:20 --> Config Class Initialized
INFO - 2023-03-13 03:56:20 --> Config Class Initialized
INFO - 2023-03-13 03:56:20 --> Hooks Class Initialized
INFO - 2023-03-13 03:56:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 03:56:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:20 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:20 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:20 --> URI Class Initialized
INFO - 2023-03-13 03:56:20 --> URI Class Initialized
INFO - 2023-03-13 03:56:20 --> Router Class Initialized
INFO - 2023-03-13 03:56:20 --> Router Class Initialized
INFO - 2023-03-13 03:56:20 --> Output Class Initialized
INFO - 2023-03-13 03:56:20 --> Output Class Initialized
INFO - 2023-03-13 03:56:20 --> Security Class Initialized
INFO - 2023-03-13 03:56:20 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:20 --> Input Class Initialized
INFO - 2023-03-13 03:56:20 --> Input Class Initialized
INFO - 2023-03-13 03:56:20 --> Language Class Initialized
INFO - 2023-03-13 03:56:20 --> Language Class Initialized
INFO - 2023-03-13 03:56:20 --> Loader Class Initialized
INFO - 2023-03-13 03:56:20 --> Loader Class Initialized
INFO - 2023-03-13 03:56:20 --> Controller Class Initialized
INFO - 2023-03-13 03:56:20 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 03:56:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:20 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:20 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:20 --> Final output sent to browser
DEBUG - 2023-03-13 03:56:20 --> Total execution time: 0.0167
INFO - 2023-03-13 03:56:20 --> Config Class Initialized
INFO - 2023-03-13 03:56:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:20 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:20 --> URI Class Initialized
INFO - 2023-03-13 03:56:20 --> Router Class Initialized
INFO - 2023-03-13 03:56:20 --> Output Class Initialized
INFO - 2023-03-13 03:56:20 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:20 --> Input Class Initialized
INFO - 2023-03-13 03:56:20 --> Language Class Initialized
INFO - 2023-03-13 03:56:20 --> Loader Class Initialized
INFO - 2023-03-13 03:56:20 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:20 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:20 --> Final output sent to browser
DEBUG - 2023-03-13 03:56:20 --> Total execution time: 0.0903
INFO - 2023-03-13 03:56:20 --> Config Class Initialized
INFO - 2023-03-13 03:56:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:20 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:20 --> URI Class Initialized
INFO - 2023-03-13 03:56:20 --> Router Class Initialized
INFO - 2023-03-13 03:56:20 --> Output Class Initialized
INFO - 2023-03-13 03:56:20 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:20 --> Input Class Initialized
INFO - 2023-03-13 03:56:20 --> Language Class Initialized
INFO - 2023-03-13 03:56:20 --> Loader Class Initialized
INFO - 2023-03-13 03:56:20 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:20 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:22 --> Config Class Initialized
INFO - 2023-03-13 03:56:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:22 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:22 --> URI Class Initialized
INFO - 2023-03-13 03:56:22 --> Router Class Initialized
INFO - 2023-03-13 03:56:22 --> Output Class Initialized
INFO - 2023-03-13 03:56:22 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:22 --> Input Class Initialized
INFO - 2023-03-13 03:56:22 --> Language Class Initialized
INFO - 2023-03-13 03:56:22 --> Loader Class Initialized
INFO - 2023-03-13 03:56:22 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:22 --> Config Class Initialized
INFO - 2023-03-13 03:56:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:22 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:22 --> URI Class Initialized
INFO - 2023-03-13 03:56:22 --> Router Class Initialized
INFO - 2023-03-13 03:56:22 --> Output Class Initialized
INFO - 2023-03-13 03:56:22 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:22 --> Input Class Initialized
INFO - 2023-03-13 03:56:22 --> Language Class Initialized
INFO - 2023-03-13 03:56:22 --> Loader Class Initialized
INFO - 2023-03-13 03:56:22 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:22 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:32 --> Config Class Initialized
INFO - 2023-03-13 03:56:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:32 --> URI Class Initialized
INFO - 2023-03-13 03:56:32 --> Router Class Initialized
INFO - 2023-03-13 03:56:32 --> Output Class Initialized
INFO - 2023-03-13 03:56:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:32 --> Input Class Initialized
INFO - 2023-03-13 03:56:32 --> Language Class Initialized
INFO - 2023-03-13 03:56:32 --> Loader Class Initialized
INFO - 2023-03-13 03:56:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:32 --> Config Class Initialized
INFO - 2023-03-13 03:56:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:32 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:32 --> URI Class Initialized
INFO - 2023-03-13 03:56:32 --> Router Class Initialized
INFO - 2023-03-13 03:56:32 --> Output Class Initialized
INFO - 2023-03-13 03:56:32 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:32 --> Input Class Initialized
INFO - 2023-03-13 03:56:32 --> Language Class Initialized
INFO - 2023-03-13 03:56:32 --> Loader Class Initialized
INFO - 2023-03-13 03:56:32 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:32 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:34 --> Config Class Initialized
INFO - 2023-03-13 03:56:34 --> Config Class Initialized
INFO - 2023-03-13 03:56:34 --> Hooks Class Initialized
INFO - 2023-03-13 03:56:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 03:56:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:34 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:34 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:34 --> URI Class Initialized
INFO - 2023-03-13 03:56:34 --> URI Class Initialized
INFO - 2023-03-13 03:56:34 --> Router Class Initialized
INFO - 2023-03-13 03:56:34 --> Router Class Initialized
INFO - 2023-03-13 03:56:34 --> Output Class Initialized
INFO - 2023-03-13 03:56:34 --> Output Class Initialized
INFO - 2023-03-13 03:56:34 --> Security Class Initialized
INFO - 2023-03-13 03:56:34 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 03:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:34 --> Input Class Initialized
INFO - 2023-03-13 03:56:34 --> Input Class Initialized
INFO - 2023-03-13 03:56:34 --> Language Class Initialized
INFO - 2023-03-13 03:56:34 --> Language Class Initialized
INFO - 2023-03-13 03:56:34 --> Loader Class Initialized
INFO - 2023-03-13 03:56:34 --> Loader Class Initialized
INFO - 2023-03-13 03:56:34 --> Controller Class Initialized
INFO - 2023-03-13 03:56:34 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 03:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:34 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:34 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:34 --> Final output sent to browser
DEBUG - 2023-03-13 03:56:34 --> Total execution time: 0.0556
INFO - 2023-03-13 03:56:34 --> Config Class Initialized
INFO - 2023-03-13 03:56:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 03:56:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 03:56:34 --> Utf8 Class Initialized
INFO - 2023-03-13 03:56:34 --> URI Class Initialized
INFO - 2023-03-13 03:56:34 --> Router Class Initialized
INFO - 2023-03-13 03:56:34 --> Output Class Initialized
INFO - 2023-03-13 03:56:34 --> Security Class Initialized
DEBUG - 2023-03-13 03:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 03:56:34 --> Input Class Initialized
INFO - 2023-03-13 03:56:34 --> Language Class Initialized
INFO - 2023-03-13 03:56:34 --> Loader Class Initialized
INFO - 2023-03-13 03:56:34 --> Controller Class Initialized
DEBUG - 2023-03-13 03:56:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 03:56:34 --> Database Driver Class Initialized
INFO - 2023-03-13 03:56:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 03:56:34 --> Final output sent to browser
DEBUG - 2023-03-13 03:56:34 --> Total execution time: 0.0111
INFO - 2023-03-13 05:34:51 --> Config Class Initialized
INFO - 2023-03-13 05:34:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:34:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:34:51 --> Utf8 Class Initialized
INFO - 2023-03-13 05:34:51 --> URI Class Initialized
INFO - 2023-03-13 05:34:51 --> Router Class Initialized
INFO - 2023-03-13 05:34:51 --> Output Class Initialized
INFO - 2023-03-13 05:34:51 --> Security Class Initialized
DEBUG - 2023-03-13 05:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:34:51 --> Input Class Initialized
INFO - 2023-03-13 05:34:51 --> Language Class Initialized
INFO - 2023-03-13 05:34:51 --> Loader Class Initialized
INFO - 2023-03-13 05:34:51 --> Controller Class Initialized
DEBUG - 2023-03-13 05:34:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:34:51 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:34:51 --> Final output sent to browser
DEBUG - 2023-03-13 05:34:51 --> Total execution time: 0.0213
INFO - 2023-03-13 05:34:51 --> Config Class Initialized
INFO - 2023-03-13 05:34:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:34:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:34:51 --> Utf8 Class Initialized
INFO - 2023-03-13 05:34:51 --> URI Class Initialized
INFO - 2023-03-13 05:34:51 --> Router Class Initialized
INFO - 2023-03-13 05:34:51 --> Output Class Initialized
INFO - 2023-03-13 05:34:51 --> Security Class Initialized
DEBUG - 2023-03-13 05:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:34:51 --> Input Class Initialized
INFO - 2023-03-13 05:34:51 --> Language Class Initialized
INFO - 2023-03-13 05:34:51 --> Loader Class Initialized
INFO - 2023-03-13 05:34:51 --> Controller Class Initialized
DEBUG - 2023-03-13 05:34:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:34:51 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:34:51 --> Final output sent to browser
DEBUG - 2023-03-13 05:34:51 --> Total execution time: 0.0562
INFO - 2023-03-13 05:34:54 --> Config Class Initialized
INFO - 2023-03-13 05:34:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:34:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:34:54 --> Utf8 Class Initialized
INFO - 2023-03-13 05:34:54 --> URI Class Initialized
INFO - 2023-03-13 05:34:54 --> Router Class Initialized
INFO - 2023-03-13 05:34:54 --> Output Class Initialized
INFO - 2023-03-13 05:34:54 --> Security Class Initialized
DEBUG - 2023-03-13 05:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:34:54 --> Input Class Initialized
INFO - 2023-03-13 05:34:54 --> Language Class Initialized
INFO - 2023-03-13 05:34:54 --> Loader Class Initialized
INFO - 2023-03-13 05:34:54 --> Controller Class Initialized
DEBUG - 2023-03-13 05:34:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:34:54 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:54 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:34:54 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:55 --> Model "Login_model" initialized
INFO - 2023-03-13 05:34:55 --> Final output sent to browser
DEBUG - 2023-03-13 05:34:55 --> Total execution time: 0.1260
INFO - 2023-03-13 05:34:55 --> Config Class Initialized
INFO - 2023-03-13 05:34:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:34:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:34:55 --> Utf8 Class Initialized
INFO - 2023-03-13 05:34:55 --> URI Class Initialized
INFO - 2023-03-13 05:34:55 --> Router Class Initialized
INFO - 2023-03-13 05:34:55 --> Output Class Initialized
INFO - 2023-03-13 05:34:55 --> Security Class Initialized
DEBUG - 2023-03-13 05:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:34:55 --> Input Class Initialized
INFO - 2023-03-13 05:34:55 --> Language Class Initialized
INFO - 2023-03-13 05:34:55 --> Loader Class Initialized
INFO - 2023-03-13 05:34:55 --> Controller Class Initialized
DEBUG - 2023-03-13 05:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:34:55 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:55 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:34:55 --> Database Driver Class Initialized
INFO - 2023-03-13 05:34:55 --> Model "Login_model" initialized
INFO - 2023-03-13 05:34:55 --> Final output sent to browser
DEBUG - 2023-03-13 05:34:55 --> Total execution time: 0.0937
INFO - 2023-03-13 05:43:06 --> Config Class Initialized
INFO - 2023-03-13 05:43:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:06 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:06 --> URI Class Initialized
INFO - 2023-03-13 05:43:06 --> Router Class Initialized
INFO - 2023-03-13 05:43:06 --> Output Class Initialized
INFO - 2023-03-13 05:43:06 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:06 --> Input Class Initialized
INFO - 2023-03-13 05:43:06 --> Language Class Initialized
INFO - 2023-03-13 05:43:06 --> Loader Class Initialized
INFO - 2023-03-13 05:43:06 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:06 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:06 --> Total execution time: 0.0029
INFO - 2023-03-13 05:43:06 --> Config Class Initialized
INFO - 2023-03-13 05:43:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:06 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:06 --> URI Class Initialized
INFO - 2023-03-13 05:43:06 --> Router Class Initialized
INFO - 2023-03-13 05:43:06 --> Output Class Initialized
INFO - 2023-03-13 05:43:06 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:06 --> Input Class Initialized
INFO - 2023-03-13 05:43:06 --> Language Class Initialized
INFO - 2023-03-13 05:43:06 --> Loader Class Initialized
INFO - 2023-03-13 05:43:06 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:06 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:06 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:06 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:06 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:06 --> Total execution time: 0.0185
INFO - 2023-03-13 05:43:06 --> Config Class Initialized
INFO - 2023-03-13 05:43:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:06 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:06 --> URI Class Initialized
INFO - 2023-03-13 05:43:06 --> Router Class Initialized
INFO - 2023-03-13 05:43:06 --> Output Class Initialized
INFO - 2023-03-13 05:43:06 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:06 --> Input Class Initialized
INFO - 2023-03-13 05:43:06 --> Language Class Initialized
INFO - 2023-03-13 05:43:06 --> Loader Class Initialized
INFO - 2023-03-13 05:43:06 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:06 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:06 --> Total execution time: 0.0422
INFO - 2023-03-13 05:43:06 --> Config Class Initialized
INFO - 2023-03-13 05:43:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:06 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:06 --> URI Class Initialized
INFO - 2023-03-13 05:43:06 --> Router Class Initialized
INFO - 2023-03-13 05:43:06 --> Output Class Initialized
INFO - 2023-03-13 05:43:06 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:06 --> Input Class Initialized
INFO - 2023-03-13 05:43:06 --> Language Class Initialized
INFO - 2023-03-13 05:43:06 --> Loader Class Initialized
INFO - 2023-03-13 05:43:06 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:06 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:06 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:06 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:06 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:06 --> Total execution time: 0.0220
INFO - 2023-03-13 05:43:07 --> Config Class Initialized
INFO - 2023-03-13 05:43:07 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:07 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:07 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:07 --> URI Class Initialized
INFO - 2023-03-13 05:43:07 --> Router Class Initialized
INFO - 2023-03-13 05:43:07 --> Output Class Initialized
INFO - 2023-03-13 05:43:07 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:07 --> Input Class Initialized
INFO - 2023-03-13 05:43:07 --> Language Class Initialized
INFO - 2023-03-13 05:43:07 --> Loader Class Initialized
INFO - 2023-03-13 05:43:07 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:07 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:07 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:07 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:07 --> Total execution time: 0.0162
INFO - 2023-03-13 05:43:07 --> Config Class Initialized
INFO - 2023-03-13 05:43:07 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:07 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:07 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:07 --> URI Class Initialized
INFO - 2023-03-13 05:43:07 --> Router Class Initialized
INFO - 2023-03-13 05:43:07 --> Output Class Initialized
INFO - 2023-03-13 05:43:07 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:07 --> Input Class Initialized
INFO - 2023-03-13 05:43:07 --> Language Class Initialized
INFO - 2023-03-13 05:43:07 --> Loader Class Initialized
INFO - 2023-03-13 05:43:07 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:07 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:07 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:07 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:07 --> Total execution time: 0.0569
INFO - 2023-03-13 05:43:08 --> Config Class Initialized
INFO - 2023-03-13 05:43:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:08 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:08 --> URI Class Initialized
INFO - 2023-03-13 05:43:08 --> Router Class Initialized
INFO - 2023-03-13 05:43:08 --> Output Class Initialized
INFO - 2023-03-13 05:43:08 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:08 --> Input Class Initialized
INFO - 2023-03-13 05:43:08 --> Language Class Initialized
INFO - 2023-03-13 05:43:08 --> Loader Class Initialized
INFO - 2023-03-13 05:43:08 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:08 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:08 --> Total execution time: 0.0414
INFO - 2023-03-13 05:43:08 --> Config Class Initialized
INFO - 2023-03-13 05:43:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:08 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:08 --> URI Class Initialized
INFO - 2023-03-13 05:43:08 --> Router Class Initialized
INFO - 2023-03-13 05:43:08 --> Output Class Initialized
INFO - 2023-03-13 05:43:08 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:08 --> Input Class Initialized
INFO - 2023-03-13 05:43:08 --> Language Class Initialized
INFO - 2023-03-13 05:43:08 --> Loader Class Initialized
INFO - 2023-03-13 05:43:08 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:08 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:08 --> Total execution time: 0.0279
INFO - 2023-03-13 05:43:08 --> Config Class Initialized
INFO - 2023-03-13 05:43:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:08 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:08 --> URI Class Initialized
INFO - 2023-03-13 05:43:08 --> Router Class Initialized
INFO - 2023-03-13 05:43:08 --> Output Class Initialized
INFO - 2023-03-13 05:43:08 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:08 --> Input Class Initialized
INFO - 2023-03-13 05:43:08 --> Language Class Initialized
INFO - 2023-03-13 05:43:08 --> Loader Class Initialized
INFO - 2023-03-13 05:43:08 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:08 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:08 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:08 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:08 --> Total execution time: 0.0447
INFO - 2023-03-13 05:43:08 --> Config Class Initialized
INFO - 2023-03-13 05:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:09 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:09 --> URI Class Initialized
INFO - 2023-03-13 05:43:09 --> Router Class Initialized
INFO - 2023-03-13 05:43:09 --> Output Class Initialized
INFO - 2023-03-13 05:43:09 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:09 --> Input Class Initialized
INFO - 2023-03-13 05:43:09 --> Language Class Initialized
INFO - 2023-03-13 05:43:09 --> Loader Class Initialized
INFO - 2023-03-13 05:43:09 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:09 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:09 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:09 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:09 --> Total execution time: 0.0880
INFO - 2023-03-13 05:43:10 --> Config Class Initialized
INFO - 2023-03-13 05:43:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:10 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:10 --> URI Class Initialized
INFO - 2023-03-13 05:43:10 --> Router Class Initialized
INFO - 2023-03-13 05:43:10 --> Output Class Initialized
INFO - 2023-03-13 05:43:10 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:10 --> Input Class Initialized
INFO - 2023-03-13 05:43:10 --> Language Class Initialized
INFO - 2023-03-13 05:43:10 --> Loader Class Initialized
INFO - 2023-03-13 05:43:10 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:10 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:10 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:10 --> Total execution time: 0.0535
INFO - 2023-03-13 05:43:10 --> Config Class Initialized
INFO - 2023-03-13 05:43:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:10 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:10 --> URI Class Initialized
INFO - 2023-03-13 05:43:10 --> Router Class Initialized
INFO - 2023-03-13 05:43:10 --> Output Class Initialized
INFO - 2023-03-13 05:43:10 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:10 --> Input Class Initialized
INFO - 2023-03-13 05:43:10 --> Language Class Initialized
INFO - 2023-03-13 05:43:10 --> Loader Class Initialized
INFO - 2023-03-13 05:43:10 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:10 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:10 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:10 --> Total execution time: 0.0895
INFO - 2023-03-13 05:43:13 --> Config Class Initialized
INFO - 2023-03-13 05:43:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:13 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:13 --> URI Class Initialized
INFO - 2023-03-13 05:43:13 --> Router Class Initialized
INFO - 2023-03-13 05:43:13 --> Output Class Initialized
INFO - 2023-03-13 05:43:13 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:13 --> Input Class Initialized
INFO - 2023-03-13 05:43:13 --> Language Class Initialized
INFO - 2023-03-13 05:43:13 --> Loader Class Initialized
INFO - 2023-03-13 05:43:13 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:13 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:13 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:13 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:13 --> Total execution time: 0.0158
INFO - 2023-03-13 05:43:13 --> Config Class Initialized
INFO - 2023-03-13 05:43:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:13 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:13 --> URI Class Initialized
INFO - 2023-03-13 05:43:13 --> Router Class Initialized
INFO - 2023-03-13 05:43:13 --> Output Class Initialized
INFO - 2023-03-13 05:43:13 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:13 --> Input Class Initialized
INFO - 2023-03-13 05:43:13 --> Language Class Initialized
INFO - 2023-03-13 05:43:13 --> Loader Class Initialized
INFO - 2023-03-13 05:43:13 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:13 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:13 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:13 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:13 --> Total execution time: 0.0561
INFO - 2023-03-13 05:43:15 --> Config Class Initialized
INFO - 2023-03-13 05:43:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:15 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:15 --> URI Class Initialized
INFO - 2023-03-13 05:43:15 --> Router Class Initialized
INFO - 2023-03-13 05:43:15 --> Output Class Initialized
INFO - 2023-03-13 05:43:15 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:15 --> Input Class Initialized
INFO - 2023-03-13 05:43:15 --> Language Class Initialized
INFO - 2023-03-13 05:43:15 --> Loader Class Initialized
INFO - 2023-03-13 05:43:15 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:15 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:15 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:15 --> Total execution time: 0.0531
INFO - 2023-03-13 05:43:15 --> Config Class Initialized
INFO - 2023-03-13 05:43:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:15 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:15 --> URI Class Initialized
INFO - 2023-03-13 05:43:15 --> Router Class Initialized
INFO - 2023-03-13 05:43:15 --> Output Class Initialized
INFO - 2023-03-13 05:43:15 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:15 --> Input Class Initialized
INFO - 2023-03-13 05:43:15 --> Language Class Initialized
INFO - 2023-03-13 05:43:15 --> Loader Class Initialized
INFO - 2023-03-13 05:43:15 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:15 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:15 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:15 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:15 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:15 --> Total execution time: 0.0725
INFO - 2023-03-13 05:43:15 --> Config Class Initialized
INFO - 2023-03-13 05:43:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:43:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:43:15 --> Utf8 Class Initialized
INFO - 2023-03-13 05:43:15 --> URI Class Initialized
INFO - 2023-03-13 05:43:15 --> Router Class Initialized
INFO - 2023-03-13 05:43:15 --> Output Class Initialized
INFO - 2023-03-13 05:43:15 --> Security Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:43:15 --> Input Class Initialized
INFO - 2023-03-13 05:43:15 --> Language Class Initialized
INFO - 2023-03-13 05:43:15 --> Loader Class Initialized
INFO - 2023-03-13 05:43:15 --> Controller Class Initialized
DEBUG - 2023-03-13 05:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:43:15 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:43:15 --> Database Driver Class Initialized
INFO - 2023-03-13 05:43:15 --> Model "Login_model" initialized
INFO - 2023-03-13 05:43:15 --> Final output sent to browser
DEBUG - 2023-03-13 05:43:15 --> Total execution time: 0.0758
INFO - 2023-03-13 05:48:48 --> Config Class Initialized
INFO - 2023-03-13 05:48:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:48:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:48:48 --> Utf8 Class Initialized
INFO - 2023-03-13 05:48:48 --> URI Class Initialized
INFO - 2023-03-13 05:48:48 --> Router Class Initialized
INFO - 2023-03-13 05:48:48 --> Output Class Initialized
INFO - 2023-03-13 05:48:48 --> Security Class Initialized
DEBUG - 2023-03-13 05:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:48:48 --> Input Class Initialized
INFO - 2023-03-13 05:48:48 --> Language Class Initialized
INFO - 2023-03-13 05:48:48 --> Loader Class Initialized
INFO - 2023-03-13 05:48:48 --> Controller Class Initialized
DEBUG - 2023-03-13 05:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:48:48 --> Database Driver Class Initialized
INFO - 2023-03-13 05:48:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:48:48 --> Final output sent to browser
DEBUG - 2023-03-13 05:48:48 --> Total execution time: 0.0681
INFO - 2023-03-13 05:48:48 --> Config Class Initialized
INFO - 2023-03-13 05:48:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:48:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:48:48 --> Utf8 Class Initialized
INFO - 2023-03-13 05:48:48 --> URI Class Initialized
INFO - 2023-03-13 05:48:48 --> Router Class Initialized
INFO - 2023-03-13 05:48:48 --> Output Class Initialized
INFO - 2023-03-13 05:48:48 --> Security Class Initialized
DEBUG - 2023-03-13 05:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:48:48 --> Input Class Initialized
INFO - 2023-03-13 05:48:48 --> Language Class Initialized
INFO - 2023-03-13 05:48:48 --> Loader Class Initialized
INFO - 2023-03-13 05:48:48 --> Controller Class Initialized
DEBUG - 2023-03-13 05:48:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:48:48 --> Database Driver Class Initialized
INFO - 2023-03-13 05:48:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:48:48 --> Final output sent to browser
DEBUG - 2023-03-13 05:48:48 --> Total execution time: 0.1339
INFO - 2023-03-13 05:54:32 --> Config Class Initialized
INFO - 2023-03-13 05:54:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:54:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:54:32 --> Utf8 Class Initialized
INFO - 2023-03-13 05:54:32 --> URI Class Initialized
INFO - 2023-03-13 05:54:32 --> Router Class Initialized
INFO - 2023-03-13 05:54:32 --> Output Class Initialized
INFO - 2023-03-13 05:54:32 --> Security Class Initialized
DEBUG - 2023-03-13 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:54:32 --> Input Class Initialized
INFO - 2023-03-13 05:54:32 --> Language Class Initialized
INFO - 2023-03-13 05:54:32 --> Loader Class Initialized
INFO - 2023-03-13 05:54:32 --> Controller Class Initialized
DEBUG - 2023-03-13 05:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:54:32 --> Database Driver Class Initialized
INFO - 2023-03-13 05:54:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:54:32 --> Final output sent to browser
DEBUG - 2023-03-13 05:54:32 --> Total execution time: 0.0142
INFO - 2023-03-13 05:54:32 --> Config Class Initialized
INFO - 2023-03-13 05:54:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:54:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:54:32 --> Utf8 Class Initialized
INFO - 2023-03-13 05:54:32 --> URI Class Initialized
INFO - 2023-03-13 05:54:32 --> Router Class Initialized
INFO - 2023-03-13 05:54:32 --> Output Class Initialized
INFO - 2023-03-13 05:54:32 --> Security Class Initialized
DEBUG - 2023-03-13 05:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:54:32 --> Input Class Initialized
INFO - 2023-03-13 05:54:32 --> Language Class Initialized
INFO - 2023-03-13 05:54:32 --> Loader Class Initialized
INFO - 2023-03-13 05:54:32 --> Controller Class Initialized
DEBUG - 2023-03-13 05:54:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:54:32 --> Database Driver Class Initialized
INFO - 2023-03-13 05:54:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:54:32 --> Final output sent to browser
DEBUG - 2023-03-13 05:54:32 --> Total execution time: 0.0534
INFO - 2023-03-13 05:54:33 --> Config Class Initialized
INFO - 2023-03-13 05:54:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:54:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:54:33 --> Utf8 Class Initialized
INFO - 2023-03-13 05:54:33 --> URI Class Initialized
INFO - 2023-03-13 05:54:33 --> Router Class Initialized
INFO - 2023-03-13 05:54:33 --> Output Class Initialized
INFO - 2023-03-13 05:54:33 --> Security Class Initialized
DEBUG - 2023-03-13 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:54:33 --> Input Class Initialized
INFO - 2023-03-13 05:54:33 --> Language Class Initialized
INFO - 2023-03-13 05:54:33 --> Loader Class Initialized
INFO - 2023-03-13 05:54:33 --> Controller Class Initialized
DEBUG - 2023-03-13 05:54:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:54:33 --> Database Driver Class Initialized
INFO - 2023-03-13 05:54:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:54:33 --> Final output sent to browser
DEBUG - 2023-03-13 05:54:33 --> Total execution time: 0.0590
INFO - 2023-03-13 05:54:33 --> Config Class Initialized
INFO - 2023-03-13 05:54:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 05:54:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 05:54:33 --> Utf8 Class Initialized
INFO - 2023-03-13 05:54:33 --> URI Class Initialized
INFO - 2023-03-13 05:54:33 --> Router Class Initialized
INFO - 2023-03-13 05:54:33 --> Output Class Initialized
INFO - 2023-03-13 05:54:33 --> Security Class Initialized
DEBUG - 2023-03-13 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 05:54:33 --> Input Class Initialized
INFO - 2023-03-13 05:54:33 --> Language Class Initialized
INFO - 2023-03-13 05:54:33 --> Loader Class Initialized
INFO - 2023-03-13 05:54:33 --> Controller Class Initialized
DEBUG - 2023-03-13 05:54:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 05:54:33 --> Database Driver Class Initialized
INFO - 2023-03-13 05:54:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 05:54:33 --> Final output sent to browser
DEBUG - 2023-03-13 05:54:33 --> Total execution time: 0.0944
INFO - 2023-03-13 06:13:03 --> Config Class Initialized
INFO - 2023-03-13 06:13:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:03 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:03 --> URI Class Initialized
INFO - 2023-03-13 06:13:03 --> Router Class Initialized
INFO - 2023-03-13 06:13:03 --> Output Class Initialized
INFO - 2023-03-13 06:13:03 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:03 --> Input Class Initialized
INFO - 2023-03-13 06:13:03 --> Language Class Initialized
INFO - 2023-03-13 06:13:03 --> Loader Class Initialized
INFO - 2023-03-13 06:13:03 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:03 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:03 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:03 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:03 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:03 --> Total execution time: 0.0283
INFO - 2023-03-13 06:13:03 --> Config Class Initialized
INFO - 2023-03-13 06:13:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:03 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:03 --> URI Class Initialized
INFO - 2023-03-13 06:13:03 --> Router Class Initialized
INFO - 2023-03-13 06:13:03 --> Output Class Initialized
INFO - 2023-03-13 06:13:03 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:03 --> Input Class Initialized
INFO - 2023-03-13 06:13:03 --> Language Class Initialized
INFO - 2023-03-13 06:13:03 --> Loader Class Initialized
INFO - 2023-03-13 06:13:03 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:03 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:03 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:03 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:03 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:03 --> Total execution time: 0.0873
INFO - 2023-03-13 06:13:20 --> Config Class Initialized
INFO - 2023-03-13 06:13:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:20 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:20 --> URI Class Initialized
INFO - 2023-03-13 06:13:20 --> Router Class Initialized
INFO - 2023-03-13 06:13:20 --> Output Class Initialized
INFO - 2023-03-13 06:13:20 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:20 --> Input Class Initialized
INFO - 2023-03-13 06:13:20 --> Language Class Initialized
INFO - 2023-03-13 06:13:20 --> Loader Class Initialized
INFO - 2023-03-13 06:13:20 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:20 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:20 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:20 --> Total execution time: 0.0145
INFO - 2023-03-13 06:13:20 --> Config Class Initialized
INFO - 2023-03-13 06:13:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:20 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:20 --> URI Class Initialized
INFO - 2023-03-13 06:13:20 --> Router Class Initialized
INFO - 2023-03-13 06:13:20 --> Output Class Initialized
INFO - 2023-03-13 06:13:20 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:20 --> Input Class Initialized
INFO - 2023-03-13 06:13:20 --> Language Class Initialized
INFO - 2023-03-13 06:13:20 --> Loader Class Initialized
INFO - 2023-03-13 06:13:20 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:20 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:20 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:20 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:20 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:20 --> Total execution time: 0.0173
INFO - 2023-03-13 06:13:28 --> Config Class Initialized
INFO - 2023-03-13 06:13:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:28 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:28 --> URI Class Initialized
INFO - 2023-03-13 06:13:28 --> Router Class Initialized
INFO - 2023-03-13 06:13:28 --> Output Class Initialized
INFO - 2023-03-13 06:13:28 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:28 --> Input Class Initialized
INFO - 2023-03-13 06:13:28 --> Language Class Initialized
INFO - 2023-03-13 06:13:28 --> Loader Class Initialized
INFO - 2023-03-13 06:13:28 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:28 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:28 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:28 --> Total execution time: 0.0153
INFO - 2023-03-13 06:13:28 --> Config Class Initialized
INFO - 2023-03-13 06:13:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:28 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:28 --> URI Class Initialized
INFO - 2023-03-13 06:13:28 --> Router Class Initialized
INFO - 2023-03-13 06:13:28 --> Output Class Initialized
INFO - 2023-03-13 06:13:28 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:28 --> Input Class Initialized
INFO - 2023-03-13 06:13:28 --> Language Class Initialized
INFO - 2023-03-13 06:13:28 --> Loader Class Initialized
INFO - 2023-03-13 06:13:28 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:28 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:28 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:28 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:28 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:28 --> Total execution time: 0.0192
INFO - 2023-03-13 06:13:52 --> Config Class Initialized
INFO - 2023-03-13 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:52 --> URI Class Initialized
INFO - 2023-03-13 06:13:52 --> Router Class Initialized
INFO - 2023-03-13 06:13:52 --> Output Class Initialized
INFO - 2023-03-13 06:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:52 --> Input Class Initialized
INFO - 2023-03-13 06:13:52 --> Language Class Initialized
INFO - 2023-03-13 06:13:52 --> Loader Class Initialized
INFO - 2023-03-13 06:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:52 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:52 --> Total execution time: 0.0122
INFO - 2023-03-13 06:13:52 --> Config Class Initialized
INFO - 2023-03-13 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:52 --> URI Class Initialized
INFO - 2023-03-13 06:13:52 --> Router Class Initialized
INFO - 2023-03-13 06:13:52 --> Output Class Initialized
INFO - 2023-03-13 06:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:52 --> Input Class Initialized
INFO - 2023-03-13 06:13:52 --> Language Class Initialized
INFO - 2023-03-13 06:13:52 --> Loader Class Initialized
INFO - 2023-03-13 06:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:52 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:52 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:52 --> Total execution time: 0.0172
INFO - 2023-03-13 06:13:52 --> Config Class Initialized
INFO - 2023-03-13 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:52 --> URI Class Initialized
INFO - 2023-03-13 06:13:52 --> Router Class Initialized
INFO - 2023-03-13 06:13:52 --> Output Class Initialized
INFO - 2023-03-13 06:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:52 --> Input Class Initialized
INFO - 2023-03-13 06:13:52 --> Language Class Initialized
INFO - 2023-03-13 06:13:52 --> Loader Class Initialized
INFO - 2023-03-13 06:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:52 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:52 --> Total execution time: 0.0128
INFO - 2023-03-13 06:13:52 --> Config Class Initialized
INFO - 2023-03-13 06:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:52 --> URI Class Initialized
INFO - 2023-03-13 06:13:52 --> Router Class Initialized
INFO - 2023-03-13 06:13:52 --> Output Class Initialized
INFO - 2023-03-13 06:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:52 --> Input Class Initialized
INFO - 2023-03-13 06:13:52 --> Language Class Initialized
INFO - 2023-03-13 06:13:52 --> Loader Class Initialized
INFO - 2023-03-13 06:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:53 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:53 --> Total execution time: 1.2786
INFO - 2023-03-13 06:13:53 --> Config Class Initialized
INFO - 2023-03-13 06:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:53 --> URI Class Initialized
INFO - 2023-03-13 06:13:53 --> Router Class Initialized
INFO - 2023-03-13 06:13:53 --> Output Class Initialized
INFO - 2023-03-13 06:13:53 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:53 --> Input Class Initialized
INFO - 2023-03-13 06:13:53 --> Language Class Initialized
INFO - 2023-03-13 06:13:53 --> Loader Class Initialized
INFO - 2023-03-13 06:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:53 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:53 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:53 --> Total execution time: 0.0621
INFO - 2023-03-13 06:13:53 --> Config Class Initialized
INFO - 2023-03-13 06:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 06:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 06:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 06:13:53 --> URI Class Initialized
INFO - 2023-03-13 06:13:53 --> Router Class Initialized
INFO - 2023-03-13 06:13:53 --> Output Class Initialized
INFO - 2023-03-13 06:13:53 --> Security Class Initialized
DEBUG - 2023-03-13 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 06:13:53 --> Input Class Initialized
INFO - 2023-03-13 06:13:53 --> Language Class Initialized
INFO - 2023-03-13 06:13:53 --> Loader Class Initialized
INFO - 2023-03-13 06:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 06:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 06:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 06:13:53 --> Model "Login_model" initialized
INFO - 2023-03-13 06:13:53 --> Final output sent to browser
DEBUG - 2023-03-13 06:13:53 --> Total execution time: 0.0233
INFO - 2023-03-13 07:04:47 --> Config Class Initialized
INFO - 2023-03-13 07:04:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:04:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:04:47 --> Utf8 Class Initialized
INFO - 2023-03-13 07:04:47 --> URI Class Initialized
INFO - 2023-03-13 07:04:47 --> Router Class Initialized
INFO - 2023-03-13 07:04:47 --> Output Class Initialized
INFO - 2023-03-13 07:04:47 --> Security Class Initialized
DEBUG - 2023-03-13 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:04:47 --> Input Class Initialized
INFO - 2023-03-13 07:04:47 --> Language Class Initialized
INFO - 2023-03-13 07:04:47 --> Loader Class Initialized
INFO - 2023-03-13 07:04:47 --> Controller Class Initialized
DEBUG - 2023-03-13 07:04:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:04:47 --> Database Driver Class Initialized
INFO - 2023-03-13 07:04:47 --> Database Driver Class Initialized
INFO - 2023-03-13 07:04:47 --> Model "Login_model" initialized
INFO - 2023-03-13 07:04:47 --> Final output sent to browser
DEBUG - 2023-03-13 07:04:47 --> Total execution time: 0.1716
INFO - 2023-03-13 07:04:47 --> Config Class Initialized
INFO - 2023-03-13 07:04:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:04:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:04:47 --> Utf8 Class Initialized
INFO - 2023-03-13 07:04:47 --> URI Class Initialized
INFO - 2023-03-13 07:04:47 --> Router Class Initialized
INFO - 2023-03-13 07:04:47 --> Output Class Initialized
INFO - 2023-03-13 07:04:47 --> Security Class Initialized
DEBUG - 2023-03-13 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:04:47 --> Input Class Initialized
INFO - 2023-03-13 07:04:47 --> Language Class Initialized
INFO - 2023-03-13 07:04:47 --> Loader Class Initialized
INFO - 2023-03-13 07:04:47 --> Controller Class Initialized
DEBUG - 2023-03-13 07:04:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:04:47 --> Database Driver Class Initialized
INFO - 2023-03-13 07:04:47 --> Database Driver Class Initialized
INFO - 2023-03-13 07:04:47 --> Model "Login_model" initialized
INFO - 2023-03-13 07:04:47 --> Final output sent to browser
DEBUG - 2023-03-13 07:04:47 --> Total execution time: 0.0637
INFO - 2023-03-13 07:35:58 --> Config Class Initialized
INFO - 2023-03-13 07:35:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:35:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:35:58 --> Utf8 Class Initialized
INFO - 2023-03-13 07:35:58 --> URI Class Initialized
INFO - 2023-03-13 07:35:58 --> Router Class Initialized
INFO - 2023-03-13 07:35:58 --> Output Class Initialized
INFO - 2023-03-13 07:35:58 --> Security Class Initialized
DEBUG - 2023-03-13 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:35:58 --> Input Class Initialized
INFO - 2023-03-13 07:35:58 --> Language Class Initialized
INFO - 2023-03-13 07:35:58 --> Loader Class Initialized
INFO - 2023-03-13 07:35:58 --> Controller Class Initialized
DEBUG - 2023-03-13 07:35:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:35:58 --> Database Driver Class Initialized
INFO - 2023-03-13 07:35:58 --> Database Driver Class Initialized
INFO - 2023-03-13 07:35:58 --> Model "Login_model" initialized
INFO - 2023-03-13 07:35:58 --> Final output sent to browser
DEBUG - 2023-03-13 07:35:58 --> Total execution time: 0.1034
INFO - 2023-03-13 07:35:58 --> Config Class Initialized
INFO - 2023-03-13 07:35:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:35:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:35:58 --> Utf8 Class Initialized
INFO - 2023-03-13 07:35:58 --> URI Class Initialized
INFO - 2023-03-13 07:35:58 --> Router Class Initialized
INFO - 2023-03-13 07:35:58 --> Output Class Initialized
INFO - 2023-03-13 07:35:58 --> Security Class Initialized
DEBUG - 2023-03-13 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:35:58 --> Input Class Initialized
INFO - 2023-03-13 07:35:58 --> Language Class Initialized
INFO - 2023-03-13 07:35:58 --> Loader Class Initialized
INFO - 2023-03-13 07:35:58 --> Controller Class Initialized
DEBUG - 2023-03-13 07:35:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:35:58 --> Database Driver Class Initialized
INFO - 2023-03-13 07:35:58 --> Database Driver Class Initialized
INFO - 2023-03-13 07:35:58 --> Model "Login_model" initialized
INFO - 2023-03-13 07:35:58 --> Final output sent to browser
DEBUG - 2023-03-13 07:35:58 --> Total execution time: 0.0560
INFO - 2023-03-13 07:36:08 --> Config Class Initialized
INFO - 2023-03-13 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-13 07:36:08 --> URI Class Initialized
INFO - 2023-03-13 07:36:08 --> Router Class Initialized
INFO - 2023-03-13 07:36:08 --> Output Class Initialized
INFO - 2023-03-13 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-13 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:36:08 --> Input Class Initialized
INFO - 2023-03-13 07:36:08 --> Language Class Initialized
INFO - 2023-03-13 07:36:08 --> Loader Class Initialized
INFO - 2023-03-13 07:36:08 --> Controller Class Initialized
DEBUG - 2023-03-13 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-13 07:36:08 --> Total execution time: 0.0140
INFO - 2023-03-13 07:36:08 --> Config Class Initialized
INFO - 2023-03-13 07:36:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:36:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:36:08 --> Utf8 Class Initialized
INFO - 2023-03-13 07:36:08 --> URI Class Initialized
INFO - 2023-03-13 07:36:08 --> Router Class Initialized
INFO - 2023-03-13 07:36:08 --> Output Class Initialized
INFO - 2023-03-13 07:36:08 --> Security Class Initialized
DEBUG - 2023-03-13 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:36:08 --> Input Class Initialized
INFO - 2023-03-13 07:36:08 --> Language Class Initialized
INFO - 2023-03-13 07:36:08 --> Loader Class Initialized
INFO - 2023-03-13 07:36:08 --> Controller Class Initialized
DEBUG - 2023-03-13 07:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:08 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:08 --> Model "Login_model" initialized
INFO - 2023-03-13 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-13 07:36:08 --> Total execution time: 0.0299
INFO - 2023-03-13 07:36:42 --> Config Class Initialized
INFO - 2023-03-13 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:36:42 --> Utf8 Class Initialized
INFO - 2023-03-13 07:36:42 --> URI Class Initialized
INFO - 2023-03-13 07:36:42 --> Router Class Initialized
INFO - 2023-03-13 07:36:42 --> Output Class Initialized
INFO - 2023-03-13 07:36:42 --> Security Class Initialized
DEBUG - 2023-03-13 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:36:42 --> Input Class Initialized
INFO - 2023-03-13 07:36:42 --> Language Class Initialized
INFO - 2023-03-13 07:36:42 --> Loader Class Initialized
INFO - 2023-03-13 07:36:42 --> Controller Class Initialized
DEBUG - 2023-03-13 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:36:42 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:43 --> Final output sent to browser
DEBUG - 2023-03-13 07:36:43 --> Total execution time: 0.1651
INFO - 2023-03-13 07:36:43 --> Config Class Initialized
INFO - 2023-03-13 07:36:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:36:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:36:43 --> Utf8 Class Initialized
INFO - 2023-03-13 07:36:43 --> URI Class Initialized
INFO - 2023-03-13 07:36:43 --> Router Class Initialized
INFO - 2023-03-13 07:36:43 --> Output Class Initialized
INFO - 2023-03-13 07:36:43 --> Security Class Initialized
DEBUG - 2023-03-13 07:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:36:43 --> Input Class Initialized
INFO - 2023-03-13 07:36:43 --> Language Class Initialized
INFO - 2023-03-13 07:36:43 --> Loader Class Initialized
INFO - 2023-03-13 07:36:43 --> Controller Class Initialized
DEBUG - 2023-03-13 07:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:36:43 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:43 --> Database Driver Class Initialized
INFO - 2023-03-13 07:36:43 --> Model "Login_model" initialized
INFO - 2023-03-13 07:36:43 --> Final output sent to browser
DEBUG - 2023-03-13 07:36:43 --> Total execution time: 0.1678
INFO - 2023-03-13 07:37:04 --> Config Class Initialized
INFO - 2023-03-13 07:37:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:37:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:37:04 --> Utf8 Class Initialized
INFO - 2023-03-13 07:37:04 --> URI Class Initialized
INFO - 2023-03-13 07:37:04 --> Router Class Initialized
INFO - 2023-03-13 07:37:04 --> Output Class Initialized
INFO - 2023-03-13 07:37:04 --> Security Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:37:04 --> Input Class Initialized
INFO - 2023-03-13 07:37:04 --> Language Class Initialized
INFO - 2023-03-13 07:37:04 --> Loader Class Initialized
INFO - 2023-03-13 07:37:04 --> Controller Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:37:04 --> Database Driver Class Initialized
INFO - 2023-03-13 07:37:04 --> Final output sent to browser
DEBUG - 2023-03-13 07:37:04 --> Total execution time: 0.0171
INFO - 2023-03-13 07:37:04 --> Config Class Initialized
INFO - 2023-03-13 07:37:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:37:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:37:04 --> Utf8 Class Initialized
INFO - 2023-03-13 07:37:04 --> URI Class Initialized
INFO - 2023-03-13 07:37:04 --> Router Class Initialized
INFO - 2023-03-13 07:37:04 --> Output Class Initialized
INFO - 2023-03-13 07:37:04 --> Security Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:37:04 --> Input Class Initialized
INFO - 2023-03-13 07:37:04 --> Language Class Initialized
INFO - 2023-03-13 07:37:04 --> Loader Class Initialized
INFO - 2023-03-13 07:37:04 --> Controller Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:37:04 --> Database Driver Class Initialized
INFO - 2023-03-13 07:37:04 --> Database Driver Class Initialized
INFO - 2023-03-13 07:37:04 --> Model "Login_model" initialized
INFO - 2023-03-13 07:37:04 --> Final output sent to browser
DEBUG - 2023-03-13 07:37:04 --> Total execution time: 0.0248
INFO - 2023-03-13 07:37:04 --> Config Class Initialized
INFO - 2023-03-13 07:37:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:37:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:37:04 --> Utf8 Class Initialized
INFO - 2023-03-13 07:37:04 --> URI Class Initialized
INFO - 2023-03-13 07:37:04 --> Router Class Initialized
INFO - 2023-03-13 07:37:04 --> Output Class Initialized
INFO - 2023-03-13 07:37:04 --> Security Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:37:04 --> Input Class Initialized
INFO - 2023-03-13 07:37:04 --> Language Class Initialized
INFO - 2023-03-13 07:37:04 --> Loader Class Initialized
INFO - 2023-03-13 07:37:04 --> Controller Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:37:04 --> Database Driver Class Initialized
INFO - 2023-03-13 07:37:04 --> Final output sent to browser
DEBUG - 2023-03-13 07:37:04 --> Total execution time: 0.0175
INFO - 2023-03-13 07:37:04 --> Config Class Initialized
INFO - 2023-03-13 07:37:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:37:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:37:04 --> Utf8 Class Initialized
INFO - 2023-03-13 07:37:04 --> URI Class Initialized
INFO - 2023-03-13 07:37:04 --> Router Class Initialized
INFO - 2023-03-13 07:37:04 --> Output Class Initialized
INFO - 2023-03-13 07:37:04 --> Security Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:37:04 --> Input Class Initialized
INFO - 2023-03-13 07:37:04 --> Language Class Initialized
INFO - 2023-03-13 07:37:04 --> Loader Class Initialized
INFO - 2023-03-13 07:37:04 --> Controller Class Initialized
DEBUG - 2023-03-13 07:37:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:37:04 --> Database Driver Class Initialized
INFO - 2023-03-13 07:37:04 --> Final output sent to browser
DEBUG - 2023-03-13 07:37:04 --> Total execution time: 0.0313
INFO - 2023-03-13 07:38:22 --> Config Class Initialized
INFO - 2023-03-13 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:22 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:22 --> URI Class Initialized
INFO - 2023-03-13 07:38:22 --> Router Class Initialized
INFO - 2023-03-13 07:38:22 --> Output Class Initialized
INFO - 2023-03-13 07:38:22 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:22 --> Input Class Initialized
INFO - 2023-03-13 07:38:22 --> Language Class Initialized
INFO - 2023-03-13 07:38:22 --> Loader Class Initialized
INFO - 2023-03-13 07:38:22 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:22 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:22 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:22 --> Total execution time: 0.0171
INFO - 2023-03-13 07:38:22 --> Config Class Initialized
INFO - 2023-03-13 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:22 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:22 --> URI Class Initialized
INFO - 2023-03-13 07:38:22 --> Router Class Initialized
INFO - 2023-03-13 07:38:22 --> Output Class Initialized
INFO - 2023-03-13 07:38:22 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:22 --> Input Class Initialized
INFO - 2023-03-13 07:38:22 --> Language Class Initialized
INFO - 2023-03-13 07:38:22 --> Loader Class Initialized
INFO - 2023-03-13 07:38:22 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:22 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:22 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:22 --> Model "Login_model" initialized
INFO - 2023-03-13 07:38:22 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:22 --> Total execution time: 0.0337
INFO - 2023-03-13 07:38:22 --> Config Class Initialized
INFO - 2023-03-13 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:22 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:22 --> URI Class Initialized
INFO - 2023-03-13 07:38:22 --> Router Class Initialized
INFO - 2023-03-13 07:38:22 --> Output Class Initialized
INFO - 2023-03-13 07:38:22 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:22 --> Input Class Initialized
INFO - 2023-03-13 07:38:22 --> Language Class Initialized
INFO - 2023-03-13 07:38:22 --> Loader Class Initialized
INFO - 2023-03-13 07:38:22 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:22 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:22 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:22 --> Total execution time: 0.0132
INFO - 2023-03-13 07:38:22 --> Config Class Initialized
INFO - 2023-03-13 07:38:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:22 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:22 --> URI Class Initialized
INFO - 2023-03-13 07:38:22 --> Router Class Initialized
INFO - 2023-03-13 07:38:22 --> Output Class Initialized
INFO - 2023-03-13 07:38:22 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:22 --> Input Class Initialized
INFO - 2023-03-13 07:38:22 --> Language Class Initialized
INFO - 2023-03-13 07:38:22 --> Loader Class Initialized
INFO - 2023-03-13 07:38:22 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:22 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:22 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:22 --> Total execution time: 0.0284
INFO - 2023-03-13 07:38:27 --> Config Class Initialized
INFO - 2023-03-13 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:27 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:27 --> URI Class Initialized
INFO - 2023-03-13 07:38:27 --> Router Class Initialized
INFO - 2023-03-13 07:38:27 --> Output Class Initialized
INFO - 2023-03-13 07:38:27 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:27 --> Input Class Initialized
INFO - 2023-03-13 07:38:27 --> Language Class Initialized
INFO - 2023-03-13 07:38:27 --> Loader Class Initialized
INFO - 2023-03-13 07:38:27 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:27 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:27 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:27 --> Total execution time: 0.0125
INFO - 2023-03-13 07:38:27 --> Config Class Initialized
INFO - 2023-03-13 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:27 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:27 --> URI Class Initialized
INFO - 2023-03-13 07:38:27 --> Router Class Initialized
INFO - 2023-03-13 07:38:27 --> Output Class Initialized
INFO - 2023-03-13 07:38:27 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:27 --> Input Class Initialized
INFO - 2023-03-13 07:38:27 --> Language Class Initialized
INFO - 2023-03-13 07:38:27 --> Loader Class Initialized
INFO - 2023-03-13 07:38:27 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:27 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:27 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:27 --> Model "Login_model" initialized
INFO - 2023-03-13 07:38:27 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:27 --> Total execution time: 0.0213
INFO - 2023-03-13 07:38:27 --> Config Class Initialized
INFO - 2023-03-13 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:27 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:27 --> URI Class Initialized
INFO - 2023-03-13 07:38:27 --> Router Class Initialized
INFO - 2023-03-13 07:38:27 --> Output Class Initialized
INFO - 2023-03-13 07:38:27 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:27 --> Input Class Initialized
INFO - 2023-03-13 07:38:27 --> Language Class Initialized
INFO - 2023-03-13 07:38:27 --> Loader Class Initialized
INFO - 2023-03-13 07:38:27 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:27 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:27 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:27 --> Total execution time: 0.0117
INFO - 2023-03-13 07:38:27 --> Config Class Initialized
INFO - 2023-03-13 07:38:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:38:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:38:27 --> Utf8 Class Initialized
INFO - 2023-03-13 07:38:27 --> URI Class Initialized
INFO - 2023-03-13 07:38:27 --> Router Class Initialized
INFO - 2023-03-13 07:38:27 --> Output Class Initialized
INFO - 2023-03-13 07:38:27 --> Security Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:38:27 --> Input Class Initialized
INFO - 2023-03-13 07:38:27 --> Language Class Initialized
INFO - 2023-03-13 07:38:27 --> Loader Class Initialized
INFO - 2023-03-13 07:38:27 --> Controller Class Initialized
DEBUG - 2023-03-13 07:38:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:38:27 --> Database Driver Class Initialized
INFO - 2023-03-13 07:38:27 --> Final output sent to browser
DEBUG - 2023-03-13 07:38:27 --> Total execution time: 0.0266
INFO - 2023-03-13 07:39:17 --> Config Class Initialized
INFO - 2023-03-13 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-13 07:39:17 --> URI Class Initialized
INFO - 2023-03-13 07:39:17 --> Router Class Initialized
INFO - 2023-03-13 07:39:17 --> Output Class Initialized
INFO - 2023-03-13 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:39:17 --> Input Class Initialized
INFO - 2023-03-13 07:39:17 --> Language Class Initialized
INFO - 2023-03-13 07:39:17 --> Loader Class Initialized
INFO - 2023-03-13 07:39:17 --> Controller Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:39:17 --> Database Driver Class Initialized
INFO - 2023-03-13 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-13 07:39:17 --> Total execution time: 0.0119
INFO - 2023-03-13 07:39:17 --> Config Class Initialized
INFO - 2023-03-13 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-13 07:39:17 --> URI Class Initialized
INFO - 2023-03-13 07:39:17 --> Router Class Initialized
INFO - 2023-03-13 07:39:17 --> Output Class Initialized
INFO - 2023-03-13 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:39:17 --> Input Class Initialized
INFO - 2023-03-13 07:39:17 --> Language Class Initialized
INFO - 2023-03-13 07:39:17 --> Loader Class Initialized
INFO - 2023-03-13 07:39:17 --> Controller Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:39:17 --> Database Driver Class Initialized
INFO - 2023-03-13 07:39:17 --> Database Driver Class Initialized
INFO - 2023-03-13 07:39:17 --> Model "Login_model" initialized
INFO - 2023-03-13 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-13 07:39:17 --> Total execution time: 0.0161
INFO - 2023-03-13 07:39:17 --> Config Class Initialized
INFO - 2023-03-13 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-13 07:39:17 --> URI Class Initialized
INFO - 2023-03-13 07:39:17 --> Router Class Initialized
INFO - 2023-03-13 07:39:17 --> Output Class Initialized
INFO - 2023-03-13 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:39:17 --> Input Class Initialized
INFO - 2023-03-13 07:39:17 --> Language Class Initialized
INFO - 2023-03-13 07:39:17 --> Loader Class Initialized
INFO - 2023-03-13 07:39:17 --> Controller Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:39:17 --> Database Driver Class Initialized
INFO - 2023-03-13 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-13 07:39:17 --> Total execution time: 0.0501
INFO - 2023-03-13 07:39:17 --> Config Class Initialized
INFO - 2023-03-13 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-13 07:39:17 --> URI Class Initialized
INFO - 2023-03-13 07:39:17 --> Router Class Initialized
INFO - 2023-03-13 07:39:17 --> Output Class Initialized
INFO - 2023-03-13 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:39:17 --> Input Class Initialized
INFO - 2023-03-13 07:39:17 --> Language Class Initialized
INFO - 2023-03-13 07:39:17 --> Loader Class Initialized
INFO - 2023-03-13 07:39:17 --> Controller Class Initialized
DEBUG - 2023-03-13 07:39:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:39:17 --> Database Driver Class Initialized
INFO - 2023-03-13 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-13 07:39:17 --> Total execution time: 0.0265
INFO - 2023-03-13 07:44:39 --> Config Class Initialized
INFO - 2023-03-13 07:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:39 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:39 --> URI Class Initialized
INFO - 2023-03-13 07:44:39 --> Router Class Initialized
INFO - 2023-03-13 07:44:39 --> Output Class Initialized
INFO - 2023-03-13 07:44:39 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:39 --> Input Class Initialized
INFO - 2023-03-13 07:44:39 --> Language Class Initialized
INFO - 2023-03-13 07:44:39 --> Loader Class Initialized
INFO - 2023-03-13 07:44:39 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:39 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:39 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:39 --> Total execution time: 0.0448
INFO - 2023-03-13 07:44:39 --> Config Class Initialized
INFO - 2023-03-13 07:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:39 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:39 --> URI Class Initialized
INFO - 2023-03-13 07:44:39 --> Router Class Initialized
INFO - 2023-03-13 07:44:39 --> Output Class Initialized
INFO - 2023-03-13 07:44:39 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:39 --> Input Class Initialized
INFO - 2023-03-13 07:44:39 --> Language Class Initialized
INFO - 2023-03-13 07:44:39 --> Loader Class Initialized
INFO - 2023-03-13 07:44:39 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:39 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:39 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:39 --> Model "Login_model" initialized
INFO - 2023-03-13 07:44:39 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:39 --> Total execution time: 0.0257
INFO - 2023-03-13 07:44:39 --> Config Class Initialized
INFO - 2023-03-13 07:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:39 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:39 --> URI Class Initialized
INFO - 2023-03-13 07:44:39 --> Router Class Initialized
INFO - 2023-03-13 07:44:39 --> Output Class Initialized
INFO - 2023-03-13 07:44:39 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:39 --> Input Class Initialized
INFO - 2023-03-13 07:44:39 --> Language Class Initialized
INFO - 2023-03-13 07:44:39 --> Loader Class Initialized
INFO - 2023-03-13 07:44:39 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:39 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:39 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:39 --> Total execution time: 0.0091
INFO - 2023-03-13 07:44:39 --> Config Class Initialized
INFO - 2023-03-13 07:44:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:39 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:39 --> URI Class Initialized
INFO - 2023-03-13 07:44:39 --> Router Class Initialized
INFO - 2023-03-13 07:44:39 --> Output Class Initialized
INFO - 2023-03-13 07:44:39 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:39 --> Input Class Initialized
INFO - 2023-03-13 07:44:39 --> Language Class Initialized
INFO - 2023-03-13 07:44:39 --> Loader Class Initialized
INFO - 2023-03-13 07:44:39 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:39 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:40 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:40 --> Total execution time: 0.8063
INFO - 2023-03-13 07:44:40 --> Config Class Initialized
INFO - 2023-03-13 07:44:40 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:40 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:40 --> URI Class Initialized
INFO - 2023-03-13 07:44:40 --> Router Class Initialized
INFO - 2023-03-13 07:44:40 --> Output Class Initialized
INFO - 2023-03-13 07:44:40 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:40 --> Input Class Initialized
INFO - 2023-03-13 07:44:40 --> Language Class Initialized
INFO - 2023-03-13 07:44:40 --> Loader Class Initialized
INFO - 2023-03-13 07:44:40 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:40 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:40 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:40 --> Model "Login_model" initialized
INFO - 2023-03-13 07:44:40 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:40 --> Total execution time: 0.0497
INFO - 2023-03-13 07:44:40 --> Config Class Initialized
INFO - 2023-03-13 07:44:40 --> Hooks Class Initialized
DEBUG - 2023-03-13 07:44:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 07:44:40 --> Utf8 Class Initialized
INFO - 2023-03-13 07:44:40 --> URI Class Initialized
INFO - 2023-03-13 07:44:40 --> Router Class Initialized
INFO - 2023-03-13 07:44:40 --> Output Class Initialized
INFO - 2023-03-13 07:44:40 --> Security Class Initialized
DEBUG - 2023-03-13 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 07:44:40 --> Input Class Initialized
INFO - 2023-03-13 07:44:40 --> Language Class Initialized
INFO - 2023-03-13 07:44:40 --> Loader Class Initialized
INFO - 2023-03-13 07:44:40 --> Controller Class Initialized
DEBUG - 2023-03-13 07:44:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 07:44:40 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:40 --> Database Driver Class Initialized
INFO - 2023-03-13 07:44:40 --> Model "Login_model" initialized
INFO - 2023-03-13 07:44:40 --> Final output sent to browser
DEBUG - 2023-03-13 07:44:40 --> Total execution time: 0.0693
INFO - 2023-03-13 08:03:52 --> Config Class Initialized
INFO - 2023-03-13 08:03:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:03:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:03:52 --> Utf8 Class Initialized
INFO - 2023-03-13 08:03:52 --> URI Class Initialized
INFO - 2023-03-13 08:03:52 --> Router Class Initialized
INFO - 2023-03-13 08:03:52 --> Output Class Initialized
INFO - 2023-03-13 08:03:52 --> Security Class Initialized
DEBUG - 2023-03-13 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:03:52 --> Input Class Initialized
INFO - 2023-03-13 08:03:52 --> Language Class Initialized
INFO - 2023-03-13 08:03:52 --> Loader Class Initialized
INFO - 2023-03-13 08:03:52 --> Controller Class Initialized
DEBUG - 2023-03-13 08:03:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:03:52 --> Database Driver Class Initialized
INFO - 2023-03-13 08:03:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:03:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:03:53 --> Model "Login_model" initialized
INFO - 2023-03-13 08:03:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:03:53 --> Total execution time: 0.0597
INFO - 2023-03-13 08:03:53 --> Config Class Initialized
INFO - 2023-03-13 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:03:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:03:53 --> URI Class Initialized
INFO - 2023-03-13 08:03:53 --> Router Class Initialized
INFO - 2023-03-13 08:03:53 --> Output Class Initialized
INFO - 2023-03-13 08:03:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:03:53 --> Input Class Initialized
INFO - 2023-03-13 08:03:53 --> Language Class Initialized
INFO - 2023-03-13 08:03:53 --> Loader Class Initialized
INFO - 2023-03-13 08:03:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:03:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:03:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:03:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:03:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:03:53 --> Model "Login_model" initialized
INFO - 2023-03-13 08:03:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:03:53 --> Total execution time: 0.1214
INFO - 2023-03-13 08:03:56 --> Config Class Initialized
INFO - 2023-03-13 08:03:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:03:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:03:56 --> Utf8 Class Initialized
INFO - 2023-03-13 08:03:56 --> URI Class Initialized
INFO - 2023-03-13 08:03:56 --> Router Class Initialized
INFO - 2023-03-13 08:03:56 --> Output Class Initialized
INFO - 2023-03-13 08:03:56 --> Security Class Initialized
DEBUG - 2023-03-13 08:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:03:56 --> Input Class Initialized
INFO - 2023-03-13 08:03:56 --> Language Class Initialized
INFO - 2023-03-13 08:03:56 --> Loader Class Initialized
INFO - 2023-03-13 08:03:56 --> Controller Class Initialized
DEBUG - 2023-03-13 08:03:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:03:56 --> Final output sent to browser
DEBUG - 2023-03-13 08:03:56 --> Total execution time: 0.1082
INFO - 2023-03-13 08:03:56 --> Config Class Initialized
INFO - 2023-03-13 08:03:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:03:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:03:56 --> Utf8 Class Initialized
INFO - 2023-03-13 08:03:56 --> URI Class Initialized
INFO - 2023-03-13 08:03:56 --> Router Class Initialized
INFO - 2023-03-13 08:03:56 --> Output Class Initialized
INFO - 2023-03-13 08:03:56 --> Security Class Initialized
DEBUG - 2023-03-13 08:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:03:56 --> Input Class Initialized
INFO - 2023-03-13 08:03:56 --> Language Class Initialized
INFO - 2023-03-13 08:03:56 --> Loader Class Initialized
INFO - 2023-03-13 08:03:56 --> Controller Class Initialized
DEBUG - 2023-03-13 08:03:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:03:56 --> Final output sent to browser
DEBUG - 2023-03-13 08:03:56 --> Total execution time: 0.0526
INFO - 2023-03-13 08:04:19 --> Config Class Initialized
INFO - 2023-03-13 08:04:19 --> Config Class Initialized
INFO - 2023-03-13 08:04:19 --> Hooks Class Initialized
INFO - 2023-03-13 08:04:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:19 --> Utf8 Class Initialized
DEBUG - 2023-03-13 08:04:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:19 --> URI Class Initialized
INFO - 2023-03-13 08:04:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:19 --> URI Class Initialized
INFO - 2023-03-13 08:04:19 --> Router Class Initialized
INFO - 2023-03-13 08:04:19 --> Router Class Initialized
INFO - 2023-03-13 08:04:19 --> Output Class Initialized
INFO - 2023-03-13 08:04:19 --> Output Class Initialized
INFO - 2023-03-13 08:04:19 --> Security Class Initialized
INFO - 2023-03-13 08:04:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:19 --> Input Class Initialized
INFO - 2023-03-13 08:04:19 --> Input Class Initialized
INFO - 2023-03-13 08:04:19 --> Language Class Initialized
INFO - 2023-03-13 08:04:19 --> Language Class Initialized
INFO - 2023-03-13 08:04:19 --> Loader Class Initialized
INFO - 2023-03-13 08:04:19 --> Loader Class Initialized
INFO - 2023-03-13 08:04:19 --> Controller Class Initialized
INFO - 2023-03-13 08:04:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:04:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:19 --> Total execution time: 0.0177
INFO - 2023-03-13 08:04:19 --> Config Class Initialized
INFO - 2023-03-13 08:04:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:19 --> URI Class Initialized
INFO - 2023-03-13 08:04:19 --> Router Class Initialized
INFO - 2023-03-13 08:04:19 --> Output Class Initialized
INFO - 2023-03-13 08:04:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:19 --> Input Class Initialized
INFO - 2023-03-13 08:04:19 --> Language Class Initialized
INFO - 2023-03-13 08:04:19 --> Loader Class Initialized
INFO - 2023-03-13 08:04:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:19 --> Total execution time: 0.1345
INFO - 2023-03-13 08:04:19 --> Config Class Initialized
INFO - 2023-03-13 08:04:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:19 --> URI Class Initialized
INFO - 2023-03-13 08:04:19 --> Router Class Initialized
INFO - 2023-03-13 08:04:19 --> Output Class Initialized
INFO - 2023-03-13 08:04:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:19 --> Input Class Initialized
INFO - 2023-03-13 08:04:19 --> Language Class Initialized
INFO - 2023-03-13 08:04:19 --> Loader Class Initialized
INFO - 2023-03-13 08:04:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:20 --> Config Class Initialized
INFO - 2023-03-13 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:20 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:20 --> URI Class Initialized
INFO - 2023-03-13 08:04:20 --> Router Class Initialized
INFO - 2023-03-13 08:04:20 --> Output Class Initialized
INFO - 2023-03-13 08:04:20 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:20 --> Input Class Initialized
INFO - 2023-03-13 08:04:20 --> Language Class Initialized
INFO - 2023-03-13 08:04:20 --> Loader Class Initialized
INFO - 2023-03-13 08:04:20 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:20 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:20 --> Total execution time: 0.0628
INFO - 2023-03-13 08:04:20 --> Config Class Initialized
INFO - 2023-03-13 08:04:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:20 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:20 --> URI Class Initialized
INFO - 2023-03-13 08:04:20 --> Router Class Initialized
INFO - 2023-03-13 08:04:20 --> Output Class Initialized
INFO - 2023-03-13 08:04:20 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:20 --> Input Class Initialized
INFO - 2023-03-13 08:04:20 --> Language Class Initialized
INFO - 2023-03-13 08:04:20 --> Loader Class Initialized
INFO - 2023-03-13 08:04:20 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:20 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:20 --> Total execution time: 0.0613
INFO - 2023-03-13 08:04:25 --> Config Class Initialized
INFO - 2023-03-13 08:04:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:25 --> URI Class Initialized
INFO - 2023-03-13 08:04:25 --> Router Class Initialized
INFO - 2023-03-13 08:04:25 --> Output Class Initialized
INFO - 2023-03-13 08:04:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:25 --> Input Class Initialized
INFO - 2023-03-13 08:04:25 --> Language Class Initialized
INFO - 2023-03-13 08:04:25 --> Loader Class Initialized
INFO - 2023-03-13 08:04:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:25 --> Total execution time: 0.0057
INFO - 2023-03-13 08:04:25 --> Config Class Initialized
INFO - 2023-03-13 08:04:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:25 --> URI Class Initialized
INFO - 2023-03-13 08:04:25 --> Router Class Initialized
INFO - 2023-03-13 08:04:25 --> Output Class Initialized
INFO - 2023-03-13 08:04:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:25 --> Input Class Initialized
INFO - 2023-03-13 08:04:25 --> Language Class Initialized
INFO - 2023-03-13 08:04:25 --> Loader Class Initialized
INFO - 2023-03-13 08:04:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:25 --> Total execution time: 0.0527
INFO - 2023-03-13 08:04:30 --> Config Class Initialized
INFO - 2023-03-13 08:04:30 --> Config Class Initialized
INFO - 2023-03-13 08:04:30 --> Hooks Class Initialized
INFO - 2023-03-13 08:04:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:30 --> Utf8 Class Initialized
DEBUG - 2023-03-13 08:04:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:30 --> URI Class Initialized
INFO - 2023-03-13 08:04:30 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:30 --> Router Class Initialized
INFO - 2023-03-13 08:04:30 --> URI Class Initialized
INFO - 2023-03-13 08:04:30 --> Output Class Initialized
INFO - 2023-03-13 08:04:30 --> Router Class Initialized
INFO - 2023-03-13 08:04:30 --> Security Class Initialized
INFO - 2023-03-13 08:04:30 --> Output Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:30 --> Security Class Initialized
INFO - 2023-03-13 08:04:30 --> Input Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:30 --> Language Class Initialized
INFO - 2023-03-13 08:04:30 --> Input Class Initialized
INFO - 2023-03-13 08:04:30 --> Language Class Initialized
INFO - 2023-03-13 08:04:30 --> Loader Class Initialized
INFO - 2023-03-13 08:04:30 --> Controller Class Initialized
INFO - 2023-03-13 08:04:30 --> Loader Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:30 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:30 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:30 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:30 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:30 --> Total execution time: 0.0148
INFO - 2023-03-13 08:04:30 --> Config Class Initialized
INFO - 2023-03-13 08:04:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:30 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:30 --> URI Class Initialized
INFO - 2023-03-13 08:04:30 --> Router Class Initialized
INFO - 2023-03-13 08:04:30 --> Output Class Initialized
INFO - 2023-03-13 08:04:30 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:30 --> Input Class Initialized
INFO - 2023-03-13 08:04:30 --> Language Class Initialized
INFO - 2023-03-13 08:04:30 --> Loader Class Initialized
INFO - 2023-03-13 08:04:30 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:30 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:30 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:30 --> Total execution time: 0.0102
INFO - 2023-03-13 08:04:30 --> Config Class Initialized
INFO - 2023-03-13 08:04:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:30 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:30 --> URI Class Initialized
INFO - 2023-03-13 08:04:30 --> Router Class Initialized
INFO - 2023-03-13 08:04:30 --> Output Class Initialized
INFO - 2023-03-13 08:04:30 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:30 --> Input Class Initialized
INFO - 2023-03-13 08:04:30 --> Language Class Initialized
INFO - 2023-03-13 08:04:30 --> Loader Class Initialized
INFO - 2023-03-13 08:04:30 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:30 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:32 --> Config Class Initialized
INFO - 2023-03-13 08:04:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:32 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:32 --> URI Class Initialized
INFO - 2023-03-13 08:04:32 --> Router Class Initialized
INFO - 2023-03-13 08:04:32 --> Output Class Initialized
INFO - 2023-03-13 08:04:32 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:32 --> Input Class Initialized
INFO - 2023-03-13 08:04:32 --> Language Class Initialized
INFO - 2023-03-13 08:04:32 --> Loader Class Initialized
INFO - 2023-03-13 08:04:32 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:32 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:32 --> Config Class Initialized
INFO - 2023-03-13 08:04:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:32 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:32 --> URI Class Initialized
INFO - 2023-03-13 08:04:32 --> Router Class Initialized
INFO - 2023-03-13 08:04:32 --> Output Class Initialized
INFO - 2023-03-13 08:04:32 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:32 --> Input Class Initialized
INFO - 2023-03-13 08:04:32 --> Language Class Initialized
INFO - 2023-03-13 08:04:32 --> Loader Class Initialized
INFO - 2023-03-13 08:04:32 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:32 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:32 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:34 --> Config Class Initialized
INFO - 2023-03-13 08:04:34 --> Config Class Initialized
INFO - 2023-03-13 08:04:34 --> Hooks Class Initialized
INFO - 2023-03-13 08:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:34 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:34 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:34 --> URI Class Initialized
INFO - 2023-03-13 08:04:34 --> URI Class Initialized
INFO - 2023-03-13 08:04:34 --> Router Class Initialized
INFO - 2023-03-13 08:04:34 --> Router Class Initialized
INFO - 2023-03-13 08:04:34 --> Output Class Initialized
INFO - 2023-03-13 08:04:34 --> Output Class Initialized
INFO - 2023-03-13 08:04:34 --> Security Class Initialized
INFO - 2023-03-13 08:04:34 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:34 --> Input Class Initialized
INFO - 2023-03-13 08:04:34 --> Input Class Initialized
INFO - 2023-03-13 08:04:34 --> Language Class Initialized
INFO - 2023-03-13 08:04:34 --> Language Class Initialized
INFO - 2023-03-13 08:04:34 --> Loader Class Initialized
INFO - 2023-03-13 08:04:34 --> Loader Class Initialized
INFO - 2023-03-13 08:04:34 --> Controller Class Initialized
INFO - 2023-03-13 08:04:34 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:34 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:34 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:34 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:34 --> Total execution time: 0.0333
INFO - 2023-03-13 08:04:34 --> Config Class Initialized
INFO - 2023-03-13 08:04:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:34 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:34 --> URI Class Initialized
INFO - 2023-03-13 08:04:34 --> Router Class Initialized
INFO - 2023-03-13 08:04:34 --> Output Class Initialized
INFO - 2023-03-13 08:04:34 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:34 --> Input Class Initialized
INFO - 2023-03-13 08:04:34 --> Language Class Initialized
INFO - 2023-03-13 08:04:34 --> Loader Class Initialized
INFO - 2023-03-13 08:04:34 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:34 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:35 --> Config Class Initialized
INFO - 2023-03-13 08:04:35 --> Config Class Initialized
INFO - 2023-03-13 08:04:35 --> Hooks Class Initialized
INFO - 2023-03-13 08:04:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:04:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:35 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:35 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:35 --> URI Class Initialized
INFO - 2023-03-13 08:04:35 --> URI Class Initialized
INFO - 2023-03-13 08:04:35 --> Router Class Initialized
INFO - 2023-03-13 08:04:35 --> Router Class Initialized
INFO - 2023-03-13 08:04:35 --> Output Class Initialized
INFO - 2023-03-13 08:04:35 --> Output Class Initialized
INFO - 2023-03-13 08:04:35 --> Security Class Initialized
INFO - 2023-03-13 08:04:35 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:35 --> Input Class Initialized
INFO - 2023-03-13 08:04:35 --> Input Class Initialized
INFO - 2023-03-13 08:04:35 --> Language Class Initialized
INFO - 2023-03-13 08:04:35 --> Language Class Initialized
INFO - 2023-03-13 08:04:35 --> Loader Class Initialized
INFO - 2023-03-13 08:04:35 --> Loader Class Initialized
INFO - 2023-03-13 08:04:35 --> Controller Class Initialized
INFO - 2023-03-13 08:04:35 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:04:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:35 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:35 --> Database Driver Class Initialized
INFO - 2023-03-13 08:04:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:04:35 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:35 --> Total execution time: 0.0354
INFO - 2023-03-13 08:04:36 --> Config Class Initialized
INFO - 2023-03-13 08:04:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:36 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:36 --> URI Class Initialized
INFO - 2023-03-13 08:04:36 --> Router Class Initialized
INFO - 2023-03-13 08:04:36 --> Output Class Initialized
INFO - 2023-03-13 08:04:36 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:36 --> Input Class Initialized
INFO - 2023-03-13 08:04:36 --> Language Class Initialized
INFO - 2023-03-13 08:04:36 --> Loader Class Initialized
INFO - 2023-03-13 08:04:36 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:36 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:36 --> Total execution time: 0.0612
INFO - 2023-03-13 08:04:36 --> Config Class Initialized
INFO - 2023-03-13 08:04:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:04:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:04:36 --> Utf8 Class Initialized
INFO - 2023-03-13 08:04:36 --> URI Class Initialized
INFO - 2023-03-13 08:04:36 --> Router Class Initialized
INFO - 2023-03-13 08:04:36 --> Output Class Initialized
INFO - 2023-03-13 08:04:36 --> Security Class Initialized
DEBUG - 2023-03-13 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:04:36 --> Input Class Initialized
INFO - 2023-03-13 08:04:36 --> Language Class Initialized
INFO - 2023-03-13 08:04:36 --> Loader Class Initialized
INFO - 2023-03-13 08:04:36 --> Controller Class Initialized
DEBUG - 2023-03-13 08:04:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:04:36 --> Final output sent to browser
DEBUG - 2023-03-13 08:04:36 --> Total execution time: 0.0473
INFO - 2023-03-13 08:05:45 --> Config Class Initialized
INFO - 2023-03-13 08:05:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:45 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:45 --> URI Class Initialized
INFO - 2023-03-13 08:05:45 --> Router Class Initialized
INFO - 2023-03-13 08:05:45 --> Output Class Initialized
INFO - 2023-03-13 08:05:45 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:45 --> Input Class Initialized
INFO - 2023-03-13 08:05:45 --> Language Class Initialized
INFO - 2023-03-13 08:05:45 --> Loader Class Initialized
INFO - 2023-03-13 08:05:45 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:45 --> Database Driver Class Initialized
INFO - 2023-03-13 08:05:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:05:45 --> Database Driver Class Initialized
INFO - 2023-03-13 08:05:45 --> Model "Login_model" initialized
INFO - 2023-03-13 08:05:45 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:45 --> Total execution time: 0.1215
INFO - 2023-03-13 08:05:45 --> Config Class Initialized
INFO - 2023-03-13 08:05:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:45 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:45 --> URI Class Initialized
INFO - 2023-03-13 08:05:45 --> Router Class Initialized
INFO - 2023-03-13 08:05:45 --> Output Class Initialized
INFO - 2023-03-13 08:05:45 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:45 --> Input Class Initialized
INFO - 2023-03-13 08:05:45 --> Language Class Initialized
INFO - 2023-03-13 08:05:45 --> Loader Class Initialized
INFO - 2023-03-13 08:05:45 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:45 --> Database Driver Class Initialized
INFO - 2023-03-13 08:05:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:05:45 --> Database Driver Class Initialized
INFO - 2023-03-13 08:05:45 --> Model "Login_model" initialized
INFO - 2023-03-13 08:05:45 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:45 --> Total execution time: 0.0360
INFO - 2023-03-13 08:05:48 --> Config Class Initialized
INFO - 2023-03-13 08:05:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:48 --> URI Class Initialized
INFO - 2023-03-13 08:05:48 --> Router Class Initialized
INFO - 2023-03-13 08:05:48 --> Output Class Initialized
INFO - 2023-03-13 08:05:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:48 --> Input Class Initialized
INFO - 2023-03-13 08:05:48 --> Language Class Initialized
INFO - 2023-03-13 08:05:48 --> Loader Class Initialized
INFO - 2023-03-13 08:05:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:48 --> Total execution time: 0.0659
INFO - 2023-03-13 08:05:48 --> Config Class Initialized
INFO - 2023-03-13 08:05:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:48 --> URI Class Initialized
INFO - 2023-03-13 08:05:48 --> Router Class Initialized
INFO - 2023-03-13 08:05:48 --> Output Class Initialized
INFO - 2023-03-13 08:05:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:48 --> Input Class Initialized
INFO - 2023-03-13 08:05:48 --> Language Class Initialized
INFO - 2023-03-13 08:05:48 --> Loader Class Initialized
INFO - 2023-03-13 08:05:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:48 --> Total execution time: 0.0766
INFO - 2023-03-13 08:05:51 --> Config Class Initialized
INFO - 2023-03-13 08:05:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:51 --> URI Class Initialized
INFO - 2023-03-13 08:05:51 --> Router Class Initialized
INFO - 2023-03-13 08:05:51 --> Output Class Initialized
INFO - 2023-03-13 08:05:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:51 --> Input Class Initialized
INFO - 2023-03-13 08:05:51 --> Language Class Initialized
INFO - 2023-03-13 08:05:51 --> Loader Class Initialized
INFO - 2023-03-13 08:05:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:51 --> Total execution time: 0.0042
INFO - 2023-03-13 08:05:51 --> Config Class Initialized
INFO - 2023-03-13 08:05:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:05:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:05:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:05:51 --> URI Class Initialized
INFO - 2023-03-13 08:05:51 --> Router Class Initialized
INFO - 2023-03-13 08:05:51 --> Output Class Initialized
INFO - 2023-03-13 08:05:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:05:51 --> Input Class Initialized
INFO - 2023-03-13 08:05:51 --> Language Class Initialized
INFO - 2023-03-13 08:05:51 --> Loader Class Initialized
INFO - 2023-03-13 08:05:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:05:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:05:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:05:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:05:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:05:51 --> Total execution time: 0.0539
INFO - 2023-03-13 08:08:00 --> Config Class Initialized
INFO - 2023-03-13 08:08:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:01 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:01 --> URI Class Initialized
INFO - 2023-03-13 08:08:01 --> Router Class Initialized
INFO - 2023-03-13 08:08:01 --> Output Class Initialized
INFO - 2023-03-13 08:08:01 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:01 --> Input Class Initialized
INFO - 2023-03-13 08:08:01 --> Language Class Initialized
INFO - 2023-03-13 08:08:01 --> Loader Class Initialized
INFO - 2023-03-13 08:08:01 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:08:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:08:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:08:01 --> Model "Login_model" initialized
INFO - 2023-03-13 08:08:01 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:01 --> Total execution time: 0.2003
INFO - 2023-03-13 08:08:01 --> Config Class Initialized
INFO - 2023-03-13 08:08:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:01 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:01 --> URI Class Initialized
INFO - 2023-03-13 08:08:01 --> Router Class Initialized
INFO - 2023-03-13 08:08:01 --> Output Class Initialized
INFO - 2023-03-13 08:08:01 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:01 --> Input Class Initialized
INFO - 2023-03-13 08:08:01 --> Language Class Initialized
INFO - 2023-03-13 08:08:01 --> Loader Class Initialized
INFO - 2023-03-13 08:08:01 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:08:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:08:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:08:01 --> Model "Login_model" initialized
INFO - 2023-03-13 08:08:01 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:01 --> Total execution time: 0.0483
INFO - 2023-03-13 08:08:18 --> Config Class Initialized
INFO - 2023-03-13 08:08:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:18 --> URI Class Initialized
INFO - 2023-03-13 08:08:18 --> Router Class Initialized
INFO - 2023-03-13 08:08:18 --> Output Class Initialized
INFO - 2023-03-13 08:08:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:18 --> Input Class Initialized
INFO - 2023-03-13 08:08:18 --> Language Class Initialized
INFO - 2023-03-13 08:08:18 --> Loader Class Initialized
INFO - 2023-03-13 08:08:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:18 --> Total execution time: 0.0615
INFO - 2023-03-13 08:08:18 --> Config Class Initialized
INFO - 2023-03-13 08:08:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:18 --> URI Class Initialized
INFO - 2023-03-13 08:08:18 --> Router Class Initialized
INFO - 2023-03-13 08:08:18 --> Output Class Initialized
INFO - 2023-03-13 08:08:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:18 --> Input Class Initialized
INFO - 2023-03-13 08:08:18 --> Language Class Initialized
INFO - 2023-03-13 08:08:18 --> Loader Class Initialized
INFO - 2023-03-13 08:08:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:18 --> Total execution time: 0.0572
INFO - 2023-03-13 08:08:19 --> Config Class Initialized
INFO - 2023-03-13 08:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:19 --> URI Class Initialized
INFO - 2023-03-13 08:08:19 --> Router Class Initialized
INFO - 2023-03-13 08:08:19 --> Output Class Initialized
INFO - 2023-03-13 08:08:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:19 --> Input Class Initialized
INFO - 2023-03-13 08:08:19 --> Language Class Initialized
INFO - 2023-03-13 08:08:19 --> Loader Class Initialized
INFO - 2023-03-13 08:08:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:19 --> Total execution time: 0.0044
INFO - 2023-03-13 08:08:19 --> Config Class Initialized
INFO - 2023-03-13 08:08:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:08:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:08:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:08:19 --> URI Class Initialized
INFO - 2023-03-13 08:08:19 --> Router Class Initialized
INFO - 2023-03-13 08:08:19 --> Output Class Initialized
INFO - 2023-03-13 08:08:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:08:19 --> Input Class Initialized
INFO - 2023-03-13 08:08:19 --> Language Class Initialized
INFO - 2023-03-13 08:08:19 --> Loader Class Initialized
INFO - 2023-03-13 08:08:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:08:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:08:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:08:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:08:19 --> Total execution time: 0.0115
INFO - 2023-03-13 08:09:45 --> Config Class Initialized
INFO - 2023-03-13 08:09:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:09:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:09:45 --> Utf8 Class Initialized
INFO - 2023-03-13 08:09:45 --> URI Class Initialized
INFO - 2023-03-13 08:09:45 --> Router Class Initialized
INFO - 2023-03-13 08:09:45 --> Output Class Initialized
INFO - 2023-03-13 08:09:45 --> Security Class Initialized
DEBUG - 2023-03-13 08:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:09:45 --> Input Class Initialized
INFO - 2023-03-13 08:09:45 --> Language Class Initialized
INFO - 2023-03-13 08:09:45 --> Loader Class Initialized
INFO - 2023-03-13 08:09:45 --> Controller Class Initialized
DEBUG - 2023-03-13 08:09:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:09:45 --> Final output sent to browser
DEBUG - 2023-03-13 08:09:45 --> Total execution time: 0.0946
INFO - 2023-03-13 08:09:45 --> Config Class Initialized
INFO - 2023-03-13 08:09:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:09:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:09:45 --> Utf8 Class Initialized
INFO - 2023-03-13 08:09:45 --> URI Class Initialized
INFO - 2023-03-13 08:09:45 --> Router Class Initialized
INFO - 2023-03-13 08:09:45 --> Output Class Initialized
INFO - 2023-03-13 08:09:45 --> Security Class Initialized
DEBUG - 2023-03-13 08:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:09:45 --> Input Class Initialized
INFO - 2023-03-13 08:09:45 --> Language Class Initialized
INFO - 2023-03-13 08:09:45 --> Loader Class Initialized
INFO - 2023-03-13 08:09:45 --> Controller Class Initialized
DEBUG - 2023-03-13 08:09:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:09:45 --> Final output sent to browser
DEBUG - 2023-03-13 08:09:45 --> Total execution time: 0.0511
INFO - 2023-03-13 08:09:53 --> Config Class Initialized
INFO - 2023-03-13 08:09:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:09:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:09:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:09:53 --> URI Class Initialized
INFO - 2023-03-13 08:09:53 --> Router Class Initialized
INFO - 2023-03-13 08:09:53 --> Output Class Initialized
INFO - 2023-03-13 08:09:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:09:53 --> Input Class Initialized
INFO - 2023-03-13 08:09:53 --> Language Class Initialized
INFO - 2023-03-13 08:09:53 --> Loader Class Initialized
INFO - 2023-03-13 08:09:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:09:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:09:53 --> Total execution time: 0.0042
INFO - 2023-03-13 08:09:53 --> Config Class Initialized
INFO - 2023-03-13 08:09:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:09:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:09:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:09:53 --> URI Class Initialized
INFO - 2023-03-13 08:09:53 --> Router Class Initialized
INFO - 2023-03-13 08:09:53 --> Output Class Initialized
INFO - 2023-03-13 08:09:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:09:53 --> Input Class Initialized
INFO - 2023-03-13 08:09:53 --> Language Class Initialized
INFO - 2023-03-13 08:09:53 --> Loader Class Initialized
INFO - 2023-03-13 08:09:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:09:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:09:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:09:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:09:53 --> Total execution time: 0.0161
INFO - 2023-03-13 08:10:34 --> Config Class Initialized
INFO - 2023-03-13 08:10:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:10:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:10:34 --> Utf8 Class Initialized
INFO - 2023-03-13 08:10:34 --> URI Class Initialized
INFO - 2023-03-13 08:10:34 --> Router Class Initialized
INFO - 2023-03-13 08:10:34 --> Output Class Initialized
INFO - 2023-03-13 08:10:34 --> Security Class Initialized
DEBUG - 2023-03-13 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:10:34 --> Input Class Initialized
INFO - 2023-03-13 08:10:34 --> Language Class Initialized
INFO - 2023-03-13 08:10:34 --> Loader Class Initialized
INFO - 2023-03-13 08:10:34 --> Controller Class Initialized
DEBUG - 2023-03-13 08:10:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:10:34 --> Final output sent to browser
DEBUG - 2023-03-13 08:10:34 --> Total execution time: 0.0902
INFO - 2023-03-13 08:10:34 --> Config Class Initialized
INFO - 2023-03-13 08:10:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:10:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:10:34 --> Utf8 Class Initialized
INFO - 2023-03-13 08:10:34 --> URI Class Initialized
INFO - 2023-03-13 08:10:34 --> Router Class Initialized
INFO - 2023-03-13 08:10:34 --> Output Class Initialized
INFO - 2023-03-13 08:10:34 --> Security Class Initialized
DEBUG - 2023-03-13 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:10:34 --> Input Class Initialized
INFO - 2023-03-13 08:10:34 --> Language Class Initialized
INFO - 2023-03-13 08:10:34 --> Loader Class Initialized
INFO - 2023-03-13 08:10:34 --> Controller Class Initialized
DEBUG - 2023-03-13 08:10:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:10:34 --> Final output sent to browser
DEBUG - 2023-03-13 08:10:34 --> Total execution time: 0.0613
INFO - 2023-03-13 08:10:35 --> Config Class Initialized
INFO - 2023-03-13 08:10:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:10:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:10:35 --> Utf8 Class Initialized
INFO - 2023-03-13 08:10:35 --> URI Class Initialized
INFO - 2023-03-13 08:10:35 --> Router Class Initialized
INFO - 2023-03-13 08:10:35 --> Output Class Initialized
INFO - 2023-03-13 08:10:35 --> Security Class Initialized
DEBUG - 2023-03-13 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:10:35 --> Input Class Initialized
INFO - 2023-03-13 08:10:35 --> Language Class Initialized
INFO - 2023-03-13 08:10:35 --> Loader Class Initialized
INFO - 2023-03-13 08:10:35 --> Controller Class Initialized
DEBUG - 2023-03-13 08:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:10:35 --> Final output sent to browser
DEBUG - 2023-03-13 08:10:35 --> Total execution time: 0.0084
INFO - 2023-03-13 08:10:35 --> Config Class Initialized
INFO - 2023-03-13 08:10:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:10:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:10:35 --> Utf8 Class Initialized
INFO - 2023-03-13 08:10:35 --> URI Class Initialized
INFO - 2023-03-13 08:10:35 --> Router Class Initialized
INFO - 2023-03-13 08:10:35 --> Output Class Initialized
INFO - 2023-03-13 08:10:35 --> Security Class Initialized
DEBUG - 2023-03-13 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:10:35 --> Input Class Initialized
INFO - 2023-03-13 08:10:35 --> Language Class Initialized
INFO - 2023-03-13 08:10:35 --> Loader Class Initialized
INFO - 2023-03-13 08:10:35 --> Controller Class Initialized
DEBUG - 2023-03-13 08:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:10:35 --> Database Driver Class Initialized
INFO - 2023-03-13 08:10:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:10:35 --> Final output sent to browser
DEBUG - 2023-03-13 08:10:35 --> Total execution time: 0.0114
INFO - 2023-03-13 08:11:42 --> Config Class Initialized
INFO - 2023-03-13 08:11:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:11:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:11:42 --> Utf8 Class Initialized
INFO - 2023-03-13 08:11:42 --> URI Class Initialized
INFO - 2023-03-13 08:11:42 --> Router Class Initialized
INFO - 2023-03-13 08:11:42 --> Output Class Initialized
INFO - 2023-03-13 08:11:42 --> Security Class Initialized
DEBUG - 2023-03-13 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:11:42 --> Input Class Initialized
INFO - 2023-03-13 08:11:42 --> Language Class Initialized
INFO - 2023-03-13 08:11:42 --> Loader Class Initialized
INFO - 2023-03-13 08:11:42 --> Controller Class Initialized
DEBUG - 2023-03-13 08:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:11:42 --> Final output sent to browser
DEBUG - 2023-03-13 08:11:42 --> Total execution time: 0.1086
INFO - 2023-03-13 08:11:42 --> Config Class Initialized
INFO - 2023-03-13 08:11:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:11:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:11:42 --> Utf8 Class Initialized
INFO - 2023-03-13 08:11:42 --> URI Class Initialized
INFO - 2023-03-13 08:11:42 --> Router Class Initialized
INFO - 2023-03-13 08:11:42 --> Output Class Initialized
INFO - 2023-03-13 08:11:42 --> Security Class Initialized
DEBUG - 2023-03-13 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:11:42 --> Input Class Initialized
INFO - 2023-03-13 08:11:42 --> Language Class Initialized
INFO - 2023-03-13 08:11:42 --> Loader Class Initialized
INFO - 2023-03-13 08:11:42 --> Controller Class Initialized
DEBUG - 2023-03-13 08:11:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:11:42 --> Final output sent to browser
DEBUG - 2023-03-13 08:11:42 --> Total execution time: 0.0582
INFO - 2023-03-13 08:11:52 --> Config Class Initialized
INFO - 2023-03-13 08:11:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:11:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:11:52 --> Utf8 Class Initialized
INFO - 2023-03-13 08:11:52 --> URI Class Initialized
INFO - 2023-03-13 08:11:52 --> Router Class Initialized
INFO - 2023-03-13 08:11:52 --> Output Class Initialized
INFO - 2023-03-13 08:11:52 --> Security Class Initialized
DEBUG - 2023-03-13 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:11:52 --> Input Class Initialized
INFO - 2023-03-13 08:11:52 --> Language Class Initialized
INFO - 2023-03-13 08:11:52 --> Loader Class Initialized
INFO - 2023-03-13 08:11:52 --> Controller Class Initialized
DEBUG - 2023-03-13 08:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:11:52 --> Final output sent to browser
DEBUG - 2023-03-13 08:11:52 --> Total execution time: 0.1405
INFO - 2023-03-13 08:11:52 --> Config Class Initialized
INFO - 2023-03-13 08:11:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:11:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:11:52 --> Utf8 Class Initialized
INFO - 2023-03-13 08:11:52 --> URI Class Initialized
INFO - 2023-03-13 08:11:52 --> Router Class Initialized
INFO - 2023-03-13 08:11:52 --> Output Class Initialized
INFO - 2023-03-13 08:11:52 --> Security Class Initialized
DEBUG - 2023-03-13 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:11:52 --> Input Class Initialized
INFO - 2023-03-13 08:11:52 --> Language Class Initialized
INFO - 2023-03-13 08:11:52 --> Loader Class Initialized
INFO - 2023-03-13 08:11:52 --> Controller Class Initialized
DEBUG - 2023-03-13 08:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:11:52 --> Final output sent to browser
DEBUG - 2023-03-13 08:11:52 --> Total execution time: 0.0583
INFO - 2023-03-13 08:12:31 --> Config Class Initialized
INFO - 2023-03-13 08:12:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:32 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:32 --> URI Class Initialized
INFO - 2023-03-13 08:12:32 --> Router Class Initialized
INFO - 2023-03-13 08:12:32 --> Output Class Initialized
INFO - 2023-03-13 08:12:32 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:32 --> Input Class Initialized
INFO - 2023-03-13 08:12:32 --> Language Class Initialized
INFO - 2023-03-13 08:12:32 --> Loader Class Initialized
INFO - 2023-03-13 08:12:32 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:32 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:32 --> Total execution time: 0.0796
INFO - 2023-03-13 08:12:32 --> Config Class Initialized
INFO - 2023-03-13 08:12:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:32 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:32 --> URI Class Initialized
INFO - 2023-03-13 08:12:32 --> Router Class Initialized
INFO - 2023-03-13 08:12:32 --> Output Class Initialized
INFO - 2023-03-13 08:12:32 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:32 --> Input Class Initialized
INFO - 2023-03-13 08:12:32 --> Language Class Initialized
INFO - 2023-03-13 08:12:32 --> Loader Class Initialized
INFO - 2023-03-13 08:12:32 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:32 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:32 --> Total execution time: 0.0559
INFO - 2023-03-13 08:12:53 --> Config Class Initialized
INFO - 2023-03-13 08:12:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:53 --> URI Class Initialized
INFO - 2023-03-13 08:12:53 --> Router Class Initialized
INFO - 2023-03-13 08:12:53 --> Output Class Initialized
INFO - 2023-03-13 08:12:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:53 --> Input Class Initialized
INFO - 2023-03-13 08:12:53 --> Language Class Initialized
INFO - 2023-03-13 08:12:53 --> Loader Class Initialized
INFO - 2023-03-13 08:12:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:12:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:12:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:12:53 --> Model "Login_model" initialized
INFO - 2023-03-13 08:12:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:53 --> Total execution time: 0.1281
INFO - 2023-03-13 08:12:53 --> Config Class Initialized
INFO - 2023-03-13 08:12:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:53 --> URI Class Initialized
INFO - 2023-03-13 08:12:53 --> Router Class Initialized
INFO - 2023-03-13 08:12:53 --> Output Class Initialized
INFO - 2023-03-13 08:12:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:53 --> Input Class Initialized
INFO - 2023-03-13 08:12:53 --> Language Class Initialized
INFO - 2023-03-13 08:12:53 --> Loader Class Initialized
INFO - 2023-03-13 08:12:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:12:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:12:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:12:53 --> Model "Login_model" initialized
INFO - 2023-03-13 08:12:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:53 --> Total execution time: 0.1083
INFO - 2023-03-13 08:12:56 --> Config Class Initialized
INFO - 2023-03-13 08:12:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:56 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:56 --> URI Class Initialized
INFO - 2023-03-13 08:12:56 --> Router Class Initialized
INFO - 2023-03-13 08:12:56 --> Output Class Initialized
INFO - 2023-03-13 08:12:56 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:56 --> Input Class Initialized
INFO - 2023-03-13 08:12:56 --> Language Class Initialized
INFO - 2023-03-13 08:12:56 --> Loader Class Initialized
INFO - 2023-03-13 08:12:56 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:56 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:56 --> Total execution time: 0.0602
INFO - 2023-03-13 08:12:56 --> Config Class Initialized
INFO - 2023-03-13 08:12:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:56 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:56 --> URI Class Initialized
INFO - 2023-03-13 08:12:56 --> Router Class Initialized
INFO - 2023-03-13 08:12:56 --> Output Class Initialized
INFO - 2023-03-13 08:12:56 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:56 --> Input Class Initialized
INFO - 2023-03-13 08:12:56 --> Language Class Initialized
INFO - 2023-03-13 08:12:56 --> Loader Class Initialized
INFO - 2023-03-13 08:12:56 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:56 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:56 --> Total execution time: 0.0574
INFO - 2023-03-13 08:12:59 --> Config Class Initialized
INFO - 2023-03-13 08:12:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:59 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:59 --> URI Class Initialized
INFO - 2023-03-13 08:12:59 --> Router Class Initialized
INFO - 2023-03-13 08:12:59 --> Output Class Initialized
INFO - 2023-03-13 08:12:59 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:59 --> Input Class Initialized
INFO - 2023-03-13 08:12:59 --> Language Class Initialized
INFO - 2023-03-13 08:12:59 --> Loader Class Initialized
INFO - 2023-03-13 08:12:59 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:59 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:59 --> Total execution time: 0.0048
INFO - 2023-03-13 08:12:59 --> Config Class Initialized
INFO - 2023-03-13 08:12:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:12:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:12:59 --> Utf8 Class Initialized
INFO - 2023-03-13 08:12:59 --> URI Class Initialized
INFO - 2023-03-13 08:12:59 --> Router Class Initialized
INFO - 2023-03-13 08:12:59 --> Output Class Initialized
INFO - 2023-03-13 08:12:59 --> Security Class Initialized
DEBUG - 2023-03-13 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:12:59 --> Input Class Initialized
INFO - 2023-03-13 08:12:59 --> Language Class Initialized
INFO - 2023-03-13 08:12:59 --> Loader Class Initialized
INFO - 2023-03-13 08:12:59 --> Controller Class Initialized
DEBUG - 2023-03-13 08:12:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:12:59 --> Database Driver Class Initialized
INFO - 2023-03-13 08:12:59 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:12:59 --> Final output sent to browser
DEBUG - 2023-03-13 08:12:59 --> Total execution time: 0.0114
INFO - 2023-03-13 08:13:06 --> Config Class Initialized
INFO - 2023-03-13 08:13:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:06 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:06 --> URI Class Initialized
INFO - 2023-03-13 08:13:06 --> Router Class Initialized
INFO - 2023-03-13 08:13:06 --> Output Class Initialized
INFO - 2023-03-13 08:13:06 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:06 --> Input Class Initialized
INFO - 2023-03-13 08:13:06 --> Language Class Initialized
INFO - 2023-03-13 08:13:06 --> Loader Class Initialized
INFO - 2023-03-13 08:13:06 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:06 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:06 --> Total execution time: 0.0041
INFO - 2023-03-13 08:13:06 --> Config Class Initialized
INFO - 2023-03-13 08:13:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:06 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:06 --> URI Class Initialized
INFO - 2023-03-13 08:13:06 --> Router Class Initialized
INFO - 2023-03-13 08:13:06 --> Output Class Initialized
INFO - 2023-03-13 08:13:06 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:06 --> Input Class Initialized
INFO - 2023-03-13 08:13:06 --> Language Class Initialized
INFO - 2023-03-13 08:13:06 --> Loader Class Initialized
INFO - 2023-03-13 08:13:06 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:06 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:06 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:06 --> Total execution time: 0.0148
INFO - 2023-03-13 08:13:12 --> Config Class Initialized
INFO - 2023-03-13 08:13:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:12 --> URI Class Initialized
INFO - 2023-03-13 08:13:12 --> Router Class Initialized
INFO - 2023-03-13 08:13:12 --> Output Class Initialized
INFO - 2023-03-13 08:13:12 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:12 --> Input Class Initialized
INFO - 2023-03-13 08:13:12 --> Language Class Initialized
INFO - 2023-03-13 08:13:12 --> Loader Class Initialized
INFO - 2023-03-13 08:13:12 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:12 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:12 --> Total execution time: 0.0162
INFO - 2023-03-13 08:13:12 --> Config Class Initialized
INFO - 2023-03-13 08:13:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:12 --> URI Class Initialized
INFO - 2023-03-13 08:13:12 --> Router Class Initialized
INFO - 2023-03-13 08:13:12 --> Output Class Initialized
INFO - 2023-03-13 08:13:12 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:12 --> Input Class Initialized
INFO - 2023-03-13 08:13:12 --> Language Class Initialized
INFO - 2023-03-13 08:13:12 --> Loader Class Initialized
INFO - 2023-03-13 08:13:12 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:12 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:12 --> Total execution time: 0.1345
INFO - 2023-03-13 08:13:13 --> Config Class Initialized
INFO - 2023-03-13 08:13:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:13 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:13 --> URI Class Initialized
INFO - 2023-03-13 08:13:13 --> Router Class Initialized
INFO - 2023-03-13 08:13:13 --> Output Class Initialized
INFO - 2023-03-13 08:13:13 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:13 --> Input Class Initialized
INFO - 2023-03-13 08:13:13 --> Language Class Initialized
INFO - 2023-03-13 08:13:13 --> Loader Class Initialized
INFO - 2023-03-13 08:13:13 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:13 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:13 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:13 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:13 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:13 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:13 --> Total execution time: 0.0653
INFO - 2023-03-13 08:13:13 --> Config Class Initialized
INFO - 2023-03-13 08:13:13 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:13 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:13 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:13 --> URI Class Initialized
INFO - 2023-03-13 08:13:13 --> Router Class Initialized
INFO - 2023-03-13 08:13:13 --> Output Class Initialized
INFO - 2023-03-13 08:13:13 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:13 --> Input Class Initialized
INFO - 2023-03-13 08:13:13 --> Language Class Initialized
INFO - 2023-03-13 08:13:13 --> Loader Class Initialized
INFO - 2023-03-13 08:13:13 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:13 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:13 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:13 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:13 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:13 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:13 --> Total execution time: 0.0349
INFO - 2023-03-13 08:13:14 --> Config Class Initialized
INFO - 2023-03-13 08:13:14 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:14 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:14 --> URI Class Initialized
INFO - 2023-03-13 08:13:14 --> Router Class Initialized
INFO - 2023-03-13 08:13:14 --> Output Class Initialized
INFO - 2023-03-13 08:13:14 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:14 --> Input Class Initialized
INFO - 2023-03-13 08:13:14 --> Language Class Initialized
INFO - 2023-03-13 08:13:14 --> Loader Class Initialized
INFO - 2023-03-13 08:13:14 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:14 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:14 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:14 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:14 --> Total execution time: 0.0173
INFO - 2023-03-13 08:13:15 --> Config Class Initialized
INFO - 2023-03-13 08:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:15 --> URI Class Initialized
INFO - 2023-03-13 08:13:15 --> Router Class Initialized
INFO - 2023-03-13 08:13:15 --> Output Class Initialized
INFO - 2023-03-13 08:13:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:15 --> Input Class Initialized
INFO - 2023-03-13 08:13:15 --> Language Class Initialized
INFO - 2023-03-13 08:13:15 --> Loader Class Initialized
INFO - 2023-03-13 08:13:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:15 --> Total execution time: 0.0427
INFO - 2023-03-13 08:13:15 --> Config Class Initialized
INFO - 2023-03-13 08:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:15 --> URI Class Initialized
INFO - 2023-03-13 08:13:15 --> Router Class Initialized
INFO - 2023-03-13 08:13:15 --> Output Class Initialized
INFO - 2023-03-13 08:13:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:15 --> Input Class Initialized
INFO - 2023-03-13 08:13:15 --> Language Class Initialized
INFO - 2023-03-13 08:13:15 --> Loader Class Initialized
INFO - 2023-03-13 08:13:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:15 --> Total execution time: 0.0199
INFO - 2023-03-13 08:13:15 --> Config Class Initialized
INFO - 2023-03-13 08:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:15 --> URI Class Initialized
INFO - 2023-03-13 08:13:15 --> Router Class Initialized
INFO - 2023-03-13 08:13:15 --> Output Class Initialized
INFO - 2023-03-13 08:13:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:15 --> Input Class Initialized
INFO - 2023-03-13 08:13:15 --> Language Class Initialized
INFO - 2023-03-13 08:13:15 --> Loader Class Initialized
INFO - 2023-03-13 08:13:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:15 --> Total execution time: 0.0420
INFO - 2023-03-13 08:13:15 --> Config Class Initialized
INFO - 2023-03-13 08:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:15 --> URI Class Initialized
INFO - 2023-03-13 08:13:15 --> Router Class Initialized
INFO - 2023-03-13 08:13:15 --> Output Class Initialized
INFO - 2023-03-13 08:13:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:15 --> Input Class Initialized
INFO - 2023-03-13 08:13:15 --> Language Class Initialized
INFO - 2023-03-13 08:13:15 --> Loader Class Initialized
INFO - 2023-03-13 08:13:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:15 --> Total execution time: 0.0197
INFO - 2023-03-13 08:13:15 --> Config Class Initialized
INFO - 2023-03-13 08:13:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:15 --> URI Class Initialized
INFO - 2023-03-13 08:13:15 --> Router Class Initialized
INFO - 2023-03-13 08:13:15 --> Output Class Initialized
INFO - 2023-03-13 08:13:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:15 --> Input Class Initialized
INFO - 2023-03-13 08:13:15 --> Language Class Initialized
INFO - 2023-03-13 08:13:15 --> Loader Class Initialized
INFO - 2023-03-13 08:13:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:15 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:15 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:15 --> Total execution time: 0.0360
INFO - 2023-03-13 08:13:18 --> Config Class Initialized
INFO - 2023-03-13 08:13:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:18 --> URI Class Initialized
INFO - 2023-03-13 08:13:18 --> Router Class Initialized
INFO - 2023-03-13 08:13:18 --> Output Class Initialized
INFO - 2023-03-13 08:13:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:18 --> Input Class Initialized
INFO - 2023-03-13 08:13:18 --> Language Class Initialized
INFO - 2023-03-13 08:13:18 --> Loader Class Initialized
INFO - 2023-03-13 08:13:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:18 --> Total execution time: 0.0604
INFO - 2023-03-13 08:13:18 --> Config Class Initialized
INFO - 2023-03-13 08:13:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:18 --> URI Class Initialized
INFO - 2023-03-13 08:13:18 --> Router Class Initialized
INFO - 2023-03-13 08:13:18 --> Output Class Initialized
INFO - 2023-03-13 08:13:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:18 --> Input Class Initialized
INFO - 2023-03-13 08:13:18 --> Language Class Initialized
INFO - 2023-03-13 08:13:18 --> Loader Class Initialized
INFO - 2023-03-13 08:13:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:18 --> Total execution time: 0.0502
INFO - 2023-03-13 08:13:20 --> Config Class Initialized
INFO - 2023-03-13 08:13:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:20 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:20 --> URI Class Initialized
INFO - 2023-03-13 08:13:20 --> Router Class Initialized
INFO - 2023-03-13 08:13:20 --> Output Class Initialized
INFO - 2023-03-13 08:13:20 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:20 --> Input Class Initialized
INFO - 2023-03-13 08:13:20 --> Language Class Initialized
INFO - 2023-03-13 08:13:20 --> Loader Class Initialized
INFO - 2023-03-13 08:13:20 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:20 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:20 --> Total execution time: 0.0040
INFO - 2023-03-13 08:13:20 --> Config Class Initialized
INFO - 2023-03-13 08:13:20 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:20 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:20 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:20 --> URI Class Initialized
INFO - 2023-03-13 08:13:20 --> Router Class Initialized
INFO - 2023-03-13 08:13:20 --> Output Class Initialized
INFO - 2023-03-13 08:13:20 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:20 --> Input Class Initialized
INFO - 2023-03-13 08:13:20 --> Language Class Initialized
INFO - 2023-03-13 08:13:20 --> Loader Class Initialized
INFO - 2023-03-13 08:13:20 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:20 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:20 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:20 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:20 --> Total execution time: 0.0139
INFO - 2023-03-13 08:13:38 --> Config Class Initialized
INFO - 2023-03-13 08:13:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:38 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:38 --> URI Class Initialized
INFO - 2023-03-13 08:13:38 --> Router Class Initialized
INFO - 2023-03-13 08:13:38 --> Output Class Initialized
INFO - 2023-03-13 08:13:38 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:38 --> Input Class Initialized
INFO - 2023-03-13 08:13:38 --> Language Class Initialized
INFO - 2023-03-13 08:13:38 --> Loader Class Initialized
INFO - 2023-03-13 08:13:38 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:38 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:38 --> Total execution time: 0.1177
INFO - 2023-03-13 08:13:38 --> Config Class Initialized
INFO - 2023-03-13 08:13:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:38 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:38 --> URI Class Initialized
INFO - 2023-03-13 08:13:38 --> Router Class Initialized
INFO - 2023-03-13 08:13:38 --> Output Class Initialized
INFO - 2023-03-13 08:13:38 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:38 --> Input Class Initialized
INFO - 2023-03-13 08:13:38 --> Language Class Initialized
INFO - 2023-03-13 08:13:38 --> Loader Class Initialized
INFO - 2023-03-13 08:13:38 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:38 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:38 --> Total execution time: 0.0637
INFO - 2023-03-13 08:13:47 --> Config Class Initialized
INFO - 2023-03-13 08:13:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:47 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:47 --> URI Class Initialized
INFO - 2023-03-13 08:13:47 --> Router Class Initialized
INFO - 2023-03-13 08:13:47 --> Output Class Initialized
INFO - 2023-03-13 08:13:47 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:47 --> Input Class Initialized
INFO - 2023-03-13 08:13:47 --> Language Class Initialized
INFO - 2023-03-13 08:13:47 --> Loader Class Initialized
INFO - 2023-03-13 08:13:47 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:47 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:47 --> Total execution time: 0.0037
INFO - 2023-03-13 08:13:47 --> Config Class Initialized
INFO - 2023-03-13 08:13:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:47 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:47 --> URI Class Initialized
INFO - 2023-03-13 08:13:47 --> Router Class Initialized
INFO - 2023-03-13 08:13:47 --> Output Class Initialized
INFO - 2023-03-13 08:13:47 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:47 --> Input Class Initialized
INFO - 2023-03-13 08:13:47 --> Language Class Initialized
INFO - 2023-03-13 08:13:47 --> Loader Class Initialized
INFO - 2023-03-13 08:13:47 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:47 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:47 --> Model "Login_model" initialized
INFO - 2023-03-13 08:13:47 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:47 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:47 --> Total execution time: 0.0237
INFO - 2023-03-13 08:13:48 --> Config Class Initialized
INFO - 2023-03-13 08:13:48 --> Config Class Initialized
INFO - 2023-03-13 08:13:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:48 --> URI Class Initialized
INFO - 2023-03-13 08:13:48 --> Router Class Initialized
INFO - 2023-03-13 08:13:48 --> Output Class Initialized
INFO - 2023-03-13 08:13:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:48 --> Input Class Initialized
INFO - 2023-03-13 08:13:48 --> Language Class Initialized
INFO - 2023-03-13 08:13:48 --> Loader Class Initialized
INFO - 2023-03-13 08:13:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:48 --> Total execution time: 0.0050
INFO - 2023-03-13 08:13:48 --> Config Class Initialized
INFO - 2023-03-13 08:13:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:48 --> URI Class Initialized
INFO - 2023-03-13 08:13:48 --> Router Class Initialized
INFO - 2023-03-13 08:13:48 --> Output Class Initialized
INFO - 2023-03-13 08:13:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:48 --> Input Class Initialized
INFO - 2023-03-13 08:13:48 --> Language Class Initialized
INFO - 2023-03-13 08:13:48 --> Loader Class Initialized
INFO - 2023-03-13 08:13:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:48 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:48 --> Total execution time: 0.0135
INFO - 2023-03-13 08:13:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:48 --> URI Class Initialized
INFO - 2023-03-13 08:13:48 --> Router Class Initialized
INFO - 2023-03-13 08:13:48 --> Output Class Initialized
INFO - 2023-03-13 08:13:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:48 --> Input Class Initialized
INFO - 2023-03-13 08:13:48 --> Language Class Initialized
INFO - 2023-03-13 08:13:48 --> Loader Class Initialized
INFO - 2023-03-13 08:13:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:48 --> Total execution time: 0.1372
INFO - 2023-03-13 08:13:48 --> Config Class Initialized
INFO - 2023-03-13 08:13:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:48 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:48 --> URI Class Initialized
INFO - 2023-03-13 08:13:48 --> Router Class Initialized
INFO - 2023-03-13 08:13:48 --> Output Class Initialized
INFO - 2023-03-13 08:13:48 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:48 --> Input Class Initialized
INFO - 2023-03-13 08:13:48 --> Language Class Initialized
INFO - 2023-03-13 08:13:48 --> Loader Class Initialized
INFO - 2023-03-13 08:13:48 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:48 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:48 --> Total execution time: 0.0535
INFO - 2023-03-13 08:13:49 --> Config Class Initialized
INFO - 2023-03-13 08:13:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:49 --> URI Class Initialized
INFO - 2023-03-13 08:13:49 --> Router Class Initialized
INFO - 2023-03-13 08:13:49 --> Output Class Initialized
INFO - 2023-03-13 08:13:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:49 --> Input Class Initialized
INFO - 2023-03-13 08:13:49 --> Language Class Initialized
INFO - 2023-03-13 08:13:49 --> Loader Class Initialized
INFO - 2023-03-13 08:13:49 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:49 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:49 --> Total execution time: 0.0171
INFO - 2023-03-13 08:13:50 --> Config Class Initialized
INFO - 2023-03-13 08:13:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:50 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:50 --> URI Class Initialized
INFO - 2023-03-13 08:13:50 --> Router Class Initialized
INFO - 2023-03-13 08:13:50 --> Output Class Initialized
INFO - 2023-03-13 08:13:50 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:50 --> Input Class Initialized
INFO - 2023-03-13 08:13:50 --> Language Class Initialized
INFO - 2023-03-13 08:13:50 --> Loader Class Initialized
INFO - 2023-03-13 08:13:50 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:50 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:50 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:50 --> Total execution time: 0.0192
INFO - 2023-03-13 08:13:51 --> Config Class Initialized
INFO - 2023-03-13 08:13:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:51 --> URI Class Initialized
INFO - 2023-03-13 08:13:51 --> Router Class Initialized
INFO - 2023-03-13 08:13:51 --> Output Class Initialized
INFO - 2023-03-13 08:13:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:51 --> Input Class Initialized
INFO - 2023-03-13 08:13:51 --> Language Class Initialized
INFO - 2023-03-13 08:13:51 --> Loader Class Initialized
INFO - 2023-03-13 08:13:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:51 --> Total execution time: 0.0169
INFO - 2023-03-13 08:13:52 --> Config Class Initialized
INFO - 2023-03-13 08:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:52 --> URI Class Initialized
INFO - 2023-03-13 08:13:52 --> Router Class Initialized
INFO - 2023-03-13 08:13:52 --> Output Class Initialized
INFO - 2023-03-13 08:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:52 --> Input Class Initialized
INFO - 2023-03-13 08:13:52 --> Language Class Initialized
INFO - 2023-03-13 08:13:52 --> Loader Class Initialized
INFO - 2023-03-13 08:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:52 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:52 --> Total execution time: 0.0212
INFO - 2023-03-13 08:13:52 --> Config Class Initialized
INFO - 2023-03-13 08:13:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:52 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:52 --> URI Class Initialized
INFO - 2023-03-13 08:13:52 --> Router Class Initialized
INFO - 2023-03-13 08:13:52 --> Output Class Initialized
INFO - 2023-03-13 08:13:52 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:52 --> Input Class Initialized
INFO - 2023-03-13 08:13:52 --> Language Class Initialized
INFO - 2023-03-13 08:13:52 --> Loader Class Initialized
INFO - 2023-03-13 08:13:52 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:52 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:53 --> Config Class Initialized
INFO - 2023-03-13 08:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:53 --> URI Class Initialized
INFO - 2023-03-13 08:13:53 --> Router Class Initialized
INFO - 2023-03-13 08:13:53 --> Output Class Initialized
INFO - 2023-03-13 08:13:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:53 --> Input Class Initialized
INFO - 2023-03-13 08:13:53 --> Language Class Initialized
INFO - 2023-03-13 08:13:53 --> Loader Class Initialized
INFO - 2023-03-13 08:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:53 --> Config Class Initialized
INFO - 2023-03-13 08:13:53 --> Config Class Initialized
INFO - 2023-03-13 08:13:53 --> Hooks Class Initialized
INFO - 2023-03-13 08:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:53 --> Utf8 Class Initialized
DEBUG - 2023-03-13 08:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:53 --> URI Class Initialized
INFO - 2023-03-13 08:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:53 --> Router Class Initialized
INFO - 2023-03-13 08:13:53 --> URI Class Initialized
INFO - 2023-03-13 08:13:53 --> Output Class Initialized
INFO - 2023-03-13 08:13:53 --> Router Class Initialized
INFO - 2023-03-13 08:13:53 --> Security Class Initialized
INFO - 2023-03-13 08:13:53 --> Output Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:53 --> Security Class Initialized
INFO - 2023-03-13 08:13:53 --> Input Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:53 --> Language Class Initialized
INFO - 2023-03-13 08:13:53 --> Input Class Initialized
INFO - 2023-03-13 08:13:53 --> Language Class Initialized
INFO - 2023-03-13 08:13:53 --> Loader Class Initialized
INFO - 2023-03-13 08:13:53 --> Loader Class Initialized
INFO - 2023-03-13 08:13:53 --> Controller Class Initialized
INFO - 2023-03-13 08:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:53 --> Total execution time: 0.0160
INFO - 2023-03-13 08:13:53 --> Config Class Initialized
INFO - 2023-03-13 08:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:53 --> URI Class Initialized
INFO - 2023-03-13 08:13:53 --> Router Class Initialized
INFO - 2023-03-13 08:13:53 --> Output Class Initialized
INFO - 2023-03-13 08:13:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:53 --> Input Class Initialized
INFO - 2023-03-13 08:13:53 --> Language Class Initialized
INFO - 2023-03-13 08:13:53 --> Loader Class Initialized
INFO - 2023-03-13 08:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:53 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:53 --> Total execution time: 0.0111
INFO - 2023-03-13 08:13:53 --> Config Class Initialized
INFO - 2023-03-13 08:13:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:53 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:53 --> URI Class Initialized
INFO - 2023-03-13 08:13:53 --> Router Class Initialized
INFO - 2023-03-13 08:13:53 --> Output Class Initialized
INFO - 2023-03-13 08:13:53 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:53 --> Input Class Initialized
INFO - 2023-03-13 08:13:53 --> Language Class Initialized
INFO - 2023-03-13 08:13:53 --> Loader Class Initialized
INFO - 2023-03-13 08:13:53 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:53 --> Database Driver Class Initialized
INFO - 2023-03-13 08:13:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:13:54 --> Config Class Initialized
INFO - 2023-03-13 08:13:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:54 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:54 --> URI Class Initialized
INFO - 2023-03-13 08:13:54 --> Router Class Initialized
INFO - 2023-03-13 08:13:54 --> Output Class Initialized
INFO - 2023-03-13 08:13:54 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:54 --> Input Class Initialized
INFO - 2023-03-13 08:13:54 --> Language Class Initialized
INFO - 2023-03-13 08:13:54 --> Loader Class Initialized
INFO - 2023-03-13 08:13:54 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:54 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:54 --> Total execution time: 0.0565
INFO - 2023-03-13 08:13:54 --> Config Class Initialized
INFO - 2023-03-13 08:13:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:13:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:13:54 --> Utf8 Class Initialized
INFO - 2023-03-13 08:13:54 --> URI Class Initialized
INFO - 2023-03-13 08:13:54 --> Router Class Initialized
INFO - 2023-03-13 08:13:54 --> Output Class Initialized
INFO - 2023-03-13 08:13:54 --> Security Class Initialized
DEBUG - 2023-03-13 08:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:13:54 --> Input Class Initialized
INFO - 2023-03-13 08:13:54 --> Language Class Initialized
INFO - 2023-03-13 08:13:54 --> Loader Class Initialized
INFO - 2023-03-13 08:13:54 --> Controller Class Initialized
DEBUG - 2023-03-13 08:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:13:54 --> Final output sent to browser
DEBUG - 2023-03-13 08:13:54 --> Total execution time: 0.0534
INFO - 2023-03-13 08:14:01 --> Config Class Initialized
INFO - 2023-03-13 08:14:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:14:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:14:01 --> Utf8 Class Initialized
INFO - 2023-03-13 08:14:01 --> URI Class Initialized
INFO - 2023-03-13 08:14:01 --> Router Class Initialized
INFO - 2023-03-13 08:14:01 --> Output Class Initialized
INFO - 2023-03-13 08:14:01 --> Security Class Initialized
DEBUG - 2023-03-13 08:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:14:01 --> Input Class Initialized
INFO - 2023-03-13 08:14:01 --> Language Class Initialized
INFO - 2023-03-13 08:14:01 --> Loader Class Initialized
INFO - 2023-03-13 08:14:01 --> Controller Class Initialized
DEBUG - 2023-03-13 08:14:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:14:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:14:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:14:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:14:01 --> Model "Login_model" initialized
INFO - 2023-03-13 08:14:01 --> Final output sent to browser
DEBUG - 2023-03-13 08:14:01 --> Total execution time: 0.1556
INFO - 2023-03-13 08:14:01 --> Config Class Initialized
INFO - 2023-03-13 08:14:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:14:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:14:01 --> Utf8 Class Initialized
INFO - 2023-03-13 08:14:01 --> URI Class Initialized
INFO - 2023-03-13 08:14:01 --> Router Class Initialized
INFO - 2023-03-13 08:14:01 --> Output Class Initialized
INFO - 2023-03-13 08:14:01 --> Security Class Initialized
DEBUG - 2023-03-13 08:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:14:01 --> Input Class Initialized
INFO - 2023-03-13 08:14:01 --> Language Class Initialized
INFO - 2023-03-13 08:14:01 --> Loader Class Initialized
INFO - 2023-03-13 08:14:01 --> Controller Class Initialized
DEBUG - 2023-03-13 08:14:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:14:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:14:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:14:01 --> Database Driver Class Initialized
INFO - 2023-03-13 08:14:01 --> Model "Login_model" initialized
INFO - 2023-03-13 08:14:01 --> Final output sent to browser
DEBUG - 2023-03-13 08:14:01 --> Total execution time: 0.0439
INFO - 2023-03-13 08:14:58 --> Config Class Initialized
INFO - 2023-03-13 08:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:14:58 --> Utf8 Class Initialized
INFO - 2023-03-13 08:14:58 --> URI Class Initialized
INFO - 2023-03-13 08:14:58 --> Router Class Initialized
INFO - 2023-03-13 08:14:58 --> Output Class Initialized
INFO - 2023-03-13 08:14:58 --> Security Class Initialized
DEBUG - 2023-03-13 08:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:14:58 --> Input Class Initialized
INFO - 2023-03-13 08:14:58 --> Language Class Initialized
INFO - 2023-03-13 08:14:58 --> Loader Class Initialized
INFO - 2023-03-13 08:14:58 --> Controller Class Initialized
DEBUG - 2023-03-13 08:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:14:58 --> Final output sent to browser
DEBUG - 2023-03-13 08:14:58 --> Total execution time: 0.0744
INFO - 2023-03-13 08:14:58 --> Config Class Initialized
INFO - 2023-03-13 08:14:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:14:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:14:58 --> Utf8 Class Initialized
INFO - 2023-03-13 08:14:58 --> URI Class Initialized
INFO - 2023-03-13 08:14:58 --> Router Class Initialized
INFO - 2023-03-13 08:14:58 --> Output Class Initialized
INFO - 2023-03-13 08:14:58 --> Security Class Initialized
DEBUG - 2023-03-13 08:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:14:58 --> Input Class Initialized
INFO - 2023-03-13 08:14:58 --> Language Class Initialized
INFO - 2023-03-13 08:14:58 --> Loader Class Initialized
INFO - 2023-03-13 08:14:58 --> Controller Class Initialized
DEBUG - 2023-03-13 08:14:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:14:58 --> Final output sent to browser
DEBUG - 2023-03-13 08:14:58 --> Total execution time: 0.0591
INFO - 2023-03-13 08:15:03 --> Config Class Initialized
INFO - 2023-03-13 08:15:03 --> Config Class Initialized
INFO - 2023-03-13 08:15:03 --> Hooks Class Initialized
INFO - 2023-03-13 08:15:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:03 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:15:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:03 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:03 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:03 --> URI Class Initialized
INFO - 2023-03-13 08:15:03 --> URI Class Initialized
INFO - 2023-03-13 08:15:03 --> Router Class Initialized
INFO - 2023-03-13 08:15:03 --> Router Class Initialized
INFO - 2023-03-13 08:15:03 --> Output Class Initialized
INFO - 2023-03-13 08:15:03 --> Output Class Initialized
INFO - 2023-03-13 08:15:03 --> Security Class Initialized
INFO - 2023-03-13 08:15:03 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:03 --> Input Class Initialized
INFO - 2023-03-13 08:15:03 --> Input Class Initialized
INFO - 2023-03-13 08:15:03 --> Language Class Initialized
INFO - 2023-03-13 08:15:03 --> Language Class Initialized
INFO - 2023-03-13 08:15:03 --> Loader Class Initialized
INFO - 2023-03-13 08:15:03 --> Loader Class Initialized
INFO - 2023-03-13 08:15:03 --> Controller Class Initialized
INFO - 2023-03-13 08:15:03 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:03 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:03 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:03 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:03 --> Total execution time: 0.0198
INFO - 2023-03-13 08:15:03 --> Config Class Initialized
INFO - 2023-03-13 08:15:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:03 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:03 --> URI Class Initialized
INFO - 2023-03-13 08:15:03 --> Router Class Initialized
INFO - 2023-03-13 08:15:03 --> Output Class Initialized
INFO - 2023-03-13 08:15:03 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:03 --> Input Class Initialized
INFO - 2023-03-13 08:15:03 --> Language Class Initialized
INFO - 2023-03-13 08:15:03 --> Loader Class Initialized
INFO - 2023-03-13 08:15:03 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:03 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:03 --> Config Class Initialized
INFO - 2023-03-13 08:15:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:03 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:03 --> URI Class Initialized
INFO - 2023-03-13 08:15:03 --> Router Class Initialized
INFO - 2023-03-13 08:15:03 --> Output Class Initialized
INFO - 2023-03-13 08:15:03 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:03 --> Input Class Initialized
INFO - 2023-03-13 08:15:03 --> Language Class Initialized
INFO - 2023-03-13 08:15:03 --> Final output sent to browser
INFO - 2023-03-13 08:15:03 --> Loader Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Total execution time: 0.2109
INFO - 2023-03-13 08:15:03 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:03 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:04 --> Config Class Initialized
INFO - 2023-03-13 08:15:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:04 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:04 --> URI Class Initialized
INFO - 2023-03-13 08:15:04 --> Router Class Initialized
INFO - 2023-03-13 08:15:04 --> Output Class Initialized
INFO - 2023-03-13 08:15:04 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:04 --> Input Class Initialized
INFO - 2023-03-13 08:15:04 --> Language Class Initialized
INFO - 2023-03-13 08:15:04 --> Loader Class Initialized
INFO - 2023-03-13 08:15:04 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:04 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:04 --> Total execution time: 0.0600
INFO - 2023-03-13 08:15:04 --> Config Class Initialized
INFO - 2023-03-13 08:15:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:04 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:04 --> URI Class Initialized
INFO - 2023-03-13 08:15:04 --> Router Class Initialized
INFO - 2023-03-13 08:15:04 --> Output Class Initialized
INFO - 2023-03-13 08:15:04 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:04 --> Input Class Initialized
INFO - 2023-03-13 08:15:04 --> Language Class Initialized
INFO - 2023-03-13 08:15:04 --> Loader Class Initialized
INFO - 2023-03-13 08:15:04 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:04 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:04 --> Total execution time: 0.0606
INFO - 2023-03-13 08:15:06 --> Config Class Initialized
INFO - 2023-03-13 08:15:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:06 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:06 --> URI Class Initialized
INFO - 2023-03-13 08:15:06 --> Router Class Initialized
INFO - 2023-03-13 08:15:06 --> Output Class Initialized
INFO - 2023-03-13 08:15:06 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:06 --> Input Class Initialized
INFO - 2023-03-13 08:15:06 --> Language Class Initialized
INFO - 2023-03-13 08:15:06 --> Loader Class Initialized
INFO - 2023-03-13 08:15:06 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:06 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:06 --> Total execution time: 0.0050
INFO - 2023-03-13 08:15:06 --> Config Class Initialized
INFO - 2023-03-13 08:15:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:06 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:06 --> URI Class Initialized
INFO - 2023-03-13 08:15:06 --> Router Class Initialized
INFO - 2023-03-13 08:15:06 --> Output Class Initialized
INFO - 2023-03-13 08:15:06 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:06 --> Input Class Initialized
INFO - 2023-03-13 08:15:06 --> Language Class Initialized
INFO - 2023-03-13 08:15:06 --> Loader Class Initialized
INFO - 2023-03-13 08:15:06 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:06 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:06 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:06 --> Total execution time: 0.0547
INFO - 2023-03-13 08:15:25 --> Config Class Initialized
INFO - 2023-03-13 08:15:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:25 --> URI Class Initialized
INFO - 2023-03-13 08:15:25 --> Router Class Initialized
INFO - 2023-03-13 08:15:25 --> Output Class Initialized
INFO - 2023-03-13 08:15:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:25 --> Input Class Initialized
INFO - 2023-03-13 08:15:25 --> Language Class Initialized
INFO - 2023-03-13 08:15:25 --> Loader Class Initialized
INFO - 2023-03-13 08:15:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:25 --> Model "Login_model" initialized
INFO - 2023-03-13 08:15:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:25 --> Total execution time: 0.2226
INFO - 2023-03-13 08:15:25 --> Config Class Initialized
INFO - 2023-03-13 08:15:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:15:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:15:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:15:25 --> URI Class Initialized
INFO - 2023-03-13 08:15:25 --> Router Class Initialized
INFO - 2023-03-13 08:15:25 --> Output Class Initialized
INFO - 2023-03-13 08:15:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:15:25 --> Input Class Initialized
INFO - 2023-03-13 08:15:25 --> Language Class Initialized
INFO - 2023-03-13 08:15:25 --> Loader Class Initialized
INFO - 2023-03-13 08:15:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:15:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:15:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:15:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:15:25 --> Model "Login_model" initialized
INFO - 2023-03-13 08:15:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:15:25 --> Total execution time: 0.0427
INFO - 2023-03-13 08:17:26 --> Config Class Initialized
INFO - 2023-03-13 08:17:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:26 --> URI Class Initialized
INFO - 2023-03-13 08:17:26 --> Router Class Initialized
INFO - 2023-03-13 08:17:26 --> Output Class Initialized
INFO - 2023-03-13 08:17:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:26 --> Input Class Initialized
INFO - 2023-03-13 08:17:26 --> Language Class Initialized
INFO - 2023-03-13 08:17:26 --> Loader Class Initialized
INFO - 2023-03-13 08:17:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:26 --> Total execution time: 0.0194
INFO - 2023-03-13 08:17:26 --> Config Class Initialized
INFO - 2023-03-13 08:17:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:26 --> URI Class Initialized
INFO - 2023-03-13 08:17:26 --> Router Class Initialized
INFO - 2023-03-13 08:17:26 --> Output Class Initialized
INFO - 2023-03-13 08:17:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:26 --> Input Class Initialized
INFO - 2023-03-13 08:17:26 --> Language Class Initialized
INFO - 2023-03-13 08:17:26 --> Loader Class Initialized
INFO - 2023-03-13 08:17:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:26 --> Total execution time: 0.0551
INFO - 2023-03-13 08:17:28 --> Config Class Initialized
INFO - 2023-03-13 08:17:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:28 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:28 --> URI Class Initialized
INFO - 2023-03-13 08:17:28 --> Router Class Initialized
INFO - 2023-03-13 08:17:28 --> Output Class Initialized
INFO - 2023-03-13 08:17:28 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:28 --> Input Class Initialized
INFO - 2023-03-13 08:17:28 --> Language Class Initialized
INFO - 2023-03-13 08:17:28 --> Loader Class Initialized
INFO - 2023-03-13 08:17:28 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:28 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:28 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:28 --> Total execution time: 0.0491
INFO - 2023-03-13 08:17:28 --> Config Class Initialized
INFO - 2023-03-13 08:17:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:28 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:28 --> URI Class Initialized
INFO - 2023-03-13 08:17:28 --> Router Class Initialized
INFO - 2023-03-13 08:17:28 --> Output Class Initialized
INFO - 2023-03-13 08:17:28 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:28 --> Input Class Initialized
INFO - 2023-03-13 08:17:28 --> Language Class Initialized
INFO - 2023-03-13 08:17:28 --> Loader Class Initialized
INFO - 2023-03-13 08:17:28 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:28 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:28 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:28 --> Total execution time: 0.0918
INFO - 2023-03-13 08:17:41 --> Config Class Initialized
INFO - 2023-03-13 08:17:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:41 --> URI Class Initialized
INFO - 2023-03-13 08:17:41 --> Router Class Initialized
INFO - 2023-03-13 08:17:41 --> Output Class Initialized
INFO - 2023-03-13 08:17:41 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:41 --> Input Class Initialized
INFO - 2023-03-13 08:17:41 --> Language Class Initialized
INFO - 2023-03-13 08:17:41 --> Loader Class Initialized
INFO - 2023-03-13 08:17:41 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:41 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:41 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:41 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:41 --> Total execution time: 0.1322
INFO - 2023-03-13 08:17:41 --> Config Class Initialized
INFO - 2023-03-13 08:17:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:17:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:17:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:17:41 --> URI Class Initialized
INFO - 2023-03-13 08:17:41 --> Router Class Initialized
INFO - 2023-03-13 08:17:41 --> Output Class Initialized
INFO - 2023-03-13 08:17:41 --> Security Class Initialized
DEBUG - 2023-03-13 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:17:41 --> Input Class Initialized
INFO - 2023-03-13 08:17:41 --> Language Class Initialized
INFO - 2023-03-13 08:17:41 --> Loader Class Initialized
INFO - 2023-03-13 08:17:41 --> Controller Class Initialized
DEBUG - 2023-03-13 08:17:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:17:41 --> Database Driver Class Initialized
INFO - 2023-03-13 08:17:41 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:17:41 --> Final output sent to browser
DEBUG - 2023-03-13 08:17:41 --> Total execution time: 0.0510
INFO - 2023-03-13 08:19:17 --> Config Class Initialized
INFO - 2023-03-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:17 --> URI Class Initialized
INFO - 2023-03-13 08:19:17 --> Router Class Initialized
INFO - 2023-03-13 08:19:17 --> Output Class Initialized
INFO - 2023-03-13 08:19:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:17 --> Input Class Initialized
INFO - 2023-03-13 08:19:17 --> Language Class Initialized
INFO - 2023-03-13 08:19:17 --> Loader Class Initialized
INFO - 2023-03-13 08:19:17 --> Controller Class Initialized
INFO - 2023-03-13 08:19:17 --> Helper loaded: form_helper
INFO - 2023-03-13 08:19:17 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:17 --> Model "Change_model" initialized
INFO - 2023-03-13 08:19:17 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:19:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:17 --> Total execution time: 0.0313
INFO - 2023-03-13 08:19:17 --> Config Class Initialized
INFO - 2023-03-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:17 --> URI Class Initialized
INFO - 2023-03-13 08:19:17 --> Router Class Initialized
INFO - 2023-03-13 08:19:17 --> Output Class Initialized
INFO - 2023-03-13 08:19:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:17 --> Input Class Initialized
INFO - 2023-03-13 08:19:17 --> Language Class Initialized
INFO - 2023-03-13 08:19:17 --> Loader Class Initialized
INFO - 2023-03-13 08:19:17 --> Controller Class Initialized
INFO - 2023-03-13 08:19:17 --> Helper loaded: form_helper
INFO - 2023-03-13 08:19:17 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:17 --> Total execution time: 0.0461
INFO - 2023-03-13 08:19:17 --> Config Class Initialized
INFO - 2023-03-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:17 --> URI Class Initialized
INFO - 2023-03-13 08:19:17 --> Router Class Initialized
INFO - 2023-03-13 08:19:17 --> Output Class Initialized
INFO - 2023-03-13 08:19:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:17 --> Input Class Initialized
INFO - 2023-03-13 08:19:17 --> Language Class Initialized
INFO - 2023-03-13 08:19:17 --> Loader Class Initialized
INFO - 2023-03-13 08:19:17 --> Controller Class Initialized
INFO - 2023-03-13 08:19:17 --> Helper loaded: form_helper
INFO - 2023-03-13 08:19:17 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:17 --> Model "Login_model" initialized
INFO - 2023-03-13 08:19:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:17 --> Total execution time: 0.0581
INFO - 2023-03-13 08:19:17 --> Config Class Initialized
INFO - 2023-03-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:17 --> URI Class Initialized
INFO - 2023-03-13 08:19:17 --> Router Class Initialized
INFO - 2023-03-13 08:19:17 --> Output Class Initialized
INFO - 2023-03-13 08:19:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:17 --> Input Class Initialized
INFO - 2023-03-13 08:19:17 --> Language Class Initialized
INFO - 2023-03-13 08:19:17 --> Loader Class Initialized
INFO - 2023-03-13 08:19:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:17 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:19:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:17 --> Total execution time: 0.0132
INFO - 2023-03-13 08:19:17 --> Config Class Initialized
INFO - 2023-03-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:17 --> URI Class Initialized
INFO - 2023-03-13 08:19:17 --> Router Class Initialized
INFO - 2023-03-13 08:19:17 --> Output Class Initialized
INFO - 2023-03-13 08:19:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:17 --> Input Class Initialized
INFO - 2023-03-13 08:19:17 --> Language Class Initialized
INFO - 2023-03-13 08:19:17 --> Loader Class Initialized
INFO - 2023-03-13 08:19:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:17 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:19:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:17 --> Total execution time: 0.0191
INFO - 2023-03-13 08:19:18 --> Config Class Initialized
INFO - 2023-03-13 08:19:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:18 --> URI Class Initialized
INFO - 2023-03-13 08:19:18 --> Router Class Initialized
INFO - 2023-03-13 08:19:18 --> Output Class Initialized
INFO - 2023-03-13 08:19:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:18 --> Input Class Initialized
INFO - 2023-03-13 08:19:18 --> Language Class Initialized
INFO - 2023-03-13 08:19:18 --> Loader Class Initialized
INFO - 2023-03-13 08:19:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:19:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:18 --> Model "Login_model" initialized
INFO - 2023-03-13 08:19:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:18 --> Total execution time: 0.0546
INFO - 2023-03-13 08:19:18 --> Config Class Initialized
INFO - 2023-03-13 08:19:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:19:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:19:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:19:18 --> URI Class Initialized
INFO - 2023-03-13 08:19:18 --> Router Class Initialized
INFO - 2023-03-13 08:19:18 --> Output Class Initialized
INFO - 2023-03-13 08:19:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:19:18 --> Input Class Initialized
INFO - 2023-03-13 08:19:18 --> Language Class Initialized
INFO - 2023-03-13 08:19:18 --> Loader Class Initialized
INFO - 2023-03-13 08:19:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:19:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:19:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:19:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:19:18 --> Model "Login_model" initialized
INFO - 2023-03-13 08:19:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:19:18 --> Total execution time: 0.0357
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
INFO - 2023-03-13 08:21:51 --> Helper loaded: form_helper
INFO - 2023-03-13 08:21:51 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Model "Change_model" initialized
INFO - 2023-03-13 08:21:51 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0287
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
INFO - 2023-03-13 08:21:51 --> Helper loaded: form_helper
INFO - 2023-03-13 08:21:51 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0424
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
INFO - 2023-03-13 08:21:51 --> Helper loaded: form_helper
INFO - 2023-03-13 08:21:51 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Login_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0146
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0134
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0146
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Login_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0375
INFO - 2023-03-13 08:21:51 --> Config Class Initialized
INFO - 2023-03-13 08:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:21:51 --> Utf8 Class Initialized
INFO - 2023-03-13 08:21:51 --> URI Class Initialized
INFO - 2023-03-13 08:21:51 --> Router Class Initialized
INFO - 2023-03-13 08:21:51 --> Output Class Initialized
INFO - 2023-03-13 08:21:51 --> Security Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:21:51 --> Input Class Initialized
INFO - 2023-03-13 08:21:51 --> Language Class Initialized
INFO - 2023-03-13 08:21:51 --> Loader Class Initialized
INFO - 2023-03-13 08:21:51 --> Controller Class Initialized
DEBUG - 2023-03-13 08:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:21:51 --> Database Driver Class Initialized
INFO - 2023-03-13 08:21:51 --> Model "Login_model" initialized
INFO - 2023-03-13 08:21:51 --> Final output sent to browser
DEBUG - 2023-03-13 08:21:51 --> Total execution time: 0.0381
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
INFO - 2023-03-13 08:22:21 --> Helper loaded: form_helper
INFO - 2023-03-13 08:22:21 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Model "Change_model" initialized
INFO - 2023-03-13 08:22:21 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0445
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
INFO - 2023-03-13 08:22:21 --> Helper loaded: form_helper
INFO - 2023-03-13 08:22:21 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0023
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
INFO - 2023-03-13 08:22:21 --> Helper loaded: form_helper
INFO - 2023-03-13 08:22:21 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Login_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0193
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0131
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0149
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Login_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0840
INFO - 2023-03-13 08:22:21 --> Config Class Initialized
INFO - 2023-03-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:22:21 --> Utf8 Class Initialized
INFO - 2023-03-13 08:22:21 --> URI Class Initialized
INFO - 2023-03-13 08:22:21 --> Router Class Initialized
INFO - 2023-03-13 08:22:21 --> Output Class Initialized
INFO - 2023-03-13 08:22:21 --> Security Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:22:21 --> Input Class Initialized
INFO - 2023-03-13 08:22:21 --> Language Class Initialized
INFO - 2023-03-13 08:22:21 --> Loader Class Initialized
INFO - 2023-03-13 08:22:21 --> Controller Class Initialized
DEBUG - 2023-03-13 08:22:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:22:21 --> Database Driver Class Initialized
INFO - 2023-03-13 08:22:21 --> Model "Login_model" initialized
INFO - 2023-03-13 08:22:21 --> Final output sent to browser
DEBUG - 2023-03-13 08:22:21 --> Total execution time: 0.0736
INFO - 2023-03-13 08:23:07 --> Config Class Initialized
INFO - 2023-03-13 08:23:07 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:07 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:07 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:07 --> URI Class Initialized
INFO - 2023-03-13 08:23:07 --> Router Class Initialized
INFO - 2023-03-13 08:23:07 --> Output Class Initialized
INFO - 2023-03-13 08:23:07 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:07 --> Input Class Initialized
INFO - 2023-03-13 08:23:07 --> Language Class Initialized
INFO - 2023-03-13 08:23:07 --> Loader Class Initialized
INFO - 2023-03-13 08:23:07 --> Controller Class Initialized
INFO - 2023-03-13 08:23:07 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:07 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:07 --> Model "Change_model" initialized
INFO - 2023-03-13 08:23:07 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:23:07 --> Final output sent to browser
DEBUG - 2023-03-13 08:23:07 --> Total execution time: 0.1056
INFO - 2023-03-13 08:23:07 --> Config Class Initialized
INFO - 2023-03-13 08:23:07 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:07 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:07 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:07 --> URI Class Initialized
INFO - 2023-03-13 08:23:07 --> Router Class Initialized
INFO - 2023-03-13 08:23:07 --> Output Class Initialized
INFO - 2023-03-13 08:23:07 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:07 --> Input Class Initialized
INFO - 2023-03-13 08:23:07 --> Language Class Initialized
INFO - 2023-03-13 08:23:07 --> Loader Class Initialized
INFO - 2023-03-13 08:23:07 --> Controller Class Initialized
INFO - 2023-03-13 08:23:07 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:07 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:07 --> Final output sent to browser
DEBUG - 2023-03-13 08:23:07 --> Total execution time: 0.0033
INFO - 2023-03-13 08:23:07 --> Config Class Initialized
INFO - 2023-03-13 08:23:07 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:07 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:07 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:07 --> URI Class Initialized
INFO - 2023-03-13 08:23:07 --> Router Class Initialized
INFO - 2023-03-13 08:23:07 --> Output Class Initialized
INFO - 2023-03-13 08:23:07 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:07 --> Input Class Initialized
INFO - 2023-03-13 08:23:07 --> Language Class Initialized
INFO - 2023-03-13 08:23:07 --> Loader Class Initialized
INFO - 2023-03-13 08:23:07 --> Controller Class Initialized
INFO - 2023-03-13 08:23:07 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:07 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:07 --> Database Driver Class Initialized
INFO - 2023-03-13 08:23:07 --> Model "Login_model" initialized
INFO - 2023-03-13 08:23:22 --> Config Class Initialized
INFO - 2023-03-13 08:23:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:22 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:22 --> URI Class Initialized
INFO - 2023-03-13 08:23:22 --> Router Class Initialized
INFO - 2023-03-13 08:23:22 --> Output Class Initialized
INFO - 2023-03-13 08:23:22 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:22 --> Input Class Initialized
INFO - 2023-03-13 08:23:22 --> Language Class Initialized
INFO - 2023-03-13 08:23:22 --> Loader Class Initialized
INFO - 2023-03-13 08:23:22 --> Controller Class Initialized
INFO - 2023-03-13 08:23:22 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:22 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:22 --> Model "Change_model" initialized
INFO - 2023-03-13 08:23:22 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:23:22 --> Final output sent to browser
DEBUG - 2023-03-13 08:23:22 --> Total execution time: 0.0275
INFO - 2023-03-13 08:23:22 --> Config Class Initialized
INFO - 2023-03-13 08:23:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:22 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:22 --> URI Class Initialized
INFO - 2023-03-13 08:23:22 --> Router Class Initialized
INFO - 2023-03-13 08:23:22 --> Output Class Initialized
INFO - 2023-03-13 08:23:22 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:22 --> Input Class Initialized
INFO - 2023-03-13 08:23:22 --> Language Class Initialized
INFO - 2023-03-13 08:23:22 --> Loader Class Initialized
INFO - 2023-03-13 08:23:22 --> Controller Class Initialized
INFO - 2023-03-13 08:23:22 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:22 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:22 --> Final output sent to browser
DEBUG - 2023-03-13 08:23:22 --> Total execution time: 0.0035
INFO - 2023-03-13 08:23:22 --> Config Class Initialized
INFO - 2023-03-13 08:23:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:23:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:23:22 --> Utf8 Class Initialized
INFO - 2023-03-13 08:23:22 --> URI Class Initialized
INFO - 2023-03-13 08:23:22 --> Router Class Initialized
INFO - 2023-03-13 08:23:22 --> Output Class Initialized
INFO - 2023-03-13 08:23:22 --> Security Class Initialized
DEBUG - 2023-03-13 08:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:23:22 --> Input Class Initialized
INFO - 2023-03-13 08:23:22 --> Language Class Initialized
INFO - 2023-03-13 08:23:22 --> Loader Class Initialized
INFO - 2023-03-13 08:23:22 --> Controller Class Initialized
INFO - 2023-03-13 08:23:22 --> Helper loaded: form_helper
INFO - 2023-03-13 08:23:22 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:23:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:23:22 --> Database Driver Class Initialized
INFO - 2023-03-13 08:23:22 --> Model "Login_model" initialized
INFO - 2023-03-13 08:24:49 --> Config Class Initialized
INFO - 2023-03-13 08:24:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:49 --> URI Class Initialized
INFO - 2023-03-13 08:24:49 --> Router Class Initialized
INFO - 2023-03-13 08:24:49 --> Output Class Initialized
INFO - 2023-03-13 08:24:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:49 --> Input Class Initialized
INFO - 2023-03-13 08:24:49 --> Language Class Initialized
INFO - 2023-03-13 08:24:49 --> Loader Class Initialized
INFO - 2023-03-13 08:24:49 --> Controller Class Initialized
INFO - 2023-03-13 08:24:49 --> Helper loaded: form_helper
INFO - 2023-03-13 08:24:49 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:49 --> Model "Change_model" initialized
INFO - 2023-03-13 08:24:49 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:24:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:49 --> Total execution time: 0.0239
INFO - 2023-03-13 08:24:49 --> Config Class Initialized
INFO - 2023-03-13 08:24:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:49 --> URI Class Initialized
INFO - 2023-03-13 08:24:49 --> Router Class Initialized
INFO - 2023-03-13 08:24:49 --> Output Class Initialized
INFO - 2023-03-13 08:24:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:49 --> Input Class Initialized
INFO - 2023-03-13 08:24:49 --> Language Class Initialized
INFO - 2023-03-13 08:24:49 --> Loader Class Initialized
INFO - 2023-03-13 08:24:49 --> Controller Class Initialized
INFO - 2023-03-13 08:24:49 --> Helper loaded: form_helper
INFO - 2023-03-13 08:24:49 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:49 --> Total execution time: 0.0038
INFO - 2023-03-13 08:24:49 --> Config Class Initialized
INFO - 2023-03-13 08:24:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:49 --> URI Class Initialized
INFO - 2023-03-13 08:24:49 --> Router Class Initialized
INFO - 2023-03-13 08:24:49 --> Output Class Initialized
INFO - 2023-03-13 08:24:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:49 --> Input Class Initialized
INFO - 2023-03-13 08:24:49 --> Language Class Initialized
INFO - 2023-03-13 08:24:49 --> Loader Class Initialized
INFO - 2023-03-13 08:24:49 --> Controller Class Initialized
INFO - 2023-03-13 08:24:49 --> Helper loaded: form_helper
INFO - 2023-03-13 08:24:49 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:49 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:49 --> Model "Login_model" initialized
INFO - 2023-03-13 08:24:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:49 --> Total execution time: 0.0149
INFO - 2023-03-13 08:24:49 --> Config Class Initialized
INFO - 2023-03-13 08:24:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:49 --> URI Class Initialized
INFO - 2023-03-13 08:24:49 --> Router Class Initialized
INFO - 2023-03-13 08:24:49 --> Output Class Initialized
INFO - 2023-03-13 08:24:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:49 --> Input Class Initialized
INFO - 2023-03-13 08:24:49 --> Language Class Initialized
INFO - 2023-03-13 08:24:49 --> Loader Class Initialized
INFO - 2023-03-13 08:24:49 --> Controller Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:49 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:24:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:49 --> Total execution time: 0.0561
INFO - 2023-03-13 08:24:49 --> Config Class Initialized
INFO - 2023-03-13 08:24:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:49 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:49 --> URI Class Initialized
INFO - 2023-03-13 08:24:49 --> Router Class Initialized
INFO - 2023-03-13 08:24:49 --> Output Class Initialized
INFO - 2023-03-13 08:24:49 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:49 --> Input Class Initialized
INFO - 2023-03-13 08:24:49 --> Language Class Initialized
INFO - 2023-03-13 08:24:49 --> Loader Class Initialized
INFO - 2023-03-13 08:24:49 --> Controller Class Initialized
DEBUG - 2023-03-13 08:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:49 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:24:49 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:49 --> Total execution time: 0.0126
INFO - 2023-03-13 08:24:50 --> Config Class Initialized
INFO - 2023-03-13 08:24:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:50 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:50 --> URI Class Initialized
INFO - 2023-03-13 08:24:50 --> Router Class Initialized
INFO - 2023-03-13 08:24:50 --> Output Class Initialized
INFO - 2023-03-13 08:24:50 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:50 --> Input Class Initialized
INFO - 2023-03-13 08:24:50 --> Language Class Initialized
INFO - 2023-03-13 08:24:50 --> Loader Class Initialized
INFO - 2023-03-13 08:24:50 --> Controller Class Initialized
DEBUG - 2023-03-13 08:24:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:50 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:24:50 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:50 --> Model "Login_model" initialized
INFO - 2023-03-13 08:24:50 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:50 --> Total execution time: 0.0890
INFO - 2023-03-13 08:24:50 --> Config Class Initialized
INFO - 2023-03-13 08:24:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:24:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:24:50 --> Utf8 Class Initialized
INFO - 2023-03-13 08:24:50 --> URI Class Initialized
INFO - 2023-03-13 08:24:50 --> Router Class Initialized
INFO - 2023-03-13 08:24:50 --> Output Class Initialized
INFO - 2023-03-13 08:24:50 --> Security Class Initialized
DEBUG - 2023-03-13 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:24:50 --> Input Class Initialized
INFO - 2023-03-13 08:24:50 --> Language Class Initialized
INFO - 2023-03-13 08:24:50 --> Loader Class Initialized
INFO - 2023-03-13 08:24:50 --> Controller Class Initialized
DEBUG - 2023-03-13 08:24:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:24:50 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:24:50 --> Database Driver Class Initialized
INFO - 2023-03-13 08:24:50 --> Model "Login_model" initialized
INFO - 2023-03-13 08:24:50 --> Final output sent to browser
DEBUG - 2023-03-13 08:24:50 --> Total execution time: 0.1220
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
INFO - 2023-03-13 08:31:10 --> Helper loaded: form_helper
INFO - 2023-03-13 08:31:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Model "Change_model" initialized
INFO - 2023-03-13 08:31:10 --> Model "Grafana_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0321
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
INFO - 2023-03-13 08:31:10 --> Helper loaded: form_helper
INFO - 2023-03-13 08:31:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0026
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
INFO - 2023-03-13 08:31:10 --> Helper loaded: form_helper
INFO - 2023-03-13 08:31:10 --> Helper loaded: url_helper
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Login_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0165
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0522
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0129
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Login_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0385
INFO - 2023-03-13 08:31:10 --> Config Class Initialized
INFO - 2023-03-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:31:10 --> Utf8 Class Initialized
INFO - 2023-03-13 08:31:10 --> URI Class Initialized
INFO - 2023-03-13 08:31:10 --> Router Class Initialized
INFO - 2023-03-13 08:31:10 --> Output Class Initialized
INFO - 2023-03-13 08:31:10 --> Security Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:31:10 --> Input Class Initialized
INFO - 2023-03-13 08:31:10 --> Language Class Initialized
INFO - 2023-03-13 08:31:10 --> Loader Class Initialized
INFO - 2023-03-13 08:31:10 --> Controller Class Initialized
DEBUG - 2023-03-13 08:31:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:31:10 --> Database Driver Class Initialized
INFO - 2023-03-13 08:31:10 --> Model "Login_model" initialized
INFO - 2023-03-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:31:10 --> Total execution time: 0.0785
INFO - 2023-03-13 08:32:23 --> Config Class Initialized
INFO - 2023-03-13 08:32:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:23 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:23 --> URI Class Initialized
INFO - 2023-03-13 08:32:23 --> Router Class Initialized
INFO - 2023-03-13 08:32:23 --> Output Class Initialized
INFO - 2023-03-13 08:32:23 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:23 --> Input Class Initialized
INFO - 2023-03-13 08:32:23 --> Language Class Initialized
INFO - 2023-03-13 08:32:23 --> Loader Class Initialized
INFO - 2023-03-13 08:32:23 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:23 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:32:23 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:23 --> Total execution time: 0.1556
INFO - 2023-03-13 08:32:23 --> Config Class Initialized
INFO - 2023-03-13 08:32:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:23 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:23 --> URI Class Initialized
INFO - 2023-03-13 08:32:23 --> Router Class Initialized
INFO - 2023-03-13 08:32:23 --> Output Class Initialized
INFO - 2023-03-13 08:32:23 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:23 --> Input Class Initialized
INFO - 2023-03-13 08:32:23 --> Language Class Initialized
INFO - 2023-03-13 08:32:23 --> Loader Class Initialized
INFO - 2023-03-13 08:32:23 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:23 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:23 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:32:23 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:23 --> Total execution time: 0.2220
INFO - 2023-03-13 08:32:25 --> Config Class Initialized
INFO - 2023-03-13 08:32:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:25 --> URI Class Initialized
INFO - 2023-03-13 08:32:25 --> Router Class Initialized
INFO - 2023-03-13 08:32:25 --> Output Class Initialized
INFO - 2023-03-13 08:32:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:25 --> Input Class Initialized
INFO - 2023-03-13 08:32:25 --> Language Class Initialized
INFO - 2023-03-13 08:32:25 --> Loader Class Initialized
INFO - 2023-03-13 08:32:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:32:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:25 --> Model "Login_model" initialized
INFO - 2023-03-13 08:32:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:25 --> Total execution time: 0.0459
INFO - 2023-03-13 08:32:25 --> Config Class Initialized
INFO - 2023-03-13 08:32:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:25 --> URI Class Initialized
INFO - 2023-03-13 08:32:25 --> Router Class Initialized
INFO - 2023-03-13 08:32:25 --> Output Class Initialized
INFO - 2023-03-13 08:32:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:25 --> Input Class Initialized
INFO - 2023-03-13 08:32:25 --> Language Class Initialized
INFO - 2023-03-13 08:32:25 --> Loader Class Initialized
INFO - 2023-03-13 08:32:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:32:25 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:25 --> Model "Login_model" initialized
INFO - 2023-03-13 08:32:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:25 --> Total execution time: 0.0529
INFO - 2023-03-13 08:32:37 --> Config Class Initialized
INFO - 2023-03-13 08:32:37 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:37 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:37 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:37 --> URI Class Initialized
INFO - 2023-03-13 08:32:37 --> Router Class Initialized
INFO - 2023-03-13 08:32:37 --> Output Class Initialized
INFO - 2023-03-13 08:32:37 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:37 --> Input Class Initialized
INFO - 2023-03-13 08:32:37 --> Language Class Initialized
INFO - 2023-03-13 08:32:37 --> Loader Class Initialized
INFO - 2023-03-13 08:32:37 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:37 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:37 --> Total execution time: 0.0645
INFO - 2023-03-13 08:32:37 --> Config Class Initialized
INFO - 2023-03-13 08:32:37 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:37 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:37 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:37 --> URI Class Initialized
INFO - 2023-03-13 08:32:37 --> Router Class Initialized
INFO - 2023-03-13 08:32:37 --> Output Class Initialized
INFO - 2023-03-13 08:32:37 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:37 --> Input Class Initialized
INFO - 2023-03-13 08:32:37 --> Language Class Initialized
INFO - 2023-03-13 08:32:37 --> Loader Class Initialized
INFO - 2023-03-13 08:32:37 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:37 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:37 --> Total execution time: 0.0671
INFO - 2023-03-13 08:32:39 --> Config Class Initialized
INFO - 2023-03-13 08:32:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:39 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:39 --> URI Class Initialized
INFO - 2023-03-13 08:32:39 --> Router Class Initialized
INFO - 2023-03-13 08:32:39 --> Output Class Initialized
INFO - 2023-03-13 08:32:39 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:39 --> Input Class Initialized
INFO - 2023-03-13 08:32:39 --> Language Class Initialized
INFO - 2023-03-13 08:32:39 --> Loader Class Initialized
INFO - 2023-03-13 08:32:39 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:39 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:39 --> Total execution time: 0.0050
INFO - 2023-03-13 08:32:39 --> Config Class Initialized
INFO - 2023-03-13 08:32:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:32:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:32:39 --> Utf8 Class Initialized
INFO - 2023-03-13 08:32:39 --> URI Class Initialized
INFO - 2023-03-13 08:32:39 --> Router Class Initialized
INFO - 2023-03-13 08:32:39 --> Output Class Initialized
INFO - 2023-03-13 08:32:39 --> Security Class Initialized
DEBUG - 2023-03-13 08:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:32:39 --> Input Class Initialized
INFO - 2023-03-13 08:32:39 --> Language Class Initialized
INFO - 2023-03-13 08:32:39 --> Loader Class Initialized
INFO - 2023-03-13 08:32:39 --> Controller Class Initialized
DEBUG - 2023-03-13 08:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:32:39 --> Database Driver Class Initialized
INFO - 2023-03-13 08:32:39 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:32:39 --> Final output sent to browser
DEBUG - 2023-03-13 08:32:39 --> Total execution time: 0.1091
INFO - 2023-03-13 08:35:35 --> Config Class Initialized
INFO - 2023-03-13 08:35:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:35:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:35:35 --> Utf8 Class Initialized
INFO - 2023-03-13 08:35:35 --> URI Class Initialized
INFO - 2023-03-13 08:35:35 --> Router Class Initialized
INFO - 2023-03-13 08:35:35 --> Output Class Initialized
INFO - 2023-03-13 08:35:35 --> Security Class Initialized
DEBUG - 2023-03-13 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:35:35 --> Input Class Initialized
INFO - 2023-03-13 08:35:35 --> Language Class Initialized
INFO - 2023-03-13 08:35:35 --> Loader Class Initialized
INFO - 2023-03-13 08:35:35 --> Controller Class Initialized
DEBUG - 2023-03-13 08:35:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:35:36 --> Final output sent to browser
DEBUG - 2023-03-13 08:35:36 --> Total execution time: 0.1037
INFO - 2023-03-13 08:35:36 --> Config Class Initialized
INFO - 2023-03-13 08:35:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:35:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:35:36 --> Utf8 Class Initialized
INFO - 2023-03-13 08:35:36 --> URI Class Initialized
INFO - 2023-03-13 08:35:36 --> Router Class Initialized
INFO - 2023-03-13 08:35:36 --> Output Class Initialized
INFO - 2023-03-13 08:35:36 --> Security Class Initialized
DEBUG - 2023-03-13 08:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:35:36 --> Input Class Initialized
INFO - 2023-03-13 08:35:36 --> Language Class Initialized
INFO - 2023-03-13 08:35:36 --> Loader Class Initialized
INFO - 2023-03-13 08:35:36 --> Controller Class Initialized
DEBUG - 2023-03-13 08:35:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:35:36 --> Final output sent to browser
DEBUG - 2023-03-13 08:35:36 --> Total execution time: 0.0512
INFO - 2023-03-13 08:36:17 --> Config Class Initialized
INFO - 2023-03-13 08:36:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:36:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:36:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:36:17 --> URI Class Initialized
INFO - 2023-03-13 08:36:17 --> Router Class Initialized
INFO - 2023-03-13 08:36:17 --> Output Class Initialized
INFO - 2023-03-13 08:36:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:36:17 --> Input Class Initialized
INFO - 2023-03-13 08:36:17 --> Language Class Initialized
INFO - 2023-03-13 08:36:17 --> Loader Class Initialized
INFO - 2023-03-13 08:36:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:36:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:36:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:36:17 --> Total execution time: 0.2215
INFO - 2023-03-13 08:36:17 --> Config Class Initialized
INFO - 2023-03-13 08:36:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:36:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:36:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:36:17 --> URI Class Initialized
INFO - 2023-03-13 08:36:17 --> Router Class Initialized
INFO - 2023-03-13 08:36:17 --> Output Class Initialized
INFO - 2023-03-13 08:36:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:36:17 --> Input Class Initialized
INFO - 2023-03-13 08:36:17 --> Language Class Initialized
INFO - 2023-03-13 08:36:17 --> Loader Class Initialized
INFO - 2023-03-13 08:36:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:36:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:36:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:36:17 --> Total execution time: 0.0658
INFO - 2023-03-13 08:37:40 --> Config Class Initialized
INFO - 2023-03-13 08:37:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:37:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:37:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:37:41 --> URI Class Initialized
INFO - 2023-03-13 08:37:41 --> Router Class Initialized
INFO - 2023-03-13 08:37:41 --> Output Class Initialized
INFO - 2023-03-13 08:37:41 --> Security Class Initialized
DEBUG - 2023-03-13 08:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:37:41 --> Input Class Initialized
INFO - 2023-03-13 08:37:41 --> Language Class Initialized
INFO - 2023-03-13 08:37:41 --> Loader Class Initialized
INFO - 2023-03-13 08:37:41 --> Controller Class Initialized
DEBUG - 2023-03-13 08:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:37:41 --> Final output sent to browser
DEBUG - 2023-03-13 08:37:41 --> Total execution time: 0.1398
INFO - 2023-03-13 08:37:41 --> Config Class Initialized
INFO - 2023-03-13 08:37:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:37:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:37:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:37:41 --> URI Class Initialized
INFO - 2023-03-13 08:37:41 --> Router Class Initialized
INFO - 2023-03-13 08:37:41 --> Output Class Initialized
INFO - 2023-03-13 08:37:41 --> Security Class Initialized
DEBUG - 2023-03-13 08:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:37:41 --> Input Class Initialized
INFO - 2023-03-13 08:37:41 --> Language Class Initialized
INFO - 2023-03-13 08:37:41 --> Loader Class Initialized
INFO - 2023-03-13 08:37:41 --> Controller Class Initialized
DEBUG - 2023-03-13 08:37:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:37:41 --> Final output sent to browser
DEBUG - 2023-03-13 08:37:41 --> Total execution time: 0.0500
INFO - 2023-03-13 08:38:24 --> Config Class Initialized
INFO - 2023-03-13 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:38:24 --> Utf8 Class Initialized
INFO - 2023-03-13 08:38:24 --> URI Class Initialized
INFO - 2023-03-13 08:38:24 --> Router Class Initialized
INFO - 2023-03-13 08:38:24 --> Output Class Initialized
INFO - 2023-03-13 08:38:24 --> Security Class Initialized
DEBUG - 2023-03-13 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:38:24 --> Input Class Initialized
INFO - 2023-03-13 08:38:24 --> Language Class Initialized
INFO - 2023-03-13 08:38:24 --> Loader Class Initialized
INFO - 2023-03-13 08:38:24 --> Controller Class Initialized
DEBUG - 2023-03-13 08:38:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:38:24 --> Final output sent to browser
DEBUG - 2023-03-13 08:38:24 --> Total execution time: 0.0923
INFO - 2023-03-13 08:38:24 --> Config Class Initialized
INFO - 2023-03-13 08:38:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:38:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:38:25 --> Utf8 Class Initialized
INFO - 2023-03-13 08:38:25 --> URI Class Initialized
INFO - 2023-03-13 08:38:25 --> Router Class Initialized
INFO - 2023-03-13 08:38:25 --> Output Class Initialized
INFO - 2023-03-13 08:38:25 --> Security Class Initialized
DEBUG - 2023-03-13 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:38:25 --> Input Class Initialized
INFO - 2023-03-13 08:38:25 --> Language Class Initialized
INFO - 2023-03-13 08:38:25 --> Loader Class Initialized
INFO - 2023-03-13 08:38:25 --> Controller Class Initialized
DEBUG - 2023-03-13 08:38:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:38:25 --> Final output sent to browser
DEBUG - 2023-03-13 08:38:25 --> Total execution time: 0.0519
INFO - 2023-03-13 08:38:29 --> Config Class Initialized
INFO - 2023-03-13 08:38:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:38:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:38:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:38:29 --> URI Class Initialized
INFO - 2023-03-13 08:38:29 --> Router Class Initialized
INFO - 2023-03-13 08:38:29 --> Output Class Initialized
INFO - 2023-03-13 08:38:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:38:29 --> Input Class Initialized
INFO - 2023-03-13 08:38:29 --> Language Class Initialized
INFO - 2023-03-13 08:38:29 --> Loader Class Initialized
INFO - 2023-03-13 08:38:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:38:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:38:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:38:29 --> Total execution time: 0.1067
INFO - 2023-03-13 08:39:15 --> Config Class Initialized
INFO - 2023-03-13 08:39:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:39:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:15 --> URI Class Initialized
INFO - 2023-03-13 08:39:15 --> Router Class Initialized
INFO - 2023-03-13 08:39:15 --> Output Class Initialized
INFO - 2023-03-13 08:39:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:15 --> Input Class Initialized
INFO - 2023-03-13 08:39:15 --> Language Class Initialized
INFO - 2023-03-13 08:39:15 --> Loader Class Initialized
INFO - 2023-03-13 08:39:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:39:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:15 --> Total execution time: 0.0935
INFO - 2023-03-13 08:39:15 --> Config Class Initialized
INFO - 2023-03-13 08:39:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:39:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:15 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:15 --> URI Class Initialized
INFO - 2023-03-13 08:39:15 --> Router Class Initialized
INFO - 2023-03-13 08:39:15 --> Output Class Initialized
INFO - 2023-03-13 08:39:15 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:15 --> Input Class Initialized
INFO - 2023-03-13 08:39:15 --> Language Class Initialized
INFO - 2023-03-13 08:39:15 --> Loader Class Initialized
INFO - 2023-03-13 08:39:15 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:39:15 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:15 --> Total execution time: 0.0481
INFO - 2023-03-13 08:39:26 --> Config Class Initialized
INFO - 2023-03-13 08:39:26 --> Config Class Initialized
INFO - 2023-03-13 08:39:26 --> Hooks Class Initialized
INFO - 2023-03-13 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:26 --> URI Class Initialized
INFO - 2023-03-13 08:39:26 --> Router Class Initialized
INFO - 2023-03-13 08:39:26 --> Output Class Initialized
INFO - 2023-03-13 08:39:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:26 --> Input Class Initialized
INFO - 2023-03-13 08:39:26 --> Language Class Initialized
INFO - 2023-03-13 08:39:26 --> Loader Class Initialized
INFO - 2023-03-13 08:39:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:26 --> URI Class Initialized
INFO - 2023-03-13 08:39:26 --> Router Class Initialized
INFO - 2023-03-13 08:39:26 --> Output Class Initialized
INFO - 2023-03-13 08:39:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:26 --> Input Class Initialized
INFO - 2023-03-13 08:39:26 --> Language Class Initialized
INFO - 2023-03-13 08:39:26 --> Loader Class Initialized
INFO - 2023-03-13 08:39:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:39:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:39:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:39:26 --> Model "Login_model" initialized
INFO - 2023-03-13 08:39:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:26 --> Total execution time: 0.0775
INFO - 2023-03-13 08:39:26 --> Config Class Initialized
INFO - 2023-03-13 08:39:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:26 --> Total execution time: 0.1059
INFO - 2023-03-13 08:39:26 --> Config Class Initialized
INFO - 2023-03-13 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:26 --> URI Class Initialized
INFO - 2023-03-13 08:39:26 --> Router Class Initialized
INFO - 2023-03-13 08:39:26 --> Output Class Initialized
INFO - 2023-03-13 08:39:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:26 --> Input Class Initialized
INFO - 2023-03-13 08:39:26 --> Language Class Initialized
INFO - 2023-03-13 08:39:26 --> Loader Class Initialized
INFO - 2023-03-13 08:39:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:39:26 --> Utf8 Class Initialized
INFO - 2023-03-13 08:39:26 --> URI Class Initialized
INFO - 2023-03-13 08:39:26 --> Router Class Initialized
INFO - 2023-03-13 08:39:26 --> Output Class Initialized
INFO - 2023-03-13 08:39:26 --> Security Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:39:26 --> Input Class Initialized
INFO - 2023-03-13 08:39:26 --> Language Class Initialized
INFO - 2023-03-13 08:39:26 --> Loader Class Initialized
INFO - 2023-03-13 08:39:26 --> Controller Class Initialized
DEBUG - 2023-03-13 08:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:39:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:39:26 --> Database Driver Class Initialized
INFO - 2023-03-13 08:39:26 --> Model "Login_model" initialized
INFO - 2023-03-13 08:39:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:26 --> Total execution time: 0.0697
INFO - 2023-03-13 08:39:26 --> Final output sent to browser
DEBUG - 2023-03-13 08:39:26 --> Total execution time: 0.0677
INFO - 2023-03-13 08:40:12 --> Config Class Initialized
INFO - 2023-03-13 08:40:12 --> Config Class Initialized
INFO - 2023-03-13 08:40:12 --> Hooks Class Initialized
INFO - 2023-03-13 08:40:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:40:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:40:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:12 --> URI Class Initialized
INFO - 2023-03-13 08:40:12 --> URI Class Initialized
INFO - 2023-03-13 08:40:12 --> Router Class Initialized
INFO - 2023-03-13 08:40:12 --> Router Class Initialized
INFO - 2023-03-13 08:40:12 --> Output Class Initialized
INFO - 2023-03-13 08:40:12 --> Output Class Initialized
INFO - 2023-03-13 08:40:12 --> Security Class Initialized
INFO - 2023-03-13 08:40:12 --> Security Class Initialized
DEBUG - 2023-03-13 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:40:12 --> Input Class Initialized
INFO - 2023-03-13 08:40:12 --> Input Class Initialized
INFO - 2023-03-13 08:40:12 --> Language Class Initialized
INFO - 2023-03-13 08:40:12 --> Language Class Initialized
INFO - 2023-03-13 08:40:12 --> Loader Class Initialized
INFO - 2023-03-13 08:40:12 --> Loader Class Initialized
INFO - 2023-03-13 08:40:12 --> Controller Class Initialized
INFO - 2023-03-13 08:40:12 --> Controller Class Initialized
DEBUG - 2023-03-13 08:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:40:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:40:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:40:12 --> Model "Login_model" initialized
INFO - 2023-03-13 08:40:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:12 --> Total execution time: 0.1035
INFO - 2023-03-13 08:40:12 --> Config Class Initialized
INFO - 2023-03-13 08:40:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:12 --> Total execution time: 0.1273
INFO - 2023-03-13 08:40:12 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:40:12 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:40:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:12 --> URI Class Initialized
INFO - 2023-03-13 08:40:12 --> Router Class Initialized
INFO - 2023-03-13 08:40:12 --> Output Class Initialized
INFO - 2023-03-13 08:40:12 --> Security Class Initialized
DEBUG - 2023-03-13 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:40:12 --> Input Class Initialized
INFO - 2023-03-13 08:40:12 --> Config Class Initialized
INFO - 2023-03-13 08:40:12 --> Language Class Initialized
INFO - 2023-03-13 08:40:12 --> Hooks Class Initialized
INFO - 2023-03-13 08:40:12 --> Loader Class Initialized
INFO - 2023-03-13 08:40:12 --> Controller Class Initialized
DEBUG - 2023-03-13 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:40:12 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:40:12 --> URI Class Initialized
INFO - 2023-03-13 08:40:12 --> Router Class Initialized
INFO - 2023-03-13 08:40:12 --> Output Class Initialized
INFO - 2023-03-13 08:40:12 --> Security Class Initialized
DEBUG - 2023-03-13 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:40:12 --> Input Class Initialized
INFO - 2023-03-13 08:40:12 --> Language Class Initialized
INFO - 2023-03-13 08:40:12 --> Loader Class Initialized
INFO - 2023-03-13 08:40:12 --> Controller Class Initialized
DEBUG - 2023-03-13 08:40:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:40:12 --> Database Driver Class Initialized
INFO - 2023-03-13 08:40:12 --> Model "Login_model" initialized
INFO - 2023-03-13 08:40:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:12 --> Total execution time: 0.0729
INFO - 2023-03-13 08:40:12 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:12 --> Total execution time: 0.0681
INFO - 2023-03-13 08:40:18 --> Config Class Initialized
INFO - 2023-03-13 08:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:40:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:18 --> URI Class Initialized
INFO - 2023-03-13 08:40:18 --> Router Class Initialized
INFO - 2023-03-13 08:40:18 --> Output Class Initialized
INFO - 2023-03-13 08:40:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:40:18 --> Input Class Initialized
INFO - 2023-03-13 08:40:18 --> Language Class Initialized
INFO - 2023-03-13 08:40:18 --> Loader Class Initialized
INFO - 2023-03-13 08:40:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:40:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:18 --> Total execution time: 0.0048
INFO - 2023-03-13 08:40:18 --> Config Class Initialized
INFO - 2023-03-13 08:40:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:40:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:40:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:40:18 --> URI Class Initialized
INFO - 2023-03-13 08:40:18 --> Router Class Initialized
INFO - 2023-03-13 08:40:18 --> Output Class Initialized
INFO - 2023-03-13 08:40:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:40:18 --> Input Class Initialized
INFO - 2023-03-13 08:40:18 --> Language Class Initialized
INFO - 2023-03-13 08:40:18 --> Loader Class Initialized
INFO - 2023-03-13 08:40:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:40:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:40:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:40:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:40:18 --> Final output sent to browser
DEBUG - 2023-03-13 08:40:18 --> Total execution time: 0.0167
INFO - 2023-03-13 08:41:00 --> Config Class Initialized
INFO - 2023-03-13 08:41:00 --> Config Class Initialized
INFO - 2023-03-13 08:41:00 --> Hooks Class Initialized
INFO - 2023-03-13 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:00 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:00 --> URI Class Initialized
INFO - 2023-03-13 08:41:00 --> Router Class Initialized
INFO - 2023-03-13 08:41:00 --> Output Class Initialized
INFO - 2023-03-13 08:41:00 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:00 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:00 --> URI Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:00 --> Router Class Initialized
INFO - 2023-03-13 08:41:00 --> Input Class Initialized
INFO - 2023-03-13 08:41:00 --> Output Class Initialized
INFO - 2023-03-13 08:41:00 --> Language Class Initialized
INFO - 2023-03-13 08:41:00 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:00 --> Loader Class Initialized
INFO - 2023-03-13 08:41:00 --> Input Class Initialized
INFO - 2023-03-13 08:41:00 --> Language Class Initialized
INFO - 2023-03-13 08:41:00 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:00 --> Loader Class Initialized
INFO - 2023-03-13 08:41:00 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:00 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:00 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:00 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:00 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:00 --> Total execution time: 0.0782
INFO - 2023-03-13 08:41:00 --> Config Class Initialized
INFO - 2023-03-13 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:00 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:00 --> URI Class Initialized
INFO - 2023-03-13 08:41:00 --> Router Class Initialized
INFO - 2023-03-13 08:41:00 --> Output Class Initialized
INFO - 2023-03-13 08:41:00 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:00 --> Input Class Initialized
INFO - 2023-03-13 08:41:00 --> Language Class Initialized
INFO - 2023-03-13 08:41:00 --> Loader Class Initialized
INFO - 2023-03-13 08:41:00 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:00 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:00 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:00 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:00 --> Total execution time: 0.1142
INFO - 2023-03-13 08:41:00 --> Config Class Initialized
INFO - 2023-03-13 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:00 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:00 --> URI Class Initialized
INFO - 2023-03-13 08:41:00 --> Router Class Initialized
INFO - 2023-03-13 08:41:00 --> Output Class Initialized
INFO - 2023-03-13 08:41:00 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:00 --> Input Class Initialized
INFO - 2023-03-13 08:41:00 --> Language Class Initialized
INFO - 2023-03-13 08:41:00 --> Loader Class Initialized
INFO - 2023-03-13 08:41:00 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:00 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:00 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:00 --> Total execution time: 0.0523
INFO - 2023-03-13 08:41:00 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:00 --> Total execution time: 0.0650
INFO - 2023-03-13 08:41:17 --> Config Class Initialized
INFO - 2023-03-13 08:41:17 --> Config Class Initialized
INFO - 2023-03-13 08:41:17 --> Hooks Class Initialized
INFO - 2023-03-13 08:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:17 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:17 --> URI Class Initialized
INFO - 2023-03-13 08:41:17 --> URI Class Initialized
INFO - 2023-03-13 08:41:17 --> Router Class Initialized
INFO - 2023-03-13 08:41:17 --> Router Class Initialized
INFO - 2023-03-13 08:41:17 --> Output Class Initialized
INFO - 2023-03-13 08:41:17 --> Output Class Initialized
INFO - 2023-03-13 08:41:17 --> Security Class Initialized
INFO - 2023-03-13 08:41:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:17 --> Input Class Initialized
INFO - 2023-03-13 08:41:17 --> Input Class Initialized
INFO - 2023-03-13 08:41:17 --> Language Class Initialized
INFO - 2023-03-13 08:41:17 --> Language Class Initialized
INFO - 2023-03-13 08:41:17 --> Loader Class Initialized
INFO - 2023-03-13 08:41:17 --> Loader Class Initialized
INFO - 2023-03-13 08:41:17 --> Controller Class Initialized
INFO - 2023-03-13 08:41:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:17 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:17 --> Total execution time: 0.0700
INFO - 2023-03-13 08:41:17 --> Config Class Initialized
INFO - 2023-03-13 08:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:17 --> URI Class Initialized
INFO - 2023-03-13 08:41:17 --> Router Class Initialized
INFO - 2023-03-13 08:41:17 --> Output Class Initialized
INFO - 2023-03-13 08:41:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:17 --> Input Class Initialized
INFO - 2023-03-13 08:41:17 --> Language Class Initialized
INFO - 2023-03-13 08:41:17 --> Loader Class Initialized
INFO - 2023-03-13 08:41:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:17 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:17 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:17 --> Total execution time: 0.0290
INFO - 2023-03-13 08:41:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:17 --> Total execution time: 0.1078
INFO - 2023-03-13 08:41:17 --> Config Class Initialized
INFO - 2023-03-13 08:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:17 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:17 --> URI Class Initialized
INFO - 2023-03-13 08:41:17 --> Router Class Initialized
INFO - 2023-03-13 08:41:17 --> Output Class Initialized
INFO - 2023-03-13 08:41:17 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:17 --> Input Class Initialized
INFO - 2023-03-13 08:41:17 --> Language Class Initialized
INFO - 2023-03-13 08:41:17 --> Loader Class Initialized
INFO - 2023-03-13 08:41:17 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:17 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:17 --> Total execution time: 0.0625
INFO - 2023-03-13 08:41:27 --> Config Class Initialized
INFO - 2023-03-13 08:41:27 --> Config Class Initialized
INFO - 2023-03-13 08:41:27 --> Hooks Class Initialized
INFO - 2023-03-13 08:41:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:41:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:27 --> URI Class Initialized
INFO - 2023-03-13 08:41:27 --> URI Class Initialized
INFO - 2023-03-13 08:41:27 --> Router Class Initialized
INFO - 2023-03-13 08:41:27 --> Router Class Initialized
INFO - 2023-03-13 08:41:27 --> Output Class Initialized
INFO - 2023-03-13 08:41:27 --> Output Class Initialized
INFO - 2023-03-13 08:41:27 --> Security Class Initialized
INFO - 2023-03-13 08:41:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:27 --> Input Class Initialized
INFO - 2023-03-13 08:41:27 --> Input Class Initialized
INFO - 2023-03-13 08:41:27 --> Language Class Initialized
INFO - 2023-03-13 08:41:27 --> Language Class Initialized
INFO - 2023-03-13 08:41:27 --> Loader Class Initialized
INFO - 2023-03-13 08:41:27 --> Loader Class Initialized
INFO - 2023-03-13 08:41:27 --> Controller Class Initialized
INFO - 2023-03-13 08:41:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:27 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:27 --> Total execution time: 0.0683
INFO - 2023-03-13 08:41:27 --> Config Class Initialized
INFO - 2023-03-13 08:41:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:27 --> URI Class Initialized
INFO - 2023-03-13 08:41:27 --> Router Class Initialized
INFO - 2023-03-13 08:41:27 --> Output Class Initialized
INFO - 2023-03-13 08:41:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:27 --> Input Class Initialized
INFO - 2023-03-13 08:41:27 --> Language Class Initialized
INFO - 2023-03-13 08:41:27 --> Loader Class Initialized
INFO - 2023-03-13 08:41:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:41:27 --> Model "Login_model" initialized
INFO - 2023-03-13 08:41:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:27 --> Total execution time: 0.0243
INFO - 2023-03-13 08:41:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:27 --> Total execution time: 0.1013
INFO - 2023-03-13 08:41:27 --> Config Class Initialized
INFO - 2023-03-13 08:41:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:41:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:41:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:41:27 --> URI Class Initialized
INFO - 2023-03-13 08:41:27 --> Router Class Initialized
INFO - 2023-03-13 08:41:27 --> Output Class Initialized
INFO - 2023-03-13 08:41:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:41:27 --> Input Class Initialized
INFO - 2023-03-13 08:41:27 --> Language Class Initialized
INFO - 2023-03-13 08:41:27 --> Loader Class Initialized
INFO - 2023-03-13 08:41:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:41:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:41:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:41:27 --> Total execution time: 0.0582
INFO - 2023-03-13 08:43:09 --> Config Class Initialized
INFO - 2023-03-13 08:43:09 --> Config Class Initialized
INFO - 2023-03-13 08:43:09 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:09 --> Utf8 Class Initialized
DEBUG - 2023-03-13 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:09 --> URI Class Initialized
INFO - 2023-03-13 08:43:09 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:09 --> Router Class Initialized
INFO - 2023-03-13 08:43:09 --> URI Class Initialized
INFO - 2023-03-13 08:43:09 --> Output Class Initialized
INFO - 2023-03-13 08:43:09 --> Router Class Initialized
INFO - 2023-03-13 08:43:09 --> Security Class Initialized
INFO - 2023-03-13 08:43:09 --> Output Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:09 --> Security Class Initialized
INFO - 2023-03-13 08:43:09 --> Input Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:09 --> Language Class Initialized
INFO - 2023-03-13 08:43:09 --> Input Class Initialized
INFO - 2023-03-13 08:43:09 --> Language Class Initialized
INFO - 2023-03-13 08:43:09 --> Loader Class Initialized
INFO - 2023-03-13 08:43:09 --> Loader Class Initialized
INFO - 2023-03-13 08:43:09 --> Controller Class Initialized
INFO - 2023-03-13 08:43:09 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:09 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:09 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:09 --> Total execution time: 0.0951
INFO - 2023-03-13 08:43:09 --> Config Class Initialized
INFO - 2023-03-13 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:09 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:09 --> URI Class Initialized
INFO - 2023-03-13 08:43:09 --> Router Class Initialized
INFO - 2023-03-13 08:43:09 --> Output Class Initialized
INFO - 2023-03-13 08:43:09 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:09 --> Input Class Initialized
INFO - 2023-03-13 08:43:09 --> Language Class Initialized
INFO - 2023-03-13 08:43:09 --> Loader Class Initialized
INFO - 2023-03-13 08:43:09 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:09 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:09 --> Total execution time: 0.1068
INFO - 2023-03-13 08:43:09 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:09 --> Config Class Initialized
INFO - 2023-03-13 08:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:09 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:09 --> URI Class Initialized
INFO - 2023-03-13 08:43:09 --> Router Class Initialized
INFO - 2023-03-13 08:43:09 --> Output Class Initialized
INFO - 2023-03-13 08:43:09 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:09 --> Input Class Initialized
INFO - 2023-03-13 08:43:09 --> Language Class Initialized
INFO - 2023-03-13 08:43:09 --> Loader Class Initialized
INFO - 2023-03-13 08:43:09 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:09 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:09 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:09 --> Total execution time: 0.0242
INFO - 2023-03-13 08:43:10 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:10 --> Total execution time: 0.0578
INFO - 2023-03-13 08:43:28 --> Config Class Initialized
INFO - 2023-03-13 08:43:28 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:28 --> Config Class Initialized
DEBUG - 2023-03-13 08:43:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:28 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:28 --> Utf8 Class Initialized
DEBUG - 2023-03-13 08:43:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:28 --> URI Class Initialized
INFO - 2023-03-13 08:43:28 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:28 --> URI Class Initialized
INFO - 2023-03-13 08:43:28 --> Router Class Initialized
INFO - 2023-03-13 08:43:28 --> Router Class Initialized
INFO - 2023-03-13 08:43:28 --> Output Class Initialized
INFO - 2023-03-13 08:43:28 --> Output Class Initialized
INFO - 2023-03-13 08:43:28 --> Security Class Initialized
INFO - 2023-03-13 08:43:28 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:28 --> Input Class Initialized
INFO - 2023-03-13 08:43:28 --> Input Class Initialized
INFO - 2023-03-13 08:43:28 --> Language Class Initialized
INFO - 2023-03-13 08:43:28 --> Language Class Initialized
INFO - 2023-03-13 08:43:28 --> Loader Class Initialized
INFO - 2023-03-13 08:43:28 --> Loader Class Initialized
INFO - 2023-03-13 08:43:28 --> Controller Class Initialized
INFO - 2023-03-13 08:43:28 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:43:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:28 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:28 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:29 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:29 --> Total execution time: 0.0775
INFO - 2023-03-13 08:43:29 --> Config Class Initialized
INFO - 2023-03-13 08:43:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:29 --> URI Class Initialized
INFO - 2023-03-13 08:43:29 --> Router Class Initialized
INFO - 2023-03-13 08:43:29 --> Output Class Initialized
INFO - 2023-03-13 08:43:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:29 --> Input Class Initialized
INFO - 2023-03-13 08:43:29 --> Language Class Initialized
INFO - 2023-03-13 08:43:29 --> Loader Class Initialized
INFO - 2023-03-13 08:43:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:29 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:29 --> Total execution time: 0.0299
INFO - 2023-03-13 08:43:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:29 --> Total execution time: 0.1134
INFO - 2023-03-13 08:43:29 --> Config Class Initialized
INFO - 2023-03-13 08:43:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:29 --> URI Class Initialized
INFO - 2023-03-13 08:43:29 --> Router Class Initialized
INFO - 2023-03-13 08:43:29 --> Output Class Initialized
INFO - 2023-03-13 08:43:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:29 --> Input Class Initialized
INFO - 2023-03-13 08:43:29 --> Language Class Initialized
INFO - 2023-03-13 08:43:29 --> Loader Class Initialized
INFO - 2023-03-13 08:43:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:29 --> Total execution time: 0.0629
INFO - 2023-03-13 08:43:41 --> Config Class Initialized
INFO - 2023-03-13 08:43:41 --> Config Class Initialized
INFO - 2023-03-13 08:43:41 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:41 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:41 --> URI Class Initialized
INFO - 2023-03-13 08:43:41 --> URI Class Initialized
INFO - 2023-03-13 08:43:41 --> Router Class Initialized
INFO - 2023-03-13 08:43:41 --> Router Class Initialized
INFO - 2023-03-13 08:43:41 --> Output Class Initialized
INFO - 2023-03-13 08:43:41 --> Output Class Initialized
INFO - 2023-03-13 08:43:41 --> Security Class Initialized
INFO - 2023-03-13 08:43:41 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:41 --> Input Class Initialized
INFO - 2023-03-13 08:43:41 --> Input Class Initialized
INFO - 2023-03-13 08:43:41 --> Language Class Initialized
INFO - 2023-03-13 08:43:41 --> Language Class Initialized
INFO - 2023-03-13 08:43:41 --> Loader Class Initialized
INFO - 2023-03-13 08:43:41 --> Loader Class Initialized
INFO - 2023-03-13 08:43:41 --> Controller Class Initialized
INFO - 2023-03-13 08:43:41 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:41 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:41 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:41 --> Final output sent to browser
INFO - 2023-03-13 08:43:41 --> Model "Login_model" initialized
DEBUG - 2023-03-13 08:43:41 --> Total execution time: 0.2524
INFO - 2023-03-13 08:43:41 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:41 --> Total execution time: 0.4255
INFO - 2023-03-13 08:43:42 --> Config Class Initialized
INFO - 2023-03-13 08:43:42 --> Config Class Initialized
INFO - 2023-03-13 08:43:42 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:42 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:42 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:42 --> URI Class Initialized
INFO - 2023-03-13 08:43:42 --> URI Class Initialized
INFO - 2023-03-13 08:43:42 --> Router Class Initialized
INFO - 2023-03-13 08:43:42 --> Router Class Initialized
INFO - 2023-03-13 08:43:42 --> Output Class Initialized
INFO - 2023-03-13 08:43:42 --> Output Class Initialized
INFO - 2023-03-13 08:43:42 --> Security Class Initialized
INFO - 2023-03-13 08:43:42 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:42 --> Input Class Initialized
INFO - 2023-03-13 08:43:42 --> Input Class Initialized
INFO - 2023-03-13 08:43:42 --> Language Class Initialized
INFO - 2023-03-13 08:43:42 --> Language Class Initialized
INFO - 2023-03-13 08:43:42 --> Loader Class Initialized
INFO - 2023-03-13 08:43:42 --> Loader Class Initialized
INFO - 2023-03-13 08:43:42 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:42 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:42 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:42 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:42 --> Final output sent to browser
INFO - 2023-03-13 08:43:42 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:42 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:42 --> Total execution time: 0.4308
DEBUG - 2023-03-13 08:43:42 --> Total execution time: 0.4993
INFO - 2023-03-13 08:43:55 --> Config Class Initialized
INFO - 2023-03-13 08:43:55 --> Config Class Initialized
INFO - 2023-03-13 08:43:55 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:55 --> URI Class Initialized
INFO - 2023-03-13 08:43:55 --> URI Class Initialized
INFO - 2023-03-13 08:43:55 --> Router Class Initialized
INFO - 2023-03-13 08:43:55 --> Router Class Initialized
INFO - 2023-03-13 08:43:55 --> Output Class Initialized
INFO - 2023-03-13 08:43:55 --> Output Class Initialized
INFO - 2023-03-13 08:43:55 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:55 --> Security Class Initialized
INFO - 2023-03-13 08:43:55 --> Input Class Initialized
DEBUG - 2023-03-13 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:55 --> Language Class Initialized
INFO - 2023-03-13 08:43:55 --> Input Class Initialized
INFO - 2023-03-13 08:43:55 --> Language Class Initialized
INFO - 2023-03-13 08:43:55 --> Loader Class Initialized
INFO - 2023-03-13 08:43:55 --> Loader Class Initialized
INFO - 2023-03-13 08:43:55 --> Controller Class Initialized
INFO - 2023-03-13 08:43:55 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:55 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:55 --> Final output sent to browser
INFO - 2023-03-13 08:43:55 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:55 --> Total execution time: 0.0958
DEBUG - 2023-03-13 08:43:55 --> Total execution time: 0.0955
INFO - 2023-03-13 08:43:55 --> Config Class Initialized
INFO - 2023-03-13 08:43:55 --> Config Class Initialized
INFO - 2023-03-13 08:43:55 --> Hooks Class Initialized
INFO - 2023-03-13 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 08:43:55 --> URI Class Initialized
INFO - 2023-03-13 08:43:55 --> URI Class Initialized
INFO - 2023-03-13 08:43:55 --> Router Class Initialized
INFO - 2023-03-13 08:43:55 --> Router Class Initialized
INFO - 2023-03-13 08:43:55 --> Output Class Initialized
INFO - 2023-03-13 08:43:55 --> Output Class Initialized
INFO - 2023-03-13 08:43:55 --> Security Class Initialized
INFO - 2023-03-13 08:43:55 --> Security Class Initialized
DEBUG - 2023-03-13 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:43:55 --> Input Class Initialized
INFO - 2023-03-13 08:43:55 --> Input Class Initialized
INFO - 2023-03-13 08:43:55 --> Language Class Initialized
INFO - 2023-03-13 08:43:55 --> Language Class Initialized
INFO - 2023-03-13 08:43:55 --> Loader Class Initialized
INFO - 2023-03-13 08:43:55 --> Loader Class Initialized
INFO - 2023-03-13 08:43:55 --> Controller Class Initialized
INFO - 2023-03-13 08:43:55 --> Controller Class Initialized
DEBUG - 2023-03-13 08:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:55 --> Database Driver Class Initialized
INFO - 2023-03-13 08:43:55 --> Model "Login_model" initialized
INFO - 2023-03-13 08:43:55 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:55 --> Total execution time: 0.0673
INFO - 2023-03-13 08:43:55 --> Final output sent to browser
DEBUG - 2023-03-13 08:43:55 --> Total execution time: 0.1001
INFO - 2023-03-13 08:48:18 --> Config Class Initialized
INFO - 2023-03-13 08:48:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:18 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:18 --> URI Class Initialized
INFO - 2023-03-13 08:48:18 --> Router Class Initialized
INFO - 2023-03-13 08:48:18 --> Output Class Initialized
INFO - 2023-03-13 08:48:18 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:18 --> Input Class Initialized
INFO - 2023-03-13 08:48:18 --> Language Class Initialized
INFO - 2023-03-13 08:48:18 --> Loader Class Initialized
INFO - 2023-03-13 08:48:18 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:18 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:48:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:19 --> Total execution time: 0.0179
INFO - 2023-03-13 08:48:19 --> Config Class Initialized
INFO - 2023-03-13 08:48:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:19 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:19 --> URI Class Initialized
INFO - 2023-03-13 08:48:19 --> Router Class Initialized
INFO - 2023-03-13 08:48:19 --> Output Class Initialized
INFO - 2023-03-13 08:48:19 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:19 --> Input Class Initialized
INFO - 2023-03-13 08:48:19 --> Language Class Initialized
INFO - 2023-03-13 08:48:19 --> Loader Class Initialized
INFO - 2023-03-13 08:48:19 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:19 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:48:19 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:19 --> Total execution time: 0.0533
INFO - 2023-03-13 08:48:24 --> Config Class Initialized
INFO - 2023-03-13 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:24 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:24 --> URI Class Initialized
INFO - 2023-03-13 08:48:24 --> Router Class Initialized
INFO - 2023-03-13 08:48:24 --> Output Class Initialized
INFO - 2023-03-13 08:48:24 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:24 --> Input Class Initialized
INFO - 2023-03-13 08:48:24 --> Language Class Initialized
INFO - 2023-03-13 08:48:24 --> Loader Class Initialized
INFO - 2023-03-13 08:48:24 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:24 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:48:24 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:24 --> Model "Login_model" initialized
INFO - 2023-03-13 08:48:24 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:24 --> Total execution time: 0.1582
INFO - 2023-03-13 08:48:24 --> Config Class Initialized
INFO - 2023-03-13 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:24 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:24 --> URI Class Initialized
INFO - 2023-03-13 08:48:24 --> Router Class Initialized
INFO - 2023-03-13 08:48:24 --> Output Class Initialized
INFO - 2023-03-13 08:48:24 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:24 --> Input Class Initialized
INFO - 2023-03-13 08:48:24 --> Language Class Initialized
INFO - 2023-03-13 08:48:24 --> Loader Class Initialized
INFO - 2023-03-13 08:48:24 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:24 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:48:24 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:24 --> Model "Login_model" initialized
INFO - 2023-03-13 08:48:24 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:24 --> Total execution time: 0.1165
INFO - 2023-03-13 08:48:27 --> Config Class Initialized
INFO - 2023-03-13 08:48:27 --> Config Class Initialized
INFO - 2023-03-13 08:48:27 --> Hooks Class Initialized
INFO - 2023-03-13 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:27 --> URI Class Initialized
INFO - 2023-03-13 08:48:27 --> URI Class Initialized
INFO - 2023-03-13 08:48:27 --> Router Class Initialized
INFO - 2023-03-13 08:48:27 --> Router Class Initialized
INFO - 2023-03-13 08:48:27 --> Output Class Initialized
INFO - 2023-03-13 08:48:27 --> Output Class Initialized
INFO - 2023-03-13 08:48:27 --> Security Class Initialized
INFO - 2023-03-13 08:48:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:27 --> Input Class Initialized
INFO - 2023-03-13 08:48:27 --> Input Class Initialized
INFO - 2023-03-13 08:48:27 --> Language Class Initialized
INFO - 2023-03-13 08:48:27 --> Language Class Initialized
INFO - 2023-03-13 08:48:27 --> Loader Class Initialized
INFO - 2023-03-13 08:48:27 --> Loader Class Initialized
INFO - 2023-03-13 08:48:27 --> Controller Class Initialized
INFO - 2023-03-13 08:48:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:27 --> Model "Login_model" initialized
INFO - 2023-03-13 08:48:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:27 --> Total execution time: 0.0355
INFO - 2023-03-13 08:48:27 --> Config Class Initialized
INFO - 2023-03-13 08:48:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:27 --> Total execution time: 0.0639
INFO - 2023-03-13 08:48:27 --> Config Class Initialized
INFO - 2023-03-13 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:27 --> URI Class Initialized
INFO - 2023-03-13 08:48:27 --> Router Class Initialized
INFO - 2023-03-13 08:48:27 --> Output Class Initialized
INFO - 2023-03-13 08:48:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:27 --> Input Class Initialized
INFO - 2023-03-13 08:48:27 --> Language Class Initialized
INFO - 2023-03-13 08:48:27 --> Loader Class Initialized
INFO - 2023-03-13 08:48:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:27 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:27 --> URI Class Initialized
INFO - 2023-03-13 08:48:27 --> Router Class Initialized
INFO - 2023-03-13 08:48:27 --> Output Class Initialized
INFO - 2023-03-13 08:48:27 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:27 --> Input Class Initialized
INFO - 2023-03-13 08:48:27 --> Language Class Initialized
INFO - 2023-03-13 08:48:27 --> Loader Class Initialized
INFO - 2023-03-13 08:48:27 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:27 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:27 --> Model "Login_model" initialized
INFO - 2023-03-13 08:48:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:27 --> Total execution time: 0.0633
INFO - 2023-03-13 08:48:27 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:27 --> Total execution time: 0.0544
INFO - 2023-03-13 08:48:29 --> Config Class Initialized
INFO - 2023-03-13 08:48:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:29 --> URI Class Initialized
INFO - 2023-03-13 08:48:29 --> Router Class Initialized
INFO - 2023-03-13 08:48:29 --> Output Class Initialized
INFO - 2023-03-13 08:48:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:29 --> Input Class Initialized
INFO - 2023-03-13 08:48:29 --> Language Class Initialized
INFO - 2023-03-13 08:48:29 --> Loader Class Initialized
INFO - 2023-03-13 08:48:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:29 --> Total execution time: 0.0043
INFO - 2023-03-13 08:48:29 --> Config Class Initialized
INFO - 2023-03-13 08:48:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:48:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:48:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:48:29 --> URI Class Initialized
INFO - 2023-03-13 08:48:29 --> Router Class Initialized
INFO - 2023-03-13 08:48:29 --> Output Class Initialized
INFO - 2023-03-13 08:48:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:48:29 --> Input Class Initialized
INFO - 2023-03-13 08:48:29 --> Language Class Initialized
INFO - 2023-03-13 08:48:29 --> Loader Class Initialized
INFO - 2023-03-13 08:48:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:48:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:48:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:48:29 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:48:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:48:29 --> Total execution time: 0.0541
INFO - 2023-03-13 08:49:21 --> Config Class Initialized
INFO - 2023-03-13 08:49:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:22 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:22 --> URI Class Initialized
INFO - 2023-03-13 08:49:22 --> Router Class Initialized
INFO - 2023-03-13 08:49:22 --> Output Class Initialized
INFO - 2023-03-13 08:49:22 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:22 --> Input Class Initialized
INFO - 2023-03-13 08:49:22 --> Language Class Initialized
INFO - 2023-03-13 08:49:22 --> Loader Class Initialized
INFO - 2023-03-13 08:49:22 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:22 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:49:22 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:22 --> Model "Login_model" initialized
INFO - 2023-03-13 08:49:22 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:22 --> Total execution time: 0.1799
INFO - 2023-03-13 08:49:22 --> Config Class Initialized
INFO - 2023-03-13 08:49:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:22 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:22 --> URI Class Initialized
INFO - 2023-03-13 08:49:22 --> Router Class Initialized
INFO - 2023-03-13 08:49:22 --> Output Class Initialized
INFO - 2023-03-13 08:49:22 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:22 --> Input Class Initialized
INFO - 2023-03-13 08:49:22 --> Language Class Initialized
INFO - 2023-03-13 08:49:22 --> Loader Class Initialized
INFO - 2023-03-13 08:49:22 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:22 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:49:22 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:22 --> Model "Login_model" initialized
INFO - 2023-03-13 08:49:22 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:22 --> Total execution time: 0.0512
INFO - 2023-03-13 08:49:29 --> Config Class Initialized
INFO - 2023-03-13 08:49:29 --> Config Class Initialized
INFO - 2023-03-13 08:49:29 --> Hooks Class Initialized
INFO - 2023-03-13 08:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 08:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:29 --> URI Class Initialized
INFO - 2023-03-13 08:49:29 --> URI Class Initialized
INFO - 2023-03-13 08:49:29 --> Router Class Initialized
INFO - 2023-03-13 08:49:29 --> Router Class Initialized
INFO - 2023-03-13 08:49:29 --> Output Class Initialized
INFO - 2023-03-13 08:49:29 --> Output Class Initialized
INFO - 2023-03-13 08:49:29 --> Security Class Initialized
INFO - 2023-03-13 08:49:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:29 --> Input Class Initialized
INFO - 2023-03-13 08:49:29 --> Input Class Initialized
INFO - 2023-03-13 08:49:29 --> Language Class Initialized
INFO - 2023-03-13 08:49:29 --> Language Class Initialized
INFO - 2023-03-13 08:49:29 --> Loader Class Initialized
INFO - 2023-03-13 08:49:29 --> Loader Class Initialized
INFO - 2023-03-13 08:49:29 --> Controller Class Initialized
INFO - 2023-03-13 08:49:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 08:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:29 --> Model "Login_model" initialized
INFO - 2023-03-13 08:49:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:29 --> Total execution time: 0.0319
INFO - 2023-03-13 08:49:29 --> Config Class Initialized
INFO - 2023-03-13 08:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:29 --> URI Class Initialized
INFO - 2023-03-13 08:49:29 --> Router Class Initialized
INFO - 2023-03-13 08:49:29 --> Output Class Initialized
INFO - 2023-03-13 08:49:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:29 --> Input Class Initialized
INFO - 2023-03-13 08:49:29 --> Language Class Initialized
INFO - 2023-03-13 08:49:29 --> Loader Class Initialized
INFO - 2023-03-13 08:49:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:29 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:29 --> Model "Login_model" initialized
INFO - 2023-03-13 08:49:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:29 --> Total execution time: 0.0258
INFO - 2023-03-13 08:49:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:29 --> Total execution time: 0.0659
INFO - 2023-03-13 08:49:29 --> Config Class Initialized
INFO - 2023-03-13 08:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:29 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:29 --> URI Class Initialized
INFO - 2023-03-13 08:49:29 --> Router Class Initialized
INFO - 2023-03-13 08:49:29 --> Output Class Initialized
INFO - 2023-03-13 08:49:29 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:29 --> Input Class Initialized
INFO - 2023-03-13 08:49:29 --> Language Class Initialized
INFO - 2023-03-13 08:49:29 --> Loader Class Initialized
INFO - 2023-03-13 08:49:29 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:29 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:29 --> Total execution time: 0.0626
INFO - 2023-03-13 08:49:30 --> Config Class Initialized
INFO - 2023-03-13 08:49:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:30 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:30 --> URI Class Initialized
INFO - 2023-03-13 08:49:30 --> Router Class Initialized
INFO - 2023-03-13 08:49:30 --> Output Class Initialized
INFO - 2023-03-13 08:49:30 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:30 --> Input Class Initialized
INFO - 2023-03-13 08:49:30 --> Language Class Initialized
INFO - 2023-03-13 08:49:30 --> Loader Class Initialized
INFO - 2023-03-13 08:49:30 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:30 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:30 --> Total execution time: 0.0044
INFO - 2023-03-13 08:49:30 --> Config Class Initialized
INFO - 2023-03-13 08:49:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 08:49:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 08:49:30 --> Utf8 Class Initialized
INFO - 2023-03-13 08:49:30 --> URI Class Initialized
INFO - 2023-03-13 08:49:30 --> Router Class Initialized
INFO - 2023-03-13 08:49:30 --> Output Class Initialized
INFO - 2023-03-13 08:49:30 --> Security Class Initialized
DEBUG - 2023-03-13 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 08:49:30 --> Input Class Initialized
INFO - 2023-03-13 08:49:30 --> Language Class Initialized
INFO - 2023-03-13 08:49:30 --> Loader Class Initialized
INFO - 2023-03-13 08:49:30 --> Controller Class Initialized
DEBUG - 2023-03-13 08:49:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 08:49:30 --> Database Driver Class Initialized
INFO - 2023-03-13 08:49:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 08:49:30 --> Final output sent to browser
DEBUG - 2023-03-13 08:49:30 --> Total execution time: 0.0169
INFO - 2023-03-13 09:13:24 --> Config Class Initialized
INFO - 2023-03-13 09:13:24 --> Config Class Initialized
INFO - 2023-03-13 09:13:24 --> Hooks Class Initialized
INFO - 2023-03-13 09:13:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:13:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:13:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:13:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:13:24 --> URI Class Initialized
INFO - 2023-03-13 09:13:24 --> URI Class Initialized
INFO - 2023-03-13 09:13:24 --> Router Class Initialized
INFO - 2023-03-13 09:13:24 --> Router Class Initialized
INFO - 2023-03-13 09:13:24 --> Output Class Initialized
INFO - 2023-03-13 09:13:25 --> Output Class Initialized
INFO - 2023-03-13 09:13:25 --> Security Class Initialized
INFO - 2023-03-13 09:13:25 --> Security Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:13:25 --> Input Class Initialized
INFO - 2023-03-13 09:13:25 --> Language Class Initialized
INFO - 2023-03-13 09:13:25 --> Input Class Initialized
INFO - 2023-03-13 09:13:25 --> Language Class Initialized
INFO - 2023-03-13 09:13:25 --> Loader Class Initialized
INFO - 2023-03-13 09:13:25 --> Controller Class Initialized
INFO - 2023-03-13 09:13:25 --> Loader Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:13:25 --> Controller Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:13:25 --> Database Driver Class Initialized
INFO - 2023-03-13 09:13:25 --> Database Driver Class Initialized
INFO - 2023-03-13 09:13:25 --> Model "Login_model" initialized
INFO - 2023-03-13 09:13:25 --> Final output sent to browser
DEBUG - 2023-03-13 09:13:25 --> Total execution time: 0.2696
INFO - 2023-03-13 09:13:25 --> Final output sent to browser
DEBUG - 2023-03-13 09:13:25 --> Total execution time: 0.3094
INFO - 2023-03-13 09:13:25 --> Config Class Initialized
INFO - 2023-03-13 09:13:25 --> Config Class Initialized
INFO - 2023-03-13 09:13:25 --> Hooks Class Initialized
INFO - 2023-03-13 09:13:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:13:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:13:25 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:13:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:13:25 --> Utf8 Class Initialized
INFO - 2023-03-13 09:13:25 --> URI Class Initialized
INFO - 2023-03-13 09:13:25 --> URI Class Initialized
INFO - 2023-03-13 09:13:25 --> Router Class Initialized
INFO - 2023-03-13 09:13:25 --> Router Class Initialized
INFO - 2023-03-13 09:13:25 --> Output Class Initialized
INFO - 2023-03-13 09:13:25 --> Output Class Initialized
INFO - 2023-03-13 09:13:25 --> Security Class Initialized
INFO - 2023-03-13 09:13:25 --> Security Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:13:25 --> Input Class Initialized
INFO - 2023-03-13 09:13:25 --> Input Class Initialized
INFO - 2023-03-13 09:13:25 --> Language Class Initialized
INFO - 2023-03-13 09:13:25 --> Language Class Initialized
INFO - 2023-03-13 09:13:25 --> Loader Class Initialized
INFO - 2023-03-13 09:13:25 --> Controller Class Initialized
INFO - 2023-03-13 09:13:25 --> Loader Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:13:25 --> Controller Class Initialized
DEBUG - 2023-03-13 09:13:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:13:25 --> Database Driver Class Initialized
INFO - 2023-03-13 09:13:25 --> Database Driver Class Initialized
INFO - 2023-03-13 09:13:25 --> Model "Login_model" initialized
INFO - 2023-03-13 09:13:25 --> Final output sent to browser
DEBUG - 2023-03-13 09:13:25 --> Total execution time: 0.0773
INFO - 2023-03-13 09:13:25 --> Final output sent to browser
DEBUG - 2023-03-13 09:13:25 --> Total execution time: 0.1081
INFO - 2023-03-13 09:14:09 --> Config Class Initialized
INFO - 2023-03-13 09:14:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:14:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:14:09 --> Utf8 Class Initialized
INFO - 2023-03-13 09:14:09 --> URI Class Initialized
INFO - 2023-03-13 09:14:09 --> Router Class Initialized
INFO - 2023-03-13 09:14:09 --> Output Class Initialized
INFO - 2023-03-13 09:14:09 --> Security Class Initialized
DEBUG - 2023-03-13 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:14:09 --> Input Class Initialized
INFO - 2023-03-13 09:14:09 --> Language Class Initialized
INFO - 2023-03-13 09:14:09 --> Loader Class Initialized
INFO - 2023-03-13 09:14:09 --> Controller Class Initialized
DEBUG - 2023-03-13 09:14:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:14:09 --> Final output sent to browser
DEBUG - 2023-03-13 09:14:09 --> Total execution time: 0.0033
INFO - 2023-03-13 09:14:09 --> Config Class Initialized
INFO - 2023-03-13 09:14:09 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:14:09 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:14:09 --> Utf8 Class Initialized
INFO - 2023-03-13 09:14:09 --> URI Class Initialized
INFO - 2023-03-13 09:14:09 --> Router Class Initialized
INFO - 2023-03-13 09:14:09 --> Output Class Initialized
INFO - 2023-03-13 09:14:09 --> Security Class Initialized
DEBUG - 2023-03-13 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:14:09 --> Input Class Initialized
INFO - 2023-03-13 09:14:09 --> Language Class Initialized
INFO - 2023-03-13 09:14:09 --> Loader Class Initialized
INFO - 2023-03-13 09:14:09 --> Controller Class Initialized
DEBUG - 2023-03-13 09:14:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:14:09 --> Database Driver Class Initialized
INFO - 2023-03-13 09:14:09 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:14:09 --> Final output sent to browser
DEBUG - 2023-03-13 09:14:09 --> Total execution time: 0.0570
INFO - 2023-03-13 09:15:43 --> Config Class Initialized
INFO - 2023-03-13 09:15:43 --> Config Class Initialized
INFO - 2023-03-13 09:15:43 --> Hooks Class Initialized
INFO - 2023-03-13 09:15:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:15:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:15:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:15:43 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:43 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:43 --> URI Class Initialized
INFO - 2023-03-13 09:15:43 --> URI Class Initialized
INFO - 2023-03-13 09:15:43 --> Router Class Initialized
INFO - 2023-03-13 09:15:43 --> Router Class Initialized
INFO - 2023-03-13 09:15:43 --> Output Class Initialized
INFO - 2023-03-13 09:15:43 --> Output Class Initialized
INFO - 2023-03-13 09:15:43 --> Security Class Initialized
INFO - 2023-03-13 09:15:43 --> Security Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:43 --> Input Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:43 --> Language Class Initialized
INFO - 2023-03-13 09:15:43 --> Input Class Initialized
INFO - 2023-03-13 09:15:43 --> Language Class Initialized
INFO - 2023-03-13 09:15:43 --> Loader Class Initialized
INFO - 2023-03-13 09:15:43 --> Loader Class Initialized
INFO - 2023-03-13 09:15:43 --> Controller Class Initialized
INFO - 2023-03-13 09:15:43 --> Controller Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:15:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:15:43 --> Database Driver Class Initialized
INFO - 2023-03-13 09:15:43 --> Database Driver Class Initialized
INFO - 2023-03-13 09:15:43 --> Model "Login_model" initialized
INFO - 2023-03-13 09:15:43 --> Final output sent to browser
DEBUG - 2023-03-13 09:15:43 --> Total execution time: 0.0381
INFO - 2023-03-13 09:15:43 --> Config Class Initialized
INFO - 2023-03-13 09:15:43 --> Final output sent to browser
INFO - 2023-03-13 09:15:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Total execution time: 0.1157
DEBUG - 2023-03-13 09:15:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:15:43 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:43 --> URI Class Initialized
INFO - 2023-03-13 09:15:43 --> Router Class Initialized
INFO - 2023-03-13 09:15:43 --> Output Class Initialized
INFO - 2023-03-13 09:15:43 --> Security Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:43 --> Input Class Initialized
INFO - 2023-03-13 09:15:43 --> Language Class Initialized
INFO - 2023-03-13 09:15:43 --> Loader Class Initialized
INFO - 2023-03-13 09:15:43 --> Controller Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:15:43 --> Database Driver Class Initialized
INFO - 2023-03-13 09:15:43 --> Config Class Initialized
INFO - 2023-03-13 09:15:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:15:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:15:43 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:43 --> URI Class Initialized
INFO - 2023-03-13 09:15:43 --> Router Class Initialized
INFO - 2023-03-13 09:15:43 --> Output Class Initialized
INFO - 2023-03-13 09:15:43 --> Security Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:43 --> Input Class Initialized
INFO - 2023-03-13 09:15:43 --> Language Class Initialized
INFO - 2023-03-13 09:15:43 --> Loader Class Initialized
INFO - 2023-03-13 09:15:43 --> Controller Class Initialized
DEBUG - 2023-03-13 09:15:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:15:43 --> Database Driver Class Initialized
INFO - 2023-03-13 09:15:43 --> Model "Login_model" initialized
INFO - 2023-03-13 09:15:43 --> Final output sent to browser
DEBUG - 2023-03-13 09:15:43 --> Total execution time: 0.1333
INFO - 2023-03-13 09:15:43 --> Final output sent to browser
DEBUG - 2023-03-13 09:15:43 --> Total execution time: 0.0936
INFO - 2023-03-13 09:15:46 --> Config Class Initialized
INFO - 2023-03-13 09:15:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:15:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:15:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:46 --> URI Class Initialized
INFO - 2023-03-13 09:15:46 --> Router Class Initialized
INFO - 2023-03-13 09:15:46 --> Output Class Initialized
INFO - 2023-03-13 09:15:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:46 --> Input Class Initialized
INFO - 2023-03-13 09:15:46 --> Language Class Initialized
INFO - 2023-03-13 09:15:46 --> Loader Class Initialized
INFO - 2023-03-13 09:15:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:15:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:15:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:15:46 --> Total execution time: 0.0060
INFO - 2023-03-13 09:15:46 --> Config Class Initialized
INFO - 2023-03-13 09:15:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:15:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:15:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:15:46 --> URI Class Initialized
INFO - 2023-03-13 09:15:46 --> Router Class Initialized
INFO - 2023-03-13 09:15:46 --> Output Class Initialized
INFO - 2023-03-13 09:15:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:15:46 --> Input Class Initialized
INFO - 2023-03-13 09:15:46 --> Language Class Initialized
INFO - 2023-03-13 09:15:46 --> Loader Class Initialized
INFO - 2023-03-13 09:15:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:15:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:15:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:15:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:15:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:15:46 --> Total execution time: 0.0547
INFO - 2023-03-13 09:18:19 --> Config Class Initialized
INFO - 2023-03-13 09:18:19 --> Hooks Class Initialized
INFO - 2023-03-13 09:18:19 --> Config Class Initialized
INFO - 2023-03-13 09:18:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:19 --> URI Class Initialized
INFO - 2023-03-13 09:18:19 --> Router Class Initialized
INFO - 2023-03-13 09:18:19 --> Output Class Initialized
INFO - 2023-03-13 09:18:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:19 --> Input Class Initialized
DEBUG - 2023-03-13 09:18:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:19 --> Language Class Initialized
INFO - 2023-03-13 09:18:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:19 --> URI Class Initialized
INFO - 2023-03-13 09:18:19 --> Loader Class Initialized
INFO - 2023-03-13 09:18:19 --> Router Class Initialized
INFO - 2023-03-13 09:18:19 --> Controller Class Initialized
INFO - 2023-03-13 09:18:19 --> Output Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:19 --> Input Class Initialized
INFO - 2023-03-13 09:18:19 --> Language Class Initialized
INFO - 2023-03-13 09:18:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:19 --> Loader Class Initialized
INFO - 2023-03-13 09:18:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:19 --> Model "Login_model" initialized
INFO - 2023-03-13 09:18:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:19 --> Total execution time: 0.2911
INFO - 2023-03-13 09:18:19 --> Config Class Initialized
INFO - 2023-03-13 09:18:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:19 --> URI Class Initialized
INFO - 2023-03-13 09:18:19 --> Router Class Initialized
INFO - 2023-03-13 09:18:19 --> Output Class Initialized
INFO - 2023-03-13 09:18:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:19 --> Input Class Initialized
INFO - 2023-03-13 09:18:19 --> Language Class Initialized
INFO - 2023-03-13 09:18:19 --> Loader Class Initialized
INFO - 2023-03-13 09:18:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:19 --> Total execution time: 0.3086
INFO - 2023-03-13 09:18:19 --> Config Class Initialized
INFO - 2023-03-13 09:18:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:19 --> URI Class Initialized
INFO - 2023-03-13 09:18:19 --> Router Class Initialized
INFO - 2023-03-13 09:18:19 --> Output Class Initialized
INFO - 2023-03-13 09:18:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:19 --> Input Class Initialized
INFO - 2023-03-13 09:18:19 --> Language Class Initialized
INFO - 2023-03-13 09:18:19 --> Loader Class Initialized
INFO - 2023-03-13 09:18:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:19 --> Model "Login_model" initialized
INFO - 2023-03-13 09:18:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:19 --> Total execution time: 0.0584
INFO - 2023-03-13 09:18:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:19 --> Total execution time: 0.0484
INFO - 2023-03-13 09:18:39 --> Config Class Initialized
INFO - 2023-03-13 09:18:39 --> Config Class Initialized
INFO - 2023-03-13 09:18:39 --> Hooks Class Initialized
INFO - 2023-03-13 09:18:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:18:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:39 --> URI Class Initialized
INFO - 2023-03-13 09:18:39 --> URI Class Initialized
INFO - 2023-03-13 09:18:39 --> Router Class Initialized
INFO - 2023-03-13 09:18:39 --> Router Class Initialized
INFO - 2023-03-13 09:18:39 --> Output Class Initialized
INFO - 2023-03-13 09:18:39 --> Output Class Initialized
INFO - 2023-03-13 09:18:39 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:39 --> Security Class Initialized
INFO - 2023-03-13 09:18:39 --> Input Class Initialized
INFO - 2023-03-13 09:18:39 --> Language Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:39 --> Input Class Initialized
INFO - 2023-03-13 09:18:39 --> Loader Class Initialized
INFO - 2023-03-13 09:18:39 --> Language Class Initialized
INFO - 2023-03-13 09:18:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:39 --> Loader Class Initialized
INFO - 2023-03-13 09:18:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:39 --> Total execution time: 0.0725
INFO - 2023-03-13 09:18:39 --> Config Class Initialized
INFO - 2023-03-13 09:18:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:39 --> URI Class Initialized
INFO - 2023-03-13 09:18:39 --> Router Class Initialized
INFO - 2023-03-13 09:18:39 --> Output Class Initialized
INFO - 2023-03-13 09:18:39 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:39 --> Input Class Initialized
INFO - 2023-03-13 09:18:39 --> Language Class Initialized
INFO - 2023-03-13 09:18:39 --> Loader Class Initialized
INFO - 2023-03-13 09:18:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:18:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:39 --> Total execution time: 0.1359
INFO - 2023-03-13 09:18:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:39 --> Total execution time: 0.0724
INFO - 2023-03-13 09:18:39 --> Config Class Initialized
INFO - 2023-03-13 09:18:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:18:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:18:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:18:39 --> URI Class Initialized
INFO - 2023-03-13 09:18:39 --> Router Class Initialized
INFO - 2023-03-13 09:18:39 --> Output Class Initialized
INFO - 2023-03-13 09:18:39 --> Security Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:18:39 --> Input Class Initialized
INFO - 2023-03-13 09:18:39 --> Language Class Initialized
INFO - 2023-03-13 09:18:39 --> Loader Class Initialized
INFO - 2023-03-13 09:18:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:18:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:18:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:18:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:18:39 --> Total execution time: 0.0972
INFO - 2023-03-13 09:21:16 --> Config Class Initialized
INFO - 2023-03-13 09:21:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:21:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:21:16 --> Utf8 Class Initialized
INFO - 2023-03-13 09:21:16 --> URI Class Initialized
INFO - 2023-03-13 09:21:16 --> Router Class Initialized
INFO - 2023-03-13 09:21:16 --> Output Class Initialized
INFO - 2023-03-13 09:21:16 --> Security Class Initialized
DEBUG - 2023-03-13 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:21:16 --> Input Class Initialized
INFO - 2023-03-13 09:21:16 --> Language Class Initialized
INFO - 2023-03-13 09:21:16 --> Loader Class Initialized
INFO - 2023-03-13 09:21:16 --> Controller Class Initialized
DEBUG - 2023-03-13 09:21:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:21:16 --> Final output sent to browser
DEBUG - 2023-03-13 09:21:16 --> Total execution time: 0.0040
INFO - 2023-03-13 09:21:16 --> Config Class Initialized
INFO - 2023-03-13 09:21:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:21:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:21:16 --> Utf8 Class Initialized
INFO - 2023-03-13 09:21:16 --> URI Class Initialized
INFO - 2023-03-13 09:21:16 --> Router Class Initialized
INFO - 2023-03-13 09:21:16 --> Output Class Initialized
INFO - 2023-03-13 09:21:16 --> Security Class Initialized
DEBUG - 2023-03-13 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:21:16 --> Input Class Initialized
INFO - 2023-03-13 09:21:16 --> Language Class Initialized
INFO - 2023-03-13 09:21:16 --> Loader Class Initialized
INFO - 2023-03-13 09:21:16 --> Controller Class Initialized
DEBUG - 2023-03-13 09:21:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:21:16 --> Database Driver Class Initialized
INFO - 2023-03-13 09:21:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:21:16 --> Final output sent to browser
DEBUG - 2023-03-13 09:21:16 --> Total execution time: 0.0122
INFO - 2023-03-13 09:23:23 --> Config Class Initialized
INFO - 2023-03-13 09:23:23 --> Config Class Initialized
INFO - 2023-03-13 09:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:23 --> URI Class Initialized
INFO - 2023-03-13 09:23:23 --> Router Class Initialized
INFO - 2023-03-13 09:23:23 --> Output Class Initialized
INFO - 2023-03-13 09:23:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:23 --> Input Class Initialized
INFO - 2023-03-13 09:23:23 --> Language Class Initialized
INFO - 2023-03-13 09:23:23 --> Hooks Class Initialized
INFO - 2023-03-13 09:23:23 --> Loader Class Initialized
DEBUG - 2023-03-13 09:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:23 --> Controller Class Initialized
INFO - 2023-03-13 09:23:23 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:23 --> URI Class Initialized
INFO - 2023-03-13 09:23:23 --> Router Class Initialized
INFO - 2023-03-13 09:23:23 --> Output Class Initialized
INFO - 2023-03-13 09:23:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:23 --> Input Class Initialized
INFO - 2023-03-13 09:23:23 --> Language Class Initialized
INFO - 2023-03-13 09:23:23 --> Loader Class Initialized
INFO - 2023-03-13 09:23:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:23:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:23 --> Total execution time: 0.1262
INFO - 2023-03-13 09:23:23 --> Config Class Initialized
INFO - 2023-03-13 09:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:23 --> URI Class Initialized
INFO - 2023-03-13 09:23:23 --> Router Class Initialized
INFO - 2023-03-13 09:23:23 --> Output Class Initialized
INFO - 2023-03-13 09:23:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:23 --> Input Class Initialized
INFO - 2023-03-13 09:23:23 --> Language Class Initialized
INFO - 2023-03-13 09:23:23 --> Loader Class Initialized
INFO - 2023-03-13 09:23:23 --> Controller Class Initialized
INFO - 2023-03-13 09:23:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:23:23 --> Total execution time: 0.2020
INFO - 2023-03-13 09:23:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:23 --> Config Class Initialized
INFO - 2023-03-13 09:23:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:23 --> URI Class Initialized
INFO - 2023-03-13 09:23:23 --> Router Class Initialized
INFO - 2023-03-13 09:23:23 --> Output Class Initialized
INFO - 2023-03-13 09:23:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:23 --> Input Class Initialized
INFO - 2023-03-13 09:23:23 --> Language Class Initialized
INFO - 2023-03-13 09:23:23 --> Loader Class Initialized
INFO - 2023-03-13 09:23:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:23:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:23 --> Total execution time: 0.0696
INFO - 2023-03-13 09:23:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:23 --> Total execution time: 0.0693
INFO - 2023-03-13 09:23:46 --> Config Class Initialized
INFO - 2023-03-13 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:46 --> URI Class Initialized
INFO - 2023-03-13 09:23:46 --> Config Class Initialized
INFO - 2023-03-13 09:23:46 --> Router Class Initialized
INFO - 2023-03-13 09:23:46 --> Output Class Initialized
INFO - 2023-03-13 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:46 --> Input Class Initialized
INFO - 2023-03-13 09:23:46 --> Language Class Initialized
INFO - 2023-03-13 09:23:46 --> Loader Class Initialized
INFO - 2023-03-13 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:46 --> URI Class Initialized
INFO - 2023-03-13 09:23:46 --> Router Class Initialized
INFO - 2023-03-13 09:23:46 --> Output Class Initialized
INFO - 2023-03-13 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:46 --> Input Class Initialized
INFO - 2023-03-13 09:23:46 --> Language Class Initialized
INFO - 2023-03-13 09:23:46 --> Loader Class Initialized
INFO - 2023-03-13 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:46 --> Total execution time: 0.2767
INFO - 2023-03-13 09:23:46 --> Config Class Initialized
INFO - 2023-03-13 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:46 --> URI Class Initialized
INFO - 2023-03-13 09:23:46 --> Router Class Initialized
INFO - 2023-03-13 09:23:46 --> Output Class Initialized
INFO - 2023-03-13 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:46 --> Input Class Initialized
INFO - 2023-03-13 09:23:46 --> Language Class Initialized
INFO - 2023-03-13 09:23:46 --> Loader Class Initialized
INFO - 2023-03-13 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:46 --> Model "Login_model" initialized
INFO - 2023-03-13 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:46 --> Total execution time: 0.2921
INFO - 2023-03-13 09:23:46 --> Config Class Initialized
INFO - 2023-03-13 09:23:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:46 --> URI Class Initialized
INFO - 2023-03-13 09:23:46 --> Router Class Initialized
INFO - 2023-03-13 09:23:46 --> Output Class Initialized
INFO - 2023-03-13 09:23:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:46 --> Input Class Initialized
INFO - 2023-03-13 09:23:46 --> Language Class Initialized
INFO - 2023-03-13 09:23:46 --> Loader Class Initialized
INFO - 2023-03-13 09:23:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:46 --> Model "Login_model" initialized
INFO - 2023-03-13 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:46 --> Total execution time: 0.0292
INFO - 2023-03-13 09:23:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:46 --> Total execution time: 0.0734
INFO - 2023-03-13 09:23:48 --> Config Class Initialized
INFO - 2023-03-13 09:23:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:48 --> URI Class Initialized
INFO - 2023-03-13 09:23:48 --> Router Class Initialized
INFO - 2023-03-13 09:23:48 --> Output Class Initialized
INFO - 2023-03-13 09:23:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:48 --> Input Class Initialized
INFO - 2023-03-13 09:23:48 --> Language Class Initialized
INFO - 2023-03-13 09:23:48 --> Loader Class Initialized
INFO - 2023-03-13 09:23:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:48 --> Total execution time: 0.0370
INFO - 2023-03-13 09:23:48 --> Config Class Initialized
INFO - 2023-03-13 09:23:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:23:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:23:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:23:49 --> URI Class Initialized
INFO - 2023-03-13 09:23:49 --> Router Class Initialized
INFO - 2023-03-13 09:23:49 --> Output Class Initialized
INFO - 2023-03-13 09:23:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:23:49 --> Input Class Initialized
INFO - 2023-03-13 09:23:49 --> Language Class Initialized
INFO - 2023-03-13 09:23:49 --> Loader Class Initialized
INFO - 2023-03-13 09:23:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:23:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:23:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:23:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:23:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:23:49 --> Total execution time: 0.0362
INFO - 2023-03-13 09:24:56 --> Config Class Initialized
INFO - 2023-03-13 09:24:56 --> Config Class Initialized
INFO - 2023-03-13 09:24:56 --> Hooks Class Initialized
INFO - 2023-03-13 09:24:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:24:56 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:24:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:24:56 --> Utf8 Class Initialized
INFO - 2023-03-13 09:24:56 --> Utf8 Class Initialized
INFO - 2023-03-13 09:24:56 --> URI Class Initialized
INFO - 2023-03-13 09:24:56 --> URI Class Initialized
INFO - 2023-03-13 09:24:56 --> Router Class Initialized
INFO - 2023-03-13 09:24:56 --> Router Class Initialized
INFO - 2023-03-13 09:24:56 --> Output Class Initialized
INFO - 2023-03-13 09:24:56 --> Output Class Initialized
INFO - 2023-03-13 09:24:56 --> Security Class Initialized
INFO - 2023-03-13 09:24:56 --> Security Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:24:56 --> Input Class Initialized
INFO - 2023-03-13 09:24:56 --> Input Class Initialized
INFO - 2023-03-13 09:24:56 --> Language Class Initialized
INFO - 2023-03-13 09:24:56 --> Language Class Initialized
INFO - 2023-03-13 09:24:56 --> Loader Class Initialized
INFO - 2023-03-13 09:24:56 --> Loader Class Initialized
INFO - 2023-03-13 09:24:56 --> Controller Class Initialized
INFO - 2023-03-13 09:24:56 --> Controller Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:24:56 --> Database Driver Class Initialized
INFO - 2023-03-13 09:24:56 --> Database Driver Class Initialized
INFO - 2023-03-13 09:24:56 --> Final output sent to browser
DEBUG - 2023-03-13 09:24:56 --> Total execution time: 0.1248
INFO - 2023-03-13 09:24:56 --> Config Class Initialized
INFO - 2023-03-13 09:24:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:24:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:24:56 --> Utf8 Class Initialized
INFO - 2023-03-13 09:24:56 --> URI Class Initialized
INFO - 2023-03-13 09:24:56 --> Router Class Initialized
INFO - 2023-03-13 09:24:56 --> Model "Login_model" initialized
INFO - 2023-03-13 09:24:56 --> Output Class Initialized
INFO - 2023-03-13 09:24:56 --> Security Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:24:56 --> Input Class Initialized
INFO - 2023-03-13 09:24:56 --> Language Class Initialized
INFO - 2023-03-13 09:24:56 --> Loader Class Initialized
INFO - 2023-03-13 09:24:56 --> Controller Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:24:56 --> Final output sent to browser
DEBUG - 2023-03-13 09:24:56 --> Total execution time: 0.1459
INFO - 2023-03-13 09:24:56 --> Config Class Initialized
INFO - 2023-03-13 09:24:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:24:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:24:56 --> Final output sent to browser
INFO - 2023-03-13 09:24:56 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Total execution time: 0.1319
INFO - 2023-03-13 09:24:56 --> URI Class Initialized
INFO - 2023-03-13 09:24:56 --> Router Class Initialized
INFO - 2023-03-13 09:24:56 --> Output Class Initialized
INFO - 2023-03-13 09:24:56 --> Security Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:24:56 --> Input Class Initialized
INFO - 2023-03-13 09:24:56 --> Language Class Initialized
INFO - 2023-03-13 09:24:56 --> Loader Class Initialized
INFO - 2023-03-13 09:24:56 --> Controller Class Initialized
DEBUG - 2023-03-13 09:24:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:24:56 --> Database Driver Class Initialized
INFO - 2023-03-13 09:24:56 --> Database Driver Class Initialized
INFO - 2023-03-13 09:24:56 --> Model "Login_model" initialized
INFO - 2023-03-13 09:24:56 --> Final output sent to browser
DEBUG - 2023-03-13 09:24:56 --> Total execution time: 0.1651
INFO - 2023-03-13 09:25:00 --> Config Class Initialized
INFO - 2023-03-13 09:25:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:00 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:00 --> URI Class Initialized
INFO - 2023-03-13 09:25:00 --> Router Class Initialized
INFO - 2023-03-13 09:25:00 --> Output Class Initialized
INFO - 2023-03-13 09:25:00 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:00 --> Input Class Initialized
INFO - 2023-03-13 09:25:00 --> Language Class Initialized
INFO - 2023-03-13 09:25:00 --> Loader Class Initialized
INFO - 2023-03-13 09:25:00 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:00 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:00 --> Total execution time: 0.0061
INFO - 2023-03-13 09:25:00 --> Config Class Initialized
INFO - 2023-03-13 09:25:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:00 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:00 --> URI Class Initialized
INFO - 2023-03-13 09:25:00 --> Router Class Initialized
INFO - 2023-03-13 09:25:00 --> Output Class Initialized
INFO - 2023-03-13 09:25:00 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:00 --> Input Class Initialized
INFO - 2023-03-13 09:25:00 --> Language Class Initialized
INFO - 2023-03-13 09:25:00 --> Loader Class Initialized
INFO - 2023-03-13 09:25:00 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:00 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:00 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:25:00 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:00 --> Total execution time: 0.0516
INFO - 2023-03-13 09:25:18 --> Config Class Initialized
INFO - 2023-03-13 09:25:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:18 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:18 --> URI Class Initialized
INFO - 2023-03-13 09:25:18 --> Router Class Initialized
INFO - 2023-03-13 09:25:18 --> Output Class Initialized
INFO - 2023-03-13 09:25:18 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:18 --> Input Class Initialized
INFO - 2023-03-13 09:25:18 --> Language Class Initialized
INFO - 2023-03-13 09:25:18 --> Loader Class Initialized
INFO - 2023-03-13 09:25:18 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:18 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:25:18 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:18 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:18 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:18 --> Total execution time: 0.1325
INFO - 2023-03-13 09:25:18 --> Config Class Initialized
INFO - 2023-03-13 09:25:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:18 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:18 --> URI Class Initialized
INFO - 2023-03-13 09:25:18 --> Router Class Initialized
INFO - 2023-03-13 09:25:18 --> Output Class Initialized
INFO - 2023-03-13 09:25:18 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:18 --> Input Class Initialized
INFO - 2023-03-13 09:25:18 --> Language Class Initialized
INFO - 2023-03-13 09:25:18 --> Loader Class Initialized
INFO - 2023-03-13 09:25:18 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:18 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:25:18 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:18 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:18 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:18 --> Total execution time: 0.1241
INFO - 2023-03-13 09:25:22 --> Config Class Initialized
INFO - 2023-03-13 09:25:22 --> Config Class Initialized
INFO - 2023-03-13 09:25:22 --> Hooks Class Initialized
INFO - 2023-03-13 09:25:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:25:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:22 --> URI Class Initialized
INFO - 2023-03-13 09:25:22 --> URI Class Initialized
INFO - 2023-03-13 09:25:22 --> Router Class Initialized
INFO - 2023-03-13 09:25:22 --> Router Class Initialized
INFO - 2023-03-13 09:25:22 --> Output Class Initialized
INFO - 2023-03-13 09:25:22 --> Security Class Initialized
INFO - 2023-03-13 09:25:22 --> Output Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:22 --> Security Class Initialized
INFO - 2023-03-13 09:25:22 --> Input Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:22 --> Language Class Initialized
INFO - 2023-03-13 09:25:22 --> Input Class Initialized
INFO - 2023-03-13 09:25:22 --> Language Class Initialized
INFO - 2023-03-13 09:25:22 --> Loader Class Initialized
INFO - 2023-03-13 09:25:22 --> Loader Class Initialized
INFO - 2023-03-13 09:25:22 --> Controller Class Initialized
INFO - 2023-03-13 09:25:22 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:25:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:22 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:22 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:22 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:22 --> Total execution time: 0.0424
INFO - 2023-03-13 09:25:22 --> Config Class Initialized
INFO - 2023-03-13 09:25:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:22 --> URI Class Initialized
INFO - 2023-03-13 09:25:22 --> Router Class Initialized
INFO - 2023-03-13 09:25:22 --> Output Class Initialized
INFO - 2023-03-13 09:25:22 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:22 --> Input Class Initialized
INFO - 2023-03-13 09:25:22 --> Language Class Initialized
INFO - 2023-03-13 09:25:22 --> Loader Class Initialized
INFO - 2023-03-13 09:25:22 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:22 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:22 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:22 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:22 --> Total execution time: 0.0264
INFO - 2023-03-13 09:25:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:22 --> Total execution time: 0.0767
INFO - 2023-03-13 09:25:22 --> Config Class Initialized
INFO - 2023-03-13 09:25:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:22 --> URI Class Initialized
INFO - 2023-03-13 09:25:22 --> Router Class Initialized
INFO - 2023-03-13 09:25:22 --> Output Class Initialized
INFO - 2023-03-13 09:25:22 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:22 --> Input Class Initialized
INFO - 2023-03-13 09:25:22 --> Language Class Initialized
INFO - 2023-03-13 09:25:22 --> Loader Class Initialized
INFO - 2023-03-13 09:25:22 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:22 --> Total execution time: 0.0676
INFO - 2023-03-13 09:25:49 --> Config Class Initialized
INFO - 2023-03-13 09:25:49 --> Config Class Initialized
INFO - 2023-03-13 09:25:49 --> Hooks Class Initialized
INFO - 2023-03-13 09:25:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:25:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:49 --> URI Class Initialized
INFO - 2023-03-13 09:25:49 --> URI Class Initialized
INFO - 2023-03-13 09:25:49 --> Router Class Initialized
INFO - 2023-03-13 09:25:49 --> Router Class Initialized
INFO - 2023-03-13 09:25:49 --> Output Class Initialized
INFO - 2023-03-13 09:25:49 --> Output Class Initialized
INFO - 2023-03-13 09:25:49 --> Security Class Initialized
INFO - 2023-03-13 09:25:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:49 --> Input Class Initialized
INFO - 2023-03-13 09:25:49 --> Input Class Initialized
INFO - 2023-03-13 09:25:49 --> Language Class Initialized
INFO - 2023-03-13 09:25:49 --> Language Class Initialized
INFO - 2023-03-13 09:25:49 --> Loader Class Initialized
INFO - 2023-03-13 09:25:49 --> Loader Class Initialized
INFO - 2023-03-13 09:25:49 --> Controller Class Initialized
INFO - 2023-03-13 09:25:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:25:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:49 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:49 --> Total execution time: 0.0331
INFO - 2023-03-13 09:25:49 --> Config Class Initialized
INFO - 2023-03-13 09:25:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:49 --> URI Class Initialized
INFO - 2023-03-13 09:25:49 --> Router Class Initialized
INFO - 2023-03-13 09:25:49 --> Output Class Initialized
INFO - 2023-03-13 09:25:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:49 --> Input Class Initialized
INFO - 2023-03-13 09:25:49 --> Language Class Initialized
INFO - 2023-03-13 09:25:49 --> Loader Class Initialized
INFO - 2023-03-13 09:25:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:25:49 --> Model "Login_model" initialized
INFO - 2023-03-13 09:25:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:49 --> Total execution time: 0.0301
INFO - 2023-03-13 09:25:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:49 --> Total execution time: 0.0723
INFO - 2023-03-13 09:25:49 --> Config Class Initialized
INFO - 2023-03-13 09:25:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:25:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:25:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:25:49 --> URI Class Initialized
INFO - 2023-03-13 09:25:49 --> Router Class Initialized
INFO - 2023-03-13 09:25:49 --> Output Class Initialized
INFO - 2023-03-13 09:25:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:25:49 --> Input Class Initialized
INFO - 2023-03-13 09:25:49 --> Language Class Initialized
INFO - 2023-03-13 09:25:49 --> Loader Class Initialized
INFO - 2023-03-13 09:25:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:25:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:25:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:25:49 --> Total execution time: 0.0608
INFO - 2023-03-13 09:26:48 --> Config Class Initialized
INFO - 2023-03-13 09:26:48 --> Config Class Initialized
INFO - 2023-03-13 09:26:48 --> Hooks Class Initialized
INFO - 2023-03-13 09:26:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:26:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:26:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:26:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:26:48 --> URI Class Initialized
INFO - 2023-03-13 09:26:48 --> URI Class Initialized
INFO - 2023-03-13 09:26:48 --> Router Class Initialized
INFO - 2023-03-13 09:26:48 --> Router Class Initialized
INFO - 2023-03-13 09:26:48 --> Output Class Initialized
INFO - 2023-03-13 09:26:48 --> Security Class Initialized
INFO - 2023-03-13 09:26:48 --> Output Class Initialized
INFO - 2023-03-13 09:26:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:26:48 --> Input Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:26:48 --> Language Class Initialized
INFO - 2023-03-13 09:26:48 --> Input Class Initialized
INFO - 2023-03-13 09:26:48 --> Loader Class Initialized
INFO - 2023-03-13 09:26:48 --> Language Class Initialized
INFO - 2023-03-13 09:26:48 --> Controller Class Initialized
INFO - 2023-03-13 09:26:48 --> Loader Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:26:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:26:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:26:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:26:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:26:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:26:48 --> Total execution time: 0.1362
INFO - 2023-03-13 09:26:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:26:48 --> Total execution time: 0.1463
INFO - 2023-03-13 09:26:48 --> Config Class Initialized
INFO - 2023-03-13 09:26:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:26:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:26:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:26:48 --> URI Class Initialized
INFO - 2023-03-13 09:26:48 --> Router Class Initialized
INFO - 2023-03-13 09:26:48 --> Output Class Initialized
INFO - 2023-03-13 09:26:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:26:48 --> Config Class Initialized
INFO - 2023-03-13 09:26:48 --> Hooks Class Initialized
INFO - 2023-03-13 09:26:48 --> Input Class Initialized
INFO - 2023-03-13 09:26:48 --> Language Class Initialized
INFO - 2023-03-13 09:26:48 --> Loader Class Initialized
INFO - 2023-03-13 09:26:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:26:48 --> Database Driver Class Initialized
DEBUG - 2023-03-13 09:26:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:26:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:26:48 --> URI Class Initialized
INFO - 2023-03-13 09:26:48 --> Router Class Initialized
INFO - 2023-03-13 09:26:48 --> Output Class Initialized
INFO - 2023-03-13 09:26:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:26:48 --> Input Class Initialized
INFO - 2023-03-13 09:26:48 --> Language Class Initialized
INFO - 2023-03-13 09:26:48 --> Loader Class Initialized
INFO - 2023-03-13 09:26:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:26:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:26:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:26:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:26:48 --> Total execution time: 0.0361
INFO - 2023-03-13 09:26:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:26:48 --> Total execution time: 0.0733
INFO - 2023-03-13 09:27:01 --> Config Class Initialized
INFO - 2023-03-13 09:27:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:27:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:27:01 --> Utf8 Class Initialized
INFO - 2023-03-13 09:27:01 --> URI Class Initialized
INFO - 2023-03-13 09:27:01 --> Router Class Initialized
INFO - 2023-03-13 09:27:01 --> Output Class Initialized
INFO - 2023-03-13 09:27:01 --> Security Class Initialized
DEBUG - 2023-03-13 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:27:01 --> Input Class Initialized
INFO - 2023-03-13 09:27:01 --> Language Class Initialized
INFO - 2023-03-13 09:27:01 --> Loader Class Initialized
INFO - 2023-03-13 09:27:01 --> Controller Class Initialized
DEBUG - 2023-03-13 09:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:27:01 --> Final output sent to browser
DEBUG - 2023-03-13 09:27:01 --> Total execution time: 0.0051
INFO - 2023-03-13 09:27:01 --> Config Class Initialized
INFO - 2023-03-13 09:27:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:27:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:27:01 --> Utf8 Class Initialized
INFO - 2023-03-13 09:27:01 --> URI Class Initialized
INFO - 2023-03-13 09:27:01 --> Router Class Initialized
INFO - 2023-03-13 09:27:01 --> Output Class Initialized
INFO - 2023-03-13 09:27:01 --> Security Class Initialized
DEBUG - 2023-03-13 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:27:01 --> Input Class Initialized
INFO - 2023-03-13 09:27:01 --> Language Class Initialized
INFO - 2023-03-13 09:27:01 --> Loader Class Initialized
INFO - 2023-03-13 09:27:01 --> Controller Class Initialized
DEBUG - 2023-03-13 09:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:27:01 --> Database Driver Class Initialized
INFO - 2023-03-13 09:27:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:27:01 --> Final output sent to browser
DEBUG - 2023-03-13 09:27:01 --> Total execution time: 0.0191
INFO - 2023-03-13 09:28:39 --> Config Class Initialized
INFO - 2023-03-13 09:28:39 --> Config Class Initialized
INFO - 2023-03-13 09:28:39 --> Hooks Class Initialized
INFO - 2023-03-13 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:39 --> URI Class Initialized
INFO - 2023-03-13 09:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:39 --> Router Class Initialized
INFO - 2023-03-13 09:28:39 --> URI Class Initialized
INFO - 2023-03-13 09:28:39 --> Router Class Initialized
INFO - 2023-03-13 09:28:39 --> Output Class Initialized
INFO - 2023-03-13 09:28:39 --> Security Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:39 --> Input Class Initialized
INFO - 2023-03-13 09:28:39 --> Language Class Initialized
INFO - 2023-03-13 09:28:39 --> Output Class Initialized
INFO - 2023-03-13 09:28:39 --> Loader Class Initialized
INFO - 2023-03-13 09:28:39 --> Security Class Initialized
INFO - 2023-03-13 09:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:39 --> Input Class Initialized
INFO - 2023-03-13 09:28:39 --> Language Class Initialized
INFO - 2023-03-13 09:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:39 --> Loader Class Initialized
INFO - 2023-03-13 09:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:39 --> Total execution time: 0.0292
INFO - 2023-03-13 09:28:39 --> Config Class Initialized
INFO - 2023-03-13 09:28:39 --> Final output sent to browser
INFO - 2023-03-13 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Total execution time: 0.0566
DEBUG - 2023-03-13 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:39 --> Config Class Initialized
INFO - 2023-03-13 09:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:39 --> Hooks Class Initialized
INFO - 2023-03-13 09:28:39 --> URI Class Initialized
DEBUG - 2023-03-13 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:39 --> Router Class Initialized
INFO - 2023-03-13 09:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:39 --> Output Class Initialized
INFO - 2023-03-13 09:28:39 --> URI Class Initialized
INFO - 2023-03-13 09:28:39 --> Security Class Initialized
INFO - 2023-03-13 09:28:39 --> Router Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:39 --> Output Class Initialized
INFO - 2023-03-13 09:28:39 --> Input Class Initialized
INFO - 2023-03-13 09:28:39 --> Security Class Initialized
INFO - 2023-03-13 09:28:39 --> Language Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:39 --> Input Class Initialized
INFO - 2023-03-13 09:28:39 --> Loader Class Initialized
INFO - 2023-03-13 09:28:39 --> Language Class Initialized
INFO - 2023-03-13 09:28:39 --> Controller Class Initialized
INFO - 2023-03-13 09:28:39 --> Loader Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:39 --> Total execution time: 0.1107
INFO - 2023-03-13 09:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:39 --> Total execution time: 0.0983
INFO - 2023-03-13 09:28:48 --> Config Class Initialized
INFO - 2023-03-13 09:28:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:48 --> URI Class Initialized
INFO - 2023-03-13 09:28:48 --> Router Class Initialized
INFO - 2023-03-13 09:28:48 --> Output Class Initialized
INFO - 2023-03-13 09:28:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:48 --> Input Class Initialized
INFO - 2023-03-13 09:28:48 --> Language Class Initialized
INFO - 2023-03-13 09:28:48 --> Loader Class Initialized
INFO - 2023-03-13 09:28:48 --> Config Class Initialized
INFO - 2023-03-13 09:28:48 --> Controller Class Initialized
INFO - 2023-03-13 09:28:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:28:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:48 --> URI Class Initialized
INFO - 2023-03-13 09:28:48 --> Router Class Initialized
INFO - 2023-03-13 09:28:48 --> Output Class Initialized
INFO - 2023-03-13 09:28:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:48 --> Input Class Initialized
INFO - 2023-03-13 09:28:48 --> Language Class Initialized
INFO - 2023-03-13 09:28:48 --> Loader Class Initialized
INFO - 2023-03-13 09:28:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:28:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:48 --> Total execution time: 0.1145
INFO - 2023-03-13 09:28:48 --> Config Class Initialized
INFO - 2023-03-13 09:28:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:48 --> URI Class Initialized
INFO - 2023-03-13 09:28:48 --> Router Class Initialized
INFO - 2023-03-13 09:28:48 --> Output Class Initialized
INFO - 2023-03-13 09:28:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:48 --> Input Class Initialized
INFO - 2023-03-13 09:28:48 --> Language Class Initialized
INFO - 2023-03-13 09:28:48 --> Loader Class Initialized
INFO - 2023-03-13 09:28:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:28:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:28:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:48 --> Total execution time: 0.0444
INFO - 2023-03-13 09:28:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:48 --> Total execution time: 0.2423
INFO - 2023-03-13 09:28:48 --> Config Class Initialized
INFO - 2023-03-13 09:28:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:28:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:28:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:28:48 --> URI Class Initialized
INFO - 2023-03-13 09:28:48 --> Router Class Initialized
INFO - 2023-03-13 09:28:48 --> Output Class Initialized
INFO - 2023-03-13 09:28:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:28:48 --> Input Class Initialized
INFO - 2023-03-13 09:28:48 --> Language Class Initialized
INFO - 2023-03-13 09:28:48 --> Loader Class Initialized
INFO - 2023-03-13 09:28:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:28:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:28:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:28:48 --> Total execution time: 0.0570
INFO - 2023-03-13 09:29:27 --> Config Class Initialized
INFO - 2023-03-13 09:29:27 --> Config Class Initialized
INFO - 2023-03-13 09:29:27 --> Hooks Class Initialized
INFO - 2023-03-13 09:29:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:29:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:29:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:27 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:27 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:27 --> URI Class Initialized
INFO - 2023-03-13 09:29:27 --> URI Class Initialized
INFO - 2023-03-13 09:29:27 --> Router Class Initialized
INFO - 2023-03-13 09:29:27 --> Router Class Initialized
INFO - 2023-03-13 09:29:27 --> Output Class Initialized
INFO - 2023-03-13 09:29:27 --> Output Class Initialized
INFO - 2023-03-13 09:29:27 --> Security Class Initialized
INFO - 2023-03-13 09:29:27 --> Security Class Initialized
DEBUG - 2023-03-13 09:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:29:27 --> Input Class Initialized
INFO - 2023-03-13 09:29:27 --> Input Class Initialized
INFO - 2023-03-13 09:29:27 --> Language Class Initialized
INFO - 2023-03-13 09:29:27 --> Language Class Initialized
INFO - 2023-03-13 09:29:27 --> Loader Class Initialized
INFO - 2023-03-13 09:29:27 --> Loader Class Initialized
INFO - 2023-03-13 09:29:27 --> Controller Class Initialized
INFO - 2023-03-13 09:29:27 --> Controller Class Initialized
DEBUG - 2023-03-13 09:29:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:29:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:29:27 --> Database Driver Class Initialized
INFO - 2023-03-13 09:29:27 --> Database Driver Class Initialized
INFO - 2023-03-13 09:29:27 --> Model "Login_model" initialized
INFO - 2023-03-13 09:29:27 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:27 --> Total execution time: 0.0675
INFO - 2023-03-13 09:29:27 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:27 --> Total execution time: 0.0694
INFO - 2023-03-13 09:29:28 --> Config Class Initialized
INFO - 2023-03-13 09:29:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:28 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:28 --> Config Class Initialized
INFO - 2023-03-13 09:29:28 --> URI Class Initialized
INFO - 2023-03-13 09:29:28 --> Hooks Class Initialized
INFO - 2023-03-13 09:29:28 --> Router Class Initialized
DEBUG - 2023-03-13 09:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:28 --> Output Class Initialized
INFO - 2023-03-13 09:29:28 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:28 --> Security Class Initialized
INFO - 2023-03-13 09:29:28 --> URI Class Initialized
DEBUG - 2023-03-13 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:29:28 --> Input Class Initialized
INFO - 2023-03-13 09:29:28 --> Router Class Initialized
INFO - 2023-03-13 09:29:28 --> Language Class Initialized
INFO - 2023-03-13 09:29:28 --> Output Class Initialized
INFO - 2023-03-13 09:29:28 --> Loader Class Initialized
INFO - 2023-03-13 09:29:28 --> Security Class Initialized
INFO - 2023-03-13 09:29:28 --> Controller Class Initialized
DEBUG - 2023-03-13 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:29:28 --> Input Class Initialized
INFO - 2023-03-13 09:29:28 --> Language Class Initialized
INFO - 2023-03-13 09:29:28 --> Loader Class Initialized
INFO - 2023-03-13 09:29:28 --> Controller Class Initialized
DEBUG - 2023-03-13 09:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:29:28 --> Database Driver Class Initialized
INFO - 2023-03-13 09:29:28 --> Database Driver Class Initialized
INFO - 2023-03-13 09:29:28 --> Model "Login_model" initialized
INFO - 2023-03-13 09:29:28 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:28 --> Total execution time: 0.0625
INFO - 2023-03-13 09:29:28 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:28 --> Total execution time: 0.0827
INFO - 2023-03-13 09:29:36 --> Config Class Initialized
INFO - 2023-03-13 09:29:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:29:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:36 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:36 --> URI Class Initialized
INFO - 2023-03-13 09:29:36 --> Router Class Initialized
INFO - 2023-03-13 09:29:36 --> Output Class Initialized
INFO - 2023-03-13 09:29:36 --> Security Class Initialized
DEBUG - 2023-03-13 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:29:36 --> Input Class Initialized
INFO - 2023-03-13 09:29:36 --> Language Class Initialized
INFO - 2023-03-13 09:29:36 --> Loader Class Initialized
INFO - 2023-03-13 09:29:36 --> Controller Class Initialized
DEBUG - 2023-03-13 09:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:29:36 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:36 --> Total execution time: 0.0045
INFO - 2023-03-13 09:29:36 --> Config Class Initialized
INFO - 2023-03-13 09:29:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:29:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:36 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:36 --> URI Class Initialized
INFO - 2023-03-13 09:29:36 --> Router Class Initialized
INFO - 2023-03-13 09:29:36 --> Output Class Initialized
INFO - 2023-03-13 09:29:36 --> Security Class Initialized
DEBUG - 2023-03-13 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:29:36 --> Input Class Initialized
INFO - 2023-03-13 09:29:36 --> Language Class Initialized
INFO - 2023-03-13 09:29:36 --> Loader Class Initialized
INFO - 2023-03-13 09:29:36 --> Controller Class Initialized
DEBUG - 2023-03-13 09:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:29:36 --> Database Driver Class Initialized
INFO - 2023-03-13 09:29:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:29:36 --> Final output sent to browser
DEBUG - 2023-03-13 09:29:36 --> Total execution time: 0.0529
INFO - 2023-03-13 09:29:40 --> Config Class Initialized
INFO - 2023-03-13 09:29:40 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:29:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:29:40 --> Utf8 Class Initialized
INFO - 2023-03-13 09:29:40 --> URI Class Initialized
INFO - 2023-03-13 09:29:40 --> Router Class Initialized
INFO - 2023-03-13 09:29:40 --> Output Class Initialized
INFO - 2023-03-13 09:29:40 --> Security Class Initialized
DEBUG - 2023-03-13 09:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:29:40 --> Input Class Initialized
INFO - 2023-03-13 09:29:40 --> Language Class Initialized
ERROR - 2023-03-13 09:29:40 --> 404 Page Not Found: user/Cluster/addSchema
INFO - 2023-03-13 09:36:10 --> Config Class Initialized
INFO - 2023-03-13 09:36:10 --> Config Class Initialized
INFO - 2023-03-13 09:36:10 --> Hooks Class Initialized
INFO - 2023-03-13 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:10 --> URI Class Initialized
INFO - 2023-03-13 09:36:10 --> Router Class Initialized
INFO - 2023-03-13 09:36:10 --> URI Class Initialized
INFO - 2023-03-13 09:36:10 --> Output Class Initialized
INFO - 2023-03-13 09:36:10 --> Security Class Initialized
INFO - 2023-03-13 09:36:10 --> Router Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:10 --> Output Class Initialized
INFO - 2023-03-13 09:36:10 --> Input Class Initialized
INFO - 2023-03-13 09:36:10 --> Security Class Initialized
INFO - 2023-03-13 09:36:10 --> Language Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:10 --> Input Class Initialized
INFO - 2023-03-13 09:36:10 --> Language Class Initialized
INFO - 2023-03-13 09:36:10 --> Loader Class Initialized
INFO - 2023-03-13 09:36:10 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:10 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:10 --> Loader Class Initialized
INFO - 2023-03-13 09:36:10 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:10 --> Total execution time: 0.1293
INFO - 2023-03-13 09:36:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:10 --> Total execution time: 0.2650
INFO - 2023-03-13 09:36:10 --> Config Class Initialized
INFO - 2023-03-13 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:10 --> URI Class Initialized
INFO - 2023-03-13 09:36:10 --> Router Class Initialized
INFO - 2023-03-13 09:36:10 --> Output Class Initialized
INFO - 2023-03-13 09:36:10 --> Config Class Initialized
INFO - 2023-03-13 09:36:10 --> Security Class Initialized
INFO - 2023-03-13 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:10 --> Input Class Initialized
INFO - 2023-03-13 09:36:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:10 --> Language Class Initialized
INFO - 2023-03-13 09:36:10 --> URI Class Initialized
INFO - 2023-03-13 09:36:10 --> Loader Class Initialized
INFO - 2023-03-13 09:36:10 --> Router Class Initialized
INFO - 2023-03-13 09:36:10 --> Controller Class Initialized
INFO - 2023-03-13 09:36:10 --> Output Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:10 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:10 --> Input Class Initialized
INFO - 2023-03-13 09:36:10 --> Language Class Initialized
INFO - 2023-03-13 09:36:10 --> Loader Class Initialized
INFO - 2023-03-13 09:36:10 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:10 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:10 --> Total execution time: 0.0282
INFO - 2023-03-13 09:36:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:10 --> Total execution time: 0.0655
INFO - 2023-03-13 09:36:19 --> Config Class Initialized
INFO - 2023-03-13 09:36:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:19 --> URI Class Initialized
INFO - 2023-03-13 09:36:19 --> Router Class Initialized
INFO - 2023-03-13 09:36:19 --> Output Class Initialized
INFO - 2023-03-13 09:36:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:19 --> Input Class Initialized
INFO - 2023-03-13 09:36:19 --> Language Class Initialized
INFO - 2023-03-13 09:36:19 --> Loader Class Initialized
INFO - 2023-03-13 09:36:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:36:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:19 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:19 --> Total execution time: 0.1542
INFO - 2023-03-13 09:36:19 --> Config Class Initialized
INFO - 2023-03-13 09:36:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:19 --> URI Class Initialized
INFO - 2023-03-13 09:36:19 --> Router Class Initialized
INFO - 2023-03-13 09:36:19 --> Output Class Initialized
INFO - 2023-03-13 09:36:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:19 --> Input Class Initialized
INFO - 2023-03-13 09:36:19 --> Language Class Initialized
INFO - 2023-03-13 09:36:19 --> Loader Class Initialized
INFO - 2023-03-13 09:36:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:19 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:36:19 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:19 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:19 --> Total execution time: 0.1194
INFO - 2023-03-13 09:36:23 --> Config Class Initialized
INFO - 2023-03-13 09:36:23 --> Hooks Class Initialized
INFO - 2023-03-13 09:36:23 --> Config Class Initialized
INFO - 2023-03-13 09:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:23 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:23 --> URI Class Initialized
INFO - 2023-03-13 09:36:23 --> URI Class Initialized
INFO - 2023-03-13 09:36:23 --> Router Class Initialized
INFO - 2023-03-13 09:36:23 --> Router Class Initialized
INFO - 2023-03-13 09:36:23 --> Output Class Initialized
INFO - 2023-03-13 09:36:23 --> Output Class Initialized
INFO - 2023-03-13 09:36:23 --> Security Class Initialized
INFO - 2023-03-13 09:36:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:23 --> Input Class Initialized
DEBUG - 2023-03-13 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:23 --> Language Class Initialized
INFO - 2023-03-13 09:36:23 --> Input Class Initialized
INFO - 2023-03-13 09:36:23 --> Loader Class Initialized
INFO - 2023-03-13 09:36:23 --> Language Class Initialized
INFO - 2023-03-13 09:36:23 --> Loader Class Initialized
INFO - 2023-03-13 09:36:23 --> Controller Class Initialized
INFO - 2023-03-13 09:36:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:23 --> Total execution time: 0.0794
INFO - 2023-03-13 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:23 --> Total execution time: 0.0811
INFO - 2023-03-13 09:36:23 --> Config Class Initialized
INFO - 2023-03-13 09:36:23 --> Config Class Initialized
INFO - 2023-03-13 09:36:23 --> Hooks Class Initialized
INFO - 2023-03-13 09:36:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:36:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:23 --> URI Class Initialized
INFO - 2023-03-13 09:36:23 --> URI Class Initialized
INFO - 2023-03-13 09:36:23 --> Router Class Initialized
INFO - 2023-03-13 09:36:23 --> Router Class Initialized
INFO - 2023-03-13 09:36:23 --> Output Class Initialized
INFO - 2023-03-13 09:36:23 --> Output Class Initialized
INFO - 2023-03-13 09:36:23 --> Security Class Initialized
INFO - 2023-03-13 09:36:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:23 --> Input Class Initialized
INFO - 2023-03-13 09:36:23 --> Input Class Initialized
INFO - 2023-03-13 09:36:23 --> Language Class Initialized
INFO - 2023-03-13 09:36:23 --> Language Class Initialized
INFO - 2023-03-13 09:36:23 --> Loader Class Initialized
INFO - 2023-03-13 09:36:23 --> Loader Class Initialized
INFO - 2023-03-13 09:36:23 --> Controller Class Initialized
INFO - 2023-03-13 09:36:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:36:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:23 --> Total execution time: 0.0625
INFO - 2023-03-13 09:36:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:23 --> Total execution time: 0.0648
INFO - 2023-03-13 09:36:26 --> Config Class Initialized
INFO - 2023-03-13 09:36:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:26 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:26 --> URI Class Initialized
INFO - 2023-03-13 09:36:26 --> Router Class Initialized
INFO - 2023-03-13 09:36:26 --> Output Class Initialized
INFO - 2023-03-13 09:36:26 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:26 --> Input Class Initialized
INFO - 2023-03-13 09:36:26 --> Language Class Initialized
INFO - 2023-03-13 09:36:26 --> Loader Class Initialized
INFO - 2023-03-13 09:36:26 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:26 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:26 --> Total execution time: 0.0272
INFO - 2023-03-13 09:36:26 --> Config Class Initialized
INFO - 2023-03-13 09:36:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:26 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:26 --> URI Class Initialized
INFO - 2023-03-13 09:36:26 --> Router Class Initialized
INFO - 2023-03-13 09:36:26 --> Output Class Initialized
INFO - 2023-03-13 09:36:26 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:26 --> Input Class Initialized
INFO - 2023-03-13 09:36:26 --> Language Class Initialized
INFO - 2023-03-13 09:36:26 --> Loader Class Initialized
INFO - 2023-03-13 09:36:26 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:26 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:36:26 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:26 --> Total execution time: 0.0561
INFO - 2023-03-13 09:36:32 --> Config Class Initialized
INFO - 2023-03-13 09:36:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:32 --> URI Class Initialized
INFO - 2023-03-13 09:36:32 --> Router Class Initialized
INFO - 2023-03-13 09:36:32 --> Output Class Initialized
INFO - 2023-03-13 09:36:32 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:32 --> Input Class Initialized
INFO - 2023-03-13 09:36:32 --> Language Class Initialized
INFO - 2023-03-13 09:36:32 --> Loader Class Initialized
INFO - 2023-03-13 09:36:32 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:32 --> Total execution time: 0.0054
INFO - 2023-03-13 09:36:32 --> Config Class Initialized
INFO - 2023-03-13 09:36:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:32 --> URI Class Initialized
INFO - 2023-03-13 09:36:32 --> Router Class Initialized
INFO - 2023-03-13 09:36:32 --> Output Class Initialized
INFO - 2023-03-13 09:36:32 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:32 --> Input Class Initialized
INFO - 2023-03-13 09:36:32 --> Language Class Initialized
INFO - 2023-03-13 09:36:32 --> Loader Class Initialized
INFO - 2023-03-13 09:36:32 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:32 --> Total execution time: 0.0295
INFO - 2023-03-13 09:36:48 --> Config Class Initialized
INFO - 2023-03-13 09:36:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:48 --> URI Class Initialized
INFO - 2023-03-13 09:36:48 --> Router Class Initialized
INFO - 2023-03-13 09:36:48 --> Output Class Initialized
INFO - 2023-03-13 09:36:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:48 --> Input Class Initialized
INFO - 2023-03-13 09:36:48 --> Language Class Initialized
INFO - 2023-03-13 09:36:48 --> Loader Class Initialized
INFO - 2023-03-13 09:36:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:36:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:48 --> Total execution time: 0.0478
INFO - 2023-03-13 09:36:48 --> Config Class Initialized
INFO - 2023-03-13 09:36:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:48 --> URI Class Initialized
INFO - 2023-03-13 09:36:48 --> Router Class Initialized
INFO - 2023-03-13 09:36:48 --> Output Class Initialized
INFO - 2023-03-13 09:36:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:48 --> Input Class Initialized
INFO - 2023-03-13 09:36:48 --> Language Class Initialized
INFO - 2023-03-13 09:36:48 --> Loader Class Initialized
INFO - 2023-03-13 09:36:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:36:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:48 --> Total execution time: 0.0491
INFO - 2023-03-13 09:36:50 --> Config Class Initialized
INFO - 2023-03-13 09:36:50 --> Config Class Initialized
INFO - 2023-03-13 09:36:50 --> Hooks Class Initialized
INFO - 2023-03-13 09:36:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:36:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:50 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:50 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:50 --> URI Class Initialized
INFO - 2023-03-13 09:36:50 --> URI Class Initialized
INFO - 2023-03-13 09:36:50 --> Router Class Initialized
INFO - 2023-03-13 09:36:50 --> Router Class Initialized
INFO - 2023-03-13 09:36:50 --> Output Class Initialized
INFO - 2023-03-13 09:36:50 --> Output Class Initialized
INFO - 2023-03-13 09:36:50 --> Security Class Initialized
INFO - 2023-03-13 09:36:50 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:50 --> Input Class Initialized
INFO - 2023-03-13 09:36:50 --> Input Class Initialized
INFO - 2023-03-13 09:36:50 --> Language Class Initialized
INFO - 2023-03-13 09:36:50 --> Language Class Initialized
INFO - 2023-03-13 09:36:50 --> Loader Class Initialized
INFO - 2023-03-13 09:36:50 --> Loader Class Initialized
INFO - 2023-03-13 09:36:50 --> Controller Class Initialized
INFO - 2023-03-13 09:36:50 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:50 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:51 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:51 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:51 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:51 --> Total execution time: 0.0930
INFO - 2023-03-13 09:36:51 --> Config Class Initialized
INFO - 2023-03-13 09:36:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:51 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:51 --> Final output sent to browser
INFO - 2023-03-13 09:36:51 --> URI Class Initialized
DEBUG - 2023-03-13 09:36:51 --> Total execution time: 0.1045
INFO - 2023-03-13 09:36:51 --> Router Class Initialized
INFO - 2023-03-13 09:36:51 --> Output Class Initialized
INFO - 2023-03-13 09:36:51 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:51 --> Input Class Initialized
INFO - 2023-03-13 09:36:51 --> Language Class Initialized
INFO - 2023-03-13 09:36:51 --> Loader Class Initialized
INFO - 2023-03-13 09:36:51 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:51 --> Config Class Initialized
INFO - 2023-03-13 09:36:51 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:36:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:36:51 --> Utf8 Class Initialized
INFO - 2023-03-13 09:36:51 --> URI Class Initialized
INFO - 2023-03-13 09:36:51 --> Router Class Initialized
INFO - 2023-03-13 09:36:51 --> Output Class Initialized
INFO - 2023-03-13 09:36:51 --> Security Class Initialized
DEBUG - 2023-03-13 09:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:36:51 --> Input Class Initialized
INFO - 2023-03-13 09:36:51 --> Language Class Initialized
INFO - 2023-03-13 09:36:51 --> Loader Class Initialized
INFO - 2023-03-13 09:36:51 --> Controller Class Initialized
DEBUG - 2023-03-13 09:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:36:51 --> Database Driver Class Initialized
INFO - 2023-03-13 09:36:51 --> Model "Login_model" initialized
INFO - 2023-03-13 09:36:51 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:51 --> Total execution time: 0.0655
INFO - 2023-03-13 09:36:51 --> Final output sent to browser
DEBUG - 2023-03-13 09:36:51 --> Total execution time: 0.0857
INFO - 2023-03-13 09:37:16 --> Config Class Initialized
INFO - 2023-03-13 09:37:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:37:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:37:16 --> Utf8 Class Initialized
INFO - 2023-03-13 09:37:16 --> URI Class Initialized
INFO - 2023-03-13 09:37:16 --> Router Class Initialized
INFO - 2023-03-13 09:37:16 --> Output Class Initialized
INFO - 2023-03-13 09:37:16 --> Security Class Initialized
DEBUG - 2023-03-13 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:37:16 --> Input Class Initialized
INFO - 2023-03-13 09:37:16 --> Language Class Initialized
INFO - 2023-03-13 09:37:16 --> Loader Class Initialized
INFO - 2023-03-13 09:37:16 --> Controller Class Initialized
DEBUG - 2023-03-13 09:37:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:37:16 --> Final output sent to browser
DEBUG - 2023-03-13 09:37:16 --> Total execution time: 0.0678
INFO - 2023-03-13 09:37:16 --> Config Class Initialized
INFO - 2023-03-13 09:37:16 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:37:16 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:37:16 --> Utf8 Class Initialized
INFO - 2023-03-13 09:37:16 --> URI Class Initialized
INFO - 2023-03-13 09:37:16 --> Router Class Initialized
INFO - 2023-03-13 09:37:16 --> Output Class Initialized
INFO - 2023-03-13 09:37:16 --> Security Class Initialized
DEBUG - 2023-03-13 09:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:37:16 --> Input Class Initialized
INFO - 2023-03-13 09:37:16 --> Language Class Initialized
INFO - 2023-03-13 09:37:16 --> Loader Class Initialized
INFO - 2023-03-13 09:37:16 --> Controller Class Initialized
DEBUG - 2023-03-13 09:37:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:37:16 --> Database Driver Class Initialized
INFO - 2023-03-13 09:37:16 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:37:16 --> Final output sent to browser
DEBUG - 2023-03-13 09:37:16 --> Total execution time: 0.0129
INFO - 2023-03-13 09:37:19 --> Config Class Initialized
INFO - 2023-03-13 09:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:37:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:37:19 --> URI Class Initialized
INFO - 2023-03-13 09:37:19 --> Router Class Initialized
INFO - 2023-03-13 09:37:19 --> Output Class Initialized
INFO - 2023-03-13 09:37:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:37:19 --> Input Class Initialized
INFO - 2023-03-13 09:37:19 --> Language Class Initialized
INFO - 2023-03-13 09:37:19 --> Loader Class Initialized
INFO - 2023-03-13 09:37:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:37:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:37:19 --> Total execution time: 0.0068
INFO - 2023-03-13 09:37:19 --> Config Class Initialized
INFO - 2023-03-13 09:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:37:19 --> Utf8 Class Initialized
INFO - 2023-03-13 09:37:19 --> URI Class Initialized
INFO - 2023-03-13 09:37:19 --> Router Class Initialized
INFO - 2023-03-13 09:37:19 --> Output Class Initialized
INFO - 2023-03-13 09:37:19 --> Security Class Initialized
DEBUG - 2023-03-13 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:37:19 --> Input Class Initialized
INFO - 2023-03-13 09:37:19 --> Language Class Initialized
INFO - 2023-03-13 09:37:19 --> Loader Class Initialized
INFO - 2023-03-13 09:37:19 --> Controller Class Initialized
DEBUG - 2023-03-13 09:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:37:19 --> Final output sent to browser
DEBUG - 2023-03-13 09:37:19 --> Total execution time: 0.0168
INFO - 2023-03-13 09:39:45 --> Config Class Initialized
INFO - 2023-03-13 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:45 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:45 --> URI Class Initialized
INFO - 2023-03-13 09:39:45 --> Router Class Initialized
INFO - 2023-03-13 09:39:45 --> Output Class Initialized
INFO - 2023-03-13 09:39:45 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:45 --> Input Class Initialized
INFO - 2023-03-13 09:39:45 --> Language Class Initialized
INFO - 2023-03-13 09:39:45 --> Loader Class Initialized
INFO - 2023-03-13 09:39:45 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:45 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:39:45 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:45 --> Model "Login_model" initialized
INFO - 2023-03-13 09:39:45 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:45 --> Total execution time: 0.1254
INFO - 2023-03-13 09:39:45 --> Config Class Initialized
INFO - 2023-03-13 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:45 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:45 --> URI Class Initialized
INFO - 2023-03-13 09:39:45 --> Router Class Initialized
INFO - 2023-03-13 09:39:45 --> Output Class Initialized
INFO - 2023-03-13 09:39:45 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:45 --> Input Class Initialized
INFO - 2023-03-13 09:39:45 --> Language Class Initialized
INFO - 2023-03-13 09:39:45 --> Loader Class Initialized
INFO - 2023-03-13 09:39:45 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:45 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:45 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:39:45 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:45 --> Model "Login_model" initialized
INFO - 2023-03-13 09:39:45 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:45 --> Total execution time: 0.1253
INFO - 2023-03-13 09:39:49 --> Config Class Initialized
INFO - 2023-03-13 09:39:49 --> Hooks Class Initialized
INFO - 2023-03-13 09:39:49 --> Config Class Initialized
INFO - 2023-03-13 09:39:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:49 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:39:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:49 --> URI Class Initialized
INFO - 2023-03-13 09:39:49 --> URI Class Initialized
INFO - 2023-03-13 09:39:49 --> Router Class Initialized
INFO - 2023-03-13 09:39:49 --> Router Class Initialized
INFO - 2023-03-13 09:39:49 --> Output Class Initialized
INFO - 2023-03-13 09:39:49 --> Output Class Initialized
INFO - 2023-03-13 09:39:49 --> Security Class Initialized
INFO - 2023-03-13 09:39:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:49 --> Input Class Initialized
INFO - 2023-03-13 09:39:49 --> Input Class Initialized
INFO - 2023-03-13 09:39:49 --> Language Class Initialized
INFO - 2023-03-13 09:39:49 --> Language Class Initialized
INFO - 2023-03-13 09:39:49 --> Loader Class Initialized
INFO - 2023-03-13 09:39:49 --> Loader Class Initialized
INFO - 2023-03-13 09:39:49 --> Controller Class Initialized
INFO - 2023-03-13 09:39:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:49 --> Model "Login_model" initialized
INFO - 2023-03-13 09:39:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:49 --> Total execution time: 0.0539
INFO - 2023-03-13 09:39:49 --> Config Class Initialized
INFO - 2023-03-13 09:39:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:49 --> URI Class Initialized
INFO - 2023-03-13 09:39:49 --> Router Class Initialized
INFO - 2023-03-13 09:39:49 --> Output Class Initialized
INFO - 2023-03-13 09:39:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:49 --> Input Class Initialized
INFO - 2023-03-13 09:39:49 --> Language Class Initialized
INFO - 2023-03-13 09:39:49 --> Loader Class Initialized
INFO - 2023-03-13 09:39:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:49 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:49 --> Model "Login_model" initialized
INFO - 2023-03-13 09:39:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:49 --> Total execution time: 0.0863
INFO - 2023-03-13 09:39:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:49 --> Total execution time: 0.0324
INFO - 2023-03-13 09:39:49 --> Config Class Initialized
INFO - 2023-03-13 09:39:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:49 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:49 --> URI Class Initialized
INFO - 2023-03-13 09:39:49 --> Router Class Initialized
INFO - 2023-03-13 09:39:49 --> Output Class Initialized
INFO - 2023-03-13 09:39:49 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:49 --> Input Class Initialized
INFO - 2023-03-13 09:39:49 --> Language Class Initialized
INFO - 2023-03-13 09:39:49 --> Loader Class Initialized
INFO - 2023-03-13 09:39:49 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:49 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:49 --> Total execution time: 0.1076
INFO - 2023-03-13 09:39:55 --> Config Class Initialized
INFO - 2023-03-13 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:55 --> URI Class Initialized
INFO - 2023-03-13 09:39:55 --> Router Class Initialized
INFO - 2023-03-13 09:39:55 --> Output Class Initialized
INFO - 2023-03-13 09:39:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:55 --> Input Class Initialized
INFO - 2023-03-13 09:39:55 --> Language Class Initialized
INFO - 2023-03-13 09:39:55 --> Loader Class Initialized
INFO - 2023-03-13 09:39:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:55 --> Total execution time: 0.0054
INFO - 2023-03-13 09:39:55 --> Config Class Initialized
INFO - 2023-03-13 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:55 --> URI Class Initialized
INFO - 2023-03-13 09:39:55 --> Router Class Initialized
INFO - 2023-03-13 09:39:55 --> Output Class Initialized
INFO - 2023-03-13 09:39:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:55 --> Input Class Initialized
INFO - 2023-03-13 09:39:55 --> Language Class Initialized
INFO - 2023-03-13 09:39:55 --> Loader Class Initialized
INFO - 2023-03-13 09:39:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:55 --> Database Driver Class Initialized
INFO - 2023-03-13 09:39:55 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:39:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:55 --> Total execution time: 0.0124
INFO - 2023-03-13 09:39:57 --> Config Class Initialized
INFO - 2023-03-13 09:39:57 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:57 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:57 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:57 --> URI Class Initialized
INFO - 2023-03-13 09:39:57 --> Router Class Initialized
INFO - 2023-03-13 09:39:57 --> Output Class Initialized
INFO - 2023-03-13 09:39:57 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:57 --> Input Class Initialized
INFO - 2023-03-13 09:39:57 --> Language Class Initialized
INFO - 2023-03-13 09:39:57 --> Loader Class Initialized
INFO - 2023-03-13 09:39:57 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:57 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:57 --> Total execution time: 0.0048
INFO - 2023-03-13 09:39:57 --> Config Class Initialized
INFO - 2023-03-13 09:39:57 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:39:57 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:39:57 --> Utf8 Class Initialized
INFO - 2023-03-13 09:39:57 --> URI Class Initialized
INFO - 2023-03-13 09:39:57 --> Router Class Initialized
INFO - 2023-03-13 09:39:57 --> Output Class Initialized
INFO - 2023-03-13 09:39:57 --> Security Class Initialized
DEBUG - 2023-03-13 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:39:57 --> Input Class Initialized
INFO - 2023-03-13 09:39:57 --> Language Class Initialized
INFO - 2023-03-13 09:39:57 --> Loader Class Initialized
INFO - 2023-03-13 09:39:57 --> Controller Class Initialized
DEBUG - 2023-03-13 09:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:39:57 --> Final output sent to browser
DEBUG - 2023-03-13 09:39:57 --> Total execution time: 0.0550
INFO - 2023-03-13 09:41:08 --> Config Class Initialized
INFO - 2023-03-13 09:41:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:08 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:08 --> URI Class Initialized
INFO - 2023-03-13 09:41:08 --> Router Class Initialized
INFO - 2023-03-13 09:41:08 --> Output Class Initialized
INFO - 2023-03-13 09:41:08 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:08 --> Input Class Initialized
INFO - 2023-03-13 09:41:08 --> Language Class Initialized
INFO - 2023-03-13 09:41:08 --> Loader Class Initialized
INFO - 2023-03-13 09:41:08 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:08 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:08 --> Total execution time: 0.0040
INFO - 2023-03-13 09:41:08 --> Config Class Initialized
INFO - 2023-03-13 09:41:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:08 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:08 --> URI Class Initialized
INFO - 2023-03-13 09:41:08 --> Router Class Initialized
INFO - 2023-03-13 09:41:08 --> Output Class Initialized
INFO - 2023-03-13 09:41:08 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:08 --> Input Class Initialized
INFO - 2023-03-13 09:41:08 --> Language Class Initialized
INFO - 2023-03-13 09:41:08 --> Loader Class Initialized
INFO - 2023-03-13 09:41:08 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:08 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:08 --> Total execution time: 0.0151
INFO - 2023-03-13 09:41:34 --> Config Class Initialized
INFO - 2023-03-13 09:41:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:34 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:34 --> URI Class Initialized
INFO - 2023-03-13 09:41:34 --> Router Class Initialized
INFO - 2023-03-13 09:41:34 --> Output Class Initialized
INFO - 2023-03-13 09:41:34 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:34 --> Input Class Initialized
INFO - 2023-03-13 09:41:34 --> Language Class Initialized
INFO - 2023-03-13 09:41:34 --> Loader Class Initialized
INFO - 2023-03-13 09:41:34 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:34 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:34 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:41:34 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:34 --> Model "Login_model" initialized
INFO - 2023-03-13 09:41:35 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:35 --> Total execution time: 0.1201
INFO - 2023-03-13 09:41:35 --> Config Class Initialized
INFO - 2023-03-13 09:41:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:35 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:35 --> URI Class Initialized
INFO - 2023-03-13 09:41:35 --> Router Class Initialized
INFO - 2023-03-13 09:41:35 --> Output Class Initialized
INFO - 2023-03-13 09:41:35 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:35 --> Input Class Initialized
INFO - 2023-03-13 09:41:35 --> Language Class Initialized
INFO - 2023-03-13 09:41:35 --> Loader Class Initialized
INFO - 2023-03-13 09:41:35 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:35 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:41:35 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:35 --> Model "Login_model" initialized
INFO - 2023-03-13 09:41:35 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:35 --> Total execution time: 0.0839
INFO - 2023-03-13 09:41:41 --> Config Class Initialized
INFO - 2023-03-13 09:41:41 --> Config Class Initialized
INFO - 2023-03-13 09:41:41 --> Hooks Class Initialized
INFO - 2023-03-13 09:41:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:41:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:41 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:41 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:41 --> URI Class Initialized
INFO - 2023-03-13 09:41:41 --> URI Class Initialized
INFO - 2023-03-13 09:41:41 --> Router Class Initialized
INFO - 2023-03-13 09:41:41 --> Router Class Initialized
INFO - 2023-03-13 09:41:41 --> Output Class Initialized
INFO - 2023-03-13 09:41:41 --> Output Class Initialized
INFO - 2023-03-13 09:41:41 --> Security Class Initialized
INFO - 2023-03-13 09:41:41 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:41 --> Input Class Initialized
INFO - 2023-03-13 09:41:41 --> Input Class Initialized
INFO - 2023-03-13 09:41:41 --> Language Class Initialized
INFO - 2023-03-13 09:41:41 --> Language Class Initialized
INFO - 2023-03-13 09:41:41 --> Loader Class Initialized
INFO - 2023-03-13 09:41:41 --> Loader Class Initialized
INFO - 2023-03-13 09:41:41 --> Controller Class Initialized
INFO - 2023-03-13 09:41:41 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:41 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:41 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:41 --> Model "Login_model" initialized
INFO - 2023-03-13 09:41:41 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:41 --> Total execution time: 0.0375
INFO - 2023-03-13 09:41:41 --> Config Class Initialized
INFO - 2023-03-13 09:41:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:41 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:41 --> URI Class Initialized
INFO - 2023-03-13 09:41:41 --> Router Class Initialized
INFO - 2023-03-13 09:41:41 --> Output Class Initialized
INFO - 2023-03-13 09:41:41 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:41 --> Input Class Initialized
INFO - 2023-03-13 09:41:41 --> Language Class Initialized
INFO - 2023-03-13 09:41:41 --> Loader Class Initialized
INFO - 2023-03-13 09:41:41 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:41 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:41 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:41 --> Model "Login_model" initialized
INFO - 2023-03-13 09:41:41 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:41 --> Total execution time: 0.0697
INFO - 2023-03-13 09:41:41 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:41 --> Total execution time: 0.0270
INFO - 2023-03-13 09:41:41 --> Config Class Initialized
INFO - 2023-03-13 09:41:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:41 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:41 --> URI Class Initialized
INFO - 2023-03-13 09:41:41 --> Router Class Initialized
INFO - 2023-03-13 09:41:41 --> Output Class Initialized
INFO - 2023-03-13 09:41:41 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:41 --> Input Class Initialized
INFO - 2023-03-13 09:41:41 --> Language Class Initialized
INFO - 2023-03-13 09:41:41 --> Loader Class Initialized
INFO - 2023-03-13 09:41:41 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:41 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:41 --> Total execution time: 0.1046
INFO - 2023-03-13 09:41:42 --> Config Class Initialized
INFO - 2023-03-13 09:41:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:42 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:42 --> URI Class Initialized
INFO - 2023-03-13 09:41:42 --> Router Class Initialized
INFO - 2023-03-13 09:41:42 --> Output Class Initialized
INFO - 2023-03-13 09:41:42 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:42 --> Input Class Initialized
INFO - 2023-03-13 09:41:42 --> Language Class Initialized
INFO - 2023-03-13 09:41:42 --> Loader Class Initialized
INFO - 2023-03-13 09:41:42 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:42 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:43 --> Total execution time: 0.1155
INFO - 2023-03-13 09:41:43 --> Config Class Initialized
INFO - 2023-03-13 09:41:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:43 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:43 --> URI Class Initialized
INFO - 2023-03-13 09:41:43 --> Router Class Initialized
INFO - 2023-03-13 09:41:43 --> Output Class Initialized
INFO - 2023-03-13 09:41:43 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:43 --> Input Class Initialized
INFO - 2023-03-13 09:41:43 --> Language Class Initialized
INFO - 2023-03-13 09:41:43 --> Loader Class Initialized
INFO - 2023-03-13 09:41:43 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:43 --> Database Driver Class Initialized
INFO - 2023-03-13 09:41:43 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:41:43 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:43 --> Total execution time: 0.0407
INFO - 2023-03-13 09:41:46 --> Config Class Initialized
INFO - 2023-03-13 09:41:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:46 --> URI Class Initialized
INFO - 2023-03-13 09:41:46 --> Router Class Initialized
INFO - 2023-03-13 09:41:46 --> Output Class Initialized
INFO - 2023-03-13 09:41:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:46 --> Input Class Initialized
INFO - 2023-03-13 09:41:46 --> Language Class Initialized
INFO - 2023-03-13 09:41:46 --> Loader Class Initialized
INFO - 2023-03-13 09:41:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:46 --> Total execution time: 0.0049
INFO - 2023-03-13 09:41:46 --> Config Class Initialized
INFO - 2023-03-13 09:41:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:41:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:41:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:41:46 --> URI Class Initialized
INFO - 2023-03-13 09:41:46 --> Router Class Initialized
INFO - 2023-03-13 09:41:46 --> Output Class Initialized
INFO - 2023-03-13 09:41:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:41:46 --> Input Class Initialized
INFO - 2023-03-13 09:41:46 --> Language Class Initialized
INFO - 2023-03-13 09:41:46 --> Loader Class Initialized
INFO - 2023-03-13 09:41:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:41:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:41:46 --> Total execution time: 0.0216
INFO - 2023-03-13 09:42:10 --> Config Class Initialized
INFO - 2023-03-13 09:42:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:10 --> URI Class Initialized
INFO - 2023-03-13 09:42:10 --> Router Class Initialized
INFO - 2023-03-13 09:42:10 --> Output Class Initialized
INFO - 2023-03-13 09:42:10 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:10 --> Input Class Initialized
INFO - 2023-03-13 09:42:10 --> Language Class Initialized
INFO - 2023-03-13 09:42:10 --> Loader Class Initialized
INFO - 2023-03-13 09:42:10 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:10 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:10 --> Total execution time: 0.1697
INFO - 2023-03-13 09:42:10 --> Config Class Initialized
INFO - 2023-03-13 09:42:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:10 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:10 --> URI Class Initialized
INFO - 2023-03-13 09:42:10 --> Router Class Initialized
INFO - 2023-03-13 09:42:10 --> Output Class Initialized
INFO - 2023-03-13 09:42:10 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:10 --> Input Class Initialized
INFO - 2023-03-13 09:42:10 --> Language Class Initialized
INFO - 2023-03-13 09:42:10 --> Loader Class Initialized
INFO - 2023-03-13 09:42:10 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:10 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:10 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:10 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:10 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:10 --> Total execution time: 0.0836
INFO - 2023-03-13 09:42:42 --> Config Class Initialized
INFO - 2023-03-13 09:42:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:42 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:42 --> URI Class Initialized
INFO - 2023-03-13 09:42:42 --> Router Class Initialized
INFO - 2023-03-13 09:42:42 --> Output Class Initialized
INFO - 2023-03-13 09:42:42 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:42 --> Input Class Initialized
INFO - 2023-03-13 09:42:42 --> Language Class Initialized
INFO - 2023-03-13 09:42:42 --> Loader Class Initialized
INFO - 2023-03-13 09:42:42 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:42 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:42 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:42 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:42 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:42 --> Total execution time: 0.1867
INFO - 2023-03-13 09:42:42 --> Config Class Initialized
INFO - 2023-03-13 09:42:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:42 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:42 --> URI Class Initialized
INFO - 2023-03-13 09:42:42 --> Router Class Initialized
INFO - 2023-03-13 09:42:42 --> Output Class Initialized
INFO - 2023-03-13 09:42:42 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:42 --> Input Class Initialized
INFO - 2023-03-13 09:42:42 --> Language Class Initialized
INFO - 2023-03-13 09:42:42 --> Loader Class Initialized
INFO - 2023-03-13 09:42:42 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:42 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:42 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:42 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:42 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:42 --> Total execution time: 0.0442
INFO - 2023-03-13 09:42:46 --> Config Class Initialized
INFO - 2023-03-13 09:42:46 --> Config Class Initialized
INFO - 2023-03-13 09:42:46 --> Hooks Class Initialized
INFO - 2023-03-13 09:42:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:46 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:42:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:46 --> URI Class Initialized
INFO - 2023-03-13 09:42:46 --> URI Class Initialized
INFO - 2023-03-13 09:42:46 --> Router Class Initialized
INFO - 2023-03-13 09:42:46 --> Router Class Initialized
INFO - 2023-03-13 09:42:46 --> Output Class Initialized
INFO - 2023-03-13 09:42:46 --> Output Class Initialized
INFO - 2023-03-13 09:42:46 --> Security Class Initialized
INFO - 2023-03-13 09:42:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:46 --> Input Class Initialized
INFO - 2023-03-13 09:42:46 --> Input Class Initialized
INFO - 2023-03-13 09:42:46 --> Language Class Initialized
INFO - 2023-03-13 09:42:46 --> Language Class Initialized
INFO - 2023-03-13 09:42:46 --> Loader Class Initialized
INFO - 2023-03-13 09:42:46 --> Loader Class Initialized
INFO - 2023-03-13 09:42:46 --> Controller Class Initialized
INFO - 2023-03-13 09:42:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:46 --> Total execution time: 0.0162
INFO - 2023-03-13 09:42:46 --> Config Class Initialized
INFO - 2023-03-13 09:42:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:46 --> URI Class Initialized
INFO - 2023-03-13 09:42:46 --> Router Class Initialized
INFO - 2023-03-13 09:42:46 --> Output Class Initialized
INFO - 2023-03-13 09:42:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:46 --> Input Class Initialized
INFO - 2023-03-13 09:42:46 --> Language Class Initialized
INFO - 2023-03-13 09:42:46 --> Loader Class Initialized
INFO - 2023-03-13 09:42:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:46 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:46 --> Total execution time: 0.1330
INFO - 2023-03-13 09:42:46 --> Config Class Initialized
INFO - 2023-03-13 09:42:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:46 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:46 --> URI Class Initialized
INFO - 2023-03-13 09:42:46 --> Router Class Initialized
INFO - 2023-03-13 09:42:46 --> Output Class Initialized
INFO - 2023-03-13 09:42:46 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:46 --> Input Class Initialized
INFO - 2023-03-13 09:42:46 --> Language Class Initialized
INFO - 2023-03-13 09:42:46 --> Loader Class Initialized
INFO - 2023-03-13 09:42:46 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:46 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:47 --> Config Class Initialized
INFO - 2023-03-13 09:42:47 --> Config Class Initialized
INFO - 2023-03-13 09:42:47 --> Hooks Class Initialized
INFO - 2023-03-13 09:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:47 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:47 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:47 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:47 --> URI Class Initialized
INFO - 2023-03-13 09:42:47 --> URI Class Initialized
INFO - 2023-03-13 09:42:47 --> Router Class Initialized
INFO - 2023-03-13 09:42:47 --> Router Class Initialized
INFO - 2023-03-13 09:42:47 --> Output Class Initialized
INFO - 2023-03-13 09:42:47 --> Output Class Initialized
INFO - 2023-03-13 09:42:47 --> Security Class Initialized
INFO - 2023-03-13 09:42:47 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:47 --> Input Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:47 --> Language Class Initialized
INFO - 2023-03-13 09:42:47 --> Input Class Initialized
INFO - 2023-03-13 09:42:47 --> Loader Class Initialized
INFO - 2023-03-13 09:42:47 --> Language Class Initialized
INFO - 2023-03-13 09:42:47 --> Controller Class Initialized
INFO - 2023-03-13 09:42:47 --> Loader Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:47 --> Controller Class Initialized
INFO - 2023-03-13 09:42:47 --> Database Driver Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:47 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:47 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:47 --> Total execution time: 0.0147
INFO - 2023-03-13 09:42:47 --> Config Class Initialized
INFO - 2023-03-13 09:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:47 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:47 --> URI Class Initialized
INFO - 2023-03-13 09:42:47 --> Router Class Initialized
INFO - 2023-03-13 09:42:47 --> Output Class Initialized
INFO - 2023-03-13 09:42:47 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:47 --> Input Class Initialized
INFO - 2023-03-13 09:42:47 --> Language Class Initialized
INFO - 2023-03-13 09:42:47 --> Loader Class Initialized
INFO - 2023-03-13 09:42:47 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:47 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:48 --> Config Class Initialized
INFO - 2023-03-13 09:42:48 --> Config Class Initialized
INFO - 2023-03-13 09:42:48 --> Hooks Class Initialized
INFO - 2023-03-13 09:42:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:48 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:42:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:48 --> URI Class Initialized
INFO - 2023-03-13 09:42:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:48 --> Router Class Initialized
INFO - 2023-03-13 09:42:48 --> URI Class Initialized
INFO - 2023-03-13 09:42:48 --> Output Class Initialized
INFO - 2023-03-13 09:42:48 --> Router Class Initialized
INFO - 2023-03-13 09:42:48 --> Security Class Initialized
INFO - 2023-03-13 09:42:48 --> Output Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:48 --> Security Class Initialized
INFO - 2023-03-13 09:42:48 --> Input Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:48 --> Language Class Initialized
INFO - 2023-03-13 09:42:48 --> Input Class Initialized
INFO - 2023-03-13 09:42:48 --> Language Class Initialized
INFO - 2023-03-13 09:42:48 --> Loader Class Initialized
INFO - 2023-03-13 09:42:48 --> Controller Class Initialized
INFO - 2023-03-13 09:42:48 --> Loader Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:48 --> Final output sent to browser
INFO - 2023-03-13 09:42:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:48 --> Total execution time: 0.1480
DEBUG - 2023-03-13 09:42:48 --> Total execution time: 0.1484
INFO - 2023-03-13 09:42:48 --> Config Class Initialized
INFO - 2023-03-13 09:42:48 --> Config Class Initialized
INFO - 2023-03-13 09:42:48 --> Hooks Class Initialized
INFO - 2023-03-13 09:42:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:42:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:48 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:48 --> URI Class Initialized
INFO - 2023-03-13 09:42:48 --> URI Class Initialized
INFO - 2023-03-13 09:42:48 --> Router Class Initialized
INFO - 2023-03-13 09:42:48 --> Router Class Initialized
INFO - 2023-03-13 09:42:48 --> Output Class Initialized
INFO - 2023-03-13 09:42:48 --> Output Class Initialized
INFO - 2023-03-13 09:42:48 --> Security Class Initialized
INFO - 2023-03-13 09:42:48 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:48 --> Input Class Initialized
INFO - 2023-03-13 09:42:48 --> Input Class Initialized
INFO - 2023-03-13 09:42:48 --> Language Class Initialized
INFO - 2023-03-13 09:42:48 --> Language Class Initialized
INFO - 2023-03-13 09:42:48 --> Loader Class Initialized
INFO - 2023-03-13 09:42:48 --> Controller Class Initialized
INFO - 2023-03-13 09:42:48 --> Loader Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:48 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:48 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:48 --> Model "Login_model" initialized
INFO - 2023-03-13 09:42:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:48 --> Total execution time: 0.0310
INFO - 2023-03-13 09:42:48 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:48 --> Total execution time: 0.0674
INFO - 2023-03-13 09:42:53 --> Config Class Initialized
INFO - 2023-03-13 09:42:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:53 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:53 --> URI Class Initialized
INFO - 2023-03-13 09:42:53 --> Router Class Initialized
INFO - 2023-03-13 09:42:53 --> Output Class Initialized
INFO - 2023-03-13 09:42:53 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:53 --> Input Class Initialized
INFO - 2023-03-13 09:42:53 --> Language Class Initialized
INFO - 2023-03-13 09:42:53 --> Loader Class Initialized
INFO - 2023-03-13 09:42:53 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:53 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:53 --> Total execution time: 0.0065
INFO - 2023-03-13 09:42:53 --> Config Class Initialized
INFO - 2023-03-13 09:42:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:53 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:53 --> URI Class Initialized
INFO - 2023-03-13 09:42:53 --> Router Class Initialized
INFO - 2023-03-13 09:42:53 --> Output Class Initialized
INFO - 2023-03-13 09:42:53 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:53 --> Input Class Initialized
INFO - 2023-03-13 09:42:53 --> Language Class Initialized
INFO - 2023-03-13 09:42:53 --> Loader Class Initialized
INFO - 2023-03-13 09:42:53 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:53 --> Database Driver Class Initialized
INFO - 2023-03-13 09:42:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:42:53 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:53 --> Total execution time: 0.0119
INFO - 2023-03-13 09:42:55 --> Config Class Initialized
INFO - 2023-03-13 09:42:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:55 --> URI Class Initialized
INFO - 2023-03-13 09:42:55 --> Router Class Initialized
INFO - 2023-03-13 09:42:55 --> Output Class Initialized
INFO - 2023-03-13 09:42:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:55 --> Input Class Initialized
INFO - 2023-03-13 09:42:55 --> Language Class Initialized
INFO - 2023-03-13 09:42:55 --> Loader Class Initialized
INFO - 2023-03-13 09:42:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:55 --> Total execution time: 0.0434
INFO - 2023-03-13 09:42:55 --> Config Class Initialized
INFO - 2023-03-13 09:42:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:55 --> URI Class Initialized
INFO - 2023-03-13 09:42:55 --> Router Class Initialized
INFO - 2023-03-13 09:42:55 --> Output Class Initialized
INFO - 2023-03-13 09:42:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:55 --> Input Class Initialized
INFO - 2023-03-13 09:42:55 --> Language Class Initialized
INFO - 2023-03-13 09:42:55 --> Loader Class Initialized
INFO - 2023-03-13 09:42:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:55 --> Total execution time: 0.1529
INFO - 2023-03-13 09:42:58 --> Config Class Initialized
INFO - 2023-03-13 09:42:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:58 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:58 --> URI Class Initialized
INFO - 2023-03-13 09:42:58 --> Router Class Initialized
INFO - 2023-03-13 09:42:58 --> Output Class Initialized
INFO - 2023-03-13 09:42:58 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:58 --> Input Class Initialized
INFO - 2023-03-13 09:42:58 --> Language Class Initialized
INFO - 2023-03-13 09:42:58 --> Loader Class Initialized
INFO - 2023-03-13 09:42:58 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:58 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:58 --> Total execution time: 0.0163
INFO - 2023-03-13 09:42:59 --> Config Class Initialized
INFO - 2023-03-13 09:42:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:42:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:42:59 --> Utf8 Class Initialized
INFO - 2023-03-13 09:42:59 --> URI Class Initialized
INFO - 2023-03-13 09:42:59 --> Router Class Initialized
INFO - 2023-03-13 09:42:59 --> Output Class Initialized
INFO - 2023-03-13 09:42:59 --> Security Class Initialized
DEBUG - 2023-03-13 09:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:42:59 --> Input Class Initialized
INFO - 2023-03-13 09:42:59 --> Language Class Initialized
INFO - 2023-03-13 09:42:59 --> Loader Class Initialized
INFO - 2023-03-13 09:42:59 --> Controller Class Initialized
DEBUG - 2023-03-13 09:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:42:59 --> Final output sent to browser
DEBUG - 2023-03-13 09:42:59 --> Total execution time: 0.0240
INFO - 2023-03-13 09:43:00 --> Config Class Initialized
INFO - 2023-03-13 09:43:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:00 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:00 --> URI Class Initialized
INFO - 2023-03-13 09:43:00 --> Router Class Initialized
INFO - 2023-03-13 09:43:00 --> Output Class Initialized
INFO - 2023-03-13 09:43:00 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:00 --> Input Class Initialized
INFO - 2023-03-13 09:43:00 --> Language Class Initialized
INFO - 2023-03-13 09:43:00 --> Loader Class Initialized
INFO - 2023-03-13 09:43:00 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:00 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:00 --> Total execution time: 0.0170
INFO - 2023-03-13 09:43:17 --> Config Class Initialized
INFO - 2023-03-13 09:43:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:17 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:17 --> URI Class Initialized
INFO - 2023-03-13 09:43:17 --> Router Class Initialized
INFO - 2023-03-13 09:43:17 --> Output Class Initialized
INFO - 2023-03-13 09:43:17 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:17 --> Input Class Initialized
INFO - 2023-03-13 09:43:17 --> Language Class Initialized
INFO - 2023-03-13 09:43:17 --> Loader Class Initialized
INFO - 2023-03-13 09:43:17 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:17 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:17 --> Total execution time: 0.0048
INFO - 2023-03-13 09:43:17 --> Config Class Initialized
INFO - 2023-03-13 09:43:17 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:17 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:17 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:17 --> URI Class Initialized
INFO - 2023-03-13 09:43:17 --> Router Class Initialized
INFO - 2023-03-13 09:43:17 --> Output Class Initialized
INFO - 2023-03-13 09:43:17 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:17 --> Input Class Initialized
INFO - 2023-03-13 09:43:17 --> Language Class Initialized
INFO - 2023-03-13 09:43:17 --> Loader Class Initialized
INFO - 2023-03-13 09:43:17 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:17 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:17 --> Total execution time: 0.0204
INFO - 2023-03-13 09:43:23 --> Config Class Initialized
INFO - 2023-03-13 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:23 --> URI Class Initialized
INFO - 2023-03-13 09:43:23 --> Router Class Initialized
INFO - 2023-03-13 09:43:23 --> Output Class Initialized
INFO - 2023-03-13 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:23 --> Input Class Initialized
INFO - 2023-03-13 09:43:23 --> Language Class Initialized
INFO - 2023-03-13 09:43:23 --> Loader Class Initialized
INFO - 2023-03-13 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:23 --> Total execution time: 0.0054
INFO - 2023-03-13 09:43:23 --> Config Class Initialized
INFO - 2023-03-13 09:43:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:23 --> URI Class Initialized
INFO - 2023-03-13 09:43:23 --> Router Class Initialized
INFO - 2023-03-13 09:43:23 --> Output Class Initialized
INFO - 2023-03-13 09:43:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:23 --> Input Class Initialized
INFO - 2023-03-13 09:43:23 --> Language Class Initialized
INFO - 2023-03-13 09:43:23 --> Loader Class Initialized
INFO - 2023-03-13 09:43:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:23 --> Total execution time: 0.0244
INFO - 2023-03-13 09:43:55 --> Config Class Initialized
INFO - 2023-03-13 09:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:55 --> URI Class Initialized
INFO - 2023-03-13 09:43:55 --> Router Class Initialized
INFO - 2023-03-13 09:43:55 --> Output Class Initialized
INFO - 2023-03-13 09:43:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:55 --> Input Class Initialized
INFO - 2023-03-13 09:43:55 --> Language Class Initialized
INFO - 2023-03-13 09:43:55 --> Loader Class Initialized
INFO - 2023-03-13 09:43:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:55 --> Total execution time: 0.0052
INFO - 2023-03-13 09:43:55 --> Config Class Initialized
INFO - 2023-03-13 09:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:43:55 --> Utf8 Class Initialized
INFO - 2023-03-13 09:43:55 --> URI Class Initialized
INFO - 2023-03-13 09:43:55 --> Router Class Initialized
INFO - 2023-03-13 09:43:55 --> Output Class Initialized
INFO - 2023-03-13 09:43:55 --> Security Class Initialized
DEBUG - 2023-03-13 09:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:43:55 --> Input Class Initialized
INFO - 2023-03-13 09:43:55 --> Language Class Initialized
INFO - 2023-03-13 09:43:55 --> Loader Class Initialized
INFO - 2023-03-13 09:43:55 --> Controller Class Initialized
DEBUG - 2023-03-13 09:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:43:55 --> Final output sent to browser
DEBUG - 2023-03-13 09:43:55 --> Total execution time: 0.0189
INFO - 2023-03-13 09:44:03 --> Config Class Initialized
INFO - 2023-03-13 09:44:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:44:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:44:03 --> Utf8 Class Initialized
INFO - 2023-03-13 09:44:03 --> URI Class Initialized
INFO - 2023-03-13 09:44:03 --> Router Class Initialized
INFO - 2023-03-13 09:44:03 --> Output Class Initialized
INFO - 2023-03-13 09:44:03 --> Security Class Initialized
DEBUG - 2023-03-13 09:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:44:03 --> Input Class Initialized
INFO - 2023-03-13 09:44:03 --> Language Class Initialized
INFO - 2023-03-13 09:44:03 --> Loader Class Initialized
INFO - 2023-03-13 09:44:03 --> Controller Class Initialized
DEBUG - 2023-03-13 09:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:44:03 --> Final output sent to browser
DEBUG - 2023-03-13 09:44:03 --> Total execution time: 0.0125
INFO - 2023-03-13 09:44:03 --> Config Class Initialized
INFO - 2023-03-13 09:44:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:44:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:44:03 --> Utf8 Class Initialized
INFO - 2023-03-13 09:44:03 --> URI Class Initialized
INFO - 2023-03-13 09:44:03 --> Router Class Initialized
INFO - 2023-03-13 09:44:03 --> Output Class Initialized
INFO - 2023-03-13 09:44:03 --> Security Class Initialized
DEBUG - 2023-03-13 09:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:44:03 --> Input Class Initialized
INFO - 2023-03-13 09:44:03 --> Language Class Initialized
INFO - 2023-03-13 09:44:03 --> Loader Class Initialized
INFO - 2023-03-13 09:44:03 --> Controller Class Initialized
DEBUG - 2023-03-13 09:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:44:03 --> Final output sent to browser
DEBUG - 2023-03-13 09:44:03 --> Total execution time: 0.0147
INFO - 2023-03-13 09:45:14 --> Config Class Initialized
INFO - 2023-03-13 09:45:14 --> Config Class Initialized
INFO - 2023-03-13 09:45:14 --> Hooks Class Initialized
INFO - 2023-03-13 09:45:14 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:14 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:14 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:14 --> URI Class Initialized
INFO - 2023-03-13 09:45:14 --> URI Class Initialized
INFO - 2023-03-13 09:45:14 --> Router Class Initialized
INFO - 2023-03-13 09:45:14 --> Router Class Initialized
INFO - 2023-03-13 09:45:14 --> Output Class Initialized
INFO - 2023-03-13 09:45:14 --> Output Class Initialized
INFO - 2023-03-13 09:45:14 --> Security Class Initialized
INFO - 2023-03-13 09:45:14 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:14 --> Input Class Initialized
INFO - 2023-03-13 09:45:14 --> Input Class Initialized
INFO - 2023-03-13 09:45:14 --> Language Class Initialized
INFO - 2023-03-13 09:45:14 --> Language Class Initialized
INFO - 2023-03-13 09:45:14 --> Loader Class Initialized
INFO - 2023-03-13 09:45:14 --> Loader Class Initialized
INFO - 2023-03-13 09:45:14 --> Controller Class Initialized
INFO - 2023-03-13 09:45:14 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:14 --> Database Driver Class Initialized
INFO - 2023-03-13 09:45:14 --> Database Driver Class Initialized
INFO - 2023-03-13 09:45:14 --> Model "Login_model" initialized
INFO - 2023-03-13 09:45:14 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:14 --> Total execution time: 0.0414
INFO - 2023-03-13 09:45:14 --> Config Class Initialized
INFO - 2023-03-13 09:45:14 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:14 --> Total execution time: 0.0741
INFO - 2023-03-13 09:45:14 --> Config Class Initialized
INFO - 2023-03-13 09:45:14 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:14 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:14 --> URI Class Initialized
INFO - 2023-03-13 09:45:14 --> Hooks Class Initialized
INFO - 2023-03-13 09:45:14 --> Router Class Initialized
INFO - 2023-03-13 09:45:14 --> Output Class Initialized
DEBUG - 2023-03-13 09:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:14 --> Security Class Initialized
INFO - 2023-03-13 09:45:14 --> Utf8 Class Initialized
DEBUG - 2023-03-13 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:14 --> Input Class Initialized
INFO - 2023-03-13 09:45:14 --> URI Class Initialized
INFO - 2023-03-13 09:45:14 --> Language Class Initialized
INFO - 2023-03-13 09:45:14 --> Router Class Initialized
INFO - 2023-03-13 09:45:14 --> Output Class Initialized
INFO - 2023-03-13 09:45:14 --> Loader Class Initialized
INFO - 2023-03-13 09:45:14 --> Security Class Initialized
INFO - 2023-03-13 09:45:14 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:14 --> Input Class Initialized
INFO - 2023-03-13 09:45:14 --> Language Class Initialized
INFO - 2023-03-13 09:45:14 --> Loader Class Initialized
INFO - 2023-03-13 09:45:14 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:14 --> Database Driver Class Initialized
INFO - 2023-03-13 09:45:14 --> Database Driver Class Initialized
INFO - 2023-03-13 09:45:14 --> Model "Login_model" initialized
INFO - 2023-03-13 09:45:14 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:14 --> Total execution time: 0.0937
INFO - 2023-03-13 09:45:14 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:14 --> Total execution time: 0.1087
INFO - 2023-03-13 09:45:24 --> Config Class Initialized
INFO - 2023-03-13 09:45:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:24 --> URI Class Initialized
INFO - 2023-03-13 09:45:24 --> Router Class Initialized
INFO - 2023-03-13 09:45:24 --> Output Class Initialized
INFO - 2023-03-13 09:45:24 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:24 --> Input Class Initialized
INFO - 2023-03-13 09:45:24 --> Language Class Initialized
INFO - 2023-03-13 09:45:24 --> Loader Class Initialized
INFO - 2023-03-13 09:45:24 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:24 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:24 --> Total execution time: 0.0062
INFO - 2023-03-13 09:45:24 --> Config Class Initialized
INFO - 2023-03-13 09:45:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:24 --> URI Class Initialized
INFO - 2023-03-13 09:45:24 --> Router Class Initialized
INFO - 2023-03-13 09:45:24 --> Output Class Initialized
INFO - 2023-03-13 09:45:24 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:24 --> Input Class Initialized
INFO - 2023-03-13 09:45:24 --> Language Class Initialized
INFO - 2023-03-13 09:45:24 --> Loader Class Initialized
INFO - 2023-03-13 09:45:24 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:24 --> Database Driver Class Initialized
INFO - 2023-03-13 09:45:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:45:24 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:24 --> Total execution time: 0.0937
INFO - 2023-03-13 09:45:29 --> Config Class Initialized
INFO - 2023-03-13 09:45:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:29 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:29 --> URI Class Initialized
INFO - 2023-03-13 09:45:29 --> Router Class Initialized
INFO - 2023-03-13 09:45:29 --> Output Class Initialized
INFO - 2023-03-13 09:45:29 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:29 --> Input Class Initialized
INFO - 2023-03-13 09:45:29 --> Language Class Initialized
INFO - 2023-03-13 09:45:29 --> Loader Class Initialized
INFO - 2023-03-13 09:45:29 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:29 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:29 --> Total execution time: 0.0098
INFO - 2023-03-13 09:45:29 --> Config Class Initialized
INFO - 2023-03-13 09:45:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:29 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:29 --> URI Class Initialized
INFO - 2023-03-13 09:45:29 --> Router Class Initialized
INFO - 2023-03-13 09:45:29 --> Output Class Initialized
INFO - 2023-03-13 09:45:29 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:29 --> Input Class Initialized
INFO - 2023-03-13 09:45:29 --> Language Class Initialized
INFO - 2023-03-13 09:45:29 --> Loader Class Initialized
INFO - 2023-03-13 09:45:29 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:29 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:29 --> Total execution time: 0.0312
INFO - 2023-03-13 09:45:29 --> Config Class Initialized
INFO - 2023-03-13 09:45:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:29 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:29 --> URI Class Initialized
INFO - 2023-03-13 09:45:29 --> Router Class Initialized
INFO - 2023-03-13 09:45:29 --> Output Class Initialized
INFO - 2023-03-13 09:45:29 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:29 --> Input Class Initialized
INFO - 2023-03-13 09:45:29 --> Language Class Initialized
INFO - 2023-03-13 09:45:29 --> Loader Class Initialized
INFO - 2023-03-13 09:45:29 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:29 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:29 --> Total execution time: 0.1151
INFO - 2023-03-13 09:45:29 --> Config Class Initialized
INFO - 2023-03-13 09:45:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:45:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:45:29 --> Utf8 Class Initialized
INFO - 2023-03-13 09:45:29 --> URI Class Initialized
INFO - 2023-03-13 09:45:29 --> Router Class Initialized
INFO - 2023-03-13 09:45:29 --> Output Class Initialized
INFO - 2023-03-13 09:45:29 --> Security Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:45:29 --> Input Class Initialized
INFO - 2023-03-13 09:45:29 --> Language Class Initialized
INFO - 2023-03-13 09:45:29 --> Loader Class Initialized
INFO - 2023-03-13 09:45:29 --> Controller Class Initialized
DEBUG - 2023-03-13 09:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:45:29 --> Final output sent to browser
DEBUG - 2023-03-13 09:45:29 --> Total execution time: 0.0620
INFO - 2023-03-13 09:47:02 --> Config Class Initialized
INFO - 2023-03-13 09:47:02 --> Config Class Initialized
INFO - 2023-03-13 09:47:02 --> Hooks Class Initialized
INFO - 2023-03-13 09:47:02 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:02 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:02 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:02 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:02 --> URI Class Initialized
INFO - 2023-03-13 09:47:02 --> URI Class Initialized
INFO - 2023-03-13 09:47:02 --> Router Class Initialized
INFO - 2023-03-13 09:47:02 --> Router Class Initialized
INFO - 2023-03-13 09:47:02 --> Output Class Initialized
INFO - 2023-03-13 09:47:02 --> Output Class Initialized
INFO - 2023-03-13 09:47:02 --> Security Class Initialized
INFO - 2023-03-13 09:47:02 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:02 --> Input Class Initialized
INFO - 2023-03-13 09:47:02 --> Input Class Initialized
INFO - 2023-03-13 09:47:02 --> Language Class Initialized
INFO - 2023-03-13 09:47:02 --> Language Class Initialized
INFO - 2023-03-13 09:47:02 --> Loader Class Initialized
INFO - 2023-03-13 09:47:02 --> Loader Class Initialized
INFO - 2023-03-13 09:47:02 --> Controller Class Initialized
INFO - 2023-03-13 09:47:02 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:02 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:02 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:02 --> Model "Login_model" initialized
INFO - 2023-03-13 09:47:02 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:02 --> Total execution time: 0.1354
INFO - 2023-03-13 09:47:02 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:02 --> Total execution time: 0.1419
INFO - 2023-03-13 09:47:02 --> Config Class Initialized
INFO - 2023-03-13 09:47:02 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:02 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:02 --> URI Class Initialized
INFO - 2023-03-13 09:47:02 --> Config Class Initialized
INFO - 2023-03-13 09:47:02 --> Router Class Initialized
INFO - 2023-03-13 09:47:02 --> Hooks Class Initialized
INFO - 2023-03-13 09:47:02 --> Output Class Initialized
DEBUG - 2023-03-13 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:02 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:02 --> Security Class Initialized
INFO - 2023-03-13 09:47:02 --> URI Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:02 --> Input Class Initialized
INFO - 2023-03-13 09:47:02 --> Router Class Initialized
INFO - 2023-03-13 09:47:02 --> Output Class Initialized
INFO - 2023-03-13 09:47:02 --> Language Class Initialized
INFO - 2023-03-13 09:47:02 --> Security Class Initialized
INFO - 2023-03-13 09:47:02 --> Loader Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:02 --> Input Class Initialized
INFO - 2023-03-13 09:47:02 --> Language Class Initialized
INFO - 2023-03-13 09:47:02 --> Loader Class Initialized
INFO - 2023-03-13 09:47:02 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:02 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:02 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:02 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:02 --> Model "Login_model" initialized
INFO - 2023-03-13 09:47:02 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:02 --> Total execution time: 0.0409
INFO - 2023-03-13 09:47:02 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:02 --> Total execution time: 0.0926
INFO - 2023-03-13 09:47:05 --> Config Class Initialized
INFO - 2023-03-13 09:47:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:05 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:05 --> URI Class Initialized
INFO - 2023-03-13 09:47:05 --> Router Class Initialized
INFO - 2023-03-13 09:47:05 --> Output Class Initialized
INFO - 2023-03-13 09:47:05 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:05 --> Input Class Initialized
INFO - 2023-03-13 09:47:05 --> Language Class Initialized
INFO - 2023-03-13 09:47:05 --> Loader Class Initialized
INFO - 2023-03-13 09:47:05 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:05 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:05 --> Total execution time: 0.0045
INFO - 2023-03-13 09:47:05 --> Config Class Initialized
INFO - 2023-03-13 09:47:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:05 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:05 --> URI Class Initialized
INFO - 2023-03-13 09:47:05 --> Router Class Initialized
INFO - 2023-03-13 09:47:05 --> Output Class Initialized
INFO - 2023-03-13 09:47:05 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:05 --> Input Class Initialized
INFO - 2023-03-13 09:47:05 --> Language Class Initialized
INFO - 2023-03-13 09:47:05 --> Loader Class Initialized
INFO - 2023-03-13 09:47:05 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:05 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:05 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:47:05 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:05 --> Total execution time: 0.0143
INFO - 2023-03-13 09:47:15 --> Config Class Initialized
INFO - 2023-03-13 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:15 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:15 --> URI Class Initialized
INFO - 2023-03-13 09:47:15 --> Router Class Initialized
INFO - 2023-03-13 09:47:15 --> Output Class Initialized
INFO - 2023-03-13 09:47:15 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:15 --> Input Class Initialized
INFO - 2023-03-13 09:47:15 --> Language Class Initialized
INFO - 2023-03-13 09:47:15 --> Loader Class Initialized
INFO - 2023-03-13 09:47:15 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:15 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:15 --> Total execution time: 0.0048
INFO - 2023-03-13 09:47:15 --> Config Class Initialized
INFO - 2023-03-13 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:15 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:15 --> URI Class Initialized
INFO - 2023-03-13 09:47:15 --> Router Class Initialized
INFO - 2023-03-13 09:47:15 --> Output Class Initialized
INFO - 2023-03-13 09:47:15 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:15 --> Input Class Initialized
INFO - 2023-03-13 09:47:15 --> Language Class Initialized
INFO - 2023-03-13 09:47:15 --> Loader Class Initialized
INFO - 2023-03-13 09:47:15 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:15 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:15 --> Total execution time: 0.0305
INFO - 2023-03-13 09:47:15 --> Config Class Initialized
INFO - 2023-03-13 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:15 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:15 --> URI Class Initialized
INFO - 2023-03-13 09:47:15 --> Router Class Initialized
INFO - 2023-03-13 09:47:15 --> Output Class Initialized
INFO - 2023-03-13 09:47:15 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:15 --> Input Class Initialized
INFO - 2023-03-13 09:47:15 --> Language Class Initialized
INFO - 2023-03-13 09:47:15 --> Loader Class Initialized
INFO - 2023-03-13 09:47:15 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:15 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:15 --> Total execution time: 0.0861
INFO - 2023-03-13 09:47:15 --> Config Class Initialized
INFO - 2023-03-13 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:15 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:15 --> URI Class Initialized
INFO - 2023-03-13 09:47:15 --> Router Class Initialized
INFO - 2023-03-13 09:47:15 --> Output Class Initialized
INFO - 2023-03-13 09:47:15 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:15 --> Input Class Initialized
INFO - 2023-03-13 09:47:15 --> Language Class Initialized
INFO - 2023-03-13 09:47:15 --> Loader Class Initialized
INFO - 2023-03-13 09:47:15 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:15 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:15 --> Total execution time: 0.0665
INFO - 2023-03-13 09:47:22 --> Config Class Initialized
INFO - 2023-03-13 09:47:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:22 --> URI Class Initialized
INFO - 2023-03-13 09:47:22 --> Router Class Initialized
INFO - 2023-03-13 09:47:22 --> Output Class Initialized
INFO - 2023-03-13 09:47:22 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:22 --> Input Class Initialized
INFO - 2023-03-13 09:47:22 --> Language Class Initialized
INFO - 2023-03-13 09:47:22 --> Loader Class Initialized
INFO - 2023-03-13 09:47:22 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:22 --> Total execution time: 0.0059
INFO - 2023-03-13 09:47:22 --> Config Class Initialized
INFO - 2023-03-13 09:47:22 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:22 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:22 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:22 --> URI Class Initialized
INFO - 2023-03-13 09:47:22 --> Router Class Initialized
INFO - 2023-03-13 09:47:22 --> Output Class Initialized
INFO - 2023-03-13 09:47:22 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:22 --> Input Class Initialized
INFO - 2023-03-13 09:47:22 --> Language Class Initialized
INFO - 2023-03-13 09:47:22 --> Loader Class Initialized
INFO - 2023-03-13 09:47:22 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:22 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:22 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:47:22 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:22 --> Total execution time: 0.0120
INFO - 2023-03-13 09:47:24 --> Config Class Initialized
INFO - 2023-03-13 09:47:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:24 --> URI Class Initialized
INFO - 2023-03-13 09:47:24 --> Router Class Initialized
INFO - 2023-03-13 09:47:24 --> Output Class Initialized
INFO - 2023-03-13 09:47:24 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:24 --> Input Class Initialized
INFO - 2023-03-13 09:47:24 --> Language Class Initialized
INFO - 2023-03-13 09:47:24 --> Loader Class Initialized
INFO - 2023-03-13 09:47:24 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:24 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:24 --> Total execution time: 0.0081
INFO - 2023-03-13 09:47:24 --> Config Class Initialized
INFO - 2023-03-13 09:47:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:24 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:24 --> URI Class Initialized
INFO - 2023-03-13 09:47:24 --> Router Class Initialized
INFO - 2023-03-13 09:47:24 --> Output Class Initialized
INFO - 2023-03-13 09:47:24 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:24 --> Input Class Initialized
INFO - 2023-03-13 09:47:24 --> Language Class Initialized
INFO - 2023-03-13 09:47:24 --> Loader Class Initialized
INFO - 2023-03-13 09:47:24 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:24 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:24 --> Total execution time: 0.0140
INFO - 2023-03-13 09:47:37 --> Config Class Initialized
INFO - 2023-03-13 09:47:37 --> Config Class Initialized
INFO - 2023-03-13 09:47:37 --> Hooks Class Initialized
INFO - 2023-03-13 09:47:37 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:37 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:37 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:37 --> URI Class Initialized
INFO - 2023-03-13 09:47:37 --> URI Class Initialized
INFO - 2023-03-13 09:47:37 --> Router Class Initialized
INFO - 2023-03-13 09:47:37 --> Router Class Initialized
INFO - 2023-03-13 09:47:37 --> Output Class Initialized
INFO - 2023-03-13 09:47:37 --> Output Class Initialized
INFO - 2023-03-13 09:47:37 --> Security Class Initialized
INFO - 2023-03-13 09:47:37 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:37 --> Input Class Initialized
INFO - 2023-03-13 09:47:37 --> Input Class Initialized
INFO - 2023-03-13 09:47:37 --> Language Class Initialized
INFO - 2023-03-13 09:47:37 --> Language Class Initialized
INFO - 2023-03-13 09:47:37 --> Loader Class Initialized
INFO - 2023-03-13 09:47:37 --> Loader Class Initialized
INFO - 2023-03-13 09:47:37 --> Controller Class Initialized
INFO - 2023-03-13 09:47:37 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:47:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:37 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:37 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:37 --> Model "Login_model" initialized
INFO - 2023-03-13 09:47:37 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:37 --> Total execution time: 0.0876
INFO - 2023-03-13 09:47:37 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:37 --> Total execution time: 0.0914
INFO - 2023-03-13 09:47:37 --> Config Class Initialized
INFO - 2023-03-13 09:47:37 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:37 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:37 --> Config Class Initialized
INFO - 2023-03-13 09:47:37 --> URI Class Initialized
INFO - 2023-03-13 09:47:37 --> Hooks Class Initialized
INFO - 2023-03-13 09:47:37 --> Router Class Initialized
DEBUG - 2023-03-13 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:47:37 --> Output Class Initialized
INFO - 2023-03-13 09:47:37 --> Utf8 Class Initialized
INFO - 2023-03-13 09:47:37 --> Security Class Initialized
INFO - 2023-03-13 09:47:37 --> URI Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:37 --> Router Class Initialized
INFO - 2023-03-13 09:47:37 --> Input Class Initialized
INFO - 2023-03-13 09:47:37 --> Output Class Initialized
INFO - 2023-03-13 09:47:37 --> Language Class Initialized
INFO - 2023-03-13 09:47:37 --> Security Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:47:37 --> Loader Class Initialized
INFO - 2023-03-13 09:47:37 --> Input Class Initialized
INFO - 2023-03-13 09:47:37 --> Controller Class Initialized
INFO - 2023-03-13 09:47:37 --> Language Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:37 --> Loader Class Initialized
INFO - 2023-03-13 09:47:37 --> Controller Class Initialized
DEBUG - 2023-03-13 09:47:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:47:37 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:37 --> Database Driver Class Initialized
INFO - 2023-03-13 09:47:37 --> Model "Login_model" initialized
INFO - 2023-03-13 09:47:37 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:37 --> Total execution time: 0.1173
INFO - 2023-03-13 09:47:37 --> Final output sent to browser
DEBUG - 2023-03-13 09:47:37 --> Total execution time: 0.1211
INFO - 2023-03-13 09:48:30 --> Config Class Initialized
INFO - 2023-03-13 09:48:30 --> Config Class Initialized
INFO - 2023-03-13 09:48:30 --> Hooks Class Initialized
INFO - 2023-03-13 09:48:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:48:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:30 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:30 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:30 --> URI Class Initialized
INFO - 2023-03-13 09:48:30 --> URI Class Initialized
INFO - 2023-03-13 09:48:30 --> Router Class Initialized
INFO - 2023-03-13 09:48:30 --> Router Class Initialized
INFO - 2023-03-13 09:48:30 --> Output Class Initialized
INFO - 2023-03-13 09:48:30 --> Output Class Initialized
INFO - 2023-03-13 09:48:30 --> Security Class Initialized
INFO - 2023-03-13 09:48:30 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:30 --> Input Class Initialized
INFO - 2023-03-13 09:48:30 --> Input Class Initialized
INFO - 2023-03-13 09:48:30 --> Language Class Initialized
INFO - 2023-03-13 09:48:30 --> Language Class Initialized
INFO - 2023-03-13 09:48:30 --> Loader Class Initialized
INFO - 2023-03-13 09:48:30 --> Loader Class Initialized
INFO - 2023-03-13 09:48:30 --> Controller Class Initialized
INFO - 2023-03-13 09:48:30 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:48:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:30 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:30 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:48:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:48:30 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:30 --> Total execution time: 0.0255
INFO - 2023-03-13 09:48:30 --> Config Class Initialized
INFO - 2023-03-13 09:48:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:31 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:31 --> URI Class Initialized
INFO - 2023-03-13 09:48:31 --> Router Class Initialized
INFO - 2023-03-13 09:48:31 --> Output Class Initialized
INFO - 2023-03-13 09:48:31 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:31 --> Input Class Initialized
INFO - 2023-03-13 09:48:31 --> Language Class Initialized
INFO - 2023-03-13 09:48:31 --> Loader Class Initialized
INFO - 2023-03-13 09:48:31 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:31 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:31 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:48:31 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:31 --> Total execution time: 0.1889
INFO - 2023-03-13 09:48:31 --> Config Class Initialized
INFO - 2023-03-13 09:48:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:31 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:31 --> URI Class Initialized
INFO - 2023-03-13 09:48:31 --> Router Class Initialized
INFO - 2023-03-13 09:48:31 --> Output Class Initialized
INFO - 2023-03-13 09:48:31 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:31 --> Input Class Initialized
INFO - 2023-03-13 09:48:31 --> Language Class Initialized
INFO - 2023-03-13 09:48:31 --> Loader Class Initialized
INFO - 2023-03-13 09:48:31 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:31 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:31 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:48:32 --> Config Class Initialized
INFO - 2023-03-13 09:48:32 --> Config Class Initialized
INFO - 2023-03-13 09:48:32 --> Hooks Class Initialized
INFO - 2023-03-13 09:48:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:32 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:48:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:32 --> URI Class Initialized
INFO - 2023-03-13 09:48:32 --> URI Class Initialized
INFO - 2023-03-13 09:48:32 --> Router Class Initialized
INFO - 2023-03-13 09:48:32 --> Router Class Initialized
INFO - 2023-03-13 09:48:32 --> Output Class Initialized
INFO - 2023-03-13 09:48:32 --> Output Class Initialized
INFO - 2023-03-13 09:48:32 --> Security Class Initialized
INFO - 2023-03-13 09:48:32 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:32 --> Input Class Initialized
INFO - 2023-03-13 09:48:32 --> Input Class Initialized
INFO - 2023-03-13 09:48:32 --> Language Class Initialized
INFO - 2023-03-13 09:48:32 --> Language Class Initialized
INFO - 2023-03-13 09:48:32 --> Loader Class Initialized
INFO - 2023-03-13 09:48:32 --> Loader Class Initialized
INFO - 2023-03-13 09:48:32 --> Controller Class Initialized
INFO - 2023-03-13 09:48:32 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:32 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:32 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:32 --> Model "Login_model" initialized
INFO - 2023-03-13 09:48:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:32 --> Total execution time: 0.0335
INFO - 2023-03-13 09:48:32 --> Config Class Initialized
INFO - 2023-03-13 09:48:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:32 --> URI Class Initialized
INFO - 2023-03-13 09:48:32 --> Router Class Initialized
INFO - 2023-03-13 09:48:32 --> Output Class Initialized
INFO - 2023-03-13 09:48:32 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:32 --> Input Class Initialized
INFO - 2023-03-13 09:48:32 --> Language Class Initialized
INFO - 2023-03-13 09:48:32 --> Loader Class Initialized
INFO - 2023-03-13 09:48:32 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:32 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:32 --> Database Driver Class Initialized
INFO - 2023-03-13 09:48:32 --> Model "Login_model" initialized
INFO - 2023-03-13 09:48:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:32 --> Total execution time: 0.0237
INFO - 2023-03-13 09:48:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:32 --> Total execution time: 0.0795
INFO - 2023-03-13 09:48:32 --> Config Class Initialized
INFO - 2023-03-13 09:48:32 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:48:32 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:48:32 --> Utf8 Class Initialized
INFO - 2023-03-13 09:48:32 --> URI Class Initialized
INFO - 2023-03-13 09:48:32 --> Router Class Initialized
INFO - 2023-03-13 09:48:32 --> Output Class Initialized
INFO - 2023-03-13 09:48:32 --> Security Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:48:32 --> Input Class Initialized
INFO - 2023-03-13 09:48:32 --> Language Class Initialized
INFO - 2023-03-13 09:48:32 --> Loader Class Initialized
INFO - 2023-03-13 09:48:32 --> Controller Class Initialized
DEBUG - 2023-03-13 09:48:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:48:32 --> Final output sent to browser
DEBUG - 2023-03-13 09:48:32 --> Total execution time: 0.0596
INFO - 2023-03-13 09:57:23 --> Config Class Initialized
INFO - 2023-03-13 09:57:23 --> Config Class Initialized
INFO - 2023-03-13 09:57:23 --> Hooks Class Initialized
INFO - 2023-03-13 09:57:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:57:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:23 --> URI Class Initialized
INFO - 2023-03-13 09:57:23 --> URI Class Initialized
INFO - 2023-03-13 09:57:23 --> Router Class Initialized
INFO - 2023-03-13 09:57:23 --> Router Class Initialized
INFO - 2023-03-13 09:57:23 --> Output Class Initialized
INFO - 2023-03-13 09:57:23 --> Output Class Initialized
INFO - 2023-03-13 09:57:23 --> Security Class Initialized
INFO - 2023-03-13 09:57:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:23 --> Input Class Initialized
INFO - 2023-03-13 09:57:23 --> Input Class Initialized
INFO - 2023-03-13 09:57:23 --> Language Class Initialized
INFO - 2023-03-13 09:57:23 --> Language Class Initialized
INFO - 2023-03-13 09:57:23 --> Loader Class Initialized
INFO - 2023-03-13 09:57:23 --> Loader Class Initialized
INFO - 2023-03-13 09:57:23 --> Controller Class Initialized
INFO - 2023-03-13 09:57:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:23 --> Total execution time: 0.1149
INFO - 2023-03-13 09:57:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:23 --> Total execution time: 0.1183
INFO - 2023-03-13 09:57:23 --> Config Class Initialized
INFO - 2023-03-13 09:57:23 --> Config Class Initialized
INFO - 2023-03-13 09:57:23 --> Hooks Class Initialized
INFO - 2023-03-13 09:57:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:57:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:23 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:23 --> URI Class Initialized
INFO - 2023-03-13 09:57:23 --> URI Class Initialized
INFO - 2023-03-13 09:57:23 --> Router Class Initialized
INFO - 2023-03-13 09:57:23 --> Router Class Initialized
INFO - 2023-03-13 09:57:23 --> Output Class Initialized
INFO - 2023-03-13 09:57:23 --> Output Class Initialized
INFO - 2023-03-13 09:57:23 --> Security Class Initialized
INFO - 2023-03-13 09:57:23 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:23 --> Input Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:23 --> Language Class Initialized
INFO - 2023-03-13 09:57:23 --> Input Class Initialized
INFO - 2023-03-13 09:57:23 --> Language Class Initialized
INFO - 2023-03-13 09:57:23 --> Loader Class Initialized
INFO - 2023-03-13 09:57:23 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:23 --> Loader Class Initialized
INFO - 2023-03-13 09:57:23 --> Controller Class Initialized
INFO - 2023-03-13 09:57:23 --> Database Driver Class Initialized
DEBUG - 2023-03-13 09:57:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:23 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:23 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:23 --> Total execution time: 0.0672
INFO - 2023-03-13 09:57:23 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:23 --> Total execution time: 0.1059
INFO - 2023-03-13 09:57:26 --> Config Class Initialized
INFO - 2023-03-13 09:57:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:26 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:26 --> URI Class Initialized
INFO - 2023-03-13 09:57:26 --> Router Class Initialized
INFO - 2023-03-13 09:57:26 --> Output Class Initialized
INFO - 2023-03-13 09:57:26 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:26 --> Input Class Initialized
INFO - 2023-03-13 09:57:26 --> Language Class Initialized
INFO - 2023-03-13 09:57:26 --> Loader Class Initialized
INFO - 2023-03-13 09:57:26 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:26 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:26 --> Total execution time: 0.0746
INFO - 2023-03-13 09:57:26 --> Config Class Initialized
INFO - 2023-03-13 09:57:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:26 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:26 --> URI Class Initialized
INFO - 2023-03-13 09:57:26 --> Router Class Initialized
INFO - 2023-03-13 09:57:26 --> Output Class Initialized
INFO - 2023-03-13 09:57:26 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:26 --> Input Class Initialized
INFO - 2023-03-13 09:57:26 --> Language Class Initialized
INFO - 2023-03-13 09:57:26 --> Loader Class Initialized
INFO - 2023-03-13 09:57:26 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:26 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:57:26 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:26 --> Total execution time: 0.0527
INFO - 2023-03-13 09:57:35 --> Config Class Initialized
INFO - 2023-03-13 09:57:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:35 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:35 --> URI Class Initialized
INFO - 2023-03-13 09:57:35 --> Router Class Initialized
INFO - 2023-03-13 09:57:35 --> Output Class Initialized
INFO - 2023-03-13 09:57:35 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:35 --> Input Class Initialized
INFO - 2023-03-13 09:57:35 --> Language Class Initialized
INFO - 2023-03-13 09:57:35 --> Loader Class Initialized
INFO - 2023-03-13 09:57:35 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:35 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:57:35 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:35 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:35 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:35 --> Total execution time: 0.2028
INFO - 2023-03-13 09:57:36 --> Config Class Initialized
INFO - 2023-03-13 09:57:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:36 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:36 --> URI Class Initialized
INFO - 2023-03-13 09:57:36 --> Router Class Initialized
INFO - 2023-03-13 09:57:36 --> Output Class Initialized
INFO - 2023-03-13 09:57:36 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:36 --> Input Class Initialized
INFO - 2023-03-13 09:57:36 --> Language Class Initialized
INFO - 2023-03-13 09:57:36 --> Loader Class Initialized
INFO - 2023-03-13 09:57:36 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:36 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 09:57:36 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:36 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:36 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:36 --> Total execution time: 0.1269
INFO - 2023-03-13 09:57:39 --> Config Class Initialized
INFO - 2023-03-13 09:57:39 --> Config Class Initialized
INFO - 2023-03-13 09:57:39 --> Hooks Class Initialized
INFO - 2023-03-13 09:57:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:39 --> URI Class Initialized
INFO - 2023-03-13 09:57:39 --> URI Class Initialized
INFO - 2023-03-13 09:57:39 --> Router Class Initialized
INFO - 2023-03-13 09:57:39 --> Router Class Initialized
INFO - 2023-03-13 09:57:39 --> Output Class Initialized
INFO - 2023-03-13 09:57:39 --> Output Class Initialized
INFO - 2023-03-13 09:57:39 --> Security Class Initialized
INFO - 2023-03-13 09:57:39 --> Security Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:39 --> Input Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:39 --> Language Class Initialized
INFO - 2023-03-13 09:57:39 --> Input Class Initialized
INFO - 2023-03-13 09:57:39 --> Language Class Initialized
INFO - 2023-03-13 09:57:39 --> Loader Class Initialized
INFO - 2023-03-13 09:57:39 --> Loader Class Initialized
INFO - 2023-03-13 09:57:39 --> Controller Class Initialized
INFO - 2023-03-13 09:57:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:57:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:39 --> Total execution time: 0.0346
INFO - 2023-03-13 09:57:39 --> Config Class Initialized
INFO - 2023-03-13 09:57:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:39 --> Total execution time: 0.0786
INFO - 2023-03-13 09:57:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:39 --> URI Class Initialized
INFO - 2023-03-13 09:57:39 --> Config Class Initialized
INFO - 2023-03-13 09:57:39 --> Hooks Class Initialized
INFO - 2023-03-13 09:57:39 --> Router Class Initialized
DEBUG - 2023-03-13 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:57:39 --> Output Class Initialized
INFO - 2023-03-13 09:57:39 --> Utf8 Class Initialized
INFO - 2023-03-13 09:57:39 --> Security Class Initialized
INFO - 2023-03-13 09:57:39 --> URI Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:57:39 --> Input Class Initialized
INFO - 2023-03-13 09:57:39 --> Router Class Initialized
INFO - 2023-03-13 09:57:39 --> Language Class Initialized
INFO - 2023-03-13 09:57:39 --> Output Class Initialized
INFO - 2023-03-13 09:57:39 --> Loader Class Initialized
INFO - 2023-03-13 09:57:39 --> Security Class Initialized
INFO - 2023-03-13 09:57:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:57:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:39 --> Input Class Initialized
INFO - 2023-03-13 09:57:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:39 --> Language Class Initialized
INFO - 2023-03-13 09:57:39 --> Loader Class Initialized
INFO - 2023-03-13 09:57:39 --> Controller Class Initialized
DEBUG - 2023-03-13 09:57:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:57:39 --> Database Driver Class Initialized
INFO - 2023-03-13 09:57:39 --> Model "Login_model" initialized
INFO - 2023-03-13 09:57:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:39 --> Total execution time: 0.0788
INFO - 2023-03-13 09:57:39 --> Final output sent to browser
DEBUG - 2023-03-13 09:57:39 --> Total execution time: 0.0842
INFO - 2023-03-13 09:59:38 --> Config Class Initialized
INFO - 2023-03-13 09:59:38 --> Config Class Initialized
INFO - 2023-03-13 09:59:38 --> Hooks Class Initialized
INFO - 2023-03-13 09:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 09:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:59:38 --> Utf8 Class Initialized
INFO - 2023-03-13 09:59:38 --> Utf8 Class Initialized
INFO - 2023-03-13 09:59:38 --> URI Class Initialized
INFO - 2023-03-13 09:59:38 --> URI Class Initialized
INFO - 2023-03-13 09:59:38 --> Router Class Initialized
INFO - 2023-03-13 09:59:38 --> Router Class Initialized
INFO - 2023-03-13 09:59:38 --> Output Class Initialized
INFO - 2023-03-13 09:59:38 --> Output Class Initialized
INFO - 2023-03-13 09:59:38 --> Security Class Initialized
INFO - 2023-03-13 09:59:38 --> Security Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:59:38 --> Input Class Initialized
INFO - 2023-03-13 09:59:38 --> Input Class Initialized
INFO - 2023-03-13 09:59:38 --> Language Class Initialized
INFO - 2023-03-13 09:59:38 --> Language Class Initialized
INFO - 2023-03-13 09:59:38 --> Loader Class Initialized
INFO - 2023-03-13 09:59:38 --> Loader Class Initialized
INFO - 2023-03-13 09:59:38 --> Controller Class Initialized
INFO - 2023-03-13 09:59:38 --> Controller Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 09:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:59:38 --> Database Driver Class Initialized
INFO - 2023-03-13 09:59:38 --> Database Driver Class Initialized
INFO - 2023-03-13 09:59:38 --> Model "Login_model" initialized
INFO - 2023-03-13 09:59:38 --> Final output sent to browser
DEBUG - 2023-03-13 09:59:38 --> Total execution time: 0.0582
INFO - 2023-03-13 09:59:38 --> Config Class Initialized
INFO - 2023-03-13 09:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:59:38 --> Utf8 Class Initialized
INFO - 2023-03-13 09:59:38 --> URI Class Initialized
INFO - 2023-03-13 09:59:38 --> Router Class Initialized
INFO - 2023-03-13 09:59:38 --> Output Class Initialized
INFO - 2023-03-13 09:59:38 --> Security Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:59:38 --> Input Class Initialized
INFO - 2023-03-13 09:59:38 --> Language Class Initialized
INFO - 2023-03-13 09:59:38 --> Loader Class Initialized
INFO - 2023-03-13 09:59:38 --> Controller Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:59:38 --> Database Driver Class Initialized
INFO - 2023-03-13 09:59:38 --> Database Driver Class Initialized
INFO - 2023-03-13 09:59:38 --> Model "Login_model" initialized
INFO - 2023-03-13 09:59:38 --> Final output sent to browser
DEBUG - 2023-03-13 09:59:38 --> Total execution time: 0.0271
INFO - 2023-03-13 09:59:38 --> Final output sent to browser
DEBUG - 2023-03-13 09:59:38 --> Total execution time: 0.1025
INFO - 2023-03-13 09:59:38 --> Config Class Initialized
INFO - 2023-03-13 09:59:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 09:59:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 09:59:38 --> Utf8 Class Initialized
INFO - 2023-03-13 09:59:38 --> URI Class Initialized
INFO - 2023-03-13 09:59:38 --> Router Class Initialized
INFO - 2023-03-13 09:59:38 --> Output Class Initialized
INFO - 2023-03-13 09:59:38 --> Security Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 09:59:38 --> Input Class Initialized
INFO - 2023-03-13 09:59:38 --> Language Class Initialized
INFO - 2023-03-13 09:59:38 --> Loader Class Initialized
INFO - 2023-03-13 09:59:38 --> Controller Class Initialized
DEBUG - 2023-03-13 09:59:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 09:59:38 --> Final output sent to browser
DEBUG - 2023-03-13 09:59:38 --> Total execution time: 0.0826
INFO - 2023-03-13 10:00:24 --> Config Class Initialized
INFO - 2023-03-13 10:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:24 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:24 --> URI Class Initialized
INFO - 2023-03-13 10:00:24 --> Router Class Initialized
INFO - 2023-03-13 10:00:24 --> Output Class Initialized
INFO - 2023-03-13 10:00:24 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:24 --> Input Class Initialized
INFO - 2023-03-13 10:00:24 --> Language Class Initialized
INFO - 2023-03-13 10:00:24 --> Loader Class Initialized
INFO - 2023-03-13 10:00:24 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:24 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:24 --> Total execution time: 0.0025
INFO - 2023-03-13 10:00:24 --> Config Class Initialized
INFO - 2023-03-13 10:00:24 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:24 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:24 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:24 --> URI Class Initialized
INFO - 2023-03-13 10:00:24 --> Router Class Initialized
INFO - 2023-03-13 10:00:24 --> Output Class Initialized
INFO - 2023-03-13 10:00:24 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:24 --> Input Class Initialized
INFO - 2023-03-13 10:00:24 --> Language Class Initialized
INFO - 2023-03-13 10:00:24 --> Loader Class Initialized
INFO - 2023-03-13 10:00:24 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:24 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:24 --> Model "Login_model" initialized
INFO - 2023-03-13 10:00:24 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:24 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:24 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:24 --> Total execution time: 0.0269
INFO - 2023-03-13 10:00:25 --> Config Class Initialized
INFO - 2023-03-13 10:00:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:25 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:25 --> URI Class Initialized
INFO - 2023-03-13 10:00:25 --> Config Class Initialized
INFO - 2023-03-13 10:00:25 --> Hooks Class Initialized
INFO - 2023-03-13 10:00:25 --> Router Class Initialized
DEBUG - 2023-03-13 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:25 --> Output Class Initialized
INFO - 2023-03-13 10:00:25 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:25 --> Security Class Initialized
INFO - 2023-03-13 10:00:25 --> URI Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:25 --> Input Class Initialized
INFO - 2023-03-13 10:00:25 --> Router Class Initialized
INFO - 2023-03-13 10:00:25 --> Language Class Initialized
INFO - 2023-03-13 10:00:25 --> Output Class Initialized
INFO - 2023-03-13 10:00:25 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:25 --> Loader Class Initialized
INFO - 2023-03-13 10:00:25 --> Input Class Initialized
INFO - 2023-03-13 10:00:25 --> Controller Class Initialized
INFO - 2023-03-13 10:00:25 --> Language Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:25 --> Loader Class Initialized
INFO - 2023-03-13 10:00:25 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:25 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:25 --> Total execution time: 0.0312
INFO - 2023-03-13 10:00:25 --> Config Class Initialized
INFO - 2023-03-13 10:00:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:25 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:25 --> URI Class Initialized
INFO - 2023-03-13 10:00:25 --> Router Class Initialized
INFO - 2023-03-13 10:00:25 --> Output Class Initialized
INFO - 2023-03-13 10:00:25 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:25 --> Input Class Initialized
INFO - 2023-03-13 10:00:25 --> Language Class Initialized
INFO - 2023-03-13 10:00:25 --> Loader Class Initialized
INFO - 2023-03-13 10:00:25 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:25 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:26 --> Total execution time: 0.0196
INFO - 2023-03-13 10:00:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:26 --> Total execution time: 0.1223
INFO - 2023-03-13 10:00:26 --> Config Class Initialized
INFO - 2023-03-13 10:00:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:26 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:26 --> URI Class Initialized
INFO - 2023-03-13 10:00:26 --> Router Class Initialized
INFO - 2023-03-13 10:00:26 --> Output Class Initialized
INFO - 2023-03-13 10:00:26 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:26 --> Input Class Initialized
INFO - 2023-03-13 10:00:26 --> Language Class Initialized
INFO - 2023-03-13 10:00:26 --> Loader Class Initialized
INFO - 2023-03-13 10:00:26 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:26 --> Total execution time: 0.0736
INFO - 2023-03-13 10:00:26 --> Config Class Initialized
INFO - 2023-03-13 10:00:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:26 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:26 --> URI Class Initialized
INFO - 2023-03-13 10:00:26 --> Router Class Initialized
INFO - 2023-03-13 10:00:26 --> Output Class Initialized
INFO - 2023-03-13 10:00:26 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:26 --> Input Class Initialized
INFO - 2023-03-13 10:00:26 --> Language Class Initialized
INFO - 2023-03-13 10:00:26 --> Loader Class Initialized
INFO - 2023-03-13 10:00:26 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:26 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:26 --> Total execution time: 0.0179
INFO - 2023-03-13 10:00:27 --> Config Class Initialized
INFO - 2023-03-13 10:00:27 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:27 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:27 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:27 --> URI Class Initialized
INFO - 2023-03-13 10:00:27 --> Router Class Initialized
INFO - 2023-03-13 10:00:27 --> Output Class Initialized
INFO - 2023-03-13 10:00:27 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:27 --> Input Class Initialized
INFO - 2023-03-13 10:00:27 --> Language Class Initialized
INFO - 2023-03-13 10:00:27 --> Loader Class Initialized
INFO - 2023-03-13 10:00:27 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:27 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:27 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:27 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:27 --> Total execution time: 0.0394
INFO - 2023-03-13 10:00:28 --> Config Class Initialized
INFO - 2023-03-13 10:00:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:28 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:28 --> URI Class Initialized
INFO - 2023-03-13 10:00:28 --> Router Class Initialized
INFO - 2023-03-13 10:00:28 --> Output Class Initialized
INFO - 2023-03-13 10:00:28 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:28 --> Input Class Initialized
INFO - 2023-03-13 10:00:28 --> Language Class Initialized
INFO - 2023-03-13 10:00:28 --> Loader Class Initialized
INFO - 2023-03-13 10:00:28 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:28 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:28 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:28 --> Total execution time: 0.0145
INFO - 2023-03-13 10:00:29 --> Config Class Initialized
INFO - 2023-03-13 10:00:29 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:29 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:29 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:29 --> URI Class Initialized
INFO - 2023-03-13 10:00:29 --> Router Class Initialized
INFO - 2023-03-13 10:00:29 --> Output Class Initialized
INFO - 2023-03-13 10:00:29 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:29 --> Input Class Initialized
INFO - 2023-03-13 10:00:29 --> Language Class Initialized
INFO - 2023-03-13 10:00:29 --> Loader Class Initialized
INFO - 2023-03-13 10:00:29 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:29 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:29 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:29 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:29 --> Total execution time: 0.0173
INFO - 2023-03-13 10:00:30 --> Config Class Initialized
INFO - 2023-03-13 10:00:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:30 --> URI Class Initialized
INFO - 2023-03-13 10:00:30 --> Router Class Initialized
INFO - 2023-03-13 10:00:30 --> Output Class Initialized
INFO - 2023-03-13 10:00:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:30 --> Input Class Initialized
INFO - 2023-03-13 10:00:30 --> Language Class Initialized
INFO - 2023-03-13 10:00:30 --> Loader Class Initialized
INFO - 2023-03-13 10:00:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:30 --> Total execution time: 0.0175
INFO - 2023-03-13 10:00:31 --> Config Class Initialized
INFO - 2023-03-13 10:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:31 --> URI Class Initialized
INFO - 2023-03-13 10:00:31 --> Router Class Initialized
INFO - 2023-03-13 10:00:31 --> Output Class Initialized
INFO - 2023-03-13 10:00:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:31 --> Input Class Initialized
INFO - 2023-03-13 10:00:31 --> Language Class Initialized
INFO - 2023-03-13 10:00:31 --> Loader Class Initialized
INFO - 2023-03-13 10:00:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:31 --> Total execution time: 0.0036
INFO - 2023-03-13 10:00:31 --> Config Class Initialized
INFO - 2023-03-13 10:00:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:31 --> URI Class Initialized
INFO - 2023-03-13 10:00:31 --> Router Class Initialized
INFO - 2023-03-13 10:00:31 --> Output Class Initialized
INFO - 2023-03-13 10:00:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:31 --> Input Class Initialized
INFO - 2023-03-13 10:00:31 --> Language Class Initialized
INFO - 2023-03-13 10:00:31 --> Loader Class Initialized
INFO - 2023-03-13 10:00:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:31 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:31 --> Total execution time: 0.0168
INFO - 2023-03-13 10:00:38 --> Config Class Initialized
INFO - 2023-03-13 10:00:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:38 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:38 --> URI Class Initialized
INFO - 2023-03-13 10:00:38 --> Router Class Initialized
INFO - 2023-03-13 10:00:38 --> Output Class Initialized
INFO - 2023-03-13 10:00:38 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:38 --> Input Class Initialized
INFO - 2023-03-13 10:00:38 --> Language Class Initialized
INFO - 2023-03-13 10:00:38 --> Loader Class Initialized
INFO - 2023-03-13 10:00:38 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:38 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:38 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:38 --> Model "Login_model" initialized
INFO - 2023-03-13 10:00:38 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:38 --> Total execution time: 0.1238
INFO - 2023-03-13 10:00:38 --> Config Class Initialized
INFO - 2023-03-13 10:00:38 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:38 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:38 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:38 --> URI Class Initialized
INFO - 2023-03-13 10:00:38 --> Router Class Initialized
INFO - 2023-03-13 10:00:38 --> Output Class Initialized
INFO - 2023-03-13 10:00:38 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:38 --> Input Class Initialized
INFO - 2023-03-13 10:00:38 --> Language Class Initialized
INFO - 2023-03-13 10:00:38 --> Loader Class Initialized
INFO - 2023-03-13 10:00:38 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:38 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:38 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:38 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:38 --> Model "Login_model" initialized
INFO - 2023-03-13 10:00:38 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:38 --> Total execution time: 0.0336
INFO - 2023-03-13 10:00:46 --> Config Class Initialized
INFO - 2023-03-13 10:00:46 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:46 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:46 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:46 --> URI Class Initialized
INFO - 2023-03-13 10:00:46 --> Router Class Initialized
INFO - 2023-03-13 10:00:46 --> Output Class Initialized
INFO - 2023-03-13 10:00:46 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:46 --> Input Class Initialized
INFO - 2023-03-13 10:00:46 --> Language Class Initialized
INFO - 2023-03-13 10:00:46 --> Loader Class Initialized
INFO - 2023-03-13 10:00:46 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:46 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:46 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:47 --> Config Class Initialized
INFO - 2023-03-13 10:00:47 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:47 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:47 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:47 --> URI Class Initialized
INFO - 2023-03-13 10:00:47 --> Router Class Initialized
INFO - 2023-03-13 10:00:47 --> Output Class Initialized
INFO - 2023-03-13 10:00:47 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:47 --> Input Class Initialized
INFO - 2023-03-13 10:00:47 --> Language Class Initialized
INFO - 2023-03-13 10:00:47 --> Loader Class Initialized
INFO - 2023-03-13 10:00:47 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:47 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:47 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:48 --> Config Class Initialized
INFO - 2023-03-13 10:00:48 --> Config Class Initialized
INFO - 2023-03-13 10:00:48 --> Hooks Class Initialized
INFO - 2023-03-13 10:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:48 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:48 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:48 --> URI Class Initialized
INFO - 2023-03-13 10:00:48 --> URI Class Initialized
INFO - 2023-03-13 10:00:48 --> Router Class Initialized
INFO - 2023-03-13 10:00:48 --> Router Class Initialized
INFO - 2023-03-13 10:00:48 --> Output Class Initialized
INFO - 2023-03-13 10:00:48 --> Output Class Initialized
INFO - 2023-03-13 10:00:48 --> Security Class Initialized
INFO - 2023-03-13 10:00:48 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:48 --> Input Class Initialized
INFO - 2023-03-13 10:00:48 --> Input Class Initialized
INFO - 2023-03-13 10:00:48 --> Language Class Initialized
INFO - 2023-03-13 10:00:48 --> Language Class Initialized
INFO - 2023-03-13 10:00:48 --> Loader Class Initialized
INFO - 2023-03-13 10:00:48 --> Loader Class Initialized
INFO - 2023-03-13 10:00:48 --> Controller Class Initialized
INFO - 2023-03-13 10:00:48 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:48 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:48 --> Total execution time: 0.0691
INFO - 2023-03-13 10:00:48 --> Config Class Initialized
INFO - 2023-03-13 10:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:48 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:48 --> URI Class Initialized
INFO - 2023-03-13 10:00:48 --> Router Class Initialized
INFO - 2023-03-13 10:00:48 --> Output Class Initialized
INFO - 2023-03-13 10:00:48 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:48 --> Input Class Initialized
INFO - 2023-03-13 10:00:48 --> Language Class Initialized
INFO - 2023-03-13 10:00:48 --> Loader Class Initialized
INFO - 2023-03-13 10:00:48 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:48 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:48 --> Total execution time: 0.0994
INFO - 2023-03-13 10:00:49 --> Config Class Initialized
INFO - 2023-03-13 10:00:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:49 --> URI Class Initialized
INFO - 2023-03-13 10:00:49 --> Router Class Initialized
INFO - 2023-03-13 10:00:49 --> Output Class Initialized
INFO - 2023-03-13 10:00:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:49 --> Input Class Initialized
INFO - 2023-03-13 10:00:49 --> Language Class Initialized
INFO - 2023-03-13 10:00:49 --> Loader Class Initialized
INFO - 2023-03-13 10:00:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:00:49 --> Config Class Initialized
INFO - 2023-03-13 10:00:49 --> Config Class Initialized
INFO - 2023-03-13 10:00:49 --> Hooks Class Initialized
INFO - 2023-03-13 10:00:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:00:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:49 --> URI Class Initialized
INFO - 2023-03-13 10:00:49 --> URI Class Initialized
INFO - 2023-03-13 10:00:49 --> Router Class Initialized
INFO - 2023-03-13 10:00:49 --> Router Class Initialized
INFO - 2023-03-13 10:00:49 --> Output Class Initialized
INFO - 2023-03-13 10:00:49 --> Output Class Initialized
INFO - 2023-03-13 10:00:49 --> Security Class Initialized
INFO - 2023-03-13 10:00:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:49 --> Input Class Initialized
INFO - 2023-03-13 10:00:49 --> Input Class Initialized
INFO - 2023-03-13 10:00:49 --> Language Class Initialized
INFO - 2023-03-13 10:00:49 --> Language Class Initialized
INFO - 2023-03-13 10:00:49 --> Loader Class Initialized
INFO - 2023-03-13 10:00:49 --> Controller Class Initialized
INFO - 2023-03-13 10:00:49 --> Loader Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:49 --> Controller Class Initialized
INFO - 2023-03-13 10:00:49 --> Database Driver Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:49 --> Model "Login_model" initialized
INFO - 2023-03-13 10:00:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:49 --> Total execution time: 0.0962
INFO - 2023-03-13 10:00:49 --> Config Class Initialized
INFO - 2023-03-13 10:00:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:49 --> URI Class Initialized
INFO - 2023-03-13 10:00:49 --> Router Class Initialized
INFO - 2023-03-13 10:00:49 --> Output Class Initialized
INFO - 2023-03-13 10:00:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:49 --> Input Class Initialized
INFO - 2023-03-13 10:00:49 --> Language Class Initialized
INFO - 2023-03-13 10:00:49 --> Loader Class Initialized
INFO - 2023-03-13 10:00:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:00:49 --> Model "Login_model" initialized
INFO - 2023-03-13 10:00:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:49 --> Total execution time: 0.1113
INFO - 2023-03-13 10:00:50 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:50 --> Total execution time: 0.3150
INFO - 2023-03-13 10:00:50 --> Config Class Initialized
INFO - 2023-03-13 10:00:50 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:00:50 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:00:50 --> Utf8 Class Initialized
INFO - 2023-03-13 10:00:50 --> URI Class Initialized
INFO - 2023-03-13 10:00:50 --> Router Class Initialized
INFO - 2023-03-13 10:00:50 --> Output Class Initialized
INFO - 2023-03-13 10:00:50 --> Security Class Initialized
DEBUG - 2023-03-13 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:00:50 --> Input Class Initialized
INFO - 2023-03-13 10:00:50 --> Language Class Initialized
INFO - 2023-03-13 10:00:50 --> Loader Class Initialized
INFO - 2023-03-13 10:00:50 --> Controller Class Initialized
DEBUG - 2023-03-13 10:00:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:00:50 --> Final output sent to browser
DEBUG - 2023-03-13 10:00:50 --> Total execution time: 0.2947
INFO - 2023-03-13 10:02:40 --> Config Class Initialized
INFO - 2023-03-13 10:02:40 --> Config Class Initialized
INFO - 2023-03-13 10:02:40 --> Hooks Class Initialized
INFO - 2023-03-13 10:02:40 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:02:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:02:40 --> Utf8 Class Initialized
INFO - 2023-03-13 10:02:40 --> Utf8 Class Initialized
INFO - 2023-03-13 10:02:40 --> URI Class Initialized
INFO - 2023-03-13 10:02:40 --> URI Class Initialized
INFO - 2023-03-13 10:02:40 --> Router Class Initialized
INFO - 2023-03-13 10:02:40 --> Router Class Initialized
INFO - 2023-03-13 10:02:40 --> Output Class Initialized
INFO - 2023-03-13 10:02:40 --> Output Class Initialized
INFO - 2023-03-13 10:02:40 --> Security Class Initialized
INFO - 2023-03-13 10:02:40 --> Security Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:02:40 --> Input Class Initialized
INFO - 2023-03-13 10:02:40 --> Input Class Initialized
INFO - 2023-03-13 10:02:40 --> Language Class Initialized
INFO - 2023-03-13 10:02:40 --> Language Class Initialized
INFO - 2023-03-13 10:02:40 --> Loader Class Initialized
INFO - 2023-03-13 10:02:40 --> Loader Class Initialized
INFO - 2023-03-13 10:02:40 --> Controller Class Initialized
INFO - 2023-03-13 10:02:40 --> Controller Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:02:40 --> Database Driver Class Initialized
INFO - 2023-03-13 10:02:40 --> Database Driver Class Initialized
INFO - 2023-03-13 10:02:40 --> Model "Login_model" initialized
INFO - 2023-03-13 10:02:40 --> Final output sent to browser
DEBUG - 2023-03-13 10:02:40 --> Total execution time: 0.0399
INFO - 2023-03-13 10:02:40 --> Config Class Initialized
INFO - 2023-03-13 10:02:40 --> Final output sent to browser
DEBUG - 2023-03-13 10:02:40 --> Total execution time: 0.0771
INFO - 2023-03-13 10:02:40 --> Config Class Initialized
INFO - 2023-03-13 10:02:40 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:02:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:02:40 --> Utf8 Class Initialized
INFO - 2023-03-13 10:02:40 --> URI Class Initialized
INFO - 2023-03-13 10:02:40 --> Router Class Initialized
INFO - 2023-03-13 10:02:40 --> Output Class Initialized
INFO - 2023-03-13 10:02:40 --> Security Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:02:40 --> Input Class Initialized
INFO - 2023-03-13 10:02:40 --> Hooks Class Initialized
INFO - 2023-03-13 10:02:40 --> Language Class Initialized
DEBUG - 2023-03-13 10:02:40 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:02:40 --> Loader Class Initialized
INFO - 2023-03-13 10:02:40 --> Utf8 Class Initialized
INFO - 2023-03-13 10:02:40 --> Controller Class Initialized
INFO - 2023-03-13 10:02:40 --> URI Class Initialized
INFO - 2023-03-13 10:02:40 --> Router Class Initialized
INFO - 2023-03-13 10:02:40 --> Output Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:02:40 --> Security Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:02:40 --> Input Class Initialized
INFO - 2023-03-13 10:02:40 --> Language Class Initialized
INFO - 2023-03-13 10:02:40 --> Loader Class Initialized
INFO - 2023-03-13 10:02:40 --> Controller Class Initialized
DEBUG - 2023-03-13 10:02:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:02:40 --> Database Driver Class Initialized
INFO - 2023-03-13 10:02:40 --> Database Driver Class Initialized
INFO - 2023-03-13 10:02:40 --> Model "Login_model" initialized
INFO - 2023-03-13 10:02:40 --> Final output sent to browser
DEBUG - 2023-03-13 10:02:40 --> Total execution time: 0.0632
INFO - 2023-03-13 10:02:40 --> Final output sent to browser
DEBUG - 2023-03-13 10:02:40 --> Total execution time: 0.0757
INFO - 2023-03-13 10:04:41 --> Config Class Initialized
INFO - 2023-03-13 10:04:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:41 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:41 --> URI Class Initialized
INFO - 2023-03-13 10:04:41 --> Router Class Initialized
INFO - 2023-03-13 10:04:41 --> Output Class Initialized
INFO - 2023-03-13 10:04:41 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:41 --> Input Class Initialized
INFO - 2023-03-13 10:04:41 --> Language Class Initialized
INFO - 2023-03-13 10:04:41 --> Loader Class Initialized
INFO - 2023-03-13 10:04:41 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:41 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:41 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:41 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:41 --> Total execution time: 0.0155
INFO - 2023-03-13 10:04:41 --> Config Class Initialized
INFO - 2023-03-13 10:04:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:41 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:41 --> URI Class Initialized
INFO - 2023-03-13 10:04:41 --> Router Class Initialized
INFO - 2023-03-13 10:04:41 --> Output Class Initialized
INFO - 2023-03-13 10:04:41 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:41 --> Input Class Initialized
INFO - 2023-03-13 10:04:41 --> Language Class Initialized
INFO - 2023-03-13 10:04:41 --> Loader Class Initialized
INFO - 2023-03-13 10:04:41 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:41 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:41 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:41 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:41 --> Total execution time: 0.0555
INFO - 2023-03-13 10:04:43 --> Config Class Initialized
INFO - 2023-03-13 10:04:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:43 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:43 --> URI Class Initialized
INFO - 2023-03-13 10:04:43 --> Router Class Initialized
INFO - 2023-03-13 10:04:43 --> Output Class Initialized
INFO - 2023-03-13 10:04:43 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:43 --> Input Class Initialized
INFO - 2023-03-13 10:04:43 --> Language Class Initialized
INFO - 2023-03-13 10:04:43 --> Loader Class Initialized
INFO - 2023-03-13 10:04:43 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:43 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:43 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:43 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:43 --> Total execution time: 0.1811
INFO - 2023-03-13 10:04:43 --> Config Class Initialized
INFO - 2023-03-13 10:04:43 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:43 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:43 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:43 --> URI Class Initialized
INFO - 2023-03-13 10:04:43 --> Router Class Initialized
INFO - 2023-03-13 10:04:43 --> Output Class Initialized
INFO - 2023-03-13 10:04:43 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:43 --> Input Class Initialized
INFO - 2023-03-13 10:04:43 --> Language Class Initialized
INFO - 2023-03-13 10:04:43 --> Loader Class Initialized
INFO - 2023-03-13 10:04:43 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:43 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:43 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:43 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:43 --> Total execution time: 0.0848
INFO - 2023-03-13 10:04:48 --> Config Class Initialized
INFO - 2023-03-13 10:04:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:49 --> URI Class Initialized
INFO - 2023-03-13 10:04:49 --> Router Class Initialized
INFO - 2023-03-13 10:04:49 --> Output Class Initialized
INFO - 2023-03-13 10:04:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:49 --> Input Class Initialized
INFO - 2023-03-13 10:04:49 --> Language Class Initialized
INFO - 2023-03-13 10:04:49 --> Loader Class Initialized
INFO - 2023-03-13 10:04:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:49 --> Total execution time: 0.0260
INFO - 2023-03-13 10:04:49 --> Config Class Initialized
INFO - 2023-03-13 10:04:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:49 --> URI Class Initialized
INFO - 2023-03-13 10:04:49 --> Router Class Initialized
INFO - 2023-03-13 10:04:49 --> Output Class Initialized
INFO - 2023-03-13 10:04:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:49 --> Input Class Initialized
INFO - 2023-03-13 10:04:49 --> Language Class Initialized
INFO - 2023-03-13 10:04:49 --> Loader Class Initialized
INFO - 2023-03-13 10:04:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:49 --> Total execution time: 0.0112
INFO - 2023-03-13 10:04:52 --> Config Class Initialized
INFO - 2023-03-13 10:04:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:52 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:52 --> URI Class Initialized
INFO - 2023-03-13 10:04:52 --> Router Class Initialized
INFO - 2023-03-13 10:04:52 --> Output Class Initialized
INFO - 2023-03-13 10:04:52 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:52 --> Input Class Initialized
INFO - 2023-03-13 10:04:52 --> Language Class Initialized
INFO - 2023-03-13 10:04:52 --> Loader Class Initialized
INFO - 2023-03-13 10:04:52 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:52 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:52 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:52 --> Total execution time: 0.0450
INFO - 2023-03-13 10:04:52 --> Config Class Initialized
INFO - 2023-03-13 10:04:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:52 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:52 --> URI Class Initialized
INFO - 2023-03-13 10:04:52 --> Router Class Initialized
INFO - 2023-03-13 10:04:52 --> Output Class Initialized
INFO - 2023-03-13 10:04:52 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:52 --> Input Class Initialized
INFO - 2023-03-13 10:04:52 --> Language Class Initialized
INFO - 2023-03-13 10:04:52 --> Loader Class Initialized
INFO - 2023-03-13 10:04:52 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:52 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:52 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:52 --> Total execution time: 0.0414
INFO - 2023-03-13 10:04:53 --> Config Class Initialized
INFO - 2023-03-13 10:04:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:53 --> URI Class Initialized
INFO - 2023-03-13 10:04:53 --> Router Class Initialized
INFO - 2023-03-13 10:04:53 --> Output Class Initialized
INFO - 2023-03-13 10:04:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:53 --> Input Class Initialized
INFO - 2023-03-13 10:04:53 --> Language Class Initialized
INFO - 2023-03-13 10:04:53 --> Loader Class Initialized
INFO - 2023-03-13 10:04:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:04:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:53 --> Total execution time: 0.0425
INFO - 2023-03-13 10:04:53 --> Config Class Initialized
INFO - 2023-03-13 10:04:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:53 --> URI Class Initialized
INFO - 2023-03-13 10:04:53 --> Router Class Initialized
INFO - 2023-03-13 10:04:53 --> Output Class Initialized
INFO - 2023-03-13 10:04:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:53 --> Input Class Initialized
INFO - 2023-03-13 10:04:53 --> Language Class Initialized
INFO - 2023-03-13 10:04:53 --> Loader Class Initialized
INFO - 2023-03-13 10:04:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:53 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:04:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:53 --> Total execution time: 0.0336
INFO - 2023-03-13 10:04:55 --> Config Class Initialized
INFO - 2023-03-13 10:04:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:55 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:55 --> URI Class Initialized
INFO - 2023-03-13 10:04:55 --> Router Class Initialized
INFO - 2023-03-13 10:04:55 --> Output Class Initialized
INFO - 2023-03-13 10:04:55 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:55 --> Input Class Initialized
INFO - 2023-03-13 10:04:55 --> Language Class Initialized
INFO - 2023-03-13 10:04:55 --> Loader Class Initialized
INFO - 2023-03-13 10:04:55 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:55 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:55 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:55 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:55 --> Total execution time: 0.0181
INFO - 2023-03-13 10:04:55 --> Config Class Initialized
INFO - 2023-03-13 10:04:55 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:55 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:55 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:55 --> URI Class Initialized
INFO - 2023-03-13 10:04:55 --> Router Class Initialized
INFO - 2023-03-13 10:04:55 --> Output Class Initialized
INFO - 2023-03-13 10:04:55 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:55 --> Input Class Initialized
INFO - 2023-03-13 10:04:55 --> Language Class Initialized
INFO - 2023-03-13 10:04:55 --> Loader Class Initialized
INFO - 2023-03-13 10:04:55 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:55 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:55 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:55 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:55 --> Total execution time: 0.0126
INFO - 2023-03-13 10:04:57 --> Config Class Initialized
INFO - 2023-03-13 10:04:57 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:04:57 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:04:57 --> Utf8 Class Initialized
INFO - 2023-03-13 10:04:57 --> URI Class Initialized
INFO - 2023-03-13 10:04:57 --> Router Class Initialized
INFO - 2023-03-13 10:04:57 --> Output Class Initialized
INFO - 2023-03-13 10:04:57 --> Security Class Initialized
DEBUG - 2023-03-13 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:04:57 --> Input Class Initialized
INFO - 2023-03-13 10:04:57 --> Language Class Initialized
INFO - 2023-03-13 10:04:57 --> Loader Class Initialized
INFO - 2023-03-13 10:04:57 --> Controller Class Initialized
DEBUG - 2023-03-13 10:04:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:04:57 --> Database Driver Class Initialized
INFO - 2023-03-13 10:04:57 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:04:57 --> Final output sent to browser
DEBUG - 2023-03-13 10:04:57 --> Total execution time: 0.0806
INFO - 2023-03-13 10:05:01 --> Config Class Initialized
INFO - 2023-03-13 10:05:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:05:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:05:01 --> Utf8 Class Initialized
INFO - 2023-03-13 10:05:01 --> URI Class Initialized
INFO - 2023-03-13 10:05:01 --> Router Class Initialized
INFO - 2023-03-13 10:05:01 --> Output Class Initialized
INFO - 2023-03-13 10:05:01 --> Security Class Initialized
DEBUG - 2023-03-13 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:05:01 --> Input Class Initialized
INFO - 2023-03-13 10:05:01 --> Language Class Initialized
INFO - 2023-03-13 10:05:01 --> Loader Class Initialized
INFO - 2023-03-13 10:05:01 --> Controller Class Initialized
DEBUG - 2023-03-13 10:05:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:05:01 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:05:01 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:01 --> Model "Login_model" initialized
INFO - 2023-03-13 10:05:01 --> Final output sent to browser
DEBUG - 2023-03-13 10:05:01 --> Total execution time: 0.0371
INFO - 2023-03-13 10:05:01 --> Config Class Initialized
INFO - 2023-03-13 10:05:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:05:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:05:01 --> Utf8 Class Initialized
INFO - 2023-03-13 10:05:01 --> URI Class Initialized
INFO - 2023-03-13 10:05:01 --> Router Class Initialized
INFO - 2023-03-13 10:05:01 --> Output Class Initialized
INFO - 2023-03-13 10:05:01 --> Security Class Initialized
DEBUG - 2023-03-13 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:05:01 --> Input Class Initialized
INFO - 2023-03-13 10:05:01 --> Language Class Initialized
INFO - 2023-03-13 10:05:01 --> Loader Class Initialized
INFO - 2023-03-13 10:05:01 --> Controller Class Initialized
DEBUG - 2023-03-13 10:05:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:05:01 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:02 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:05:02 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:02 --> Model "Login_model" initialized
INFO - 2023-03-13 10:05:02 --> Final output sent to browser
DEBUG - 2023-03-13 10:05:02 --> Total execution time: 0.1446
INFO - 2023-03-13 10:05:03 --> Config Class Initialized
INFO - 2023-03-13 10:05:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:05:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:05:03 --> Utf8 Class Initialized
INFO - 2023-03-13 10:05:03 --> URI Class Initialized
INFO - 2023-03-13 10:05:03 --> Router Class Initialized
INFO - 2023-03-13 10:05:03 --> Output Class Initialized
INFO - 2023-03-13 10:05:03 --> Security Class Initialized
DEBUG - 2023-03-13 10:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:05:03 --> Input Class Initialized
INFO - 2023-03-13 10:05:03 --> Language Class Initialized
INFO - 2023-03-13 10:05:03 --> Loader Class Initialized
INFO - 2023-03-13 10:05:03 --> Controller Class Initialized
DEBUG - 2023-03-13 10:05:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:05:03 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:05:03 --> Final output sent to browser
DEBUG - 2023-03-13 10:05:03 --> Total execution time: 0.0148
INFO - 2023-03-13 10:05:03 --> Config Class Initialized
INFO - 2023-03-13 10:05:03 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:05:03 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:05:03 --> Utf8 Class Initialized
INFO - 2023-03-13 10:05:03 --> URI Class Initialized
INFO - 2023-03-13 10:05:03 --> Router Class Initialized
INFO - 2023-03-13 10:05:03 --> Output Class Initialized
INFO - 2023-03-13 10:05:03 --> Security Class Initialized
DEBUG - 2023-03-13 10:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:05:03 --> Input Class Initialized
INFO - 2023-03-13 10:05:03 --> Language Class Initialized
INFO - 2023-03-13 10:05:03 --> Loader Class Initialized
INFO - 2023-03-13 10:05:03 --> Controller Class Initialized
DEBUG - 2023-03-13 10:05:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:05:03 --> Database Driver Class Initialized
INFO - 2023-03-13 10:05:03 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:05:03 --> Final output sent to browser
DEBUG - 2023-03-13 10:05:03 --> Total execution time: 0.0116
INFO - 2023-03-13 10:15:18 --> Config Class Initialized
INFO - 2023-03-13 10:15:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:15:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:15:18 --> Utf8 Class Initialized
INFO - 2023-03-13 10:15:18 --> URI Class Initialized
INFO - 2023-03-13 10:15:18 --> Router Class Initialized
INFO - 2023-03-13 10:15:18 --> Output Class Initialized
INFO - 2023-03-13 10:15:18 --> Security Class Initialized
DEBUG - 2023-03-13 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:15:18 --> Input Class Initialized
INFO - 2023-03-13 10:15:18 --> Language Class Initialized
INFO - 2023-03-13 10:15:18 --> Loader Class Initialized
INFO - 2023-03-13 10:15:18 --> Controller Class Initialized
DEBUG - 2023-03-13 10:15:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:15:18 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:15:18 --> Final output sent to browser
DEBUG - 2023-03-13 10:15:18 --> Total execution time: 0.0798
INFO - 2023-03-13 10:15:18 --> Config Class Initialized
INFO - 2023-03-13 10:15:18 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:15:18 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:15:18 --> Utf8 Class Initialized
INFO - 2023-03-13 10:15:18 --> URI Class Initialized
INFO - 2023-03-13 10:15:18 --> Router Class Initialized
INFO - 2023-03-13 10:15:18 --> Output Class Initialized
INFO - 2023-03-13 10:15:18 --> Security Class Initialized
DEBUG - 2023-03-13 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:15:18 --> Input Class Initialized
INFO - 2023-03-13 10:15:18 --> Language Class Initialized
INFO - 2023-03-13 10:15:18 --> Loader Class Initialized
INFO - 2023-03-13 10:15:18 --> Controller Class Initialized
DEBUG - 2023-03-13 10:15:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:15:18 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:18 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:15:18 --> Final output sent to browser
DEBUG - 2023-03-13 10:15:18 --> Total execution time: 0.0910
INFO - 2023-03-13 10:15:21 --> Config Class Initialized
INFO - 2023-03-13 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:15:21 --> Utf8 Class Initialized
INFO - 2023-03-13 10:15:21 --> URI Class Initialized
INFO - 2023-03-13 10:15:21 --> Router Class Initialized
INFO - 2023-03-13 10:15:21 --> Output Class Initialized
INFO - 2023-03-13 10:15:21 --> Security Class Initialized
DEBUG - 2023-03-13 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:15:21 --> Input Class Initialized
INFO - 2023-03-13 10:15:21 --> Language Class Initialized
INFO - 2023-03-13 10:15:21 --> Loader Class Initialized
INFO - 2023-03-13 10:15:21 --> Controller Class Initialized
DEBUG - 2023-03-13 10:15:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:15:21 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:15:21 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:21 --> Model "Login_model" initialized
INFO - 2023-03-13 10:15:21 --> Final output sent to browser
DEBUG - 2023-03-13 10:15:21 --> Total execution time: 0.2153
INFO - 2023-03-13 10:15:21 --> Config Class Initialized
INFO - 2023-03-13 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:15:21 --> Utf8 Class Initialized
INFO - 2023-03-13 10:15:21 --> URI Class Initialized
INFO - 2023-03-13 10:15:21 --> Router Class Initialized
INFO - 2023-03-13 10:15:21 --> Output Class Initialized
INFO - 2023-03-13 10:15:21 --> Security Class Initialized
DEBUG - 2023-03-13 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:15:21 --> Input Class Initialized
INFO - 2023-03-13 10:15:21 --> Language Class Initialized
INFO - 2023-03-13 10:15:21 --> Loader Class Initialized
INFO - 2023-03-13 10:15:21 --> Controller Class Initialized
DEBUG - 2023-03-13 10:15:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:15:21 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:21 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:15:21 --> Database Driver Class Initialized
INFO - 2023-03-13 10:15:21 --> Model "Login_model" initialized
INFO - 2023-03-13 10:15:21 --> Final output sent to browser
DEBUG - 2023-03-13 10:15:21 --> Total execution time: 0.0826
INFO - 2023-03-13 10:16:31 --> Config Class Initialized
INFO - 2023-03-13 10:16:31 --> Config Class Initialized
INFO - 2023-03-13 10:16:31 --> Hooks Class Initialized
INFO - 2023-03-13 10:16:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:16:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:16:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:16:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:16:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:16:31 --> URI Class Initialized
INFO - 2023-03-13 10:16:31 --> URI Class Initialized
INFO - 2023-03-13 10:16:31 --> Router Class Initialized
INFO - 2023-03-13 10:16:31 --> Router Class Initialized
INFO - 2023-03-13 10:16:31 --> Output Class Initialized
INFO - 2023-03-13 10:16:31 --> Output Class Initialized
INFO - 2023-03-13 10:16:31 --> Security Class Initialized
INFO - 2023-03-13 10:16:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:16:31 --> Input Class Initialized
INFO - 2023-03-13 10:16:31 --> Input Class Initialized
INFO - 2023-03-13 10:16:31 --> Language Class Initialized
INFO - 2023-03-13 10:16:31 --> Language Class Initialized
INFO - 2023-03-13 10:16:31 --> Loader Class Initialized
INFO - 2023-03-13 10:16:31 --> Loader Class Initialized
INFO - 2023-03-13 10:16:31 --> Controller Class Initialized
INFO - 2023-03-13 10:16:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:16:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:16:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:16:31 --> Model "Login_model" initialized
INFO - 2023-03-13 10:16:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:16:31 --> Total execution time: 0.0309
INFO - 2023-03-13 10:16:31 --> Config Class Initialized
INFO - 2023-03-13 10:16:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:16:31 --> Total execution time: 0.0630
INFO - 2023-03-13 10:16:31 --> Config Class Initialized
INFO - 2023-03-13 10:16:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:16:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:16:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:16:31 --> URI Class Initialized
INFO - 2023-03-13 10:16:31 --> Router Class Initialized
INFO - 2023-03-13 10:16:31 --> Output Class Initialized
INFO - 2023-03-13 10:16:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:16:31 --> Input Class Initialized
INFO - 2023-03-13 10:16:31 --> Language Class Initialized
INFO - 2023-03-13 10:16:31 --> Loader Class Initialized
INFO - 2023-03-13 10:16:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:16:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:16:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:16:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:16:31 --> URI Class Initialized
INFO - 2023-03-13 10:16:31 --> Router Class Initialized
INFO - 2023-03-13 10:16:31 --> Output Class Initialized
INFO - 2023-03-13 10:16:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:16:31 --> Input Class Initialized
INFO - 2023-03-13 10:16:31 --> Language Class Initialized
INFO - 2023-03-13 10:16:31 --> Loader Class Initialized
INFO - 2023-03-13 10:16:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:16:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:16:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:16:31 --> Model "Login_model" initialized
INFO - 2023-03-13 10:16:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:16:31 --> Total execution time: 0.0634
INFO - 2023-03-13 10:16:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:16:31 --> Total execution time: 0.0592
INFO - 2023-03-13 10:19:49 --> Config Class Initialized
INFO - 2023-03-13 10:19:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:19:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:19:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:19:49 --> URI Class Initialized
INFO - 2023-03-13 10:19:49 --> Router Class Initialized
INFO - 2023-03-13 10:19:49 --> Output Class Initialized
INFO - 2023-03-13 10:19:49 --> Security Class Initialized
INFO - 2023-03-13 10:19:49 --> Config Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:19:49 --> Input Class Initialized
INFO - 2023-03-13 10:19:49 --> Language Class Initialized
INFO - 2023-03-13 10:19:49 --> Loader Class Initialized
INFO - 2023-03-13 10:19:49 --> Hooks Class Initialized
INFO - 2023-03-13 10:19:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:19:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:19:49 --> URI Class Initialized
INFO - 2023-03-13 10:19:49 --> Router Class Initialized
INFO - 2023-03-13 10:19:49 --> Output Class Initialized
INFO - 2023-03-13 10:19:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:19:49 --> Input Class Initialized
INFO - 2023-03-13 10:19:49 --> Language Class Initialized
INFO - 2023-03-13 10:19:49 --> Loader Class Initialized
INFO - 2023-03-13 10:19:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:19:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:19:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:19:49 --> Model "Login_model" initialized
INFO - 2023-03-13 10:19:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:19:49 --> Total execution time: 0.0675
INFO - 2023-03-13 10:19:49 --> Config Class Initialized
INFO - 2023-03-13 10:19:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:19:49 --> Total execution time: 0.1156
INFO - 2023-03-13 10:19:49 --> Config Class Initialized
INFO - 2023-03-13 10:19:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:19:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:19:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:19:49 --> URI Class Initialized
INFO - 2023-03-13 10:19:49 --> Router Class Initialized
INFO - 2023-03-13 10:19:49 --> Output Class Initialized
INFO - 2023-03-13 10:19:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:19:49 --> Input Class Initialized
INFO - 2023-03-13 10:19:49 --> Hooks Class Initialized
INFO - 2023-03-13 10:19:49 --> Language Class Initialized
DEBUG - 2023-03-13 10:19:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:19:49 --> Loader Class Initialized
INFO - 2023-03-13 10:19:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:19:49 --> Controller Class Initialized
INFO - 2023-03-13 10:19:49 --> URI Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:19:49 --> Router Class Initialized
INFO - 2023-03-13 10:19:49 --> Output Class Initialized
INFO - 2023-03-13 10:19:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:19:49 --> Input Class Initialized
INFO - 2023-03-13 10:19:49 --> Language Class Initialized
INFO - 2023-03-13 10:19:49 --> Loader Class Initialized
INFO - 2023-03-13 10:19:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:19:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:19:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:19:49 --> Model "Login_model" initialized
INFO - 2023-03-13 10:19:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:19:49 --> Total execution time: 0.1125
INFO - 2023-03-13 10:19:50 --> Final output sent to browser
DEBUG - 2023-03-13 10:19:50 --> Total execution time: 0.1043
INFO - 2023-03-13 10:22:33 --> Config Class Initialized
INFO - 2023-03-13 10:22:33 --> Config Class Initialized
INFO - 2023-03-13 10:22:33 --> Hooks Class Initialized
INFO - 2023-03-13 10:22:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:33 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:22:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:33 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:33 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:33 --> URI Class Initialized
INFO - 2023-03-13 10:22:33 --> URI Class Initialized
INFO - 2023-03-13 10:22:33 --> Router Class Initialized
INFO - 2023-03-13 10:22:33 --> Router Class Initialized
INFO - 2023-03-13 10:22:33 --> Output Class Initialized
INFO - 2023-03-13 10:22:33 --> Output Class Initialized
INFO - 2023-03-13 10:22:33 --> Security Class Initialized
INFO - 2023-03-13 10:22:33 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:33 --> Input Class Initialized
INFO - 2023-03-13 10:22:33 --> Input Class Initialized
INFO - 2023-03-13 10:22:33 --> Language Class Initialized
INFO - 2023-03-13 10:22:33 --> Language Class Initialized
INFO - 2023-03-13 10:22:33 --> Loader Class Initialized
INFO - 2023-03-13 10:22:33 --> Loader Class Initialized
INFO - 2023-03-13 10:22:33 --> Controller Class Initialized
INFO - 2023-03-13 10:22:33 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:22:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:33 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:33 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:33 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:33 --> Final output sent to browser
INFO - 2023-03-13 10:22:33 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:33 --> Total execution time: 0.0836
DEBUG - 2023-03-13 10:22:33 --> Total execution time: 0.0900
INFO - 2023-03-13 10:22:33 --> Config Class Initialized
INFO - 2023-03-13 10:22:33 --> Config Class Initialized
INFO - 2023-03-13 10:22:33 --> Hooks Class Initialized
INFO - 2023-03-13 10:22:34 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:22:34 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:34 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:34 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:34 --> URI Class Initialized
INFO - 2023-03-13 10:22:34 --> URI Class Initialized
INFO - 2023-03-13 10:22:34 --> Router Class Initialized
INFO - 2023-03-13 10:22:34 --> Router Class Initialized
INFO - 2023-03-13 10:22:34 --> Output Class Initialized
INFO - 2023-03-13 10:22:34 --> Output Class Initialized
INFO - 2023-03-13 10:22:34 --> Security Class Initialized
INFO - 2023-03-13 10:22:34 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:34 --> Input Class Initialized
INFO - 2023-03-13 10:22:34 --> Input Class Initialized
INFO - 2023-03-13 10:22:34 --> Language Class Initialized
INFO - 2023-03-13 10:22:34 --> Language Class Initialized
INFO - 2023-03-13 10:22:34 --> Loader Class Initialized
INFO - 2023-03-13 10:22:34 --> Loader Class Initialized
INFO - 2023-03-13 10:22:34 --> Controller Class Initialized
INFO - 2023-03-13 10:22:34 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:22:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:34 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:34 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:34 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:34 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:34 --> Total execution time: 0.0723
INFO - 2023-03-13 10:22:34 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:34 --> Total execution time: 0.1155
INFO - 2023-03-13 10:22:48 --> Config Class Initialized
INFO - 2023-03-13 10:22:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:48 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:48 --> URI Class Initialized
INFO - 2023-03-13 10:22:48 --> Router Class Initialized
INFO - 2023-03-13 10:22:48 --> Output Class Initialized
INFO - 2023-03-13 10:22:48 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:48 --> Input Class Initialized
INFO - 2023-03-13 10:22:48 --> Language Class Initialized
INFO - 2023-03-13 10:22:48 --> Loader Class Initialized
INFO - 2023-03-13 10:22:48 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:22:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:48 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:48 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:48 --> Total execution time: 0.1426
INFO - 2023-03-13 10:22:48 --> Config Class Initialized
INFO - 2023-03-13 10:22:48 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:48 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:48 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:48 --> URI Class Initialized
INFO - 2023-03-13 10:22:48 --> Router Class Initialized
INFO - 2023-03-13 10:22:48 --> Output Class Initialized
INFO - 2023-03-13 10:22:48 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:48 --> Input Class Initialized
INFO - 2023-03-13 10:22:48 --> Language Class Initialized
INFO - 2023-03-13 10:22:48 --> Loader Class Initialized
INFO - 2023-03-13 10:22:48 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:48 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:22:48 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:48 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:48 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:48 --> Total execution time: 0.0789
INFO - 2023-03-13 10:22:53 --> Config Class Initialized
INFO - 2023-03-13 10:22:53 --> Config Class Initialized
INFO - 2023-03-13 10:22:53 --> Hooks Class Initialized
INFO - 2023-03-13 10:22:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:22:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:53 --> URI Class Initialized
INFO - 2023-03-13 10:22:53 --> URI Class Initialized
INFO - 2023-03-13 10:22:53 --> Router Class Initialized
INFO - 2023-03-13 10:22:53 --> Router Class Initialized
INFO - 2023-03-13 10:22:53 --> Output Class Initialized
INFO - 2023-03-13 10:22:53 --> Output Class Initialized
INFO - 2023-03-13 10:22:53 --> Security Class Initialized
INFO - 2023-03-13 10:22:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:53 --> Input Class Initialized
INFO - 2023-03-13 10:22:53 --> Input Class Initialized
INFO - 2023-03-13 10:22:53 --> Language Class Initialized
INFO - 2023-03-13 10:22:53 --> Language Class Initialized
INFO - 2023-03-13 10:22:53 --> Loader Class Initialized
INFO - 2023-03-13 10:22:53 --> Loader Class Initialized
INFO - 2023-03-13 10:22:53 --> Controller Class Initialized
INFO - 2023-03-13 10:22:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:53 --> Total execution time: 0.0310
INFO - 2023-03-13 10:22:53 --> Config Class Initialized
INFO - 2023-03-13 10:22:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:53 --> Total execution time: 0.0725
INFO - 2023-03-13 10:22:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:53 --> URI Class Initialized
INFO - 2023-03-13 10:22:53 --> Router Class Initialized
INFO - 2023-03-13 10:22:53 --> Output Class Initialized
INFO - 2023-03-13 10:22:53 --> Config Class Initialized
INFO - 2023-03-13 10:22:53 --> Security Class Initialized
INFO - 2023-03-13 10:22:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:22:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:22:53 --> Input Class Initialized
INFO - 2023-03-13 10:22:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:22:53 --> Language Class Initialized
INFO - 2023-03-13 10:22:53 --> URI Class Initialized
INFO - 2023-03-13 10:22:53 --> Loader Class Initialized
INFO - 2023-03-13 10:22:53 --> Router Class Initialized
INFO - 2023-03-13 10:22:53 --> Controller Class Initialized
INFO - 2023-03-13 10:22:53 --> Output Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:22:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:53 --> Input Class Initialized
INFO - 2023-03-13 10:22:53 --> Language Class Initialized
INFO - 2023-03-13 10:22:53 --> Loader Class Initialized
INFO - 2023-03-13 10:22:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:22:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:22:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:22:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:22:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:53 --> Total execution time: 0.0659
INFO - 2023-03-13 10:22:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:22:53 --> Total execution time: 0.0711
INFO - 2023-03-13 10:28:39 --> Config Class Initialized
INFO - 2023-03-13 10:28:39 --> Config Class Initialized
INFO - 2023-03-13 10:28:39 --> Hooks Class Initialized
INFO - 2023-03-13 10:28:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 10:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 10:28:39 --> URI Class Initialized
INFO - 2023-03-13 10:28:39 --> URI Class Initialized
INFO - 2023-03-13 10:28:39 --> Router Class Initialized
INFO - 2023-03-13 10:28:39 --> Output Class Initialized
INFO - 2023-03-13 10:28:39 --> Security Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:28:39 --> Input Class Initialized
INFO - 2023-03-13 10:28:39 --> Language Class Initialized
INFO - 2023-03-13 10:28:39 --> Loader Class Initialized
INFO - 2023-03-13 10:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:28:39 --> Router Class Initialized
INFO - 2023-03-13 10:28:39 --> Output Class Initialized
INFO - 2023-03-13 10:28:39 --> Security Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:28:39 --> Input Class Initialized
INFO - 2023-03-13 10:28:39 --> Language Class Initialized
INFO - 2023-03-13 10:28:39 --> Loader Class Initialized
INFO - 2023-03-13 10:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 10:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 10:28:39 --> Model "Login_model" initialized
INFO - 2023-03-13 10:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 10:28:39 --> Total execution time: 0.0836
INFO - 2023-03-13 10:28:39 --> Config Class Initialized
INFO - 2023-03-13 10:28:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 10:28:39 --> URI Class Initialized
INFO - 2023-03-13 10:28:39 --> Final output sent to browser
INFO - 2023-03-13 10:28:39 --> Router Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Total execution time: 0.0964
INFO - 2023-03-13 10:28:39 --> Output Class Initialized
INFO - 2023-03-13 10:28:39 --> Security Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:28:39 --> Input Class Initialized
INFO - 2023-03-13 10:28:39 --> Language Class Initialized
INFO - 2023-03-13 10:28:39 --> Loader Class Initialized
INFO - 2023-03-13 10:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:28:39 --> Config Class Initialized
INFO - 2023-03-13 10:28:39 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:28:39 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:28:39 --> Utf8 Class Initialized
INFO - 2023-03-13 10:28:39 --> URI Class Initialized
INFO - 2023-03-13 10:28:39 --> Router Class Initialized
INFO - 2023-03-13 10:28:39 --> Output Class Initialized
INFO - 2023-03-13 10:28:39 --> Security Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:28:39 --> Input Class Initialized
INFO - 2023-03-13 10:28:39 --> Language Class Initialized
INFO - 2023-03-13 10:28:39 --> Loader Class Initialized
INFO - 2023-03-13 10:28:39 --> Controller Class Initialized
DEBUG - 2023-03-13 10:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 10:28:39 --> Database Driver Class Initialized
INFO - 2023-03-13 10:28:39 --> Model "Login_model" initialized
INFO - 2023-03-13 10:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 10:28:39 --> Total execution time: 0.1088
INFO - 2023-03-13 10:28:39 --> Final output sent to browser
DEBUG - 2023-03-13 10:28:39 --> Total execution time: 0.1182
INFO - 2023-03-13 10:29:28 --> Config Class Initialized
INFO - 2023-03-13 10:29:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:28 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:28 --> URI Class Initialized
INFO - 2023-03-13 10:29:28 --> Router Class Initialized
INFO - 2023-03-13 10:29:28 --> Output Class Initialized
INFO - 2023-03-13 10:29:28 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:28 --> Input Class Initialized
INFO - 2023-03-13 10:29:28 --> Language Class Initialized
INFO - 2023-03-13 10:29:28 --> Loader Class Initialized
INFO - 2023-03-13 10:29:28 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:28 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:28 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:28 --> Total execution time: 0.0168
INFO - 2023-03-13 10:29:28 --> Config Class Initialized
INFO - 2023-03-13 10:29:28 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:28 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:28 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:28 --> URI Class Initialized
INFO - 2023-03-13 10:29:28 --> Router Class Initialized
INFO - 2023-03-13 10:29:28 --> Output Class Initialized
INFO - 2023-03-13 10:29:28 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:28 --> Input Class Initialized
INFO - 2023-03-13 10:29:28 --> Language Class Initialized
INFO - 2023-03-13 10:29:28 --> Loader Class Initialized
INFO - 2023-03-13 10:29:28 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:28 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:28 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:28 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:28 --> Total execution time: 0.0519
INFO - 2023-03-13 10:29:30 --> Config Class Initialized
INFO - 2023-03-13 10:29:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:30 --> URI Class Initialized
INFO - 2023-03-13 10:29:30 --> Router Class Initialized
INFO - 2023-03-13 10:29:30 --> Output Class Initialized
INFO - 2023-03-13 10:29:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:30 --> Input Class Initialized
INFO - 2023-03-13 10:29:30 --> Language Class Initialized
INFO - 2023-03-13 10:29:30 --> Loader Class Initialized
INFO - 2023-03-13 10:29:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:30 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:30 --> Total execution time: 0.0610
INFO - 2023-03-13 10:29:30 --> Config Class Initialized
INFO - 2023-03-13 10:29:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:30 --> URI Class Initialized
INFO - 2023-03-13 10:29:30 --> Router Class Initialized
INFO - 2023-03-13 10:29:30 --> Output Class Initialized
INFO - 2023-03-13 10:29:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:30 --> Input Class Initialized
INFO - 2023-03-13 10:29:30 --> Language Class Initialized
INFO - 2023-03-13 10:29:30 --> Loader Class Initialized
INFO - 2023-03-13 10:29:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:30 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:30 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:30 --> Total execution time: 0.0605
INFO - 2023-03-13 10:29:33 --> Config Class Initialized
INFO - 2023-03-13 10:29:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:33 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:33 --> URI Class Initialized
INFO - 2023-03-13 10:29:33 --> Router Class Initialized
INFO - 2023-03-13 10:29:33 --> Output Class Initialized
INFO - 2023-03-13 10:29:33 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:33 --> Input Class Initialized
INFO - 2023-03-13 10:29:33 --> Language Class Initialized
INFO - 2023-03-13 10:29:33 --> Loader Class Initialized
INFO - 2023-03-13 10:29:33 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:33 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:33 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:33 --> Total execution time: 0.0191
INFO - 2023-03-13 10:29:33 --> Config Class Initialized
INFO - 2023-03-13 10:29:33 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:33 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:33 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:33 --> URI Class Initialized
INFO - 2023-03-13 10:29:33 --> Router Class Initialized
INFO - 2023-03-13 10:29:33 --> Output Class Initialized
INFO - 2023-03-13 10:29:33 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:33 --> Input Class Initialized
INFO - 2023-03-13 10:29:33 --> Language Class Initialized
INFO - 2023-03-13 10:29:33 --> Loader Class Initialized
INFO - 2023-03-13 10:29:33 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:33 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:33 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:33 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:33 --> Total execution time: 0.0136
INFO - 2023-03-13 10:29:35 --> Config Class Initialized
INFO - 2023-03-13 10:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:35 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:35 --> URI Class Initialized
INFO - 2023-03-13 10:29:35 --> Router Class Initialized
INFO - 2023-03-13 10:29:35 --> Output Class Initialized
INFO - 2023-03-13 10:29:35 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:35 --> Input Class Initialized
INFO - 2023-03-13 10:29:35 --> Language Class Initialized
INFO - 2023-03-13 10:29:35 --> Loader Class Initialized
INFO - 2023-03-13 10:29:35 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:35 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:35 --> Total execution time: 0.0044
INFO - 2023-03-13 10:29:35 --> Config Class Initialized
INFO - 2023-03-13 10:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:35 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:35 --> URI Class Initialized
INFO - 2023-03-13 10:29:35 --> Router Class Initialized
INFO - 2023-03-13 10:29:35 --> Output Class Initialized
INFO - 2023-03-13 10:29:35 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:35 --> Input Class Initialized
INFO - 2023-03-13 10:29:35 --> Language Class Initialized
INFO - 2023-03-13 10:29:35 --> Loader Class Initialized
INFO - 2023-03-13 10:29:35 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:35 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:35 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:35 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:35 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:35 --> Total execution time: 0.0782
INFO - 2023-03-13 10:29:35 --> Config Class Initialized
INFO - 2023-03-13 10:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:35 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:35 --> URI Class Initialized
INFO - 2023-03-13 10:29:35 --> Router Class Initialized
INFO - 2023-03-13 10:29:35 --> Output Class Initialized
INFO - 2023-03-13 10:29:35 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:35 --> Input Class Initialized
INFO - 2023-03-13 10:29:35 --> Language Class Initialized
INFO - 2023-03-13 10:29:35 --> Loader Class Initialized
INFO - 2023-03-13 10:29:35 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:35 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:35 --> Total execution time: 0.0424
INFO - 2023-03-13 10:29:35 --> Config Class Initialized
INFO - 2023-03-13 10:29:35 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:35 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:35 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:35 --> URI Class Initialized
INFO - 2023-03-13 10:29:35 --> Router Class Initialized
INFO - 2023-03-13 10:29:35 --> Output Class Initialized
INFO - 2023-03-13 10:29:35 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:35 --> Input Class Initialized
INFO - 2023-03-13 10:29:35 --> Language Class Initialized
INFO - 2023-03-13 10:29:35 --> Loader Class Initialized
INFO - 2023-03-13 10:29:35 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:35 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:35 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:35 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:35 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:35 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:35 --> Total execution time: 0.0220
INFO - 2023-03-13 10:29:36 --> Config Class Initialized
INFO - 2023-03-13 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:36 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:36 --> URI Class Initialized
INFO - 2023-03-13 10:29:36 --> Router Class Initialized
INFO - 2023-03-13 10:29:36 --> Output Class Initialized
INFO - 2023-03-13 10:29:36 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:36 --> Input Class Initialized
INFO - 2023-03-13 10:29:36 --> Language Class Initialized
INFO - 2023-03-13 10:29:36 --> Loader Class Initialized
INFO - 2023-03-13 10:29:36 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:36 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:36 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:36 --> Total execution time: 0.0362
INFO - 2023-03-13 10:29:36 --> Config Class Initialized
INFO - 2023-03-13 10:29:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:29:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:29:36 --> Utf8 Class Initialized
INFO - 2023-03-13 10:29:36 --> URI Class Initialized
INFO - 2023-03-13 10:29:36 --> Router Class Initialized
INFO - 2023-03-13 10:29:36 --> Output Class Initialized
INFO - 2023-03-13 10:29:36 --> Security Class Initialized
DEBUG - 2023-03-13 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:29:36 --> Input Class Initialized
INFO - 2023-03-13 10:29:36 --> Language Class Initialized
INFO - 2023-03-13 10:29:36 --> Loader Class Initialized
INFO - 2023-03-13 10:29:36 --> Controller Class Initialized
DEBUG - 2023-03-13 10:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:29:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:29:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:29:36 --> Model "Login_model" initialized
INFO - 2023-03-13 10:29:36 --> Final output sent to browser
DEBUG - 2023-03-13 10:29:36 --> Total execution time: 0.0505
INFO - 2023-03-13 10:32:02 --> Config Class Initialized
INFO - 2023-03-13 10:32:02 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:02 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:02 --> URI Class Initialized
INFO - 2023-03-13 10:32:02 --> Router Class Initialized
INFO - 2023-03-13 10:32:02 --> Output Class Initialized
INFO - 2023-03-13 10:32:02 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:02 --> Input Class Initialized
INFO - 2023-03-13 10:32:02 --> Language Class Initialized
INFO - 2023-03-13 10:32:02 --> Loader Class Initialized
INFO - 2023-03-13 10:32:02 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:02 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:02 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:02 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:02 --> Total execution time: 0.1379
INFO - 2023-03-13 10:32:02 --> Config Class Initialized
INFO - 2023-03-13 10:32:02 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:02 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:02 --> URI Class Initialized
INFO - 2023-03-13 10:32:02 --> Router Class Initialized
INFO - 2023-03-13 10:32:02 --> Output Class Initialized
INFO - 2023-03-13 10:32:02 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:02 --> Input Class Initialized
INFO - 2023-03-13 10:32:02 --> Language Class Initialized
INFO - 2023-03-13 10:32:02 --> Loader Class Initialized
INFO - 2023-03-13 10:32:02 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:02 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:02 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:02 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:02 --> Total execution time: 0.1232
INFO - 2023-03-13 10:32:04 --> Config Class Initialized
INFO - 2023-03-13 10:32:04 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:04 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:04 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:04 --> URI Class Initialized
INFO - 2023-03-13 10:32:04 --> Router Class Initialized
INFO - 2023-03-13 10:32:04 --> Output Class Initialized
INFO - 2023-03-13 10:32:04 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:04 --> Input Class Initialized
INFO - 2023-03-13 10:32:04 --> Language Class Initialized
INFO - 2023-03-13 10:32:04 --> Loader Class Initialized
INFO - 2023-03-13 10:32:04 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:04 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:04 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:04 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:04 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:04 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:04 --> Total execution time: 0.0413
INFO - 2023-03-13 10:32:04 --> Config Class Initialized
INFO - 2023-03-13 10:32:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:05 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:05 --> URI Class Initialized
INFO - 2023-03-13 10:32:05 --> Router Class Initialized
INFO - 2023-03-13 10:32:05 --> Output Class Initialized
INFO - 2023-03-13 10:32:05 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:05 --> Input Class Initialized
INFO - 2023-03-13 10:32:05 --> Language Class Initialized
INFO - 2023-03-13 10:32:05 --> Loader Class Initialized
INFO - 2023-03-13 10:32:05 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:05 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:05 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:05 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:05 --> Total execution time: 0.0755
INFO - 2023-03-13 10:32:08 --> Config Class Initialized
INFO - 2023-03-13 10:32:08 --> Config Class Initialized
INFO - 2023-03-13 10:32:08 --> Hooks Class Initialized
INFO - 2023-03-13 10:32:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:32:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:08 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:08 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:08 --> URI Class Initialized
INFO - 2023-03-13 10:32:08 --> URI Class Initialized
INFO - 2023-03-13 10:32:08 --> Router Class Initialized
INFO - 2023-03-13 10:32:08 --> Router Class Initialized
INFO - 2023-03-13 10:32:08 --> Output Class Initialized
INFO - 2023-03-13 10:32:08 --> Output Class Initialized
INFO - 2023-03-13 10:32:08 --> Security Class Initialized
INFO - 2023-03-13 10:32:08 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:08 --> Input Class Initialized
INFO - 2023-03-13 10:32:08 --> Input Class Initialized
INFO - 2023-03-13 10:32:08 --> Language Class Initialized
INFO - 2023-03-13 10:32:08 --> Language Class Initialized
INFO - 2023-03-13 10:32:08 --> Loader Class Initialized
INFO - 2023-03-13 10:32:08 --> Loader Class Initialized
INFO - 2023-03-13 10:32:08 --> Controller Class Initialized
INFO - 2023-03-13 10:32:08 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:08 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:08 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:08 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:08 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:08 --> Total execution time: 0.1002
INFO - 2023-03-13 10:32:08 --> Config Class Initialized
INFO - 2023-03-13 10:32:08 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:08 --> Total execution time: 0.1327
INFO - 2023-03-13 10:32:08 --> Config Class Initialized
INFO - 2023-03-13 10:32:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:08 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:08 --> URI Class Initialized
INFO - 2023-03-13 10:32:08 --> Router Class Initialized
INFO - 2023-03-13 10:32:08 --> Output Class Initialized
INFO - 2023-03-13 10:32:08 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:08 --> Input Class Initialized
INFO - 2023-03-13 10:32:08 --> Language Class Initialized
INFO - 2023-03-13 10:32:08 --> Loader Class Initialized
INFO - 2023-03-13 10:32:08 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:08 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:08 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:08 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:08 --> URI Class Initialized
INFO - 2023-03-13 10:32:08 --> Router Class Initialized
INFO - 2023-03-13 10:32:08 --> Output Class Initialized
INFO - 2023-03-13 10:32:08 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:08 --> Input Class Initialized
INFO - 2023-03-13 10:32:08 --> Language Class Initialized
INFO - 2023-03-13 10:32:08 --> Loader Class Initialized
INFO - 2023-03-13 10:32:08 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:08 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:08 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:08 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:08 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:08 --> Total execution time: 0.0688
INFO - 2023-03-13 10:32:08 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:08 --> Total execution time: 0.0801
INFO - 2023-03-13 10:32:51 --> Config Class Initialized
INFO - 2023-03-13 10:32:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:51 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:51 --> URI Class Initialized
INFO - 2023-03-13 10:32:51 --> Router Class Initialized
INFO - 2023-03-13 10:32:51 --> Output Class Initialized
INFO - 2023-03-13 10:32:51 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:51 --> Input Class Initialized
INFO - 2023-03-13 10:32:51 --> Language Class Initialized
INFO - 2023-03-13 10:32:51 --> Loader Class Initialized
INFO - 2023-03-13 10:32:51 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:51 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:51 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:51 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:51 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:51 --> Total execution time: 0.1787
INFO - 2023-03-13 10:32:51 --> Config Class Initialized
INFO - 2023-03-13 10:32:51 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:32:51 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:32:51 --> Utf8 Class Initialized
INFO - 2023-03-13 10:32:51 --> URI Class Initialized
INFO - 2023-03-13 10:32:51 --> Router Class Initialized
INFO - 2023-03-13 10:32:51 --> Output Class Initialized
INFO - 2023-03-13 10:32:51 --> Security Class Initialized
DEBUG - 2023-03-13 10:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:32:51 --> Input Class Initialized
INFO - 2023-03-13 10:32:51 --> Language Class Initialized
INFO - 2023-03-13 10:32:51 --> Loader Class Initialized
INFO - 2023-03-13 10:32:51 --> Controller Class Initialized
DEBUG - 2023-03-13 10:32:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:32:51 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:51 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:32:51 --> Database Driver Class Initialized
INFO - 2023-03-13 10:32:51 --> Model "Login_model" initialized
INFO - 2023-03-13 10:32:51 --> Final output sent to browser
DEBUG - 2023-03-13 10:32:51 --> Total execution time: 0.0400
INFO - 2023-03-13 10:33:30 --> Config Class Initialized
INFO - 2023-03-13 10:33:30 --> Config Class Initialized
INFO - 2023-03-13 10:33:30 --> Hooks Class Initialized
INFO - 2023-03-13 10:33:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:33:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:33:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:33:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:33:31 --> URI Class Initialized
INFO - 2023-03-13 10:33:31 --> URI Class Initialized
INFO - 2023-03-13 10:33:31 --> Router Class Initialized
INFO - 2023-03-13 10:33:31 --> Router Class Initialized
INFO - 2023-03-13 10:33:31 --> Output Class Initialized
INFO - 2023-03-13 10:33:31 --> Output Class Initialized
INFO - 2023-03-13 10:33:31 --> Security Class Initialized
INFO - 2023-03-13 10:33:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:33:31 --> Input Class Initialized
INFO - 2023-03-13 10:33:31 --> Input Class Initialized
INFO - 2023-03-13 10:33:31 --> Language Class Initialized
INFO - 2023-03-13 10:33:31 --> Language Class Initialized
INFO - 2023-03-13 10:33:31 --> Loader Class Initialized
INFO - 2023-03-13 10:33:31 --> Loader Class Initialized
INFO - 2023-03-13 10:33:31 --> Controller Class Initialized
INFO - 2023-03-13 10:33:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:33:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:33:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:33:31 --> Model "Login_model" initialized
INFO - 2023-03-13 10:33:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:33:31 --> Total execution time: 0.0397
INFO - 2023-03-13 10:33:31 --> Config Class Initialized
INFO - 2023-03-13 10:33:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:33:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:33:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:33:31 --> URI Class Initialized
INFO - 2023-03-13 10:33:31 --> Router Class Initialized
INFO - 2023-03-13 10:33:31 --> Output Class Initialized
INFO - 2023-03-13 10:33:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:33:31 --> Input Class Initialized
INFO - 2023-03-13 10:33:31 --> Language Class Initialized
INFO - 2023-03-13 10:33:31 --> Loader Class Initialized
INFO - 2023-03-13 10:33:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:33:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:33:31 --> Database Driver Class Initialized
INFO - 2023-03-13 10:33:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:33:31 --> Total execution time: 0.0929
INFO - 2023-03-13 10:33:31 --> Model "Login_model" initialized
INFO - 2023-03-13 10:33:31 --> Config Class Initialized
INFO - 2023-03-13 10:33:31 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:33:31 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:33:31 --> Utf8 Class Initialized
INFO - 2023-03-13 10:33:31 --> URI Class Initialized
INFO - 2023-03-13 10:33:31 --> Router Class Initialized
INFO - 2023-03-13 10:33:31 --> Output Class Initialized
INFO - 2023-03-13 10:33:31 --> Security Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:33:31 --> Input Class Initialized
INFO - 2023-03-13 10:33:31 --> Language Class Initialized
INFO - 2023-03-13 10:33:31 --> Loader Class Initialized
INFO - 2023-03-13 10:33:31 --> Controller Class Initialized
DEBUG - 2023-03-13 10:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:33:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:33:31 --> Total execution time: 0.0575
INFO - 2023-03-13 10:33:31 --> Final output sent to browser
DEBUG - 2023-03-13 10:33:31 --> Total execution time: 0.0750
INFO - 2023-03-13 10:36:36 --> Config Class Initialized
INFO - 2023-03-13 10:36:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:36:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:36:36 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:36 --> URI Class Initialized
INFO - 2023-03-13 10:36:36 --> Router Class Initialized
INFO - 2023-03-13 10:36:36 --> Output Class Initialized
INFO - 2023-03-13 10:36:36 --> Security Class Initialized
DEBUG - 2023-03-13 10:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:36:36 --> Input Class Initialized
INFO - 2023-03-13 10:36:36 --> Language Class Initialized
INFO - 2023-03-13 10:36:36 --> Loader Class Initialized
INFO - 2023-03-13 10:36:36 --> Controller Class Initialized
DEBUG - 2023-03-13 10:36:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:36:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:36:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:36 --> Model "Login_model" initialized
INFO - 2023-03-13 10:36:36 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:36 --> Total execution time: 0.2210
INFO - 2023-03-13 10:36:36 --> Config Class Initialized
INFO - 2023-03-13 10:36:36 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:36:36 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:36:36 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:36 --> URI Class Initialized
INFO - 2023-03-13 10:36:36 --> Router Class Initialized
INFO - 2023-03-13 10:36:36 --> Output Class Initialized
INFO - 2023-03-13 10:36:36 --> Security Class Initialized
DEBUG - 2023-03-13 10:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:36:36 --> Input Class Initialized
INFO - 2023-03-13 10:36:36 --> Language Class Initialized
INFO - 2023-03-13 10:36:36 --> Loader Class Initialized
INFO - 2023-03-13 10:36:36 --> Controller Class Initialized
DEBUG - 2023-03-13 10:36:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:36:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:36 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:36:36 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:36 --> Model "Login_model" initialized
INFO - 2023-03-13 10:36:36 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:36 --> Total execution time: 0.0795
INFO - 2023-03-13 10:36:53 --> Config Class Initialized
INFO - 2023-03-13 10:36:53 --> Config Class Initialized
INFO - 2023-03-13 10:36:53 --> Hooks Class Initialized
INFO - 2023-03-13 10:36:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:36:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:36:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:53 --> URI Class Initialized
INFO - 2023-03-13 10:36:53 --> URI Class Initialized
INFO - 2023-03-13 10:36:53 --> Router Class Initialized
INFO - 2023-03-13 10:36:53 --> Router Class Initialized
INFO - 2023-03-13 10:36:53 --> Output Class Initialized
INFO - 2023-03-13 10:36:53 --> Output Class Initialized
INFO - 2023-03-13 10:36:53 --> Security Class Initialized
INFO - 2023-03-13 10:36:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:36:53 --> Input Class Initialized
INFO - 2023-03-13 10:36:53 --> Input Class Initialized
INFO - 2023-03-13 10:36:53 --> Language Class Initialized
INFO - 2023-03-13 10:36:53 --> Language Class Initialized
INFO - 2023-03-13 10:36:53 --> Loader Class Initialized
INFO - 2023-03-13 10:36:53 --> Loader Class Initialized
INFO - 2023-03-13 10:36:53 --> Controller Class Initialized
INFO - 2023-03-13 10:36:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:36:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:36:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:53 --> Total execution time: 0.0786
INFO - 2023-03-13 10:36:53 --> Config Class Initialized
INFO - 2023-03-13 10:36:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:36:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:36:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:53 --> URI Class Initialized
INFO - 2023-03-13 10:36:53 --> Router Class Initialized
INFO - 2023-03-13 10:36:53 --> Output Class Initialized
INFO - 2023-03-13 10:36:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:36:53 --> Input Class Initialized
INFO - 2023-03-13 10:36:53 --> Language Class Initialized
INFO - 2023-03-13 10:36:53 --> Loader Class Initialized
INFO - 2023-03-13 10:36:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:36:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:53 --> Database Driver Class Initialized
INFO - 2023-03-13 10:36:53 --> Model "Login_model" initialized
INFO - 2023-03-13 10:36:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:53 --> Total execution time: 0.0310
INFO - 2023-03-13 10:36:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:53 --> Total execution time: 0.1328
INFO - 2023-03-13 10:36:53 --> Config Class Initialized
INFO - 2023-03-13 10:36:53 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:36:53 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:36:53 --> Utf8 Class Initialized
INFO - 2023-03-13 10:36:53 --> URI Class Initialized
INFO - 2023-03-13 10:36:53 --> Router Class Initialized
INFO - 2023-03-13 10:36:53 --> Output Class Initialized
INFO - 2023-03-13 10:36:53 --> Security Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:36:53 --> Input Class Initialized
INFO - 2023-03-13 10:36:53 --> Language Class Initialized
INFO - 2023-03-13 10:36:53 --> Loader Class Initialized
INFO - 2023-03-13 10:36:53 --> Controller Class Initialized
DEBUG - 2023-03-13 10:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:36:53 --> Final output sent to browser
DEBUG - 2023-03-13 10:36:53 --> Total execution time: 0.0755
INFO - 2023-03-13 10:37:49 --> Config Class Initialized
INFO - 2023-03-13 10:37:49 --> Config Class Initialized
INFO - 2023-03-13 10:37:49 --> Hooks Class Initialized
INFO - 2023-03-13 10:37:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:37:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:49 --> URI Class Initialized
INFO - 2023-03-13 10:37:49 --> URI Class Initialized
INFO - 2023-03-13 10:37:49 --> Router Class Initialized
INFO - 2023-03-13 10:37:49 --> Router Class Initialized
INFO - 2023-03-13 10:37:49 --> Output Class Initialized
INFO - 2023-03-13 10:37:49 --> Output Class Initialized
INFO - 2023-03-13 10:37:49 --> Security Class Initialized
INFO - 2023-03-13 10:37:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:49 --> Input Class Initialized
INFO - 2023-03-13 10:37:49 --> Input Class Initialized
INFO - 2023-03-13 10:37:49 --> Language Class Initialized
INFO - 2023-03-13 10:37:49 --> Language Class Initialized
INFO - 2023-03-13 10:37:49 --> Loader Class Initialized
INFO - 2023-03-13 10:37:49 --> Loader Class Initialized
INFO - 2023-03-13 10:37:49 --> Controller Class Initialized
INFO - 2023-03-13 10:37:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:49 --> Final output sent to browser
DEBUG - 2023-03-13 10:37:49 --> Total execution time: 0.0169
INFO - 2023-03-13 10:37:49 --> Config Class Initialized
INFO - 2023-03-13 10:37:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:49 --> URI Class Initialized
INFO - 2023-03-13 10:37:49 --> Router Class Initialized
INFO - 2023-03-13 10:37:49 --> Output Class Initialized
INFO - 2023-03-13 10:37:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:49 --> Input Class Initialized
INFO - 2023-03-13 10:37:49 --> Language Class Initialized
INFO - 2023-03-13 10:37:49 --> Loader Class Initialized
INFO - 2023-03-13 10:37:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:49 --> Config Class Initialized
INFO - 2023-03-13 10:37:49 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:49 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:49 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:49 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:49 --> URI Class Initialized
INFO - 2023-03-13 10:37:49 --> Router Class Initialized
INFO - 2023-03-13 10:37:49 --> Output Class Initialized
INFO - 2023-03-13 10:37:49 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:49 --> Final output sent to browser
INFO - 2023-03-13 10:37:49 --> Input Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Total execution time: 0.1709
INFO - 2023-03-13 10:37:49 --> Language Class Initialized
INFO - 2023-03-13 10:37:49 --> Loader Class Initialized
INFO - 2023-03-13 10:37:49 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:49 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:50 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:52 --> Config Class Initialized
INFO - 2023-03-13 10:37:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:52 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:52 --> URI Class Initialized
INFO - 2023-03-13 10:37:52 --> Router Class Initialized
INFO - 2023-03-13 10:37:52 --> Output Class Initialized
INFO - 2023-03-13 10:37:52 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:52 --> Input Class Initialized
INFO - 2023-03-13 10:37:52 --> Language Class Initialized
INFO - 2023-03-13 10:37:52 --> Loader Class Initialized
INFO - 2023-03-13 10:37:52 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:52 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:52 --> Config Class Initialized
INFO - 2023-03-13 10:37:52 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:52 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:52 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:52 --> URI Class Initialized
INFO - 2023-03-13 10:37:52 --> Router Class Initialized
INFO - 2023-03-13 10:37:52 --> Output Class Initialized
INFO - 2023-03-13 10:37:52 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:52 --> Input Class Initialized
INFO - 2023-03-13 10:37:52 --> Language Class Initialized
INFO - 2023-03-13 10:37:52 --> Loader Class Initialized
INFO - 2023-03-13 10:37:52 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:52 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:52 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:54 --> Config Class Initialized
INFO - 2023-03-13 10:37:54 --> Config Class Initialized
INFO - 2023-03-13 10:37:54 --> Hooks Class Initialized
INFO - 2023-03-13 10:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:54 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:54 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:54 --> URI Class Initialized
INFO - 2023-03-13 10:37:54 --> URI Class Initialized
INFO - 2023-03-13 10:37:54 --> Router Class Initialized
INFO - 2023-03-13 10:37:54 --> Router Class Initialized
INFO - 2023-03-13 10:37:54 --> Output Class Initialized
INFO - 2023-03-13 10:37:54 --> Output Class Initialized
INFO - 2023-03-13 10:37:54 --> Security Class Initialized
INFO - 2023-03-13 10:37:54 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:54 --> Input Class Initialized
INFO - 2023-03-13 10:37:54 --> Input Class Initialized
INFO - 2023-03-13 10:37:54 --> Language Class Initialized
INFO - 2023-03-13 10:37:54 --> Language Class Initialized
INFO - 2023-03-13 10:37:54 --> Loader Class Initialized
INFO - 2023-03-13 10:37:54 --> Loader Class Initialized
INFO - 2023-03-13 10:37:54 --> Controller Class Initialized
INFO - 2023-03-13 10:37:54 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:54 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:54 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:54 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:54 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:54 --> Final output sent to browser
DEBUG - 2023-03-13 10:37:54 --> Total execution time: 0.0143
INFO - 2023-03-13 10:37:59 --> Config Class Initialized
INFO - 2023-03-13 10:37:59 --> Config Class Initialized
INFO - 2023-03-13 10:37:59 --> Hooks Class Initialized
INFO - 2023-03-13 10:37:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:37:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:59 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:59 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:59 --> URI Class Initialized
INFO - 2023-03-13 10:37:59 --> URI Class Initialized
INFO - 2023-03-13 10:37:59 --> Router Class Initialized
INFO - 2023-03-13 10:37:59 --> Router Class Initialized
INFO - 2023-03-13 10:37:59 --> Output Class Initialized
INFO - 2023-03-13 10:37:59 --> Output Class Initialized
INFO - 2023-03-13 10:37:59 --> Security Class Initialized
INFO - 2023-03-13 10:37:59 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:59 --> Input Class Initialized
INFO - 2023-03-13 10:37:59 --> Input Class Initialized
INFO - 2023-03-13 10:37:59 --> Language Class Initialized
INFO - 2023-03-13 10:37:59 --> Language Class Initialized
INFO - 2023-03-13 10:37:59 --> Loader Class Initialized
INFO - 2023-03-13 10:37:59 --> Loader Class Initialized
INFO - 2023-03-13 10:37:59 --> Controller Class Initialized
INFO - 2023-03-13 10:37:59 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:59 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:59 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:59 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:59 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:59 --> Final output sent to browser
DEBUG - 2023-03-13 10:37:59 --> Total execution time: 0.0167
INFO - 2023-03-13 10:37:59 --> Config Class Initialized
INFO - 2023-03-13 10:37:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:59 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:59 --> URI Class Initialized
INFO - 2023-03-13 10:37:59 --> Router Class Initialized
INFO - 2023-03-13 10:37:59 --> Output Class Initialized
INFO - 2023-03-13 10:37:59 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:59 --> Input Class Initialized
INFO - 2023-03-13 10:37:59 --> Language Class Initialized
INFO - 2023-03-13 10:37:59 --> Loader Class Initialized
INFO - 2023-03-13 10:37:59 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:59 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:59 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:37:59 --> Final output sent to browser
DEBUG - 2023-03-13 10:37:59 --> Total execution time: 0.0121
INFO - 2023-03-13 10:37:59 --> Config Class Initialized
INFO - 2023-03-13 10:37:59 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:37:59 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:37:59 --> Utf8 Class Initialized
INFO - 2023-03-13 10:37:59 --> URI Class Initialized
INFO - 2023-03-13 10:37:59 --> Router Class Initialized
INFO - 2023-03-13 10:37:59 --> Output Class Initialized
INFO - 2023-03-13 10:37:59 --> Security Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:37:59 --> Input Class Initialized
INFO - 2023-03-13 10:37:59 --> Language Class Initialized
INFO - 2023-03-13 10:37:59 --> Loader Class Initialized
INFO - 2023-03-13 10:37:59 --> Controller Class Initialized
DEBUG - 2023-03-13 10:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:37:59 --> Database Driver Class Initialized
INFO - 2023-03-13 10:37:59 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:38:00 --> Config Class Initialized
INFO - 2023-03-13 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:38:00 --> Utf8 Class Initialized
INFO - 2023-03-13 10:38:00 --> URI Class Initialized
INFO - 2023-03-13 10:38:00 --> Router Class Initialized
INFO - 2023-03-13 10:38:00 --> Output Class Initialized
INFO - 2023-03-13 10:38:00 --> Security Class Initialized
DEBUG - 2023-03-13 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:38:00 --> Input Class Initialized
INFO - 2023-03-13 10:38:00 --> Language Class Initialized
INFO - 2023-03-13 10:38:00 --> Loader Class Initialized
INFO - 2023-03-13 10:38:00 --> Controller Class Initialized
DEBUG - 2023-03-13 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:38:00 --> Database Driver Class Initialized
INFO - 2023-03-13 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:38:00 --> Config Class Initialized
INFO - 2023-03-13 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:38:00 --> Utf8 Class Initialized
INFO - 2023-03-13 10:38:00 --> URI Class Initialized
INFO - 2023-03-13 10:38:00 --> Router Class Initialized
INFO - 2023-03-13 10:38:00 --> Output Class Initialized
INFO - 2023-03-13 10:38:00 --> Security Class Initialized
DEBUG - 2023-03-13 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:38:00 --> Input Class Initialized
INFO - 2023-03-13 10:38:00 --> Language Class Initialized
INFO - 2023-03-13 10:38:00 --> Loader Class Initialized
INFO - 2023-03-13 10:38:00 --> Controller Class Initialized
DEBUG - 2023-03-13 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:38:00 --> Database Driver Class Initialized
INFO - 2023-03-13 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:40:42 --> Config Class Initialized
INFO - 2023-03-13 10:40:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:40:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:40:42 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:42 --> URI Class Initialized
INFO - 2023-03-13 10:40:42 --> Router Class Initialized
INFO - 2023-03-13 10:40:42 --> Output Class Initialized
INFO - 2023-03-13 10:40:42 --> Security Class Initialized
DEBUG - 2023-03-13 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:40:42 --> Input Class Initialized
INFO - 2023-03-13 10:40:42 --> Language Class Initialized
INFO - 2023-03-13 10:40:42 --> Loader Class Initialized
INFO - 2023-03-13 10:40:42 --> Controller Class Initialized
DEBUG - 2023-03-13 10:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:40:42 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:40:42 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:42 --> Model "Login_model" initialized
INFO - 2023-03-13 10:40:42 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:42 --> Total execution time: 0.0616
INFO - 2023-03-13 10:40:42 --> Config Class Initialized
INFO - 2023-03-13 10:40:42 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:40:42 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:40:42 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:42 --> URI Class Initialized
INFO - 2023-03-13 10:40:42 --> Router Class Initialized
INFO - 2023-03-13 10:40:42 --> Output Class Initialized
INFO - 2023-03-13 10:40:42 --> Security Class Initialized
DEBUG - 2023-03-13 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:40:42 --> Input Class Initialized
INFO - 2023-03-13 10:40:42 --> Language Class Initialized
INFO - 2023-03-13 10:40:42 --> Loader Class Initialized
INFO - 2023-03-13 10:40:42 --> Controller Class Initialized
DEBUG - 2023-03-13 10:40:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:40:42 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:42 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:40:42 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:42 --> Model "Login_model" initialized
INFO - 2023-03-13 10:40:42 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:43 --> Total execution time: 0.0954
INFO - 2023-03-13 10:40:56 --> Config Class Initialized
INFO - 2023-03-13 10:40:56 --> Config Class Initialized
INFO - 2023-03-13 10:40:56 --> Hooks Class Initialized
INFO - 2023-03-13 10:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:40:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:56 --> URI Class Initialized
INFO - 2023-03-13 10:40:56 --> URI Class Initialized
INFO - 2023-03-13 10:40:56 --> Router Class Initialized
INFO - 2023-03-13 10:40:56 --> Router Class Initialized
INFO - 2023-03-13 10:40:56 --> Output Class Initialized
INFO - 2023-03-13 10:40:56 --> Output Class Initialized
INFO - 2023-03-13 10:40:56 --> Security Class Initialized
INFO - 2023-03-13 10:40:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:40:56 --> Input Class Initialized
INFO - 2023-03-13 10:40:56 --> Input Class Initialized
INFO - 2023-03-13 10:40:56 --> Language Class Initialized
INFO - 2023-03-13 10:40:56 --> Language Class Initialized
INFO - 2023-03-13 10:40:56 --> Loader Class Initialized
INFO - 2023-03-13 10:40:56 --> Loader Class Initialized
INFO - 2023-03-13 10:40:56 --> Controller Class Initialized
INFO - 2023-03-13 10:40:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:40:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:56 --> Model "Login_model" initialized
INFO - 2023-03-13 10:40:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:56 --> Total execution time: 0.0906
INFO - 2023-03-13 10:40:56 --> Config Class Initialized
INFO - 2023-03-13 10:40:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:56 --> Total execution time: 0.1184
INFO - 2023-03-13 10:40:56 --> Config Class Initialized
INFO - 2023-03-13 10:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:40:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:56 --> URI Class Initialized
INFO - 2023-03-13 10:40:56 --> Router Class Initialized
INFO - 2023-03-13 10:40:56 --> Output Class Initialized
INFO - 2023-03-13 10:40:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:40:56 --> Input Class Initialized
INFO - 2023-03-13 10:40:56 --> Language Class Initialized
INFO - 2023-03-13 10:40:56 --> Loader Class Initialized
INFO - 2023-03-13 10:40:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:40:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:40:56 --> URI Class Initialized
INFO - 2023-03-13 10:40:56 --> Router Class Initialized
INFO - 2023-03-13 10:40:56 --> Output Class Initialized
INFO - 2023-03-13 10:40:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:40:56 --> Input Class Initialized
INFO - 2023-03-13 10:40:56 --> Language Class Initialized
INFO - 2023-03-13 10:40:56 --> Loader Class Initialized
INFO - 2023-03-13 10:40:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:40:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:40:56 --> Model "Login_model" initialized
INFO - 2023-03-13 10:40:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:56 --> Total execution time: 0.0633
INFO - 2023-03-13 10:40:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:40:56 --> Total execution time: 0.0793
INFO - 2023-03-13 10:49:58 --> Config Class Initialized
INFO - 2023-03-13 10:49:58 --> Config Class Initialized
INFO - 2023-03-13 10:49:58 --> Hooks Class Initialized
INFO - 2023-03-13 10:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:49:58 --> Utf8 Class Initialized
INFO - 2023-03-13 10:49:58 --> Utf8 Class Initialized
INFO - 2023-03-13 10:49:58 --> URI Class Initialized
INFO - 2023-03-13 10:49:58 --> URI Class Initialized
INFO - 2023-03-13 10:49:58 --> Router Class Initialized
INFO - 2023-03-13 10:49:58 --> Router Class Initialized
INFO - 2023-03-13 10:49:58 --> Output Class Initialized
INFO - 2023-03-13 10:49:58 --> Output Class Initialized
INFO - 2023-03-13 10:49:58 --> Security Class Initialized
INFO - 2023-03-13 10:49:58 --> Security Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:49:58 --> Input Class Initialized
INFO - 2023-03-13 10:49:58 --> Input Class Initialized
INFO - 2023-03-13 10:49:58 --> Language Class Initialized
INFO - 2023-03-13 10:49:58 --> Language Class Initialized
INFO - 2023-03-13 10:49:58 --> Loader Class Initialized
INFO - 2023-03-13 10:49:58 --> Loader Class Initialized
INFO - 2023-03-13 10:49:58 --> Controller Class Initialized
INFO - 2023-03-13 10:49:58 --> Controller Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:49:58 --> Database Driver Class Initialized
INFO - 2023-03-13 10:49:58 --> Database Driver Class Initialized
INFO - 2023-03-13 10:49:58 --> Final output sent to browser
DEBUG - 2023-03-13 10:49:58 --> Total execution time: 0.0626
INFO - 2023-03-13 10:49:58 --> Model "Login_model" initialized
INFO - 2023-03-13 10:49:58 --> Config Class Initialized
INFO - 2023-03-13 10:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:49:58 --> Final output sent to browser
INFO - 2023-03-13 10:49:58 --> Utf8 Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Total execution time: 0.0723
INFO - 2023-03-13 10:49:58 --> URI Class Initialized
INFO - 2023-03-13 10:49:58 --> Router Class Initialized
INFO - 2023-03-13 10:49:58 --> Output Class Initialized
INFO - 2023-03-13 10:49:58 --> Security Class Initialized
INFO - 2023-03-13 10:49:58 --> Config Class Initialized
INFO - 2023-03-13 10:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:49:58 --> Input Class Initialized
INFO - 2023-03-13 10:49:58 --> Utf8 Class Initialized
INFO - 2023-03-13 10:49:58 --> Language Class Initialized
INFO - 2023-03-13 10:49:58 --> URI Class Initialized
INFO - 2023-03-13 10:49:58 --> Loader Class Initialized
INFO - 2023-03-13 10:49:58 --> Router Class Initialized
INFO - 2023-03-13 10:49:58 --> Controller Class Initialized
INFO - 2023-03-13 10:49:58 --> Output Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:49:58 --> Security Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:49:58 --> Input Class Initialized
INFO - 2023-03-13 10:49:58 --> Language Class Initialized
INFO - 2023-03-13 10:49:58 --> Loader Class Initialized
INFO - 2023-03-13 10:49:58 --> Controller Class Initialized
DEBUG - 2023-03-13 10:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:49:58 --> Database Driver Class Initialized
INFO - 2023-03-13 10:49:58 --> Database Driver Class Initialized
INFO - 2023-03-13 10:49:58 --> Model "Login_model" initialized
INFO - 2023-03-13 10:49:58 --> Final output sent to browser
DEBUG - 2023-03-13 10:49:58 --> Total execution time: 0.1106
INFO - 2023-03-13 10:49:58 --> Final output sent to browser
DEBUG - 2023-03-13 10:49:59 --> Total execution time: 0.1063
INFO - 2023-03-13 10:50:06 --> Config Class Initialized
INFO - 2023-03-13 10:50:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:06 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:06 --> URI Class Initialized
INFO - 2023-03-13 10:50:06 --> Router Class Initialized
INFO - 2023-03-13 10:50:06 --> Output Class Initialized
INFO - 2023-03-13 10:50:06 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:06 --> Input Class Initialized
INFO - 2023-03-13 10:50:06 --> Language Class Initialized
INFO - 2023-03-13 10:50:06 --> Loader Class Initialized
INFO - 2023-03-13 10:50:06 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:06 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:50:06 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:06 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:06 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:06 --> Total execution time: 0.3191
INFO - 2023-03-13 10:50:06 --> Config Class Initialized
INFO - 2023-03-13 10:50:06 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:06 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:06 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:06 --> URI Class Initialized
INFO - 2023-03-13 10:50:06 --> Router Class Initialized
INFO - 2023-03-13 10:50:06 --> Output Class Initialized
INFO - 2023-03-13 10:50:06 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:06 --> Input Class Initialized
INFO - 2023-03-13 10:50:06 --> Language Class Initialized
INFO - 2023-03-13 10:50:06 --> Loader Class Initialized
INFO - 2023-03-13 10:50:06 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:06 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:06 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:50:06 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:06 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:06 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:06 --> Total execution time: 0.0795
INFO - 2023-03-13 10:50:10 --> Config Class Initialized
INFO - 2023-03-13 10:50:10 --> Config Class Initialized
INFO - 2023-03-13 10:50:10 --> Hooks Class Initialized
INFO - 2023-03-13 10:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:10 --> Utf8 Class Initialized
DEBUG - 2023-03-13 10:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:10 --> URI Class Initialized
INFO - 2023-03-13 10:50:10 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:10 --> Router Class Initialized
INFO - 2023-03-13 10:50:10 --> URI Class Initialized
INFO - 2023-03-13 10:50:10 --> Output Class Initialized
INFO - 2023-03-13 10:50:10 --> Router Class Initialized
INFO - 2023-03-13 10:50:10 --> Security Class Initialized
INFO - 2023-03-13 10:50:10 --> Output Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:10 --> Security Class Initialized
INFO - 2023-03-13 10:50:10 --> Input Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:10 --> Language Class Initialized
INFO - 2023-03-13 10:50:10 --> Input Class Initialized
INFO - 2023-03-13 10:50:10 --> Loader Class Initialized
INFO - 2023-03-13 10:50:10 --> Language Class Initialized
INFO - 2023-03-13 10:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:10 --> Loader Class Initialized
INFO - 2023-03-13 10:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:10 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:10 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:10 --> Total execution time: 0.0354
INFO - 2023-03-13 10:50:10 --> Config Class Initialized
INFO - 2023-03-13 10:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:10 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:10 --> URI Class Initialized
INFO - 2023-03-13 10:50:10 --> Router Class Initialized
INFO - 2023-03-13 10:50:10 --> Output Class Initialized
INFO - 2023-03-13 10:50:10 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:10 --> Input Class Initialized
INFO - 2023-03-13 10:50:10 --> Language Class Initialized
INFO - 2023-03-13 10:50:10 --> Loader Class Initialized
INFO - 2023-03-13 10:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:10 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:10 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:10 --> Final output sent to browser
INFO - 2023-03-13 10:50:10 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:10 --> Total execution time: 0.0229
DEBUG - 2023-03-13 10:50:10 --> Total execution time: 0.0721
INFO - 2023-03-13 10:50:10 --> Config Class Initialized
INFO - 2023-03-13 10:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:10 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:10 --> URI Class Initialized
INFO - 2023-03-13 10:50:10 --> Router Class Initialized
INFO - 2023-03-13 10:50:10 --> Output Class Initialized
INFO - 2023-03-13 10:50:10 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:10 --> Input Class Initialized
INFO - 2023-03-13 10:50:10 --> Language Class Initialized
INFO - 2023-03-13 10:50:10 --> Loader Class Initialized
INFO - 2023-03-13 10:50:10 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:10 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:10 --> Total execution time: 0.1058
INFO - 2023-03-13 10:50:19 --> Config Class Initialized
INFO - 2023-03-13 10:50:19 --> Config Class Initialized
INFO - 2023-03-13 10:50:19 --> Hooks Class Initialized
INFO - 2023-03-13 10:50:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:19 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:50:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:19 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:19 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:19 --> URI Class Initialized
INFO - 2023-03-13 10:50:19 --> URI Class Initialized
INFO - 2023-03-13 10:50:19 --> Router Class Initialized
INFO - 2023-03-13 10:50:19 --> Output Class Initialized
INFO - 2023-03-13 10:50:19 --> Router Class Initialized
INFO - 2023-03-13 10:50:19 --> Security Class Initialized
INFO - 2023-03-13 10:50:19 --> Output Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:19 --> Security Class Initialized
INFO - 2023-03-13 10:50:19 --> Input Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:19 --> Language Class Initialized
INFO - 2023-03-13 10:50:19 --> Input Class Initialized
INFO - 2023-03-13 10:50:19 --> Language Class Initialized
INFO - 2023-03-13 10:50:19 --> Loader Class Initialized
INFO - 2023-03-13 10:50:19 --> Loader Class Initialized
INFO - 2023-03-13 10:50:19 --> Controller Class Initialized
INFO - 2023-03-13 10:50:19 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:50:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:19 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:19 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:19 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:19 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:19 --> Total execution time: 0.0299
INFO - 2023-03-13 10:50:19 --> Config Class Initialized
INFO - 2023-03-13 10:50:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:19 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:19 --> URI Class Initialized
INFO - 2023-03-13 10:50:19 --> Router Class Initialized
INFO - 2023-03-13 10:50:19 --> Output Class Initialized
INFO - 2023-03-13 10:50:19 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:19 --> Input Class Initialized
INFO - 2023-03-13 10:50:19 --> Language Class Initialized
INFO - 2023-03-13 10:50:19 --> Loader Class Initialized
INFO - 2023-03-13 10:50:19 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:19 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:19 --> Database Driver Class Initialized
INFO - 2023-03-13 10:50:19 --> Model "Login_model" initialized
INFO - 2023-03-13 10:50:19 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:19 --> Total execution time: 0.0268
INFO - 2023-03-13 10:50:19 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:19 --> Total execution time: 0.0725
INFO - 2023-03-13 10:50:19 --> Config Class Initialized
INFO - 2023-03-13 10:50:19 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:50:19 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:50:19 --> Utf8 Class Initialized
INFO - 2023-03-13 10:50:19 --> URI Class Initialized
INFO - 2023-03-13 10:50:19 --> Router Class Initialized
INFO - 2023-03-13 10:50:19 --> Output Class Initialized
INFO - 2023-03-13 10:50:19 --> Security Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:50:19 --> Input Class Initialized
INFO - 2023-03-13 10:50:19 --> Language Class Initialized
INFO - 2023-03-13 10:50:19 --> Loader Class Initialized
INFO - 2023-03-13 10:50:19 --> Controller Class Initialized
DEBUG - 2023-03-13 10:50:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:50:19 --> Final output sent to browser
DEBUG - 2023-03-13 10:50:19 --> Total execution time: 0.0831
INFO - 2023-03-13 10:52:56 --> Config Class Initialized
INFO - 2023-03-13 10:52:56 --> Config Class Initialized
INFO - 2023-03-13 10:52:56 --> Hooks Class Initialized
INFO - 2023-03-13 10:52:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:52:56 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:52:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:52:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:52:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:52:56 --> URI Class Initialized
INFO - 2023-03-13 10:52:56 --> URI Class Initialized
INFO - 2023-03-13 10:52:56 --> Router Class Initialized
INFO - 2023-03-13 10:52:56 --> Router Class Initialized
INFO - 2023-03-13 10:52:56 --> Output Class Initialized
INFO - 2023-03-13 10:52:56 --> Output Class Initialized
INFO - 2023-03-13 10:52:56 --> Security Class Initialized
INFO - 2023-03-13 10:52:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:52:56 --> Input Class Initialized
INFO - 2023-03-13 10:52:56 --> Input Class Initialized
INFO - 2023-03-13 10:52:56 --> Language Class Initialized
INFO - 2023-03-13 10:52:56 --> Language Class Initialized
INFO - 2023-03-13 10:52:56 --> Loader Class Initialized
INFO - 2023-03-13 10:52:56 --> Loader Class Initialized
INFO - 2023-03-13 10:52:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:52:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:52:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:52:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:52:56 --> Model "Login_model" initialized
INFO - 2023-03-13 10:52:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:52:56 --> Total execution time: 0.1253
INFO - 2023-03-13 10:52:56 --> Config Class Initialized
INFO - 2023-03-13 10:52:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:52:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:52:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:52:56 --> URI Class Initialized
INFO - 2023-03-13 10:52:56 --> Router Class Initialized
INFO - 2023-03-13 10:52:56 --> Output Class Initialized
INFO - 2023-03-13 10:52:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:52:56 --> Input Class Initialized
INFO - 2023-03-13 10:52:56 --> Language Class Initialized
INFO - 2023-03-13 10:52:56 --> Loader Class Initialized
INFO - 2023-03-13 10:52:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:52:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:52:56 --> Database Driver Class Initialized
INFO - 2023-03-13 10:52:56 --> Model "Login_model" initialized
INFO - 2023-03-13 10:52:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:52:56 --> Total execution time: 0.0424
INFO - 2023-03-13 10:52:56 --> Final output sent to browser
DEBUG - 2023-03-13 10:52:56 --> Total execution time: 0.1837
INFO - 2023-03-13 10:52:56 --> Config Class Initialized
INFO - 2023-03-13 10:52:56 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:52:56 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:52:56 --> Utf8 Class Initialized
INFO - 2023-03-13 10:52:56 --> URI Class Initialized
INFO - 2023-03-13 10:52:56 --> Router Class Initialized
INFO - 2023-03-13 10:52:56 --> Output Class Initialized
INFO - 2023-03-13 10:52:56 --> Security Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:52:56 --> Input Class Initialized
INFO - 2023-03-13 10:52:56 --> Language Class Initialized
INFO - 2023-03-13 10:52:56 --> Loader Class Initialized
INFO - 2023-03-13 10:52:56 --> Controller Class Initialized
DEBUG - 2023-03-13 10:52:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:52:57 --> Final output sent to browser
DEBUG - 2023-03-13 10:52:57 --> Total execution time: 0.0847
INFO - 2023-03-13 10:53:01 --> Config Class Initialized
INFO - 2023-03-13 10:53:01 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:01 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:01 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:01 --> URI Class Initialized
INFO - 2023-03-13 10:53:01 --> Router Class Initialized
INFO - 2023-03-13 10:53:01 --> Output Class Initialized
INFO - 2023-03-13 10:53:01 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:01 --> Input Class Initialized
INFO - 2023-03-13 10:53:01 --> Language Class Initialized
INFO - 2023-03-13 10:53:01 --> Loader Class Initialized
INFO - 2023-03-13 10:53:01 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:01 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:01 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:53:01 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:02 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:02 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:02 --> Total execution time: 0.2755
INFO - 2023-03-13 10:53:02 --> Config Class Initialized
INFO - 2023-03-13 10:53:02 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:02 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:02 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:02 --> URI Class Initialized
INFO - 2023-03-13 10:53:02 --> Router Class Initialized
INFO - 2023-03-13 10:53:02 --> Output Class Initialized
INFO - 2023-03-13 10:53:02 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:02 --> Input Class Initialized
INFO - 2023-03-13 10:53:02 --> Language Class Initialized
INFO - 2023-03-13 10:53:02 --> Loader Class Initialized
INFO - 2023-03-13 10:53:02 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:02 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:02 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:53:02 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:02 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:02 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:02 --> Total execution time: 0.0428
INFO - 2023-03-13 10:53:05 --> Config Class Initialized
INFO - 2023-03-13 10:53:05 --> Config Class Initialized
INFO - 2023-03-13 10:53:05 --> Hooks Class Initialized
INFO - 2023-03-13 10:53:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:05 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:05 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:05 --> URI Class Initialized
INFO - 2023-03-13 10:53:05 --> URI Class Initialized
INFO - 2023-03-13 10:53:05 --> Router Class Initialized
INFO - 2023-03-13 10:53:05 --> Router Class Initialized
INFO - 2023-03-13 10:53:05 --> Output Class Initialized
INFO - 2023-03-13 10:53:05 --> Output Class Initialized
INFO - 2023-03-13 10:53:05 --> Security Class Initialized
INFO - 2023-03-13 10:53:05 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:05 --> Input Class Initialized
INFO - 2023-03-13 10:53:05 --> Input Class Initialized
INFO - 2023-03-13 10:53:05 --> Language Class Initialized
INFO - 2023-03-13 10:53:05 --> Language Class Initialized
INFO - 2023-03-13 10:53:05 --> Loader Class Initialized
INFO - 2023-03-13 10:53:05 --> Loader Class Initialized
INFO - 2023-03-13 10:53:05 --> Controller Class Initialized
INFO - 2023-03-13 10:53:05 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:05 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:05 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:05 --> Total execution time: 0.0370
INFO - 2023-03-13 10:53:05 --> Config Class Initialized
INFO - 2023-03-13 10:53:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:05 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:05 --> URI Class Initialized
INFO - 2023-03-13 10:53:05 --> Router Class Initialized
INFO - 2023-03-13 10:53:05 --> Output Class Initialized
INFO - 2023-03-13 10:53:05 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:05 --> Input Class Initialized
INFO - 2023-03-13 10:53:05 --> Language Class Initialized
INFO - 2023-03-13 10:53:05 --> Loader Class Initialized
INFO - 2023-03-13 10:53:05 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:05 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:05 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:05 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:05 --> Total execution time: 0.0298
INFO - 2023-03-13 10:53:05 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:05 --> Total execution time: 0.0780
INFO - 2023-03-13 10:53:05 --> Config Class Initialized
INFO - 2023-03-13 10:53:05 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:05 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:05 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:05 --> URI Class Initialized
INFO - 2023-03-13 10:53:05 --> Router Class Initialized
INFO - 2023-03-13 10:53:05 --> Output Class Initialized
INFO - 2023-03-13 10:53:05 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:05 --> Input Class Initialized
INFO - 2023-03-13 10:53:05 --> Language Class Initialized
INFO - 2023-03-13 10:53:05 --> Loader Class Initialized
INFO - 2023-03-13 10:53:05 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:05 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:05 --> Total execution time: 0.0669
INFO - 2023-03-13 10:53:23 --> Config Class Initialized
INFO - 2023-03-13 10:53:23 --> Config Class Initialized
INFO - 2023-03-13 10:53:23 --> Hooks Class Initialized
INFO - 2023-03-13 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:23 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:23 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:23 --> URI Class Initialized
INFO - 2023-03-13 10:53:23 --> URI Class Initialized
INFO - 2023-03-13 10:53:23 --> Router Class Initialized
INFO - 2023-03-13 10:53:23 --> Router Class Initialized
INFO - 2023-03-13 10:53:23 --> Output Class Initialized
INFO - 2023-03-13 10:53:23 --> Output Class Initialized
INFO - 2023-03-13 10:53:23 --> Security Class Initialized
INFO - 2023-03-13 10:53:23 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:23 --> Input Class Initialized
INFO - 2023-03-13 10:53:23 --> Input Class Initialized
INFO - 2023-03-13 10:53:23 --> Language Class Initialized
INFO - 2023-03-13 10:53:23 --> Language Class Initialized
INFO - 2023-03-13 10:53:23 --> Loader Class Initialized
INFO - 2023-03-13 10:53:23 --> Loader Class Initialized
INFO - 2023-03-13 10:53:23 --> Controller Class Initialized
INFO - 2023-03-13 10:53:23 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:23 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:23 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:23 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:23 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:23 --> Total execution time: 0.0532
INFO - 2023-03-13 10:53:23 --> Config Class Initialized
INFO - 2023-03-13 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:23 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:23 --> URI Class Initialized
INFO - 2023-03-13 10:53:23 --> Router Class Initialized
INFO - 2023-03-13 10:53:23 --> Output Class Initialized
INFO - 2023-03-13 10:53:23 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:23 --> Input Class Initialized
INFO - 2023-03-13 10:53:23 --> Language Class Initialized
INFO - 2023-03-13 10:53:23 --> Loader Class Initialized
INFO - 2023-03-13 10:53:23 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:23 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:23 --> Database Driver Class Initialized
INFO - 2023-03-13 10:53:23 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:23 --> Total execution time: 0.0871
INFO - 2023-03-13 10:53:23 --> Model "Login_model" initialized
INFO - 2023-03-13 10:53:23 --> Config Class Initialized
INFO - 2023-03-13 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:53:23 --> Utf8 Class Initialized
INFO - 2023-03-13 10:53:23 --> URI Class Initialized
INFO - 2023-03-13 10:53:23 --> Router Class Initialized
INFO - 2023-03-13 10:53:23 --> Output Class Initialized
INFO - 2023-03-13 10:53:23 --> Security Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:53:23 --> Input Class Initialized
INFO - 2023-03-13 10:53:23 --> Final output sent to browser
INFO - 2023-03-13 10:53:23 --> Language Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Total execution time: 0.0335
INFO - 2023-03-13 10:53:23 --> Loader Class Initialized
INFO - 2023-03-13 10:53:23 --> Controller Class Initialized
DEBUG - 2023-03-13 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:53:23 --> Final output sent to browser
DEBUG - 2023-03-13 10:53:23 --> Total execution time: 0.0719
INFO - 2023-03-13 10:54:25 --> Config Class Initialized
INFO - 2023-03-13 10:54:25 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:54:25 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:54:25 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:25 --> URI Class Initialized
INFO - 2023-03-13 10:54:25 --> Router Class Initialized
INFO - 2023-03-13 10:54:25 --> Output Class Initialized
INFO - 2023-03-13 10:54:25 --> Security Class Initialized
DEBUG - 2023-03-13 10:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:54:25 --> Input Class Initialized
INFO - 2023-03-13 10:54:25 --> Language Class Initialized
INFO - 2023-03-13 10:54:25 --> Loader Class Initialized
INFO - 2023-03-13 10:54:25 --> Controller Class Initialized
DEBUG - 2023-03-13 10:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:54:25 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:25 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:54:25 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:26 --> Model "Login_model" initialized
INFO - 2023-03-13 10:54:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:26 --> Total execution time: 0.1676
INFO - 2023-03-13 10:54:26 --> Config Class Initialized
INFO - 2023-03-13 10:54:26 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:54:26 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:54:26 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:26 --> URI Class Initialized
INFO - 2023-03-13 10:54:26 --> Router Class Initialized
INFO - 2023-03-13 10:54:26 --> Output Class Initialized
INFO - 2023-03-13 10:54:26 --> Security Class Initialized
DEBUG - 2023-03-13 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:54:26 --> Input Class Initialized
INFO - 2023-03-13 10:54:26 --> Language Class Initialized
INFO - 2023-03-13 10:54:26 --> Loader Class Initialized
INFO - 2023-03-13 10:54:26 --> Controller Class Initialized
DEBUG - 2023-03-13 10:54:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:54:26 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:26 --> Model "Cluster_model" initialized
INFO - 2023-03-13 10:54:26 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:26 --> Model "Login_model" initialized
INFO - 2023-03-13 10:54:26 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:26 --> Total execution time: 0.1122
INFO - 2023-03-13 10:54:30 --> Config Class Initialized
INFO - 2023-03-13 10:54:30 --> Config Class Initialized
INFO - 2023-03-13 10:54:30 --> Hooks Class Initialized
INFO - 2023-03-13 10:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 10:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:54:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:30 --> URI Class Initialized
INFO - 2023-03-13 10:54:30 --> URI Class Initialized
INFO - 2023-03-13 10:54:30 --> Router Class Initialized
INFO - 2023-03-13 10:54:30 --> Router Class Initialized
INFO - 2023-03-13 10:54:30 --> Output Class Initialized
INFO - 2023-03-13 10:54:30 --> Output Class Initialized
INFO - 2023-03-13 10:54:30 --> Security Class Initialized
INFO - 2023-03-13 10:54:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:54:30 --> Input Class Initialized
INFO - 2023-03-13 10:54:30 --> Input Class Initialized
INFO - 2023-03-13 10:54:30 --> Language Class Initialized
INFO - 2023-03-13 10:54:30 --> Language Class Initialized
INFO - 2023-03-13 10:54:30 --> Loader Class Initialized
INFO - 2023-03-13 10:54:30 --> Loader Class Initialized
INFO - 2023-03-13 10:54:30 --> Controller Class Initialized
INFO - 2023-03-13 10:54:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 10:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:54:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:30 --> Model "Login_model" initialized
INFO - 2023-03-13 10:54:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:30 --> Total execution time: 0.0374
INFO - 2023-03-13 10:54:30 --> Config Class Initialized
INFO - 2023-03-13 10:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:54:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:30 --> URI Class Initialized
INFO - 2023-03-13 10:54:30 --> Router Class Initialized
INFO - 2023-03-13 10:54:30 --> Output Class Initialized
INFO - 2023-03-13 10:54:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:54:30 --> Input Class Initialized
INFO - 2023-03-13 10:54:30 --> Language Class Initialized
INFO - 2023-03-13 10:54:30 --> Loader Class Initialized
INFO - 2023-03-13 10:54:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:54:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:30 --> Database Driver Class Initialized
INFO - 2023-03-13 10:54:30 --> Model "Login_model" initialized
INFO - 2023-03-13 10:54:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:30 --> Total execution time: 0.0238
INFO - 2023-03-13 10:54:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:30 --> Total execution time: 0.0701
INFO - 2023-03-13 10:54:30 --> Config Class Initialized
INFO - 2023-03-13 10:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-13 10:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-13 10:54:30 --> Utf8 Class Initialized
INFO - 2023-03-13 10:54:30 --> URI Class Initialized
INFO - 2023-03-13 10:54:30 --> Router Class Initialized
INFO - 2023-03-13 10:54:30 --> Output Class Initialized
INFO - 2023-03-13 10:54:30 --> Security Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 10:54:30 --> Input Class Initialized
INFO - 2023-03-13 10:54:30 --> Language Class Initialized
INFO - 2023-03-13 10:54:30 --> Loader Class Initialized
INFO - 2023-03-13 10:54:30 --> Controller Class Initialized
DEBUG - 2023-03-13 10:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 10:54:30 --> Final output sent to browser
DEBUG - 2023-03-13 10:54:30 --> Total execution time: 0.0687
INFO - 2023-03-13 12:49:41 --> Config Class Initialized
INFO - 2023-03-13 12:49:41 --> Config Class Initialized
INFO - 2023-03-13 12:49:41 --> Hooks Class Initialized
INFO - 2023-03-13 12:49:41 --> Hooks Class Initialized
DEBUG - 2023-03-13 12:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-13 12:49:41 --> UTF-8 Support Enabled
INFO - 2023-03-13 12:49:41 --> Utf8 Class Initialized
INFO - 2023-03-13 12:49:41 --> Utf8 Class Initialized
INFO - 2023-03-13 12:49:41 --> URI Class Initialized
INFO - 2023-03-13 12:49:41 --> URI Class Initialized
INFO - 2023-03-13 12:49:41 --> Router Class Initialized
INFO - 2023-03-13 12:49:41 --> Router Class Initialized
INFO - 2023-03-13 12:49:41 --> Output Class Initialized
INFO - 2023-03-13 12:49:41 --> Output Class Initialized
INFO - 2023-03-13 12:49:41 --> Security Class Initialized
INFO - 2023-03-13 12:49:41 --> Security Class Initialized
DEBUG - 2023-03-13 12:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-13 12:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-13 12:49:41 --> Input Class Initialized
INFO - 2023-03-13 12:49:41 --> Input Class Initialized
INFO - 2023-03-13 12:49:41 --> Language Class Initialized
INFO - 2023-03-13 12:49:41 --> Language Class Initialized
INFO - 2023-03-13 12:49:41 --> Loader Class Initialized
INFO - 2023-03-13 12:49:41 --> Loader Class Initialized
INFO - 2023-03-13 12:49:41 --> Controller Class Initialized
INFO - 2023-03-13 12:49:41 --> Controller Class Initialized
DEBUG - 2023-03-13 12:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-13 12:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-13 12:49:41 --> Database Driver Class Initialized
INFO - 2023-03-13 12:49:41 --> Database Driver Class Initialized
ERROR - 2023-03-13 12:49:51 --> Unable to connect to the database
ERROR - 2023-03-13 12:49:51 --> Unable to connect to the database
INFO - 2023-03-13 12:49:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-13 12:49:51 --> Language file loaded: language/english/db_lang.php
