const config = {
    BASE_URL: "http://192.168.0.126:8081", //接口地址
    API_URL: "http://192.168.0.127:55000",
  };
  sessionStorage.setItem('response', JSON.stringify(config));