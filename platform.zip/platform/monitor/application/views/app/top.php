<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href='<?=base_url().'application/views/plugin/bootstrap-3.3.5/css/bootstrap.css'?>'/>
	<link rel="stylesheet" href='<?=base_url().'application/views/plugin/bootstrap-fileinput/css/fileinput.min.css'?>'/>
	<link rel="stylesheet" href='<?=base_url().'application/views/plugin/font-awesome-4.7.0/css/font-awesome.min.css'?>'/>
	<link rel="stylesheet" href='<?=base_url().'application/views/plugin/bootstrap-table/css/bootstrap-table.css'?>'/>
	<link rel="stylesheet" href='<?=base_url().'application/views/plugin/jedate/css/jedate.css'?>'/>
<!--	<link rel="stylesheet" href='--><?//=base_url().'application/views/plugin/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css'?><!--'/>-->
	<link rel="stylesheet" href="<?=base_url().'application/views/plugin/app/css/style.css'?>">
	<script src="<?=base_url().'application/views/plugin/app/js/jquery-1.11.1.js'?>"></script>
	<script src="<?=base_url().'application/views/plugin/app/js/common.js'?>"></script>
	<script src='<?=base_url().'application/views/plugin/layer/layer.js'?>'></script>
	<script src='<?=base_url().'application/views/plugin/bootstrap-3.3.5/js/bootstrap.min.js'?>'></script>
	<script src='<?=base_url().'application/views/plugin/bootstrap-fileinput/js/fileinput.min.js'?>'></script>
	<script src='<?=base_url().'application/views/plugin/bootstrap-fileinput/js/zh.js'?>'></script>
	<script src='<?=base_url().'application/views/plugin/bootstrap-table/js/bootstrap-table.js'?>'></script>
	<script src='<?=base_url().'application/views/plugin/bootstrap-table/js/bootstrap-table-zh-CN.js'?>'></script>
	<!--<script src='<?/*=base_url().'application/views/plugin/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js'*/?>'></script>
	<script src='<?/*=base_url().'application/views/plugin/bootstrap-datetimepicker/js/bootstrap-datetimepicker.zh-CN.js'*/?>'></script>-->
	<script src="<?=base_url().'application/views/plugin/jedate/js/jedate.js'?>"></script>
	<title>监控管理</title>
</head>
<body class="bg">
